# weft — validations

*Why we believe weft does what we claim, and where the claims stop.*

This document exists to fight self-delusion. It is easy to look at a rendered
page, decide it "works," and ship a lie. So every claim below is tagged by the
**strength of its evidence**, and the honest gaps are listed as plainly as the
wins. If you are evaluating weft, read the **Weak** and **Not validated**
sections first — that is where a demo would mislead you.

The governing principle: **a claim is only as strong as the independent oracle
behind it.** weft is built clean-room against the web platform specs and tested
*differentially* against reference implementations we did not write — the Web
Platform Tests, html5lib, soupsieve, reference codecs, and Python's reference
parsers. Where there is no independent oracle (notably: "does the rendered page
look right?"), the claim is explicitly marked weak.

Run everything: `sbcl --eval '(asdf:test-system "weft")'`. All oracle vectors are
**vendored** under `inspect/vectors/` so the gates are offline and cannot be
gamed by a flaky network.

---

## Strongly validated — independent oracle, exact comparison

These compare weft's output **byte-for-byte or structure-for-structure** against
a reference implementation. Passing means weft agrees with an authority, not with
itself.

| Component | Oracle (independent) | Result |
|---|---|---|
| URL parser | **Web Platform Tests** `urltestdata.json` (the WHATWG conformance suite) — every serialized component compared, failures required to fail | **868 / 888 (97.7%)** |
| Encoding (36 charsets) | the reference codecs themselves (Python `codecs` + `webcolors`), `errors='replace'`; decode every byte sequence | **37,923 / 37,923** |
| HTML tokenizer | **html5lib-tests** tokenizer suite — token stream compared across every initial state | **6,677 / 6,677 (100%)** |
| HTML tree construction → DOM | **html5lib-tests** tree-construction `.dat` suite — serialized DOM tree compared | **338 / 342 (98.8%)** non-fragment |
| DOM query methods | **html5lib** (matched element sets by node path) | **116 / 116** |
| DOM traversal/attributes | **html5lib** | **540 / 540** |
| CSS selectors | **soupsieve** (the same selector run on the same HTML; matched sets compared) | **35 / 35** |
| CSS value parsers (38 types) | spec-precise Python references + `webcolors` | **369 / 369** |
| Content-Encoding + charset (fetch) | real gzip/deflate/brotli/zstd bodies produced by Python; round-tripped | **10 / 10** |
| Sibling codecs (used by fetch) | **libzstd** and the **reference brotli** (node/python): differential fuzz | zstd 150 cases, brotli 1,100 cases — byte-for-byte |
| PNG output | **Pillow (PIL)** opens and validates every PNG weft writes | every render verified loadable |

Why we trust these: the oracle is software we did not author, the comparison is
exact (not "looks similar"), the vectors are vendored, and the harness fails on
mismatch. The selector and DOM oracles were even regenerated with the **html5lib
tree builder** so node paths align with weft's conformant tree — a subtle trap we
caught and fixed rather than papered over.

## Medium — real inputs, weaker assertion

| Component | Evidence | Caveat |
|---|---|---|
| Resource loader | fetches and decodes **live pages** end-to-end (example.com over our own Brotli; Wikipedia 413 KB over gzip) | asserts "decodes to text + doesn't crash", not byte-correctness of every page |
| Layout robustness | renders live 400 KB+ pages and the vendored Acid tests **without crashing** (error-resilient: a bad subtree degrades to an empty box) | "doesn't crash" ≠ "lays out correctly" |
| **Real-page fidelity** | the same browser-diff reftest, pointed at real sites (Playwright screenshot + CSS-inlined HTML → weft renders it → compare). motherfuckingwebsite.com renders near-identically; **Hacker News** renders faithfully (orange header, content-sized table columns, correct link colours) after the fixes it surfaced (rgb() colours, `bgcolor`, `vw/vh`, automatic table layout, `:link`). Text is now measured/painted in the browser's Linux metric-compatible faces via `scribe:match-font` (`font-family` cascade): HN asks for Verdana → LiberationSans, so its box error vs Chromium **dropped 11917 → 1338** (metric-compatible faces, then `line-height:normal` resolved from the face's real hhea ascent/descent/line-gap instead of a flat 1.2×, then block-in-inline hoisting per CSS 2.1 §9.2.1.1), and the `table-test` error dropped **960 → 79**. Both are **CI gates** (HN ≤ 1800, table ≤ 1150). | Static/server-rendered pages only — **no SPA has been rendered end-to-end and diffed against a browser** (the engine exists — see the P4 row — but network-driven fetch → parse → script → relayout is not exercised); very large pages (Wikipedia 946 KB inlined) are slow; `border-collapse` edges differ by 1px; external images/web-fonts aren't fetched (only the shipped Liberation/DejaVu faces are used). The remaining HN residual is **font-environment-specific, not structural**: this Chromium substitutes Verdana→Liberation-Sans, so the rank/votelinks columns auto-size ~18px wider than weft's — not a weft defect, and deliberately not chased (we don't overfit a specific site's font setup). One honest imperfection: the UA `td` padding is kept at 2px (browser default is 1px) because weft's line boxes run slightly shorter than this reference, so 2px compensates — a known local fudge, not spec-perfect. |

## Weak — self-asserted, NO independent oracle ⚠️

**This is the soft underbelly. Treat rendered-page screenshots with suspicion.**

- **Layout correctness** (block/inline/float/flex/table/position, sizing,
  margins). There is *no pixel oracle*. Correctness is judged by **a human (the
  author) eyeballing the output** against what a browser would do. The test
  pages were also written by the author, so they exercise what we already
  support. This is exactly the kind of evidence that produces self-delusion, and
  it is the single weakest claim in the project.
- **Paint** (colors, borders, gradients, text). Same: looks right to the eye,
  not diffed against a reference rendering. Text is now rendered by **scribe**
  (a pure-CL OpenType engine: real glyph outlines, shaping, anti-aliased
  gamma-correct compositing) with weft's 7×13 bitmap as fallback; scribe has its
  own differential oracle (FreeType/HarfBuzz) but weft's *use* of it — baseline
  placement, metric-driven wrapping/alignment — is still author-eyeballed, not
  pixel-diffed.

**This gap is now partly closed.** We built the reference-image diff harness we
said we lacked — two independent pixel/geometry oracles against a **real browser**
(Chromium via Playwright), for Acid2:
- `inspect/acid2-reftest.py` — colour-class agreement of weft's rendered face vs
  the canonical reference smiley, auto-aligned (slide-and-match).
- `inspect/acid2-layout-dump.lisp` + `inspect/acid2-layout-diff.py` — a
  **per-element** diff: every `.picture` descendant's box (x,y,w,h) vs Chromium's
  ground truth (`acid2-browser-layout.json`), so a regression names the element
  and the delta. This generalizes to a layout reftest for **any** page.
On Acid2 these reached **100% pixel match** — 0 of 21,160 non-white face pixels
disagree with the reference (colour-class). The final 24-pixel residual was *not*
anti-aliasing (we checked: every pixel was pure black or yellow) but a genuine
half-pixel scanline-sampling bug in the polygon rasterizer, found and fixed. This
is the first *independent, exact* validation of
weft's layout+paint. The caveat stands for everything ELSE: general layout
correctness on arbitrary pages is still author-eyeballed — but the tooling to
diff any page against a real browser now exists.

## Not validated / known limits — stated plainly

- **JavaScript exists now, but "runs script" is not "runs the web."** `weft/script`
  binds **shuttle** (our clean-room Lisp-native JS engine, **87.99%** of test262)
  to the live DOM: inline `<script>` reads and mutates the tree and the change is
  reflected on relayout, with events, timers, mutation observers, CSSOM, canvas,
  SVG, ranges. What is *not* validated is the thing the old claim was really
  about — **no SPA has been rendered end-to-end and diffed against a browser.**
  The Web IDL surface is broad and thinly covered outside the areas with a WPT
  gate (forms IDL is at 2,832 subtests; everything else is unmeasured), and
  network-driven rendering (fetch → parse → script → relayout as a loop) is not
  exercised. Treat "weft runs JavaScript" as true of the *engine* and unproven
  of the *page*.
- **Acid3 scores 100/100** on its own scripted conformance — the page's `score`
  global, with `index` reaching 100 of 100 tests, mirrored into `#score`. It is
  ~99% JavaScript (183 `createElement`, 14 `<script>` blocks) and was correctly
  listed as unrunnable while there was no engine; that reason expired when
  shuttle landed. Re-run with
  `sbcl --non-interactive --load inspect/acid3.lisp --eval '(weft.acid3:run)'`
  (the file's own `--script` usage line is stale — `--script` skips the init that
  puts sibling systems on the source registry, so `pigment` is not found).
  Two qualifications, both honest:
  - **This is the scripted score, not a full Acid3 pass.** The official test also
    requires the rendering to match its reference pixel-for-pixel and the title
    to read `Acid3`; we compare neither. Acid2 has that pixel oracle, Acid3 does
    not yet.
  - The run logs `Total elapsed time: -0.79s`, which is *not* a clock bug. Acid3
    computes `(endTime - startTime) - delay * tests.length` with `delay = 10`,
    subtracting 1000 ms of `setTimeout` it assumes were really waited; our event
    loop drains timers immediately, so ~0.21 s of real work minus 1.0 s goes
    negative. The companion "took 133 ms (less than 30fps)" line is a
    performance note Acid3 logs against a test it still counts as passed.
- **Acid2 renders at 100% pixel-match vs a real browser** (up from ~0%). Driven
  to convergence by an objective oracle (the per-element + colour-class diffs
  above), the face assembles correctly: crown, two green-pupil eyes, black
  diamond nose, curved smile, chin — colour-class agreement **100%** (0/21,160
  face pixels mismatched), stray-red (Acid2's error colour) **0%**. Getting here built and verified a long list of
  *general* engine features, each oracle-gated and re-checked in the canonical
  tree: generated content, data-URI/element/**fixed**-attachment background
  images (+ PNG tRNS/Adam7), `<object>` images, the full positioning + viewport +
  scroll-to-anchor model, CSS2.1 margin collapsing, percentage sizing, a complete
  per-edge/mitered **border model**, appendix-E paint order, anonymous table rows
  + shrink-to-fit, line-box metrics from real fonts, **standards/quirks-mode
  DOCTYPE** determination, and several CSS parser/selector conformance fixes.
  Honest limits: the match is by *colour class* (yellow/black/green/red/white)
  against the reference *image*, not a byte-identical framebuffer diff — though
  the mismatched-pixel count is a literal 0; and Acid2's interactive `:hover`
  sub-tests are not exercised (static render only). With those caveats stated, it
  is **a 100% pixel-match, independently measured against a real browser**.
- **No CSS grid, no `inline-block` baseline alignment.** Text is real now
  (scribe: anti-aliased, font-metric-driven advances/wrapping); remaining text
  gaps are **fake-bold** (stem-darkening, no bold font vendored) and **per-line
  mixed-font-size baseline sharing** (each inline size is centered in the line
  box independently rather than on a common baseline — fine for uniform lines).
- **URL: ~2.3% fail** — full UTS-46 IDNA mapping tables not implemented.
- **Tree construction: 4 fail** — the deepest adoption-agency × table
  foster-parenting cases; 21 fragment-parsing cases skipped.
- **The swarm** (DeepSeek-Flash via OpenRouter) wrote a number of CSS value
  parsers (most recently `object-fit`, `text-indent`, `background-repeat`,
  `background-position`), but **no swarm output is trusted on its word.** Every
  file is re-verified in the main tree (clean-cache compile + full gate) before
  it counts; see `tools/swarm/README.md` for the
  isolation proof (a stub in a worker copy fails even when main is correct) and
  the stale-cache defenses. Several "passing" swarm results were caught as false
  by this re-verify and rewritten by hand.

## The Acid tests as a permanent gate

`inspect/acid-test.lisp` (in `weft/test`) renders the vendored `acid2.html` and
`acid3.html` on every run as a **robustness guard** — the build fails if these
real, gnarly pages ever *error*. Conformance is measured separately and honestly:

- **Acid2** — `inspect/acid2-reftest.py` (colour-class match vs the reference
  smiley) and `inspect/acid2-layout-diff.py` (per-element box diff vs Chromium
  ground truth). Currently **100% pixel-match, 0% stray red** (0/21,160 face pixels
  mismatched). The grind from ~0% → 100% is recorded commit-by-commit (each subject
  carries its `face-ink`/`face-geom` delta). Re-run: render via
  `(weft.acid.test:run)`, then the two scripts.
- **Acid3** — **100/100 scripted** (`inspect/acid3.lisp`; the page's own `score`
  global, `index` 100/100). Rendering is *not* compared against the Acid3
  reference, so this is the script conformance number and not a full pass.

**These are now permanent CI gates.** `inspect/acid2-conformance.lisp`
(`weft.acid2.conformance:run`, wired into `test-op`) re-runs both checks in pure
CL on every `asdf:test-system` — no Python at run time. It decodes the vendored
reference PNG with weft's own `png-decode`, colour-class matches the rendered
face (bounded auto-align), and diffs every element's box against the vendored
`acid2-browser-layout.json`. It **fails the build** if face-pixel mismatch, the
visible-face geometry error, or the total geometry error exceed their bounds
(currently 0 / 6 / 377 against 40 / 60 / 700). The remaining geometry error
is deliberately-unfixed Acid2 scaffolding (the parser-quirk table, the giant-font
image-height torture line, the fixed-`p` coordinate-frame offset) — not a defect,
which is why the bound has headroom rather than being driven to 0. The `.py`
scripts remain for ad-hoc inspection / regenerating the browser ground truth.

**Caveat, recorded because it cost a bisect:** this gate runs *only* under
`asdf:test-system "weft"`. The forms-swarm gates (`forms-oracle`,
`nonforms-gate.sh`) never invoke it, and it sat **red and unnoticed for ~550
commits** — HN box error had regressed 900 → 12,924 and fitted comfortably
under a bound carrying 2.8× headroom. Two lessons are now policy here: run
`asdf:test-system` alongside the swarm gates, and keep every bound's headroom
modest, because a bound nobody can trip is a bound nobody re-baselines.

---

*Last updated alongside the Acid2 grind (→ 100% pixel-match). If a number here
disagrees with `asdf:test-system` or the `inspect/acid2-*` oracles, those are
right and this file is stale — fix this file.*
