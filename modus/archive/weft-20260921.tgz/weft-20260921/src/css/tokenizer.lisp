;;;; src/css/tokenizer.lisp — CSS tokenizer (CSS Syntax Level 3 §4).
;;;;
;;;; Code points in -> tokens out.  Covers the token types a stylesheet parser
;;;; needs: whitespace, ident, function, at-keyword, hash, string, url, number,
;;;; dimension, percentage, delim, and the bracket/colon/semicolon/comma tokens.
;;;; Comments are stripped.  Used by the rule/declaration parser (parser.lisp).
(in-package #:weft.css)

(defstruct ctok type value unit)   ; type keyword; value string/number; unit for dimension

(declaim (inline ws-p name-start-p name-p digit-p))
(defun ws-p (c) (member c '(#\Space #\Tab #\Newline #\Return #\Page)))
(defun name-start-p (c) (or (alpha-char-p c) (char= c #\_) (> (char-code c) 127)))
(defun name-p (c) (or (name-start-p c) (digit-char-p c) (char= c #\-)))
(defun digit-p (c) (and c (digit-char-p c)))

(defun css-tokenize (input)
  "Tokenize INPUT (a CSS string) into a vector of CTOKs."
  (let* ((s input) (n (length s)) (i 0) (out '()))
    (labels ((cur () (when (< i n) (char s i)))
             (la (k) (let ((j (+ i k))) (when (< j n) (char s j))))
             (emit (ty &optional v u) (push (make-ctok :type ty :value v :unit u) out))
             (consume-comment ()
               (incf i 2)
               (loop while (< i n) do
                 (if (and (char= (char s i) #\*) (eql (la 1) #\/)) (progn (incf i 2) (return)) (incf i))))
             (consume-string (q)
               (incf i)
               (let ((b (make-string-output-stream)))
                 (loop while (< i n) do
                   (let ((c (char s i)))
                     (cond ((char= c q) (incf i) (return))
                           ;; CSS escapes decode inside strings too (Syntax 4.3.7):
                           ;; `\a0 ` -> U+00A0, `\"` -> a literal quote.  Share the
                           ;; hex-aware decoder with idents (was: naive next-char).
                           ((char= c #\\)
                            (if (and (< (1+ i) n) (char= (char s (1+ i)) #\Newline))
                                (incf i 2)             ; escaped newline: line continuation
                                (consume-escape b)))
                           ((char= c #\Newline) (return))   ; bad string
                           (t (write-char c b) (incf i)))))
                 (emit :string (get-output-stream-string b))))
             (consume-escape (b)
               ;; I is at a backslash.  CSS: `\` + 1-6 hex digits (+ optional one
               ;; trailing whitespace) is a hex escape decoded to that code point;
               ;; otherwise the next char is taken literally.  Acid2's `m\argin`
               ;; is thus "m"+U+000A+"rgin" (NOT "margin") -> an unknown property.
               (incf i)
               (cond ((>= i n) nil)
                     ((digit-char-p (char s i) 16)
                      (let ((start i))
                        (loop while (and (< i n) (< (- i start) 6) (digit-char-p (char s i) 16)) do (incf i))
                        (let ((code (parse-integer s :start start :end i :radix 16)))
                          (when (and (< i n) (ws-p (char s i))) (incf i))
                          (write-char (if (or (zerop code) (> code #x10FFFF)) (code-char #xFFFD)
                                          (code-char code)) b))))
                     (t (write-char (char s i) b) (incf i))))
             (consume-name ()
               (let ((b (make-string-output-stream)))
                 (loop while (and (< i n) (or (name-p (char s i))
                                              (and (char= (char s i) #\\) (< (1+ i) n)))) do
                   (if (char= (char s i) #\\)
                       (consume-escape b)
                       (progn (write-char (char s i) b) (incf i))))
                 (get-output-stream-string b)))
             (number-start-p ()
               (let ((c (cur)))
                 (or (digit-p c)
                     (and (member c '(#\+ #\-)) (or (digit-p (la 1))
                                                    (and (eql (la 1) #\.) (digit-p (la 2)))))
                     (and (char= c #\.) (digit-p (la 1))))))
             (consume-number ()
               (let ((start i))
                 (when (member (cur) '(#\+ #\-)) (incf i))
                 (loop while (and (< i n) (digit-p (char s i))) do (incf i))
                 (when (and (< i n) (char= (char s i) #\.) (digit-p (la 1)))
                   (incf i) (loop while (and (< i n) (digit-p (char s i))) do (incf i)))
                 (when (and (< i n) (member (char s i) '(#\e #\E))
                            (or (digit-p (la 1))
                                (and (member (la 1) '(#\+ #\-)) (digit-p (la 2)))))
                   (incf i) (when (member (cur) '(#\+ #\-)) (incf i))
                   (loop while (and (< i n) (digit-p (char s i))) do (incf i)))
                 (safe-number (subseq s start i)))))
      (loop while (< i n) do
        (let ((c (char s i)))
          (cond
            ((and (char= c #\/) (eql (la 1) #\*)) (consume-comment))
            ;; CDO `<!--` and CDC `-->` (CSS Syntax §4.3.1): SGML comment delimiters,
            ;; historically wrapped around a stylesheet's rules.  Skip them (they are
            ;; discarded at the stylesheet top level) so `<!-- div{...} -->` parses.
            ((and (char= c #\<) (eql (la 1) #\!) (eql (la 2) #\-) (eql (la 3) #\-)) (incf i 4))
            ((and (char= c #\-) (eql (la 1) #\-) (eql (la 2) #\>)) (incf i 3))
            ((ws-p c) (loop while (and (< i n) (ws-p (char s i))) do (incf i)) (emit :ws))
            ((or (char= c #\") (char= c #\')) (consume-string c))
            ((char= c #\#)
             (incf i)
             (if (and (< i n) (or (name-p (char s i)) (char= (char s i) #\\)))
                 (emit :hash (consume-name))
                 (emit :delim "#")))
            ((number-start-p)
             (let ((num (consume-number)))
               (cond ((and (< i n) (char= (char s i) #\%)) (incf i) (emit :percentage num))
                     ((and (< i n) (or (name-start-p (char s i)) (char= (char s i) #\\)))
                      (emit :dimension num (consume-name)))
                     (t (emit :number num)))))
            ((or (name-start-p c) (and (char= c #\-) (or (name-start-p (la 1)) (eql (la 1) #\-)
                                                         (eql (la 1) #\\)))
                 (and (char= c #\\) (la 1)))
             (let ((name (consume-name)))
               (cond
                 ((and (< i n) (char= (char s i) #\())
                  (incf i)
                  (if (string-equal name "url")
                      ;; url( ... ) — quoted arg => function-ish; else raw url token
                      (progn
                        (loop while (and (< i n) (ws-p (char s i))) do (incf i))
                        (if (and (< i n) (member (char s i) '(#\" #\')))
                            (progn (emit :function "url"))   ; let parser read the string + )
                            (let ((b (make-string-output-stream)))
                              (loop while (and (< i n) (not (char= (char s i) #\)))) do
                                (unless (ws-p (char s i)) (write-char (char s i) b)) (incf i))
                              (when (< i n) (incf i))   ; consume )
                              (emit :url (get-output-stream-string b)))))
                      (emit :function name)))
                 (t (emit :ident name)))))
            ((char= c #\@)
             (incf i)
             ;; @ starts an at-keyword only when the following chars would start an
             ;; identifier (CSS Syntax §4.3.3): a name-start, or `-` + (name-start /
             ;; `-` / escape).  `@-1import` (a `-` then a digit) is NOT an ident
             ;; start, so the @ is a lone delim and `-1import` follows separately.
             (if (and (< i n)
                      (or (name-start-p (char s i))
                          (and (char= (char s i) #\-)
                               (or (name-start-p (la 1)) (eql (la 1) #\-) (eql (la 1) #\\)))))
                 (emit :at-keyword (consume-name))
                 (emit :delim "@")))
            ((char= c #\() (incf i) (emit :lparen))
            ((char= c #\)) (incf i) (emit :rparen))
            ((char= c #\{) (incf i) (emit :lbrace))
            ((char= c #\}) (incf i) (emit :rbrace))
            ((char= c #\[) (incf i) (emit :lbracket))
            ((char= c #\]) (incf i) (emit :rbracket))
            ((char= c #\:) (incf i) (emit :colon))
            ((char= c #\;) (incf i) (emit :semicolon))
            ((char= c #\,) (incf i) (emit :comma))
            (t (incf i) (emit :delim (string c))))))
      (coerce (nreverse out) 'vector))))
