;;;; src/html/tree.lisp — HTML tree construction (WHATWG §13.2.6).
;;;;
;;;; Consumes tokenizer tokens into a DOM document via the insertion-mode state
;;;; machine.  Covers the document skeleton (initial/before-html/before-head/
;;;; in-head/after-head), the bulk of "in body" (text, blocks with implied <p>
;;;; closing, headings, list items, generic start/end with implied end tags),
;;;; raw-text/RCDATA reentrancy, and the TABLE modes (in-table / in-table-text /
;;;; in-table-body / in-row / in-cell) with foster parenting.  Still follow-ups:
;;;; the adoption agency algorithm (formatting misnesting), <select>, captions/
;;;; colgroups in full, foreign content, and fragment parsing.
(in-package #:weft.html)

(defparameter *void* '("area" "base" "br" "col" "embed" "hr" "img" "input"
                       "keygen" "link" "meta" "param" "source" "track" "wbr"))
(defparameter *head-void* '("base" "basefont" "bgsound" "link" "meta"))
(defparameter *block-closes-p*
  '("address" "article" "aside" "blockquote" "center" "details" "dialog" "dir"
    "div" "dl" "fieldset" "figcaption" "figure" "footer" "header" "hgroup" "main"
    "menu" "nav" "ol" "p" "section" "summary" "ul" "pre" "listing"
    "form" "fieldset"))
(defparameter *headings* '("h1" "h2" "h3" "h4" "h5" "h6"))
;; block container end tags: generate implied end tags, then pop to the element
(defparameter *block-end-tags*
  '("address" "article" "aside" "blockquote" "button" "center" "details" "dialog"
    "dir" "div" "dl" "fieldset" "figcaption" "figure" "footer" "header" "hgroup"
    "listing" "main" "menu" "nav" "ol" "pre" "section" "summary" "ul"))
;; "has an element in scope" boundary sets (WHATWG §13.2.4.2)
(defparameter *scope-bounds* '("applet" "caption" "html" "table" "td" "th" "marquee" "object" "template"))
(defparameter *button-scope* (cons "button" *scope-bounds*))
(defparameter *implied-end* '("dd" "dt" "li" "optgroup" "option" "p" "rb" "rp" "rt" "rtc"))
(defparameter *formatting* '("a" "b" "big" "code" "em" "font" "i" "nobr" "s"
                             "small" "strike" "strong" "tt" "u"))
;; "special" category (subset relevant to the adoption agency furthest-block search)
(defparameter *special*
  '("address" "applet" "area" "article" "aside" "base" "basefont" "bgsound"
    "blockquote" "body" "br" "button" "caption" "center" "col" "colgroup" "dd"
    "details" "dir" "div" "dl" "dt" "embed" "fieldset" "figcaption" "figure"
    "footer" "form" "frame" "frameset" "h1" "h2" "h3" "h4" "h5" "h6" "head"
    "header" "hgroup" "hr" "html" "iframe" "img" "input" "li" "link" "listing"
    "main" "marquee" "menu" "meta" "nav" "noembed" "noframes" "noscript"
    "object" "ol" "p" "param" "plaintext" "pre" "script" "section" "select"
    "source" "style" "summary" "table" "tbody" "td" "template" "textarea"
    "tfoot" "th" "thead" "title" "tr" "track" "ul" "wbr" "xmp"))
(defparameter *ws* '(#\Tab #\Newline #\Page #\Return #\Space))
;; start tags ignored in "in body" (they belong to table/frame/head contexts)
(defparameter *in-body-ignored-starts*
  '("caption" "col" "colgroup" "frame" "head" "tbody" "td" "tfoot" "th" "thead" "tr"))

(defun ws-char-tok-p (tk)
  ;; A character token whose data is entirely whitespace.  Character tokens now
  ;; carry a coalesced run, so test every character (an empty run counts as ws).
  (and (eq (tok-type tk) :char)
       (every (lambda (c) (member c *ws*)) (tok-data tk))))

(defparameter *rawtext-els* '("style" "xmp" "iframe" "noembed" "noframes" "script"))
(defparameter *rcdata-els* '("title" "textarea"))

;; HTML5 "quirks mode" DOCTYPE determination (13.2.6.1).  Public identifiers
;; that force quirks regardless of system id — exact matches and prefixes.
(defparameter *quirks-public-exact*
  '("-//w3o//dtd w3 html strict 3.0//en//"
    "-/w3c/dtd html 4.0 transitional/en" "html"))
(defparameter *quirks-public-prefixes*
  '("+//silmaril//dtd html pro v0r11 19970101//"
    "-//as//dtd html 3.0 aswedit + extensions//"
    "-//advasoft ltd//dtd html 3.0 aswedit + extensions//"
    "-//ietf//dtd html 2.0 level 1//" "-//ietf//dtd html 2.0 level 2//"
    "-//ietf//dtd html 2.0 strict level 1//" "-//ietf//dtd html 2.0 strict level 2//"
    "-//ietf//dtd html 2.0 strict//" "-//ietf//dtd html 2.0//"
    "-//ietf//dtd html 2.1e//" "-//ietf//dtd html 3.0//"
    "-//ietf//dtd html 3.2 final//" "-//ietf//dtd html 3.2//"
    "-//ietf//dtd html 3//" "-//ietf//dtd html level 0//"
    "-//ietf//dtd html level 1//" "-//ietf//dtd html level 2//"
    "-//ietf//dtd html level 3//" "-//ietf//dtd html strict level 0//"
    "-//ietf//dtd html strict level 1//" "-//ietf//dtd html strict level 2//"
    "-//ietf//dtd html strict level 3//" "-//ietf//dtd html strict//"
    "-//ietf//dtd html//" "-//metrius//dtd metrius presentational//"
    "-//microsoft//dtd internet explorer 2.0 html strict//"
    "-//microsoft//dtd internet explorer 2.0 html//"
    "-//microsoft//dtd internet explorer 2.0 tables//"
    "-//microsoft//dtd internet explorer 3.0 html strict//"
    "-//microsoft//dtd internet explorer 3.0 html//"
    "-//microsoft//dtd internet explorer 3.0 tables//"
    "-//netscape comm. corp.//dtd html//"
    "-//netscape comm. corp.//dtd strict html//"
    "-//o'reilly and associates//dtd html 2.0//"
    "-//o'reilly and associates//dtd html extended 1.0//"
    "-//o'reilly and associates//dtd html extended relaxed 1.0//"
    "-//sq//dtd html 2.0 hotmetal + extensions//"
    "-//softquad software//dtd hotmetal pro 6.0::19990601::extensions to html 4.0//"
    "-//softquad//dtd hotmetal pro 4.0::19971010::extensions to html 4.0//"
    "-//spyglass//dtd html 2.0 extended//"
    "-//sun microsystems corp.//dtd hotjava html//"
    "-//sun microsystems corp.//dtd hotjava strict html//"
    "-//w3c//dtd html 3 1995-03-24//" "-//w3c//dtd html 3.2 draft//"
    "-//w3c//dtd html 3.2 final//" "-//w3c//dtd html 3.2//"
    "-//w3c//dtd html 3.2s draft//" "-//w3c//dtd html 4.0 frameset//"
    "-//w3c//dtd html 4.0 transitional//" "-//w3c//dtd html experimental 19960712//"
    "-//w3c//dtd html experimental 970421//" "-//w3c//dtd w3 html//"
    "-//w3o//dtd w3 html 3.0//" "-//webtechs//dtd mozilla html 2.0//"
    "-//webtechs//dtd mozilla html//"))
;; These two are quirks only when the system identifier is absent.
(defparameter *quirks-public-prefixes-no-system*
  '("-//w3c//dtd html 4.01 frameset//" "-//w3c//dtd html 4.01 transitional//"))

(defun ci-prefix-p (prefix s)
  (and s (>= (length s) (length prefix))
       (string-equal prefix (subseq s 0 (length prefix)))))

(defun doctype-quirks-p (name public system force)
  "True when a DOCTYPE puts the document in (full) quirks mode (HTML5 13.2.6.1).
Limited-quirks counts as NON-quirks here — only full quirks suppresses e.g.
<table> closing an open <p>."
  (or force
      (not (equal name "html"))
      (and public (member public *quirks-public-exact* :test #'string-equal))
      (and public (some (lambda (p) (ci-prefix-p p public)) *quirks-public-prefixes*))
      (and system (string-equal system "http://www.ibm.com/data/dtd/v11/ibmxhtml1-transitional.dtd"))
      (and (null system) public
           (some (lambda (p) (ci-prefix-p p public)) *quirks-public-prefixes-no-system*))))

(defun parse-html (input &key context)
  "Parse an HTML string into a DOM document.  When CONTEXT (a lower-case tag
name string) is supplied, parse INPUT as an HTML fragment in that element's
context (WHATWG §13.4): the returned document holds a single <html> element
whose children are the fragment nodes."
  (multiple-value-bind (tklist src) (tokenize input)
   (let* ((toks (coerce tklist 'vector)) (ntok (length toks)) (s src)
          (doc (make-document)) (open '()) (mode :initial) (orig-mode nil)
          (head nil) (i 0) (reconsume nil) (fostering nil) (pending nil) (drop-nl nil)
          (form-ptr nil) (frameset-ok t) (quirks t)
          (afe (make-array 0 :adjustable t :fill-pointer 0)))   ; active formatting elements
    (labels
        ((current () (car open))
         (top-name () (and open (dnode-name (current))))
         (switch (m) (setf mode m))
         (reproc () (setf reconsume t))
         ;; ---- insertion location (with foster parenting) ----
         (foster-place ()
           (if (and fostering
                    (member (top-name) '("table" "tbody" "tfoot" "thead" "tr") :test #'equal))
               (let ((last-table (find "table" open :key #'dnode-name :test #'equal)))
                 (if (and last-table (dnode-parent last-table))
                     (values (dnode-parent last-table) last-table)
                     (let ((pos (position last-table open)))
                       (values (nth (1+ pos) open) nil))))
               (values (current) nil)))
         (insert-node (node)
           (multiple-value-bind (parent before) (foster-place)
             (dom-insert-before parent node before)))
         (push-el (el) (push el open) el)
         (insert-element (name &optional attrs (ns :html))
           (let ((el (make-element name attrs ns)))
             (when form-ptr
               (setf (dnode-form-ptr el) form-ptr))
             (insert-node el) (push-el el) el))
         (insert-void (name &optional attrs)
           (let ((el (make-element name attrs)))
             (when form-ptr
               (setf (dnode-form-ptr el) form-ptr))
             (insert-node el)))
         (insert-text (data)
           (multiple-value-bind (parent before) (foster-place)
             (let ((prev (dom-prev-sibling parent before)))
               (if (and prev (eq (dnode-kind prev) :text))
                   (setf (dnode-data prev) (concatenate 'string (dnode-data prev) data))
                   (dom-insert-before parent (make-text data) before)))))
         ;; ---- raw text / RCDATA (tokenizer reentrancy) ----
         ;; Re-tokenize the source after the start tag in the element's content
         ;; model (RAWTEXT or RCDATA), take its leading characters as the element
         ;; text, then splice the post-end-tag tokens back onto the main stream.
         (raw-element (tk rcdata-p)
           (let* ((name (tok-name tk)) (el (make-element name (tok-attrs tk)))
                  (state (if rcdata-p :rcdata :rawtext))
                  (rest (subseq s (1+ (tok-cend tk))))
                  (rtoks (coerce (tokenize rest :state state :last-start-tag name) 'vector))
                  (endpos (position-if (lambda (x) (and (eq (tok-type x) :end-tag)
                                                        (equal (tok-name x) name)))
                                       rtoks))
                  (text (with-output-to-string (o)
                          (loop for k from 0 below (or endpos (length rtoks))
                                for x = (aref rtoks k)
                                when (eq (tok-type x) :char) do (write-string (tok-data x) o)))))
             ;; <textarea> drops a single leading newline
             (when (and (equal name "textarea") (plusp (length text))
                        (char= (char text 0) #\Newline))
               (setf text (subseq text 1)))
             (insert-node el)
             (when (plusp (length text)) (dom-append el (make-text text)))
             ;; rebase the token stream + source onto the remainder past the end tag
             (let ((tail (if endpos (subseq rtoks (1+ endpos))
                             (vector (make-tok :type :eof)))))
               (setf toks (concatenate 'vector (subseq toks 0 (1+ i)) tail)
                     ntok (length toks)
                     s rest))))
         ;; ---- scope queries ----
         (in-scope (name &optional (bounds *scope-bounds*))
           (loop for el in open do
             (cond ((equal (dnode-name el) name) (return t))
                   ((member (dnode-name el) bounds :test #'equal) (return nil)))))
         (in-table-scope (name)
           (in-scope name '("html" "table" "template")))
         (in-select-scope (name)                     ; everything is a bound except optgroup/option
           (loop for el in open do
             (cond ((equal (dnode-name el) name) (return t))
                   ((not (member (dnode-name el) '("optgroup" "option") :test #'equal)) (return nil)))))
         (gen-implied (&optional except)
           (loop while (and open (member (top-name) *implied-end* :test #'equal)
                            (not (equal (top-name) except)))
                 do (pop open)))
         (close-p ()
           (when (in-scope "p" *button-scope*)
             (gen-implied "p")
             (loop while (and open (not (equal (top-name) "p"))) do (pop open))
             (when open (pop open))))
         (pop-until (name)
           (gen-implied name)
           (when (in-scope name)
             (loop while (and open (not (equal (top-name) name))) do (pop open))
             (when open (pop open))))
         ;; ---- table stack clearing ----
         (clear-to (names)
           (loop while (and open (not (member (top-name) names :test #'equal))) do (pop open)))
         (reset-mode ()
           (loop for el in open do
             (let ((n (dnode-name el)))
               (cond ((member n '("td" "th") :test #'equal) (return (switch :in-cell)))
                     ((equal n "tr") (return (switch :in-row)))
                     ((member n '("tbody" "tfoot" "thead") :test #'equal) (return (switch :in-table-body)))
                     ((equal n "table") (return (switch :in-table)))
                     ((equal n "head") (return (switch :in-body)))
                     ((equal n "body") (return (switch :in-body)))
                     ((equal n "html") (return (switch :in-body)))))))
         ;; ---- active formatting elements (AFE) ----
         (push-marker () (vector-push-extend :marker afe))
         (clear-afe-to-marker ()
           (loop while (plusp (length afe))
                 for top = (aref afe (1- (length afe)))
                 do (decf (fill-pointer afe))
                 until (eq top :marker)))
         (same-fmt (a b)                            ; same name + attributes
           (and (equal (dnode-name a) (dnode-name b))
                (null (set-exclusive-or (dnode-attrs a) (dnode-attrs b) :test #'equal))))
         (push-afe (el)
           ;; Noah's Ark: at most 3 equal entries since the last marker
           (let ((count 0))
             (loop for k from (1- (length afe)) downto 0
                   for e = (aref afe k)
                   until (eq e :marker)
                   when (and (not (eq e :marker)) (same-fmt e el)) do (incf count))
             (when (>= count 3)
               (loop for k from 0 below (length afe)
                     for e = (aref afe k)
                     when (and (not (eq e :marker)) (same-fmt e el))
                       do (loop for j from k below (1- (length afe)) do (setf (aref afe j) (aref afe (1+ j))))
                          (decf (fill-pointer afe))
                          (return))))
           (vector-push-extend el afe))
         (afe-remove (el)
           (let ((k (position el afe)))
             (when k (loop for j from k below (1- (length afe)) do (setf (aref afe j) (aref afe (1+ j))))
                   (decf (fill-pointer afe)))))
         (reconstruct-afe ()
           (when (plusp (length afe))
             (let ((idx (1- (length afe))))
               (unless (or (eq (aref afe idx) :marker) (member (aref afe idx) open))
                 (loop                                ; rewind to an entry that is a marker / open / first
                   (if (zerop idx) (return))
                   (decf idx)
                   (when (or (eq (aref afe idx) :marker) (member (aref afe idx) open))
                     (incf idx) (return)))
                 (loop                                ; create clones forward
                   (let* ((old (aref afe idx))
                          (new (insert-element (dnode-name old) (dnode-attrs old))))
                     (setf (aref afe idx) new)
                     (when (= idx (1- (length afe))) (return))
                     (incf idx)))))))
         (last-fmt (name)                            ; last AFE element named NAME after last marker
           (loop for k from (1- (length afe)) downto 0
                 for e = (aref afe k)
                 when (eq e :marker) do (return nil)
                 when (and (not (eq e :marker)) (equal (dnode-name e) name)) do (return e)))
         ;; ---- the adoption agency algorithm (WHATWG §13.2.6.4.7) ----
         (adoption-agency (subject)
           (let ((cur (current)))
             (when (and cur (equal (dnode-name cur) subject) (not (position cur afe)))
               (pop open) (return-from adoption-agency)))
           (dotimes (outer 8)
             (let ((fmt (last-fmt subject)))
               (when (null fmt) (body-end-generic subject) (return-from adoption-agency))
               (unless (member fmt open) (afe-remove fmt) (return-from adoption-agency))
               (unless (in-scope (dnode-name fmt)) (return-from adoption-agency))
               (let* ((fmt-open-pos (position fmt open))   ; 0 = newest
                      (furthest nil))
                 ;; furthest block: the special element newer than fmt closest to it
                 ;; (newer = lower index; take the first match scanning toward 0)
                 (loop for k from (1- fmt-open-pos) downto 0
                       for el = (nth k open)
                       when (member (dnode-name el) *special* :test #'equal)
                         do (setf furthest el) (return))
                 (when (null furthest)
                   (loop while (and open (not (eq (current) fmt))) do (pop open))
                   (pop open) (afe-remove fmt) (return-from adoption-agency))
                 (let* ((ca (nth (1+ fmt-open-pos) open))   ; common ancestor (above fmt)
                        (bookmark (position fmt afe))
                        (node nil) (last-node furthest) (inner 0)
                        (node-idx (position furthest open)))   ; track position across removals
                   (loop
                     (incf inner)
                     (incf node-idx)                          ; element above (older)
                     (when (>= node-idx (length open)) (return))
                     (setf node (nth node-idx open))
                     (when (eq node fmt) (return))
                     (let ((in-afe (position node afe)))
                       (when (and (> inner 3) in-afe) (afe-remove node) (setf in-afe nil))
                       (cond
                         ((null in-afe)                        ; drop node from open; keep index aligned
                          (setf open (remove node open)) (decf node-idx))
                         (t
                          (let ((clone (make-element (dnode-name node) (dnode-attrs node))))
                            (setf (aref afe (position node afe)) clone)
                            (setf open (substitute clone node open))
                            (setf node clone)
                            (when (eq last-node furthest) (setf bookmark (1+ (position clone afe))))
                            (dom-remove last-node) (dom-append clone last-node)
                            (setf last-node clone))))))
                   ;; place last-node into the common ancestor (foster-aware)
                   (dom-remove last-node)
                   (if (member (dnode-name ca) '("table" "tbody" "tfoot" "thead" "tr") :test #'equal)
                       (let ((lt (find "table" open :key #'dnode-name :test #'equal)))
                         (if (and lt (dnode-parent lt)) (dom-insert-before (dnode-parent lt) last-node lt)
                             (dom-append ca last-node)))
                       (dom-append ca last-node))
                   ;; clone fmt, move furthest's children into it, append to furthest
                   (let ((clone (make-element (dnode-name fmt) (dnode-attrs fmt))))
                     (dom-move-children furthest clone)
                     (dom-append furthest clone)
                     ;; AFE: remove fmt, insert clone at bookmark
                     (afe-remove fmt)
                     (let ((bm (min (or bookmark (length afe)) (length afe))))
                       (vector-push-extend nil afe)
                       (loop for k from (1- (length afe)) above bm do (setf (aref afe k) (aref afe (1- k))))
                       (setf (aref afe bm) clone))
                     ;; open: remove fmt, insert clone immediately newer than furthest
                     ;; (newer = lower index, i.e. just before furthest in the list)
                     (setf open (remove fmt open))
                     (let ((fp (position furthest open)))
                       (setf open (append (subseq open 0 fp) (list clone)
                                          (subseq open fp))))))))))
         ;; ---- "in body" start/end, reusable from table fallthroughs ----
         (body-end-generic (name)
           ;; "any other end tag": walk from current; match -> pop to it; hit a
           ;; special element first -> ignore the end tag.
           (loop for node in open do
             (cond ((equal (dnode-name node) name)
                    (gen-implied name)
                    (loop while (and open (not (eq (current) node))) do (pop open))
                    (when open (pop open))
                    (return))
                   ((member (dnode-name node) *special* :test #'equal) (return)))))
         (merge-attrs (el attrs)
           (dolist (a attrs)
             (unless (assoc (car a) (dnode-attrs el) :test #'string=)
               (setf (dnode-attrs el) (append (dnode-attrs el) (list a))))))
         (plaintext-element (tk)
           (let ((el (make-element "plaintext" (tok-attrs tk)))
                 (rest (subseq s (1+ (tok-cend tk)))))
             (insert-node el)
             (when (plusp (length rest)) (dom-append el (make-text rest)))
             (setf toks (concatenate 'vector (subseq toks 0 (1+ i)) (vector (make-tok :type :eof)))
                   ntok (length toks) s "")))
         (body-start (tk name)
           (when (equal name "image") (setf name "img"))   ; legacy alias
           (cond
             ((equal name "html")
              (merge-attrs (find "html" open :key #'dnode-name :test #'equal) (tok-attrs tk)))
             ((equal name "body")
              (let ((b (find "body" open :key #'dnode-name :test #'equal)))
                (when b (setf frameset-ok nil) (merge-attrs b (tok-attrs tk)))))
             ((equal name "plaintext")
              (when (in-scope "p" *button-scope*) (close-p))
              (setf frameset-ok nil) (plaintext-element tk))
             ((member name *in-body-ignored-starts* :test #'equal))   ; parse error, ignore
             ((equal name "xmp")                       ; closes <p>, RAWTEXT, clears frameset-ok
              (when (in-scope "p" *button-scope*) (close-p))
              (reconstruct-afe) (setf frameset-ok nil) (raw-element tk nil))
             ((equal name "textarea")
              (raw-element tk t) (setf frameset-ok nil))
             ((member name *rcdata-els* :test #'equal) (raw-element tk t))
             ((member name *rawtext-els* :test #'equal) (raw-element tk nil))
             ((equal name "table")
              (when (and (not quirks) (in-scope "p" *button-scope*)) (close-p))
              (insert-element "table" (tok-attrs tk)) (setf frameset-ok nil) (switch :in-table))
             ((member name *headings* :test #'equal)
              (when (in-scope "p" *button-scope*) (close-p))
              (when (member (top-name) *headings* :test #'equal) (pop open))
              (insert-element name (tok-attrs tk)))
             ((equal name "li")
              (setf frameset-ok nil)
              ;; scan: close an enclosing <li>, stopping at special (except address/div/p)
              (loop for node in open
                    for nm = (dnode-name node)
                    do (cond ((equal nm "li")
                              (gen-implied "li")
                              (loop while (and open (not (equal (top-name) "li"))) do (pop open))
                              (when open (pop open)) (return))
                             ((and (member nm *special* :test #'equal)
                                   (not (member nm '("address" "div" "p") :test #'equal))) (return))))
              (when (in-scope "p" *button-scope*) (close-p))
              (insert-element "li" (tok-attrs tk)))
             ((member name '("dd" "dt") :test #'equal)
              (setf frameset-ok nil)
              (loop for node in open
                    for nm = (dnode-name node)
                    do (cond ((member nm '("dd" "dt") :test #'equal)
                              (gen-implied nm)
                              (loop while (and open (not (equal (top-name) nm))) do (pop open))
                              (when open (pop open)) (return))
                             ((and (member nm *special* :test #'equal)
                                   (not (member nm '("address" "div" "p") :test #'equal))) (return))))
              (when (in-scope "p" *button-scope*) (close-p))
              (insert-element name (tok-attrs tk)))
             ((equal name "a")
              (let ((existing (last-fmt "a")))
                (when existing (adoption-agency "a") (afe-remove existing)))
              (reconstruct-afe)
              (push-afe (insert-element "a" (tok-attrs tk))))
             ((equal name "nobr")
              (reconstruct-afe)
              (when (in-scope "nobr") (adoption-agency "nobr") (reconstruct-afe))
              (push-afe (insert-element "nobr" (tok-attrs tk))))
             ((member name *formatting* :test #'equal)
              (reconstruct-afe)
              (push-afe (insert-element name (tok-attrs tk))))
             ((member name '("applet" "marquee" "object") :test #'equal)
              (reconstruct-afe)
              (insert-element name (tok-attrs tk)) (push-marker))
             ((equal name "button")
              (when (in-scope "button") (pop-until "button"))
              (reconstruct-afe)
              (insert-element "button" (tok-attrs tk)))
             ((equal name "form")
              (unless form-ptr
                (when (in-scope "p" *button-scope*) (close-p))
                (setf form-ptr (insert-element "form" (tok-attrs tk)))))
             ((equal name "frameset")
              (when frameset-ok
                (let ((b (find "body" open :key #'dnode-name :test #'equal)))
                  (when (and b (dnode-parent b)) (dom-remove b)))
                (loop while (and open (not (equal (top-name) "html"))) do (pop open))
                (insert-element "frameset" (tok-attrs tk)) (switch :in-frameset)))
             ((equal name "select")
              (reconstruct-afe) (insert-element "select" (tok-attrs tk))
              (setf frameset-ok nil) (switch :in-select))
             ((member name '("optgroup" "option") :test #'equal)
              (when (equal (top-name) "option") (pop open))
              (reconstruct-afe) (insert-element name (tok-attrs tk)))
             ((equal name "hr")
              (when (in-scope "p" *button-scope*) (close-p))
              (insert-void "hr" (tok-attrs tk)) (setf frameset-ok nil))
             ((member name '("area" "br" "embed" "img" "keygen" "wbr") :test #'equal)
              (reconstruct-afe) (insert-void name (tok-attrs tk)) (setf frameset-ok nil))
             ((equal name "input")
              (reconstruct-afe) (insert-void "input" (tok-attrs tk))
              (let ((ty (cdr (assoc "type" (tok-attrs tk) :test #'string=))))
                (unless (and ty (string-equal ty "hidden")) (setf frameset-ok nil))))
             ((member name *void* :test #'equal) (insert-void name (tok-attrs tk)))
             ((member name '("pre" "listing") :test #'equal)
              (when (in-scope "p" *button-scope*) (close-p))
              (insert-element name (tok-attrs tk))
              (setf drop-nl t frameset-ok nil))         ; a leading newline is dropped
             ((member name *block-closes-p* :test #'equal)
              (when (in-scope "p" *button-scope*) (close-p))
              (insert-element name (tok-attrs tk)))
             (t (reconstruct-afe)
                ;; Foreign content (inside <svg>/<math>): a self-closing start tag
                ;; (e.g. <rect .../>) is inserted and immediately closed, per the
                ;; XML content model.  Gated on an svg/math ancestor so ordinary
                ;; HTML (<div/> etc.) is unaffected — the slash is ignored there.
                (let ((foreign (some (lambda (el) (member (dnode-name el) '("svg" "math") :test #'equal))
                                     open)))
                  (insert-element name (tok-attrs tk))
                  (when (and foreign (tok-self-closing tk)) (pop open))))))
         (body-end (name)
           (cond
             ((equal name "body") (switch :after-body))
             ((equal name "html") (switch :after-body) (reproc))
             ((equal name "br")                        ; </br> acts as <br> start tag
              (reconstruct-afe) (insert-void "br") (setf frameset-ok nil))
             ((equal name "form")
              (let ((node form-ptr))
                (setf form-ptr nil)
                (when (and node (member node open) (in-scope "form"))
                  (gen-implied)
                  (setf open (remove node open)))))
             ((equal name "p")
              (if (in-scope "p" *button-scope*) (pop-until "p")
                  (progn (insert-element "p") (pop open))))
             ((member name *block-end-tags* :test #'equal)
              (when (in-scope name)
                (gen-implied)
                (loop while (and open (not (equal (top-name) name))) do (pop open))
                (when open (pop open))))
             ((member name '("li" "dd" "dt") :test #'equal)
              (let ((bounds (if (equal name "li") '("ol" "ul" "html" "table" "td" "th" "caption" "template")
                                *scope-bounds*)))
                (when (in-scope name bounds)
                  (gen-implied name)
                  (loop while (and open (not (equal (top-name) name))) do (pop open))
                  (when open (pop open)))))
             ((member name *headings* :test #'equal)
              (when (loop for el in open thereis (member (dnode-name el) *headings* :test #'equal))
                (gen-implied)
                (loop while (and open (not (member (top-name) *headings* :test #'equal))) do (pop open))
                (when open (pop open))))
             ((member name '("applet" "marquee" "object") :test #'equal)
              (when (in-scope name) (gen-implied) (pop-until name) (clear-afe-to-marker)))
             ((member name *formatting* :test #'equal) (adoption-agency name))
             (t (body-end-generic name))))
         ;; ---- table cell helpers ----
         (close-cell ()
           (gen-implied)
           (loop while (and open (not (member (top-name) '("td" "th") :test #'equal))) do (pop open))
           (when open (pop open))
           (clear-afe-to-marker)
           (switch :in-row)))
      ;; ---- fragment parsing (WHATWG §13.4): when CONTEXT (a tag name) is
      ;; given, seed a synthetic <html> root, then set the insertion mode as if
      ;; the context element were the sole open element.  The root's children are
      ;; the fragment result.
      (when context
        (let ((root (make-element "html")))
          (dom-append doc root) (push-el root)
          (switch
           (cond ((member context '("table") :test #'equal) :in-table)
                 ((member context '("tbody" "thead" "tfoot") :test #'equal) :in-table-body)
                 ((equal context "tr") :in-row)
                 ((member context '("td" "th" "caption") :test #'equal) :in-body)
                 ((equal context "colgroup") :in-column-group)
                 ((equal context "select") :in-select)
                 ((member context '("head" "noscript") :test #'equal) :in-head)
                 (t :in-body)))
          (when (member context '("title" "textarea") :test #'equal)
            (setf mode :in-body))))
      (loop
        (when (>= i ntok) (return))
        (let* ((tk (aref toks i)) (ty (tok-type tk)))
          (setf reconsume nil)
          ;; Fragment parsing: at EOF, "stop parsing" — never let a mode's EOF
          ;; fallthrough pop the synthetic root or synthesize a <body>/<head>.
          (when (and context (eq ty :eof)) (return))
          (ecase mode
            (:initial
             (cond ((eq ty :doctype)
                    (dom-append doc (%dnode :kind :doctype :name (tok-name tk)
                                            :public (tok-public tk) :system (tok-system tk)))
                    ;; Quirks per HTML5 13.2.6.1: standards (non-quirks) for a clean
                    ;; <!DOCTYPE html> AND for known standards public ids such as
                    ;; Acid2's "-//W3C//DTD HTML 4.01//EN" (Strict, no system id).
                    (setf quirks (doctype-quirks-p (tok-name tk) (tok-public tk)
                                                   (tok-system tk) (tok-force-quirks tk)))
                    (switch :before-html))
                   ((eq ty :comment) (dom-append doc (make-comment (tok-data tk))))
                   ((ws-char-tok-p tk))
                   (t (switch :before-html) (reproc))))
            (:before-html
             (cond ((eq ty :comment) (dom-append doc (make-comment (tok-data tk))))
                   ((ws-char-tok-p tk))
                   ((and (eq ty :start-tag) (equal (tok-name tk) "html"))
                    (let ((el (make-element "html" (tok-attrs tk)))) (dom-append doc el) (push-el el))
                    (switch :before-head))
                   (t (let ((el (make-element "html"))) (dom-append doc el) (push-el el))
                      (switch :before-head) (reproc))))
            (:before-head
             (cond ((ws-char-tok-p tk))
                   ((eq ty :comment) (dom-append (current) (make-comment (tok-data tk))))
                   ((and (eq ty :start-tag) (equal (tok-name tk) "head"))
                    (setf head (insert-element "head" (tok-attrs tk))) (switch :in-head))
                   (t (setf head (insert-element "head")) (switch :in-head) (reproc))))
            (:in-head
             (cond ((ws-char-tok-p tk) (insert-text (tok-data tk)))
                   ((eq ty :comment) (dom-append (current) (make-comment (tok-data tk))))
                   ((and (eq ty :start-tag) (equal (tok-name tk) "html"))
                    (merge-attrs (find "html" open :key #'dnode-name :test #'equal) (tok-attrs tk)))
                   ((and (eq ty :start-tag) (member (tok-name tk) *head-void* :test #'equal))
                    (insert-void (tok-name tk) (tok-attrs tk)))
                   ((and (eq ty :start-tag) (equal (tok-name tk) "meta"))
                    (insert-void "meta" (tok-attrs tk)))
                   ((and (eq ty :start-tag) (equal (tok-name tk) "title")) (raw-element tk t))
                   ((and (eq ty :start-tag)
                         (member (tok-name tk) '("style" "script" "noframes" "noscript" "noembed") :test #'equal))
                    (raw-element tk nil))
                   ((and (eq ty :end-tag) (equal (tok-name tk) "head")) (pop open) (switch :after-head))
                   ;; body/html/br leave head; any other stray end tag is ignored
                   ((and (eq ty :end-tag) (member (tok-name tk) '("body" "html" "br") :test #'equal))
                    (pop open) (switch :after-head) (reproc))
                   ((eq ty :end-tag))                    ; ignore other end tags in head
                   (t (pop open) (switch :after-head) (reproc))))
            (:after-head
             (cond ((ws-char-tok-p tk) (insert-text (tok-data tk)))
                   ((eq ty :comment) (dom-append (current) (make-comment (tok-data tk))))
                   ((and (eq ty :start-tag) (equal (tok-name tk) "body"))
                    (insert-element "body" (tok-attrs tk)) (switch :in-body))
                   ((and (eq ty :start-tag) (equal (tok-name tk) "html")) (switch :in-body))
                   ((and (eq ty :start-tag) (equal (tok-name tk) "frameset"))
                    (insert-element "frameset" (tok-attrs tk)) (switch :in-frameset))
                   ;; head-content start tags: re-process in head, then remove it
                   ((and (eq ty :start-tag)
                         (member (tok-name tk) '("base" "basefont" "bgsound" "link" "meta"
                                                 "title" "style" "script" "noframes" "template") :test #'equal))
                    (push head open)
                    (cond ((member (tok-name tk) *rcdata-els* :test #'equal) (raw-element tk t))
                          ((member (tok-name tk) *rawtext-els* :test #'equal) (raw-element tk nil))
                          (t (insert-void (tok-name tk) (tok-attrs tk))))
                    (setf open (remove head open)))
                   (t (insert-element "body") (switch :in-body) (reproc))))
            (:in-body
             (cond
               ((eq ty :char)
                (let ((data (tok-data tk)))
                  ;; <pre>/<listing>/<textarea> drop a single leading newline; the
                  ;; following text is now one coalesced run, so strip its first char.
                  (when (and drop-nl (plusp (length data)) (char= (char data 0) #\Newline))
                    (setf data (subseq data 1)))
                  (setf drop-nl nil)
                  (when (and (plusp (length data)) (notevery (lambda (c) (member c *ws*)) data))
                    (setf frameset-ok nil))
                  (when (plusp (length data)) (reconstruct-afe) (insert-text data))))
               ((eq ty :comment) (dom-append (current) (make-comment (tok-data tk))))
               ((eq ty :doctype))
               ((eq ty :start-tag) (setf drop-nl nil) (body-start tk (tok-name tk)))
               ((eq ty :end-tag) (setf drop-nl nil) (body-end (tok-name tk)))
               ((eq ty :eof) (return))))
            ;; ---- TABLE ----
            (:in-table
             (cond
               ((and (eq ty :char))                      ; collect into in-table-text
                (setf pending '() orig-mode :in-table) (switch :in-table-text) (reproc))
               ((eq ty :comment) (dom-append (current) (make-comment (tok-data tk))))
               ((eq ty :start-tag)
                (let ((name (tok-name tk)))
                  (cond
                    ((member name '("tbody" "tfoot" "thead") :test #'equal)
                     (clear-to '("table" "html")) (insert-element name (tok-attrs tk)) (switch :in-table-body))
                    ((member name '("td" "th" "tr") :test #'equal)
                     (clear-to '("table" "html")) (insert-element "tbody") (switch :in-table-body) (reproc))
                    ((equal name "caption")
                     (clear-to '("table" "html")) (insert-element "caption" (tok-attrs tk))
                     (push-marker) (switch :in-caption))
                    ((equal name "colgroup")
                     (clear-to '("table" "html")) (insert-element "colgroup" (tok-attrs tk)) (switch :in-column-group))
                    ((equal name "col")
                     (clear-to '("table" "html")) (insert-element "colgroup") (switch :in-column-group) (reproc))
                    ((equal name "table")                ; nested: act as </table>, reprocess
                     (when (in-table-scope "table")
                       (loop while (and open (not (equal (top-name) "table"))) do (pop open))
                       (when open (pop open)) (reset-mode) (reproc)))
                    ((member name '("style" "script") :test #'equal) (raw-element tk nil))
                    ((and (equal name "input")            ; type=hidden stays in the table
                          (let ((ty (cdr (assoc "type" (tok-attrs tk) :test #'string=))))
                            (and ty (string-equal ty "hidden"))))
                     (insert-void "input" (tok-attrs tk)))
                    (t (setf fostering t) (body-start tk name) (setf fostering nil)))))
               ((eq ty :end-tag)
                (let ((name (tok-name tk)))
                  (cond
                    ((equal name "table")
                     (when (in-table-scope "table")
                       (loop while (and open (not (equal (top-name) "table"))) do (pop open))
                       (when open (pop open)) (reset-mode)))
                    ((member name '("body" "caption" "col" "colgroup" "html" "tbody"
                                    "td" "tfoot" "th" "thead" "tr") :test #'equal))   ; ignore
                    (t (setf fostering t) (body-end name) (setf fostering nil)))))
               ((eq ty :eof) (return))))
            (:in-table-text
             (cond
               ((eq ty :char) (push (tok-data tk) pending))
               (t ;; flush: foster-parent if any non-whitespace, else plain-insert
                (let ((text (apply #'concatenate 'string (nreverse pending))))
                  (if (some (lambda (c) (not (member c *ws*))) text)
                      (progn (setf fostering t) (reconstruct-afe) (insert-text text) (setf fostering nil))
                      (insert-text text)))
                (setf pending nil) (switch (or orig-mode :in-table)) (reproc))))
            (:in-table-body
             (cond
               ((eq ty :start-tag)
                (let ((name (tok-name tk)))
                  (cond
                    ((equal name "tr")
                     (clear-to '("tbody" "tfoot" "thead" "html")) (insert-element "tr" (tok-attrs tk)) (switch :in-row))
                    ((member name '("td" "th") :test #'equal)
                     (clear-to '("tbody" "tfoot" "thead" "html")) (insert-element "tr") (switch :in-row) (reproc))
                    ((member name '("caption" "col" "colgroup" "tbody" "tfoot" "thead") :test #'equal)
                     (when (or (in-table-scope "tbody") (in-table-scope "thead") (in-table-scope "tfoot"))
                       (clear-to '("tbody" "tfoot" "thead" "html")) (pop open) (switch :in-table) (reproc)))
                    (t (switch :in-table) (reproc)))))
               ((eq ty :end-tag)
                (let ((name (tok-name tk)))
                  (cond
                    ((member name '("tbody" "tfoot" "thead") :test #'equal)
                     (when (in-table-scope name)
                       (clear-to '("tbody" "tfoot" "thead" "html")) (pop open) (switch :in-table)))
                    ((equal name "table")
                     (when (or (in-table-scope "tbody") (in-table-scope "thead") (in-table-scope "tfoot"))
                       (clear-to '("tbody" "tfoot" "thead" "html")) (pop open) (switch :in-table) (reproc)))
                    ((member name '("body" "caption" "col" "colgroup" "html" "td" "th" "tr") :test #'equal))
                    (t (switch :in-table) (reproc)))))
               ((eq ty :char) (setf pending '() orig-mode :in-table-body) (switch :in-table-text) (reproc))
               ((eq ty :comment) (dom-append (current) (make-comment (tok-data tk))))
               ((eq ty :eof) (return))))
            (:in-row
             (cond
               ((eq ty :start-tag)
                (let ((name (tok-name tk)))
                  (cond
                    ((member name '("td" "th") :test #'equal)
                     (clear-to '("tr" "html")) (insert-element name (tok-attrs tk))
                     (push-marker) (switch :in-cell))
                    ((member name '("caption" "col" "colgroup" "tbody" "tfoot" "thead" "tr") :test #'equal)
                     (when (in-table-scope "tr")
                       (clear-to '("tr" "html")) (pop open) (switch :in-table-body) (reproc)))
                    (t (setf fostering t) (body-start tk name) (setf fostering nil)))))
               ((eq ty :end-tag)
                (let ((name (tok-name tk)))
                  (cond
                    ((equal name "tr")
                     (when (in-table-scope "tr")
                       (clear-to '("tr" "html")) (pop open) (switch :in-table-body)))
                    ((member name '("tbody" "tfoot" "thead") :test #'equal)
                     (when (in-table-scope name)
                       (when (in-table-scope "tr") (clear-to '("tr" "html")) (pop open))
                       (switch :in-table-body) (reproc)))
                    ((equal name "table")
                     (when (in-table-scope "tr")
                       (clear-to '("tr" "html")) (pop open) (switch :in-table-body) (reproc)))
                    ((member name '("body" "caption" "col" "colgroup" "html" "td" "th") :test #'equal))
                    (t (switch :in-table) (reproc)))))
               ((eq ty :char) (setf pending '() orig-mode :in-row) (switch :in-table-text) (reproc))
               ((eq ty :comment) (dom-append (current) (make-comment (tok-data tk))))
               ((eq ty :eof) (return))))
            (:in-cell
             (cond
               ((eq ty :end-tag)
                (let ((name (tok-name tk)))
                  (cond
                    ((member name '("td" "th") :test #'equal)
                     (when (in-table-scope name)
                       (gen-implied)
                       (loop while (and open (not (equal (top-name) name))) do (pop open))
                       (when open (pop open)) (clear-afe-to-marker) (switch :in-row)))
                    ((member name '("table" "tbody" "tfoot" "thead" "tr") :test #'equal)
                     (when (in-table-scope name) (close-cell) (reproc)))
                    ((member name '("body" "caption" "col" "colgroup" "html") :test #'equal))
                    (t (body-end name)))))
               ((eq ty :start-tag)
                (let ((name (tok-name tk)))
                  (cond
                    ((member name '("caption" "col" "colgroup" "tbody" "td" "tfoot" "th" "thead" "tr") :test #'equal)
                     (when (or (in-table-scope "td") (in-table-scope "th")) (close-cell) (reproc)))
                    (t (body-start tk name)))))
               ((eq ty :char) (insert-text (tok-data tk)))
               ((eq ty :comment) (dom-append (current) (make-comment (tok-data tk))))
               ((eq ty :eof) (return))))
            ;; minimal caption / colgroup: delegate content, close on their end tags
            (:in-caption
             (cond
               ((and (eq ty :end-tag) (equal (tok-name tk) "caption"))
                (when (in-table-scope "caption")
                  (gen-implied)
                  (loop while (and open (not (equal (top-name) "caption"))) do (pop open))
                  (when open (pop open)) (clear-afe-to-marker) (switch :in-table)))
               ((and (eq ty :start-tag)
                     (member (tok-name tk) '("caption" "col" "colgroup" "tbody" "td" "tfoot" "th" "thead" "tr") :test #'equal))
                (when (in-table-scope "caption")
                  (gen-implied) (loop while (and open (not (equal (top-name) "caption"))) do (pop open))
                  (when open (pop open)) (clear-afe-to-marker) (switch :in-table) (reproc)))
               ((eq ty :eof) (return))
               (t (case ty
                    (:char (insert-text (tok-data tk)))
                    (:comment (dom-append (current) (make-comment (tok-data tk))))
                    (:start-tag (body-start tk (tok-name tk)))
                    (:end-tag (body-end (tok-name tk)))))))
            (:in-column-group
             (cond
               ((and (eq ty :start-tag) (equal (tok-name tk) "col")) (insert-void "col" (tok-attrs tk)))
               ((and (eq ty :end-tag) (equal (tok-name tk) "colgroup"))
                (when (equal (top-name) "colgroup") (pop open) (switch :in-table)))
               ((ws-char-tok-p tk) (insert-text (tok-data tk)))
               ((eq ty :comment) (dom-append (current) (make-comment (tok-data tk))))
               ((eq ty :eof) (return))
               (t (when (equal (top-name) "colgroup") (pop open)) (switch :in-table) (reproc))))
            (:after-body
             (cond ((eq ty :comment) (dom-append (car (last open)) (make-comment (tok-data tk))))
                   ((and (eq ty :end-tag) (equal (tok-name tk) "html")) (switch :after-after-body))
                   ((eq ty :eof) (return))
                   (t (switch :in-body) (reproc))))
            (:after-after-body
             (cond ((eq ty :comment) (dom-append doc (make-comment (tok-data tk))))
                   ((eq ty :eof) (return))
                   (t (switch :in-body) (reproc))))
            (:in-frameset
             (cond ((ws-char-tok-p tk) (insert-text (tok-data tk)))
                   ((eq ty :comment) (dom-append (current) (make-comment (tok-data tk))))
                   ((and (eq ty :start-tag) (equal (tok-name tk) "frameset"))
                    (insert-element "frameset" (tok-attrs tk)))
                   ((and (eq ty :end-tag) (equal (tok-name tk) "frameset"))
                    (unless (equal (top-name) "html") (pop open))
                    (unless (equal (top-name) "frameset") (switch :after-frameset)))
                   ((and (eq ty :start-tag) (equal (tok-name tk) "frame"))
                    (insert-void "frame" (tok-attrs tk)))
                   ((and (eq ty :start-tag) (equal (tok-name tk) "noframes")) (raw-element tk nil))
                   ((eq ty :eof) (return))
                   (t)))                                ; ignore everything else
            (:after-frameset
             (cond ((ws-char-tok-p tk) (insert-text (tok-data tk)))
                   ((eq ty :comment) (dom-append (current) (make-comment (tok-data tk))))
                   ((and (eq ty :start-tag) (equal (tok-name tk) "noframes")) (raw-element tk nil))
                   ((and (eq ty :end-tag) (equal (tok-name tk) "html")) (switch :after-after-frameset))
                   ((eq ty :eof) (return))
                   (t)))
            (:after-after-frameset
             (cond ((eq ty :comment) (dom-append doc (make-comment (tok-data tk))))
                   ((ws-char-tok-p tk) (insert-text (tok-data tk)))
                   ((eq ty :eof) (return))
                   (t)))
            (:in-select
             (cond
               ((eq ty :char) (insert-text (tok-data tk)))
               ((eq ty :comment) (dom-append (current) (make-comment (tok-data tk))))
               ((eq ty :start-tag)
                (let ((name (tok-name tk)))
                  (cond
                    ;; in-select-in-table: table tags close the select and reprocess
                    ((and (member name '("caption" "table" "tbody" "tfoot" "thead" "tr" "td" "th") :test #'equal)
                          (in-table-scope "table"))
                     (loop while (and open (not (equal (top-name) "select"))) do (pop open))
                     (when open (pop open)) (reset-mode) (reproc))
                    ((equal name "option")
                     (when (equal (top-name) "option") (pop open))
                     (insert-element "option" (tok-attrs tk)))
                    ((equal name "optgroup")
                     (when (equal (top-name) "option") (pop open))
                     (when (equal (top-name) "optgroup") (pop open))
                     (insert-element "optgroup" (tok-attrs tk)))
                    ((equal name "select")               ; nested select acts as </select>
                     (when (in-select-scope "select")
                       (loop while (and open (not (equal (top-name) "select"))) do (pop open))
                       (when open (pop open)) (reset-mode)))
                    ((member name '("input" "keygen" "textarea") :test #'equal)
                     (when (in-select-scope "select")
                       (loop while (and open (not (equal (top-name) "select"))) do (pop open))
                       (when open (pop open)) (reset-mode) (reproc)))
                    ((member name '("script" "template") :test #'equal) (raw-element tk nil))
                    ;; "In select" used to ignore every other start tag.  Containers
                    ;; now have to survive: WPT seeds
                    ;;   select.innerHTML = "<div><optgroup><div><option selected>1"
                    ;; and asserts on the resulting shape, which only holds if the
                    ;; <div>s are in the tree.  Formatting elements still get
                    ;; dropped — html5lib's tests1.dat expects <select><b> to lose
                    ;; the <b>, and inserting it there regresses two of its cases.
                    ;; The permitted set in the current spec is NOT verified here:
                    ;; this rule is derived from the two corpora we can actually
                    ;; run, and our html5lib vectors predate the spec change.
                    ((member name *formatting* :test #'equal))
                    (t (insert-element name (tok-attrs tk))))))
               ((eq ty :end-tag)
                (let ((name (tok-name tk)))
                  (cond
                    ((and (member name '("caption" "table" "tbody" "tfoot" "thead" "tr" "td" "th") :test #'equal)
                          (in-table-scope "table") (in-table-scope name))
                     (loop while (and open (not (equal (top-name) "select"))) do (pop open))
                     (when open (pop open)) (reset-mode) (reproc))
                    ((equal name "optgroup")
                     (when (and (equal (top-name) "option")
                                (>= (length open) 2) (equal (dnode-name (second open)) "optgroup"))
                       (pop open))
                     (when (equal (top-name) "optgroup") (pop open)))
                    ((equal name "option")
                     (when (equal (top-name) "option") (pop open)))
                    ((equal name "select")
                     (when (in-select-scope "select")
                       (loop while (and open (not (equal (top-name) "select"))) do (pop open))
                       (when open (pop open)) (reset-mode)))
                    (t))))
               ((eq ty :eof) (return)))))
          (unless reconsume (incf i)))))
    ;; Record the document's mode so Document.compatMode can report quirks
    ;; (HTML §"quirks mode"); LIMITED-QUIRKS folds into no-quirks for compatMode.
    (setf (dnode-mode doc) (if quirks :quirks :no-quirks))
    doc)))

(defun parse-fragment (input context-name)
  "Parse INPUT as an HTML fragment in the CONTEXT-NAME element's context
(WHATWG §13.4) and return a fresh :fragment dnode holding the parsed nodes."
  (let* ((doc (parse-html input :context (and context-name
                                              (string-downcase context-name))))
         (root (and (plusp (length (dnode-children doc)))
                    (aref (dnode-children doc) 0)))
         (frag (make-fragment)))
    (when root
      (loop for c across (copy-seq (dnode-children root))
            do (dom-remove c) (dom-append frag c)))
    frag))
