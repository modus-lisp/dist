;;;; src/render/packages.lisp — rendering package.
(defpackage #:weft.render
  (:use #:cl)
  (:local-nicknames (#:h #:weft.html) (#:css #:weft.css)
                    (#:g #:gesso) (#:st #:stencil) (#:sc #:scribe))
  ;; image/SVG codecs live in the standalone `pigment` library; weft imports the
  ;; IMG struct + accessors and the decode entry points so layout/vector/image
  ;; keep calling them unqualified.
  (:import-from #:pigment
   #:img #:make-img #:img-w #:img-h #:img-rgba #:img-sw #:img-sh #:img-sr
   #:decode-image #:decode-image-bytes #:rgba-canvas->img #:base64-decode)
  (:export #:canvas #:make-canvas #:canvas-width #:canvas-height
           #:fill-rect #:draw-text #:write-png #:canvas->png
           #:layout-tree #:layout-document #:render-to-png #:render-to-canvas #:canvas-ink #:canvas-pixels
           #:element-canvas #:*element-canvas*
           ;; network image loading + cache (bind *IMAGE-LOADER* to a fetcher)
           #:*image-loader* #:*image-store* #:clear-image-cache #:*image-fetch-deadline*
           #:fetch-image #:decode-image-bytes
           ;; live progress hook (:cascade :layout :painting) — NIL disables it
           #:*progress*
           ;; font registration (@font-face web fonts / the Ahem test font)
           #:register-font #:load-font-faces #:*font-loader* #:*font-load-budget*
           ;; interactive-shell support (hit-testing, box tree, viewport scroll)
           #:render-document #:box-at #:node-at #:point-in-box-p #:img-source-url
           #:img-loading-lazy-p #:*lazy-image-lookahead* #:inview-lazy-image-urls
           #:*fetch-inview-lazy* #:*lazy-scroll-y* #:*lazy-image-overscan*
           #:lbox #:lbox-p #:lbox-x #:lbox-y #:lbox-w #:lbox-h
           #:lbox-node #:lbox-kind #:lbox-children #:lbox-style
           ;; text fragments on a line box: an inline element has no box of its
           ;; own, so its geometry IS its fragments (see INTERACT's frag hit-test)
           #:frag #:frag-p #:frag-x #:frag-w #:frag-node #:frag-dx #:frag-dy
           ;; live form-control state: the shell binds this so a control's
           ;; CURRENT value (script-set or typed) is painted, not its default
           #:*form-value-fn* #:*form-caret-fn* #:form-control-p
           #:form-control-focusable-p #:text-editable-p #:caret-index-at
           ;; the open <select> popup: no layout box (it overlaps the page and
           ;; vanishes on pick), so the shell paints and hit-tests it itself
           #:select-menu-geometry #:paint-select-menu #:select-menu-row-at
           ;; document text selection: hit-test a point to a character, hold the
           ;; range, paint it under the glyphs, extract the string (selection.lisp)
           #:text-selection #:text-selection-p #:make-text-selection
           #:text-selection-anchor-node #:text-selection-anchor-offset
           #:text-selection-focus-node #:text-selection-focus-offset
           #:selection-collapsed-p #:selection-extend #:text-position-at
           #:selection-text #:selection-highlight-map #:select-all-position
           #:*selection-highlight* #:*selection-color*
           #:canvas-background))
