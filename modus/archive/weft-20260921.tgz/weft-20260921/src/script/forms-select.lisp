;;;; forms-select.lisp — HTMLElement IDL surface for <select> (WPT swarm unit).
;;;; Self-registering into the element-proto hook (see core.lisp).  The installer
;;;; runs on the shared element prototype; each accessor must gate on the node's
;;;; tag ((string= (h:dnode-name (n this)) "select")) so it only acts on <select>.
(in-package #:weft.script)

;;; Shared with forms-option.lisp and forms-constraints.lisp: the "displays one
;;; row" condition that gates the ask-for-a-reset auto-selection of the first
;;; option — and through it both `option.selected' and the placeholder label
;;; option.  Three files were deciding this independently and only this one
;;; consulted `size'.
(defun select-one-row-p (node)
  (and (not (dom:has-attribute node "multiple"))
       (let ((s (get-attr node "size")))
         (or (null s) (string= s "")
             (eql 1 (parse-integer s :junk-allowed t))))))

;;; These five are top-level rather than closed over inside INSTALL-FORMS-SELECT
;;; because the shell picks options too (a real dropdown click), and the IDL and
;;; the pointer must agree about which option is selected — one store, one answer.
;;; Note SELECT-AUTO-SELECT-P is NOT SELECT-ONE-ROW-P above: they disagree on a
;;; non-numeric `size' (that one says no, this one says yes), and the corpus
;;; tests both, so they stay two functions.

(defun select-options-list (node)
  "Walk all option descendants of <select> in tree order. Block at
   <option>, <hr>, <select> elements.  For <optgroup>, block only
   if we are already inside an optgroup (prevents nested optgroups)."
  (let ((result nil))
    (labels ((walk (n inside-optgroup)
               (loop for c across (h:dnode-children n)
                     do (let ((tag (h:dnode-name c)))
                          (cond ((string= tag "option")
                                 (push c result))
                                ((string= tag "optgroup")
                                 (unless inside-optgroup
                                   (walk c t)))
                                ((member tag '("hr" "select") :test #'string=)
                                 nil) ; stop here
                                (t (walk c inside-optgroup)))))))
      (walk node nil))
    (nreverse result)))

(defun select-auto-select-p (node)
  "Auto-select the first option? Only when display size is 1 (or absent)
   and multiple is absent."
  (and (not (dom:has-attribute node "multiple"))
       (let ((size-attr (get-attr node "size")))
         (or (null size-attr)
             (string= size-attr "")
             (= (or (parse-integer size-attr :junk-allowed t) 1) 1)))))

(defun select-first-non-disabled (opts)
  (position-if (lambda (o) (not (dom:has-attribute o "disabled"))) opts))

(defun select-selected-index (ctx node)
  "NODE's selectedIndex: the first `selected' option, else the auto-selected
   first enabled one, else -1."
  (let* ((opts (select-options-list node))
         (sel (position-if (lambda (o) (dom:has-attribute o "selected")) opts)))
    (if sel sel
        (if (and (not (gethash node (context-deselected ctx)))
                 (select-auto-select-p node))
            (or (select-first-non-disabled opts) -1)
            -1))))

(defun select-set-selected (ctx node idx)
  "Make option IDX of NODE the selected one.  Returns T when IDX was in range."
  (remhash node (context-deselected ctx))
  (let ((opts (select-options-list node)))
    (when (and (>= idx 0) (< idx (length opts)))
      (let ((opt (nth idx opts)))
        (dolist (o opts)
          (unless (eq o opt) (remove-attr o "selected")))
        (set-attr opt "selected" "")
        (setf (context-dirty ctx) t))
      t)))

(defun install-forms-select (ctx ep)
  (declare (ignorable ctx ep))
  (macrolet ((n (this) `(require-node ctx ,this))
             (tag-gate (this) `(string= (h:dnode-name (n ,this)) "select")))
    (let ((selected-options-cache (make-hash-table :test 'eq))
          (explicitly-deselected (context-deselected ctx)))
      (labels
          ((select-child-text (node)
             (let ((out ""))
               (loop for c across (h:dnode-children node)
                     when (eq (h:dnode-kind c) :text)
                     do (setq out (concatenate 'string out (h:dnode-data c))))
               out))
           (select-option-value (node)
             (or (get-attr node "value") (select-child-text node)))
           (select-first-selected (node)
             (let* ((opts (select-options-list node))
                    (sel (position-if (lambda (o) (dom:has-attribute o "selected")) opts)))
               (if sel (nth sel opts)
                   (and (not (gethash node explicitly-deselected))
                        (select-auto-select-p node)
                        (let ((fnd (select-first-non-disabled opts)))
                          (when fnd (nth fnd opts)))))))
           (select-set-selected-safe (node idx)
             (if (and (>= idx 0) (< idx (length (select-options-list node))))
                 (select-set-selected ctx node idx)
                 (progn
                   (setf (gethash node explicitly-deselected) t)
                   (dolist (o (select-options-list node)) (remove-attr o "selected"))
                   (setf (context-dirty ctx) t))))
           (select-add-option (node element before)
             ;; Check for HierarchyRequestError BEFORE detaching:
             ;; element must not be an ancestor of node
             (when (or (eq element node)
                       (loop for p = (h:dnode-parent node) then (h:dnode-parent p)
                             while p thereis (eq p element)))
               (throw-dom ctx "HierarchyRequestError" 3
                          "The new element is an ancestor of the insertion point"))
             ;; If before is the same as element, do nothing (check before detach)
             (when (and before (not (numberp before)) (eq before element))
               (return-from select-add-option))
             (dom-detach element)
             (if (null before)
                 (h:dom-append node element)
                 (if (numberp before)
                     (let* ((opts (select-options-list node))
                            (ref-node (and (>= before 0) (< before (length opts))
                                           (nth before opts))))
                       (if ref-node
                           (h:dom-insert-before (h:dnode-parent ref-node) element ref-node)
                           (h:dom-append node element)))
                     ;; before is a weft node — insert before it in the DOM
                     (h:dom-insert-before (h:dnode-parent before) element before)))
             (setf (context-dirty ctx) t))
           (select-remove-option (node idx)
             (let ((opts (select-options-list node)))
               (when (and (>= idx 0) (< idx (length opts)))
                 (h:dom-remove (nth idx opts))
                 (setf (context-dirty ctx) t))))
           (select-trim-options (node new-len)
             (let* ((opts (select-options-list node))
                    (cur (length opts)))
               (when (< new-len cur)
                 (loop for i from (1- cur) downto new-len
                       do (h:dom-remove (nth i opts)))
                 (setf (context-dirty ctx) t))))
           (select-extend-options (node new-len)
             (let ((cur (length (select-options-list node))))
               (when (> new-len cur)
                 (loop repeat (- new-len cur)
                       do (let ((new-opt (h:make-element "option")))
                            (h:dom-append node new-opt)))
                 (setf (context-dirty ctx) t))))
           (select-set-options-length (node new-val)
             (let* ((new-len (max 0 (floor (js:to-number new-val))))
                    (cur (length (select-options-list node))))
               (cond ((< new-len cur) (select-trim-options node new-len))
                     ((> new-len cur) (select-extend-options node new-len)))))
           (select-options-index-set (node idx val)
             (let ((opts (select-options-list node)))
               (if (< idx (length opts))
                   (if (nullish val)
                       (progn (h:dom-remove (nth idx opts))
                              (setf (context-dirty ctx) t))
                       (let ((el (require-node ctx val)))
                         (unless (eq el (nth idx opts))
                           (dom-detach el)
                           ;; Insert the new element before the old one, then remove old
                           (h:dom-insert-before (h:dnode-parent (nth idx opts)) el (nth idx opts))
                           (h:dom-remove (nth idx opts))
                           (setf (context-dirty ctx) t))))
                   ;; Appending: idx >= length, append to end if val is not null
                   (unless (nullish val)
                     (let ((el (require-node ctx val)))
                       (dom-detach el)
                       (h:dom-append node el)
                       (setf (context-dirty ctx) t))))))
           (select-options-named-item (node name)
             (when (string= name "") (return-from select-options-named-item js:*null*))
             (let* ((opts (select-options-list node))
                    ;; First try by id, then by name
                    (found (or (find name opts :test #'string=
                                     :key (lambda (o) (or (get-attr o "id") "")))
                               (find name opts :test #'string=
                                     :key (lambda (o) (or (get-attr o "name") ""))))))
               (if found (wrap ctx found) js:*null*)))
           (select-make-options-collection (node)
             (let* ((realm (context-realm ctx))
                    (htmlcol-proto (proto ctx :htmlcollection))
                    (obj (js:make-host-object realm
                          :proto htmlcol-proto
                          :get (lambda (o key rcv) (declare (ignore rcv))
                            (let ((key (js:to-property-key key)))
                              (cond
                                ((and (stringp key) (string= key "length"))
                                 (num (length (select-options-list node))))
                                ((and (stringp key) (string= key "selectedIndex"))
                                 (num (select-selected-index ctx node)))
                                ((and (stringp key) (string= key "add"))
                                 (js:native-function realm "add"
                                   (lambda (this a) (declare (ignore this))
                                     (let* ((el (require-node ctx (arg a 0)))
                                            (before (arg a 1))
                                            (b (if (or (nullish before) (js:js-undefined-p before))
                                                   nil
                                                   (let ((n (ignore-errors (floor (js:to-number before)))))
                                                     (if (and n (numberp n)) n (require-node ctx before))))))
                                       (select-add-option node el b)
                                       js:*undefined*))
                                   2))
                                ((and (stringp key) (string= key "remove"))
                                 (js:native-function realm "remove"
                                   (lambda (this a) (declare (ignore this))
                                     (let* ((idx (arg a 0))
                                            (n (if (js:js-undefined-p idx) -1
                                                   (floor (js:to-number idx)))))
                                       (select-remove-option node n))
                                     js:*undefined*)
                                   1))
                                ((and (stringp key) (string= key "item"))
                                 (js:native-function realm "item"
                                   (lambda (this a) (declare (ignore this))
                                     (let ((i (int-arg a 0)) (l (select-options-list node)))
                                       (if (< -1 i (length l)) (wrap ctx (nth i l)) js:*null*)))
                                   1))
                                ((and (stringp key) (string= key "namedItem"))
                                 (js:native-function realm "namedItem"
                                   (lambda (this a) (declare (ignore this))
                                     (select-options-named-item node (jstr (arg a 0))))
                                   1))
                                ((index-string-p key)
                                 (let ((i (parse-integer key)) (l (select-options-list node)))
                                   (if (< i (length l)) (wrap ctx (nth i l)) js:*undefined*)))
                                ((and (stringp key) (plusp (length key))
                                      (let ((found (select-options-named-item node key)))
                                        (and (not (eq found js:*null*)) found)))
                                 (select-options-named-item node key))
                                (t (js:js-get (js:js-object-proto o) key o)))))
                          :has (lambda (o key)
                            (let ((key (js:to-property-key key)))
                              (or (and (stringp key)
                                       (member key '("length" "selectedIndex" "add" "remove"
                                                     "item" "namedItem") :test #'string=))
                                  (and (index-string-p key)
                                       (< (parse-integer key) (length (select-options-list node))))
                                  (and (stringp key) (plusp (length key))
                                       (let ((found (select-options-named-item node key)))
                                         (not (eq found js:*null*))))
                                  (js:js-has (js:js-object-proto o) key))))
                          :set (lambda (o key val rcv) (declare (ignore rcv))
                            (let ((key (js:to-property-key key)))
                              (cond
                                ((and (stringp key) (string= key "length"))
                                 (select-set-options-length node val))
                                ((and (stringp key) (string= key "selectedIndex"))
                                 (select-set-selected-safe node (floor (js:to-number val))))
                                ((index-string-p key)
                                 (select-options-index-set node (parse-integer key) val))
                                (t (js:js-set (js:js-object-proto o) key val o))))
                            t)
                          :own-keys (lambda (o) (declare (ignore o))
                            (append (loop for i from 0 below (length (select-options-list node))
                                          collect (princ-to-string i))
                                    '("length" "selectedIndex" "add" "remove" "item" "namedItem"))))))
               (setf (getf (js::js-object-internal obj) :get-own-property)
                     (lambda (o key) (declare (ignore o))
                       (let ((l (select-options-list node)))
                         (cond
                           ((and (index-string-p key) (< (parse-integer key) (length l)))
                            (js::make-prop :value (wrap ctx (nth (parse-integer key) l))
                                           :enumerable t :configurable t :writable nil))
                           ((and (stringp key) (string= key "length"))
                            (js::make-prop :value (num (length l))
                                           :enumerable t :configurable t :writable t))
                           ((and (stringp key) (string= key "selectedIndex"))
                            (js::make-prop :value (num (select-selected-index ctx node))
                                           :enumerable t :configurable t :writable t))
                           (t nil)))))
               obj)))
        ;; value getter/setter
        (defgetset-for ctx ep "select" "value" (this)
          (let ((node (n this)))
            (if (tag-gate this)
                (let ((sel (select-first-selected node)))
                  (if sel (select-option-value sel) ""))
                js:*undefined*))
          (v) (let ((node (n this)))
                (when (tag-gate this)
                  (let* ((target (jstr v))
                         (opts (select-options-list node))
                         (found (find target opts :test #'string=
                                      :key (lambda (o) (select-option-value o)))))
                    (if found
                        (select-set-selected ctx node (position found opts))
                        (progn
                          (dolist (o opts) (remove-attr o "selected"))
                          (setf (context-dirty ctx) t)))
                    ;; For non-multiple selects, if multiple options somehow got selected,
                    ;; keep only the last one in tree order
                    (unless (dom:has-attribute node "multiple")
                      (let* ((opts (select-options-list node))
                             (sel-idx (position-if
                                       (lambda (o) (dom:has-attribute o "selected"))
                                       opts :from-end t)))
                        (when sel-idx
                          (let ((last-sel (nth sel-idx opts)))
                            (dolist (o opts)
                              (unless (eq o last-sel) (remove-attr o "selected"))))))))
                  (setf (context-dirty ctx) t))))
        ;; selectedIndex getter/setter
        (defgetset-for ctx ep "select" "selectedIndex" (this)
          (let ((node (n this)))
            (if (tag-gate this) (num (select-selected-index ctx node)) js:*undefined*))
          (v) (let ((node (n this)))
                (when (tag-gate this)
                  (select-set-selected-safe node (floor (js:to-number v))))))
        ;; length getter/setter
        (defgetset-for ctx ep "select" "length" (this)
          (let ((node (n this)))
            (if (tag-gate this) (num (length (select-options-list node))) js:*undefined*))
          (v) (let ((node (n this)))
                (when (tag-gate this)
                  (select-set-options-length node v))))
        ;; options getter
        (defget-for ctx ep "select" "options" (this)
          (let ((node (n this)))
            (if (tag-gate this) (select-make-options-collection node) js:*undefined*)))
        ;; selectedOptions getter — [SameObject] cached, returns HTMLCollection
        (defget-for ctx ep "select" "selectedOptions" (this)
          (let ((node (n this)))
            (if (tag-gate this)
                (let ((obj (gethash node selected-options-cache)))
                  (or obj
                      (setf (gethash node selected-options-cache)
                            (make-collection ctx
                              (lambda ()
                                (let* ((opts (select-options-list node))
                                       (selected (remove-if-not
                                                  (lambda (o) (dom:has-attribute o "selected"))
                                                  opts)))
                                  ;; If explicitly deselected, return empty
                                  (if (gethash node explicitly-deselected)
                                      nil
                                      ;; For non-multiple selects, if multiple are selected,
                                      ;; only the last one in tree order counts.
                                      ;; If none selected but auto-selectable, include first.
                                      (if (or (dom:has-attribute node "multiple")
                                              selected)
                                          (if (dom:has-attribute node "multiple")
                                              selected
                                              (list (car (last selected))))
                                          (if (and (select-auto-select-p node)
                                                   (not (gethash node explicitly-deselected)))
                                              (let ((first (car opts)))
                                                (if first (list first) nil))
                                              nil)))))
                              nil :htmlcollection))))
                js:*undefined*)))
        ;; type getter — "select-one" or "select-multiple"
        (defget-for ctx ep "select" "type" (this)
          (let ((node (n this)))
            (if (tag-gate this)
                (if (dom:has-attribute node "multiple")
                    "select-multiple"
                    "select-one")
                js:*undefined*)))
        ;; multiple getter/setter — reflected boolean attribute
        ;; size — reflected as an unsigned long, default 0.  It was not
        ;; reflected at all, so `select.size = 2' left the content attribute
        ;; absent and the select still counted as showing one row: its first
        ;; option auto-selected and select-validity.html's size-2 group failed
        ;; on its first assertion.
        (defgetset-for ctx ep "select" "size" (this)
          (let ((node (n this)))
            (if (tag-gate this)
                (num (let ((s (get-attr node "size")))
                       (or (and s (parse-integer s :junk-allowed t)) 0)))
                js:*undefined*))
          (v) (let ((node (n this)))
                (when (tag-gate this)
                  (set-attr node "size" (format nil "~d" (max 0 (js-int v))))
                  (setf (context-dirty ctx) t))))
        (defgetset-for ctx ep "select" "multiple" (this)
          (let ((node (n this)))
            (if (tag-gate this)
                (jbool (dom:has-attribute node "multiple"))
                js:*undefined*))
          (v) (let ((node (n this)))
                (when (tag-gate this)
                  (if (js:js-truthy v)
                      (set-attr node "multiple" "")
                      (remove-attr node "multiple"))
                  ;; When removing multiple, reduce selected options to 1 (the last)
                  (unless (js:js-truthy v)
                    (let* ((opts (select-options-list node))
                           (sel-idx (position-if
                                     (lambda (o) (dom:has-attribute o "selected"))
                                     opts :from-end t)))
                      (when sel-idx
                        (let ((last-sel (nth sel-idx opts)))
                          (dolist (o opts)
                            (unless (eq o last-sel) (remove-attr o "selected")))))))
                  (setf (context-dirty ctx) t))))
        ;; add method
        (defmethod-for ctx ep "select" "add" 2 (this a)
          (let ((node (n this)))
            (when (tag-gate this)
              (let ((el (require-node ctx (arg a 0)))
                    (before (arg a 1)))
                (select-add-option node el
                  (if (or (nullish before) (js:js-undefined-p before))
                      nil
                      (let ((n (ignore-errors (floor (js:to-number before)))))
                        (if (and n (numberp n)) n (require-node ctx before)))))))
            js:*undefined*))
        ;; remove method — if no args, childNode.remove (remove from parent)
        (defmethod-for ctx ep "select" "remove" 1 (this a)
          (let ((node (n this)))
            (when (tag-gate this)
              (let ((idx (arg a 0)))
                (if (js:js-undefined-p idx)
                    (let ((parent (h:dnode-parent node)))
                      (when parent (h:dom-remove node) (setf (context-dirty ctx) t)))
                    (select-remove-option node (floor (js:to-number idx))))))
            js:*undefined*))
        ;; namedItem method — install on select per-tag proto, not shared EP
        (let ((select-proto (gethash "select" (proto ctx :html-tag-protos))))
          (defmethod* ctx select-proto "namedItem" 1 (this a)
            (let ((node (n this)))
              (select-options-named-item node (jstr (arg a 0)))))
          ;; item method
          (defmethod* ctx select-proto "item" 1 (this a)
            (let ((node (n this)))
              (let ((i (ignore-errors (floor (js:to-number (arg a 0)))))
                    (opts (select-options-list node)))
                (if (and i (>= i 0) (< i (length opts)))
                    (wrap ctx (nth i opts))
                    js:*null*)))))
        ;; willValidate getter
        (defget-for ctx ep "select" "willValidate" (this)
          (let ((node (n this)))
            (if (tag-gate this) js:*true* js:*undefined*)))
        ;; checkValidity method
        (defmethod-for ctx ep "select" "checkValidity" 0 (this a)
          (declare (ignore a))
          (let ((node (n this)))
            (if (tag-gate this)
                (if (dom:has-attribute node "required")
                    (let* ((opts (select-options-list node))
                           (sel (find-if (lambda (o) (dom:has-attribute o "selected")) opts)))
                      (if sel
                          ;; Is the selected option a placeholder label option?
                          ;; It's a placeholder if it's the first option in the
                          ;; select (in tree order), its value is "", and it's
                          ;; not inside an optgroup, and the select has
                          ;; display size 1 (or no size attribute).
                          (let* ((not-inside-optgroup
                                  (let ((p (h:dnode-parent sel)))
                                    (and p (not (string= (h:dnode-name p) "optgroup")))))
                                 (first (car opts))
                                 (is-placeholder (and first (eq sel first)
                                                      not-inside-optgroup
                                                      (select-auto-select-p node)
                                                      (not (get-attr first "value"))
                                                      (string= (select-child-text first) ""))))
                            (jbool (not is-placeholder)))
                          js:*false*))
                    js:*true*)
                js:*undefined*)))
        ;; HTMLOptionElement.selected — IDL property reflecting selectedness
        (defgetset-for ctx ep "option" "selected" (this)
          (let ((node (n this)))
            (if (string= (h:dnode-name node) "option")
                (jbool (or (dom:has-attribute node "selected")
                           (let ((parent (h:dnode-parent node)))
                             (and parent
                                  (string= (h:dnode-name parent) "select")
                                  (not (dom:has-attribute parent "multiple"))
                                  (not (find-if (lambda (o) (dom:has-attribute o "selected"))
                                                (select-options-list parent)))
                                  (eq (car (select-options-list parent)) node)))))
                js:*undefined*))
          (v) (let ((node (n this)))
                (when (string= (h:dnode-name node) "option")
                  (let ((parent (h:dnode-parent node)))
                    (if (js:js-truthy v)
                        (progn
                          (set-attr node "selected" "")
                          (when (and parent (string= (h:dnode-name parent) "select")
                                     (not (dom:has-attribute parent "multiple")))
                            (dolist (o (select-options-list parent))
                              (unless (eq o node) (remove-attr o "selected")))))
                        (remove-attr node "selected")))
                  (setf (context-dirty ctx) t))))
        ;; HTMLOptionElement.defaultSelected — reflects the selected content attribute
        (defgetset-for ctx ep "option" "defaultSelected" (this)
          (let ((node (n this)))
            (if (string= (h:dnode-name node) "option")
                (jbool (dom:has-attribute node "selected"))
                js:*undefined*))
          (v) (let ((node (n this)))
                (when (string= (h:dnode-name node) "option")
                  (if (js:js-truthy v)
                      (set-attr node "selected" "")
                      (remove-attr node "selected"))
                  (setf (context-dirty ctx) t))))
        ;; HTMLOptionElement.value — getter/setter
        (defgetset-for ctx ep "option" "value" (this)
          (let ((node (n this)))
            (if (string= (h:dnode-name node) "option")
                (select-option-value node)
                js:*undefined*))
          (v) (let ((node (n this)))
                (when (string= (h:dnode-name node) "option")
                  (set-attr node "value" (jstr v))
                  (setf (context-dirty ctx) t))))
        ;; HTMLOptionElement.text — getter (child text content)
        (defget-for ctx ep "option" "text" (this)
          (let ((node (n this)))
            (if (string= (h:dnode-name node) "option")
                (child-text-content node)
                js:*undefined*)))
        ;; HTMLOptionElement.index — getter
        (defget-for ctx ep "option" "index" (this)
          (let ((node (n this)))
            (if (string= (h:dnode-name node) "option")
                (let ((parent (h:dnode-parent node)))
                  (if (and parent (string= (h:dnode-name parent) "select"))
                      (let ((pos (position node (select-options-list parent) :test #'eq)))
                        (if pos (num pos) (num -1)))
                      (num -1)))
                js:*undefined*)))
        ;; HTMLOptionElement.label — getter/setter (reflects label attr, falls back to text)
        (defgetset-for ctx ep "option" "label" (this)
          (let ((node (n this)))
            (if (string= (h:dnode-name node) "option")
                (or (get-attr node "label") (child-text-content node))
                js:*undefined*))
          (v) (let ((node (n this)))
                (when (string= (h:dnode-name node) "option")
                  (set-attr node "label" (jstr v))
                  (setf (context-dirty ctx) t))))
        ;; HTMLOptionElement.form lives in forms-option.lisp — it is the parent
        ;; SELECT's form owner, not the option's own.  A copy here asked
        ;; ELEMENT-FORM-OWNER about the option itself, which agrees only while
        ;; the select has no `form' attribute of its own.
        ;; HTMLOptGroupElement — disabled, label
        (defgetset-for ctx ep "optgroup" "disabled" (this)
          (let ((node (n this)))
            (if (string= (h:dnode-name node) "optgroup")
                (jbool (dom:has-attribute node "disabled"))
                js:*undefined*))
          (v) (let ((node (n this)))
                (when (string= (h:dnode-name node) "optgroup")
                  (if (js:js-truthy v)
                      (set-attr node "disabled" "")
                      (remove-attr node "disabled"))
                  (setf (context-dirty ctx) t))))
        (defgetset-for ctx ep "optgroup" "label" (this)
          (let ((node (n this)))
            (if (string= (h:dnode-name node) "optgroup")
                (or (get-attr node "label") "")
                js:*undefined*))
          (v) (let ((node (n this)))
                (when (string= (h:dnode-name node) "optgroup")
                  (set-attr node "label" (jstr v))
                  (setf (context-dirty ctx) t))))
        ;; HTMLSelectElement is itself an indexed collection: `sel[2]` is the
        ;; third option and `sel[2] = opt` replaces it.  That cannot live on the
        ;; prototype — the index belongs to the instance — so it goes through the
        ;; per-element exotic hook in core.lisp.  Registered HERE, inside the
        ;; installer, because the accessors above are LABELS closed over this
        ;; context; the hook is keyed by tag and re-registers per context.
        (register-element-exotic "select"
          (lambda (ectx node obj)
            (declare (ignore ectx obj))
            (list
             :get
             (lambda (o key rcv)
               (let ((k (js:to-property-key key))
                     (l (select-options-list node)))
                 (if (and (index-string-p k) (< (parse-integer k) (length l)))
                     (wrap ctx (nth (parse-integer k) l))
                     (js::ordinary-get o k (or rcv o)))))
             ;; Also as a descriptor, so getOwnPropertyDescriptor / defineProperty
             ;; agree with what `sel[0]` returns.
             :get-own-property
             (lambda (o key)
               (let ((l (select-options-list node)))
                 (if (and (index-string-p key) (< (parse-integer key) (length l)))
                     (js::make-prop :value (wrap ctx (nth (parse-integer key) l))
                                    :enumerable t :configurable t :writable nil)
                     (js::props-get o key))))
             :set
             (lambda (o key v rcv)
               (let ((k (js:to-property-key key)))
                 (cond ((index-string-p k)
                        (select-options-index-set node (parse-integer k) v)
                        t)
                       (t (js::ordinary-set o k v (or rcv o))))))
             :has
             (lambda (o key)
               (let ((k (js:to-property-key key)))
                 (or (and (index-string-p k)
                          (< (parse-integer k) (length (select-options-list node))))
                     (js::ordinary-has o k))))
             :own-keys
             (lambda (o)
               (append (loop for i from 0 below (length (select-options-list node))
                             collect (princ-to-string i))
                       (js::ordinary-own-keys o))))))))))

(register-element-proto-extension :select #'install-forms-select)