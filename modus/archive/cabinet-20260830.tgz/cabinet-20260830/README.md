# cabinet

> Working name — rename freely.

A **hierarchical filesystem in pure Common Lisp**, built on the
[pagetree](https://github.com/modus-lisp/pagetree) copy-on-write B+tree key/value
store. Inodes, directory entries, and file data all live as ordered records in
one keyspace, so **every filesystem mutation is a single pagetree transaction** —
atomic and crash-safe by construction, with **no journal and no fsck**.

A filing cabinet holds files and folders in order and hands you the one you ask
for. That's the whole idea: names and bytes, kept in order, retrieved by path.

**No FFI, no `sb-posix`, no mmap.** The only platform contact is the one pagetree
already isolates — a ~5-op block device — so cabinet runs wherever pagetree does:
on a file today (SBCL/Linux), and on [modus](https://github.com/modus-lisp) —
a bare-metal Lisp OS — on Raspberry-Pi-class hardware tomorrow.

## Status & disclaimer

A from-scratch filesystem — **not audited, not durability-certified.** Research /
educational software; keep backups. No warranty (see [LICENSE](LICENSE)).

The core is exercised by a **differential oracle**: random op sequences checked
against an in-RAM reference model (thousands of checks per run) plus a persistence
round trip (format a real file, mutate, unmount, remount, compare). See
[Build & test](#build--test).

```lisp
(asdf:load-system "cabinet")

(let ((fs (cabinet:format-fs "/tmp/disk.cab")))   ; or NIL for an in-RAM filesystem
  (cabinet:make-directories fs "/etc/ssh")
  (cabinet:write-file fs "/etc/hostname" (cabinet::string->utf8 "modus"))
  (cabinet:read-file  fs "/etc/hostname")          ; => #(109 111 100 117 115)
  (cabinet:readdir    fs "/etc")                    ; => (("hostname" . :file) ("ssh" . :directory))
  (cabinet:rename     fs "/etc/hostname" "/etc/host")
  (cabinet:stat       fs "/etc/host")               ; => #S(FINFO :type :file :size 5 ...)
  (cabinet:unmount fs))
```

## Why a filesystem on a KV store?

Because a B+tree store already solves the hard parts a filesystem otherwise
reinvents:

- **Crash-atomicity for free.** pagetree commits are copy-on-write with a
  double-buffered meta page: a mutation is either wholly present after a power
  cut or wholly absent. cabinet makes each op one transaction, so there is never
  a torn directory or a half-written inode — and no journal, no `fsck`.
- **Ordered iteration = cheap directory & sequential reads.** A directory listing
  is a cursor seek to the directory's key prefix followed by a forward scan,
  already in name order; a file's blocks are contiguous and in order.
- **Compact, RAM-bounded.** pagetree's buffer cache is sized by a byte budget —
  the reason it exists for small hardware.

## The layout

Everything is one ordered keyspace; a one-byte tag prefixes each key so records
of a kind form a contiguous, seekable run:

| key | value | serves |
|---|---|---|
| `[0]` | superblock (next inode #, root, block size) | mount |
| `[1][ino:u64be]` | inode: type, mode, nlink, size, parent, times | `stat` |
| `[2][parent:u64be][name…]` | `[child:u64be][type]` | `lookup`, `readdir`, `rename` |
| `[3][ino:u64be][block:u64be]` | up to block-size bytes | `read`, `write`, sparse holes |

Integers in keys are big-endian so byte order equals numeric order: dirents under
a parent sort by name, data blocks by index.

## API

```
format-fs / mount / unmount        create, open, close (path, or NIL = in-RAM)
mkdir / rmdir / readdir            directories (readdir -> ((name . type) …))
make-directories                   mkdir -p
create / unlink                    regular files
read-file / write-file            byte I/O at an offset; write extends & creates
append-file / truncate-file       append; grow (sparse) or shrink
link / symlink / readlink         hard links; symbolic links
rename                            move/replace, POSIX-ish type rules, cycle-safe
stat / exists-p / file-type / file-size / chmod
string->utf8 / utf8->string        the portable name codec, for byte<->string
```

Every mutating call is one atomic transaction. Paths are absolute (a leading `/`
is optional); `.` and `..` are resolved. Timestamps come from `*fs-clock*` — bind
it to the host clock (modus) or a counter (tests).

**Not yet:** transparent symlink traversal (symlinks are stored and read, but a
symlink in the middle of a path is not followed), permission/ownership
enforcement, a stateful open-file-handle API with a seek position, and
concurrent writers (pagetree is single-writer / multi-reader). Contributions
welcome.

## Build & test

Depends only on **pagetree** (found via ASDF). Pure ANSI CL otherwise.

```lisp
(push #p"/path/to/pagetree/" asdf:*central-registry*)
(push #p"/path/to/cabinet/"  asdf:*central-registry*)
(asdf:load-system "cabinet")
```

Run the differential oracle (exits non-zero on any failure):

```sh
./run-tests.sh
```

or from a REPL: `(asdf:load-system "cabinet/test")` then
`(cabinet/test:run-tests)` — returns `T` iff every check passes.

## License

MIT — see [LICENSE](LICENSE).
