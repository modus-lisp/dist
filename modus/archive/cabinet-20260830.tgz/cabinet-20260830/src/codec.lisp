;;;; codec.lisp — the on-disk key schema and record encodings.
;;;;
;;;; cabinet keeps everything in one ordered pagetree keyspace.  A one-byte tag
;;;; prefixes every key so records of a kind form a contiguous, ordered run that
;;;; a cursor can seek into and scan:
;;;;
;;;;   [0]                                  the superblock (singleton)
;;;;   [1][ino:u64be]                       an inode record
;;;;   [2][parent:u64be][name-utf8...]      a directory entry -> [child:u64be][type:u8]
;;;;   [3][ino:u64be][block:u64be]          a file data block  -> up to block-size bytes
;;;;
;;;; Integers in keys are 8-byte big-endian so lexicographic byte order equals
;;;; numeric order: dirents under one parent sort by name, data blocks by index.

(in-package #:cabinet)

;;; ---- conditions ------------------------------------------------------------

(define-condition cabinet-error (error)
  ((path :initarg :path :initform nil :reader cabinet-error-path)
   (detail :initarg :detail :initform nil :reader cabinet-error-detail))
  (:report (lambda (c s)
             (format s "cabinet: ~a~@[ ~s~]~@[ (~a)~]"
                     (type-of c) (cabinet-error-path c) (cabinet-error-detail c)))))

(define-condition not-found          (cabinet-error) ())
(define-condition not-a-directory    (cabinet-error) ())
(define-condition is-a-directory     (cabinet-error) ())
(define-condition already-exists     (cabinet-error) ())
(define-condition directory-not-empty (cabinet-error) ())
(define-condition invalid-path       (cabinet-error) ())
(define-condition cross-type-rename  (cabinet-error) ())
(define-condition corrupt-fs         (cabinet-error) ())

;;; ---- key tags & inode types ------------------------------------------------

(defconstant +tag-super+  0)
(defconstant +tag-inode+  1)
(defconstant +tag-dirent+ 2)
(defconstant +tag-data+   3)

(defconstant +type-reg+     1)          ; regular file
(defconstant +type-dir+     2)          ; directory
(defconstant +type-symlink+ 3)          ; symbolic link

(defconstant +root-ino+ 1)              ; the root directory's inode number
(defconstant +first-ino+ 2)             ; first inode number handed out after root

(defparameter +magic+ #(#x53 #x48 #x46 #x31))   ; "SHF1"

;;; ---- byte helpers ----------------------------------------------------------

(deftype u8v () '(simple-array (unsigned-byte 8) (*)))

(defun u8 (&rest bytes)
  (make-array (length bytes) :element-type '(unsigned-byte 8) :initial-contents bytes))

(defun bcat (&rest parts)
  "Concatenate byte vectors / integers-as-single-bytes into one simple u8v."
  (let* ((len (reduce #'+ parts :key (lambda (p) (if (integerp p) 1 (length p)))))
         (out (make-array len :element-type '(unsigned-byte 8)))
         (i 0))
    (dolist (p parts out)
      (if (integerp p)
          (progn (setf (aref out i) p) (incf i))
          (progn (replace out p :start1 i) (incf i (length p)))))))

(defun u64be (n)
  (let ((v (make-array 8 :element-type '(unsigned-byte 8))))
    (dotimes (i 8 v) (setf (aref v i) (ldb (byte 8 (* 8 (- 7 i))) n)))))

(defun be->u64 (v &optional (start 0))
  (let ((n 0)) (dotimes (i 8 n) (setf n (logior (ash n 8) (aref v (+ start i)))))))

(defun u32be (n)
  (let ((v (make-array 4 :element-type '(unsigned-byte 8))))
    (dotimes (i 4 v) (setf (aref v i) (ldb (byte 8 (* 8 (- 3 i))) n)))))

(defun be->u32 (v &optional (start 0))
  (let ((n 0)) (dotimes (i 4 n) (setf n (logior (ash n 8) (aref v (+ start i)))))))

;;; ---- keys ------------------------------------------------------------------

(defun super-key () (u8 +tag-super+))
(defun inode-key (ino) (bcat +tag-inode+ (u64be ino)))
(defun dirent-key (parent name-bytes) (bcat +tag-dirent+ (u64be parent) name-bytes))
(defun dirent-prefix (parent) (bcat +tag-dirent+ (u64be parent)))
(defun data-key (ino block) (bcat +tag-data+ (u64be ino) (u64be block)))
(defun data-prefix (ino) (bcat +tag-data+ (u64be ino)))

(defun key-has-prefix-p (key prefix)
  (and (>= (length key) (length prefix))
       (loop for i below (length prefix) always (= (aref key i) (aref prefix i)))))

(defun dirent-name (key)
  "The name string of a dirent KEY (bytes after the 1+8 tag/parent header)."
  (utf8->string key 9 (length key)))

;;; ---- superblock ------------------------------------------------------------

(defstruct sb (version 1) (block-size 4096) (next-ino +first-ino+) (root-ino +root-ino+))

(defun encode-sb (s)
  (bcat +magic+ (u32be (sb-version s)) (u32be (sb-block-size s))
        (u64be (sb-next-ino s)) (u64be (sb-root-ino s))))

(defun decode-sb (v)
  (unless (and (>= (length v) 4) (loop for i below 4 always (= (aref v i) (aref +magic+ i))))
    (error 'corrupt-fs :path nil :detail "bad superblock magic"))
  (make-sb :version    (be->u32 v 4)
           :block-size (be->u32 v 8)
           :next-ino   (be->u64 v 12)
           :root-ino   (be->u64 v 20)))

;;; ---- inode -----------------------------------------------------------------
;;; Fixed 41-byte record: type(1) mode(4) nlink(4) size(8) parent(8) mtime(8) ctime(8).
;;; PARENT is meaningful for directories (their ".." target, and the rename hook);
;;; it is 0 for files and symlinks, which have no single parent (hard links).

(defstruct inode
  (type +type-reg+) (mode 0) (nlink 1) (size 0) (parent 0) (mtime 0) (ctime 0))

(defun encode-inode (n)
  (bcat (inode-type n) (u32be (inode-mode n)) (u32be (inode-nlink n))
        (u64be (inode-size n)) (u64be (inode-parent n))
        (u64be (inode-mtime n)) (u64be (inode-ctime n))))

(defun decode-inode (v)
  (make-inode :type (aref v 0) :mode (be->u32 v 1) :nlink (be->u32 v 5)
              :size (be->u64 v 9) :parent (be->u64 v 17)
              :mtime (be->u64 v 25) :ctime (be->u64 v 33)))

(defun dir-p     (n) (= (inode-type n) +type-dir+))
(defun symlink-p (n) (= (inode-type n) +type-symlink+))
