;;;; utf8.lisp — a minimal, portable UTF-8 codec.
;;;;
;;;; cabinet stores path-component names as bytes, but the public API speaks in
;;;; strings.  We can't reach for sb-ext:string-to-octets (SBCL-only) and stay
;;;; portable to modus, so here's a small self-contained UTF-8 encoder/decoder
;;;; built only on CHAR-CODE / CODE-CHAR (which modus's runtime provides).

(in-package #:cabinet)

(defun string->utf8 (s)
  "Encode string S to a (simple-array (unsigned-byte 8)) of its UTF-8 bytes."
  (let ((out (make-array (length s) :element-type '(unsigned-byte 8)
                                    :adjustable t :fill-pointer 0)))
    (loop for ch across s
          for cp = (char-code ch) do
      (cond
        ((< cp #x80) (vector-push-extend cp out))
        ((< cp #x800)
         (vector-push-extend (logior #xC0 (ldb (byte 5 6) cp)) out)
         (vector-push-extend (logior #x80 (ldb (byte 6 0) cp)) out))
        ((< cp #x10000)
         (vector-push-extend (logior #xE0 (ldb (byte 4 12) cp)) out)
         (vector-push-extend (logior #x80 (ldb (byte 6 6) cp)) out)
         (vector-push-extend (logior #x80 (ldb (byte 6 0) cp)) out))
        (t
         (vector-push-extend (logior #xF0 (ldb (byte 3 18) cp)) out)
         (vector-push-extend (logior #x80 (ldb (byte 6 12) cp)) out)
         (vector-push-extend (logior #x80 (ldb (byte 6 6) cp)) out)
         (vector-push-extend (logior #x80 (ldb (byte 6 0) cp)) out))))
    ;; return a plain simple-array
    (let ((r (make-array (length out) :element-type '(unsigned-byte 8))))
      (replace r out) r)))

(defun utf8->string (bytes &optional (start 0) (end (length bytes)))
  "Decode UTF-8 BYTES[start:end] to a string.  Malformed sequences decode as the
   replacement character #xFFFD (we never signal — a filename round-trips)."
  (let ((out (make-array 0 :element-type 'character :adjustable t :fill-pointer 0))
        (i start))
    (flet ((cont (j) (and (< j end) (= #x80 (logand (aref bytes j) #xC0))))
           (lo (b) (logand b #x3F)))
      (loop while (< i end) do
        (let ((b (aref bytes i)))
          (cond
            ((< b #x80) (vector-push-extend (code-char b) out) (incf i))
            ((and (= #xC0 (logand b #xE0)) (cont (+ i 1)))
             (vector-push-extend
              (code-char (logior (ash (logand b #x1F) 6) (lo (aref bytes (+ i 1))))) out)
             (incf i 2))
            ((and (= #xE0 (logand b #xF0)) (cont (+ i 1)) (cont (+ i 2)))
             (vector-push-extend
              (code-char (logior (ash (logand b #x0F) 12)
                                 (ash (lo (aref bytes (+ i 1))) 6)
                                 (lo (aref bytes (+ i 2))))) out)
             (incf i 3))
            ((and (= #xF0 (logand b #xF8)) (cont (+ i 1)) (cont (+ i 2)) (cont (+ i 3)))
             (vector-push-extend
              (code-char (logior (ash (logand b #x07) 18)
                                 (ash (lo (aref bytes (+ i 1))) 12)
                                 (ash (lo (aref bytes (+ i 2))) 6)
                                 (lo (aref bytes (+ i 3))))) out)
             (incf i 4))
            (t (vector-push-extend (code-char #xFFFD) out) (incf i))))))
    (coerce out 'simple-string)))
