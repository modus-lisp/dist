;;;; packages.lisp — cabinet

(defpackage #:cabinet
  (:use #:cl)
  (:local-nicknames (#:pt #:pagetree))
  (:documentation
   "cabinet — a hierarchical filesystem over the pagetree CoW B+tree KV store.  A
    filing cabinet holds files and folders in order and hands you the one you ask
    for — which is just what this does: inodes, directory entries, and file data
    are ordered key/value records in one keyspace, so a filesystem mutation is a
    single pagetree write transaction: crash-atomic by construction, with no
    journal and no fsck.  Pure ANSI CL above pagetree's block-device seam.")
  (:export
   ;; lifecycle
   #:format-fs #:mount #:unmount #:fs #:fs-block-size #:*fs-clock*
   ;; directories
   #:mkdir #:rmdir #:readdir #:make-directories
   ;; files
   #:create #:unlink #:read-file #:write-file #:append-file #:truncate-file
   ;; links
   #:link #:symlink #:readlink #:rename
   ;; metadata / queries
   #:stat #:exists-p #:file-type #:file-size #:chmod
   #:stat-ino #:stat-type #:stat-mode #:stat-nlink #:stat-size
   #:stat-mtime #:stat-ctime #:stat-parent
   ;; byte<->string (portable UTF-8 codec)
   #:string->utf8 #:utf8->string
   ;; conditions
   #:cabinet-error #:cabinet-error-path
   #:cabinet-error-detail
   #:not-found #:not-a-directory #:is-a-directory
   #:already-exists #:directory-not-empty #:invalid-path #:cross-type-rename
   #:corrupt-fs))
