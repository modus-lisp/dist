;;;; fs.lisp — the filesystem: mount, path resolution, and the POSIX-ish ops.
;;;;
;;;; Everything is a record in one ordered pagetree keyspace (see codec.lisp).
;;;; A filesystem mutation is one pagetree write transaction, so it is atomic and
;;;; crash-safe by construction: pagetree's copy-on-write + double-meta commit
;;;; means a mutation is either wholly present after a crash or wholly absent —
;;;; there is never a torn directory or a half-written inode, and no fsck.

(in-package #:cabinet)

;;; ---- clock -----------------------------------------------------------------

(defvar *fs-clock* #'get-universal-time
  "Function of no args returning the current time as an integer (seconds).  The
   host clock: rebind to modus's clock on bare metal, or to a counter for
   deterministic tests.  Timestamps are metadata only — they never affect
   structure or file contents.")

(declaim (inline now))
(defun now () (funcall *fs-clock*))

;;; ---- the mounted filesystem handle -----------------------------------------

(defstruct (fs (:constructor %make-fs))
  store
  (block-size 4096)
  (root-ino +root-ino+))

(defmacro with-read ((txn fs) &body body)
  `(pt:with-read-txn (,txn (fs-store ,fs)) ,@body))
(defmacro with-write ((txn fs) &body body)
  `(pt:with-write-txn (,txn (fs-store ,fs)) ,@body))

;;; ---- record accessors (all operate inside a caller-supplied txn) -----------

(defun get-super (txn)
  (let ((v (pt:tget txn (super-key))))
    (unless v (error 'corrupt-fs :detail "no superblock — not a cabinet filesystem"))
    (decode-sb v)))
(defun put-super (txn s) (pt:tput txn (super-key) (encode-sb s)))

(defun alloc-ino (txn)
  "Reserve and return the next inode number, persisting the bump in this txn."
  (let* ((s (get-super txn)) (ino (sb-next-ino s)))
    (setf (sb-next-ino s) (1+ ino))
    (put-super txn s)
    ino))

(defun get-inode (txn ino)
  (let ((v (pt:tget txn (inode-key ino)))) (and v (decode-inode v))))
(defun put-inode (txn ino n) (pt:tput txn (inode-key ino) (encode-inode n)))
(defun del-inode (txn ino) (pt:tdel txn (inode-key ino)))
(defun require-inode (txn ino &optional path)
  (or (get-inode txn ino) (error 'corrupt-fs :path path :detail "dangling inode")))

(defun lookup-dirent (txn parent name-bytes)
  "(values child-ino type) for NAME in dir PARENT, or NIL if absent."
  (let ((v (pt:tget txn (dirent-key parent name-bytes))))
    (when v (values (be->u64 v 0) (aref v 8)))))
(defun put-dirent (txn parent name-bytes ino type)
  (pt:tput txn (dirent-key parent name-bytes) (bcat (u64be ino) type)))
(defun del-dirent (txn parent name-bytes)
  (pt:tdel txn (dirent-key parent name-bytes)))

(defun scan-prefix (txn prefix)
  "List of (key . value) for every entry whose key begins with PREFIX, in order.
   Materialized up front so callers may mutate the tree without disturbing a
   live cursor."
  (let ((cur (pt:tcursor txn)) (out '()))
    (when (pt:cursor-seek cur prefix)
      (loop for k = (pt:cursor-key cur)
            while (and k (key-has-prefix-p k prefix))
            do (push (cons k (pt:cursor-value cur)) out)
               (unless (pt:cursor-next cur) (return))))
    (nreverse out)))

(defun dir-empty-p (txn ino)
  (let ((cur (pt:tcursor txn)) (prefix (dirent-prefix ino)))
    (not (and (pt:cursor-seek cur prefix)
              (key-has-prefix-p (pt:cursor-key cur) prefix)))))

;;; ---- path resolution -------------------------------------------------------

(defun path-components (path)
  "Split PATH on '/', dropping empty pieces (so leading/trailing/double slashes
   are harmless).  '.' and '..' survive as components for RESOLVE to interpret.
   All paths are rooted at the filesystem root."
  (let ((parts '()) (start 0) (n (length path)))
    (dotimes (i (1+ n))
      (when (or (= i n) (char= (char path i) #\/))
        (when (> i start) (push (subseq path start i) parts))
        (setf start (1+ i))))
    (nreverse parts)))

(defun resolve-ino (txn components &optional path)
  "Follow COMPONENTS from the root, returning the final inode number.  Each
   non-final step must name a directory.  Symlinks are opaque (a symlink used as
   a path component signals not-a-directory) — transparent traversal is a
   documented follow-up."
  (let ((ino +root-ino+))
    (dolist (c components ino)
      (cond
        ((string= c ".") nil)
        ((string= c "..")
         (let ((n (require-inode txn ino path)))
           (unless (dir-p n) (error 'not-a-directory :path path))
           (setf ino (inode-parent n))))
        (t
         (let ((n (require-inode txn ino path)))
           (unless (dir-p n) (error 'not-a-directory :path path))
           (let ((child (lookup-dirent txn ino (string->utf8 c))))
             (unless child (error 'not-found :path path))
             (setf ino child))))))))

(defun path-ino (txn path) (resolve-ino txn (path-components path) path))

(defun resolve-parent (txn path)
  "(values PARENT-INO NAME-STRING) for the final component of PATH; the parent
   must exist and be a directory.  Signals invalid-path for the root or a
   trailing '.'/'..'"
  (let ((comps (path-components path)))
    (when (null comps) (error 'invalid-path :path path :detail "root has no parent"))
    (let ((name (car (last comps))))
      (when (or (string= name ".") (string= name ".."))
        (error 'invalid-path :path path :detail "trailing . or .."))
      (let ((pino (resolve-ino txn (butlast comps) path)))
        (unless (dir-p (require-inode txn pino path))
          (error 'not-a-directory :path path))
        (values pino name)))))

;;; ---- lifecycle -------------------------------------------------------------

(defun mount (path &key cache-bytes)
  "Open an existing cabinet filesystem at PATH (a file, or NIL for a fresh in-RAM
   store).  Signals corrupt-fs if PATH holds no superblock."
  (let* ((store (pt:open-store path :cache-bytes cache-bytes))
         (bs (pt:with-read-txn (txn store) (sb-block-size (get-super txn)))))
    (%make-fs :store store :block-size bs)))

(defun format-fs (path &key (block-size 4096) cache-bytes)
  "Create a fresh, empty cabinet filesystem at PATH (overwriting any existing file;
   PATH NIL = in-RAM).  Returns a mounted FS with just a root directory."
  (when (and path (probe-file path)) (delete-file path))
  (let ((store (pt:open-store path :cache-bytes cache-bytes)))
    (pt:with-write-txn (txn store)
      (put-super txn (make-sb :block-size block-size))
      (let ((tm (now)))
        (put-inode txn +root-ino+
                   (make-inode :type +type-dir+ :mode #o755 :nlink 2
                               :parent +root-ino+ :mtime tm :ctime tm))))
    (%make-fs :store store :block-size block-size)))

(defun unmount (fs)
  "Flush and close the filesystem."
  (pt:close-store (fs-store fs))
  (setf (fs-store fs) nil)
  t)

;;; ---- helpers shared by the mutating ops ------------------------------------

(defun touch-dir (txn ino)
  "Bump a directory's mtime after an entry is added or removed."
  (let ((n (require-inode txn ino))) (setf (inode-mtime n) (now)) (put-inode txn ino n)))

(defun name-free-p (txn parent name-bytes)
  (null (lookup-dirent txn parent name-bytes)))

(defun type-keyword (type)
  (cond ((= type +type-dir+) :directory)
        ((= type +type-symlink+) :symlink)
        (t :file)))

;;; ---- directories -----------------------------------------------------------

(defun mkdir (fs path &key (mode #o755))
  "Create directory PATH.  Signals already-exists / not-found (missing parent)."
  (with-write (txn fs)
    (multiple-value-bind (pino name) (resolve-parent txn path)
      (let ((nb (string->utf8 name)))
        (unless (name-free-p txn pino nb) (error 'already-exists :path path))
        (let ((ino (alloc-ino txn)) (tm (now)))
          (put-inode txn ino (make-inode :type +type-dir+ :mode mode :nlink 2
                                         :parent pino :mtime tm :ctime tm))
          (put-dirent txn pino nb ino +type-dir+)
          ;; the new dir's ".." backlink bumps the parent's link count
          (let ((p (require-inode txn pino path)))
            (incf (inode-nlink p)) (setf (inode-mtime p) tm) (put-inode txn pino p))
          ino)))))

(defun make-directories (fs path &key (mode #o755))
  "Create PATH and any missing parent directories (like mkdir -p).  Existing
   directories are fine; an existing non-directory on the way signals.  Returns
   the inode of the final directory."
  (let ((ino +root-ino+) (acc ""))
    (dolist (c (path-components path) ino)
      (setf acc (concatenate 'string acc "/" c))
      (unless (string= c ".")
        (with-write (txn fs)
          (if (string= c "..")
              (setf ino (inode-parent (require-inode txn ino acc)))
              (let ((nb (string->utf8 c)))
                (multiple-value-bind (child type) (lookup-dirent txn ino nb)
                  (cond
                    ((and child (= type +type-dir+)) (setf ino child))
                    (child (error 'not-a-directory :path acc))
                    (t (let ((nino (alloc-ino txn)) (tm (now)))
                         (put-inode txn nino (make-inode :type +type-dir+ :mode mode :nlink 2
                                                         :parent ino :mtime tm :ctime tm))
                         (put-dirent txn ino nb nino +type-dir+)
                         (let ((p (require-inode txn ino)))
                           (incf (inode-nlink p)) (setf (inode-mtime p) tm) (put-inode txn ino p))
                         (setf ino nino))))))))))))

(defun rmdir (fs path)
  "Remove empty directory PATH.  Signals not-a-directory / directory-not-empty."
  (with-write (txn fs)
    (multiple-value-bind (pino name) (resolve-parent txn path)
      (let ((nb (string->utf8 name)))
        (multiple-value-bind (ino type) (lookup-dirent txn pino nb)
          (unless ino (error 'not-found :path path))
          (unless (= type +type-dir+) (error 'not-a-directory :path path))
          (unless (dir-empty-p txn ino) (error 'directory-not-empty :path path))
          (del-dirent txn pino nb)
          (del-inode txn ino)
          (let ((p (require-inode txn pino)))
            (decf (inode-nlink p)) (setf (inode-mtime p) (now)) (put-inode txn pino p))
          t)))))

(defun readdir (fs path)
  "List directory PATH as ((name . type-keyword) ...) in name order.  TYPE is
   :file / :directory / :symlink."
  (with-read (txn fs)
    (let ((ino (path-ino txn path)))
      (unless (dir-p (require-inode txn ino path)) (error 'not-a-directory :path path))
      (mapcar (lambda (kv)
                (cons (dirent-name (car kv)) (type-keyword (aref (cdr kv) 8))))
              (scan-prefix txn (dirent-prefix ino))))))

;;; ---- file creation / removal / links ---------------------------------------

(defun create (fs path &key (mode #o644))
  "Create an empty regular file PATH.  Signals already-exists."
  (with-write (txn fs)
    (multiple-value-bind (pino name) (resolve-parent txn path)
      (let ((nb (string->utf8 name)))
        (unless (name-free-p txn pino nb) (error 'already-exists :path path))
        (let ((ino (alloc-ino txn)) (tm (now)))
          (put-inode txn ino (make-inode :type +type-reg+ :mode mode :nlink 1
                                         :mtime tm :ctime tm))
          (put-dirent txn pino nb ino +type-reg+)
          (touch-dir txn pino)
          ino)))))

(defun free-inode-data (txn ino)
  "Delete every data block of INO."
  (dolist (kv (scan-prefix txn (data-prefix ino)))
    (pt:tdel txn (car kv))))

(defun unlink (fs path)
  "Remove a link to a file (or symlink).  Directories need rmdir.  When the last
   link is gone the inode and its data are freed."
  (with-write (txn fs)
    (multiple-value-bind (pino name) (resolve-parent txn path)
      (let ((nb (string->utf8 name)))
        (multiple-value-bind (ino type) (lookup-dirent txn pino nb)
          (unless ino (error 'not-found :path path))
          (when (= type +type-dir+) (error 'is-a-directory :path path))
          (del-dirent txn pino nb)
          (let ((n (require-inode txn ino path)))
            (decf (inode-nlink n))
            (if (<= (inode-nlink n) 0)
                (progn (free-inode-data txn ino) (del-inode txn ino))
                (progn (setf (inode-ctime n) (now)) (put-inode txn ino n))))
          (touch-dir txn pino)
          t)))))

(defun link (fs existing new)
  "Create a hard link NEW to the existing file EXISTING (no directories)."
  (with-write (txn fs)
    (let ((ino (path-ino txn existing)))
      (let ((n (require-inode txn ino existing)))
        (when (dir-p n) (error 'is-a-directory :path existing))
        (multiple-value-bind (pino name) (resolve-parent txn new)
          (let ((nb (string->utf8 name)))
            (unless (name-free-p txn pino nb) (error 'already-exists :path new))
            (put-dirent txn pino nb ino (inode-type n))
            (incf (inode-nlink n)) (setf (inode-ctime n) (now)) (put-inode txn ino n)
            (touch-dir txn pino)
            t))))))

(defun symlink (fs target linkpath)
  "Create a symbolic link LINKPATH whose contents are the string TARGET."
  (with-write (txn fs)
    (multiple-value-bind (pino name) (resolve-parent txn linkpath)
      (let ((nb (string->utf8 name)) (tb (string->utf8 target)))
        (unless (name-free-p txn pino nb) (error 'already-exists :path linkpath))
        (let ((ino (alloc-ino txn)) (tm (now)))
          (put-inode txn ino (make-inode :type +type-symlink+ :mode #o777 :nlink 1
                                         :size (length tb) :mtime tm :ctime tm))
          (pt:tput txn (data-key ino 0) tb)
          (put-dirent txn pino nb ino +type-symlink+)
          (touch-dir txn pino)
          ino)))))

(defun readlink (fs path)
  "The target string of the symlink at PATH."
  (with-read (txn fs)
    (multiple-value-bind (pino name) (resolve-parent txn path)
      (let ((nb (string->utf8 name)))
        (multiple-value-bind (ino type) (lookup-dirent txn pino nb)
          (unless ino (error 'not-found :path path))
          (unless (= type +type-symlink+) (error 'invalid-path :path path :detail "not a symlink"))
          (let ((v (pt:tget txn (data-key ino 0))))
            (if v (utf8->string v) "")))))))

;;; ---- rename ----------------------------------------------------------------

(defun rename (fs old new)
  "Rename/move OLD to NEW.  If NEW exists it is replaced, with POSIX-ish type
   rules: a file may replace a file, an empty directory may replace an empty
   directory; a type mismatch signals cross-type-rename."
  (with-write (txn fs)
    (multiple-value-bind (opino oname) (resolve-parent txn old)
      (let ((onb (string->utf8 oname)))
        (multiple-value-bind (oino otype) (lookup-dirent txn opino onb)
          (unless oino (error 'not-found :path old))
          (multiple-value-bind (npino nname) (resolve-parent txn new)
            (let ((nnb (string->utf8 nname)))
              (when (and (= opino npino) (string= oname nname)) (return-from rename t))
              ;; a directory may not be moved into itself or a descendant (cycle)
              (when (= otype +type-dir+)
                (loop for a = npino then (inode-parent (require-inode txn a))
                      do (when (= a oino)
                           (error 'invalid-path :path new :detail "rename into own subtree"))
                         (when (= a +root-ino+) (return))))
              (multiple-value-bind (dino dtype) (lookup-dirent txn npino nnb)
                (when dino               ; destination exists — replace it
                  (let ((src-dir (= otype +type-dir+)) (dst-dir (= dtype +type-dir+)))
                    (cond
                      ((and src-dir dst-dir)
                       (unless (dir-empty-p txn dino) (error 'directory-not-empty :path new))
                       (del-dirent txn npino nnb) (del-inode txn dino)
                       (let ((p (require-inode txn npino)))
                         (decf (inode-nlink p)) (put-inode txn npino p)))
                      ((or src-dir dst-dir) (error 'cross-type-rename :path new))
                      (t                   ; file replaces file: drop the victim link
                       (del-dirent txn npino nnb)
                       (let ((v (require-inode txn dino)))
                         (decf (inode-nlink v))
                         (if (<= (inode-nlink v) 0)
                             (progn (free-inode-data txn dino) (del-inode txn dino))
                             (put-inode txn dino v)))))))
                ;; move the entry
                (del-dirent txn opino onb)
                (put-dirent txn npino nnb oino otype)
                (when (= otype +type-dir+)
                  ;; reparent: fix ".." target and move a link count between parents
                  (let ((n (require-inode txn oino)))
                    (setf (inode-parent n) npino) (put-inode txn oino n))
                  (unless (= opino npino)
                    (let ((op (require-inode txn opino)) (np (require-inode txn npino)))
                      (decf (inode-nlink op)) (put-inode txn opino op)
                      (incf (inode-nlink np)) (put-inode txn npino np))))
                (touch-dir txn opino)
                (unless (= opino npino) (touch-dir txn npino))
                t))))))))

;;; ---- file data I/O ---------------------------------------------------------

(defun get-block (txn ino blk)
  "The stored bytes of data block BLK (possibly shorter than block-size), or NIL
   if the block was never written (a hole)."
  (pt:tget txn (data-key ino blk)))

(defun require-regular (txn ino path)
  (let ((n (require-inode txn ino path)))
    (when (dir-p n) (error 'is-a-directory :path path))
    n))

(defun read-file (fs path &key (offset 0) count)
  "Read up to COUNT bytes (or to EOF) from PATH at OFFSET; returns a u8 vector.
   Holes and bytes past the stored block tail read as zero."
  (with-read (txn fs)
    (let* ((ino (path-ino txn path))
           (n (require-regular txn ino path))
           (bs (fs-block-size fs))
           (size (inode-size n))
           (start (min offset size))
           (end (if count (min size (+ start count)) size))
           (len (max 0 (- end start)))
           (out (make-array len :element-type '(unsigned-byte 8) :initial-element 0)))
      (when (plusp len)
        (loop with pos = start
              while (< pos end)
              for blk = (floor pos bs)
              for boff = (- pos (* blk bs))
              for take = (min (- bs boff) (- end pos))
              for stored = (get-block txn ino blk)
              do (when stored
                   (let ((avail (max 0 (min take (- (length stored) boff)))))
                     (when (plusp avail)
                       (replace out stored :start1 (- pos start)
                                           :start2 boff :end2 (+ boff avail)))))
                 (incf pos take)))
      out)))

(defun write-file (fs path bytes &key (offset 0) (create t) (mode #o644))
  "Write BYTES to PATH starting at OFFSET, extending the file as needed.  Creates
   the file if absent and CREATE (the default).  Returns the new file size."
  (with-write (txn fs)
    (let* ((bs (fs-block-size fs))
           (ino
             (handler-case (path-ino txn path)
               (not-found (e)
                 (unless create (error e))
                 ;; create it in this same txn
                 (multiple-value-bind (pino name) (resolve-parent txn path)
                   (let ((nb (string->utf8 name)) (i (alloc-ino txn)) (tm (now)))
                     (put-inode txn i (make-inode :type +type-reg+ :mode mode :nlink 1
                                                  :mtime tm :ctime tm))
                     (put-dirent txn pino nb i +type-reg+)
                     (touch-dir txn pino)
                     i)))))
           (n (require-regular txn ino path))
           (total (length bytes))
           (end (+ offset total)))
      (loop with pos = offset with bpos = 0
            while (< pos end)
            for blk = (floor pos bs)
            for boff = (- pos (* blk bs))
            for take = (min (- bs boff) (- end pos))
            do (let* ((stored (get-block txn ino blk))
                      (need (+ boff take))
                      (cur-len (if stored (length stored) 0))
                      (newlen (max cur-len need))
                      (buf (make-array newlen :element-type '(unsigned-byte 8)
                                              :initial-element 0)))
                 (when stored (replace buf stored))
                 (replace buf bytes :start1 boff :start2 bpos :end2 (+ bpos take))
                 (pt:tput txn (data-key ino blk) buf))
               (incf pos take) (incf bpos take))
      (when (> end (inode-size n)) (setf (inode-size n) end))
      (setf (inode-mtime n) (now) (inode-ctime n) (now))
      (put-inode txn ino n)
      (inode-size n))))

(defun append-file (fs path bytes &key (create t) (mode #o644))
  "Append BYTES to the end of PATH."
  (let ((size (with-read (txn fs)
                (handler-case (inode-size (require-regular txn (path-ino txn path) path))
                  (not-found () 0)))))
    (write-file fs path bytes :offset size :create create :mode mode)))

(defun truncate-file (fs path size)
  "Set PATH's length to SIZE: grow with a zero hole, or shrink and free the
   blocks past SIZE (trimming the boundary block)."
  (with-write (txn fs)
    (let* ((ino (path-ino txn path))
           (n (require-regular txn ino path))
           (bs (fs-block-size fs))
           (old (inode-size n)))
      (when (< size old)
        ;; drop whole blocks beyond SIZE; trim the block that straddles SIZE
        (dolist (kv (scan-prefix txn (data-prefix ino)))
          (let ((blk (be->u64 (car kv) 9)))     ; key = [3][ino:8][block:8]
            (cond ((>= (* blk bs) size) (pt:tdel txn (car kv)))
                  (t (let* ((keep (- size (* blk bs)))
                            (stored (cdr kv)))
                       (when (> (length stored) keep)
                         (pt:tput txn (car kv)
                                  (subseq stored 0 (max 0 keep))))))))))
      (setf (inode-size n) size (inode-mtime n) (now) (inode-ctime n) (now))
      (put-inode txn ino n)
      size)))

;;; ---- metadata / queries ----------------------------------------------------

(defstruct (finfo (:conc-name stat-))
  ino type mode nlink size mtime ctime parent)

(defun stat (fs path)
  "Metadata for PATH as a FINFO (accessors stat-type/-size/-mode/…).  TYPE is
   :file / :directory / :symlink."
  (with-read (txn fs)
    (let* ((ino (path-ino txn path)) (n (require-inode txn ino path)))
      (make-finfo :ino ino :type (type-keyword (inode-type n)) :mode (inode-mode n)
                  :nlink (inode-nlink n) :size (inode-size n)
                  :mtime (inode-mtime n) :ctime (inode-ctime n) :parent (inode-parent n)))))

(defun chmod (fs path mode)
  "Set PATH's permission bits to MODE (an integer).  Returns MODE."
  (with-write (txn fs)
    (let* ((ino (path-ino txn path)) (n (require-inode txn ino path)))
      (setf (inode-mode n) mode (inode-ctime n) (now)) (put-inode txn ino n)
      mode)))

(defun exists-p (fs path)
  "True if PATH resolves to something."
  (with-read (txn fs)
    (handler-case (progn (path-ino txn path) t)
      (not-found () nil) (not-a-directory () nil))))

(defun file-type (fs path)
  "The type keyword of PATH (:file/:directory/:symlink), or NIL if absent."
  (with-read (txn fs)
    (handler-case (type-keyword (inode-type (require-inode txn (path-ino txn path) path)))
      (not-found () nil) (not-a-directory () nil))))

(defun file-size (fs path)
  (with-read (txn fs)
    (inode-size (require-inode txn (path-ino txn path) path))))
