# cabinet — design notes

A POSIX-ish filesystem as a thin, ordered key schema over pagetree's CoW B+tree
KV store. The store supplies the hard guarantees (atomic commit, ordered scan,
RAM-bounded cache); cabinet supplies naming, directories, and file data.

## Layers

- **pagetree** (dependency): Layer 0 block device → pager/cache → CoW B+tree with
  crash-atomic double-meta commit. Keys/values are byte vectors; `cursor-seek`
  gives lower-bound positioning for prefix scans.
- **cabinet** (this repo):
  - `codec.lisp` — the key schema (tag-prefixed, big-endian ints) and fixed-size
    record encodings (superblock, inode, dirent, data block); conditions.
  - `utf8.lisp` — a small portable UTF-8 codec (names are stored as bytes; no
    `sb-ext:string-to-octets`, to stay modus-portable).
  - `fs.lisp` — mount/format, path resolution, and the operations.

## Key schema

One ordered keyspace, one-byte tag per key so each record kind is a contiguous,
seekable run:

```
[0]                              superblock (singleton)
[1][ino:u64be]                   inode: type,mode,nlink,size,parent,mtime,ctime
[2][parent:u64be][name-utf8…]    dirent -> [child:u64be][type:u8]
[3][ino:u64be][block:u64be]      data block -> up to block-size bytes
```

Big-endian integers so lexicographic byte order = numeric order (dirents sort by
name; blocks by index). Root inode = 1; the superblock hands out inode numbers.

## Invariants & decisions

- **op = transaction.** Each mutating op runs in one `pagetree:with-write-txn`,
  so it is atomic and crash-safe; a signalled error aborts the txn (no partial
  mutation). Reads use a read txn.
- **directories** don't store `.`/`..` as entries; `..` resolves via the inode's
  `parent` field (also the rename reparent hook). Dir `nlink` = 2 + subdirs.
- **files**: block-indexed data (default 4 KB logical blocks). Writes are
  read-modify-write per touched block; unwritten blocks and bytes past a stored
  block's tail read as zero (sparse). `size` lives in the inode.
- **hard links**: multiple dirents → one inode; `nlink` tracks them; data is
  freed when the last link goes. **symlinks**: target stored as the inode's data
  block 0; stored and readable, but not yet transparently traversed.
- **rename**: POSIX-ish replace rules (file↔file, empty-dir↔empty-dir; type
  mismatch errors); refuses moving a directory into its own subtree (cycle).

## Correctness

A **differential oracle** (`test/oracle.lisp`), the pagetree / secp256k1-fast
pattern: random op sequences run against both cabinet and a dead-simple in-RAM
model, asserting agreement (success/failure, read-backs) with periodic full-tree
comparisons; then a persistence round trip (format a real file → mutate →
unmount → remount → compare). Crash-mid-op atomicity is inherited from
pagetree's fault-injection oracle, since each op is exactly one pagetree
transaction.

## Later

Transparent symlink traversal; a stateful open-handle API (seek position);
permission/ownership checks; an extent/large-file fast path that bypasses the
btree for big sequential files; the modus Layer-0 block driver (virtio-blk for
QEMU, then SD/eMMC) that lets the whole stack persist on bare metal.
