;;;; cabinet.asd — a POSIX-ish filesystem over pagetree, in pure Common Lisp.

(asdf:defsystem :cabinet
  :description "A hierarchical filesystem built on the pagetree copy-on-write
B+tree KV store: inodes, directories, and file data live as ordered key/value
records in one keyspace, so every mutation is a single crash-atomic pagetree
transaction — no journal, no fsck.  POSIX-ish path API (mkdir/create/read/
write/readdir/stat/unlink/rename/link/symlink/truncate).  Pure ANSI CL above
pagetree's Layer-0 block-device seam — no FFI, no sb-posix; the target is
modus on Raspberry-Pi-class hardware."
  :version "0.0.1"
  :author "ynniv"
  :license "MIT"
  :depends-on ("pagetree")
  :serial t
  :components
  ((:module "src"
    :serial t
    :components
    ((:file "packages")
     (:file "utf8")
     (:file "codec")
     (:file "fs")))))

(asdf:defsystem :cabinet/test
  :description "Differential-oracle test suite for cabinet."
  :depends-on ("cabinet")
  :serial t
  :components
  ((:module "test"
    :serial t
    :components ((:file "oracle")))))
