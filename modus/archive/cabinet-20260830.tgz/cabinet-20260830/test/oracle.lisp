;;;; oracle.lisp — a differential test for cabinet.
;;;;
;;;; The correctness proof cabinet borrows from pagetree and secp256k1-fast: run
;;;; random filesystem op sequences against BOTH cabinet and a dead-simple in-RAM
;;;; reference model, and assert they agree at every step — same success/failure,
;;;; same read-backs — with periodic full-tree comparisons.  Then a persistence
;;;; round trip (format a real file, mutate, unmount, remount, compare) exercises
;;;; the on-disk path and durable reopen.  Crash-mid-op atomicity is inherited
;;;; from pagetree's fault-injection oracle: each cabinet op is exactly one
;;;; pagetree write transaction.

(defpackage #:cabinet/test
  (:use #:cl)
  (:local-nicknames (#:cab #:cabinet))
  (:export #:run-tests))

(in-package #:cabinet/test)

;;; ---- counters --------------------------------------------------------------

(defvar *checks* 0)
(defvar *fails* 0)

(defun check (ok fmt &rest args)
  (incf *checks*)
  (unless ok
    (incf *fails*)
    (format t "~&  FAIL: ~?~%" fmt args)))

;;; ---- deterministic RNG (portable, reproducible) ----------------------------

(defvar *seed* 88172645463325252)
(defun rng ()
  (let ((x *seed*))
    (setf x (logand (logxor x (ash x 13)) #xFFFFFFFFFFFFFFFF))
    (setf x (logxor x (ash x -7)))
    (setf x (logand (logxor x (ash x 17)) #xFFFFFFFFFFFFFFFF))
    (setf *seed* x)))
(defun rnd (n) (mod (rng) n))
(defun pick (seq) (elt seq (rnd (length seq))))

;;; ---- byte helpers ----------------------------------------------------------

(defun b= (x y)
  (and (= (length x) (length y))
       (loop for i below (length x) always (= (aref x i) (aref y i)))))

(defun rand-bytes (n)
  (let ((v (make-array n :element-type '(unsigned-byte 8))))
    (dotimes (i n v) (setf (aref v i) (rnd 256)))))

;;; ---- the reference model ---------------------------------------------------
;;; A hash of absolute-path-string -> mnode.  Hard links share an mnode object
;;; (so a write through one path shows through the other, as with a real inode).
;;; Directory children are derived by scanning path keys.  Error semantics are
;;; compared only as success/failure — never the specific condition class.

(defstruct mnode type (data (make-array 0 :element-type '(unsigned-byte 8)
                                          :adjustable t :fill-pointer 0)))

(defvar *m*)                            ; the model hash

(defun m-init () (setf *m* (make-hash-table :test 'equal))
  (setf (gethash "/" *m*) (make-mnode :type :dir)))

(defun m-parent (path)
  (let ((i (position #\/ path :from-end t)))
    (if (= i 0) "/" (subseq path 0 i))))
(defun m-name (path) (subseq path (1+ (position #\/ path :from-end t))))

(defun m-node (path) (gethash path *m*))
(defun m-dir-p (path)
  (let ((n (m-node path))) (and n (eq (mnode-type n) :dir))))
(defun m-children (path)
  "List of (name . type-keyword) that are direct children of dir PATH."
  (let ((out '()))
    (maphash (lambda (p n)
               (when (and (not (string= p "/")) (string= (m-parent p) path))
                 (push (cons (m-name p)
                             (ecase (mnode-type n)
                               (:dir :directory) (:file :file) (:link :symlink)))
                       out)))
             *m*)
    out))
(defun m-has-children (path) (and (m-children path) t))

;; each model op returns :ok on success or :error on any failure
(defmacro defmop (name (&rest args) &body body)
  `(defun ,name ,args (block nil ,@body)))

(defmop m-mkdir (path)
  (unless (m-dir-p (m-parent path)) (return :error))
  (when (m-node path) (return :error))
  (setf (gethash path *m*) (make-mnode :type :dir)) :ok)

(defmop m-create (path)
  (unless (m-dir-p (m-parent path)) (return :error))
  (when (m-node path) (return :error))
  (setf (gethash path *m*) (make-mnode :type :file)) :ok)

(defmop m-ensure-file (path)
  (let ((n (m-node path)))
    (cond ((and n (eq (mnode-type n) :file)) n)
          (n :error)
          (t (unless (m-dir-p (m-parent path)) (return :error))
             (let ((nn (make-mnode :type :file))) (setf (gethash path *m*) nn) nn)))))

;; NB: an adjustable array's bytes past the fill-pointer are stale, and
;; adjust-array only zero-fills elements BEYOND the total capacity — so on any
;; GROW we must explicitly zero the newly exposed logical range [old, new), or a
;; hole would surface stale data (a real filesystem reads holes as zero).
(defun m-grow (data new)
  (let ((old (fill-pointer data)))
    (when (> new (array-total-size data)) (adjust-array data new))
    (setf (fill-pointer data) new)
    (fill data 0 :start old :end new)))

(defmop m-write (path bytes offset)
  (let ((n (m-ensure-file path)))
    (when (eq n :error) (return :error))
    (let* ((data (mnode-data n)) (end (+ offset (length bytes))))
      (when (> end (fill-pointer data)) (m-grow data end))
      (replace data bytes :start1 offset)
      :ok)))

(defmop m-truncate (path size)
  (let ((n (m-node path)))
    (unless (and n (eq (mnode-type n) :file)) (return :error))
    (let ((data (mnode-data n)))
      (if (< size (fill-pointer data)) (setf (fill-pointer data) size) (m-grow data size)))
    :ok))

(defmop m-unlink (path)
  (let ((n (m-node path)))
    (unless n (return :error))
    (when (eq (mnode-type n) :dir) (return :error))
    (remhash path *m*) :ok))

(defmop m-rmdir (path)
  (let ((n (m-node path)))
    (unless (and n (eq (mnode-type n) :dir)) (return :error))
    (when (string= path "/") (return :error))
    (when (m-has-children path) (return :error))
    (remhash path *m*) :ok))

(defmop m-link (old new)
  (let ((n (m-node old)))
    (unless n (return :error))
    (when (eq (mnode-type n) :dir) (return :error))
    (unless (m-dir-p (m-parent new)) (return :error))
    (when (m-node new) (return :error))
    (setf (gethash new *m*) n) :ok))          ; SAME object => hard link

(defun m-descendant-or-self (anc p)
  "True if path P is ANC itself or nested under ANC."
  (or (string= anc p)
      (and (<= (length anc) (length p))
           (string= anc (subseq p 0 (length anc)))
           (char= (char p (length anc)) #\/))))

(defmop m-rename (old new)
  (let ((on (m-node old)))
    (unless on (return :error))
    (unless (m-dir-p (m-parent new)) (return :error))
    (when (string= old new) (return :ok))
    (when (and (eq (mnode-type on) :dir) (m-descendant-or-self old new)) (return :error))
    (let ((dn (m-node new)))
      (when dn
        (let ((sdir (eq (mnode-type on) :dir)) (ddir (eq (mnode-type dn) :dir)))
          (cond ((and sdir ddir) (when (m-has-children new) (return :error)))
                ((or sdir ddir) (return :error))))))    ; cross-type
    ;; perform: move OLD (and, if a dir, its whole subtree) to NEW
    (let ((moves '()))
      (maphash (lambda (p n)
                 (when (m-descendant-or-self old p)
                   (push (list p n (concatenate 'string new (subseq p (length old)))) moves)))
               *m*)
      (remhash new *m*)                                 ; drop any victim
      (dolist (mv moves) (remhash (first mv) *m*))
      (dolist (mv moves) (setf (gethash (third mv) *m*) (second mv))))
    :ok))

;;; ---- run an op on both sides & compare success/failure ---------------------

(defun cab-status (thunk)
  "Run THUNK; :ok if it returns, :error if it signals a cabinet condition."
  (handler-case (progn (funcall thunk) :ok)
    (cab:cabinet-error () :error)))

(defun agree (name model-result cab-thunk)
  (let ((c (cab-status cab-thunk)))
    (check (eq model-result c) "~a: model=~a cabinet=~a" name model-result c)))

;;; ---- full-tree comparison --------------------------------------------------

(defun cab-walk (fs path acc)
  "Collect (path . node-summary) for PATH and everything under it into ACC."
  (let ((type (cab:file-type fs path)))
    (ecase type
      (:directory
       (unless (string= path "/") (setf (gethash path acc) :dir))
       (when (string= path "/") (setf (gethash "/" acc) :dir))
       (dolist (e (cab:readdir fs path))
         (cab-walk fs (if (string= path "/")
                          (concatenate 'string "/" (car e))
                          (concatenate 'string path "/" (car e)))
                   acc)))
      (:file (setf (gethash path acc) (cons :file (cab:read-file fs path))))
      (:symlink (setf (gethash path acc) (cons :link (cab:readlink fs path)))))
    acc))

(defun compare-tree (fs label)
  (let ((cabt (cab-walk fs "/" (make-hash-table :test 'equal))))
    ;; every model path present & equal in cabinet
    (maphash
     (lambda (p n)
       (let ((c (gethash p cabt 'missing)))
         (ecase (mnode-type n)
           (:dir (check (eq c :dir) "~a: ~a model=dir cabinet=~a" label p c))
           (:file (check (and (consp c) (eq (car c) :file)
                              (b= (cdr c) (mnode-data n)))
                         "~a: ~a file content mismatch (cab=~a)" label p
                         (if (consp c) (length (cdr c)) c)))
           (:link (check (and (consp c) (eq (car c) :link)) "~a: ~a link mismatch" label p)))))
     *m*)
    ;; and no extra paths in cabinet the model doesn't have
    (maphash (lambda (p c) (declare (ignore c))
               (check (gethash p *m*) "~a: cabinet has extra path ~a" label p))
             cabt)))

;;; ---- path generation -------------------------------------------------------

(defparameter *names* #("a" "b" "c" "d" "e"))
(defun rand-path ()
  (let ((depth (1+ (rnd 3))) (s ""))
    (dotimes (i depth s) (setf s (concatenate 'string s "/" (pick *names*))))))

;;; ---- the fuzz loop ---------------------------------------------------------

(defun fuzz (fs steps)
  (dotimes (i steps)
    (let ((op (rnd 11)) (p (rand-path)))
      (case op
        (0 (agree "mkdir"    (m-mkdir p)       (lambda () (cab:mkdir fs p))))
        (1 (agree "create"   (m-create p)      (lambda () (cab:create fs p))))
        (2 (let ((by (rand-bytes (rnd 200))) (off (rnd 300)))
             (agree "write"  (m-write p by off) (lambda () (cab:write-file fs p by :offset off)))))
        (3 (let ((sz (rnd 400)))
             (agree "trunc"  (m-truncate p sz) (lambda () (cab:truncate-file fs p sz)))))
        (4 (agree "unlink"   (m-unlink p)      (lambda () (cab:unlink fs p))))
        (5 (agree "rmdir"    (m-rmdir p)       (lambda () (cab:rmdir fs p))))
        (6 (let ((q (rand-path)))
             (agree "rename" (m-rename p q)    (lambda () (cab:rename fs p q)))))
        (7 (let ((q (rand-path)))
             (agree "link"   (m-link p q)      (lambda () (cab:link fs p q)))))
        ;; read-back probes: only when the model says it's a readable file
        (8 (let ((n (m-node p)))
             (when (and n (eq (mnode-type n) :file))
               (handler-case
                   (check (b= (cab:read-file fs p) (mnode-data n)) "read ~a mismatch" p)
                 (cab:cabinet-error () (check nil "read ~a signalled" p))))))
        (9 (when (m-dir-p p)
             (handler-case
                 (let ((cd (sort (cab:readdir fs p) #'string< :key #'car))
                       (md (sort (m-children p) #'string< :key #'car)))
                   (check (equal cd md) "readdir ~a: cab=~a model=~a" p cd md))
               (cab:cabinet-error () (check nil "readdir ~a signalled" p)))))
        (10 (let ((n (m-node p)))
              (when (and n (eq (mnode-type n) :file))
                (handler-case
                    (check (= (cab:file-size fs p) (fill-pointer (mnode-data n)))
                           "size ~a mismatch" p)
                  (cab:cabinet-error () (check nil "size ~a signalled" p))))))))
    (when (zerop (mod i 200)) (compare-tree fs "mid"))))

;;; ---- fixed unit checks -----------------------------------------------------

(defun s->b (s) (cabinet::string->utf8 s))

(defun unit-checks ()
  (let ((fs (cab:format-fs nil)))
    ;; symlink round trip
    (cab:symlink fs "/target/path" "/lnk")
    (check (string= (cab:readlink fs "/lnk") "/target/path") "readlink round trip")
    (check (eq (cab:file-type fs "/lnk") :symlink) "symlink type")
    ;; deep make-directories
    (cab:make-directories fs "/x/y/z/w")
    (check (eq (cab:file-type fs "/x/y/z/w") :directory) "make-directories deep")
    ;; large file spanning many blocks (block-size default 4096)
    (let ((big (rand-bytes 20000)))
      (cab:write-file fs "/x/big" big)
      (check (b= (cab:read-file fs "/x/big") big) "20KB multi-block round trip")
      (check (= (cab:file-size fs "/x/big") 20000) "20KB size"))
    ;; rename into own subtree is refused
    (check (eq :error (cab-status (lambda () (cab:rename fs "/x" "/x/y/loop"))))
           "rename dir into own subtree refused")
    ;; hard-link shares content
    (cab:write-file fs "/x/f1" (s->b "shared"))
    (cab:link fs "/x/f1" "/x/f2")
    (cab:write-file fs "/x/f2" (s->b "SHARED!") :offset 0)
    (check (b= (cab:read-file fs "/x/f1") (cab:read-file fs "/x/f2")) "hard link shares data")
    (cab:unmount fs)))

;;; ---- persistence round trip ------------------------------------------------

(defun persistence-check ()
  (let ((path "/tmp/cabinet-oracle.cab"))
    (ignore-errors (delete-file path))
    (m-init)
    (let ((fs (cab:format-fs path)))
      (fuzz fs 1500)
      (compare-tree fs "pre-remount")
      (cab:unmount fs))
    ;; reopen the very same file and re-compare against the (unchanged) model
    (let ((fs (cab:mount path)))
      (compare-tree fs "post-remount")
      (cab:unmount fs))
    (ignore-errors (delete-file path))))

;;; ---- entry point -----------------------------------------------------------

(defun run-tests ()
  (setf *checks* 0 *fails* 0 *seed* 88172645463325252)
  (format t "~&[cabinet differential oracle]~%")
  (format t "[fixed unit checks]~%")
  (unit-checks)
  (format t "[in-RAM fuzz, 4000 steps]~%")
  (m-init)
  (let ((fs (cab:format-fs nil)))
    (fuzz fs 4000)
    (compare-tree fs "final-mem")
    (cab:unmount fs))
  (format t "[persistence round trip: 1500 steps on a real file, unmount, remount]~%")
  (persistence-check)
  (format t "----------------------------------~%")
  (format t "checks: ~d   failures: ~d   => ~a~%" *checks* *fails*
          (if (zerop *fails*) "PASS" "FAIL"))
  (zerop *fails*))
