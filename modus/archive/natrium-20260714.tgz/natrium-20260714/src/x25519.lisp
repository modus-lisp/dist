;;;; x25519.lisp — X25519 Diffie-Hellman on Curve25519 (RFC 7748).
;;;;
;;;; Portable big-integer reference: field elements are CL integers reduced mod
;;;; p = 2^255-19.  This is NOT the public X25519 — the public, constant-time
;;;; path is the fe25519 limb ladder in x25519-ct.lisp.  This file is that
;;;; ladder's differential oracle: exact, gated against the RFC 7748 vectors, and
;;;; deliberately variable-time (the scalar is secret, so it must not guard real
;;;; keys).  It also defines the shared field constant/helpers (*p25519*,
;;;; fe-pow, fe-inv) that ed25519.lisp reuses.

(in-package #:natrium)

(defparameter *p25519* (- (ash 1 255) 19)
  "The Curve25519 field prime, 2^255 - 19.")

(defun fe-pow (base e)
  "BASE^E mod *p25519* by square-and-multiply (E public: only used for the fixed
   inversion exponent p-2)."
  (let ((p *p25519*) (result 1) (b (mod base *p25519*)))
    (loop while (> e 0) do
      (when (oddp e) (setf result (mod (* result b) p)))
      (setf b (mod (* b b) p) e (ash e -1)))
    result))

(defun fe-inv (z)
  "Multiplicative inverse of Z mod p = Z^(p-2)."
  (fe-pow z (- *p25519* 2)))

(defun x25519-reference (scalar u-bytes)
  "Big-integer reference X25519 (RFC 7748 5): the differential oracle for the
   constant-time fe25519 ladder (x25519-ct.lisp).  Variable-time; not for keys."
  (declare (type u8v scalar u-bytes))
  (let* ((p *p25519*)
         (k (let ((c (copy-seq scalar)))            ; clamp (does not mutate input)
              (setf (aref c 0)  (logand (aref c 0) 248)
                    (aref c 31) (logior (logand (aref c 31) 127) 64))
              (le->uint c 0 32)))
         (x1 (mod (logand (le->uint u-bytes 0 32) (1- (ash 1 255))) p)) ; mask bit 255
         (x2 1) (z2 0) (x3 x1) (z3 1) (swap 0))
    (macrolet ((f+ (a b) `(mod (+ ,a ,b) p))
               (f- (a b) `(mod (- ,a ,b) p))
               (f* (a b) `(mod (* ,a ,b) p))
               (fsq (a) `(let ((v ,a)) (mod (* v v) p)))
               (cswap (bit u w)                      ; branchless conditional swap
                 `(let ((dummy (logand (- ,bit) (logxor ,u ,w))))
                    (setf ,u (logxor ,u dummy) ,w (logxor ,w dummy)))))
      (loop for tt from 254 downto 0 do
        (let ((kt (logand (ash k (- tt)) 1)))
          (setf swap (logxor swap kt))
          (cswap swap x2 x3)
          (cswap swap z2 z3)
          (setf swap kt)
          (let* ((a  (f+ x2 z2)) (aa (fsq a))
                 (b  (f- x2 z2)) (bb (fsq b))
                 (e  (f- aa bb))
                 (c  (f+ x3 z3)) (d  (f- x3 z3))
                 (da (f* d a))   (cb (f* c b)))
            (setf x3 (fsq (f+ da cb))
                  z3 (f* x1 (fsq (f- da cb)))
                  x2 (f* aa bb)
                  z2 (f* e (f+ aa (f* 121665 e)))))))
      (cswap swap x2 x3)
      (cswap swap z2 z3)
      (uint->le (f* x2 (fe-inv z2)) 32))))
