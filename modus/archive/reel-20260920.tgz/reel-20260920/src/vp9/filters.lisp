;;;; vp9/filters.lisp — GENERATED (the three eight-tap filters) plus the bilinear one.
;;;;
;;;; A motion vector addresses eighths of a sample, and the sample at a fractional position is an
;;;; eight-tap filter of its neighbours.  VP9 has three such filters and a block chooses between
;;;; them: regular, sharp, and smooth.  That is unusual — most codecs have one — and it is there
;;;; because the right filter depends on the content: a sharp filter preserves detail and rings on
;;;; noise, a smooth one does the opposite.
;;;;
;;;; Sixteen phases each, of which the first is the identity: a whole-sample vector filters nothing.
;;;; The coefficients sum to 128, which is what makes the `+ 64) >> 7' at the end a rounded average
;;;; rather than a scaling.

(in-package #:reel.vp9)

(defparameter +subpel-filters+
  (make-array '(3 16 8) :element-type '(signed-byte 32) :initial-contents
   '(
    (  ; smooth
     (   0    0    0  128    0    0    0    0)
     (  -3   -1   32   64   38    1   -3    0)
     (  -2   -2   29   63   41    2   -3    0)
     (  -2   -2   26   63   43    4   -4    0)
     (  -2   -3   24   62   46    5   -4    0)
     (  -2   -3   21   60   49    7   -4    0)
     (  -1   -4   18   59   51    9   -4    0)
     (  -1   -4   16   57   53   12   -4   -1)
     (  -1   -4   14   55   55   14   -4   -1)
     (  -1   -4   12   53   57   16   -4   -1)
     (   0   -4    9   51   59   18   -4   -1)
     (   0   -4    7   49   60   21   -3   -2)
     (   0   -4    5   46   62   24   -3   -2)
     (   0   -4    4   43   63   26   -2   -2)
     (   0   -3    2   41   63   29   -2   -2)
     (   0   -3    1   38   64   32   -1   -3)
     )
    (  ; regular
     (   0    0    0  128    0    0    0    0)
     (   0    1   -5  126    8   -3    1    0)
     (  -1    3  -10  122   18   -6    2    0)
     (  -1    4  -13  118   27   -9    3   -1)
     (  -1    4  -16  112   37  -11    4   -1)
     (  -1    5  -18  105   48  -14    4   -1)
     (  -1    5  -19   97   58  -16    5   -1)
     (  -1    6  -19   88   68  -18    5   -1)
     (  -1    6  -19   78   78  -19    6   -1)
     (  -1    5  -18   68   88  -19    6   -1)
     (  -1    5  -16   58   97  -19    5   -1)
     (  -1    4  -14   48  105  -18    5   -1)
     (  -1    4  -11   37  112  -16    4   -1)
     (  -1    3   -9   27  118  -13    4   -1)
     (   0    2   -6   18  122  -10    3   -1)
     (   0    1   -3    8  126   -5    1    0)
     )
    (  ; sharp
     (   0    0    0  128    0    0    0    0)
     (  -1    3   -7  127    8   -3    1    0)
     (  -2    5  -13  125   17   -6    3   -1)
     (  -3    7  -17  121   27  -10    5   -2)
     (  -4    9  -20  115   37  -13    6   -2)
     (  -4   10  -23  108   48  -16    8   -3)
     (  -4   10  -24  100   59  -19    9   -3)
     (  -4   11  -24   90   70  -21   10   -4)
     (  -4   11  -23   80   80  -23   11   -4)
     (  -4   10  -21   70   90  -24   11   -4)
     (  -3    9  -19   59  100  -24   10   -4)
     (  -3    8  -16   48  108  -23   10   -4)
     (  -2    6  -13   37  115  -20    9   -4)
     (  -2    5  -10   27  121  -17    7   -3)
     (  -1    3   -6   17  125  -13    5   -2)
     (   0    1   -3    8  127   -7    3   -1)
     )
))
  "[filter][phase][tap].  The filters are in the order the bitstream numbers them — smooth, regular,
   sharp — which is not the order ffmpeg declares them in.")

;;; ---- and a fourth, which is not an eight-tap filter at all ---------------------------------------
;;;
;;; A FOURTH INTERPOLATION FILTER EXISTS and this file said for a long time that there were three.
;;; BILINEAR is a two-tap linear blend padded out to eight taps so that one piece of code serves all
;;; four — phase k weights the two samples either side by 128-8k and 8k.  Encoders reach for it at
;;; very low bit rates and in speed-oriented modes, so no ordinary encode contains one and the
;;; omission survived a corpus of seven clips decoding bit-exact.  The official conformance vector
;;; vp90-2-06-bilinear is what found it.
;;;
;;; It is generated rather than transcribed because it is arithmetic, not a table.

(defparameter +subpel-filters-all+
  (let ((all (make-array '(4 16 8) :element-type '(signed-byte 32) :initial-element 0)))
    (dotimes (f 3)
      (dotimes (p 16)
        (dotimes (tap 8)
          (setf (aref all f p tap) (aref +subpel-filters+ f p tap)))))
    (dotimes (p 16)
      (setf (aref all 3 p 3) (- 128 (* 8 p))
            (aref all 3 p 4) (* 8 p)))
    all)
  "The three eight-tap filters, and bilinear as the fourth.")
(declaim (type (simple-array (signed-byte 32) (4 16 8)) +subpel-filters-all+))

(declaim (type (simple-array (signed-byte 32) (3 16 8)) +subpel-filters+))
