;;;; vp9/tables.lisp — GENERATED.  VP9's constant tables.
;;;;
;;;; Extracted mechanically from ffmpeg's transcription of the normative tables, with the symbolic
;;;; entries resolved from ffmpeg's own enumerations rather than retyped.  Each table is checked
;;;; against a property the format guarantees: the quantiser lookups are non-decreasing, and every
;;;; tree is binary, complete and acyclic — each node reachable exactly once from the root, and every
;;;; internal branch pointing FORWARD, which is what makes a tree readable in one pass with no stack.

(in-package #:reel.vp9)


;;; ---- the quantiser ------------------------------------------------------------------------------
;;;
;;; VP9 sends a quantiser INDEX and looks the step size up, separately for DC and AC and separately
;;; for luma and chroma.  Index zero is lossless and is treated as such — a picture at index zero
;;; skips the transform entirely and codes the residual with a Walsh-Hadamard instead.

(defparameter +dc-qlookup+
  (make-array 256 :element-type '(unsigned-byte 16) :initial-contents
   '(
       4    8    8    9   10   11   12   12   13   14   15   16   17   18   19   19
      20   21   22   23   24   25   26   26   27   28   29   30   31   32   32   33
      34   35   36   37   38   38   39   40   41   42   43   43   44   45   46   47
      48   48   49   50   51   52   53   53   54   55   56   57   57   58   59   60
      61   62   62   63   64   65   66   66   67   68   69   70   70   71   72   73
      74   74   75   76   77   78   78   79   80   81   81   82   83   84   85   85
      87   88   90   92   93   95   96   98   99  101  102  104  105  107  108  110
     111  113  114  116  117  118  120  121  123  125  127  129  131  134  136  138
     140  142  144  146  148  150  152  154  156  158  161  164  166  169  172  174
     177  180  182  185  187  190  192  195  199  202  205  208  211  214  217  220
     223  226  230  233  237  240  243  247  250  253  257  261  265  269  272  276
     280  284  288  292  296  300  304  309  313  317  322  326  330  335  340  344
     349  354  359  364  369  374  379  384  389  395  400  406  411  417  423  429
     435  441  447  454  461  467  475  482  489  497  505  513  522  530  539  549
     559  569  579  590  602  614  626  640  654  668  684  700  717  736  755  775
     796  819  843  869  896  925  955  988 1022 1058 1098 1139 1184 1232 1282 1336
))
  "DC step size for each of the 256 quantiser indices, at eight bits per sample.")

(defparameter +ac-qlookup+
  (make-array 256 :element-type '(unsigned-byte 16) :initial-contents
   '(
       4    8    9   10   11   12   13   14   15   16   17   18   19   20   21   22
      23   24   25   26   27   28   29   30   31   32   33   34   35   36   37   38
      39   40   41   42   43   44   45   46   47   48   49   50   51   52   53   54
      55   56   57   58   59   60   61   62   63   64   65   66   67   68   69   70
      71   72   73   74   75   76   77   78   79   80   81   82   83   84   85   86
      87   88   89   90   91   92   93   94   95   96   97   98   99  100  101  102
     104  106  108  110  112  114  116  118  120  122  124  126  128  130  132  134
     136  138  140  142  144  146  148  150  152  155  158  161  164  167  170  173
     176  179  182  185  188  191  194  197  200  203  207  211  215  219  223  227
     231  235  239  243  247  251  255  260  265  270  275  280  285  290  295  300
     305  311  317  323  329  335  341  347  353  359  366  373  380  387  394  401
     408  416  424  432  440  448  456  465  474  483  492  501  510  520  530  540
     550  560  571  582  593  604  615  627  639  651  663  676  689  702  715  729
     743  757  771  786  801  816  832  848  864  881  898  915  933  951  969  988
    1007 1026 1046 1066 1087 1108 1129 1151 1173 1196 1219 1243 1267 1292 1317 1343
    1369 1396 1423 1451 1479 1508 1537 1567 1597 1628 1660 1692 1725 1759 1793 1828
))
  "And the AC step size, which grows faster: the eye forgives a coarse high frequency and does not
   forgive a coarse average.")

(defparameter +block-size-wh+
  (make-array '(2 13 2) :element-type '(unsigned-byte 8) :initial-contents
   '(
    (
     (16 16)
     (16  8)
     ( 8 16)
     ( 8  8)
     ( 8  4)
     ( 4  8)
     ( 4  4)
     ( 4  2)
     ( 2  4)
     ( 2  2)
     ( 2  1)
     ( 1  2)
     ( 1  1)
     )
    (
     ( 8  8)
     ( 8  4)
     ( 4  8)
     ( 4  4)
     ( 4  2)
     ( 2  4)
     ( 2  2)
     ( 2  1)
     ( 1  2)
     ( 1  1)
     ( 1  1)
     ( 1  1)
     ( 1  1)
     )
))
  "Width and height of each of the thirteen block sizes, in samples for luma and again for the
   chroma of a 4:2:0 picture.  VP9's partition sizes are not square: 64x32 and 32x64 and every
   other rectangle down to 4x4, which is why this is a table and not a shift.")


;;; ---- the trees ----------------------------------------------------------------------------------
;;;
;;; A VP9 tree is a flat array of (left right) pairs.  A STRICTLY POSITIVE entry is the index of the
;;; next node; anything else is the NEGATED symbol.  That the test is `> 0' and not `>= 0' is the
;;; whole of the encoding: node zero is the root and is therefore never a branch target, which frees
;;; the value zero to mean symbol zero.  Reading it wrong turns the first symbol of several trees
;;; into an infinite loop rather than a wrong answer, which is at least loud.

(defparameter +partition-tree+
  (make-array '(3 2) :element-type '(signed-byte 32) :initial-contents
   '(
     (  0   1)
     ( -1   2)
     ( -2  -3)
     ))
  "How a block is split: not at all, into two across, into two down, or into four.")

(defparameter +segmentation-tree+
  (make-array '(7 2) :element-type '(signed-byte 32) :initial-contents
   '(
     (  1   2)
     (  3   4)
     (  5   6)
     (  0  -1)
     ( -2  -3)
     ( -4  -5)
     ( -6  -7)
     ))
  "Which of the eight segments a block belongs to.")

(defparameter +intramode-tree+
  (make-array '(9 2) :element-type '(signed-byte 32) :initial-contents
   '(
     ( -2   1)
     ( -9   2)
     (  0   3)
     (  4   6)
     ( -1   5)
     ( -4  -5)
     ( -3   7)
     ( -7   8)
     ( -6  -8)
     ))
  "The ten intra prediction modes, in the order their codes are assigned.")

(defparameter +inter-mode-tree+
  (make-array '(3 2) :element-type '(signed-byte 32) :initial-contents
   '(
     (-12   1)
     (-10   2)
     (-11 -13)
     ))
  "Zero motion, the nearest predictor, the next nearest, or a coded vector.  The
   symbols are absolute values of ffmpeg's mode enumeration, which numbers the inter modes after
   the ten intra ones, so subtract ten to index anything counted from NEARESTMV.")

(defparameter +filter-tree+
  (make-array '(2 2) :element-type '(signed-byte 32) :initial-contents
   '(
     (  0   1)
     ( -1  -2)
     ))
  "Which of the three eight-tap interpolation filters this block uses.")

(defparameter +mv-joint-tree+
  (make-array '(3 2) :element-type '(signed-byte 32) :initial-contents
   '(
     (  0   1)
     ( -1   2)
     ( -2  -3)
     ))
  "Which components of a motion vector are non-zero: neither, one, the other, or both.")

(defparameter +mv-class-tree+
  (make-array '(10 2) :element-type '(signed-byte 32) :initial-contents
   '(
     (  0   1)
     ( -1   2)
     (  3   4)
     ( -2  -3)
     (  5   6)
     ( -4  -5)
     ( -6   7)
     (  8   9)
     ( -7  -8)
     ( -9 -10)
     ))
  "The magnitude class of a vector component: a coarse logarithmic bucket, refined by
   bits that follow.")

(defparameter +mv-fp-tree+
  (make-array '(3 2) :element-type '(signed-byte 32) :initial-contents
   '(
     (  0   1)
     ( -1   2)
     ( -2  -3)
     ))
  "The fractional part of a vector component, in eighths.")

(declaim (type (simple-array (unsigned-byte 16) (256)) +dc-qlookup+ +ac-qlookup+))
(declaim (type (simple-array (unsigned-byte 8) (2 13 2)) +block-size-wh+))
