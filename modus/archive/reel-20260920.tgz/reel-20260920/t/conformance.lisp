;;;; t/conformance.lisp — the decoders against the formats' own conformance suites.
;;;;
;;;; Every fixture in this repository and in cassette's is something ffmpeg, x264 or libvpx
;;;; produced, and a mainstream encoder uses a narrow slice of the standard it implements.  Passing
;;;; those is a weaker claim than it looks.  This runs the official suites instead.
;;;;
;;;; TWO THINGS ABOUT THE ORACLE, both learned the hard way here.  Generate the reference decodes
;;;; with `-fps_mode passthrough' or ffmpeg duplicates frames to a constant rate and every
;;;; comparison after the first repeat is nonsense.  And do not compute a frame count as
;;;; size / (width * height * 3/2): VP9 changes picture size from frame to frame, so a reference
;;;; decode is not a stack of equal-sized pictures.  Walk it picture by picture, using each
;;;; picture's own length, which is what the code below does.
;;;;
;;;;   t/fetch-conformance.sh && sbcl --dynamic-space-size 8192 \
;;;;     --non-interactive --load t/conformance.lisp
(require :asdf)
(push (truename "../cassette/") asdf:*central-registry*)
(push (truename "../reed/") asdf:*central-registry*)
(asdf:load-asd (merge-pathnames "reel.asd" (or *load-truename* *default-pathname-defaults*)))
(handler-bind ((warning #'muffle-warning)) (asdf:load-system :cassette))

(defpackage #:reel-conformance (:use #:cl)) (in-package #:reel-conformance)

(defvar *conf* (or (sb-posix:getenv "CONF") "/tmp/conf"))

(defun slurp (p)
  (with-open-file (s p :element-type '(unsigned-byte 8))
    (let ((b (make-array (file-length s) :element-type '(unsigned-byte 8))))
      (read-sequence b s) b)))

(defun compare-pictures (pictures oracle)
  "PICTURES is a list of I420 vectors in output order.  Returns (values exact total first-bad)."
  (let ((n 0) (exact 0) (off 0) (bad nil))
    (dolist (y pictures (values exact n bad))
      (incf n)
      (cond ((> (+ off (length y)) (length oracle))
             (unless bad (setf bad "output runs past the reference")))
            ((loop for i below (length y) always (= (aref y i) (aref oracle (+ off i))))
             (incf exact))
            (t (unless bad (setf bad (format nil "picture ~d" n)))))
      (incf off (length y)))))

;;; ---- VP8: the seventeen official libvpx vectors, read straight out of IVF -------------------------

(defun ivf-frames (bytes)
  (let ((p (logior (aref bytes 6) (ash (aref bytes 7) 8))) (out '()))
    (loop while (<= (+ p 12) (length bytes))
          do (let ((sz (logior (aref bytes p) (ash (aref bytes (+ p 1)) 8)
                               (ash (aref bytes (+ p 2)) 16) (ash (aref bytes (+ p 3)) 24))))
               (when (> (+ p 12 sz) (length bytes)) (return))
               (push (subseq bytes (+ p 12) (+ p 12 sz)) out)
               (incf p (+ 12 sz))))
    (nreverse out)))

(defun run-vp8 ()
  (let ((pass 0) (fail 0))
    (dolist (f (sort (directory (format nil "~a/vp8/*.ivf" *conf*)) #'string< :key #'namestring))
      (let ((ref (probe-file (format nil "~a.ref.yuv" (namestring f)))))
        (handler-case
            (let ((d (reel.decode:make-decoder)) (pics '()))
              (dolist (pk (ivf-frames (slurp f)))
                (multiple-value-bind (pic shown) (reel.decode:decode-frame d pk)
                  (when (and shown pic) (push (reel.decode:picture->yuv420 pic) pics))))
              (multiple-value-bind (exact n bad) (compare-pictures (nreverse pics)
                                                                  (if ref (slurp ref) #()))
                (if (and (plusp n) (= exact n) (null bad))
                    (progn (incf pass) (format t "~&  ok   ~a: ~d frames~%" (pathname-name f) n))
                    (progn (incf fail)
                           (format t "~&  FAIL ~a: ~d of ~d~@[, first bad: ~a~]~%"
                                   (pathname-name f) exact n bad)))))
          (error (e) (incf fail) (format t "~&  FAIL ~a: ~a~%" (pathname-name f) e)))))
    (format t "~&VP8: ~d passed, ~d failed~%" pass fail)
    fail))

;;; ---- VP9: the official feature vectors, through the container ------------------------------------

(defun run-vp9 ()
  (let ((pass 0) (fail 0) (refused 0))
    (dolist (f (sort (directory (format nil "~a/vp9/*.webm" *conf*)) #'string< :key #'namestring))
      (let ((ref (probe-file (format nil "~a.ref.yuv" (namestring f)))))
        (handler-case
            (let ((p (cassette:open-media f :audio nil)) (pics '()))
              (loop for pic = (cassette:next-video-frame p) while pic
                    do (push (cassette:picture->yuv420 pic) pics))
              (multiple-value-bind (exact n bad) (compare-pictures (nreverse pics)
                                                                  (if ref (slurp ref) #()))
                (if (and (plusp n) (= exact n) (null bad))
                    (progn (incf pass) (format t "~&  ok   ~a: ~d pictures~%" (pathname-name f) n))
                    (progn (incf fail)
                           (format t "~&  FAIL ~a: ~d of ~d~@[, first bad: ~a~]~%"
                                   (pathname-name f) exact n bad)))))
          ;; profiles 1, 2 and 3 are refused by name and that is the right answer, not a failure
          (reel.vp9::vp9-error (e) (incf refused)
            (format t "~&  --   ~a: refused — ~a~%" (pathname-name f) e))
          (error (e) (incf fail) (format t "~&  FAIL ~a: ~a~%" (pathname-name f) e)))))
    (format t "~&VP9: ~d passed, ~d failed, ~d correctly refused~%" pass fail refused)
    fail))

;;; ---- H.264: a spread of the JVT conformance streams ----------------------------------------------

(defun run-h264 ()
  (let ((pass 0) (fail 0) (refused 0))
    (dolist (f (sort (append (directory (format nil "~a/h264/*.264" *conf*))
                             (directory (format nil "~a/h264/*.jsv" *conf*)))
                     #'string< :key #'namestring))
      (let ((ref (probe-file (format nil "~a.ref.yuv" (namestring f)))))
        (handler-case
            (let ((pics (mapcar #'reel.h264:picture->yuv420
                                (reel.h264:decode-annex-b (slurp f)))))
              (multiple-value-bind (exact n bad) (compare-pictures pics (if ref (slurp ref) #()))
                (if (and (plusp n) (= exact n) (null bad))
                    (progn (incf pass) (format t "~&  ok   ~a: ~d pictures~%" (file-namestring f) n))
                    (progn (incf fail)
                           (format t "~&  FAIL ~a: ~d of ~d~@[, first bad: ~a~]~%"
                                   (file-namestring f) exact n bad)))))
          (reel.h264::h264-error (e) (incf refused)
            (format t "~&  --   ~a: refused — ~a~%" (file-namestring f) e))
          (error (e) (incf fail) (format t "~&  FAIL ~a: ~a~%" (file-namestring f) e)))))
    (format t "~&H.264: ~d passed, ~d failed, ~d refused~%" pass fail refused)
    fail))

;;; ---- HEVC: the JCT-VC conformance streams, headers only for now -------------------------------
;;;
;;; The decoder is still being built and reads no pictures yet, so what can be checked is what the
;;; parser claims about a stream's geometry against what ffprobe says it is.  That is a real test
;;; and not a placeholder: the sequence parameter set declares the coding tree size, the quadtree
;;; depths and the conformance window, and getting any of them wrong moves the picture size.  A
;;; stream this cannot parse at all is a FAILURE; one it refuses by naming a tool is not.

(defun %hevc-first-picture (f spss ppss)
  "Decode F's first picture, if it is entirely intra.  Returns (values picture reason).

   Comparing this against ffmpeg is what the tiling check was standing in for: the whole pipeline —
   prediction, dequantisation, both transforms, deblocking and sample adaptive offset — either
   agrees to the sample or it does not."
  (let ((pic nil) (done nil) (why nil) (last-sh nil))
    (handler-case
        (dolist (nal (reel.hevc:annex-b-nals (slurp f)))
          (when (and (reel.hevc:nal-base-layer-p nal) (not done))
            (cond
              ((= (reel.hevc::nal-type nal) reel.hevc::+nal-sps+)
               (let ((sp (reel.hevc:parse-sps (reel.hevc:nal-rbsp nal))))
                 (setf (gethash (reel.hevc:sps-id sp) spss) sp)))
              ((= (reel.hevc::nal-type nal) reel.hevc::+nal-pps+)
               (let ((pp (reel.hevc:parse-pps (reel.hevc:nal-rbsp nal))))
                 (setf (gethash (reel.hevc:pps-id pp) ppss) pp)))
              ((reel.hevc:nal-slice-p nal)
               (let* ((br (reel.hevc:make-bitreader (reel.hevc:nal-rbsp nal)))
                      (sh (reel.hevc:parse-slice-header br nal spss ppss)))
                 (cond
                   ((and pic (reel.hevc:sh-first-in-pic sh)) (setf done t))
                   ((not (reel.hevc:sh-i-slice-p sh))
                    (setf why "the first picture is not all intra" done t pic nil))
                   (t (unless pic
                        (setf pic (reel.hevc:make-picture-for (reel.hevc::sh-sps sh))))
                      (setf last-sh sh)
                      (reel.hevc:decode-slice-data (reel.hevc::sh-sps sh)
                                                   (reel.hevc::sh-pps sh) sh br pic))))))))
      (reel.hevc:hevc-error (e) (setf why (reel.hevc:hevc-error-message e) pic nil)))
    ;; the in-loop filters run over the finished picture, every vertical edge before any
    ;; horizontal one and SAO after all of them
    (when pic
      (reel.hevc:deblock-picture pic (reel.hevc::sh-pps last-sh) last-sh)
      (reel.hevc:sao-picture pic last-sh))
    (values pic why)))

(defun %hevc-intra-pictures (f spss ppss)
  "Decode the slice data of every ALL-INTRA picture in F.  Returns (values checked good reason).

   The property being checked is that a picture's slice segments TILE it: each one stops on its own
   end_of_slice_segment_flag, and together they cover every coding tree unit exactly once.  Nothing
   is reconstructed yet, so this is what stands in for a picture — and it is not a weak stand-in,
   because a single misread syntax element desynchronises the arithmetic decoder and a
   desynchronised decoder does not stop in the right place."
  (let ((pics 0) (good 0) (why nil) (refusal nil)
        (any nil) (inter nil) (covered 0) (broke nil) (total 0))
    (labels ((finish ()
               ;; a picture with a P or B slice in it is not something this can decode yet, so it
               ;; is not counted either way
               (when (and any (not inter))
                 (incf pics)
                 (if (and (not broke) (= covered total))
                     (incf good)
                     (unless why (setf why (format nil "covered ~d of ~d CTBs" covered total)))))
               (setf any nil inter nil covered 0 broke nil)))
      (dolist (nal (reel.hevc:annex-b-nals (slurp f)))
        (when (reel.hevc:nal-base-layer-p nal)
          (cond
            ((= (reel.hevc::nal-type nal) reel.hevc::+nal-sps+)
             (let ((sp (reel.hevc:parse-sps (reel.hevc:nal-rbsp nal))))
               (setf (gethash (reel.hevc:sps-id sp) spss) sp)))
            ((= (reel.hevc::nal-type nal) reel.hevc::+nal-pps+)
             (let ((pp (reel.hevc:parse-pps (reel.hevc:nal-rbsp nal))))
               (setf (gethash (reel.hevc:pps-id pp) ppss) pp)))
            ((reel.hevc:nal-slice-p nal)
             (let* ((br (reel.hevc:make-bitreader (reel.hevc:nal-rbsp nal)))
                    (sh (reel.hevc:parse-slice-header br nal spss ppss)))
               (when (reel.hevc:sh-first-in-pic sh) (finish))
               (setf total (reel.hevc:sps-ctbs (reel.hevc::sh-sps sh)) any t)
               (if (not (reel.hevc:sh-i-slice-p sh))
                   (setf inter t)
                   (handler-case
                       (multiple-value-bind (c n term)
                           (reel.hevc:decode-slice-data (reel.hevc::sh-sps sh)
                                                        (reel.hevc::sh-pps sh) sh br)
                         (declare (ignore c))
                         (if term (incf covered n) (setf broke t)))
                     ;; a refusal names a tool this does not implement; it is not a wrong answer
                     (reel.hevc:hevc-error (e)
                       (setf broke t)
                       (unless refusal (setf refusal (reel.hevc:hevc-error-message e))))))))))) 
      (finish))
    (values pics good (or refusal why) (and refusal t))))

(defun run-hevc ()
  (let ((pass 0) (fail 0) (refused 0) (intra-ok 0) (exact 0))
    (dolist (f (sort (directory (format nil "~a/hevc/*.bit" *conf*)) #'string< :key #'namestring))
      (let ((dims (probe-file (format nil "~a.dims" (namestring f)))))
        (handler-case
            (let ((spss (make-hash-table)) (ppss (make-hash-table))
                  (w 0) (h 0) (slices 0))
              (dolist (n (reel.hevc:annex-b-nals (slurp f)))
                ;; an enhancement layer is not ours to decode; Annex F says discard it
                (when (reel.hevc:nal-base-layer-p n)
                  (cond
                    ((= (reel.hevc::nal-type n) reel.hevc::+nal-sps+)
                     (let ((sp (reel.hevc:parse-sps (reel.hevc:nal-rbsp n))))
                       (setf (gethash (reel.hevc:sps-id sp) spss) sp
                             w (reel.hevc:sps-display-width sp)
                             h (reel.hevc:sps-display-height sp))))
                    ((= (reel.hevc::nal-type n) reel.hevc::+nal-pps+)
                     (let ((pp (reel.hevc:parse-pps (reel.hevc:nal-rbsp n))))
                       (setf (gethash (reel.hevc:pps-id pp) ppss) pp)))
                    ((reel.hevc:nal-slice-p n)
                     (reel.hevc:parse-slice-header
                      (reel.hevc:make-bitreader (reel.hevc:nal-rbsp n)) n spss ppss)
                     (incf slices)))))
              (let ((want (and dims (with-open-file (s dims) (read-line s nil "")))))
                (cond ((zerop slices)
                       (incf fail)
                       (format t "~&  FAIL ~a: no slice headers~%" (pathname-name f)))
                      ((and want (string/= want (format nil "~dx~d" w h)))
                       (incf fail)
                       (format t "~&  FAIL ~a: parsed ~dx~d, ffprobe says ~a~%"
                               (pathname-name f) w h want))
                      (t
                       ;; the headers agree; now decode the slice data of the all-intra pictures
                       (multiple-value-bind (pics good why refused-p)
                           (%hevc-intra-pictures f (make-hash-table) (make-hash-table))
                         (incf intra-ok good)
                         (cond
                           ((and (plusp pics) (< good pics))
                            (if refused-p
                                (progn (incf refused)
                                       (format t "~&  --   ~a: refused — ~a~%"
                                               (pathname-name f) why))
                                (progn (incf fail)
                                       (format t "~&  FAIL ~a: ~d of ~d intra pictures~@[ — ~a~]~%"
                                               (pathname-name f) good pics why))))
                           ;; the syntax ends where it should; now the SAMPLES, against ffmpeg
                           (t
                            (let ((refp (probe-file (format nil "~a.filt.yuv" (namestring f))))
                                  (pic (%hevc-first-picture f (make-hash-table)
                                                            (make-hash-table))))
                              (cond
                                ((or (null refp) (null pic)) (incf pass))
                                (t (let ((mine (reel.hevc:picture->yuv420 pic))
                                         (ref (slurp refp)))
                                     (cond
                                       ((/= (length mine) (length ref))
                                        (incf fail)
                                        (format t "~&  FAIL ~a: ~d sample bytes, reference ~d~%"
                                                (pathname-name f) (length mine) (length ref)))
                                       ((loop for i below (length mine)
                                              always (= (aref mine i) (aref ref i)))
                                        (incf pass) (incf exact))
                                       (t (incf fail)
                                          (format t "~&  FAIL ~a: not bit-exact~%"
                                                  (pathname-name f)))))))))))))))
          (reel.hevc:hevc-error (e) (incf refused)
            (format t "~&  --   ~a: refused — ~a~%" (pathname-name f) e))
          (error (e) (incf fail) (format t "~&  FAIL ~a: ~a~%" (pathname-name f) e)))))
    (format t "~&HEVC: ~d streams parsed with the geometry ffprobe reports, ~d failed, ~d refused~%"
            pass fail refused)
    (format t "      ~d all-intra pictures parse to exactly the right end~%" intra-ok)
    (format t "      ~d first pictures reconstruct BIT-EXACTLY against ffmpeg~%" exact)
    fail))

(let ((bad 0))
  (format t "~&== VP8, the official libvpx vectors~%")   (incf bad (run-vp8))
  (format t "~&== VP9, the official feature vectors~%")  (incf bad (run-vp9))
  (format t "~&== H.264, a spread of the JVT streams~%") (incf bad (run-h264))
  (format t "~&== HEVC, the JCT-VC streams (headers)~%")  (incf bad (run-hevc))
  (format t "~&~:[CONFORMANCE OK~;CONFORMANCE: ~:*~d streams decode incorrectly~]~%"
          (if (plusp bad) bad nil)))
