;;;; src/threadsafe.lisp — the public entry points bind their own scratch.
;;;;
;;;; The limb backend keeps its working buffers in module-level specials for
;;;; speed.  WITH-FRESH-SCRATCH and WITH-FRESH-CT-SCRATCH rebind them per
;;;; thread — but until now only a caller who KNEW to wrap got that protection,
;;;; and a caller who forgot got results that were wrong in a way nothing
;;;; flagged: the point at infinity, or a valid-looking point that is not the
;;;; one asked for.  cl-payments hit exactly that the first time two of its
;;;; daemons ran in one process and derived keys on several threads at once.
;;;;
;;;; So the entry points wrap themselves.  Loaded last, this file replaces each
;;;; one with a version that binds fresh scratch around the original.  Nested
;;;; binding (a wrapped caller calling a wrapped callee) costs a few allocations
;;;; and is otherwise harmless; NOT binding costs correctness.  The macros stay
;;;; exported for callers who want one binding around a long batch instead of
;;;; one per call.

(in-package #:secp256k1-fast)

(defmacro %self-protecting (name lambda-list)
  "Replace NAME's definition with one that binds fresh scratch around it."
  (let ((inner (gensym "INNER")))
    `(let ((,inner (fdefinition ',name)))
       (setf (fdefinition ',name)
             (lambda ,lambda-list
               (with-fresh-ct-scratch (funcall ,inner ,@lambda-list)))))))

(%self-protecting secp-mul-point (k p))
(%self-protecting ct-mul-g (k))
(%self-protecting secp-pubkey (privkey))
(%self-protecting secp-inv-mod (a m))
(%self-protecting ecdsa-sign-raw (privkey-int hash-bytes))
(%self-protecting ecdsa-verify (pubkey-pt hash-bytes r s))
;; The double-scalar multiplication behind signature verification, and the
;; Schnorr entry points built on it.  cl-deposits found this one: a relay reader
;; thread verifying Nostr event signatures while a worker verified ledger
;; cosignatures made valid signatures fail, intermittently, in one process.
(%self-protecting secp-mul-2 (k1 p1 k2 p2))
(let ((inner (fdefinition 'secp256k1-fast.schnorr:schnorr-sign)))
  (setf (fdefinition 'secp256k1-fast.schnorr:schnorr-sign)
        (lambda (privkey-int msg32 &optional (aux nil aux-p))
          (with-fresh-ct-scratch
            (if aux-p (funcall inner privkey-int msg32 aux) (funcall inner privkey-int msg32))))))
(%self-protecting secp256k1-fast.schnorr:schnorr-verify (pubkey32 msg32 sig64))
(%self-protecting secp256k1-fast.schnorr:pubkey-xonly (privkey-int))

;; The affine point and field entry points.  cl-deposits found these: a node
;; building a taproot output (lift_x, then an affine add of t*G) on its worker
;; thread while the relay reader verified signatures got a valid-looking but
;; wrong output key, so quorum members disagreed on their own reserves script.
(%self-protecting secp-add-points (p1 p2))
(%self-protecting secp-double (p))
(%self-protecting secp-on-curve-p (p))
(%self-protecting secp-inv (a))          ; the limb-backend inverse, under every affine op
(%self-protecting secp256k1-fast.schnorr:lift-x (x))
(%self-protecting ct-nmul (a b))       ; Montgomery scalar multiply: shares *mont-scratch*
