;;;; present.lisp — projections, and the layout that gives them extents.
;;;;
;;;; PRESENT dispatches on (object, type, view) — the CLIM signature everyone forgets, and the seam
;;;; that makes "every view is an inspector" true as the DEGENERATE case rather than as an
;;;; architecture.  The default method walks slots via the MOP, so any new type in the image is
;;;; immediately browsable with zero UI code; designing a UI means specializing PRESENT for a
;;;; (type, view) pair.  Reads are projections here; writes are commands (command.lisp).
;;;;
;;;; PRESENT returns CONTENT, not pixels — a list of cells.  Layout then assigns extents and builds
;;;; the presentations.  Keeping them apart is what lets the content double as the FINGERPRINT: the
;;;; diff compares what the view derived its appearance from, never a closure.

(in-package #:warp)

(defgeneric present (object type view)
  (:documentation "Project OBJECT as TYPE into VIEW.  Returns a list of cells (strings or
(string . tag) pairs).  The default method is a MOP slot walk."))

;;; Enumerating a class's slots is the MOP's job, and the MOP is not ANSI.  SBCL has SB-MOP; a host
;;; that does not must never even READ `sb-mop:', because an absent package is a READER error — it
;;; happens before load, so no runtime test can guard it.  Hence #+/#- around the whole walk rather
;;; than a feature check inside it.  On SBCL this is exactly the code that was here.
;;;
;;; The test is for the SURFACE, not the vendor: modus supplies SB-MOP over its own metaobjects and
;;; pushes :SB-MOP (it does not claim :SBCL, and should not).  SBCL does not push :SB-MOP, so
;;; neither feature alone is the question — `(or sbcl sb-mop)' is.
#+(or sbcl sb-mop)
(defun %slot-cells (object class)
  (mapcar (lambda (sd)
            (let ((name (sb-mop:slot-definition-name sd)))
              (format nil "~(~a~): ~a" name
                      (if (slot-boundp object name)
                          (slot-value object name)
                          "#<unbound>"))))
          (sb-mop:class-slots class)))

#-(or sbcl sb-mop)
(defun %slot-cells (object class)
  "No MOP here: the default inspector degrades to the class name rather than refusing to load.
   A host that wants the slots back specializes PRESENT, which is what DESIGN.md asks for anyway."
  (declare (ignore object class))
  '())

(defmethod present (object type view)
  "The inspector, as a default: every slot, in definition order.  Legible, not designed — which is
exactly the trade named in DESIGN.md.  Specialize to design."
  (declare (ignorable type view))
  (let ((class (class-of object)))
    (cons (format nil "~a" (class-name class))
          (%slot-cells object class))))

;;; ---- layout ----------------------------------------------------------------
;;; A vertical list, which is client one's shape and the shape that exercises the protocol: scrolling
;;; produces :moved for rows that stay, :gone/:appeared for rows crossing the viewport edge.
;;;
;;; Only VISIBLE rows become presentations.  That is not an optimization — it is the working set.  A
;;; view subscribes to a slice, and the slice is what the consumer is told about.

(defun row-type-of (type object)
  "TYPE may be a presentation type, or a FUNCTION from object to presentation type.  A result-set is
allowed to be heterogeneous — the monitor's is, stats followed by enrolments — and each row is keyed
and projected by its own type.  A symbol is never called: presentation types ARE symbols, so only a
function can mean 'ask'."
  (if (functionp type) (funcall type object) type))

(defun layout-list (objects type view
                    &key (x 0) (y 0) (width 640) (row-height 32) (scroll-y 0) (viewport-h 480)
                         (as-of nil))
  "Lay OBJECTS out as a vertical list and return the presentations for the rows that are VISIBLE
given SCROLL-Y and VIEWPORT-H.  Extents are grid-snapped in framebuffer space (rule 3), and each
row's fingerprint is its projected content, so a row that renders the same emits nothing.

This is the CONSUMER's work, not the projection's (DESIGN.md rule 8): SCROLL-Y, VIEWPORT-H and VIEW
are all properties of the one looking.  Two consumers over one result-set call this twice, with
their own numbers, and get their own extents."
  (let ((rh (snap row-height :up t))               ; rows are a whole number of macroblocks
        (out '()))
    (loop for o in objects
          for i from 0
          for top = (- (+ y (* i rh)) scroll-y)
          when (and (> (+ top rh) y) (< top (+ y viewport-h)))    ; intersects the viewport
            do (let* ((ty (row-type-of type o))
                      (content (present o ty view)))
                 (push (make-presentation
                        :key (presentation-key ty o)
                        :type ty
                        :object o
                        :extent (snap-extent x top width rh)
                        :fingerprint content
                        :as-of as-of)
                       out)))
    (nreverse out)))

(defun list-content-height (objects &key (row-height 32))
  (* (length objects) (snap row-height :up t)))
