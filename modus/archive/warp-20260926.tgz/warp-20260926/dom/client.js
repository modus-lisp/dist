// warp/dom/client.js — the DOM encoding's client.  ONE copy, two hosts, no transport.
//
// This file is loaded verbatim by two pages that have nothing else in common:
//
//   warp/dom/client.html                                a standalone page over a WebSocket
//   webrtc-data/demo/glass-webrtc/index-nostr.html      a panel over a WebRTC data channel
//
// and it is the same file in both because the client's job does not vary with the link.  A frame
// is a frame; MAKE-WARP-CLIENT takes a SEND and hands back an APPLY, which is the browser half of
// the same statement the server half makes by taking a SEND function and nothing else.
//
// It is deliberately small, and the smallness is the argument.  The client holds a Map from key to
// node and does four things with a delta: create, replace content, re-anchor, remove.  It does not
// diff, does not reconcile, does not keep a shadow tree and does not know what a projection is —
// all of that happened on the server, which is what "the stream carries state, not events" buys.
//
// It also does not decide anything about safety.  The menu it draws is whatever the server sent
// it; it cannot invent a command, and if it tried, the server would refuse it at invocation
// (DESIGN.md rule 6).
//
// THE HOST OWNS THE ELEMENTS AND THE STYLESHEET.  This file writes exactly these class names and
// nothing else, so a page can look however it likes without touching the logic:
//
//   on a row       selected | warn | bad     and cells .v (value) .l (label) .stale (as-of)
//   on a menu item destructive              and cells .t (label)  .c (cost class)
//   on an opaque node  opaque               and cells .cap (the caption) .dim (its size)
//   on a container container                and data-container="<the name the wire used>"
//
// GESTURES ARE SCOPED TO A ROOT ELEMENT, which is the one thing the standalone page did not need
// and the panel absolutely does: a listener on `document` inside a remote-desktop client would eat
// the pointer events the trackpad lives on.  ATTACHGESTURES(root) listens on root only.
//
// ONE LINK MAY CARRY SEVERAL PROJECTIONS.  A frame names the app it belongs to in `a`, and this
// client applies only the frames addressed to the app it was made for — OPTS.APP, which is null for
// the host's default one.  That is how a phone shows the device manager and the file browser at the
// same time over the one negotiated data channel it was able to open before the offer.

"use strict";
function makeWarpClient(opts) {
  const rowsEl = opts.rows;
  const menuEl = opts.menu;
  const out    = opts.send;                 // (object) -> void.  The whole of the transport.
  const onStat = opts.onStat || function () {};
  const ROWS   = opts.viewportRows || 14;   // what this viewport can show; reported to the server
  const APP    = opts.app == null ? null : opts.app;   // which projection this client is a surface for

  // Every message we send carries the app, so the host can route it back to the right consumer.  A
  // client of the default app stamps nothing, which is what keeps a one-app link byte-for-byte what
  // it was before any of this existed.
  function send(o) { if (APP != null) o.a = APP; return out(o); }

  // key -> {key, node, in, after}.  This is the client's ENTIRE model.  The server holds the
  // memory of what we have been told; we hold the nodes it named and the anchor each one was given.
  const nodes = new Map();

  // Anchor key -> the records waiting for it.  THIS IS NOT DEFENSIVE PADDING, it is load-bearing,
  // and it is the one thing an anchor-based encoding needs that a rectangle-based one does not.
  //
  // A rectangle is absolute: deltas carrying rectangles can be applied in any order at all.  An
  // anchor is RELATIVE, so "insert X after Y" is unappliable until Y exists — and two independent
  // things make that happen:
  //
  //   * the reconciler emits within a priority band in reverse layout order, so a pass that
  //     appends two rows sends `r05 after r04` before it sends `r04`;
  //   * and even in layout order, the BUDGET can defer the anchor to a later pass entirely, which
  //     no ordering rule on the server could fix.
  //
  // So a node whose place we do not know yet is held OUT of the document rather than dropped into
  // a place we invented, and it is inserted the moment its anchor lands.  Guessing would put a row
  // in the wrong place and leave it there, which is exactly the silent-wrong-order failure this
  // encoding's positions exist to prevent.
  const waiting = new Map();
  let gen = 0, frames = 0, bytes = 0, deltas = 0;
  let scroll = 0;

  // ---- containers: the wire has always named one, and only "rows" was ever real ----------------
  //
  // A delta's `in` is the NAME of the container the node belongs to.  Two of those names are the
  // encoding's own and the HOST owns an element for each: "rows" and "menu:<key>".  Every other
  // name is the APP's — "col:/tmp/foo/", "preview" — and a container for it is created here on
  // demand, inside the rows element, and removed when its last child leaves.  Until a client
  // nested, this function was `name === "rows" ? rowsEl : menuEl` and every app container in
  // existence rendered into the hold-menu, silently, because no app had ever named one.
  //
  // WHERE A CONTAINER GOES IS NOT DERIVABLE FROM THE DELTAS, and that is the whole reason `cs`
  // exists.  `after` orders siblings WITHIN a container and says nothing at all across them, and a
  // pass emits within a priority band in reverse layout order — so the rightmost Miller column's
  // rows arrive FIRST, and ordering containers by first appearance would draw the columns right to
  // left.  So the frame carries `cs`: the app's containers, in layout order, as state rather than
  // as an event.  It is the same obligation rule 4 already puts on an anchor, one level up: never
  // put a thing in a position you invented.
  //
  // Containers do not nest in containers.  `in` is a flat name and a frame says nothing about a
  // container's own parent, so `cs` is a sequence, not a tree — Miller columns want exactly that,
  // and a client that wanted a tree would need the wire to say so.
  const containers = new Map();     // name -> element, for the app's containers only
  let order = [];                   // `cs`, as the server last stated it

  function container(name) {
    if (name == null || name === "rows") return rowsEl;
    if (name.lastIndexOf("menu:", 0) === 0) return menuEl;
    let el = containers.get(name);
    if (!el) {
      el = document.createElement("ul");
      el.className = "container";
      el.dataset.container = name;
      containers.set(name, el);
      orderContainers();
    }
    return el;
  }

  // The app's containers, in the order the server last stated.  One left-to-right pass with
  // insertBefore: a container already in its place is not touched, so re-stating an unchanged
  // order costs nothing and moves nothing.  A container we hold that `cs` does not mention keeps
  // its relative place at the end rather than being guessed at.
  function orderContainers() {
    if (!containers.size || !rowsEl) return;
    const seq = order.filter((n) => containers.has(n));
    for (const n of containers.keys()) if (seq.indexOf(n) < 0) seq.push(n);
    let prev = null;
    for (const n of seq) {
      const el = containers.get(n);
      const want = prev ? prev.nextSibling : rowsEl.firstChild;
      if (el !== want) rowsEl.insertBefore(el, want);
      prev = el;
    }
  }

  // A container is the app's claim that a group EXISTS, and the only evidence it still does is that
  // something is in it.  Emptied — the column closed, the preview cleared — it goes, so the host's
  // stylesheet never has to reason about a box with nothing in it.  Anything else the client made
  // is left alone: a node parked waiting for its anchor is out of the document, and dropping the
  // container it named would be inventing an answer to a question nobody asked.
  function dropIfEmpty(el) {
    if (!el || !el.dataset || !el.dataset.container || el.firstChild) return;
    containers.delete(el.dataset.container);
    el.remove();
  }

  // The four kinds, and nothing else.  Note what is NOT here: no re-render, no keyed list diff, no
  // virtual DOM.  A :moved does not touch the node's content, which is the entire point of rule 2.
  function applyDelta(d) {
    const rec = nodes.get(d.key);
    switch (d.k) {
      case "appeared": {
        const li = document.createElement("li");
        li.dataset.key = d.key;
        paint(li, d);
        const r = {key: d.key, node: li, in: d.in, after: d.after};
        nodes.set(d.key, r);
        place(r);
        break;
      }
      case "changed": {
        if (!rec) return;
        paint(rec.node, d);
        rec.in = d.in; rec.after = d.after;
        place(rec);
        break;
      }
      case "moved": {
        if (!rec) return;
        rec.in = d.in; rec.after = d.after;
        place(rec);                   // content untouched: the node is re-anchored, not rebuilt
        break;
      }
      case "gone": {
        if (!rec) return;
        const from = rec.node.parentNode;
        rec.node.remove();
        nodes.delete(d.key);
        dropIfEmpty(from);
        break;
      }
    }
  }

  // `after` is the key of the sibling this node follows, null meaning first child.  That is the
  // whole of the DOM's positional vocabulary and it is exactly what the server sends.
  function place(rec) {
    const parent = container(rec.in);
    if (!parent) return;
    const from = rec.node.parentNode;         // where it was, so an emptied container can go
    if (rec.after == null) {
      if (rec.node.parentNode !== parent || parent.firstChild !== rec.node) {
        parent.insertBefore(rec.node, parent.firstChild);
      }
    } else {
      const a = nodes.get(rec.after);
      if (!a || a.node.parentNode !== parent) {   // the anchor has not arrived, or is itself parked
        let w = waiting.get(rec.after);
        if (!w) waiting.set(rec.after, w = []);
        if (!w.includes(rec)) w.push(rec);
        if (rec.node.parentNode) rec.node.remove();
        if (from !== parent) dropIfEmpty(from);
        return;
      }
      if (rec.node.parentNode !== parent || rec.node.previousSibling !== a.node) {
        parent.insertBefore(rec.node, a.node.nextSibling);
      }
    }
    if (from && from !== parent) dropIfEmpty(from);
    const w = waiting.get(rec.key);               // anything that was waiting on us can go in now
    if (w) { waiting.delete(rec.key); for (const r of w) place(r); }
  }

  // ---- the widget table: what a row's cells MEAN, per declared type ----------------------
  //
  // MIRRORS src/widget.lisp, and mirrors it deliberately rather than receiving it.  Sending the
  // declarations down the wire was the alternative and it buys nothing here: a client paints the
  // kinds it has CSS for, so a kind it has never heard of is one it could not draw even if it
  // were told the layout.  What it does instead is fall back to a plain row, which is what every
  // client did before any of this and is never worse than guessing.
  //
  // WHAT THIS REPLACES is three branches that inferred a row's kind from its DATA:
  //
  //     if (d.type === "menu-item")     [label, cost, destructive?]
  //     else if (cells[2] === "opaque") [caption, dims, "opaque"]
  //     else                            [value, label, trend]
  //
  // The third slot meant trend, or destructive, or the literal tag "opaque", decided by testing
  // its own contents.  That held while every client was a flat list of one kind of thing and
  // stopped holding the moment one was not: a pivot row is a label, one number per column and a
  // total, so there is no third slot to sniff and no width to widen to.
  //
  // `repeat' is the group that varies with the data — one cell per column of a slice — and there
  // is at most one, so a layout resolves from both ends: fixed names before it, fixed names after
  // it, and whatever is left in the middle.
  const WIDGETS = {
    "menu-item":       {fixed: ["label", "cost", "tone"]},
    "row":             {fixed: ["value", "label", "trend"]},
    "opaque":          {before: ["caption", "dimensions"], repeat: "detail", after: ["kind"]},
    "heading":         {fixed: ["text", "level"]},
    "prose":           {fixed: ["text"]},
    "table-head":      {before: ["corner"], repeat: "column", after: ["total"]},
    "table-row":       {before: ["label"],  repeat: "value",  after: ["total"]},
    "table-total":     {fixed: ["label", "value"]},
    "chip":            {fixed: ["label"]},
    "entry":           {fixed: ["label", "detail", "tag"]},
    "button":          {fixed: ["glyph", "kind"]},
    "meter":           {fixed: ["state"]},
    "toggle":          {fixed: ["label", "state"]},
    "choice":          {fixed: ["label", "state"]},
    "field":           {fixed: ["label", "value"]},
    // The document client's own types map onto those kinds.  An app declares this in Lisp with
    // DEFINE-WIDGET; here it is the same statement in the encoding that has to draw it.
    "heading-row":     {fixed: ["text", "level"]},
    "prose-row":       {fixed: ["text"]},
    "slice-head-row":  {before: ["corner"], repeat: "column", after: ["total"]},
    "slice-data-row":  {before: ["label"],  repeat: "value",  after: ["total"]},
    "slice-total-row": {fixed: ["label", "value"]},
    "crumb-chip":      {fixed: ["label"]},
    // warp-files and warp-media both present ENTRY under their own names, and warp-media's
    // controls are core's BUTTON and METER.  Listing them here is what the catalogue found
    // missing: declared in Lisp, unpaintable in the browser, falling silently through to the
    // three-cell row.
    "fs-head":         {fixed: ["label", "detail", "tag"]},
    "fs-dir":          {fixed: ["label", "detail", "tag"]},
    "fs-file":         {fixed: ["label", "detail", "tag"]},
    "media-head":      {fixed: ["label", "detail", "tag"]},
    "media-dir":       {fixed: ["label", "detail", "tag"]},
    "media-track":     {fixed: ["label", "detail", "tag"]},
    "media-control":   {fixed: ["glyph", "kind"]},
    "media-seek":      {fixed: ["state"]},
    // ...and both present rule 9's OPAQUE node under their own name too.  Leaving these two out
    // is not a missing style, it is a missing TYPE: with no layout, `at("kind")` is null, the
    // opaque branch below never fires, and a preview paints as an ordinary row -- silently, which
    // is the whole reason widget-table drift is now a test rather than a habit.
    "fs-preview":      {fixed: ["caption", "dimensions", "kind"]},
    // The device manager's two types ARE core's ROW, which is why they painted correctly while
    // undeclared -- the generic branch is the one they wanted.  Named anyway: "it happens to fall
    // through to the right place" is not the same statement as "this is a row", and only the
    // second one survives someone editing the fallback.
    "enrolment":       {fixed: ["value", "label", "trend"]},
    "stat":            {fixed: ["value", "label", "trend"]},
    "media-transport": {fixed: ["title", "clock", "state", "error"]},
    "media-picture":   {before: ["caption", "dimensions"], repeat: "detail", after: ["kind"]},
    "cat-head":        {fixed: ["text", "level"]},
    "cat-note":        {fixed: ["text"]},
    "cat-menu":        {fixed: ["label", "cost", "tone"]},
    "cat-icon":        {fixed: ["glyph", "label"]},
  };

  // Resolve a declaration against an actual row: n names, one per cell, or null when the type is
  // undeclared or the row is too narrow to satisfy it.  Same rule as WIDGET-LAYOUT in Lisp, and
  // the Lisp side has the test that proves both ends agree.
  function layoutOf(type, n) {
    const w = WIDGETS[type];
    if (!w) return null;
    if (w.fixed) return w.fixed.length === n ? w.fixed.slice() : null;
    const fixed = w.before.length + w.after.length;
    if (n < fixed) return null;
    return w.before.concat(new Array(n - fixed).fill(w.repeat), w.after);
  }

  // ---- icons: the same path data src/icons.lisp holds ------------------------------------
  //
  // MIRRORED, like the widget table, and for the same reason: a client draws what it has a
  // renderer for, so an icon it has never heard of is one it could not draw even if it were sent
  // the path.  What it does instead is print the glyph as text -- which is what every client did
  // before icons existed, and is exactly right for a consumer with no geometry.
  //
  // t/icons.lisp asserts the two tables carry the same names, so this cannot quietly drift.
  const ICONS = {
    play:          {d: "M8 5v14l11-7z", fill: true},
    pause:         {d: "M6 5h4v14H6z M14 5h4v14h-4z", fill: true},
    stop:          {d: "M6 6h12v12H6z", fill: true},
    prev:          {d: "M7 5h2v14H7z M20 5v14l-10-7z", fill: true},
    next:          {d: "M15 5h2v14h-2z M4 5l10 7-10 7z", fill: true},
    "chevron-right": {d: "M9 5l7 7-7 7"},
    "chevron-left":  {d: "M15 5l-7 7 7 7"},
    "chevron-down":  {d: "M5 9l7 7 7-7"},
    "chevron-up":    {d: "M5 15l7-7 7 7"},
    close:         {d: "M6 6l12 12 M18 6L6 18"},
    check:         {d: "M4 12l5 6L20 6"},
    plus:          {d: "M12 5v14 M5 12h14"},
    minus:         {d: "M5 12h14"},
    folder:        {d: "M3 6h6l2 2h10v11H3z"},
    file:          {d: "M6 3h8l4 4v14H6z M14 3v4h4"},
    trash:         {d: "M5 7h14 M9 7V5h6v2 M7 7l1 13h8l1-13"},
  };

  // A glyph cell is a STRING drawn as text, as it always was, or a KEYWORD naming an icon.
  //
  // TOLD APART BY LOOKUP, NOT BY SYNTAX.  The first attempt tested for a leading colon, on the
  // assumption that %JSON-WRITE renders :PLAY as ":play" -- it does not, it renders "play", so
  // the test never fired and every button drew its name as text.  Looking the string up in the
  // table is simpler and has a better failure mode: an unknown glyph is drawn, which is exactly
  // what a literal like "|<" wants.
  //
  // The cost is that a literal glyph spelled "play" gets the play icon.  That is a collision
  // worth having: an app that writes "play" in a glyph cell means the play icon.
  function iconEl(glyph) {
    if (typeof glyph !== "string") return null;
    const ico = ICONS[glyph.toLowerCase()];
    if (!ico) return null;
    const NS = "http://www.w3.org/2000/svg";
    const svg = document.createElementNS(NS, "svg");
    svg.setAttribute("viewBox", "0 0 24 24");
    svg.setAttribute("class", "icon");
    const path = document.createElementNS(NS, "path");
    path.setAttribute("d", ico.d);
    if (ico.fill) { path.setAttribute("fill", "currentColor"); }
    else { path.setAttribute("fill", "none"); path.setAttribute("stroke", "currentColor");
           path.setAttribute("stroke-width", "2"); path.setAttribute("stroke-linecap", "round");
           path.setAttribute("stroke-linejoin", "round"); }
    svg.appendChild(path);
    return svg;
  }

  function paint(li, d) {
    const cells = d.cells || [];
    const names = layoutOf(d.type, cells.length);
    const at = (name) => { const i = names ? names.indexOf(name) : -1;
                           return i < 0 ? null : cells[i]; };

    if (d.type === "cat-icon") {
      li.className = "iconcell";
      li.innerHTML = "";
      const svg = iconEl(at("glyph"));
      const g = document.createElement("span"); g.className = "g";
      if (svg) g.appendChild(svg); else g.textContent = String(at("glyph"));
      li.append(g, cell("n", at("label")));
      return;
    }

    if (d.type === "cat-menu") {
      li.className = at("tone") === "destructive" ? "menusample destructive" : "menusample";
      li.innerHTML = "";
      li.append(cell("t", at("label")));
      if (at("cost")) li.append(cell("c", at("cost")));
      return;
    }

    if (d.type === "menu-item" && at("cost") === "text") {
      // A PROMPT ITEM: tapping it means ASK ME.  The keyboard is entirely the client's, between
      // this tap and the cmd message below -- which is why warp needed no new gesture and sees
      // no keystrokes.
      li.className = "prompt";
      li.innerHTML = "";
      li.append(cell("t", at("label")), cell("c", "…"));
      return;
    }

    if (d.type === "menu-item") {
      // `live' is STATE, not a cell: which value is currently set is this consumer's view of the
      // choice, not part of the choice's content.  See the note in src/menu.lisp.
      li.className = (at("tone") === "destructive" ? "destructive" : "") +
                     ((d.state && d.state.live) ? " live" : "");
      li.innerHTML = "";
      li.append(cell("t", at("label")));
      if (at("cost")) li.append(cell("c", at("cost")));
      return;
    }

    // AN OPAQUE NODE IS A HOLE, AND THE CAPTION IS THE WHOLE OF WHAT WE GET (DESIGN.md rule 9).
    // The app offers this region as pixels; this client cannot blit and is not going to be given
    // a way to — the wire is JSON cells, "binary payloads" is an open design question, and
    // sneaking the bytes through here would answer it by accident.  Detected by TYPE now rather
    // than by finding the word "opaque" in a data slot; the cell survives so an older app that
    // has not declared its type still lands here.
    if (d.type === "opaque" || at("kind") === "opaque") {
      li.className = "opaque";
      li.innerHTML = "";
      li.append(cell("cap", at("caption") ?? cells[0]));
      const dim = at("dimensions") ?? cells[1];
      if (dim) li.append(cell("dim", dim));
      if (d.as_of) li.append(cell("stale", "as of " + d.as_of));
      return;
    }

    if (d.type === "entry" || d.type === "fs-head" || d.type === "fs-dir" ||
        d.type === "fs-file" || d.type === "media-head" || d.type === "media-dir" ||
        d.type === "media-track") {
      // A NAME THAT LEADS.  The tag is the app's own keyword and an encoding that does not
      // recognise one styles the row plainly -- which is why adding a kind needs no client edit.
      const tag = String(at("tag") ?? "").replace(/^:/, "");
      li.className = "entry" + (tag ? " " + tag : "") +
                     ((d.state && d.state.selected) ? " selected" : "");
      li.innerHTML = "";
      li.append(cell("n", at("label")));
      if (at("detail")) li.append(cell("d", at("detail")));
      return;
    }

    if (d.type === "button" || d.type === "media-control") {
      li.className = "button k-" + String(at("kind") ?? "").replace(/^:/, "");
      li.innerHTML = "";
      const svg = iconEl(at("glyph"));
      if (svg) { const s = document.createElement("span"); s.className = "g"; s.appendChild(svg);
                 li.append(s); }
      else li.append(cell("g", at("glyph")));
      return;
    }

    if (d.type === "meter" || d.type === "media-seek") {
      // ONE SEGMENT.  The state is the whole cell, and the segment carries no text at all --
      // a bar made of words would be a list, which is what this looked like before the client
      // knew what a meter was.
      li.className = "seg s-" + String(at("state") ?? "empty").replace(/^:/, "");
      li.innerHTML = "";
      return;
    }

    if (d.type === "heading" || d.type === "heading-row" || d.type === "cat-head") {
      const lvl = String(at("level") || "h2").replace(/^:/, "");
      li.className = "heading " + lvl;
      li.innerHTML = "";
      li.append(cell("h", at("text")));
      return;
    }

    if (d.type === "prose" || d.type === "prose-row" || d.type === "cat-note") {
      li.className = "prose";
      li.innerHTML = "";
      li.append(cell("p", at("text")));
      return;
    }

    // A TABLE IS STILL A ROW OF CELLS, which is what makes it fit an encoding built for lists.
    // The head and the body differ only in class, so a stylesheet aligns the columns and the
    // client does not have to know the table exists as an object.
    if (d.type === "table-head" || d.type === "slice-head-row" ||
        d.type === "table-row"  || d.type === "slice-data-row") {
      const head = d.type === "table-head" || d.type === "slice-head-row";
      li.className = (head ? "trow thead" : "trow") +
                     ((d.state && d.state.selected) ? " selected" : "");
      li.innerHTML = "";
      cells.forEach((c, i) => {
        const name = names ? names[i] : null;
        li.append(cell("td " + (name || ""), c));
      });
      return;
    }

    if (d.type === "table-total" || d.type === "slice-total-row") {
      li.className = "ttotal";
      li.innerHTML = "";
      li.append(cell("l", at("label")), cell("v", at("value")));
      return;
    }

    if (d.type === "field") {
      const v = at("value");
      li.className = "field" + (v ? "" : " empty");
      li.innerHTML = "";
      li.append(cell("n", at("label")), cell("val", v || "— not set —"));
      return;
    }

    if (d.type === "toggle") {
      // ON-NESS IS A CELL, not view state: it is a fact about the setting, so every seat sees it.
      const on = String(at("state") ?? "").replace(/^:/, "") === "on";
      li.className = "toggle" + (on ? " on" : "");
      li.innerHTML = "";
      li.append(cell("box", on ? "\u2713" : ""), cell("n", at("label")));
      return;
    }

    if (d.type === "choice") {
      // An option of an inline set.  WHICH ONE IS SET IS A CELL, not view state: the selected
      // value is a fact about the setting, so every seat sees the same one.
      li.className = "choice" +
        (String(at("state") ?? "").replace(/^:/, "") === "live" ? " live" : "");
      li.innerHTML = "";
      li.append(cell("t", at("label")));
      return;
    }

    if (d.type === "chip" || d.type === "crumb-chip") {
      // ONE CHIP, ONE PRESENTATION, so it has a key and is tappable on its own.  It was a row of
      // N cells and could only be tapped whole; a gesture carries a key and no coordinates, so
      // there was nothing to send that said which cell.  Same answer core gives for menu items.
      // The horizontal strip is the CONTAINER's doing (crumbs:*), not this row's.
      li.className = "chip" + ((d.state && d.state.selected) ? " selected" : "");
      li.innerHTML = "";
      li.append(cell("t", at("label") ?? cells[0]));
      return;
    }

    // THE FALLBACK IS THE OLD DEFAULT and stays exactly as it was: value, label, trend.  An app
    // that has declared nothing gets what every app got before widgets existed.
    li.className = (d.state && d.state.selected) ? "selected " + trend(cells[2]) : trend(cells[2]);
    li.innerHTML = "";
    li.append(cell("v", cells[0]), cell("l", cells[1]));
    // as_of is on every delta because DESIGN.md makes staleness first-class: under a budget a
    // delta can arrive several passes late, and the consumer is entitled to see it.
    if (d.as_of) { li.append(cell("stale", "as of " + d.as_of)); }
  }
  function trend(t) { return t === "bad" ? "bad" : t === "warn" ? "warn" : ""; }
  function cell(cls, text) {
    const s = document.createElement("span");
    s.className = cls; s.textContent = text == null ? "" : String(text);
    return s;
  }

  // One frame, as it arrived on whatever the link is.  Takes the raw string so the byte count is
  // the real one; a host that already parsed it can pass the object instead.
  function apply(data) {
    let frame = data, raw = null;
    if (typeof data === "string") { raw = data; try { frame = JSON.parse(data); } catch (_) { return null; } }
    if (!frame) return null;
    // A frame addressed to another projection on this link is not ours to apply, and not ours to
    // count either: BYTES is what THIS surface cost, which is the number a panel reports and the
    // number a budget is checked against.
    if ((frame.a == null ? null : frame.a) !== APP) return null;
    if (raw !== null) bytes += raw.length;
    frames++;
    if (!frame.deltas) return null;
    // rule 4: snapshot chunks carry a generation, and anything older than the newest is discarded.
    if (frame.gen < gen) return frame;
    if (frame.gen > gen) { gen = frame.gen; }
    // The container order comes FIRST, so a container created by the deltas below already knows
    // where it belongs and no column is ever briefly drawn in the wrong place.
    if (frame.cs) { order = frame.cs; orderContainers(); }
    for (const d of frame.deltas) { deltas++; applyDelta(d); }
    onStat(stats());
    return frame;
  }

  // A LINK THAT WENT AWAY TAKES THE SERVER'S MEMORY WITH IT.  The server detaches the consumer on
  // close, so a reconnecting client is a NEW consumer with an empty stream and will be sent a full
  // snapshot (rule 8: attaching is not a resync).  Holding our old nodes across that would leave
  // rows on screen that the new stream never mentions and can therefore never remove.
  function reset() {
    for (const r of nodes.values()) r.node.remove();
    nodes.clear(); waiting.clear();
    for (const el of containers.values()) el.remove();
    containers.clear(); order = [];
    rowsEl.innerHTML = ""; if (menuEl) menuEl.innerHTML = "";
    gen = 0; deltas = 0;
  }

  function stats() {
    return {gen, frames, bytes, deltas, nodes: nodes.size, parked: waiting.size, scroll,
            containers: containers.size};
  }

  // ---- gestures: recognized HERE, sent as semantics.  Rule 5's vocabulary is closed and this
  // file does not extend it — every browser event below lands on tap / hold / two-finger.

  let holdTimer = null, held = null, listeners = null;

  function keyAt(ev) {
    const li = ev.target.closest ? ev.target.closest("li[data-key]") : null;
    return li ? li.dataset.key : null;
  }

  function attachGestures(root) {
    detachGestures();
    const onDown = (ev) => {
      held = keyAt(ev);
      if (!held) return;
      // press-hold is a TIMING discrimination and it is timed locally, on purpose: 100-300ms of
      // jittery link would make a hold read as a tap if the server tried to time it.
      holdTimer = setTimeout(() => { holdTimer = null; send({t: "gesture", g: "hold", key: held}); },
                             400);
    };
    const onUp = () => {
      if (holdTimer) {
        clearTimeout(holdTimer); holdTimer = null;
        // A release inside the hold window is a tap.  A release AFTER it lands on whatever is under
        // the finger, which for an open menu is a menu item — that is rule 5's hold-drag-release,
        // and it needs no verb of its own because menu items are presentations you can tap.
        if (held) send({t: "gesture", g: "tap", key: held});
      }
      held = null;
    };
    const onCtx = (ev) => {                                    // right-click is a hold
      const k = keyAt(ev);
      if (k) { ev.preventDefault(); send({t: "gesture", g: "hold", key: k}); }
    };
    const onWheel = (ev) => {                                  // wheel is the two-finger pan
      const dy = ev.deltaY > 0 ? 1 : -1;
      scroll = Math.max(0, scroll + dy);
      send({t: "gesture", g: "two-finger", dy: dy});
    };
    root.addEventListener("pointerdown", onDown);
    root.addEventListener("pointerup", onUp);
    root.addEventListener("contextmenu", onCtx);
    root.addEventListener("wheel", onWheel, {passive: true});
    listeners = {root, onDown, onUp, onCtx, onWheel};
  }

  function detachGestures() {
    if (!listeners) return;
    const l = listeners; listeners = null;
    l.root.removeEventListener("pointerdown", l.onDown);
    l.root.removeEventListener("pointerup", l.onUp);
    l.root.removeEventListener("contextmenu", l.onCtx);
    l.root.removeEventListener("wheel", l.onWheel);
    if (holdTimer) { clearTimeout(holdTimer); holdTimer = null; }
    held = null;
  }

  return {
    apply, reset, stats, attachGestures, detachGestures,
    // the viewport report: the consumer-negotiated slice, in ROWS, which is this encoding's axis
    hello: (rows, sc) => send({t: "viewport", rows: rows || ROWS, scroll: sc == null ? scroll : sc}),
    // the test harness drives these; a human uses the mouse
    tap: (k) => send({t: "gesture", g: "tap", key: k}),
    hold: (k) => send({t: "gesture", g: "hold", key: k}),
    cmd: (name, key, confirmed) => send({t: "cmd", name, key, confirmed: !!confirmed}),
    // TEXT INPUT, AND THE LINE IT DOES NOT CROSS.  `ask' collects a string with whatever this
    // platform uses -- here window.prompt, on a phone the native keyboard with its own selection,
    // autocorrect and IME -- and sends ONE message with the result.  No keystroke, cursor or
    // intermediate string reaches the wire, which is the difference between text INPUT (this) and
    // text EDITING (a continuous channel warp does not have).
    //
    // A CANCEL SENDS NOTHING.  window.prompt returns null when dismissed, and that is a different
    // thing from an empty string: one means "I changed my mind", the other means "make it empty".
    // Collapsing them would rename a file to "" on a mis-tap.
    setText: (name, key, value) => { if (value != null) send({t: "cmd", name, key, value}); },
    ask: (name, key, current, question) => {
      const v = window.prompt(question || "value", current == null ? "" : String(current));
      if (v != null) send({t: "cmd", name, key, value: v});
      return v;
    },
    viewport: (rows, sc) => send({t: "viewport", rows, scroll: sc}),
    // every row this client holds, in document order — which for a flat app is the rows element's
    // own children and for a nesting one reads across its containers, left to right
    keys: () => [...rowsEl.querySelectorAll("li[data-key]")].map((li) => li.dataset.key),
    menu: () => (menuEl ? [...menuEl.children].map((li) => li.dataset.key) : []),
    // the nesting as it was RENDERED: container name -> the keys in it, in document order.  A test
    // that checks this is checking the DOM, not the client's own idea of the DOM.
    containers: () => [...rowsEl.children]
      .filter((el) => el.dataset && el.dataset.container)
      .map((el) => [el.dataset.container,
                    [...el.children].map((li) => li.dataset.key)]),
    // the anchor chain as the client believes it, so a test can check the DOM against the WIRE
    // rather than against the client's own idea of the DOM
    anchors: () => Object.fromEntries([...nodes].map(([k, r]) => [k, r.after])),
    parked: () => [...waiting.keys()]
  };
}
if (typeof window !== "undefined") window.makeWarpClient = makeWarpClient;
