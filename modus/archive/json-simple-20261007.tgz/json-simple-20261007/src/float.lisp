;;;; float.lisp — floats to the shortest JSON text that reads back the same
;;;; float, and decimal JSON numbers to correctly rounded doubles.
;;;;
;;;; Both directions are EXACT rational arithmetic rather than a port of
;;;; Schubfach / Eisel-Lemire: the digits are the shortest that round-trip,
;;;; chosen as the closest at that length, which is what those algorithms
;;;; produce, and the rounding is whatever FLOAT of a rational gives (correct
;;;; rounding).  Slower per number than the specialised algorithms, which does
;;;; not matter for the JSON this stack moves (mostly strings and integers);
;;;; small and obviously right does.

(in-package #:json-simple)

(defun %expt10 (k)
  "10^K as an exact rational, for any integer K."
  (if (>= k 0) (expt 10 k) (/ 1 (expt 10 (- k)))))

(defun %floor-log2 (r)
  "The integer E with 2^E <= R < 2^(E+1), for a positive rational R."
  (let ((e (- (integer-length (numerator r)) (integer-length (denominator r)))))
    ;; integer-length difference is E or E+1.
    (if (< r (if (>= e 0) (expt 2 e) (/ 1 (expt 2 (- e))))) (1- e) e)))

(defun %floor-log10 (r)
  "The integer E with 10^E <= R < 10^(E+1), for a positive rational R,
   estimated from the binary exponent and corrected exactly."
  (let ((e (floor (* (%floor-log2 r) 30103) 100000)))
    (loop while (< r (%expt10 e)) do (decf e))
    (loop while (>= r (%expt10 (1+ e))) do (incf e))
    e))

(defun %rounding-interval (x)
  "For a positive finite float X = M x 2^K: (values LOW HIGH INCLUSIVE), the
   exact rationals bounding every real number that rounds to X under IEEE
   round-to-nearest-even, and whether the bounds themselves round to X (they
   do when M is even).  The gap below is half the usual when X is a power of
   two above the smallest normal.  Pure rational arithmetic: no conversion
   back to a float, which some hosts get wrong for subnormals."
  (multiple-value-bind (m k) (integer-decode-float x)
    (let* ((p (float-digits x))
           (ulp (expt 2 k))
           (half (/ ulp 2))
           (r (* m ulp))
           (low-half (if (and (= m (expt 2 (1- p)))
                              (> k (nth-value 1 (integer-decode-float
                                                 (if (typep x 'double-float)
                                                     least-positive-normalized-double-float
                                                     least-positive-normalized-single-float)))))
                         (/ half 2)
                         half)))
      (values (- r low-half) (+ r half) (evenp m)))))

(defun %shortest-digits (x)
  "For a positive finite float X: (values DIGITS E10), DIGITS the shortest
   decimal digit string (no trailing zeros, at least one digit) such that
   D.IGITS x 10^E10 reads back as X, the closest such at that length."
  (let* ((r (rational x))
         (e10 (%floor-log10 r))
         (max-n (if (typep x 'double-float) 17 9)))
    (multiple-value-bind (low high inclusive) (%rounding-interval x)
      (loop for n from 1 to max-n do
        (let* ((q (round (* r (%expt10 (- (1- n) e10)))))
               (ee e10))
          ;; Rounding up can carry into an extra digit (9.99.. -> 10.0..).
          (when (= q (expt 10 n))
            (setq q (expt 10 (1- n)) ee (1+ e10)))
          (let ((cand (* q (%expt10 (- ee (1- n))))))
            (when (if inclusive (<= low cand high) (< low cand high))
              (let* ((s (princ-to-string q))
                     (end (length s)))
                (loop while (and (> end 1) (char= (char s (1- end)) #\0)) do (decf end))
                (return-from %shortest-digits (values (subseq s 0 end) ee))))))))
    ;; Unreachable for IEEE floats (17 / 9 digits always round-trip).
    (error 'json-write-error :format-control "cannot print float ~S" :format-arguments (list x))))

(defun %float-text (x)
  "X (a float) as jzon writes it: plain decimal when its decimal exponent is in
   [-3, 7) -- 100.0, 0.0012 -- otherwise d.ddde<exp> -- 1.0e7, 2.5e-10.  Zero
   is 0.0 or -0.0."
  (let ((neg (minusp (float-sign x))))
    (if (zerop x)
        (if neg "-0.0" "0.0")
        (multiple-value-bind (d e) (%shortest-digits (abs x))
          (let ((n (length d)))
            (concatenate
             'string
             (if neg "-" "")
             (cond
               ((and (>= e 0) (< e 7))
                (if (> n (1+ e))
                    (concatenate 'string (subseq d 0 (1+ e)) "." (subseq d (1+ e)))
                    (concatenate 'string d (make-string (- (1+ e) n) :initial-element #\0) ".0")))
               ((and (< e 0) (>= e -3))
                (concatenate 'string "0." (make-string (- (- e) 1) :initial-element #\0) d))
               (t
                (concatenate 'string (subseq d 0 1) "." (if (> n 1) (subseq d 1) "0")
                             "e" (princ-to-string e))))))))))

(defun %rational-double (r)
  "The double nearest the positive rational R (below the largest double), ties
   to even; 0d0 when R rounds to zero.  Done here because CL:FLOAT need not be
   correctly rounded and is not everywhere: SBCL 2.2.9 misrounds subnormals and
   reads 4.9e-324 as 0.  Builds the result only from an integer below 2^54 by
   SCALE-FLOAT to a normal double and, for subnormals, one exact multiply."
  ;; E: the exponent of R's last significant bit -- 52 below its leading bit,
  ;; or the subnormal floor 2^-1074.
  (let* ((e (max (- (%floor-log2 r) 52) -1074))
         (m (round (* r (if (>= e 0) (/ 1 (expt 2 e)) (expt 2 (- e)))))))   ; ties to even
    (if (>= e -1022)
        (scale-float (float m 1d0) e)
        ;; M x 2^E is exactly representable; get there from a normal double.
        (* (scale-float (float m 1d0) (+ e 1074)) least-positive-double-float))))

(defun %decimal-double (negative mantissa ndigits exponent)
  "MANTISSA x 10^EXPONENT as a correctly rounded double, negated when NEGATIVE,
   or :OVERFLOW when it is out of range.  jzon's range rules: a value up to one
   unit past the largest double reads as the largest double, anything bigger is
   an error, and so is a nonzero value that rounds to zero.  NDIGITS is
   MANTISSA's decimal length, used to refuse absurd exponents before computing
   (EXPT 10 ...) -- \"1e999999999\" must not allocate a gigabyte."
  (let ((mag (+ ndigits exponent)))
    (cond
      ((zerop mantissa) (if negative -0d0 0d0))
      ((or (> mag 310) (< mag -330)) :overflow)
      (t
       (let ((r (* mantissa (%expt10 exponent))))
         (if (>= r most-positive-double-float)
             ;; In rationals: a double operand would turn R into a double first.
             (if (< r (+ (rational most-positive-double-float) (expt 2 971)))
                 (if negative (- most-positive-double-float) most-positive-double-float)
                 :overflow)
             (let ((d (%rational-double r)))
               (cond ((zerop d) :overflow)
                     (negative (- d))
                     (t d)))))))))
