# mcclim-glass — a McCLIM backend on glass

Run **McCLIM** applications over VNC with no X server. McCLIM's software
renderer (`mcclim-render`) already rasterizes every CLIM drawing operation —
anti-aliased fills, TrueType text, gradients — into an ARGB image; this backend
copies that image into a [glass](../) framebuffer and serves it over RFB, and
translates RFB keyboard/pointer input back into CLIM events. Pure Common Lisp
end to end (McCLIM, mcclim-render + deps, glass) — no FFI, no X.

It is the same shape as McCLIM's stock `clx-fb` backend, with the one
display-specific hook (`clx-fb`'s `image-mirror-put` = `xlib:put-image`) replaced
by a framebuffer copy, and X's event source replaced by glass's `on-key` /
`on-pointer` callbacks feeding a CLIM event queue.

## Use

```lisp
(ql:quickload :mcclim)            ; and mcclim-render, glass on your ASDF path
(asdf:load-system :mcclim-glass)

(clim-glass:run-frame 'my-frame :port 5900 :width 800 :height 600)
;; then point any VNC client at localhost:5900
```

`run-frame` makes an application frame on a `:glass` port and runs its top-level
loop (blocking). The port starts an RFB server on the first paint and the CLIM
event-loop thread that drives it.

## An OPEN LOOK desktop

`(clim-glass:run-wm SPECS &key port width height background)` runs a tiny
**OPEN LOOK** window manager over VNC: a Sun-teal (or image/SVG) workspace with
decorated windows — title bars with the abbreviated-menu button, drag/raise,
functional resize and close, a right-click workspace root menu — compositing
McCLIM application frames, PTY **terminals**, and a **browser** side by side. Each
`spec` is a window: `(FRAME-CLASS …)`, `(:terminal …)`, `(:browse URL …)`,
`(:inspect FORM)` (Clouseau), `(:edit …)` (Climacs), … The compositor adds:

- **Damage-tracked, coalesced compositing** — recomposite + re-encode only the
  region that changed; a burst of McCLIM repaints coalesces to one composite per
  tick.
- **Adaptive drag** — opaque with `CopyRect` while the connection keeps up;
  switches to a **wireframe** outline when the socket send-queue backs up (a big
  window on a no-`CopyRect` client like macOS), snapping into place on release.
- **Live perf + control socket** — standing per-frame counters and every knob
  tunable on the running server (see `inspect/serve-desktop.lisp`, which also
  opens a bare-TCP eval socket: `echo '(glass:perf-report)' | nc -q1 127.0.0.1 4009`).

## Multi-seat: several people, one session

`(clim-glass::add-wm-seat PORT :port-num N :width W :height H)` attaches a **second
person** to a running desktop — a screen of their own on RFB port `N`, with their own
pointer, keyboard, focus, open menu, clipboard, and **arrangement of the same windows**.
The listener it opens binds **127.0.0.1 unless this session has a VNC credential**, and
says so when it overrules; `:address` is how you mean something else. Adding a person to
your desktop is not a decision to publish it.

The axis is: **what runs** is shared, **who watches** is per-seat. The applications and
each window's *content* framebuffer are shared, and so is each window's *size* — size is
what an application lays its content out to, so a per-seat size would be a per-seat
layout, which is a second copy of the application. Position and stacking carry no such
consequence, so they are per-seat: two people can hold the same window in different
places, with different things in front of it, and click, drag and type independently.

A seat's view of a window is **copy-on-write** against the window's own slots
(`wm-surface-x`, `wm-mirror-x`, `wm-window-z`), so a seat that has never moved a
particular window has no record for it and reads those — a seat joining a running
session sees the desktop as it stands, and a one-seat session carries no view records at
all. One seat is the **home seat** and writes through to those slots, so a window's own
position goes on meaning the *session's* arrangement — the default a seat sees until it
diverges, and what somebody joining later finds on screen. The same seat inherits
everything else a session has exactly one of (the session clipboard, the session mixer's
own mix, `glass:*key-injector*`, the RFB desktop name), and it is fixed at the first seat
for the life of the session.

**McCLIM windows are one consolidated seat**, and this is a documented seam rather than
a bug: a CLIM port has one pointer, one keyboard focus and one screen transformation per
top-level sheet. So exactly one seat drives a CLIM application at a time — but not the
same one all session. Which seat it is, is a **token** (`backend/clim-token.lisp`):

- **Taking it.** The last seat to *press a button inside* a CLIM window holds it; another
  seat's bare pointer motion is dropped rather than dragging CLIM's one pointer around
  under their hands.
- **The geometry goes with it.** McCLIM places pull-downs, dialogs and tooltips from the
  window's sheet transformation, so on acquisition that transformation is re-aimed at the
  *acquiring* seat's view of every CLIM window (`clim-resync-geometry`). A window whose
  view has not diverged costs nothing to resync — the comparison is against what CLIM
  currently believes — so two seats holding the desktop the same way hand it back and
  forth for free, and the second seat's pull-downs land under the second seat's pointer.
  The window's *own* position is left alone, so taking the token never moves anybody
  else's windows.
- **…and the pop-up it places goes with the *window*, on every screen.** A pull-down is a
  session-wide *unmanaged* mirror with one position, and that position is expressed in
  the driver's arrangement — so a menu opened on the driver's copy of a window at 430,300
  used to float over bare workspace on a seat holding that same window at 120,140. Every
  seat now draws an unmanaged mirror at a **draw offset** (`seat-draw-x`): its own copy of
  the window that posted it, minus where McCLIM believes that window to be. The offset is
  zero for the driver by construction and zero for everybody when nothing has diverged, so
  it is a *drawing* correction only — the pointer routing a posted menu runs through
  (`grab-frame-leaf-at`, `route-to-grabbed-sheet`) is reachable only by the seat CLIM has
  grabbed the pointer for, which is the driver, and is untouched.
  `backend/inspect/popup-attach-gate.lisp` checks it, chained submenus included, and
  proves the absence of trails by comparing the damage-limited screen against a full
  rebuild.
- **Letting go of it.** It goes **free** when the holder's pointer leaves every CLIM
  window, when the holder has been silent for `*clim-token-idle*` (15 s), or when the
  holder's last viewer disconnects. A *free* token is taken silently by the next input
  from anybody — which is also what a lone seat does with it all day, so a one-seat
  desktop cannot tell any of this is here.
- **Never mid-gesture.** While the holder has a CLIM pull-down posted, a WM menu open, a
  drag in flight or a button down, the token is **pinned**: another seat's press is
  recorded as *pending* and applied when the gesture ends, so the one pointer never
  teleports out of a tracking loop.
- **Optionally visible.** `(clim-glass::clim-token-show-indicator PORT T)` tints CLIM
  title bars on the screens of the seats that are *not* driving. Off by default.

Everything the *window manager* does — see, move, raise, lower, resize, close — stays
per-seat for CLIM windows too. Native glass surfaces (terminals, the browser, warren, a
nested remote desktop) carry no such assumption and are per-seat all the way down.
`backend/inspect/clim-handoff-gate.lisp` holds two seats on one real CLIM frame and
checks all of it, pull-down placement included, from the pixels.

Cursors need no code: glass sends the cursor *shape* once as an RFB pseudo-encoding and
each viewer draws it at its own pointer.

**Sound is per-seat too, and it decomposes exactly as the screen does.**
`(clim-glass::start-seat-audio PORT :seat S)` gives a seat a `glass:headset`
(`src/headset.lisp`): its own **mix out** and its own **microphone in**, on the ports
beside its screen's — `5903 -> 5913 / 5914`, so the primary seat's numbers are the ones a
one-seat desktop has always served and the WebRTC gateway does not notice. `add-wm-seat`
does it for a new person by default.

A window's pixels are painted **once** and composited per seat; a source's samples are
pulled **once** and summed per seat. That is not an analogy for its own sake — a source
is a *destructive pull*, so giving each seat its own mixer over the same sources would
hand each of them alternate frames of the podcast. One clock pulls, and each seat's
`glass:mix` sums what it wants at the gain it chose. The microphone is nobody else's
business and is in no mix at all; the ear follows its own seat's microphone; and
**dictation types on that seat's keyboard**, so the words land in the window *that* seat
has focused — `glass:*key-injector*` cannot answer that question, since the last RFB
listener to start owned it, which is what the primary seat now keeps.

`backend/inspect/seat-gate.lisp` holds two seats on one session and checks all of the
above from the pixels; `backend/inspect/seat-audio-gate.lisp` checks the keyboard, the
two microphones and the dictation routing; `backend/inspect/seat-dictation-e2e.lisp`
runs it for real — two sentences synthesised by chord, pushed into two microphone ports,
transcribed by two stave recognizers, typed into two windows, neither one's words in the
other's.

`backend/inspect/two-seat-desktop-gate.lisp` is the **acceptance** one, and the difference
is that it stands a desktop *up*: a real `run-wm` with its compositing loop ticking, a real
terminal with a real shell, a second person joining the running port with `add-wm-seat`, and
every claim above asserted on that — mostly on a **digest of each seat's whole screen**,
because "seat A's screen did not change while seat B moved a window" is a statement about
half a million pixels and the only honest way to make it is to hash them. It also holds the
line on what adding a seat may open (loopback unless there is a credential), on
`seat-move-window` staying a pure setter, and on the control socket answering a form it
cannot read instead of closing on it.

Also a **message-port** backend (`clim-glass:make-message-port`) + **compositor**
that run each app as an isolated actor drawing to a shared display over a mailbox —
an unmodified CLIM frame across an actor boundary — the shape glass takes toward
modus.

## Status

Working over VNC (validated with **TigerVNC** and **macOS Screen Sharing**): live
frames at their laid-out size, incremental (dirty-tile) updates, pointer +
keyboard input, **desktop resize both ways** (`DesktopSize` / `SetDesktopSize`),
and the OPEN LOOK desktop above. Headless in-process proofs under `inspect/`
(`interactive`, `compositor-proof`, `mcclim-damage-proof`, `adaptive-drag-proof`,
`handshake33-proof`, …) read the framebuffer back over RFB, or the compositor
state directly, and verify behavior.

Not yet: a pointer cursor shape; multiple top-level windows of one frame
(menus/dialogs) still share the single framebuffer; command `:keystroke`
accelerators without an interactor pane (standard CLIM — key events are delivered;
a frame with an interactor gets accelerators for free).
