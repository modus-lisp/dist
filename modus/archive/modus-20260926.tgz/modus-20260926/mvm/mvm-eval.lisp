;;;; mvm-eval.lisp — in-image runtime evaluator: compile a list of top-level
;;;; forms to ONE MVM bytecode module and execute the trailing expression via
;;;; mvm-interpret.  Extracted verbatim from build-generic.lisp's
;;;; *stage2-test-source* so the same source feeds BOTH the generic oracle
;;;; binary and the ANSI image (WS3: self-host the compiler + retire the
;;;; tree-walker).  Depends on mvm.lisp (ISA), interp.lisp (mvm-interpret),
;;;; and compiler.lisp (mvm-compile-toplevel / emit pipeline) being loaded
;;;; earlier in the image source.
;; mvm-eval-forms: compile a LIST of top-level forms (helper defuns followed by a
;; trailing expression) into ONE bytecode module and run the expression.  CALLs
;; between the functions resolve in-module (bytecode->bytecode) so NO native
;; bridge / value marshalling is needed — one representation throughout.  This
;; is the 'drop native' model: the interpreter runs everything as bytecode.
(defvar *mvm-eval-buffer* nil
  "PERF: persistent 64KB bytecode buffer reused across mvm-eval-forms calls (see
   the reuse site) instead of (make-array 65536) every call — mvm-buffer-used-
   bytes copies the bytecode out before the next call, so nothing retains it.")

(defvar *mvm-eval-cache* nil
  "PERF Round 2 (compile-caching): EQUAL hash, FORMS → (bc entry fn-table
   rt-table lam-offsets) — the compiled MVM module for those forms.  mvm-eval of a
   tiny form is ~26x compile-bound; the harness/asdf re-eval the same forms
   constantly, so caching the compiled bytecode skips the whole ~15M-cycle
   compile and pays only ~0.6M interpret.  Re-interpreting the cached bytecode
   is correct: the RESULT depends on live runtime state, not the cache.  bc is a
   COPY (mvm-buffer-used-bytes) so it's safe despite *mvm-eval-buffer* reuse.")

(defvar *e2-active-defun-names* nil
  "Names (strings) of the top-level DEFUNs of the mvm-eval module CURRENTLY
   being interpreted.  Def persistence installs those defuns' trampolines
   at module-BUILD time — BEFORE the module's code runs — so a runtime
   (fmakunbound 'f) executing before the (defun f …) in the same module
   (uiop's defun* expands `(defun* (f) …)` to exactly
   `(progn (fmakunbound 'f) (defun f …))`) would UNDO the installation
   and leave F undefined (the asdf resolve-location /
   process-source-registry-directive silent-death class).  fmakunbound
   consults this list and SKIPS removal for names the running module is
   (re)defining, honoring source order.  Set (lexical-save + setq-restore)
   around the module run in mvm-eval-forms; a condition escaping the run can
   leave it stale, which self-heals at the next mvm-eval-forms call and at
   worst makes an unrelated fmakunbound of one of these names a no-op.")

;;; ============================================================
;;; WS4 STAGE 5b — runtime JIT seam (bytecode → native → execute)
;;; ============================================================
;;;
;;; *use-jit* (default NIL): when T, mvm-eval-forms / %mvm-eval-run-tuple execute a
;;; compiled module by TRANSLATING its bytecode to native x64, mmap'ing an
;;; exec page, relocating out-of-module CALLs + patching const-pool immediates
;;; (the Stage 1-4 mechanism), and %jit-call'ing the entry — instead of
;;; mvm-interpret.  Set at boot (build-time default baked from MODUS_USE_JIT).
;;; ANY failure in the JIT path falls back to mvm-interpret, so correctness is
;;; never worse than JIT-off (unsupported forms — strings/length/MV — just take
;;; the interpret path).  When *use-jit* is NIL the seam is inert: mvm-eval is
;;; byte-for-byte behavior-identical to before.
(defvar *use-jit* nil
  "WS4-S5b: T = execute compiled mvm-eval modules as native JIT'd code (with
   interpret fallback on any error); NIL = pure mvm-interpret (unchanged).
   NB: the seam gates on the FUNCTION %jit-enabled-p (below), not on this
   special directly — a global-variable setq in kernel-main did NOT reliably
   propagate to mvm-eval's compiled read in the ANSI image (the value stayed NIL),
   whereas a defun resolves through the proven SFT (name-hash) path.  This
   special is kept for documentation / an alternate runtime override; the
   default %jit-enabled-p returns its value if bound, else NIL.")

;;; WS5 #203 — THE RE-EXECUTION GUARD.
;;;
;;; The interpret fallback re-runs the WHOLE FORM.  That is only SAFE while no
;;; user code has run yet; once control has entered JIT'd native code, the
;;; form's side effects have already happened, and re-running duplicates them.
;;; The old `(t (c) ...interpret...)` handler could not tell the two apart, so
;;; an ordinary error signalled by the user's own code replayed every side
;;; effect that preceded it (measured: pre=2 post=1 for a 3-setq progn).
;;;
;;; These two flags let the handler decide.  Both default to NIL, which is also
;;; what an uninitialised defvar reads as (compiler limitation #7), so no
;;; explicit init is required — but they MUST be saved/restored around each
;;; attempt rather than dynamically rebound, because JIT'd native code can call
;;; back into mvm-eval (a macroexpander running during a later form's compile),
;;; and because an escaping condition would otherwise leak the set value the
;;; same way *handler-bind-stack* used to (see 279f2cc).
(defvar *jit-native-ran* nil
  "T once control has been transferred INTO JIT'd native code for the current
   %mvm-eval-jit-run attempt.  While NIL, an escaping condition can only have
   come from JIT setup (translate / page build / relocation) — no user code has
   executed, so falling back to mvm-interpret is safe and invisible.  Once T,
   an escaping condition is the user's own and MUST be re-signalled, never
   answered by re-running the form.")

(defvar *jit-infra-fallback* nil
  "T when %mvm-eval-jit-run has DELIBERATELY signalled an internal sentinel
   asking for the interpret fallback even though native code already ran — i.e.
   knowingly double-executing the form's side effects.

   WS5 #218 CLOSED THE MAIN CASE.  This used to fire for EVERY form that left
   MV-count > 1 — which is not just `(values …)` but floor / truncate /
   ceiling / round / gethash / subtypep / read-from-string /
   multiple-value-bind / -list / -call / -prog1, i.e. a large fraction of
   ordinary code.  %mvm-eval-jit-run now READS the native MV block back out of
   BSS (tagged count at #x10000090, the count-1 extras at #x10000098+) and
   publishes it as *mvm-last-mv* in the exact shape mvm-interpret produces, so
   the seam returns the values directly and the form runs exactly ONCE.

   The only remaining trigger is a count outside [0,21] — beyond the 20-slot
   MV-VALUES area — which cannot be read back without handing the collector
   words that are not MV storage.  *jit-mv-fallback-count* measures it: it
   reads 0 on every workload measured (tests/jit-diff.lisp, where it read 444
   before this change, and tests/jit-census.lisp, where R-MV went 8 -> 0).")

(defvar *jit-mv-fallback-count* nil
  "How many times the MV path forced a re-run (the remaining double-execute).
   Post-#218 this counts ONLY the out-of-range residual described in
   *jit-infra-fallback*; 0 is the expected reading.")

(defvar *jit-resignal-count* nil
  "How many times an escaping USER condition was correctly re-signalled instead
   of being answered by re-running the form.  Non-zero here is the guard doing
   exactly its job; before the fix every one of these was a duplicated form.")

(defvar *jit-target-arch* :x64
  "WS4-S5 (aarch64): which native back-end the runtime-JIT seam drives.
   :x64 (default) → %jit-translate-page-1 (translate-mvm-to-x64, contiguous
   imm64 relocation).  :aarch64 → %jit-translate-page-1-aarch64
   (translate-mvm-to-aarch64, MOVZ/MOVK-quad relocation).  Set by the aarch64
   image's boot init; the x64 image leaves it :x64 so the x64 JIT path is
   behavior-identical to pre-Stage-5 (the aarch64 branch is dead code there —
   its translate-mvm-to-aarch64 / a64-* references resolve to unused sentinels,
   symmetric to the x64 image's existing dead translate-mvm-to-x64 ref).")

(defun %jit-enabled-p ()
  "WS4-S5b JIT gate.  The build OVERRIDES this defun (build-x64-linux.lisp,
   baked from MODUS_USE_JIT) to return T or NIL — last-defun-wins.  This base
   version honors *use-jit* if it is set (an alternate override point), else
   NIL (safe default: pure interpret)."
  (and (boundp (quote *use-jit*)) *use-jit*))

(defvar *jit-hot-only* t
  "RETRY-ON-HOT.  When T (default), a form is INTERPRETED on its FIRST eval and
   only JIT-translated when it is eval'd AGAIN (a cache hit -> %mvm-eval-run-tuple).
   Keeps one-shot LOAD forms (ql:quickload / quicklisp:setup are thousands of
   run-once top-level forms, most non-cacheable DEFUNs) on the fast interpret
   path instead of paying ~1ms/form of page translation they never recoup, while
   genuinely repeated forms still get native.  NIL = old eager behavior (JIT on
   first eval).  Read via %jit-hot-only-p (a bare special setq does not reliably
   propagate to mvm-eval's compiled read in-image, same as %jit-enabled-p).")

(defun %jit-hot-only-p ()
  "T = JIT only on the SECOND+ eval of a form (retry-on-hot); see *jit-hot-only*."
  (if (boundp (quote *jit-hot-only*)) *jit-hot-only* t))

(defvar *jit-inhibit* nil
  "CLASS-3 dynamic JIT inhibit.  When non-nil, %jit-active-p forces the mvm-eval
   seam onto the INTERPRET path regardless of %jit-enabled-p.  Needed because
   the ANSI gate BAKES %jit-enabled-p to a CONSTANT (build-x64-linux.lisp,
   MODUS_USE_JIT) that ignores *use-jit* — so a plain `(setq *use-jit* nil)`
   around the interp-closure trampoline compile (see %e2ic-mvm-eval-nocache) does
   NOT disable the JIT there in the gate image, and the native<->interp
   nested-call boundary fault (define-compiler-macro.1/.2/.7) resurfaces.
   %e2ic-mvm-eval-nocache sets THIS flag (lexical save + setq-restore) so the
   inhibit works uniformly in BOTH the CLI (%jit-enabled-p reads *use-jit*)
   and the gate (baked constant).  BOOTS AS NIL (defvar init-thunks are
   skipped in the ANSI image); a bare NIL read is exactly the wanted default
   (JIT not inhibited).")

(defun %jit-active-p ()
  "The mvm-eval seam gate: JIT is live only when the build enabled it AND it is
   not dynamically inhibited (see *jit-inhibit*)."
  (and (%jit-enabled-p)
       (not (and (boundp (quote *jit-inhibit*)) *jit-inhibit*))))

(defvar *jit-native-count* 0
  "WS5 diag: number of mvm-eval forms that completed via the NATIVE JIT path.")
(defvar *jit-fallback-count* 0
  "WS5 diag: number of mvm-eval forms that FELL BACK to mvm-interpret.")

;;; ------------------------------------------------------------------
;;; JIT FALLBACK CENSUS (WS4 differential coverage)
;;; ------------------------------------------------------------------
;;; *jit-fallback-count* answers "how often", never "why".  Every fallback in
;;; the seam now ALSO bumps exactly one reason counter below, so native% can be
;;; decomposed into a ranked list of blockers — the roadmap to JIT-only.
;;;
;;; The reasons are mutually exclusive and together they sum to
;;; *jit-fallback-count* (modulo the double-counting the pre-existing
;;; %jit-translate-page guard does: it bumps *jit-fallback-count* itself AND
;;; the caller's je=NIL branch bumps it again; R-TRANSLATE-ERR records the
;;; guard hit, R-PAGE-NIL the je=NIL branch, so the census reports both and the
;;; report subtracts).
;;;
;;;   R-TRANSLATE-ERR   translate-mvm-to-<arch> SIGNALLED — a translator gap.
;;;                     *jit-translate-err-count* (pre-existing) is this.
;;;   R-RELOC-CALL-UNRESOLVED   an out-of-module CALL names a function that
;;;                     %mvm-resolve-runtime-fn cannot find at all.
;;;   R-RELOC-CALL-NONNATIVE    the callee resolved but is a HEAP closure
;;;                     (tag 9, a runtime DEFUN) — no PROT_EXEC, so the
;;;                     #206 guard refuses the patch.  THE structural blocker
;;;                     for JIT-only: it fires for any form calling code that
;;;                     was itself defined at runtime.
;;;   R-RELOC-FNADDR-FAIL       a #'NAME value load could not be resolved.
;;;   R-MMAP-FAIL       %mmap-exec-page returned a non-address.
;;;   R-CONST-BAKED     a const-pool heap address would be baked into a
;;;                     function that OUTLIVES the module (a persisted DEFUN,
;;;                     a lambda body, an flet body) — where the next
;;;                     collection makes it stale and nothing re-bakes it.
;;;                     See the GC-SAFETY GATE in %jit-translate-page-1.
;;;   R-MV              the form left an MV count OUTSIDE [0,21] — past the
;;;                     20-slot MV-VALUES area — so the native block cannot be
;;;                     read back and the form is re-interpreted.
;;;                     (*jit-mv-fallback-count*.)  Since WS5 #218 an ordinary
;;;                     multiple-value form is NOT a fallback at all: the block
;;;                     is reproduced from BSS into *mvm-last-mv*.
;;;   R-NATIVE-ESCAPE   native code RAN and escaped with a non-condition
;;;                     (the unresolved-runtime-function sentinel).  This is
;;;                     the one reason that DOUBLE-EXECUTES side effects.
;;;   R-PAGE-NIL        the page build returned NIL (the union of the RELOC/
;;;                     MMAP reasons above, counted at the seam).
(defvar *jit-r-reloc-call-unresolved* nil)
(defvar *jit-r-reloc-call-nonnative* nil)
(defvar *jit-r-reloc-fnaddr-fail* nil)
(defvar *jit-r-mmap-fail* nil)
(defvar *jit-r-page-nil* nil)
(defvar *jit-r-native-escape* nil)
;;; AArch64 UNCOUNTED-EXIT INSTRUMENTATION.
;;; %jit-translate-page-1-aarch64 used to `(setq ok nil)` in three relocation
;;; loops and `return-from … nil` at two more places WITHOUT bumping any
;;; counter, so a ~50% fallback rate showed up as R-PAGE-NIL = total with every
;;; named reason reading 0 — i.e. the census could not name the blocker at all.
;;; The three SITE counters below are per-relocation-site; the four PAGE
;;; counters are per rejected page (first cause wins), so they are the ones that
;;; decompose *jit-fallback-count*.
(defvar *jit-r-lrel-fail* nil
  "SITE count: an IN-MODULE fn-addr (closure slot-0 / #'LOCAL) reloc failed —
   fn-map had no native offset, or the entry was not 16-byte aligned.")
(defvar *jit-r-crel-encode-fail* nil
  "SITE count (aarch64): an out-of-module CALL reloc resolved to a real address
   but could not be ENCODED — no linkage-cell arena page, or the cell sits
   further than ADRP's ±4 GB from the code page.  Expected to stay 0; a nonzero
   value means the call sequence fell back to interpretation and is the signal
   to revisit the PC-relative call shape.")
(defvar *jit-r-eoff-nil* nil
  "PAGE count: fn-map held no native offset for the module's ENTRY function, so
   there was nothing to call even though every reloc resolved.")
(defvar *jit-r-aa-crel-pages* nil
  "PAGE count: rejected because an OUT-OF-MODULE CALL could not be relocated.")
(defvar *jit-r-aa-frel-pages* nil
  "PAGE count: rejected because an out-of-module #'NAME value load failed.")
(defvar *jit-r-aa-lrel-pages* nil
  "PAGE count: rejected because an IN-MODULE fn-addr reloc failed.")
(defvar *jit-r-const-baked* nil
  "R-CONST-BAKED: the module's native code would contain BAKED const-pool heap
   addresses (%jit-patch-consts movabs sites), which the next collection makes
   stale with no way to re-bake.  See the GC-SAFETY GATE in
   %jit-translate-page-1 — such a module is INTERPRETED, so every quoted
   constant is read live out of *e2-const-pool* by op-LI-CONST.")

(defvar *jit-census-on* nil
  "When T the census ALSO records the NAMES/messages behind each blocked
   relocation and translator gap (bounded lists below), not just the tallies.
   Off by default so a production JIT run pays only fixnum increments.")

(defvar *jit-blocked-callees* nil
  "Census detail: bounded alist (NAME . COUNT) of out-of-module CALL targets
   that failed relocation.  Ranked, this IS the JIT-only roadmap.")
(defvar *jit-blocked-fnaddrs* nil
  "Census detail: bounded alist (NAME . COUNT) for failed #'NAME relocations.")
(defvar *jit-translate-err-msgs* nil
  "Census detail: bounded alist (MESSAGE . COUNT) of translator-gap errors.")

(defun %jit-census-note (name place)
  "Bump NAME's count in the bounded alist held in the census PLACE list, and
   return the (possibly extended) list.  Callers setq the special from this."
  (let ((l place) (hit nil))
    (loop
      (when (null l) (return nil))
      (when (and (stringp (car (car l))) (stringp name)
                 (string= (car (car l)) name))
        (setq hit (car l))
        (return nil))
      (setq l (cdr l)))
    (cond (hit (rplacd hit (+ 1 (cdr hit))) place)
          ((>= (length place) 96) place)          ; bounded — never unbounded growth
          (t (cons (cons name 1) place)))))

(defun %jit-err-tag (c)
  "A short, groupable STRING for condition C — its simple-condition format
   control when it has one, else a generic marker.  Never signals."
  (handler-case
      (let ((fc (simple-condition-format-control c))
            (fa (handler-case (simple-condition-format-arguments c)
                  (t (c3) nil))))
        ;; The translator's own errors are all raised as
        ;;   (error "~A (fn ~D '~A' mvm-pos ~D opcode ~D operands ~S)" msg ...)
        ;; so the CONTROL string is the same for every gap and the first
        ;; ARGUMENT is the actual message.  Group on control+first-arg.
        (if (stringp fc)
            (if (and (consp fa) (stringp (car fa)))
                (concatenate 'string (car fa) " | " fc)
                fc)
            "<condition-no-string-control>"))
    (t (c2) "<condition-unreportable>")))

(defun %mvm-on-main-thread-p ()
  "T on the MAIN thread, and unconditionally in every image that never turned
   per-CPU storage on — the same 0x10000FF8 gate %GC-REGION-CELL branches on,
   so a single-threaded image pays one load and a branch and behaves exactly
   as before.

   WHY THE CACHES ASK: a module compiled DURING A CALL ON A WORKER is
   allocated in the WORKER'S region, and a global cache is region-0-reachable
   — so caching it publishes a region-0 -> worker reference that the worker's
   own collector can never fix (the forbidden direction; see the B-LITE block
   in net/hosted-sync.lisp).  Measured: one evaluated DEFUN whose body defers
   to per-call mvm-eval, first-called on a worker, left EXACTLY ONE such
   reference via *MVM-EVAL-CACHE*, constant in K.  A worker therefore runs
   uncached — correctness for a soundness invariant, at a perf cost only a
   worker-side eval loop would notice."
  (if (= (mem-ref #x10000FF8 :u32) 0)
      t
      (if (= (percpu-ref 16) 0) t nil)))

(defvar *jit-page-cache* nil
  "WS4-S5b per-module JIT cache.  EQ hash keyed by the compiled BC byte-array
   identity → a jit-entry list (base eoff cpatches gc-stamp).  A repeated mvm-eval
   of the SAME cached module reuses the already-translated exec page instead of
   re-translating (that's the speedup: translate cost amortizes over re-evals).
   After a GC the const-pool objects MOVE (the pool is a GC root the collector
   updates); each cached page's baked const immediates go stale, so we compare
   gc-stamp to (%gc-count) and RE-PATCH from the updated pool before re-exec.")

(defvar *mvm-eval-no-cache* nil
  "When T, mvm-eval-forms bypasses *mvm-eval-cache* entirely (neither hit nor
   store) for the current call.  Set (setq + unwind-protect restore) by
   %e2ic-mvm-eval-nocache: the interp-closure entry compiles forms that embed
   CAPTURED ENV CONSES via the quote pool — two DIFFERENT closures can have
   EQUAL forms (same params/body, structurally-equal but non-eq env pairs),
   and an EQUAL-keyed cache hit would hand closure B a module whose const
   pool holds closure A's cells (shared state, the two-counters bug).")

(defun %mvm-eval-cacheable-p (forms)
  "T unless any top-level form is a DEF* / IN-PACKAGE / EVAL-WHEN whose FIRST
   compile has side effects (macro/trampoline/package registration) that a
   cache HIT would skip.  Those always take the full (uncached) compile path;
   plain expressions — the bulk of harness evals — are cached."
  (dolist (f forms t)
    (when (and (consp f) (symbolp (car f)))
      (let ((n (symbol-name (car f))))
        (when (or (string-equal n "DEFUN") (string-equal n "DEFMACRO")
                  (string-equal n "DEFPACKAGE") (string-equal n "IN-PACKAGE")
                  (string-equal n "DEFVAR") (string-equal n "DEFPARAMETER")
                  (string-equal n "DEFCONSTANT") (string-equal n "DEFSTRUCT")
                  (string-equal n "DEFCLASS") (string-equal n "DEFGENERIC")
                  (string-equal n "DEFMETHOD") (string-equal n "DEFTYPE")
                  (string-equal n "DEFINE-CONDITION") (string-equal n "DEFSETF")
                  (string-equal n "DEFINE-SYMBOL-MACRO") (string-equal n "MACROLET")
                  (string-equal n "DEFINE-METHOD-COMBINATION")
                  (string-equal n "EVAL-WHEN"))
          (return-from %mvm-eval-cacheable-p nil))))))

(defun %e2-scan-persist (f acc depth)
  "WS3 def persistence pre-scan (see persist-names in mvm-eval-forms): return ACC
   extended with the names (strings) of every toplevel-context DEFUN in form F.
   CLHS 3.2.3.1: forms in a top-level EVAL-WHEN / PROGN / LOCALLY body are
   THEMSELVES top level — recurse those.  A top-level MACRO call's expansion is
   also processed as top level, so a head that is none of the above is expanded
   ONE step (macroexpand-1-mvm sees both the compiler *macro-table* and, under
   *mvm-eval-runtime-p*, the runtime macro tables) and re-inspected — this is what
   lets the scan see uiop's (with-upgradability () (defun featurep ...)) →
   eval-when → defun* → progn → defun chain.  The old raw-heads-only scan
   missed every macro-wrapped defun: single-form (eval FORM) compiles FORM as
   the %mvm-eval-thunk BODY (compile-form, never mvm-compile-toplevel), so the
   compiler-recorded *e2-persist-defuns* path never fired either, and the
   block's own (detect-os) funcall-by-symbol died with CALL-IND non-callable
   (asdf gauntlet FAILFORM 43/45).  DEPTH guards runaway expansion; expansion
   errors are treated as no-expansion (the real compile will report them)."
  (if (or (> depth 40) (not (and (consp f) (symbolp (car f)))))
      acc
      (let ((hn (symbol-name (car f))))
        (cond
          ((and (string-equal hn "DEFUN") (symbolp (cadr f)))
           ;; Key the persist name by the SAME string the compiler uses for
           ;; function-info-name (%rt-fn-name): package-qualified PKG::NAME
           ;; for a runtime-born library's symbols, bare otherwise.  If this
           ;; stayed bare while the compiler qualified, the install loop's
           ;; (member pn persist-names) below would miss and the trampoline
           ;; would only get installed via the compiler-recorded path.
           (cons (%rt-fn-name (cadr f)) acc))
          ((string-equal hn "EVAL-WHEN")
           (dolist (sub (cddr f) acc)
             (setq acc (%e2-scan-persist sub acc 0))))
          ((or (string-equal hn "PROGN") (string-equal hn "LOCALLY"))
           (dolist (sub (cdr f) acc)
             (setq acc (%e2-scan-persist sub acc 0))))
          ;; PERF GATE: only a RUNTIME user macro (with-upgradability et al,
          ;; resolved via macroexpand-1-mvm's *mvm-eval-runtime-p* fallback) can
          ;; hide a toplevel defun the raw heads miss.  Bootstrap/compile-time
          ;; macros in *macro-table* (loop, handler-case, dolist, …) never
          ;; expand to toplevel defuns — skip them so the pre-scan doesn't
          ;; double-run their expanders on every mvm-eval call.
          ;; EXCEPTIONS: DEFCLASS / DEFINE-CONDITION / DEFSTRUCT are bootstrap
          ;; macros whose expansions DO contain toplevel defuns (slot
          ;; accessor/reader/writer fns, struct constructors/accessors).
          ;; Gated out, a single-form (eval '(defclass X … :accessor A-X))
          ;; compiled A-X only in-module (the form is the %mvm-eval-thunk BODY,
          ;; so the compiler-recorded path never fires either) and every
          ;; LATER eval got UNDEFINED-FUNCTION A-X — asdf's COMPONENT-CHILDREN
          ;; / COMPONENT-OPERATION-TIMES (mark-component-preloaded, gauntlet
          ;; form 241).  Let those three fall through to the expansion branch.
          ((and *macro-table*
                (not (string-equal hn "DEFCLASS"))
                (not (string-equal hn "DEFINE-CONDITION"))
                (not (string-equal hn "DEFSTRUCT"))
                (%macro-expander (car f) (normalize-name (car f))))
           acc)
          (t
           (let ((ex (handler-case (macroexpand-1-mvm f)
                       (t (c) (cons f nil)))))
             (if (cdr ex)
                 (%e2-scan-persist (car ex) acc (+ depth 1))
                 acc)))))))

;;; --- WS4-S5b JIT machinery (small factored helpers) ---
;;;
;;; Kept deliberately SMALL / non-inlined into kernel-main or mvm-eval-forms
;;; (the boot-crash/layout class — a big body baked past a branch-displacement
;;; boundary SIGSEGVs at boot).  Each does one step; the seam calls %mvm-eval-jit-run.

(defun %jit-write-imm64 (base off word)
  "Write the 64-bit WORD little-endian into the exec page at BASE+OFF (the
   10-byte movabs's imm64 slot)."
  (let ((a (+ base off)) (v word) (j 0))
    (loop while (< j 8)
          do (progn
               (setf (mem-ref (+ a j) :u8) (logand v 255))
               (setq v (ash v -8))
               (setq j (+ j 1))))))

;;; ---------------------------------------------------------------------------
;;; LINKAGE CELLS — proper CL late binding for out-of-module native CALLs.
;;;
;;; Historically a native caller baked the callee's native address at page
;;; build (crel), so a later (re)definition of the callee was invisible: the
;;; caller kept calling the old code (the native-callers-ignore-redefinition
;;; drop-in gap).  A LINKAGE CELL is a stable u64 holding the callee's CURRENT
;;; native code address.  The aarch64 crel emits `MOVZ x16,<cell>; LDR x16,[x16];
;;; BLR x16` — the caller loads the target from the cell at every call, so
;;; repointing the cell on (re)definition makes all callers, present and future,
;;; see the new code.  This is SBCL's fdefn mechanism.  Gated by
;;; *jit-linkage-cells*; the aarch64 translator's crel emit and the aarch64 crel
;;; patch below BOTH read it and MUST agree per page (they do — same dynamic
;;; extent inside %jit-translate-page).  aarch64 only for now (x64 crel unchanged).
;;; ---------------------------------------------------------------------------

(defvar *jit-linkage-cells* nil
  "When T, out-of-module native CALLs route through a stable per-name LINKAGE
   CELL so a callee (re)definition is seen by all callers (proper CL late
   binding).  When NIL/unbound, the callee address is baked at page build (early
   binding, historical).  Set T at runtime by %jit-boot-init (Limitation 7).")

(defvar *jit-lcell-table* nil
  "name(string) -> cell address (a stable u64 in an %mmap-exec-page arena).")
(defvar *jit-lcell-next* 0 "bump pointer into the current cell arena page.")
(defvar *jit-lcell-end* 0 "end of the current cell arena page.")

(defun %jit-linkage-cell (name)
  "Return the stable u64 cell address holding NAME's current native code
   address, creating it (zero-initialised) on first request.  NIL only if the
   arena page could not be mapped."
  (when (null *jit-lcell-table*)
    (setq *jit-lcell-table* (make-hash-table :test (function equal))))
  (let ((c (gethash name *jit-lcell-table*)))
    (if c
        c
        (progn
          (when (>= *jit-lcell-next* *jit-lcell-end*)
            (let ((p (%mmap-exec-page 4096)))
              (if (< p 4096)
                  (return-from %jit-linkage-cell nil)
                  (setq *jit-lcell-next* p *jit-lcell-end* (+ p 4096)))))
          (let ((cell *jit-lcell-next*))
            (setq *jit-lcell-next* (+ cell 8))
            (setf (mem-ref cell :u64) 0)
            (puthash name *jit-lcell-table* cell)
            cell)))))

(defun %jit-lcell-set (name addr)
  "Point NAME's linkage cell at ADDR (untagged native code address).  Called on
   (re)definition (%jit-install-native-fns) so existing callers pick up the new
   code.  No-op unless linkage cells are on."
  (when (and (boundp (quote *jit-linkage-cells*)) *jit-linkage-cells*)
    (let ((cell (%jit-linkage-cell name)))
      ;; RAW-ADDR: a Lisp (setf (mem-ref … :u64)) stores the value's TAGGED form
      ;; (fixnum n -> n<<1), and the caller's LDR reads the slot's RAW bits, so
      ;; store HALF the (16-aligned) address — its raw bits are then exactly ADDR.
      ;; Storing ADDR itself makes the BLR branch to 2*ADDR (#(SIMPLE-ERROR NIL)).
      (when cell (setf (mem-ref cell :u64) (ash addr -1))))))

(defun %jit-write-movz-quad (base off word)
  "WS4-S5 (aarch64): patch a MOVZ/MOVK quad (4 consecutive 32-bit words) at
   BASE+OFF with the 4 imm16 halves of WORD.  Register-agnostic: reads each
   placeholder word and REPLACES its imm16 field (bits 5..20) with (half << 5),
   preserving the placeholder's Rd + move-wide opcode base — so a li-const/
   fn-addr site targeting ANY Xd (not just x16) patches correctly.  The aarch64
   analogue of %jit-write-imm64.

   RE-RUNNABLE (WS5 aa64 const-staleness fix): the imm16 field is CLEARED
   (#xFFE0001F keeps every bit except 5..20) before the half is OR'd in.  The
   old code OR'd into a field it assumed was still the 0 placeholder, which is
   true on the FIRST bake but silently corrupts a re-bake — and a re-bake is
   exactly what %jit-entry-for must do after a collection moves the const-pool
   objects.  On a virgin placeholder the mask is a no-op, so first-bake output
   is byte-identical to before."
  (let ((k 0))
    (loop
      (when (>= k 4) (return nil))
      (let* ((wo (+ off (* k 4)))
             (w (logior (mem-ref (+ base wo) :u8)
                        (ash (mem-ref (+ base (+ wo 1)) :u8) 8)
                        (ash (mem-ref (+ base (+ wo 2)) :u8) 16)
                        (ash (mem-ref (+ base (+ wo 3)) :u8) 24)))
             (imm (logand (ash word (- (* k 16))) #xFFFF))
             (nw (logior (logand w #xFFE0001F) (ash imm 5))))
        (setf (mem-ref (+ base wo) :u8) (logand nw 255))
        (setf (mem-ref (+ base (+ wo 1)) :u8) (logand (ash nw -8) 255))
        (setf (mem-ref (+ base (+ wo 2)) :u8) (logand (ash nw -16) 255))
        (setf (mem-ref (+ base (+ wo 3)) :u8) (logand (ash nw -24) 255)))
      (setq k (+ k 1)))))

(defun %jit-write-word32 (base off w)
  "Store the 32-bit instruction W at BASE+OFF, little-endian."
  (setf (mem-ref (+ base off) :u8) (logand w 255))
  (setf (mem-ref (+ base (+ off 1)) :u8) (logand (ash w -8) 255))
  (setf (mem-ref (+ base (+ off 2)) :u8) (logand (ash w -16) 255))
  (setf (mem-ref (+ base (+ off 3)) :u8) (logand (ash w -24) 255)))

(defun %jit-write-call-adrp (base off target)
  "Patch the two-instruction PC-relative address load at BASE+OFF so that x16
   holds the 64-bit word stored at TARGET:

     [off+0]  ADRP x16, page(TARGET)
     [off+4]  LDR  x16, [x16, #lo12(TARGET)]

   (the BLR x16 the translator emitted at off+8 needs no patch).  The aarch64
   counterpart of %JIT-WRITE-MOVZ-QUAD for out-of-module CALL sites, and three
   words shorter at every one of them.

   Returns T on success and NIL — having written NOTHING — when the site cannot
   be encoded, which is the caller's signal to reject the page and let the form
   interpret.  Two ways that happens, both checked rather than assumed, because
   a wrong immediate here is a wild branch (and on bare metal a silent spin):
     - the signed page delta does not fit ADRP's 21 bits (±4 GB), or
     - TARGET is not 8-byte aligned, which LDR's scaled imm12 cannot express.
   Both hold comfortably for a linkage cell (8-byte bump-allocated out of the
   same %mmap-exec-page arena as the code page), which is why this is the right
   shape for the call sequence and not for, say, a main-image code address."
  (let* ((pc (+ base off))
         (delta (ash (- (- target (logand target 4095))
                        (- pc (logand pc 4095)))
                     -12))
         (lo12 (logand target 4095)))
    (if (or (< delta -1048576) (> delta 1048575)
            (not (eql (logand lo12 7) 0)))
        nil
        (progn
          ;; ADRP x16, #delta : 1 immlo(2) 10000 immhi(19) Rd(5)
          (%jit-write-word32 base off
                             (logior #x90000000
                                     (ash (logand delta 3) 29)
                                     (ash (logand (ash delta -2) #x7FFFF) 5)
                                     16))
          ;; LDR x16, [x16, #lo12] : 1111100101 imm12 Rn Rt, imm12 = lo12/8
          (%jit-write-word32 base (+ off 4)
                             (logior #xF9400000
                                     (ash (ash lo12 -3) 10)
                                     (ash 16 5)
                                     16))
          t))))

(defun %jit-patch-call-site (base off name addr)
  "Patch ONE out-of-module CALL relocation site at BASE+OFF so it calls ADDR
   (an untagged native code address) for callee NAME.  Returns T on success,
   NIL if the caller must reject the page.

   THE SINGLE PLACE that knows the shape the translator emitted, so the two can
   never disagree: with *JIT-LINKAGE-CELLS* on the translator emitted ADRP+LDR
   and this points them at NAME's stable cell (and stores ADDR in it); with
   cells off it emitted an absolute MOVZ/MOVK quad and this fills it with ADDR.
   Every patcher — the production JIT driver and the build's aa64s3/s4 probes —
   goes through here."
  (if (and (boundp (quote *jit-linkage-cells*)) *jit-linkage-cells*)
      (let ((cell (%jit-linkage-cell name)))
        (if cell
            ;; store HALF the addr: a Lisp (setf (mem-ref … :u64)) stores the
            ;; value's TAGGED form (n -> n<<1) and the emitted LDR reads the
            ;; slot's RAW bits, so [cell] then reads back as exactly ADDR.
            (progn (setf (mem-ref cell :u64) (ash addr -1))
                   (%jit-write-call-adrp base off cell))
            nil))
      (progn (%jit-write-movz-quad base off addr) t)))

(defun %jit-patch-consts (base cpatches)
  "Bake each live const-pool object's tagged native word into its movabs imm64.
   CPATCHES = list of (imm64-native-off . pool-idx).  Re-runnable after GC.

   WS5 #223: CPATCHES is EMPTY on x64 whenever the constant-vector indirection
   is active (*x64-jit-constvec-p*), because the translator then emits a load
   from the GC-updated vector instead of a baked address.  This function stays
   for the aarch64 back-end (GC off, pool never moves) and for any build that
   leaves the indirection off."
  (dolist (p cpatches)
    ;; A NEGATIVE offset is a WS5 #223 constant-vector record, not a byte patch
    ;; site: there is no immediate to bake, the index is carried only so
    ;; %jit-constvec-need can size the vector.  Skip it.
    (when (>= (car p) 0)
      (let ((obj (if *e2-const-pool* (gethash (cdr p) *e2-const-pool*) nil)))
        (%jit-write-imm64 base (car p) (%val->word obj))))))

(defun %jit-constvec-need (cpatches)
  "1 + the highest constant-vector index in CPATCHES (the entries with a
   negative byte offset), or 0 if there are none.  Computed from the list
   %jit-translate-page-1 already snapshots, so no additional cross-package
   global read sits on the path that decides the vector's length."
  (let ((mx -1))
    (dolist (p cpatches)
      (when (and (< (car p) 0) (> (cdr p) mx))
        (setq mx (cdr p))))
    (+ mx 1)))

(defvar *jit-cv-sites* nil
  "DIAGNOSTIC: pages built carrying at least one constant-vector site.")
(defvar *jit-cv-reject* nil
  "How many page builds were REJECTED because the installed constant vector did
   not cover the module's own indices.  Nonzero means the sizing path is wrong;
   the page is not used, so the form interprets instead of faulting.")
(defvar *jit-cv-diag* nil
  "Bounded diagnostic-print budget; NIL until first use.")

(defun %jit-cv-verbose-p ()
  "Opt-in gate for the WS5 #223 constant-vector diagnostics.  T prints a bounded
   CVDIAG line per checkpoint; NIL (default) keeps the JIT path silent."
  nil)

(defun %jit-constvec-covers-p (cpatches where)
  "T if the INSTALLED constant vector exists and is long enough for every
   constant-vector index this module was compiled against.

   This is a correctness guard, not just a probe.  The emitted sequence is
   `movabs d,<root>; mov d,[d]; mov d,[d + idx*8 + 7]` — if the root is 0 or the
   vector is shorter than IDX, that third instruction reads unmapped memory and
   the process dies with no diagnosable state.  There is no way to bounds-check
   it in the emitted code, so it is checked HERE, once per page build, against
   the same list the sizing used.  A failure returns NIL and the caller
   abandons the page, so the form interprets — wrong-but-alive instead of a
   SIGSEGV, and the interpret path is byte-for-byte the pre-#223 behaviour.

   The vector's REAL length is read with %prim-array-length rather than trusting
   *jit-constvec-cap*: if the bug is that the cap bookkeeping disagrees with the
   object, trusting the bookkeeping would make this guard agree with the bug."
  (let ((n 0) (mx -1))
    (dolist (p cpatches)
      (when (< (car p) 0)
        (setq n (+ n 1))
        (when (> (cdr p) mx) (setq mx (cdr p)))))
    (if (eql n 0)
        t
        (let* ((v (%jit-constvec))
               (vlen (if v (%prim-array-length v) 0))
               ;; INTACTNESS, not just length.  The vector is reachable ONLY
               ;; from the BSS root, so if the collector ever declines to
               ;; forward it (rather than merely moving it) the root points at
               ;; recycled from-space and every slot read is garbage — which
               ;; looks exactly like the observed fault.  Slot 0 must still be
               ;; pool entry 0; comparing against the pool, which is rooted
               ;; through the globals alist, detects recycling for free.
               (intact (or (null *e2-const-count*) (eql *e2-const-count* 0)
                           (and v (> vlen 0)
                                (eq (aref v 0) (gethash 0 *e2-const-pool*)))))
               (ok (and v (> vlen mx) intact)))
          (setq *jit-cv-sites* (if *jit-cv-sites* (+ 1 *jit-cv-sites*) 1))
          (when (null *jit-cv-diag*) (setq *jit-cv-diag* 0))
          (unless ok
            (setq *jit-cv-reject* (if *jit-cv-reject* (+ 1 *jit-cv-reject*) 1)))
          ;; Bounded output: the first few pages carrying sites, plus the first
          ;; few rejections.  A gate run builds tens of thousands of pages, so an
          ;; unbounded print would bury the answer it is meant to produce.
          ;; Diagnostics are OPT-IN (%jit-cv-verbose-p, a defun not a defvar —
          ;; defvar init-thunks do not run in-image).  A shipping CLI must not
          ;; print to stdout on the JIT path; flip the defun to T to debug.
          (when (and (%jit-cv-verbose-p)
                     (< *jit-cv-diag* 12) (or (not ok) (< *jit-cv-sites* 4)))
            (setq *jit-cv-diag* (+ *jit-cv-diag* 1))
            (format t "CVDIAG ~A ok=~A sites=~D maxidx=~D vlen=~D intact=~A cap=~S hi=~S count=~S~%"
                    where (if ok "T" "NIL") n mx vlen (if intact "T" "NIL")
                    *jit-constvec-cap* *jit-constvec-hi* *e2-const-count*))
          ok))))

;;; ============================================================
;;; WS5 #223 — the GC-updated JIT constant vector (Lisp side)
;;; ============================================================
;;;
;;; The translator (mvm/translate-x64.lisp, +op-li-const+) compiles a quoted
;;; literal reference to
;;;
;;;     movabs d, 0x10000F00 ; mov d,[d] ; mov d,[d + idx*8 + 7]
;;;
;;; i.e. slot IDX of an ordinary heap ARRAY reachable from a fixed BSS word that
;;; the collector scans as a root.  This file owns that array: allocating it,
;;; installing it in the BSS word, growing it, and keeping slot I equal to
;;; (gethash I *e2-const-pool*).
;;;
;;; The pool is APPEND-ONLY (%e2-const-register in mvm/compiler.lisp hands out
;;; *e2-const-count* and increments; nothing ever rewrites or removes an entry),
;;; so synchronisation is a high-water mark, not a rescan: only indices
;;; [*jit-constvec-hi*, *e2-const-count*) are ever copied.  Total work over a
;;; session is O(number of consts), not O(consts x pages).
;;;
;;; Retention: the vector holds a second reference to every const the pool
;;; already holds forever, so it adds NO new retention class — *e2-const-pool*
;;; is itself an unbounded append-only global.
;;;
;;; 0x10000F00 is repeated here as a literal rather than shared with the
;;; translator's *x64-jit-constvec-root*: the two files are in different
;;; packages, and an in-image defconstant does not fold.  If one moves, move both.
;;;
;;; ============================================================
;;; THE ROOT IS PER-TARGET (#282 residual, found 2026-08-31)
;;; ============================================================
;;;
;;; x64's root is #x10000F00 (*x64-jit-constvec-root*, translate-x64.lisp:99).
;;; aarch64's is #x10000F10 (*aarch64-jit-constvec-root*, translate-aarch64.lisp
;;; :208) — deliberately NOT F00, because on bare-metal aarch64 F00 is
;;; +rpi-cl-dtb-ptr-slot+ (boot/boot-rpi-cl.lisp:153), the firmware device-tree
;;; pointer.  The emitted li-const load reads the per-target root
;;; (translate-aarch64.lisp:3069) and the aarch64 native GC trampoline scans the
;;; per-target root as a fixed root (translate-aarch64.lisp:5114) — but THIS
;;; file, which is the only thing that ever WRITES the vector into a root,
;;; hardcoded x64's F00 on both back-ends.  So on aarch64:
;;;
;;;   * the vector was published at F00 while the code loaded from F10 (always
;;;     0 — measured: JD 87 = 0 after a full bare-metal virt boot);
;;;   * nothing rooted F00, so the word went stale at the first collection and
;;;     %jit-constvec handed back a recycled from-space address (measured:
;;;     %prim-array-length of it = 14,593,280);
;;;   * %jit-constvec-covers-p's INTACT test therefore failed on every page
;;;     build that carried a constvec site, and its `return-from … nil` at
;;;     %jit-translate-page-1-aarch64 is one of the two exits that bump NO R-*
;;;     census counter — so the blocker was invisible to the census.
;;;     Measured on bare-metal QEMU virt: *jit-cv-reject* = 261 of 263 total
;;;     fallbacks, *jit-native-count* = 0, with R-TRANSLATE-ERR / R-RELOC-* /
;;;     R-MMAP / R-CONST-BAKED all 0.
;;;   * worse than "no JIT": %jit-sync-constvec's mirror loop kept doing
;;;     (aset (%jit-constvec) k o) into that recycled address — wild heap
;;;     writes on a path that ran even though not one form ever went native.
;;;
;;; This is the CONVENTION-SLOT ADDRESS DIVERGENCE class (CLAUDE.md #260/#261):
;;; one side of a contract addresses a slot differently from the other.  The
;;; cure is the same one #261 used — resolve the address in ONE place, from the
;;; back-end selector, so the writer and the reader cannot drift apart.

(defun %jit-constvec-root ()
  "The BSS word holding the tagged JIT constant vector FOR THE ACTIVE BACK-END.
   Must equal the translator's own root — *x64-jit-constvec-root* (#x10000F00)
   or *aarch64-jit-constvec-root* (#x10000F10) — because the emitted li-const
   load and the collector's fixed-root scan both use that one.

   A DEFUN, not a defvar: a defvar initform does not run in-image (Limitation 7)
   and this is read on the JIT's hot path.  BOUNDP-guarded so an image whose
   *jit-target-arch* never got set falls back to the x64 slot, which is the
   historical value — i.e. this change is a no-op on x64 by construction."
  (if (and (boundp (quote *jit-target-arch*)) (eq *jit-target-arch* :aarch64))
      #x10000F10
      #x10000F00))

(defvar *jit-constvec-cap* nil
  "Allocated length of the JIT constant vector, or NIL before the first sync.")

(defvar *jit-constvec-hi* nil
  "High-water mark: pool indices [0,*jit-constvec-hi*) are already mirrored into
   the vector.  NIL before the first sync.")

(defun %jit-constvec ()
  "The live JIT constant vector, or NIL if none has been installed yet.
   ALWAYS re-read through this — never cache the array across an allocation,
   because the collector moves it and updates the BSS word in place.
   `mem-ref :u64` is a raw-word reinterpret in both directions (the keyword
   intern table at #x10000148 is stored and read exactly this way, see
   init-keyword-table / find-symbol), so an unset root reads back as FIXNUM 0."
  (let ((w (mem-ref (%jit-constvec-root) :u64)))
    (if (eql w 0) nil w)))

(defun %jit-constvec-install (v)
  "Publish V as the JIT constant vector by storing its tagged word in the fixed
   BSS root the emitted code loads from and the collector forwards.
   PER-TARGET address — see %jit-constvec-root."
  (setf (mem-ref (%jit-constvec-root) :u64) v)
  v)

(defun %jit-sync-constvec (vneed)
  "Make the JIT constant vector hold every *e2-const-pool* entry registered so
   far AND be long enough for every :li-const index the translation just
   emitted.  Returns the pool high-water mark.

   Called from %jit-translate-page-1 after translation (so both
   *e2-const-count* and *x64-li-constvec-max* are final) and BEFORE the page is
   executed.  Idempotent and cheap in the steady state: when nothing new was
   registered it is a few global reads and a comparison.

   VNEED is 1 + the highest constant-vector index this translation emitted
   (%jit-constvec-need of the caller's *x64-li-const-patches* snapshot).

   TWO BOUNDS, NOT ONE.  Sizing by *e2-const-count* alone is WRONG and was the
   cause of a whole class of gate SIGSEGVs: compile-quote also emits :li-const
   with a *constant-table* index (string literals >= 256 chars and the generic
   quote fallback), which has no relation to the quote pool and can exceed it.
   The baked-immediate path absorbed that silently — %jit-patch-consts' gethash
   missed and it baked (%val->word nil) — but a vector load of the same index
   reads PAST THE END of the array and yields an arbitrary heap word.  So the
   vector covers max(*e2-const-count*, *x64-li-constvec-max* + 1) and every slot
   that is not a live pool entry holds NIL, which reproduces the old value
   exactly.  See the constant-vector records in mvm/translate-x64.lisp's
   +op-li-const+ handler.

   The NIL prefill also replaces MAKE-ARRAY's fixnum-0 fill: 0 is not what the
   baked path produced, and it is TRUE in CL, so a stale slot read as 0 would
   change behaviour rather than merely being unhelpful.

   GC safety: MAKE-ARRAY may collect.  The OLD vector stays reachable through
   the BSS root across that collection and is re-read afterwards; the NEW vector
   is only reachable from this frame's stack slot, which the conservative root
   scan finds and updates.  Neither AREF nor ASET allocates, so no collection
   can happen inside any of the loops."
  (let* ((n (if *e2-const-count* *e2-const-count* 0))
         (need (if (> vneed n) vneed n)))
    (when (null *jit-constvec-cap*) (setq *jit-constvec-cap* 0))
    (when (null *jit-constvec-hi*) (setq *jit-constvec-hi* 0))
    (when (> need *jit-constvec-cap*)
      (let* ((want (let ((c (if (> *jit-constvec-cap* 0)
                                (* *jit-constvec-cap* 2)
                                1024)))
                     (if (< c need) need c)))
             (nv (make-array want)))
        ;; NIL-fill first (see the docstring): every slot that never receives a
        ;; pool entry must read back NIL, not MAKE-ARRAY's fixnum 0.
        (let ((k 0))
          (loop
            (when (>= k want) (return nil))
            ;; CLAUDE.md limitation 2: a variable-index ASET in non-last
            ;; position needs a binding to force dest=frame-slot.
            (let ((dummy (aset nv k nil))) dummy)
            (setq k (+ k 1))))
        ;; re-read AFTER the alloc: a GC inside make-array moves the old vector
        ;; and rewrites the BSS root.
        (let ((old (%jit-constvec))
              (k 0)
              (lim *jit-constvec-hi*))
          (loop
            (when (>= k lim) (return nil))
            (let ((dummy (aset nv k (aref old k)))) dummy)
            (setq k (+ k 1))))
        (%jit-constvec-install nv)
        (setq *jit-constvec-cap* want)))
    ;; Mirror only genuinely-new POOL entries.  The high-water mark tracks the
    ;; POOL, never the allocated length — slots past *e2-const-count* stay NIL
    ;; and are correctly overwritten later if the pool grows into them.
    (let ((k *jit-constvec-hi*))
      (loop
        (when (>= k n) (return nil))
        (let ((o (if *e2-const-pool* (gethash k *e2-const-pool*) nil)))
          (let ((dummy (aset (%jit-constvec) k o))) dummy))
        (setq k (+ k 1))))
    (setq *jit-constvec-hi* n)
    n))

(defun %jit-patch-consts-aarch64 (base cpatches)
  "aarch64 sibling of %jit-patch-consts: bake each live const-pool object's
   tagged word into its MOVZ/MOVK quad.  CPATCHES = list of (movz-byte-off .
   pool-idx).  Re-runnable after GC (see %jit-write-movz-quad's imm16 clear).
   The caller must flush the I-cache over the patched range."
  (dolist (p cpatches)
    ;; #282: a NEGATIVE offset is a constant-VECTOR sizing record, not a patch
    ;; site — there is no immediate to bake, and treating it as one would write
    ;; a quad at a negative offset.  Skip it (x64's %jit-patch-consts does the
    ;; same).  This also covers %jit-entry-for's post-GC re-bake, which calls
    ;; through here with the entry's stored cpatches.
    (when (>= (car p) 0)
      (let ((obj (if *e2-const-pool* (gethash (cdr p) *e2-const-pool*) nil)))
        (%jit-write-movz-quad base (car p) (%val->word obj))))))

;; Pool-EXPLICIT patcher variants for the cross-page sweep
;; (%jit-refresh-all-pages): identical to the two above but read POOL, the
;; page's OWN const pool (stored in its jit-entry), instead of the global
;; *e2-const-pool* — which is only that page's pool at its own seam.
(defun %jit-patch-consts-pool (base cpatches pool)
  (dolist (p cpatches)
    (let ((obj (if pool (gethash (cdr p) pool) nil)))
      (%jit-write-imm64 base (car p) (%val->word obj)))))
(defun %jit-patch-consts-aarch64-pool (base cpatches pool)
  (dolist (p cpatches)
    (let ((obj (if pool (gethash (cdr p) pool) nil)))
      (%jit-write-movz-quad base (car p) (%val->word obj)))))

;;; #306 LATE-BOUND BRIDGE (x64).  A JIT'd page's out-of-module CALL is a
;;; `movabs rax, imm64; call rax` whose imm64 must be a NATIVE entry.  When the
;;; callee resolves to a heap object — an interp closure, a #x52 closure, or a
;;; STANDARD-GENERIC-FUNCTION (CLOS accessors: never native by construction) —
;;; the page used to be rejected and the WHOLE caller ran interpreted, ~1000x
;;; slower.  Now the site is patched to a per-site THUNK that shifts the args up
;;; one register, loads V0 with a stable NAME INDEX, sets nargs, and tail-jumps
;;; to the baked %JIT-BRIDGE-N, which resolves the name at CALL time (late
;;; binding — redefinition-safe, GC-safe: the thunk holds no heap pointer) and
;;; FUNCALLs.  Sites with >3 args still fail the page (rare; register window).
(defvar *jit-bridge-names* nil "Vector of callee NAME strings, indexed by thunk.")
(defvar *jit-bridge-count* nil "Fill index into *jit-bridge-names*.  NIL = 0.")
(defvar *jit-thunk-page* nil "Current thunk pool page base (exec).")
(defvar *jit-thunk-bump* nil "Byte offset of the next free thunk in the page.")
(defvar *jit-bridged-sites* nil "CENSUS: call sites patched to a bridge thunk.")
(defvar *jit-bridge-on* nil
  "Runtime gate for the late-bound bridge.  A defvar reads NIL at boot
   (limitation 7), so the bridge is OFF through boot — boot-time forms are
   one-shot and the aarch64 boot BRK'd with it on — and is enabled by
   (setq *jit-bridge-on* t) after boot (the CLI toplevel does this once
   validated; until then it is explicit).")
(defun %jit-bridge-on-p () *jit-bridge-on*)
;; DEFUNs, not defconstants: a defconstant in this file read UNBOUND at
;; runtime (the positional-folding class), which faulted the builder.
(defun %jit-thunk-size () 48)
(defun %jit-bridge-cap () 4096)

(defun %jit-bridge-resolve (idx)
  (let ((nm (if (and *jit-bridge-names* (< idx (length *jit-bridge-names*)))
                (aref *jit-bridge-names* idx) nil)))
    (let ((f (and nm (%mvm-resolve-runtime-fn nm))))
      (if f f (error "jit-bridge: ~A is undefined at call time" nm)))))
(defun %jit-bridge-0 (idx) (funcall (%jit-bridge-resolve idx)))
(defun %jit-bridge-1 (idx a) (funcall (%jit-bridge-resolve idx) a))
(defun %jit-bridge-2 (idx a b) (funcall (%jit-bridge-resolve idx) a b))
(defun %jit-bridge-3 (idx a b c) (funcall (%jit-bridge-resolve idx) a b c))

(defun %jit-bridge-entry (n)
  "Untagged native entry of %jit-bridge-N."
  (let ((f (symbol-function (cond ((= n 0) (quote %jit-bridge-0))
                                  ((= n 1) (quote %jit-bridge-1))
                                  ((= n 2) (quote %jit-bridge-2))
                                  (t (quote %jit-bridge-3))))))
    (- (%val->word f) 3)))

;; SMALL FUNCTIONS, FEW LIVE TEMPS: the first cut was one big builder whose
;; first-use init faulted in the baked image while the same forms worked at
;; the REPL and the builder worked once its tables existed — the MVM
;; caller-save clobber signature (reference_mvm_caller_save_bug).  Each step
;; below keeps at most two values live across a call.
(defun %jit-thunk-new-page ()
  ;; x64's %mmap-exec-page yields a SAP-able page (the page-1 idiom is
  ;; (sap-address (make-sap page))); aarch64's yields the INTEGER address and
  ;; its page path uses it directly — mirror each arch's own idiom.
  (let ((pg (%mmap-exec-page 4096)))
    (let ((base (if (eq *jit-target-arch* :aarch64) pg (sap-address (make-sap pg)))))
      (if (< base 4096)
          nil
          (progn (setq *jit-thunk-page* base)
                 (setq *jit-thunk-bump* 0)
                 base)))))

(defun %jit-bridge-ensure ()
  "First-use init of the bridge tables; T when usable."
  (when (null *jit-bridge-names*)
    (setq *jit-bridge-names* (make-array 4096))
    (setq *jit-bridge-count* 0))
  (when (null *jit-thunk-page*)
    (%jit-thunk-new-page))
  (if *jit-thunk-page* t nil))

(defun %jit-thunk-alloc ()
  "Address of a fresh 48-byte thunk slot, or NIL."
  (when (> (+ *jit-thunk-bump* 48) 4096)
    (%jit-thunk-new-page))
  (if (null *jit-thunk-page*)
      nil
      (let ((a (+ *jit-thunk-page* *jit-thunk-bump*)))
        (setq *jit-thunk-bump* (+ *jit-thunk-bump* 48))
        a)))

(defun %jit-emit-bytes (addr bytes)
  (let ((k 0))
    (dolist (b bytes)
      (setf (mem-ref (+ addr k) :u8) b)
      (setq k (+ k 1)))
    k))

(defun %jit-thunk-emit-shift (addr nargs)
  "Shift args up one register (V0..V3 = RSI RDI R8 R9); return bytes written."
  (let ((k 0))
    (when (>= nargs 3) (setq k (+ k (%jit-emit-bytes (+ addr k) (list #x4D #x89 #xC1)))))  ; mov r9,r8
    (when (>= nargs 2) (setq k (+ k (%jit-emit-bytes (+ addr k) (list #x49 #x89 #xF8)))))  ; mov r8,rdi
    (when (>= nargs 1) (setq k (+ k (%jit-emit-bytes (+ addr k) (list #x48 #x89 #xF7)))))  ; mov rdi,rsi
    k))

(defun %jit-thunk-emit-tail (addr k idx nargs)
  "movabs rsi,<tagged idx>; mov dword [0x10000150],nargs+1; movabs rax,bridge; jmp rax"
  (%jit-emit-bytes (+ addr k) (list #x48 #xBE))
  (%jit-write-imm64 addr (+ k 2) (ash idx 1))
  (%jit-emit-bytes (+ addr k 10) (list #xC7 #x04 #x25 #x50 #x01 #x00 #x10 (+ nargs 1) 0 0 0))
  (%jit-emit-bytes (+ addr k 21) (list #x48 #xB8))
  (%jit-write-imm64 addr (+ k 23) (%jit-bridge-entry nargs))
  (%jit-emit-bytes (+ addr k 31) (list #xFF #xE0))
  (+ k 33))

(defun %jit-thunk-fill (addr name nargs)
  (let ((idx *jit-bridge-count*))
    (setf (aref *jit-bridge-names* idx) name)
    (setq *jit-bridge-count* (+ idx 1))
    (%jit-thunk-emit-tail addr (%jit-thunk-emit-shift addr nargs) idx nargs)
    addr))

(defun %jit-make-bridge-thunk (name nargs)
  "Build the x64 bridge thunk for a NARGS-arg call to NAME; its address or NIL."
  (if (or (null nargs) (> nargs 3) (null (%jit-bridge-ensure))
          (>= *jit-bridge-count* 4096))
      nil
      (let ((addr (%jit-thunk-alloc)))
        (if (null addr) nil (%jit-thunk-fill addr name nargs)))))

;;; aarch64 bridge thunk (96-byte slot; words, I-cache flushed).  V0..V3 =
;;; x0..x3.  Layout:
;;;   [mov x3,x2 / mov x2,x1 / mov x1,x0 as needed]
;;;   movz/movk x0 <- tagged idx            (4 words, via %jit-write-movz-quad)
;;;   movz w16, #nargs+1                     52800010 | n<<5
;;;   movz/movk x17 <- #x10000150            (4 words)
;;;   str w16, [x17]                         B9000230
;;;   movz/movk x16 <- bridge-N entry        (4 words)
;;;   br x16                                 D61F0200
(defun %jit-emit-word32 (addr w)
  (setf (mem-ref addr :u8) (logand w 255))
  (setf (mem-ref (+ addr 1) :u8) (logand (ash w -8) 255))
  (setf (mem-ref (+ addr 2) :u8) (logand (ash w -16) 255))
  (setf (mem-ref (+ addr 3) :u8) (logand (ash w -24) 255))
  4)

(defun %jit-emit-quad-placeholder (addr rd)
  "MOVZ/MOVK placeholder quad for register RD (imm16 = 0); 16 bytes."
  (%jit-emit-word32 addr (logior #xD2800000 rd))
  (%jit-emit-word32 (+ addr 4) (logior #xF2A00000 rd))
  (%jit-emit-word32 (+ addr 8) (logior #xF2C00000 rd))
  (%jit-emit-word32 (+ addr 12) (logior #xF2E00000 rd))
  16)

(defun %jit-thunk-alloc-aarch64 ()
  (when (> (+ *jit-thunk-bump* 96) 4096)
    (%jit-thunk-new-page))
  (if (null *jit-thunk-page*)
      nil
      (let ((a (+ *jit-thunk-page* *jit-thunk-bump*)))
        (setq *jit-thunk-bump* (+ *jit-thunk-bump* 96))
        a)))

(defun %jit-thunk-emit-shift-aarch64 (addr nargs)
  (let ((k 0))
    (when (>= nargs 3) (setq k (+ k (%jit-emit-word32 (+ addr k) #xAA0203E3))))  ; mov x3,x2
    (when (>= nargs 2) (setq k (+ k (%jit-emit-word32 (+ addr k) #xAA0103E2))))  ; mov x2,x1
    (when (>= nargs 1) (setq k (+ k (%jit-emit-word32 (+ addr k) #xAA0003E1))))  ; mov x1,x0
    k))

(defun %jit-thunk-emit-tail-aarch64 (addr k idx nargs)
  (%jit-emit-quad-placeholder (+ addr k) 0)
  (%jit-write-movz-quad addr k (ash idx 1))
  (%jit-emit-word32 (+ addr k 16) (logior #x52800010 (ash (+ nargs 1) 5)))
  (%jit-emit-quad-placeholder (+ addr k 20) 17)
  (%jit-write-movz-quad addr (+ k 20) #x10000150)
  (%jit-emit-word32 (+ addr k 36) #xB9000230)
  (%jit-emit-quad-placeholder (+ addr k 40) 16)
  (%jit-write-movz-quad addr (+ k 40) (%jit-bridge-entry nargs))
  (%jit-emit-word32 (+ addr k 56) #xD61F0200)
  (+ k 60))

(defun %jit-thunk-fill-aarch64 (addr name nargs)
  (let ((idx *jit-bridge-count*))
    (setf (aref *jit-bridge-names* idx) name)
    (setq *jit-bridge-count* (+ idx 1))
    (%jit-thunk-emit-tail-aarch64 addr (%jit-thunk-emit-shift-aarch64 addr nargs) idx nargs)
    (%jit-icache-flush addr 96)
    addr))

(defun %jit-make-bridge-thunk-aarch64 (name nargs)
  (if (or (null nargs) (> nargs 3) (null (%jit-bridge-ensure))
          (>= *jit-bridge-count* 4096))
      nil
      (let ((addr (%jit-thunk-alloc-aarch64)))
        (if (null addr) nil (%jit-thunk-fill-aarch64 addr name nargs)))))

;;; NARGS-GENERIC LATE-BINDING #'NAME THUNK (aarch64) — the follow-on the frel
;;; comment below names.  A `#'NAME` used as a VALUE (funcall / apply / every /
;;; mapcar #'name, or the keyword MAKE-ARRAY expansion's `#'MAKE-ARRAY`) used to
;;; FAIL the whole page on aarch64 — correct (never bake a stale address) but it
;;; interpreted every such form.  Measured on reel's VP8 decoder: 118 of 121
;;; fn-addr failures were `#'MAKE-ARRAY`, taking vp8-idct / vp8-iwht /
;;; decode-key-frame / decode-macroblocks off the native path (idct ~70 ms a
;;; call under TCG vs microseconds native).
;;;
;;; The existing nargs-SPECIFIC thunk shifts x0..x3 to make room for the name
;;; index in x0 and bumps nargs — so it needs the arity at build time and cannot
;;; serve a value that may be called with any arity.  This thunk instead passes
;;; the index OUT-OF-BAND: it writes idx to a fixed slot through scratch x17 and
;;; `br`s to %JIT-BRIDGE-ANY with every argument register, the caller's stack
;;; pushes and the nargs slot UNTOUCHED.  The bridge's own &rest prologue then
;;; collects exactly the caller's arguments (the #x0530 copy, cap 64) and
;;; APPLYs the name resolved AT CALL TIME — late-bound on every call, which is
;;; also the correct behaviour for a name CLOS redefines later (the staleness
;;; that got the board shipped MODUS_RPI_JIT=0).  Closure-vs-native entry is
;;; delegated to Lisp FUNCALL, so no hand-written dispatch.
;;;
;;; Reentrancy: the slot is written by the thunk immediately before the branch
;;; and read by the bridge's body before it makes any call; nothing intervenes
;;; (cooperative, single-threaded).  Slot #x10000178 is the free 8 bytes in the
;;; convention block (#x150 nargs … #x1D0 all taken; #x1F0 is the write-char
;;; scratch).  One thunk per NAME, cached, so `#'foo` from many pages shares an
;;; address.  Layout (14 words, in a 96-byte slot):
;;;   movz/movk x17 <- idx (raw)         4 words
;;;   movz/movk x16 <- #x10000178        4 words
;;;   str  w17, [x16]                    B9000211
;;;   movz/movk x16 <- bridge-any entry  4 words
;;;   br   x16                           D61F0200
(defun %jit-fnaddr-idx-slot () #x10000178)
(defvar *jit-fnaddr-thunks* nil "Alist NAME-string -> thunk address (one per name).")
(defun %jit-bridge-any (&rest args)
  "Late-bound target of a #'NAME value thunk: resolve the name whose index the
   thunk stored in the fn-addr slot, then apply it to the caller's arguments."
  (let* ((idx (mem-ref #x10000178 :u32))
         (f (%jit-bridge-resolve idx)))
    ;; Cache a NATIVE target (tag-3 code word) in the thunk so the next call
    ;; branches straight to it; a heap function (interpreted closure, tag 9)
    ;; keeps taking this path.  Cleared by %jit-fnaddr-thunk-invalidate on
    ;; redefinition.
    (let ((word (%val->word f)))
      (when (eql (logand word 15) 3)
        (let* ((nm (aref *jit-bridge-names* idx))
               (h (and (stringp nm) *jit-fnaddr-thunks*
                       (assoc nm *jit-fnaddr-thunks* :test (function string=)))))
          ;; RAW-ADDR-AUDIT: the thunk's LDR reads the slot's RAW bits, and a
          ;; Lisp (setf (mem-ref … :u64)) stores the value's tagged form
          ;; (fixnum n is stored as n<<1), so store HALF the (4-aligned)
          ;; address — its raw bits are then exactly the entry address.
          ;; Storing the address itself branched to twice it (a recovered
          ;; fault, surfacing as #(SIMPLE-ERROR NIL)).
          (when h (setf (mem-ref (%jit-fnaddr-thunk-cache-slot (cdr h)) :u64)
                        (ash (- word 3) -1))))))
    (apply f args)))
(defun %jit-bridge-any-entry ()
  (- (%val->word (symbol-function (quote %jit-bridge-any))) 3))
(defun %jit-fnaddr-thunk-cache-slot (addr)
  "Byte offset of the cached native target inside a #'NAME thunk (the 96-byte
   slot is 16-aligned, so +72 is an 8-aligned data word after the 68 bytes
   of code).  0 = not cached: take the slow path."
  (+ addr 72))

(defun %jit-fnaddr-thunk-invalidate (name)
  "A DEFUN / (setf symbol-function) of NAME: drop the cached native target of
   its #'NAME thunk so the next call re-resolves — late binding is what the
   thunk exists for.  No-op when NAME has no thunk (and on x64, which bakes)."
  (let ((h (and (stringp name) *jit-fnaddr-thunks*
                (assoc name *jit-fnaddr-thunks* :test (function string=)))))
    (when h (setf (mem-ref (%jit-fnaddr-thunk-cache-slot (cdr h)) :u64) 0))))

(defun %jit-fnaddr-thunk-fill-aarch64 (addr name)
  ;; Layout:   0: ldr x16, [pc+72]   cached native target (raw code address)
  ;;           4: cbz x16, +8        not cached -> slow path
  ;;           8: br  x16            direct: args / nargs / LR untouched
  ;;          12: slow: movz/movk x17 <- idx; movz/movk x16 <- slot;
  ;;              str w17,[x16]; movz/movk x16 <- %jit-bridge-any; br x16
  ;;          72: cache word (8 bytes), 0 until %jit-bridge-any fills it.
  ;; The cached call costs 3 instructions instead of an &rest cons + APPLY
  ;; per call — (every #'zerop blk) ran the slow path once PER ELEMENT.
  (let ((idx *jit-bridge-count*) (k 0))
    (setf (aref *jit-bridge-names* idx) name)
    (setq *jit-bridge-count* (+ idx 1))
    (%jit-emit-word32 (+ addr k) #x58000250)          ; ldr x16, [pc, #72]
    (setq k (+ k 4))
    (%jit-emit-word32 (+ addr k) #xB4000050)          ; cbz x16, +8
    (setq k (+ k 4))
    (%jit-emit-word32 (+ addr k) #xD61F0200)          ; br x16
    (setq k (+ k 4))
    (setf (mem-ref (%jit-fnaddr-thunk-cache-slot addr) :u64) 0)
    (%jit-emit-quad-placeholder (+ addr k) 17)
    (%jit-write-movz-quad addr k idx)
    (setq k (+ k 16))
    (%jit-emit-quad-placeholder (+ addr k) 16)
    (%jit-write-movz-quad addr k (%jit-fnaddr-idx-slot))
    (setq k (+ k 16))
    (%jit-emit-word32 (+ addr k) #xB9000211)          ; str w17, [x16]
    (setq k (+ k 4))
    (%jit-emit-quad-placeholder (+ addr k) 16)
    (%jit-write-movz-quad addr k (%jit-bridge-any-entry))
    (setq k (+ k 16))
    (%jit-emit-word32 (+ addr k) #xD61F0200)          ; br x16
    (%jit-icache-flush addr 96)
    addr))
(defun %jit-make-fnaddr-thunk-aarch64 (name)
  "Thunk address (16-aligned, so |3 is a valid tag-3 word) for #'NAME, or NIL."
  (let ((hit (and (stringp name) (assoc name *jit-fnaddr-thunks* :test (function string=)))))
    (if hit
        (cdr hit)
        (if (or (null name) (null (%jit-bridge-ensure)) (>= *jit-bridge-count* 4096))
            nil
            (let ((addr (%jit-thunk-alloc-aarch64)))
              (if (null addr)
                  nil
                  (let ((a (%jit-fnaddr-thunk-fill-aarch64 addr name)))
                    (setq *jit-fnaddr-thunks* (cons (cons name a) *jit-fnaddr-thunks*))
                    a)))))))

(defun %jit-reloc-calls (base relocs rt-table)
  "Patch each out-of-module CALL movabs with the resolved native callee address.
   Returns T if every reloc resolved, NIL if any failed (→ caller falls back)."
  (let ((ok t))
    (dolist (r relocs)
      (let* ((name (gethash (cdr r) rt-table))
             (fn (and name (%mvm-resolve-runtime-fn name)))
             ;; %val->word FN = the callee's tagged native word (entry|3; the
             ;; LEA+OR-3 tag from mvm-fn-addr — entry is 16-aligned so low nibble
             ;; is 3).  The JIT's `movabs rax, imm64; call rax` calls the imm
             ;; DIRECTLY (verified: no runtime shift of the imm), so imm must be
             ;; the UNTAGGED entry = word - 3.  The old `(- (ash word -1) 3)`
             ;; HALVED the entry (it assumed %val->word left-shifts the native
             ;; word; it does NOT — the VALUE it returns already IS the native
             ;; word).  A halved entry is either below the load base (unmapped)
             ;; or lands mid-instruction — and for EVAL it landed on an INT3
             ;; (0xCC) byte, so `(eval …)` SIGTRAP'd whenever its (mapped) halved
             ;; target got called.
             ;; WS5 #206: the callee must be NATIVE code.  A function defined at
             ;; RUNTIME (a defun evaluated by an earlier top-level form) is not
             ;; — symbol-function holds a HEAP closure object, and the heap is
             ;; mapped PROT_READ|WRITE with no PROT_EXEC.  Patching its address
             ;; into `movabs rax, imm64; call rax` jumps into non-executable
             ;; memory: SEGV_ACCERR, caught by the boot signal handler, surfaced
             ;; as an escape MID-EXECUTION, and answered by re-running the whole
             ;; form — which is the observed side-effect doubling (task #203).
             ;; Same class as the DGMC GF-array bug that SUB-3'd into the heap.
             ;;
             ;; The low nibble already separates them and cannot collide (see
             ;; CLAUDE.md: cons=1, fn=3, char=5, obj=9 are disjoint, and
             ;; mvm-fn-addr's LEA+OR-3 makes a native fn word ALWAYS end in 3).
             ;;   (symbol-function 'car) -> 15165315        low nibble 3, in-image
             ;;   a runtime (defun kk …)  -> 129844928268201 low nibble 9, on-heap
             ;; So: only patch a tag-3 word.  Anything else fails the reloc,
             ;; which fails the page build, which makes %mvm-eval-jit-run take
             ;; its je=NIL branch and interpret the form ONCE — the correct
             ;; value with no duplicated side effects.  Losing the JIT for forms
             ;; that call runtime-defined functions is the price until a
             ;; late-bound bridge exists; a correct interpret beats a wrong
             ;; native jump.
             (word (if fn (%val->word fn) 0))
             (nativep (eql (logand word 15) 3))
             (raw (if nativep (- word 3) 0)))
        ;; #306 BRIDGE: a resolved-but-non-native callee gets a thunk instead
        ;; of failing the page (x64 only; nargs from the translator's parallel
        ;; alist, NIL on aarch64 → falls through to the old reject).
        (when (and (= raw 0) fn (%jit-bridge-on-p) (not (eq *jit-target-arch* :aarch64)))
          (let* ((na (assoc (car r) *x64-call-reloc-nargs*))
                 (th (and na (%jit-make-bridge-thunk name (cdr na)))))
            (when th
              (setq raw th)
              (setq *jit-bridged-sites*
                    (if *jit-bridged-sites* (+ 1 *jit-bridged-sites*) 1)))))
        (if (> raw 0)
            (%jit-write-imm64 base (car r) raw)
            (progn
              ;; CENSUS: distinguish "no such runtime function" from "resolved
              ;; but it is a heap closure" — the latter is the #206 guard and
              ;; the dominant structural blocker for JIT-only.
              (if fn
                  (setq *jit-r-reloc-call-nonnative*
                        (if *jit-r-reloc-call-nonnative*
                            (+ 1 *jit-r-reloc-call-nonnative*) 1))
                  (setq *jit-r-reloc-call-unresolved*
                        (if *jit-r-reloc-call-unresolved*
                            (+ 1 *jit-r-reloc-call-unresolved*) 1)))
              (when (and *jit-census-on* name)
                (setq *jit-blocked-callees*
                      (%jit-census-note
                        (if fn (concatenate 'string name " [heap-closure]")
                            (concatenate 'string name " [unresolved]"))
                        *jit-blocked-callees*)))
              (setq ok nil)))))
    ok))

(defun %jit-reloc-fn-addrs (base relocs rt-table)
  "Class 2: patch each out-of-module FN-ADDR movabs with the resolved fn's
   TAGGED native word — the SAME object %mvm-resolve-runtime-fn / symbol-function
   returns.  Unlike a CALL target (which is patched UNTAGGED = word-3 because the
   `call rax` jumps to it directly), a FN-ADDR is a VALUE load: the callable
   object flows into eq / eql / funcall, so the imm must be the full tagged word
   (entry|3).  This makes `(eq #'eq (symbol-function 'eq))` T and
   `%ht-canonicalize-test`'s `(eql v (function %eq-fn))` succeed under JIT.
   Returns T if every reloc resolved, NIL if any failed (→ caller falls back).

   TAG-3 REQUIRED, same rule %jit-reloc-calls has had since #206 — but here for
   a GC reason rather than a PROT_EXEC one.  `#'NAME` of a RUNTIME-defined
   function that kept its interpreter trampoline resolves to a HEAP closure
   (tag 9), and baking a heap address into an immediate is exactly the hazard
   the GC-SAFETY GATE in %jit-translate-page-1 exists to prevent: the collector
   moves the closure and the immediate is never re-patched.  Measured on main —
   a const-free lambda that merely mentions `(function tf)` for a const-bearing
   runtime `tf` returns correctly, then after ONE collection faults hard enough
   to escape its own handler-case (`UNHANDLED-ESCAPE … NIL`).  Const patches and
   these two relocation classes are the ONLY places an immediate is baked, so
   with this guard in place a built page provably holds no heap address at all
   and is GC-immune by construction.  A non-tag-3 target now fails the reloc,
   which fails the page build, which interprets the form once — correct, and
   the trampoline is late-bound there anyway."
  (let ((ok t))
    (dolist (r relocs)
      (let* ((name (gethash (cdr r) rt-table))
             (fn (and name (%mvm-resolve-runtime-fn name)))
             (word0 (if fn (%val->word fn) 0))
             (word (if (eql (logand word0 15) 3) word0 0)))
        (if (> word 0)
            (%jit-write-imm64 base (car r) word)
            (progn
              (setq *jit-r-reloc-fnaddr-fail*
                    (if *jit-r-reloc-fnaddr-fail*
                        (+ 1 *jit-r-reloc-fnaddr-fail*) 1))
              (when (and *jit-census-on* name)
                (setq *jit-blocked-fnaddrs*
                      (%jit-census-note name *jit-blocked-fnaddrs*)))
              (setq ok nil)))))
    ok))

;;; ============================================================
;;; WS5 #222 — NATIVE INSTALLATION OF RUNTIME-DEFINED FUNCTIONS
;;; ============================================================
;;;
;;; The last JIT fallback reason.  `mvm-eval` of `(defun f …)` installed F as
;;; %mvm-make-trampoline — a HEAP CLOSURE (tag 9) that re-enters mvm-interpret.
;;; A later top-level form calling F then failed the #206 native-callee
;;; relocation in %jit-reloc-calls (which requires tag nibble 3) and the WHOLE
;;; calling module interpreted.  That single gap was three blockers at once:
;;;   1. it was the only remaining JIT fallback reason (R-RELOC-CALL-NONNATIVE);
;;;   2. actor-spawn does `(actor-set id #x30 (untag fn))` and JUMPS there, and
;;;      an untagged heap closure is a non-executable heap address, so no
;;;      runtime-defined function could ever be an actor entry;
;;;   3. a --load-able ANSI corpus is entirely runtime DEFUNs, so it would run
;;;      100% interpreted.
;;;
;;; The mechanism: the module the JIT already translates for the top-level form
;;; ALREADY CONTAINS native code for every function the form defines — the same
;;; translate-mvm-to-x64 output, in the same exec page, with the same ABI as a
;;; build-time-native function.  Nothing new needs to be compiled.  All that was
;;; missing was to publish each defun's entry ADDRESS instead of a trampoline:
;;; fn-map gives NAME → native label, label-position gives its byte offset, and
;;; the exec page is 4096-aligned while the in-JIT *x64-native-code-offset* is 0
;;; (build-generic-cli.lisp / build-ansi-common.lisp co-init), so every function
;;; entry is 16-BYTE aligned inside the page and the OR-3 discipline of
;;; translate-x64.lisp (mvm-fn-addr = LEA + OR-3) applies verbatim:
;;; `(logior (+ base off) 3)` is a well-formed tag-3 native function word,
;;; disjoint from cons(1)/char(5)/obj(9).  %word->val reinterprets it as the
;;; function VALUE, which is exactly the object symbol-function returns for a
;;; build-time function — so eq/funcall/symbol-function identity is preserved
;;; and %jit-reloc-fn-addrs keeps patching the full TAGGED word.
;;;
;;; LIFETIME.  The exec page must outlive the compilation unit, and it does: it
;;; is mmap'd memory OUTSIDE the GC heap, and x64 never munmaps (the
;;; %jit-free-page reclamation is gated to *jit-target-arch* :aarch64 and is
;;; further gated on the result not being a function).  It is never scanned or
;;; moved by the collector, and a tag-3 word on the stack is not a pointer tag
;;; so the conservative root scan ignores it.  The cost is that a REDEFINITION
;;; leaks its predecessor's page (a few KB); see %jit-install-native-fns.
;;;
;;; THE CONST-POOL RESTRICTION — LIFTED by WS5 #223 (the constant vector).
;;; %jit-patch-consts USED TO bake each const-pool object's CURRENT tagged heap
;;; address into a movabs immediate.  Those objects MOVE under the Cheney
;;; collector, and the re-bake (%jit-entry-for, keyed on %gc-count) only fires
;;; when a page is re-entered THROUGH THE SEAM.  A persistently-installed
;;; function is entered directly by native code, so nothing re-baked it and a GC
;;; left it holding a dangling from-space address.  There is no Lisp-visible
;;; post-GC hook to fix that from here (gc_trampoline is emitted assembly and
;;; never calls back into Lisp), so a function was installed natively only when
;;; NO const patch site fell inside ITS OWN native byte range — quoted literals,
;;; strings, &key and special reads all kept interpreter trampolines.
;;;
;;; The restriction is now gone at its root: under *x64-jit-constvec-p* the
;;; translator emits `movabs d,<fixed BSS root>; mov d,[d]; mov d,[d+idx*8+7]`,
;;; a load from an ordinary heap array the collector forwards, so no address is
;;; ever baked and nothing needs re-baking.  *x64-li-const-patches* is therefore
;;; EMPTY on that path and %jit-fn-native-offsets' cleanliness test admits every
;;; function.  The per-function range analysis is KEPT rather than deleted: it is
;;; the safety interlock that makes the feature correct-by-construction if the
;;; indirection is ever off (a different back-end, a build that leaves the flag
;;; NIL) — cpatches non-empty then re-imposes exactly the old, conservative rule.
;;; See the WS5 #223 block above %jit-sync-constvec for the mechanism.

(defun %jit-fn-native-offsets (ft-list fn-map nlen cpatches)
  "Alist (NAME . NATIVE-BYTE-OFFSET) for every function of FT-LIST whose native
   code range in the freshly translated page contains NO const-pool patch site.
   FT-LIST entries are (name mvm-offset length) in EMISSION order, so a
   function's native range ends at the next function's native start (or NLEN for
   the last one — conservatively over-wide, since the GC trampoline and the
   handler-stack helpers are emitted after the last function; over-wide can only
   REJECT a function, never admit a dirty one).

   A name appearing twice in FT-LIST is skipped entirely: fn-map is keyed by
   NAME, so a duplicate resolves to the LAST label and the range attribution
   would be wrong for the earlier one."
  (let ((raw nil))
    (dolist (e ft-list)
      (let* ((nm (car e))
             (dup nil))
        ;; reject duplicate names (fn-map would alias them)
        (let ((seen 0))
          (dolist (e2 ft-list)
            (when (string= (car e2) nm) (setq seen (+ seen 1))))
          (when (> seen 1) (setq dup t)))
        (unless dup
          (let* ((lbl (gethash nm fn-map))
                 (p (if lbl (label-position lbl) nil)))
            (when (and p (integerp p))
              (setq raw (cons (cons nm p) raw)))))))
    ;; For each candidate, END = the smallest start strictly greater than its
    ;; own (scan, not "next in list", so the result does not depend on FT-LIST
    ;; being sorted by native offset).
    (let ((out nil))
      (dolist (c raw)
        (let ((start (cdr c))
              (end nlen)
              (clean t))
          (dolist (o raw)
            (when (and (> (cdr o) start) (< (cdr o) end)) (setq end (cdr o))))
          (dolist (cp cpatches)
            (when (and (>= (car cp) start) (< (car cp) end)) (setq clean nil)))
          (when clean (setq out (cons c out)))))
      out)))

(defun %jit-fn-native-offsets-aarch64 (ft-list fn-map nlen cpatches)
  "AArch64 sibling of %jit-fn-native-offsets: the (NAME . NATIVE-BYTE-OFFSET)
   alist %jit-install-native-fns needs to publish a module's top-level DEFUNs as
   REAL NATIVE functions (WS5 #222).

   IT EXISTS BECAUSE THE TWO BACK-ENDS RETURN DIFFERENT FN-MAPS, and that alone
   is why aarch64 never got #222.  translate-mvm-to-x64's fn-map is keyed by
   NAME and holds a LABEL (label-position resolves it); translate-mvm-to-aarch64's
   is keyed by MVM BYTECODE OFFSET and holds the native BYTE OFFSET directly
   (see its docstring, and %jit-translate-page-1-aarch64's own
   `(gethash mvm-entry fn-map)` for the module entry).  FT-LIST is
   (NAME MVM-OFFSET LENGTH) on both back-ends, so CADR bridges the two.

   WHAT IT FIXES.  With element 6 of the aarch64 jit-entry hardwired to NIL,
   %mvm-eval-jit-run's `(when (and persist-names (cadr (cddddr je)) …))` never
   fired, so EVERY runtime DEFUN kept the %mvm-make-trampoline heap closure
   (tag 9).  The out-of-module CALL relocation requires a tag-3 NATIVE callee
   (#206 — the heap has no PROT_EXEC), so every later form calling a runtime
   DEFUN failed relocation and the WHOLE calling module interpreted.  That is
   self-propagating: a library is a connected component of runtime DEFUNs, so
   loading one leaves all of it interpreted.  Measured on QEMU virt before this
   change: 227 of 227 fallbacks were out-of-module CALL rejects, 1491 of 1518
   failed sites were [heap-closure], and *jit-native-defun-count* was 0.

   CLEANLINESS RULE, identical to the x64 sibling: a function is admitted only
   if its native byte range holds NO BAKED const patch site, because a baked
   const is a heap address in code that outlives the seam and nothing re-bakes
   it.  On this back-end the page-level R-CONST-BAKED gate has already rejected
   the whole module if any positive-offset patch exists, so the test is normally
   vacuous — it is kept as the interlock that re-imposes the old conservative
   rule automatically should the constvec ever be off.  NEGATIVE offsets are
   constvec SIZING records, not patch sites: they name a slot in the GC-updated
   constant vector, which is append-only and globally indexed, so an installed
   function reading it after any number of collections still gets its own
   constant.  They are GC-safe anywhere and must not reject a function."
  (let ((raw nil))
    (dolist (e ft-list)
      (let ((nm (car e)) (dup nil))
        ;; A name appearing twice makes the range attribution ambiguous — skip
        ;; both, exactly as the x64 sibling does.
        (let ((seen 0))
          (dolist (e2 ft-list)
            (when (string= (car e2) nm) (setq seen (+ seen 1))))
          (when (> seen 1) (setq dup t)))
        (unless dup
          (let ((p (gethash (cadr e) fn-map)))
            (when (integerp p) (setq raw (cons (cons nm p) raw)))))))
    ;; END = the smallest start strictly greater than this one (scanned, so the
    ;; result does not depend on FT-LIST ordering), else NLEN.  Over-wide for
    ;; the last function, which can only REJECT one, never admit a dirty one.
    (let ((out nil))
      (dolist (c raw)
        (let ((start (cdr c)) (end nlen) (clean t))
          (dolist (o raw)
            (when (and (> (cdr o) start) (< (cdr o) end)) (setq end (cdr o))))
          (dolist (cp cpatches)
            (when (and (>= (car cp) 0) (>= (car cp) start) (< (car cp) end))
              (setq clean nil)))
          (when clean (setq out (cons c out)))))
      out)))

(defun %jit-native-defuns-p ()
  "Gate for native installation of runtime-defined functions.  A FUNCTION, not a
   defvar: defvar init-thunks do not run in-image (CLAUDE.md limitation 7), so a
   `(defvar *x* t)` would read NIL — the same reason %jit-enabled-p is a defun."
  t)

(defvar *jit-native-defun-count* nil
  "DIAGNOSTIC: how many runtime-defined functions have been installed as real
   native code by %jit-install-native-fns.  NIL on a JIT-off image.")

(defun %jit-install-native-fns (base fnoffs names)
  "Publish each function of FNOFFS whose NAME is in NAMES (the top-level DEFUNs
   of this module) as a REAL NATIVE function at BASE+offset, in both global
   function tables — *symbol-function-table* by name (the mvm-eval native-call
   bridge / %mvm-resolve-runtime-fn key, hence %jit-reloc-calls) and
   *native-sym-function-table* by name-hash (symbol-function / funcall).  This
   OVERWRITES the interpreter trampoline mvm-eval-forms installed moments
   earlier; puthash is last-write-wins, matching the last-defun-wins rule.
   Returns the number installed.

   The entry must be 16-BYTE aligned for the OR-3 tag to read back as 3; the
   page is page-aligned and the translator aligns every function entry mod 16
   against *x64-native-code-offset* (0 in JIT mode), so this holds — but it is
   CHECKED, and a misaligned entry is skipped rather than published as a word
   whose low nibble could collide with cons(1)/char(5)/obj(9).

   REDEFINITION.  Publishing a new address does NOT retract addresses already
   baked into previously built exec pages, so a page that baked the OLD native
   address of NM keeps calling it — EARLY BINDING, the same semantics a
   build-time native caller already has (CLAUDE.md active limitation 1,
   last-defun-wins).  The CACHED-module half of that is handled, but NOT here:
   it is handled in mvm-eval-forms' trampoline install loop, which is the only
   place NM's PREVIOUS binding is still visible (this function runs after that
   loop has already overwritten it).  See the WS5 #222 REDEFINITION
   INVALIDATION comment there.  The residual — an already-installed native
   function whose page baked a callee that is later redefined — is a real
   divergence from the interpreter's late binding and is reported, not fixed;
   see GATE-RESULT-jit-defun.md.

   The superseded page is NOT unmapped (a live caller may hold its address), so
   each redefinition leaks its predecessor's page — a few KB per redefinition,
   bounded by redefinition count, not by call count."
  (let ((n 0))
    (dolist (e fnoffs)
      (let ((nm (car e)))
        (when (member nm names :test (function string=))
          (let ((addr (+ base (cdr e))))
            (when (eql (logand addr 15) 0)
              (let ((fn (%word->val (logior addr 3))))
                (when (boundp (quote *symbol-function-table*))
                  (%jit-fnaddr-thunk-invalidate nm)
                  (puthash nm *symbol-function-table* fn))
                (when (boundp (quote *native-sym-function-table*))
                  (puthash (compute-name-hash nm) *native-sym-function-table* fn))
                ;; LINKAGE CELL: repoint NM's cell at the new native code so
                ;; every already-built caller that calls through the cell picks
                ;; up this (re)definition — proper CL late binding.
                (%jit-lcell-set nm addr)
                (setq n (+ n 1))))))))
    (setq *jit-native-defun-count*
          (if *jit-native-defun-count* (+ *jit-native-defun-count* n) n))
    n))

;;; ---------------------------------------------------------------------------
;;; JIT-EAGER — compile every still-interpreted runtime DEFUN to native, on
;;; demand.  With *jit-hot-only* T (the default) a DEFUN keeps its interpreter
;;; trampoline forever: DEFUNs are never re-eval'd, so retry-on-hot never fires
;;; for them.  That is right for fast loading but wrong for a heap that is about
;;; to be SNAPSHOT (save-and-die): a core saved that way restores every library
;;; function as bytecode, and the bare-metal interpreter arms are not the native
;;; ones (found on the Zero 2 W: the interpreted %mmap-exec-page echoes its
;;; argument).  Loading with *jit-hot-only* NIL instead pays eager translation
;;; for EVERY top-level form of the load (16 min for reel on an A53).
;;;
;;; So: the trampoline installer records each DEFUN's compiled module — the
;;; same bc/entry/tables %mvm-eval-jit-run would translate — in
;;; *jit-module-registry*, and JIT-EAGER walks it, builds each module's exec
;;; page ONCE (%jit-translate-page: the flip-safe guard, so a translator gap is
;;; a counted skip, never an error) and publishes its DEFUNs as native with
;;; %jit-install-native-fns, exactly as a hot-only-NIL load would have.  The
;;; page is not entered (no %jit-call), so nothing runs and no side effect
;;; repeats.  Call it before %save-image, or after restoring a bytecode core.
;;; The registry is a heap hash table, so it travels in the core too.

(defvar *jit-module-registry* nil
  "NAME (string) -> (bc entry ft-list fn-table rt-table lam-offsets persist-names)
   for every runtime DEFUN installed as an interpreter trampoline.  Boots NIL
   (defvars don't init); %jit-register-module creates it lazily.")

(defun %jit-register-module (names bc entry ft-list fn-table rt-table lam-offsets)
  (when (and (boundp (quote *jit-module-registry*)) (null *jit-module-registry*))
    (setq *jit-module-registry* (make-hash-table :test (function equal))))
  (when (boundp (quote *jit-module-registry*))
    (let ((m (list bc entry ft-list fn-table rt-table lam-offsets names)))
      (dolist (nm names) (puthash nm *jit-module-registry* m)))))

(defun %jit-fn-native-p (name)
  (let ((f (%mvm-resolve-runtime-fn name)))
    (and f (eql (logand (%val->word f) 15) 3))))

(defun %jit-eager-all ()
  "Translate every registered runtime DEFUN that is still an interpreter
   trampoline to native code and publish it.  Returns (INSTALLED MODULES
   FAILED).  Needs the JIT active."
  (if (not (and (%jit-active-p) (boundp (quote *jit-module-registry*))
                *jit-module-registry*))
      (list 0 0 0)
      (let ((pending nil) (installed 0) (modules 0) (failed 0) (done nil))
        ;; collect first: publishing mutates the tables we would otherwise walk
        (maphash (lambda (nm m)
                   (when (not (%jit-fn-native-p nm))
                     (when (not (member m pending :test (function eq)))
                       (setq pending (cons m pending)))))
                 *jit-module-registry*)
        (dolist (m pending)
          (when (not (member (car m) done :test (function eq)))
            (setq done (cons (car m) done))
            (let ((je (%jit-translate-page (car m) (cadr m) (reverse (caddr m))
                                           (car (cddddr m)))))
              (if (and je (cadr (cddddr je)))
                  (progn
                    (setq modules (+ modules 1))
                    (setq installed
                          (+ installed
                             (%jit-install-native-fns (car je) (cadr (cddddr je))
                                                      (car (cddr (cddddr m)))))))
                  (setq failed (+ failed 1))))))
        (when (> installed 0) (%jit-retry-drain))
        (list installed modules failed))))

(defun %init-modus-package ()
  "Bind the MODUS package's generic runtime functions.  Called from kernel-main
   AFTER the symbol-function table is populated (the package itself is created
   early in %init-packages so the reader can name MODUS:… symbols).  A call to a
   non-CL-USER symbol resolves via its QUALIFIED name string, so both the
   symbol's function cell and the qualified SFT key are set."
  (let ((p (find-package "MODUS")))
    (when p
      (dolist (nm (list "JIT-EAGER"))
        (let ((fn (%mvm-resolve-runtime-fn nm)))
          (when fn
            (let ((dst (intern nm p)))
              (set-symbol-function dst fn)
              (when (boundp (quote *symbol-function-table*))
                (puthash (concatenate (quote string) "MODUS::" nm)
                         *symbol-function-table* fn)))))))))

(defun jit-eager (&rest form)
  "Compile-ahead the runtime JIT.  With no argument, translate every registered
   runtime DEFUN that is still an interpreter trampoline to native code and
   return (INSTALLED MODULES FAILED).

   With one argument FORM (a quoted form), FIRST make every DEFUN native, THEN
   compile and run FORM natively and return its value.  Because the callees are
   already native when FORM is compiled, FORM's call sites relocate to the
   native entry points instead of interpreter trampolines — so a driver form
   (a benchmark loop, a decode) runs fully native, not through the trampolines a
   normally-JIT'd caller bakes for runtime-defined callees.  This is the honest
   way to time or run native code that calls runtime DEFUNs."
  (let ((counts (%jit-eager-all)))
    (if (null form)
        counts
        ;; FORM given: run it with the JIT forced on and not hot-gated, so this
        ;; single eval JITs and binds its calls to the natives just published.
        (let ((*jit-hot-only* nil))
          (declare (special *jit-hot-only*))
          (eval (car form))))))

(defun %jit-translate-page-1 (bc ft-list rt-table)
  "Inner: translate BC → native x64, mmap an exec page, copy bytes, relocate
   calls + patch consts.  Returns a jit-entry list (base eoff cpatches
   gc-stamp psize fn-native-offsets) or NIL if RELOCATION failed.  MAY signal
   (translator gap) — the guard wrapper %jit-translate-page turns any signal
   into NIL.

   Element 6 (FN-NATIVE-OFFSETS) is the per-function (name . native-offset)
   alist %jit-install-native-fns needs to publish this module's top-level
   DEFUNs as real native functions; see the WS5 #222 block above."
  (setq *x64-jit-mode* t)
  (multiple-value-bind (nbuf fn-map) (translate-mvm-to-x64 bc ft-list)
    ;; ============================================================
    ;; GC-SAFETY GATE (R-CONST-BAKED) — a page that would bake const-pool
    ;; HEAP addresses is not built at all; the module INTERPRETS instead.
    ;; ============================================================
    ;; %jit-patch-consts writes each const-pool object's CURRENT tagged heap
    ;; address into a `movabs` immediate.  Those objects MOVE under the Cheney
    ;; collector, and the only re-bake (%jit-entry-for, keyed on %gc-count)
    ;; fires when a cached page is re-entered THROUGH THE SEAM.  Three ways
    ;; native code with baked consts is reached WITHOUT crossing that seam —
    ;; all three were live wrong-answer bugs on main, all measured:
    ;;
    ;;   1. A CLOSURE built by this page outlives it.  A runtime DEFMACRO's
    ;;      expander (set-macro-function), a lambda stored in a global or in a
    ;;      data structure, a lambda returned as the EVAL result: each is a
    ;;      #x52 closure whose slot-0 points into this exec page.  It is
    ;;      funcalled directly, never through the seam, so nothing re-bakes it.
    ;;        (eval '(defmacro m (a b) (list '+ a b)))  … one GC …
    ;;        (macroexpand-1 '(m 2 3))  =>  (#<?> 2 3)   [garbage head]
    ;;      That is the bug this gate was written for.
    ;;
    ;;   2. A #222-installed native DEFUN reaches dirty code by CALLING it.
    ;;      %jit-fn-native-offsets only checks a function's OWN byte range, but
    ;;      an in-module call is a direct in-page branch, so a const-CLEAN
    ;;      function installed natively can jump straight into a const-DIRTY
    ;;      sibling:
    ;;        (eval '(progn (defun h1 () (list 'aa "bb")) (defun h2 () (h1))))
    ;;        … one GC …   (h1) => (AA "bb")   (h2) => (#<?> #<?>)
    ;;      h1 kept its trampoline and is fine; h2 was published native and is
    ;;      not.  The per-function check cannot see this; a page-level gate can.
    ;;
    ;;   3. A collection fires DURING this page's own execution.  The entry
    ;;      re-bake happens at entry; a top-level form that allocates past the
    ;;      threshold has every remaining const go stale mid-flight:
    ;;        (eval '(progn <allocate until gc_count moves> (list 'ee "ff")))
    ;;        => (#<?> #<?>)
    ;;      No persistence and no closure involved — an ordinary form, silently
    ;;      wrong.  Nothing short of a page-level gate covers this one.
    ;;
    ;;   4. `#'RUNTIME-DEFUN` as a VALUE.  %jit-reloc-fn-addrs baked whatever
    ;;      word the name resolved to, and a runtime DEFUN that kept its
    ;;      interpreter trampoline is a tag-9 HEAP closure.  A const-free lambda
    ;;      that merely mentions `(function tf)` therefore held a heap address
    ;;      too, and after one collection faulted hard enough to escape its own
    ;;      handler-case.  Closed in %jit-reloc-fn-addrs itself (tag-3 required,
    ;;      matching %jit-reloc-calls) rather than here, because the right answer
    ;;      is to fail that reloc, not to inspect ranges.
    ;;
    ;; Rejecting the page is CORRECT-BY-CONSTRUCTION, in the same sense as the
    ;; #206 tag-3 callee guard: with no const patch sites the page contains NO
    ;; baked heap address at all.  The only other places an immediate is baked
    ;; are the two relocation classes (%jit-reloc-calls / %jit-reloc-fn-addrs),
    ;; and BOTH now require a tag-3 native word — build-time image code or a
    ;; `%mmap-exec-page` page, neither of which the collector ever moves.  So
    ;; `cpatches = NIL` implies GC-immune, with no post-GC hook needed anywhere.
    ;;
    ;; The interpreted module is immune for the reason the DEFUN trampolines
    ;; already were: mvm-interpret's op-LI-CONST does
    ;; `(gethash idx *e2-const-pool*)` at EXECUTION time, so it reads whatever
    ;; the collector has updated the pool to hold.  Measured directly — inside
    ;; ONE lambda body after a collection, an explicit `(gethash idx
    ;; *e2-const-pool*)` returned the live object while the quoted literal
    ;; beside it returned the stale one.
    ;;
    ;; SCOPE — why the gate is "outside the THUNK", not "any const at all".
    ;; The blanket rule (reject on ANY cpatch) is sound but unaffordable: the
    ;; top-level thunk of `(defun f …)` carries the NAME 'F as a const, so
    ;; EVERY runtime defun form would be rejected and #222 would never install
    ;; anything native again — a runtime DEFUN's body would go back to being
    ;; interpreted.  Measured, not assumed: with the blanket rule the class
    ;; probes' own `(dotimes (j 100000) (make-list 40))` allocation loop went
    ;; from seconds to not finishing in two minutes.
    ;;
    ;; The thunk is the ONE function in the module that is entered only through
    ;; the seam, exactly once, with %jit-entry-for's re-bake in front of it.
    ;; Every OTHER function in the page — top-level defuns, lambda/closure
    ;; bodies, flet/labels bodies — either persists past the module (installed,
    ;; captured in a closure, stored) or is the in-page callee of something that
    ;; does.  So: a const patch site inside ANY non-thunk function rejects the
    ;; page; const sites confined to the thunk are allowed to bake.
    ;;
    ;; RESIDUAL — NOW CLOSED for the thunk (#278, hazard-3 fix): the thunk's
    ;; own consts no longer bake at all.  With *x64-jit-constvec-p* on, the
    ;; translator emits the THUNK's :li-const as a load through the GC-updated
    ;; constant vector (WS5 #223's indirection, scoped to the one function that
    ;; is entered only through the seam), recording a NEGATIVE-offset sizing
    ;; entry instead of a byte patch site.  A mid-flight collection therefore
    ;; can no longer stale a running top-level form's remaining literals — the
    ;; proven ql:quickload killer (the "~&>>> " loader-loop SIGSEGV).  NON-thunk
    ;; consts still emit baked movabs sites and this gate still rejects any
    ;; page carrying one, so the accepted-page set is unchanged.  Deleting the
    ;; gate entirely (vector loads everywhere) is the full #226 follow-up.
    ;; *jit-r-const-baked* counts how often the gate fires.
    (let ((%cpatches nil))
      ;; Only POSITIVE offsets are baked movabs patch sites; negative entries
      ;; are constant-vector sizing records (GC-safe anywhere) — skip them.
      (dolist (%p *x64-li-const-patches*)
        (when (>= (car %p) 0) (setq %cpatches (cons %p %cpatches))))
      (when %cpatches
        (let* ((%tlbl (gethash "%MVM-EVAL-THUNK" fn-map))
               (%tstart (if %tlbl (label-position %tlbl) nil)))
          (if (not (integerp %tstart))
              ;; No identifiable thunk range → cannot prove any const site is
              ;; seam-guarded.  Reject.
              (progn
                (setq *jit-r-const-baked*
                      (if *jit-r-const-baked* (+ 1 *jit-r-const-baked*) 1))
                (return-from %jit-translate-page-1 nil))
              ;; THUNK END = the smallest OTHER function start strictly greater
              ;; than %TSTART, else the whole buffer.  Scanned (not "next in
              ;; ft-list") so the answer does not depend on ft-list ordering.
              ;; When the thunk is emitted LAST the range runs to the end of the
              ;; buffer, which over-covers the translator's trailing GC/handler
              ;; helpers — those are hand-emitted asm and carry no :li-const, so
              ;; nothing dirty can hide there.
              (let ((%tend (code-buffer-position nbuf)))
                (dolist (%e ft-list)
                  (let* ((%l (gethash (car %e) fn-map))
                         (%p (if %l (label-position %l) nil)))
                    (when (and (integerp %p) (> %p %tstart) (< %p %tend))
                      (setq %tend %p))))
                (dolist (%cp %cpatches)
                  (when (or (< (car %cp) %tstart) (>= (car %cp) %tend))
                    (setq *jit-r-const-baked*
                          (if *jit-r-const-baked* (+ 1 *jit-r-const-baked*) 1))
                    (return-from %jit-translate-page-1 nil))))))))
    ;; WS5 #223 (thunk-scoped): mirror every newly registered const-pool entry
    ;; into the GC-rooted constant vector the thunk's emitted loads read from.
    ;; Must happen before the page runs; a no-op when the indirection is off.
    (%jit-sync-constvec (%jit-constvec-need *x64-li-const-patches*))
    ;; WS5 #223 SAFETY GUARD.  Verify the vector actually covers this module's
    ;; indices before any of its code can run.  If it does not, abandon the page
    ;; and let the form interpret — the emitted slot load has no bounds check and
    ;; an uncovered index is an unmapped read, i.e. an undiagnosable SIGSEGV.
    (unless (%jit-constvec-covers-p *x64-li-const-patches* "build")
      (return-from %jit-translate-page-1 nil))
    (let* ((nlen (code-buffer-position nbuf))
           (nbytes (code-buffer-bytes nbuf))
           (relocs *x64-call-relocs*)
           (fa-relocs *x64-fn-addr-relocs*)
           (cpatches *x64-li-const-patches*)
           (elabel (gethash "%MVM-EVAL-THUNK" fn-map))
           (eoff (if elabel (label-position elabel) 0))
           ;; JIT-FIX (Fix 2): the exec page must be big enough for the ACTUAL
           ;; native code length.  A fixed 4096-byte page overran on every
           ;; flet/labels/CLOS-dispatch module (their native code is 1k-15k+
           ;; bytes) — the copy loop below wrote past the mapped region → a
           ;; SIGSEGV the mvm-eval seam caught as a (nil-condition) fallback, so
           ;; those whole shape classes ran interpret-only (native%≈0).  Round
           ;; nlen UP to a 4096-byte multiple (+1 page of slack for the copy's
           ;; tail / alignment) so the full native module fits.
           (npages (+ 1 (ash nlen -12)))
           (psize (ash npages 12))
           (page (%mmap-exec-page psize))
           (base (sap-address (make-sap page))))
      ;; SAFE-FLIP GUARD (x64 parity with the aarch64 sibling): mmap failure
      ;; returns -errno, a small/negative integer.  Writing to it would fault;
      ;; return NIL so the seam interprets this form.
      (when (< base 4096)
        (setq *jit-r-mmap-fail*
              (if *jit-r-mmap-fail* (+ 1 *jit-r-mmap-fail*) 1))
        (return-from %jit-translate-page-1 nil))
      ;; Copy native bytes into the exec page.
      (let ((k 0))
        (loop while (< k nlen)
              do (progn
                   (setf (mem-ref (+ base k) :u8) (aref nbytes k))
                   (setq k (+ k 1)))))
      (if (and (%jit-reloc-calls base relocs rt-table)
               (%jit-reloc-fn-addrs base fa-relocs rt-table))
          (progn
            (%jit-patch-consts base cpatches)
            ;; 5th = PSIZE (read only on the aarch64 reclaim path; harmless
            ;; here).  6th = the per-function native-offset alist for WS5 #222
            ;; native DEFUN installation.  7th = THIS module's const pool —
            ;; %jit-patch-consts reads the GLOBAL *e2-const-pool*, which is
            ;; only correct at this module's own seam; the cross-page sweep
            ;; (%jit-refresh-all-pages) must patch from the page's OWN pool.
            (list base eoff cpatches (%gc-epoch) psize
                  (%jit-fn-native-offsets ft-list fn-map nlen cpatches)
                  *e2-const-pool*))
          nil))))

(defun %jit-translate-page-1-aarch64 (bc mvm-entry ft-list rt-table)
  "WS4-S5 (aarch64) sibling of %jit-translate-page-1.  translate-mvm-to-aarch64
   wants an eql-keyed func-idx→MVM-offset HASH (not x64's (name offset length)
   list), so build it from FT-LIST.  Translate BC under *aarch64-jit-mode*, mmap
   an exec page, copy the native words, relocate out-of-module CALLs (untagged
   callee addr = word-3) + #'NAME fn-addrs (tagged word) + patch li-const quads
   (pool object tagged word), flush the I-cache, and return a jit-entry
   (base eoff cpatches gc-stamp psize).
   Returns NIL if any reloc failed to resolve (→ interpret fallback).  MAY signal
   a translator gap — the %jit-translate-page guard turns it into NIL.

   WS5 #203 CORRECTION (this was THE aarch64 library-macro bug).  The old
   docstring here claimed \"cpatches is NIL: GC is off on aarch64-linux so the
   const-pool never moves and %jit-entry-for's post-GC re-bake never fires\".
   GC is NOT off on aarch64-linux — it collects exactly like x64, just sooner.
   So every JIT'd aarch64 page baked const-pool HEAP addresses that went
   permanently stale at the first collection, with (a) no GC-safety gate and
   (b) cpatches = NIL, which made %jit-entry-for's re-bake a no-op.  A runtime
   DEFMACRO's expander is a closure living in such a page, so after one GC:
       (eval '(defmacro m (a b) (list '+ a b)))  … one GC …
       (macroexpand-1 '(m 2 3))  =>  (#<?> 2 3)
   — the whole \"library FUNCTIONS work but library MACROS fail\" class
   (alexandria/bordeaux-threads/iterate/cl-utilities on the aarch64 ladder).
   x64 closed this with the GC-SAFETY GATE in %jit-translate-page-1; that gate
   is now ported here verbatim in intent, and cpatches is carried so the
   thunk's own consts are re-baked on a post-GC cache hit."
  (setq *aarch64-jit-mode* t)
  ;; WS5 aarch64 JIT: function entries must be 16-BYTE aligned inside the exec
  ;; page.  A closure's fn-addr slot is tagged with +tag-function+ (3) and
  ;; +op-call-ind+ validates `addr & 15 == 3` before SUB-3/BLR, so the raw
  ;; entry address needs low nibble 0.  The exec page from %mmap-exec-page is
  ;; page (4096) aligned, so the constraint reduces to native-offset mod 16 = 0
  ;; — which is what translate-mvm-to-aarch64's fn-entry NOP pad computes when
  ;; *aarch64-fn-align-offset* is 0.  In-image that global has no value (defvar
  ;; init-thunks don't run — CLAUDE.md item 7) and the pad loop degenerated to
  ;; zero padding, so entries landed on arbitrary 4-byte boundaries.  Set it
  ;; explicitly here (JIT-only; the host image builds set their own value
  ;; host-side and never call this function).
  (setq *aarch64-fn-align-offset* 0)
  (setq *a64-jit-page-reject* nil)
  (let ((ftbl (make-hash-table :test (quote eql))))
    (let ((i 0)) (dolist (e ft-list) (setf (gethash i ftbl) (cadr e)) (setq i (+ i 1))))
    (multiple-value-bind (nbuf fn-map) (translate-mvm-to-aarch64 bc ftbl)
      ;; #307 page rejection (flag, not a condition — see *a64-jit-page-reject*).
      (when *a64-jit-page-reject*
        (setq *jit-fallback-count*
              (if *jit-fallback-count* (+ 1 *jit-fallback-count*) 1))
        (return-from %jit-translate-page-1-aarch64 nil))
      ;; ============================================================
      ;; GC-SAFETY GATE (R-CONST-BAKED) — aarch64 port of the x64 gate in
      ;; %jit-translate-page-1.  See that function's long comment for the four
      ;; hazard shapes; the reasoning is arch-independent, only the encoding
      ;; (MOVZ/MOVK quad vs movabs imm64) and the offset units differ.
      ;;
      ;; A const patch site inside ANY function OTHER than the top-level thunk
      ;; means a heap address is baked into code that OUTLIVES the seam (a
      ;; lambda body / closure — e.g. a runtime DEFMACRO expander — or an
      ;; in-page callee of one).  Nothing re-bakes those, so reject the page
      ;; and let the module INTERPRET: op-LI-CONST reads *e2-const-pool* at
      ;; execution time, which the collector keeps live.  Const sites confined
      ;; to the thunk are allowed — the thunk is entered only through the seam,
      ;; behind %jit-entry-for's post-GC re-bake.
      ;;
      ;; Offsets are BYTE offsets on both sides: *aarch64-li-const-patches*
      ;; records (movz-byte-pos . pool-idx) and FN-MAP maps an MVM function
      ;; offset to a native BYTE offset (same units %jit-write-movz-quad and
      ;; the lrel patch loop below already use).
      ;; #282 LAYER 2: reject any page carrying a BAKED const site.
      ;;
      ;; A baked li-const is a heap address written into the instruction
      ;; stream.  %jit-entry-for re-bakes such sites after a collection, but
      ;; only when the seam RE-ENTERS the thunk — so a collection that fires
      ;; while the thunk is STILL RUNNING (any long loop; the htgrow2 repro's
      ;; 8000-iteration puthash loop crosses its first GC at ~i=5500) leaves
      ;; the remainder of that very run loading stale from-space addresses,
      ;; which become arbitrary garbage at the next semispace flip.  That was
      ;; the gdbstub-captured APPLY-of-fixnum crash (PC=0x2).
      ;;
      ;; With the constvec on (*aarch64-jit-constvec-p*), li-const emits an
      ;; indirect load through *aarch64-jit-constvec-root* and records a
      ;; NEGATIVE offset instead — no baked address, nothing to go stale, and
      ;; the collector forwards the vector through that root.  Those entries
      ;; are sizing records, so they never trip this gate.  A baked entry can
      ;; still appear (constvec off, or idx > 4095 exceeding the LDR's scaled
      ;; offset), and it is rejected wherever it sits — including inside the
      ;; thunk, which is where x64's gate differs: x64 can admit thunk-confined
      ;; baked sites because its full-scope constvec covers the mid-run window
      ;; regardless.  Rejected forms interpret; op-LI-CONST reads
      ;; *e2-const-pool* at execution time, which the collector keeps live.
      (dolist (%cp *aarch64-li-const-patches*)
        (when (>= (car %cp) 0)
          (setq *jit-r-const-baked*
                (if *jit-r-const-baked* (+ 1 *jit-r-const-baked*) 1))
          (return-from %jit-translate-page-1-aarch64 nil)))
      ;; Mirror every newly registered pool entry into the GC-rooted vector the
      ;; emitted loads read from, and size it to cover this module's indices.
      ;; Must happen before the page can run; a no-op when the indirection is
      ;; off (no negative entries → need 0).
      (%jit-sync-constvec (%jit-constvec-need *aarch64-li-const-patches*))
      ;; SAFETY GUARD: the emitted slot load has NO bounds check, so an index
      ;; the installed vector does not cover is an unmapped read — an
      ;; undiagnosable SIGSEGV.  Verify coverage before any of this code runs;
      ;; on failure abandon the page and let the form interpret.
      (unless (%jit-constvec-covers-p *aarch64-li-const-patches* "build-aa64")
        (return-from %jit-translate-page-1-aarch64 nil))
      (let* ((nwords (a64-buffer-position nbuf))
             (code (a64-buffer-code nbuf))
             (nlen (* nwords 4))
             (crel *aarch64-call-relocs*)
             (frel *aarch64-fn-addr-relocs*)
             (lrel *aarch64-fn-addr-local-relocs*)
             (cpat *aarch64-li-const-patches*)
             (eoff (gethash mvm-entry fn-map))
             (npages (+ 1 (ash nlen -12)))
             (psize (ash npages 12))
             (base (%mmap-exec-page psize))
             ;; WHY: 0 = no failure yet, 1 = out-of-module CALL, 2 = #'NAME
             ;; value load, 3 = in-module fn-addr.  FIRST cause wins, so the
             ;; page-level counters partition the rejected pages exactly.
             (k 0) (ok t) (why 0))
        ;; SAFE-FLIP GUARD: MAP_FAILED (mmap returns -errno = a NEGATIVE/tiny Lisp
        ;; integer, vs a huge-positive address) → DON'T write/call a bad page;
        ;; return NIL so the seam falls back to mvm-interpret for this form.
        (when (< base 4096)
          (setq *jit-r-mmap-fail*
                (if *jit-r-mmap-fail* (+ 1 *jit-r-mmap-fail*) 1))
          (return-from %jit-translate-page-1-aarch64 nil))
        (loop
          (when (>= k nwords) (return nil))
          (let ((w (aref code k)) (o (* k 4)))
            (setf (mem-ref (+ base o) :u8) (logand w 255))
            (setf (mem-ref (+ base (+ o 1)) :u8) (logand (ash w -8) 255))
            (setf (mem-ref (+ base (+ o 2)) :u8) (logand (ash w -16) 255))
            (setf (mem-ref (+ base (+ o 3)) :u8) (logand (ash w -24) 255)))
          (setq k (+ k 1)))
        ;; Out-of-module CALL relocations (untagged callee addr = word-3).
        ;; WS5 #206: the callee must carry the FN tag — see %jit-reloc-calls for
        ;; the full account.  A RUNTIME-defined function (a defun evaluated by an
        ;; earlier top-level form) is a HEAP CLOSURE, tag 9, and the heap has no
        ;; PROT_EXEC; branching to it faults mid-execution and the fallback then
        ;; re-runs the form, duplicating its side effects.  The tag test is
        ;; arch-independent (cons=1/fn=3/char=5/obj=9 are disjoint everywhere),
        ;; so aarch64 needs exactly the same guard as x64 — this is the same
        ;; defect, not a port of an x64-specific workaround.
        (dolist (r crel)
          (let* ((name (gethash (cdr r) rt-table))
                 (fn (and name (%mvm-resolve-runtime-fn name)))
                 (word (if fn (%val->word fn) 0))
                 (addr (if (eql (logand word 15) 3) (- word 3) 0)))
            ;; #306 BRIDGE (aarch64 arm): non-native callee -> per-site thunk.
            (when (and (= addr 0) fn (%jit-bridge-on-p))
              (let* ((na (assoc (car r) *aarch64-call-reloc-nargs*))
                     (th (and na (%jit-make-bridge-thunk-aarch64 name (cdr na)))))
                (when th
                  (setq addr th)
                  (setq *jit-bridged-sites*
                        (if *jit-bridged-sites* (+ 1 *jit-bridged-sites*) 1)))))
            (if (> addr 0)
                ;; LINKAGE CELL: point the caller's ADRP/LDR pair at NAME's
                ;; stable cell (the LDR dereferences it at call time) and make
                ;; the cell hold the current native address.  A later
                ;; redefinition repoints the cell, so this caller follows.
                ;; %JIT-PATCH-CALL-SITE owns the shape and reads the same
                ;; *jit-linkage-cells* the emit did, so the two cannot disagree;
                ;; NIL back means "cannot encode" (no cell arena, or an ADRP
                ;; page delta out of range) and rejects the page rather than
                ;; leaving a wild branch behind.
                (unless (%jit-patch-call-site base (car r) name addr)
                  (setq *jit-r-crel-encode-fail*
                        (if *jit-r-crel-encode-fail* (+ 1 *jit-r-crel-encode-fail*) 1))
                  (when (eql why 0) (setq why 1))
                  (setq ok nil))
                (progn
                  ;; CENSUS (x64 parity): "resolved but it is a HEAP closure —
                  ;; a runtime DEFUN" is a completely different blocker from
                  ;; "no such runtime function", and only the first is fixable
                  ;; by publishing runtime DEFUNs natively (WS5 #222).
                  (if fn
                      (setq *jit-r-reloc-call-nonnative*
                            (if *jit-r-reloc-call-nonnative*
                                (+ 1 *jit-r-reloc-call-nonnative*) 1))
                      (setq *jit-r-reloc-call-unresolved*
                            (if *jit-r-reloc-call-unresolved*
                                (+ 1 *jit-r-reloc-call-unresolved*) 1)))
                  ;; Name recording is OPT-IN (*jit-census-on*): %jit-census-note
                  ;; concatenates a fresh string and linearly rescans a
                  ;; 96-entry alist at EVERY failed site, which measurably slows
                  ;; a library load.  The tallies above are always on.
                  ;; boundp-guarded because a defvar initform may not have run
                  ;; (Limitation 7), and an UNBOUND-VARIABLE signalled here is
                  ;; swallowed by %jit-translate-page's handler-case, which would
                  ;; re-badge every reject as R-TRANSLATE-ERR and destroy the
                  ;; very attribution this census exists to provide.
                  (when (and name (boundp (quote *jit-census-on*)) *jit-census-on*
                             (boundp (quote *jit-blocked-callees*)))
                    (setq *jit-blocked-callees*
                          (%jit-census-note
                            (if fn (concatenate (quote string) name " [heap-closure]")
                                (concatenate (quote string) name " [unresolved]"))
                            *jit-blocked-callees*)))
                  (when (eql why 0) (setq why 1))
                  (setq ok nil)))))
        ;; Out-of-module #'NAME fn-addr relocations (a #'NAME used as a VALUE:
        ;; funcall / apply / mapcar #'name).
        ;;
        ;; LATE-BIND FIX (MODUS_RPI_JIT=1 vs CLOS).  The old code BAKED the
        ;; resolved tagged fn word into the MOVZ quad here — it resolved #'NAME
        ;; ONCE, at page-build.  A name that CLOS defines or redefines AFTER the
        ;; page is built (every generic function; any forward reference) is then
        ;; frozen as a STALE object.  That is precisely what made the aarch64 JIT
        ;; die in ql:quickload: QL-DIST::ENABLED-DISTS does (funcall #'enabledp d),
        ;; the page had baked the pre-CLOS `enabledp' stub, and dispatch went to
        ;; the stub instead of the installed GF — the measured reason the board
        ;; shipped MODUS_RPI_JIT=0.  The INTERPRETER's op-fn-addr (interp.lisp)
        ;; re-resolves the name via %mvm-resolve-runtime-fn on EVERY execution, so
        ;; it is always late-bound and correct (why JIT-off completes ql).  Match
        ;; it: never bake — FAIL the page so this one form interprets (a page /
        ;; setup failure BEFORE any native code runs, so no double-execution).
        ;; Only forms that take a #'NAME as a value fall back; regular calls (crel,
        ;; #306 bridge) and in-module #'local closures (lrel, below) still JIT.
        ;; Keeping these forms NATIVE via a nargs-generic late-binding thunk
        ;; (%jit-make-bridge-thunk-aarch64 is nargs-specific today) is the follow-on.
        (dolist (r frel)
          (let* ((name (gethash (cdr r) rt-table))
                 ;; NARGS-GENERIC LATE-BINDING THUNK (see %jit-make-fnaddr-thunk-
                 ;; aarch64): the #'NAME value becomes a stable tag-3 word in the
                 ;; exec thunk page that re-resolves NAME on every call — never a
                 ;; baked object, so no staleness, and the form stays NATIVE.
                 ;; Was: fail the page unconditionally (118/121 of reel's fn-addr
                 ;; rejects were `#'MAKE-ARRAY` from the keyword expansion).
                 (th (and name (%jit-bridge-on-p)
                          (%jit-make-fnaddr-thunk-aarch64 name))))
            (if th
                (%jit-write-movz-quad base (car r) (logior th 3))
                (progn
                  (setq *jit-r-reloc-fnaddr-fail*
                        (if *jit-r-reloc-fnaddr-fail*
                            (+ 1 *jit-r-reloc-fnaddr-fail*) 1))
                  (when (and name (boundp (quote *jit-census-on*)) *jit-census-on*
                             (boundp (quote *jit-blocked-fnaddrs*)))
                    (setq *jit-blocked-fnaddrs*
                          (%jit-census-note name *jit-blocked-fnaddrs*)))
                  (when (eql why 0) (setq why 2))
                  (setq ok nil)))))
        ;; WS5: IN-MODULE fn-addr relocations.  These are the sites that build a
        ;; CLOSURE (make-closure stores the lambda's fn-addr in slot 0) and any
        ;; #'LOCAL-FN value-load.  The whole-image path defers them to
        ;; apply-aarch64-fn-addr-patches, which the JIT never runs, so before
        ;; this loop every JIT-built closure carried fn-addr 0 and funcall of it
        ;; took +op-call-ind+'s bad-callable trap → PROGRAM-ERROR with the body
        ;; never entered.  Patch value = (base + fn-native-offset) | +tag-function+.
        ;; If the entry is not 16-aligned the tag nibble would not read back as
        ;; 3 and call-ind would reject it, so fail the reloc instead of shipping
        ;; a closure that traps — the seam then interprets this form (correct,
        ;; just not native).
        (dolist (r lrel)
          (let* ((noff (gethash (cdr r) fn-map))
                 (addr (if noff (+ base noff) 0)))
            (if (and noff (eql (logand addr 15) 0))
                (%jit-write-movz-quad base (car r) (logior addr 3))
                (progn
                  (setq *jit-r-lrel-fail*
                        (if *jit-r-lrel-fail* (+ 1 *jit-r-lrel-fail*) 1))
                  (when (eql why 0) (setq why 3))
                  (setq ok nil)))))
        ;; Quoted-literal / string li-const patches (pool object tagged word).
        ;; Post-gate these are THUNK-ONLY sites, so %jit-entry-for's post-GC
        ;; re-bake (which runs before the seam re-enters the thunk) covers them.
        (%jit-patch-consts-aarch64 base cpat)
        (%jit-icache-flush base nlen)
        ;; PAGE-LEVEL ATTRIBUTION.  One bump per REJECTED page, by first cause,
        ;; so these partition the R-PAGE-NIL total (the site counters above can
        ;; multiply-count a single page).
        (unless (and ok eoff)
          (cond ((eql why 1) (setq *jit-r-aa-crel-pages*
                                   (if *jit-r-aa-crel-pages*
                                       (+ 1 *jit-r-aa-crel-pages*) 1)))
                ((eql why 2) (setq *jit-r-aa-frel-pages*
                                   (if *jit-r-aa-frel-pages*
                                       (+ 1 *jit-r-aa-frel-pages*) 1)))
                ((eql why 3) (setq *jit-r-aa-lrel-pages*
                                   (if *jit-r-aa-lrel-pages*
                                       (+ 1 *jit-r-aa-lrel-pages*) 1)))
                (t (setq *jit-r-eoff-nil*
                         (if *jit-r-eoff-nil* (+ 1 *jit-r-eoff-nil*) 1)))))
        (if (and ok eoff)
            ;; 3rd element = CPATCHES, so %jit-entry-for can re-bake after a
            ;; collection moved the pool objects (was NIL, which silently
            ;; disabled the re-bake — see the docstring).
            ;; 5th element = PSIZE, so a transient form's page can be munmap'd
            ;; (%jit-free-page base psize) after its native call — see
            ;; %mvm-eval-jit-run's reclamation.
            ;; 6th = the per-function native-offset alist for WS5 #222 native
            ;; DEFUN installation.  This was hardwired NIL, which silently
            ;; disabled #222 on this back-end: every runtime DEFUN kept its
            ;; tag-9 heap trampoline, so every later form CALLING one failed the
            ;; #206 native-callee relocation and the whole calling module
            ;; interpreted — call-relocation contagion across a library's entire
            ;; call graph.  See %jit-fn-native-offsets-aarch64 for why a
            ;; separate function is needed (the two back-ends' fn-maps are keyed
            ;; differently) and for the measurement.
            ;; 7th = this module's const pool for the cross-page sweep (see the
            ;; x64 creator's comment).
            (list base eoff cpat (%gc-epoch) psize
                  (%jit-fn-native-offsets-aarch64 ft-list fn-map nlen cpat)
                  *e2-const-pool*)
            nil)))))

(defvar *jit-translate-err-count* 0
  "DIAGNOSTIC: count of translate-time errors caught by %jit-translate-page's
   guard (distinct from MV/reloc/page-unavailable fallbacks).")
(defvar *jit-last-translate-err* nil
  "DIAGNOSTIC: the last condition caught by %jit-translate-page's guard.")

;;; #306 RETRY QUEUE — dissolve the R-CALL-NONNAT contagion.
;;;
;;; A DEFUN module whose exec page fails to build at DEFINITION time (almost
;;; always because a CALLEE was not native YET — %jit-reloc-calls rejects a
;;; heap-closure callee) installs its functions as interpreter trampolines
;;; and, until now, they stayed interpreted FOREVER: every later caller of
;;; those functions then failed ITS reloc too.  Load ORDER, not capability,
;;; decided what ran native (~50% fallback on bare-metal aarch64, where the
;;; interpreter is ~1000x slower than native code — see
;;; reference_interp_speed_fully_attributed).
;;;
;;; The cure is retry-at-the-minting-point: the ONLY place a native
;;; symbol-function entry is made is %jit-install-native-fns after a
;;; successful page build, so remember each failed DEF* module (its bc,
;;; entry, ft-list, rt-table, names) and re-attempt the translation whenever
;;; a NEW native function appears (that is exactly when a queued module's
;;; missing callee may have become native).  Success installs natives via the
;;; normal path and overwrites the trampolines (last-write-wins).  Bounded:
;;; at most (%jit-retry-max-attempts) tries per module, queue capped, drain
;;; guarded against reentrancy (%jit-install-native-fns is called from the
;;; drain itself).
(defvar *jit-retry-queue* nil
  "List of (attempts bc entry ft-list rt-table names) for DEF* modules whose
   page failed to build.  Boots NIL (defvars don't init) — that is the empty
   queue.")
(defvar *jit-retry-busy* nil "Reentrancy guard for %jit-retry-drain.")
(defvar *jit-retry-on* nil
  "Opt-in gate for the retry queue.  Boots NIL = OFF: on hosted aarch64 the
   retried pages broke iterate's probes (sum/collect => ERR) with the bridge
   on OR off, while retry-off is correct and fastest — a retried translation
   still lacks some seam state beyond the const pool.  (setq *jit-retry-on* t)
   enables it for experiments.")
(defvar *jit-retry-succeeded* nil
  "CENSUS: modules that went native on a retry.  NIL = 0.")
(defvar *jit-retry-exhausted* nil
  "CENSUS: modules dropped after (%jit-retry-max-attempts) failures.  NIL = 0.")
(defun %jit-retry-max-attempts () 4)
(defun %jit-retry-queue-cap () 256)
(defun %jit-retry-install-gap () 16)
(defvar *jit-retry-doc* nil
  "An entry is re-attempted only after this many NEW native installs since
   its last attempt, so a module whose callee is defined 60 defuns later
   still gets its chance without a translate storm (4 attempts x 16 = 64).")

(defun %jit-retry-enqueue (bc entry ft-list rt-table names)
  "Remember a DEF* module whose page failed, if the queue has room."
  (when (and names *jit-retry-on*
             (< (length *jit-retry-queue*) (%jit-retry-queue-cap)))
    (setq *jit-retry-queue*
          (cons (list 0 bc entry ft-list rt-table names
                      (or *jit-native-defun-count* 0)
                      ;; The module's OWN const pool: %jit-translate-page bakes
                      ;; literals from the GLOBAL *e2-const-pool*, which is
                      ;; only correct at this module's own seam.  A retry runs
                      ;; at a LATER module's seam, so it must restore this.
                      *e2-const-pool*)
                *jit-retry-queue*))))

(defun %jit-retry-drain ()
  "Re-attempt every queued module once.  Called after a successful native
   install (a new native callee exists).  A module that builds is installed
   and removed; one that fails is kept with attempts+1, or dropped at the cap."
  (when (and *jit-retry-queue* (not *jit-retry-busy*))
    (setq *jit-retry-busy* t)
    (unwind-protect
        (let ((keep nil) (now (or *jit-native-defun-count* 0)))
          (dolist (e *jit-retry-queue*)
            (let* ((attempts (car e)) (bc (cadr e)) (entry (caddr e))
                   (ft-list (cadddr e)) (rt-table (car (cddddr e)))
                   (names (cadr (cddddr e)))
                   (last (caddr (cddddr e)))
                   (pool (cadddr (cddddr e)))
                   (je (if (< (- now last) (%jit-retry-install-gap))
                           nil
                           ;; Lexical-save + setq-restore of the pool (the
                           ;; codebase's escape-safe idiom, not a dynamic LET).
                           (let ((saved *e2-const-pool*))
                             (setq *e2-const-pool* pool)
                             (let ((r (%jit-translate-page bc entry ft-list rt-table)))
                               (setq *e2-const-pool* saved)
                               r)))))
              (cond
                ((and je (cadr (cddddr je)))
                 (%jit-install-native-fns (car je) (cadr (cddddr je)) names)
                 ;; The retried page MUST be in *jit-page-cache*: that is what
                 ;; %jit-refresh-all-pages sweeps to re-bake const-pool
                 ;; immediates after a GC.  Create the cache if %jit-entry-for
                 ;; has not yet (a `when` here skipped the store on early
                 ;; boots, leaving the page with STALE literals after the next
                 ;; collection — a GC-timing-dependent FILE-ERROR under KVM).
                 (unless *jit-page-cache*
                   (setq *jit-page-cache* (make-hash-table :test (quote eq))))
                 (setf (gethash bc *jit-page-cache*) je)
                 (setq *jit-retry-succeeded*
                       (if *jit-retry-succeeded* (+ 1 *jit-retry-succeeded*) 1)))
                ((< (- now last) (%jit-retry-install-gap))
                 (setq keep (cons e keep)))            ; not due yet, untouched
                ((< (+ 1 attempts) (%jit-retry-max-attempts))
                 (setq keep (cons (list (+ 1 attempts) bc entry ft-list rt-table names now pool)
                                  keep)))
                (t
                 (setq *jit-retry-exhausted*
                       (if *jit-retry-exhausted* (+ 1 *jit-retry-exhausted*) 1))))))
          (setq *jit-retry-queue* keep))
      (setq *jit-retry-busy* nil))))

(defun %jit-translate-page (bc mvm-entry ft-list rt-table)
  "FLIP-SAFETY GUARD (Fix 1): translate + build a JIT exec page for BC, but
   turn ANY error signalled while translating/relocating (e.g. a translator
   gap such as `Unknown register: 0` in a flet/labels/CLOS-dispatch shape)
   into a clean NIL return, so the caller falls back to mvm-interpret and the
   program's RESULT is never changed.  Every path from a top-level/load eval
   to translate-mvm-to-x64 runs through this function (both %mvm-eval-jit-run
   call shapes call %jit-entry-for or %jit-translate-page), so a translator
   gap can NEVER escape as an uncaught error nor produce a wrong value — it
   only costs one interpret fallback.  NB: the outer seam handler-case in
   %mvm-eval-run-tuple / mvm-eval-forms is kept as belt-and-suspenders; this inner
   guard exists because a translate error must degrade to NIL (interpret)
   even in any context whose outer catch might not see it."
  (handler-case
      (if (eq *jit-target-arch* :aarch64)
          (%jit-translate-page-1-aarch64 bc mvm-entry ft-list rt-table)
          (%jit-translate-page-1 bc ft-list rt-table))
    (t (c)
       (setq *jit-translate-err-count*
             (if (boundp (quote *jit-translate-err-count*))
                 (+ 1 *jit-translate-err-count*) 1))
       (setq *jit-last-translate-err* c)
       (when *jit-census-on*
         (setq *jit-translate-err-msgs*
               (%jit-census-note (%jit-err-tag c) *jit-translate-err-msgs*)))
       (setq *jit-fallback-count*
             (if *jit-fallback-count* (+ 1 *jit-fallback-count*) 1))
       nil)))

(defvar *jit-all-fresh-stamp* nil
  "The %gc-count as of the last %JIT-REFRESH-ALL-PAGES sweep.  Boots NIL
   (defvars don't init) so the first call always sweeps.")
(defvar *jit-refresh-busy* nil
  "Reentrancy guard: MAPHASH inside the sweep may itself route calls
   through APPLY, which calls the sweep.")

(defun %jit-refresh-all-pages ()
  "Re-patch const immediates of EVERY cached runtime-JIT page whose
   gc-stamp is stale.  %JIT-ENTRY-FOR covers only the mvm-eval cache
   path; a DIRECT call into a JIT page (APPLY/FUNCALL of a resolved
   runtime defun, or a JIT-to-JIT baked call) otherwise executes stale
   const-pool immediates after any GC — task #278's install drain, and
   a 4-line repro: (eval defun with a quoted literal) + %gc-collect +
   (funcall 'it) => garbage/fault.  Cheap when clean: one %gc-count
   read + eql against the sweep stamp."
  (when (and *jit-page-cache* (not *jit-refresh-busy*))
    (let ((now (%gc-epoch)))
      (unless (eql now *jit-all-fresh-stamp*)
        (setq *jit-refresh-busy* t)
        (unwind-protect
            (let ((stale nil))
              ;; Collect first — repatching mutates the table (puthash
              ;; fresh entries) and mutating under maphash is undefined.
              ;; ONLY entries carrying their OWN pool (7th element) are
              ;; sweepable: %jit-patch-consts reads the GLOBAL
              ;; *e2-const-pool*, which belongs to whatever module is
              ;; current — patching another page against it CORRUPTS that
              ;; page (measured: the first sweep build broke setup).
              ;; Pool-less entries stay stale-stamped and are re-baked at
              ;; their own seam by %jit-entry-for as before.
              (maphash (lambda (bc hit)
                         (when (and (not (eql now (cadddr hit)))
                                    (caddr (cddddr hit)))
                           (setq stale (cons (cons bc hit) stale))))
                       *jit-page-cache*)
              (dolist (pair stale)
                (let* ((bc (car pair))
                       (hit (cdr pair))
                       (pool (caddr (cddddr hit)))
                       (fresh (list (car hit) (cadr hit) (caddr hit) now
                                    (car (cddddr hit)) (cadr (cddddr hit))
                                    pool)))
                  (if (eq *jit-target-arch* :aarch64)
                      (progn
                        (%jit-patch-consts-aarch64-pool (car fresh) (caddr fresh) pool)
                        (when (caddr fresh)
                          (%jit-icache-flush (car fresh)
                                             (if (car (cddddr fresh))
                                                 (car (cddddr fresh))
                                                 4096))))
                      (%jit-patch-consts-pool (car fresh) (caddr fresh) pool))
                  (setf (gethash bc *jit-page-cache*) fresh)))
              (setq *jit-all-fresh-stamp* now))
          (setq *jit-refresh-busy* nil))))))

(defun %jit-entry-for (bc mvm-entry ft-list rt-table)
  "Return a ready-to-call jit-entry (base eoff cpatches gc-stamp) for BC, using
   *jit-page-cache* (keyed by BC identity) if present — RE-PATCHING const
   immediates when a GC has fired since the page was built (the pool moved).
   Builds + caches a fresh page on a miss.  NIL if the page can't be built."
  (unless *jit-page-cache*
    (setq *jit-page-cache* (make-hash-table :test (quote eq))))
  (let ((hit (gethash bc *jit-page-cache*)))
    (if hit
        (let ((now (%gc-epoch)))
          (if (eql now (cadddr hit))
              hit
              ;; A GC moved the const-pool objects; re-bake immediates, then
              ;; re-store a fresh entry with the new stamp (avoid mutating a
              ;; nested list place — build + puthash is compiler-safe).
              ;; Preserve the 7th element (the page's own pool) for the
              ;; cross-page sweep.
              (let ((fresh (list (car hit) (cadr hit) (caddr hit) now
                                 (car (cddddr hit)) (cadr (cddddr hit))
                                 (caddr (cddddr hit)))))
                ;; Arch-aware: x64 bakes movabs imm64, aarch64 a MOVZ/MOVK
                ;; quad, and self-modified aarch64 code needs an I-cache flush
                ;; over the page before it is branched into again.
                (if (eq *jit-target-arch* :aarch64)
                    (progn
                      (%jit-patch-consts-aarch64 (car fresh) (caddr fresh))
                      (when (caddr fresh)
                        (%jit-icache-flush (car fresh)
                                           (if (car (cddddr fresh))
                                               (car (cddddr fresh))
                                               4096))))
                    (%jit-patch-consts (car fresh) (caddr fresh)))
                ;; OFF-MAIN, DO NOT CACHE: BC and the tuple are worker-region
                ;; objects and this table is region-0-reachable — see
                ;; %MVM-ON-MAIN-THREAD-P.
                (when (%mvm-on-main-thread-p)
                  (setf (gethash bc *jit-page-cache*) fresh))
                fresh)))
        (let ((je (%jit-translate-page bc mvm-entry ft-list rt-table)))
          (when (and je (%mvm-on-main-thread-p))
            (setf (gethash bc *jit-page-cache*) je))
          je))))

(defun %mvm-eval-jit-run (bc entry ft-list fn-table rt-table lam-offsets cache-p
                          persist-names)
  "WS4-S5b: run compiled module BC as NATIVE JIT'd code, wrapping the result
   like the interpret path (%mvm-wrap-escaping-result).  If the JIT can't build
   a page we throw to the caller's handler-case, which falls back to
   mvm-interpret (safe: no user code ran).

   MULTIPLE VALUES (WS5 #218): native writes a real BSS MV block — the count as
   a tagged fixnum at #x10000090, the count-1 extras at #x10000098+ — and this
   function READS IT BACK, publishing (count . secondaries) in *mvm-last-mv*,
   the same shape mvm-interpret leaves behind.  The seam therefore re-emits the
   values directly and MV forms run exactly ONCE.  Previously they signalled an
   MV sentinel and the interpreter re-ran the whole form, duplicating every
   side effect that had already happened.  Only a count outside [0,21] (past
   the 20-slot MV-VALUES area) still falls back; see *jit-infra-fallback*.
   CACHE-P: T = reuse/store an exec page in *jit-page-cache* (cached modules,
   where the SAME bc re-evals — the speedup source); NIL = translate once, no
   cache (the fresh-bc DEF* path, whose page would never be re-hit).

   WS4 #160 Piece 2 — CONSERVATIVE-CORRECT transient reclamation (aarch64):
   a TRANSIENT form has EMPTY lam-offsets, meaning NO lambda/closure body was
   compiled INTO its exec page — the page holds only the top-level thunk's
   straight-line code, which nothing references once the native call returns.
   Such a page is translated WITHOUT caching and munmap'd immediately after the
   call (bounding a long run of distinct transient forms — e.g. a REPL/stress
   evaluating thousands of `(+ i 1)` — to O(1) live RWX pages).  CODE-BEARING
   forms (non-empty lam-offsets: a lambda body IS in the page, so an escaping
   closure may reference it) keep the cache/retain path and are NEVER freed —
   so there is NO use-after-free by construction.  As extra insurance a page is
   also retained if the form's RESULT is itself a function.  Reclaim is gated to
   *jit-target-arch* :aarch64; on x64 TRANSIENT is always NIL so behaviour and
   emitted-runtime are unchanged (the %jit-free-page trap is a no-op there)."
  ;; #160 Piece 2 (round 2): lam-offsets is NOT a usable transient signal on
  ;; aarch64 — it is ALWAYS non-nil (measured length 7 for every top-level form,
  ;; including `(+ i 1)`), so the earlier `(null lam-offsets)` never fired and
  ;; nothing was reclaimed (still exhausting ~2350).  Use the RESULT TYPE
  ;; instead: on aarch64 translate the run-tuple page WITHOUT caching (top-level
  ;; forms rarely re-eval the SAME bc, so the cache mostly just accumulates —
  ;; the exhaustion source) and, after the native call, FREE the page UNLESS the
  ;; result is a FUNCTION (an escaping closure whose code lives IN this page).
  ;; A `defun`/`setf-fn` form returns a symbol/non-function, and its installed
  ;; body is a SEPARATE module (its own page, built on first call) — so freeing
  ;; the top-level installer page is safe (validated by the defun/closure
  ;; retention probes).  x64 is untouched (aa64 is nil → original cache path).
  ;; STEP-A: reclamation is gated behind *jit-reclaim-on* (default NIL = the
  ;; CACHED baseline — %jit-entry-for, no free).  With it NIL, aa64 behaves
  ;; exactly like x64's cache path, so STEP A measures the true baseline; the
  ;; MAP_FAILED guard in %jit-translate-page-1-aarch64 still applies to both.
  (let* ((aa64 (and (eq *jit-target-arch* :aarch64)
                    (boundp (quote *jit-reclaim-on*)) *jit-reclaim-on*))
         (je (if (and cache-p (not aa64))
                 (%jit-entry-for bc entry ft-list rt-table)
                 (%jit-translate-page bc entry ft-list rt-table))))
    (if je
        (progn
          ;; WS5 #222: publish this module's top-level DEFUNs as REAL NATIVE
          ;; functions, replacing the interpreter trampolines mvm-eval-forms
          ;; installed a moment ago.  Done HERE — after every relocation and
          ;; const patch succeeded, so the page is fully formed, and BEFORE
          ;; %jit-call, so the thunk itself (and anything it calls) already
          ;; sees the native definition, exactly as it saw the trampoline.
          ;; On a page-build failure (je NIL) nothing is published and the
          ;; trampolines stand — the interpret fallback is unchanged.
          (when (and persist-names (cadr (cddddr je)) (%jit-native-defuns-p))
            (%jit-install-native-fns (car je) (cadr (cddddr je)) persist-names)
            ;; #306: a new native callee exists — give queued failed modules
            ;; their retry.
            (%jit-retry-drain))
          ;; Native code stamps MV-count into real BSS; seed it to 1 so a
          ;; single-value form reads back 1 (the thunk epilogue sets it, but
          ;; be defensive).  A form that sets it >1 falls back for correct MV.
          (setf (mem-ref #x10000090 :u64) 1)
          ;; WS5 #223 SECOND CHECK, at the LAST moment before control enters the
          ;; page.  The build-time check proves the vector was correct when the
          ;; page was made; this one proves it is STILL correct now.  A page can
          ;; be minutes and many collections old by the time it is re-entered
          ;; from *jit-page-cache*, and an installed native function's page is
          ;; re-entered without passing through here at all — so a failure here
          ;; localises the invalidation to the window between build and call,
          ;; which is the one thing the fault address cannot tell us.
          (%jit-constvec-covers-p (caddr je) "precall")
          ;; WS5 #203 POINT OF NO RETURN.  Everything above this line is JIT
          ;; setup: if it signals, no user code has run and the interpret
          ;; fallback is safe.  The instant we branch into the page, the form's
          ;; side effects begin, so any condition escaping from here on is the
          ;; user's and re-running the form would duplicate them.  Set the flag
          ;; BEFORE the call, not after — a condition signalled by the very
          ;; first instruction of the form must already count as "native ran".
          (setq *jit-native-ran* t)
          (let ((raw (%jit-call (+ (car je) (cadr je)))))
            ;; WS5 #218 — READ BACK THE NATIVE MV BLOCK.  This replaces the old
            ;; "MV form → re-interpret" sentinel, which was the last path that
            ;; re-ran a form whose side effects had already happened (measured:
            ;; `(progn (incf *k*) (floor 7 2))` left *k* = 2).  Its reach was
            ;; never limited to `(values …)`: ANY form whose last operation
            ;; leaves MV-count > 1 qualifies — floor / truncate / ceiling /
            ;; round / gethash / subtypep / read-from-string /
            ;; multiple-value-bind / -list / -call / -prog1.
            ;;
            ;; The block is the SAME location on every back-end: +mv-count-addr+
            ;; = #x10000090 holds the count as a TAGGED fixnum and the (count-1)
            ;; extras live at #x10000098 + i*8.  compile-values, op-set-mv-count
            ;; and both translators (translate-x64.lisp / translate-aarch64.lisp)
            ;; all use the compiler constant, so NO *jit-target-arch* branch is
            ;; needed here.  `mem-ref … :u64` yields the raw word, which IS the
            ;; tagged value, so mvc reads back as an ordinary integer and each
            ;; extra reads back as its Lisp object (exactly what compiled
            ;; MULTIPLE-VALUE-LIST does, compiler.lisp compile-multiple-value-list).
            ;;
            ;; ORDERING IS LOAD-BEARING — this block must be the first thing
            ;; after %jit-call and must not CALL anything until the last extra
            ;; is latched:
            ;;   * every function epilogue emits op-set-mv-count 1, so one call
            ;;     resets the count slot and we would lose the extras' length;
            ;;   * the collector scans exactly (count-1) words from #x10000098
            ;;     (translate-x64.lisp, the MV-area root scan).  If the count
            ;;     were reset while extras were still unread, a GC triggered by
            ;;     the cons loop would strand them at from-space addresses —
            ;;     the same class as the interp bug documented at interp.lisp:166.
            ;; Everything below compiles INLINE (mem-ref, fixnump, <, +, -, *,
            ;; cons), so the count stays authoritative throughout, and the
            ;; back-to-front read re-reads each BSS slot AFTER the previous
            ;; cons's possible GC — so a forwarded extra is picked up post-move.
            (let ((mvc (mem-ref #x10000090 :u64))
                  (secs nil)
                  (mv-ok nil))
              ;; Reproducible range: 0..21.  The MV-VALUES area is 20 slots
              ;; (#x10000098 .. #x10000130; +closure-env-addr+ starts at
              ;; #x10000140), so a count above 21 would read words that are NOT
              ;; MV storage and hand the GC bogus roots.  Counts that large are
              ;; already truncated by compile-values' own 16-slot storage cap on
              ;; BOTH paths, so re-interpreting them yields nothing better — but
              ;; the fallback is kept (and counted) rather than guessing.
              (if (fixnump mvc)
                  (if (< mvc 0) nil (if (< mvc 22) (setq mv-ok t) nil))
                  nil)
              (if mv-ok
                  (let ((i (- mvc 2)))
                    (loop
                      (when (< i 0) (return nil))
                      (setq secs (cons (mem-ref (+ #x10000098 (* i 8)) :u64) secs))
                      (setq i (- i 1))))
                  nil)
              (if mv-ok
                  (progn
                    ;; Publish the block in the SAME shape mvm-interpret does
                    ;; (interp.lisp: (cons count secondaries)) so the seam's
                    ;; `(values-list (cons %prim (cdr %mv)))` re-emission is
                    ;; identical for the native and interpreted paths.  mvc = 1
                    ;; means single value: NIL, which also clears a STALE
                    ;; *mvm-last-mv* left by an earlier interpret run.
                    (setq *mvm-last-mv* (if (eql mvc 1) nil (cons mvc secs)))
                    (setq *jit-native-count*
                          (if *jit-native-count* (+ 1 *jit-native-count*) 1))
                    (let ((result (%mvm-wrap-escaping-result raw bc fn-table rt-table lam-offsets)))
                      ;; Reclaim the (uncached) aarch64 page unless the RESULT is a
                      ;; function/closure whose code is in it.  car(cddddr je) = PSIZE.
                      (when (and aa64 (car (cddddr je)) (not (functionp result))
                                 ;; NEVER reclaim a page this module PUBLISHED
                                 ;; functions out of (WS5 #222): their entry
                                 ;; addresses are live in both function tables
                                 ;; and in any later page that baked them, so
                                 ;; munmap would be a use-after-free of code.
                                 ;; Reclamation is currently gated off
                                 ;; (*jit-reclaim-on* has no binding at all, so
                                 ;; AA64 is NIL), which is why this was latent;
                                 ;; now that aarch64 installs natives it is the
                                 ;; invariant made explicit, not a behaviour
                                 ;; change.
                                 (not (and persist-names (cadr (cddddr je))
                                           (%jit-native-defuns-p))))
                        (%jit-free-page (car je) (car (cddddr je))))
                      result))
                  ;; RESIDUAL SHAPE ONLY: a count outside [0,21] (or a non-fixnum
                  ;; word aliasing the slot).  Still double-executes, still
                  ;; counted — *jit-mv-fallback-count* is the proof that it does
                  ;; not fire in practice.  DON'T free the page (result unknown).
                  (progn
                    (setq *jit-infra-fallback* t)
                    (setq *jit-mv-fallback-count*
                          (if *jit-mv-fallback-count* (+ 1 *jit-mv-fallback-count*) 1))
                    (error "jit-mv-fallback"))))))
        ;; NO PAGE: %jit-translate-page's flip-safety guard returned NIL (a
        ;; translator gap it converted from a signal, or a page-build failure).
        ;; Its contract is "a translator gap can NEVER escape as an uncaught
        ;; error — it only costs one interpret fallback", so DEGRADE HERE, at
        ;; the single point of detection, rather than signalling and relying on
        ;; every caller to convert the signal back into an interpret.
        ;;
        ;; WS5 #203: `(error "jit-page-unavailable")` broke that contract on the
        ;; path that matters most for loading a library.  Both existing callers
        ;; (mvm-eval-forms and the %e2ic seam) do wrap this in a handler-case
        ;; that interprets — but MACROEXPANSION of a runtime-defined macro runs
        ;; the expander from inside %mvm-eval-compile-tuple, i.e. while COMPILING
        ;; a later top-level form, and that path has no such wrapper.  Net
        ;; effect on aarch64 (JIT on by default since #199): a macro defined by
        ;; one top-level form and used by ANY later form — the shape of every
        ;; real library, and nearly all of alexandria — died with
        ;; "jit-page-unavailable", uncatchable even by a handler-case around the
        ;; use, because the failure happened before that form ever ran.
        ;;
        ;; Interpreting here is exactly what the two callers' handlers already
        ;; do, so their behaviour is unchanged; they stay as belt-and-suspenders.
        (progn
          (setq *jit-r-page-nil*
                (if *jit-r-page-nil* (+ 1 *jit-r-page-nil*) 1))
          (setq *jit-fallback-count*
                (if *jit-fallback-count* (+ 1 *jit-fallback-count*) 1))
          ;; DIAGNOSTIC: record WHICH module fell back and WHY, so a library
          ;; load can be profiled for translator gaps by name (persist-names =
          ;; the DEFUNs this top-level form defines; *jit-last-condition* = the
          ;; translate-time signal the guard converted).  Hot-path fallbacks are
          ;; what keep a native-installed library from running at native speed —
          ;; found chasing reel's VP8 decoder (~45 of 505 fns fell back and
          ;; dominated decode time).  Read via (boundp '*jit-fallback-names*).
          (setq *jit-fallback-names*
                (cons (list persist-names
                            (if (boundp (quote *jit-last-condition*)) *jit-last-condition* nil))
                      (if (boundp (quote *jit-fallback-names*)) *jit-fallback-names* nil)))
          ;; #306: a DEF* module whose page failed — remember it for retry once
          ;; more callees have gone native (see *jit-retry-queue*).
          (when (and persist-names (%jit-native-defuns-p))
            (%jit-retry-enqueue bc entry ft-list rt-table persist-names))
          (%mvm-wrap-escaping-result
            (mvm-interpret bc :entry-point entry
                           :function-table fn-table :runtime-table rt-table
                           :return-raw nil :lambda-offsets lam-offsets)
            bc fn-table rt-table lam-offsets)))))

(defun %mvm-eval-run-tuple (tuple)
  "Interpret a cached compiled module tuple (bc entry ft-list fn-table rt-table lam-offsets).
   Conditions PROPAGATE to the caller (production EVAL semantics): an error
   signalled inside the evaluated form must reach the caller's handler-case.
   The old `(handler-case ... (error (e) (list :interp-err e)))` swallowed the
   signal into a return VALUE, so every `(eval ...) must signal` ANSI test
   (vector-push*.error, defmethod.error, signals-error helpers) failed under
   the WS3 flip.  Callers that want the capture behaviour (the e2diff gate)
   wrap mvm-eval in their own handler-case."
  ;; MULTIPLE VALUES propagate (WS3 flip): mvm-interpret stashes the run's
  ;; simulated MV state in *mvm-last-mv* (read IMMEDIATELY — see interp.lisp);
  ;; re-emit via values-list so the native caller's multiple-value-list /
  ;; m-v-bind around (eval …) sees every value, matching the tree-walker.
  ;; The tail if/values-list shape is values-preserving per
  ;; tail-form-is-values-p, so this function's epilogue does NOT reset
  ;; MV-count back to 1.
  ;;
  ;; TUPLE layout (WS4-S5b): (bc entry ft-list fn-table rt-table lam-offsets)
  ;;   car=bc caddr=ft-list cadddr=fn-table (car(cddddr))=rt-table
  ;;   (cadr(cddddr))=lam-offsets.  ft-list was inserted at index 2 for the JIT.
  (let* ((%bc (car tuple))
         (%entry (cadr tuple))
         (%ftl (caddr tuple))
         (%fnt (cadddr tuple))
         (%rt (car (cddddr tuple)))
         (%lam (cadr (cddddr tuple)))
         ;; WS4-S5b: when *use-jit*, run native; fall back to interpret on a JIT
         ;; SETUP failure (unsupported form / page-build failure), and on the MV
         ;; sentinel.  %jit-active-p (not %jit-enabled-p) so *jit-inhibit*
         ;; (Class 3) works even in the gate image whose %jit-enabled-p is a
         ;; baked constant.
         ;;
         ;; WS5 #203: the handler used to be `(t (c) ...interpret...)` — it
         ;; answered EVERY condition by re-running the whole form, including a
         ;; genuine error signalled by the user's own code after that code had
         ;; already run.  Save the guard flags lexically and clear them before
         ;; the attempt (setq, not a dynamic rebind — see 279f2cc: a dynamic
         ;; rebind does not survive the native/interpret longjmp boundary the
         ;; way a lexical save + explicit restore does), then decide in the
         ;; handler on the basis of whether native code actually ran.
         (%jnr-save *jit-native-ran*)
         (%jif-save *jit-infra-fallback*)
         (%ignore1 (setq *jit-native-ran* nil))
         (%ignore2 (setq *jit-infra-fallback* nil))
         (%prim (if (%jit-active-p)
                    ;; PERSIST-NAMES = NIL on the CACHED-tuple path: this module
                    ;; was already compiled and its DEFUNs already published by
                    ;; the mvm-eval-forms call that built the tuple, so there is
                    ;; nothing new to install (and the tuple does not carry the
                    ;; name list).
                    (handler-case (%mvm-eval-jit-run %bc %entry %ftl %fnt %rt %lam t nil)
                      (t (c)
                         (let ((%ran *jit-native-ran*)
                               (%infra *jit-infra-fallback*))
                           ;; Restore the enclosing attempt's flags before we
                           ;; either re-signal or recurse into the interpreter;
                           ;; a nested mvm-eval (a macroexpander invoked from
                           ;; JIT'd code) must not inherit ours.
                           (setq *jit-native-ran* %jnr-save)
                           (setq *jit-infra-fallback* %jif-save)
                           (if (and %ran (not %infra) (%condition-p c))
                               ;; USER CONDITION, raised after the form's side
                               ;; effects began.  Re-running would duplicate
                               ;; them.  Propagate it, exactly as the non-JIT
                               ;; path does — production EVAL semantics.
                               (progn
                                 (setq *jit-resignal-count*
                                       (if *jit-resignal-count*
                                           (+ 1 *jit-resignal-count*) 1))
                                 (error c))
                               ;; Fall back.  THREE ways to get here:
                               ;;  (1) JIT setup failed before any user code ran
                               ;;      — safe and invisible, the original intent;
                               ;;  (2) the MV out-of-range residual (WS5 #218
                               ;;      reduced this from "every MV form" to a
                               ;;      count > 21) — known double-execute;
                               ;;  (3) native ran and escaped with something that
                               ;;      is NOT a well-formed condition (%condition-p
                               ;;      false).  (3) is the unresolved-runtime-
                               ;;      function sentinel: an INFRASTRUCTURE failure
                               ;;      that happens DURING native execution, which
                               ;;      is the case the re-flip gate's
                               ;;      "infrastructure vs user condition" dichotomy
                               ;;      did not anticipate.  Re-signalling it yields
                               ;;      a malformed #(NIL NIL) at toplevel, so we
                               ;;      still fall back (and still double) until the
                               ;;      JIT can resolve runtime-defined functions.
                               (progn
                                 ;; CENSUS: split the seam-handler fallback into
                                 ;; "native already RAN" (the doubling case, an
                                 ;; infrastructure escape) vs pure setup failure.
                                 ;; NB: %infra excludes the MV residual, which
                                 ;; reaches this handler with %ran already T --
                                 ;; counting it here would double-count R-MV.
                                 (when (and %ran (not %infra))
                                   (setq *jit-r-native-escape*
                                         (if *jit-r-native-escape*
                                             (+ 1 *jit-r-native-escape*) 1)))
                                 (setq *jit-fallback-count*
                                       (if *jit-fallback-count*
                                           (+ 1 *jit-fallback-count*) 1))
                                 (%mvm-wrap-escaping-result
                                   (mvm-interpret %bc :entry-point %entry
                                                  :function-table %fnt :runtime-table %rt
                                                  :return-raw nil :lambda-offsets %lam)
                                   %bc %fnt %rt %lam))))))
                    (%mvm-wrap-escaping-result
                      (mvm-interpret %bc :entry-point %entry
                                     :function-table %fnt :runtime-table %rt
                                     :return-raw nil :lambda-offsets %lam)
                      %bc %fnt %rt %lam)))
         ;; *mvm-last-mv* must be read IMMEDIATELY after the run (see the note
         ;; at the top of this function and interp.lisp) — nothing may come
         ;; between %prim and %mv.
         (%mv *mvm-last-mv*)
         ;; CLEARED AS SOON AS LATCHED: after %mv is bound the global is stale
         ;; by this seam's own contract ("read IMMEDIATELY"), and on a WORKER
         ;; it holds a cons allocated in the worker's region — a global is
         ;; region-0-reachable, so leaving it published is one forbidden
         ;; region-0 -> worker reference per worker eval (measured: exactly
         ;; the last audit residue after the CL:INTERN fix).
         (%mvclr (setq *mvm-last-mv* nil))
         ;; WS5 #203: restore on the SUCCESS path too, but only AFTER %mv has
         ;; been latched.  The handler restores before it re-signals or falls
         ;; back; a run that completes normally would otherwise leave
         ;; *jit-native-ran* set to T, and the NEXT form's handler would read
         ;; that stale T and re-signal a setup failure it should have quietly
         ;; interpreted.
         (%ignore3 (setq *jit-native-ran* %jnr-save))
         (%ignore4 (setq *jit-infra-fallback* %jif-save)))
    (if %mv
        (if (eql (car %mv) 0)
            (values)
            ;; Secondaries escape to the native caller like the primary does,
            ;; so they get the same wrap (see the interp.lisp trampoline).
            (values-list (cons %prim
                               (let ((%acc nil))
                                 (dolist (%x (cdr %mv) (nreverse %acc))
                                   (setq %acc (cons (%mvm-wrap-escaping-result
                                                     %x %bc %fnt %rt %lam)
                                                    %acc)))))))
        %prim)))

(defun %mvm-eval-compile-tuple (forms)
  "WS4 STAGE 2 seam tap.  Compile FORMS to an MVM bytecode module via the
   SAME self-hosted compiler pipeline mvm-eval-forms uses (mvm-compile-toplevel
   + Pass1/1.5/2), but STOP before interpreting.  Returns a 6-tuple:

     (bc entry ft-list fn-table rt-table lam-offsets)

   where BC is the module bytecode, ENTRY the %MVM-EVAL-THUNK native entry
   OFFSET into BC, FN-TABLE the offset-array mvm-eval-forms hands mvm-interpret
   (:function-table), RT-TABLE the runtime-call table (out-of-module CALLs;
   EMPTY = hazard-free = JIT-executable without Stage-3 relocation),
   LAM-OFFSETS the lambda-body offset set, and FT-LIST the
   (name offset length) function-table list translate-mvm-to-x64 wants
   (the ADAPTER — built from the SAME function-info structs the compiler
   produced, so it is consistent with FN-TABLE / ENTRY).

   This does NOT install trampolines, does NOT cache, and does NOT interpret
   — it is a pure compile.  mvm-eval-forms is UNCHANGED (behavior-identical);
   this is a parallel, dead-code path reachable only from the WS4-S2 probe.
   It intentionally omits the persist/reentrancy bookkeeping because a JIT
   probe form is a single self-contained expression (no cross-call defuns)."
  (unless (and *opcode-table* (> (hash-table-count *opcode-table*) 0))
    (setq *opcode-table* (make-hash-table :test (quote eql)))
    (%populate-opcode-table))
  (let ((*functions* (make-hash-table :test (quote equal)))
        (*function-table* nil)
        (*constant-table* nil)
        (*label-counter* 0)
        (*unresolved-calls* (make-hash-table :test (quote equal)))
        (*macro-table* (make-hash-table :test (quote eql)))
        (*globals* (make-hash-table :test (quote eql)))
        (*constants* (make-hash-table :test (quote eql)))
        (*loop-exit-label* nil)
        (*block-labels* nil)
        (*tagbody-tags* nil)
        (*pending-flet-ir* nil)
        (*init-thunk-names* nil)
        (all-ir nil)
        (buf nil)
        (global-offset 0)
        (entry nil)
        (rt-table (make-hash-table))
        (rt-next #x40000000))
    (register-mvm-bootstrap-macros)
    (let* ((rforms (reverse forms))
           (last-form (car rforms))
           (last-defun-p (and (consp last-form) (symbolp (car last-form))
                              (string-equal (symbol-name (car last-form)) "DEFUN")
                              (symbolp (cadr last-form))))
           (expr (if last-defun-p (list (quote quote) (cadr last-form)) last-form))
           (defs (if last-defun-p forms (reverse (cdr rforms))))
           (toplevel (append defs (list (list (quote defun) (quote %mvm-eval-thunk) nil expr)))))
      (dolist (f toplevel)
        (let ((result (mvm-compile-toplevel f)))
          (cond
            ((null result) nil)
            ((and (consp result) (eq (car result) :multi-result))
             (dolist (sub (cdr result))
               (when (and (car sub) (cdr sub))
                 (setq all-ir (cons (cons (car sub) (cdr sub)) all-ir)))))
            (t (when (and (car result) (cdr result))
                 (setq all-ir (cons (cons (car result) (cdr result)) all-ir)))))))
      (dolist (pend *pending-flet-ir*)
        (when (and (consp pend) (car pend) (cdr pend))
          (setq all-ir (cons pend all-ir))))
      (setq all-ir (reverse all-ir))
      ;; Fresh buffer (do NOT touch *mvm-eval-buffer* — keep mvm-eval-forms's reuse
      ;; buffer pristine for the oracle interpret path that runs after us).
      ;; NOTE: reusing a persistent buffer here was tried and REVERTED — the
      ;; cached tuple keeps its bytecode by reference into this array, so the
      ;; next compile overwrote cached forms (ANSI probe 8447 + the whole
      ;; 8644-8848 block).  A reuse needs an explicit copy-out first.
      (setq buf (make-mvm-buffer :bytes (make-array 65536)))
      ;; Pass 1: assign cumulative bytecode offsets + register in *functions*.
      (dolist (e all-ir)
        (let* ((info (car e)) (ir (cdr e))
               (fn-size (let ((s 0)) (dolist (insn ir) (setq s (+ s (ir-instruction-size insn)))) s)))
          (setf (function-info-bytecode-offset info) global-offset)
          (setf (function-info-bytecode-length info) fn-size)
          (setf (gethash (function-info-name info) *functions*) info)
          (setq global-offset (+ global-offset fn-size))))
      ;; Pass 1.5: out-of-module CALL / LI-FUNC names → synthetic runtime stubs.
      (dolist (e all-ir)
        (dolist (insn (cdr e))
          (let ((name (cond ((eq (car insn) :call) (cadr insn))
                            ((eq (car insn) :li-func) (caddr insn))
                            (t nil))))
            (when (and name (stringp name) (not (gethash name *functions*)))
              (let ((info (make-function-info :name name :bytecode-offset rt-next
                                              :bytecode-length 0)))
                (setf (gethash name *functions*) info)
                (setf (gethash rt-next rt-table) name)
                (setq rt-next (+ rt-next 1)))))))
      ;; Pass 2: emit bytecode.
      (dolist (e all-ir)
        (let* ((ir (cdr e)) (lp (compute-label-positions ir)))
          (emit-bytecode-for-ir buf ir lp)))
      (dolist (e all-ir)
        (when (string-equal (string (function-info-name (car e))) "%MVM-EVAL-THUNK")
          (setq entry (function-info-bytecode-offset (car e)))))
      (let ((bc (mvm-buffer-used-bytes buf))
            (fn-table (make-array (length all-ir)))
            (lam-offsets (make-hash-table))
            (ft-list nil)
            (i 0))
        (dolist (e all-ir)
          (aset fn-table i (function-info-bytecode-offset (car e)))
          (setq i (+ i 1))
          (let ((nm (string (function-info-name (car e))))
                (off (function-info-bytecode-offset (car e)))
                (len (function-info-bytecode-length (car e))))
            ;; ADAPTER: (name offset length) for translate-mvm-to-x64 — same
            ;; structs, string name.  Reverse-consed then reversed to preserve
            ;; the all-ir order (which is what fn-table indices track too).
            (setq ft-list (cons (list nm off len) ft-list))
            (if (and (or (search "$$LAMBDA" nm) (search "$$CLOSURE" nm))
                     (not (eql off 0)))
                (puthash off lam-offsets t)
                (puthash off lam-offsets (quote :defun)))))
        (list bc entry (reverse ft-list) fn-table rt-table lam-offsets)))))

(defun mvm-eval-forms (forms)
  ;; In-image: emit integer literals as fixnum-safe :li-halves (set the GLOBAL,
  ;; not a let-binding — compiled LET of a special may not establish a dynamic
  ;; binding the compiler's compile-integer reads).  Native builds never call
  ;; mvm-eval-forms, so the global stays NIL there.
  (setq *mvm-emit-halves* t)
  ;; Mark in-image runtime compilation so mvm-compile-toplevel routes package
  ;; side-effecting forms (DEFPACKAGE) to their runtime impl instead of the
  ;; build-time no-op.  setq (not let): compiled let of a special is unreliable
  ;; in-image (same reason as *mvm-emit-halves* above).  Native builds never
  ;; call mvm-eval-forms, so the global stays NIL at build time.
  (setq *mvm-eval-runtime-p* t)
  ;; The UNWIND-PROTECT bookkeeping the compiler keeps in two defvars must
  ;; hold real values.  Images that never run INIT-ALL-GLOBALS (the ANSI gate
  ;; runners) left them uninitialised, so a lexical RETURN-FROM out of an
  ;; UNWIND-PROTECT in EVAL'd code saw no cleanup to run and skipped it.
  ;; Only repaired when invalid, so a nested compile keeps the outer state.
  (unless (and (boundp '*uwp-seq-counter*) (integerp *uwp-seq-counter*))
    (setq *uwp-seq-counter* 0))
  (unless (and (boundp '*uwp-cleanups*) (listp *uwp-cleanups*))
    (setq *uwp-cleanups* nil))
  ;; LAZY opcode-table init.  encode-instruction (mvm.lisp) reads *opcode-table*
  ;; for each instruction's operand spec during Pass-2 emit; with a NIL table
  ;; (the ANSI image skips init-all-globals, so the defparameter init thunk
  ;; never ran) every operand is silently DROPPED → corrupt bytecode → garbage
  ;; result.  Create + populate here, on first mvm-eval use, NOT at boot: a
  ;; permanent populated *opcode-table* GC root shifts GC timing enough to
  ;; surface a latent crash elsewhere (GET-INTERNAL-RUN-TIME.2 / 0xDEAD0004),
  ;; and mvm-eval is dead code until the WS3 flip, so lazy keeps the normal image's
  ;; live set identical to baseline.  Skips when already populated (the generic
  ;; image, or a 2nd mvm-eval call).  NB %populate-opcode-table's `setf gethash`
  ;; no-ops on a NIL table, so the table MUST be created first.
  (unless (and *opcode-table* (> (hash-table-count *opcode-table*) 0))
    (setq *opcode-table* (make-hash-table :test (quote eql)))
    (%populate-opcode-table))
  ;; PERF Round 2 (compile-caching): if these FORMS are cacheable (no side-
  ;; effecting DEF*) and already compiled, re-interpret the cached module and
  ;; skip the whole compile pipeline.  Checked BEFORE the big let so a hit pays
  ;; none of the setup/hash-alloc cost either.
  (let ((%cacheable (and (not *mvm-eval-no-cache*) (%mvm-eval-cacheable-p forms))))
    (when %cacheable
      (unless *mvm-eval-cache*
        (setq *mvm-eval-cache* (make-hash-table :test (quote equal))))
      (let ((%hit (gethash forms *mvm-eval-cache*)))
        (when %hit (return-from mvm-eval-forms (%mvm-eval-run-tuple %hit)))))
  (let ((*functions* (make-hash-table :test (quote equal)))
        (*function-table* nil)
        (*constant-table* nil)
        (*label-counter* 0)
        (*unresolved-calls* (make-hash-table :test (quote equal)))
        (*macro-table* (make-hash-table :test (quote eql)))
        (*globals* (make-hash-table :test (quote eql)))
        (*constants* (make-hash-table :test (quote eql)))
        (*loop-exit-label* nil)
        (*block-labels* nil)
        (*tagbody-tags* nil)
        (*pending-flet-ir* nil)
        (*init-thunk-names* nil)
        (all-ir nil)
        (buf nil)
        (global-offset 0)
        (entry nil)
        (rt-table (make-hash-table))
        (rt-next #x40000000)
        ;; WS3 def persistence: names of top-level user DEFUNs in FORMS.  Each is
        ;; compiled as a real module function and, after the module builds,
        ;; installed as a re-entrant interp trampoline in the global function
        ;; tables — so a LATER (mvm-eval …) call OR the tree-walker can call it.
        ;; Without this every (mvm-eval '(defun f …)) discarded f (closed-world
        ;; module), so no multi-form program (asdf/load/REPL) could run on mvm-eval.
        ;; Computed AFTER register-mvm-bootstrap-macros (below) via
        ;; %e2-scan-persist, which sees through EVAL-WHEN / PROGN / LOCALLY
        ;; AND macro wrappers (with-upgradability) — see its docstring.
        (persist-names nil))
    (register-mvm-bootstrap-macros)
    ;; WS3 def persistence pre-scan.  Runs with *macro-table* freshly populated
    ;; (bootstrap macros) so %e2-scan-persist's macroexpand-1-mvm sees the same
    ;; macro environment the compile loop below will; runtime user macros
    ;; resolve through the *mvm-eval-runtime-p* fallback.
    (dolist (f forms)
      (setq persist-names (%e2-scan-persist f persist-names 0)))
    ;; Split: last form is the expression; preceding forms are definitions.
    ;; A TRAILING defun is moved into the module definitions (so it gets a real
    ;; module function + offset to install a trampoline for) and the thunk
    ;; returns its NAME (matching real defun's value), instead of being wrapped
    ;; as a nested defun that compiles in-module and yields NIL.
    (let* ((rforms (reverse forms))
           (last-form (car rforms))
           (last-defun-p (and (consp last-form) (symbolp (car last-form))
                              (string-equal (symbol-name (car last-form)) "DEFUN")
                              (symbolp (cadr last-form))))
           (expr (if last-defun-p (list (quote quote) (cadr last-form)) last-form))
           (defs (if last-defun-p forms (reverse (cdr rforms))))
           (toplevel (append defs (list (list (quote defun) (quote %mvm-eval-thunk) nil expr))))
           ;; REENTRANCY: a NESTED mvm-eval during this compile loop (the toplevel
           ;; DEFMACRO handler's expander eval, build-macrolet-expander,
           ;; DEFCONSTANT value eval) re-enters mvm-eval-forms, which clears and
           ;; consumes *e2-persist-defuns* — clobbering the outer call's
           ;; accumulated names.  Save the current value in a LEXICAL here and
           ;; restore it after the union below, so each nesting level sees only
           ;; its own recordings.  (Explicit save+setq+restore, NOT a let of
           ;; the special — compiled let of a special is unreliable in-image.)
           (%e2pd-saved *e2-persist-defuns*)
           ;; Task #244.  Same reentrancy discipline as %E2PD-SAVED: publish
           ;; THIS module's pre-scanned defun names for compile-function-ref's
           ;; forward-reference test (%e2-fn-in-module-p), and put the
           ;; enclosing call's list back when the compile loop is done.
           (%e2md-saved *e2-module-defuns*))
      ;; Compiler-recorded persistence: clear the global BEFORE the compile
      ;; loop; the toplevel DEFUN handler pushes every toplevel-context defun
      ;; name (post-macroexpansion) onto it.  setq, not let (compiled let of
      ;; a special is unreliable in-image — see *mvm-emit-halves*).
      (setq *e2-persist-defuns* nil)
      (setq *%defun-deferred* nil)
      ;; Task #244: publish the pre-scanned module defun names for the
      ;; duration of the compile loop, so `#'LATER-FN' inside an EARLIER
      ;; function of this same module is recognised as in-module and
      ;; materialised as a closure instead of escaping as a raw offset.
      (setq *e2-module-defuns* persist-names)
      (dolist (f toplevel)
        (let ((result (mvm-compile-toplevel f)))
          (cond
            ((null result) nil)
            ((and (consp result) (eq (car result) :multi-result))
             (dolist (sub (cdr result))
               (when (and (car sub) (cdr sub))
                 (setq all-ir (cons (cons (car sub) (cdr sub)) all-ir)))))
            (t (when (and (car result) (cdr result))
                 (setq all-ir (cons (cons (car result) (cdr result)) all-ir)))))))
      ;; Drain *pending-flet-ir*: captureless lambdas, flet/labels bodies, and
      ;; nested defuns register their (info . ir) here instead of returning it
      ;; from mvm-compile-toplevel.  Without emitting these, a `#'(lambda ...)`
      ;; (funcall lambda) would resolve its li-func to an UN-OFFSET function and
      ;; jump to bytecode 0 → infinite recursion.  Append so they get Pass-1
      ;; offsets and Pass-2 bytecode like any other function.
      (dolist (pend *pending-flet-ir*)
        (when (and (consp pend) (car pend) (cdr pend))
          (setq all-ir (cons pend all-ir))))
      (setq all-ir (reverse all-ir))
      ;; Union the compiler-recorded defun names (macro-hidden defuns the
      ;; raw-forms pre-scan can't see — with-upgradability → eval-when →
      ;; defun) into persist-names for the trampoline install loop below.
      ;; %MVM-EVAL-THUNK excludes itself by name.  NB: a NESTED mvm-eval during
      ;; this compile loop (a macroexpander that itself calls EVAL) would
      ;; clear/consume the global mid-flight; the pre-scan names remain as
      ;; the safety net in that (rare) case.
      (dolist (pn *e2-persist-defuns*)
        (unless (or (string-equal pn "%MVM-EVAL-THUNK")
                    (member pn persist-names :test (function string=)))
          (setq persist-names (cons pn persist-names))))
      ;; REENTRANCY: restore the enclosing mvm-eval-forms call's recordings
      ;; (see %e2pd-saved above).  Outermost call restores NIL — harmless.
      (setq *e2-persist-defuns* %e2pd-saved)
      (setq *e2-module-defuns* %e2md-saved))
    ;; Small buffer (the default 128MB byte array blows the in-image heap).
    ;; PERF: REUSE a persistent 64KB buffer instead of (make-array 65536) every
    ;; call.  mvm-buffer-used-bytes copies the bytecode out before the next call,
    ;; so nothing retains the buffer — safe to reset + reuse.
    (if *mvm-eval-buffer*
        (progn
          (setf (mvm-buffer-position *mvm-eval-buffer*) 0)
          (clrhash (mvm-buffer-labels *mvm-eval-buffer*))
          (setf (mvm-buffer-fixups *mvm-eval-buffer*) nil)
          (setq buf *mvm-eval-buffer*))
        (progn
          (setq buf (make-mvm-buffer :bytes (make-array 65536)))
          (setq *mvm-eval-buffer* buf)))
    ;; Pass 1: size each function, assign cumulative bytecode offsets, register
    ;; in *functions* so emit-time CALL resolution finds them.
    (dolist (e all-ir)
      (let* ((info (car e)) (ir (cdr e))
             (fn-size (let ((s 0)) (dolist (insn ir) (setq s (+ s (ir-instruction-size insn)))) s)))
        (setf (function-info-bytecode-offset info) global-offset)
        (setf (function-info-bytecode-length info) fn-size)
        (setf (gethash (function-info-name info) *functions*) info)
        (setq global-offset (+ global-offset fn-size))))
    ;; Pass 1.5: any CALL to a name NOT defined in this module is a RUNTIME call
    ;; (a native function in the image).  Register a synthetic stub at a high
    ;; offset so emit resolves the CALL there; the interpreter's runtime-table
    ;; maps that offset back to the name and funcalls the native fn (WS1 bridge).
    ;; LI-FUNC (#'NAME / (function NAME)) to an out-of-module name is also a
    ;; runtime reference: the FN-ADDR opcode reads function-info-bytecode-offset,
    ;; so registering the name at a runtime stub offset lets the interp's
    ;; op-FN-ADDR map that offset back to the name and load the REAL native
    ;; function OBJECT.  The subsequent CALL-INDIRECT then bridge-calls it —
    ;; this is the higher-order mvm-eval path (funcall/apply/mapcar #'NAME).
    (dolist (e all-ir)
      (dolist (insn (cdr e))
        ;; The fn NAME is operand 1 for :call ((:call name nargs)) but operand 2
        ;; for :li-func ((:li-func dest name)) — pick the right slot per op.
        (let ((name (cond ((eq (car insn) :call) (cadr insn))
                          ((eq (car insn) :li-func) (caddr insn))
                          (t nil))))
          (when (and name (stringp name) (not (gethash name *functions*)))
            (let ((info (make-function-info :name name :bytecode-offset rt-next
                                            :bytecode-length 0)))
              (setf (gethash name *functions*) info)
              (setf (gethash rt-next rt-table) name)
              (setq rt-next (+ rt-next 1)))))))
    ;; Pass 2: emit (CALLs resolve to in-module OR synthetic offsets via *functions*).
    (dolist (e all-ir)
      (let* ((ir (cdr e)) (lp (compute-label-positions ir)))
        (emit-bytecode-for-ir buf ir lp)))
    (dolist (e all-ir)
      (when (string-equal (string (function-info-name (car e))) "%MVM-EVAL-THUNK")
        (setq entry (function-info-bytecode-offset (car e)))))
    (let ((bc (mvm-buffer-used-bytes buf)))
      (if entry
          (let ((fn-table (make-array (length all-ir))) (i 0)
                ;; LAMBDA-OFFSETS: the bytecode entry offsets of in-module LAMBDA /
                ;; CLOSURE bodies (named *$$LAMBDA* / *$$CLOSURE* by compile-lambda).
                ;; The interp's native-bridge uses this to recognise an mvm-eval lambda
                ;; VALUE escaping to a native higher-order fn (mapcar/reduce/…) and
                ;; wrap it in a re-entrant trampoline.  Keyed by offset; ONLY genuine
                ;; lambda bodies are recorded (never the %mvm-eval-thunk / helper defuns
                ;; / the fn at offset 0), so an ordinary fixnum DATA argument — a loop
                ;; counter 0/1/2, an index — is never mistaken for a callable.
                (lam-offsets (make-hash-table))
                ;; WS4-S5b: (name offset length) list for translate-mvm-to-x64
                ;; (the JIT adapter — same function-info structs as fn-table).
                (ft-list nil))
            (dolist (e all-ir)
              (aset fn-table i (function-info-bytecode-offset (car e)))
              (setq i (+ i 1))
              (setq ft-list
                    (cons (list (string (function-info-name (car e)))
                                (function-info-bytecode-offset (car e))
                                (function-info-bytecode-length (car e)))
                          ft-list))
              (let ((nm (string (function-info-name (car e))))
                    (off (function-info-bytecode-offset (car e))))
                ;; The T vs :DEFUN distinction is now COSMETIC (both entries
                ;; are accepted by %mvm-module-fn-offset-p, the only reader).
                ;; It used to matter because %mvm-wrap-escaping had a
                ;; BARE-INTEGER branch that fired on the T entries alone, and
                ;; offset 0 was excluded there so a DATA fixnum 0 (make-list 0 /
                ;; member 0 / (- 10 j)=0 in nsubstitute's bounds loops) would
                ;; not be wrapped into a #x52 trampoline.  That 0-guard was
                ;; only ever a partial patch — ANY small data fixnum can equal
                ;; a lambda offset — so the branch itself is gone; see
                ;; %MVM-WRAP-ESCAPING in interp.lisp (alexandria EXTREMUM.1).
                (if (and (or (search "$$LAMBDA" nm) (search "$$CLOSURE" nm))
                         (not (eql off 0)))
                    (puthash off lam-offsets t)
                    ;; NON-lambda module fns (defuns, flet bodies, the thunk)
                    ;; record under the distinct :DEFUN marker: the #x52
                    ;; branches (module-closure vs native-closure
                    ;; discrimination via %mvm-module-fn-offset-p in
                    ;; %mvm-wrap-escaping[-result] and op-obj-subtag) accept
                    ;; any entry INCLUDING offset 0 (the first module fn — a
                    ;; materialized #'SELF closure's slot-0 is very often 0),
                    ;; which is safe because slot-0 of a #x52 is never DATA.
                    (puthash off lam-offsets (quote :defun)))))
            ;; WS3 def persistence: install each top-level user DEFUN as a
            ;; re-entrant interp trampoline in BOTH global function tables —
            ;; *symbol-function-table* by NAME (the mvm-eval native-call bridge's
            ;; %mvm-resolve-runtime-fn key) and *native-sym-function-table* by
            ;; HASH (symbol-function / funcall key).  The trampoline closes over
            ;; BC so the module bytecode stays GC-alive; fn-table + lam-offsets
            ;; are fully built by now; env = NIL (a top-level defun captures
            ;; nothing).  A later (mvm-eval …) call OR the tree-walker now resolves f.
            (when persist-names
              (dolist (e all-ir)
                (let ((pn (string (function-info-name (car e)))))
                  (when (member pn persist-names :test (function string=))
                    ;; WS5 #222 REDEFINITION INVALIDATION.  This is the ONLY
                    ;; point at which PN's PREVIOUS binding is still visible —
                    ;; the puthash below overwrites it, and by the time
                    ;; %jit-install-native-fns runs (after the page is built)
                    ;; the old value is already gone.  If the previous binding
                    ;; was NATIVE code (tag nibble 3 — either build-time or a
                    ;; #222 install), some exec page in *jit-page-cache* may
                    ;; have BAKED that address into a `movabs rax, imm64; call
                    ;; rax` site, and re-running that cached page would silently
                    ;; call the SUPERSEDED definition.  Drop the whole page
                    ;; cache so every cached module re-translates and
                    ;; re-relocates against the new definition.
                    ;;
                    ;; This must happen even when the NEW definition ends up
                    ;; being only a trampoline (a const-bearing body, or a
                    ;; module whose relocation failed): the stale cached page
                    ;; still holds the OLD native address and would keep
                    ;; calling it — the first redefinition bug this feature
                    ;; produced (`(defun f …)` twice, then the SAME call form
                    ;; text, returned the second definition's answer for the
                    ;; third definition).  A FIRST definition never invalidates
                    ;; anything: no page can have baked an address for a name
                    ;; that did not previously resolve to native code, so
                    ;; loading a library pays nothing here.
                    (let ((%prev (%mvm-resolve-runtime-fn pn)))
                      (when (and %prev *jit-page-cache*
                                 (eql (logand (%val->word %prev) 15) 3))
                        (clrhash *jit-page-cache*)))
                    ;; JIT-EAGER: remember this module so the DEFUN can be
                    ;; compiled native later without re-evaluating anything.
                    (%jit-register-module persist-names bc entry ft-list
                                          fn-table rt-table lam-offsets)
                    (let ((tramp (%mvm-make-trampoline
                                   bc fn-table rt-table
                                   (function-info-bytecode-offset (car e))
                                   nil lam-offsets)))
                      ;; puthash signature is (KEY HT VALUE) — store the
                      ;; trampoline as the VALUE under PN / its name-hash.  (The
                      ;; earlier `(puthash pn tramp <table>)` had HT and VALUE
                      ;; swapped, so the closure was treated as the hash table and
                      ;; nothing was actually stored — every later resolve of PF
                      ;; returned NIL, so the trampoline never ran.)
                      (when (boundp (quote *symbol-function-table*))
                        (%jit-fnaddr-thunk-invalidate pn)
                        (puthash pn *symbol-function-table* tramp))
                      (when (boundp (quote *native-sym-function-table*))
                        (puthash (compute-name-hash pn)
                                 *native-sym-function-table* tramp)))))))
            ;; PERF Round 2: cache the compiled module for these forms so a
            ;; later mvm-eval of the same forms skips the whole compile.  bc is a
            ;; fresh copy (mvm-buffer-used-bytes), safe despite buffer reuse.
            (when (and %cacheable
                       ;; OFF-MAIN, DO NOT CACHE — the tuple below was
                       ;; allocated in THIS thread's region during the
                       ;; compile, and the cache is region-0-reachable.
                       ;; Measured as EXACTLY the last remaining
                       ;; region-0 -> worker reference after the CL:INTERN
                       ;; lock+copy fix.  See %MVM-ON-MAIN-THREAD-P.
                       (%mvm-on-main-thread-p))
              (setf (gethash forms *mvm-eval-cache*)
                    ;; WS4-S5b: ft-list inserted at index 2 (see %mvm-eval-run-tuple
                    ;; layout comment).  reverse → source order (fn-table order).
                    (list bc entry (reverse ft-list) fn-table rt-table lam-offsets)))
            ;; Conditions PROPAGATE (see %mvm-eval-run-tuple): production EVAL
            ;; must let an error signalled by the form reach the caller's
            ;; handler-case instead of returning (:interp-err e) as a value.
            ;; The RESULT is wrapped when it is an in-module #x52 lambda
            ;; closure (see %mvm-wrap-escaping-result) so `(eval '#'(lambda
            ;; ...))` hands back a natively-funcallable, per-call-distinct
            ;; function object.
            ;; MULTIPLE VALUES propagate — same *mvm-last-mv* + values-list
            ;; re-emission as %mvm-eval-run-tuple (see the comment there).
            ;; *e2-active-defun-names* = persist-names for the duration of the
            ;; run so fmakunbound honors source order vs the pre-run defun
            ;; installation (see the defvar).  Lexical-save + setq-restore
            ;; (nested mvm-eval during the run saves/restores its own).
            (let* ((%adn-saved *e2-active-defun-names*)
                   ;; WS5 #203: the re-execution guard, same as in
                   ;; %mvm-eval-run-tuple.  THIS is the site the doubling was
                   ;; measured at (a top-level form calling a runtime-defined
                   ;; function): the old `(t (c) ...interpret...)` answered a
                   ;; condition raised AFTER the form's side effects had already
                   ;; run by re-running the whole form.  Lexical-save +
                   ;; setq-restore, matching %adn-saved directly above.
                   (%jnr-saved *jit-native-ran*)
                   (%jif-saved *jit-infra-fallback*)
                   (%prim (progn
                            (setq *e2-active-defun-names* persist-names)
                            (setq *jit-native-ran* nil)
                            (setq *jit-infra-fallback* nil)
                            ;; WS4-S5b: JIT when enabled, interpret-fallback on a
                            ;; SETUP failure (page-build fail / unsupported) or
                            ;; the MV out-of-range residual — but NOT on a user condition
                            ;; raised once native code is running.
                            ;; %jit-active-p honors *jit-inhibit* (Class 3).
                            ;; RETRY-ON-HOT: with *jit-hot-only* (default T), a
                            ;; form's FIRST eval (this fresh-compile / cache-MISS
                            ;; path) INTERPRETS; it is JIT'd only when eval'd AGAIN,
                            ;; via the cache-HIT run-tuple path above (~2247), which
                            ;; stays gated on %jit-active-p alone.  One-shot LOAD
                            ;; forms (never re-eval'd; DEFUNs aren't even cacheable)
                            ;; thus never pay JIT translation — fast loading — while
                            ;; repeated forms go native on the second run.
                            (if (and (%jit-active-p) (not (%jit-hot-only-p)))
                                (handler-case
                                    (%mvm-eval-jit-run bc entry (reverse ft-list)
                                                    fn-table rt-table lam-offsets nil
                                                    persist-names)
                                  (t (c)
                                     (let ((%ran *jit-native-ran*)
                                           (%infra *jit-infra-fallback*))
                                       (setq *jit-native-ran* %jnr-saved)
                                       (setq *jit-infra-fallback* %jif-saved)
                                       (if (and %ran (not %infra) (%condition-p c))
                                           ;; User condition, after side effects
                                           ;; began → propagate, never re-run.
                                           (progn
                                             (setq *e2-active-defun-names* %adn-saved)
                                             (setq *jit-resignal-count*
                                                   (if *jit-resignal-count*
                                                       (+ 1 *jit-resignal-count*) 1))
                                             (error c))
                                           (progn
                                     (when (and %ran (not %infra))
                                       (setq *jit-r-native-escape*
                                             (if *jit-r-native-escape*
                                                 (+ 1 *jit-r-native-escape*) 1)))
                                     (setq *jit-fallback-count*
                                           (if *jit-fallback-count* (+ 1 *jit-fallback-count*) 1))
                                     (%mvm-wrap-escaping-result
                                       (mvm-interpret bc :entry-point entry
                                                      :function-table fn-table
                                                      :runtime-table rt-table
                                                      :return-raw nil
                                                      :lambda-offsets lam-offsets)
                                       bc fn-table rt-table lam-offsets))))))
                                (%mvm-wrap-escaping-result
                                  (mvm-interpret bc :entry-point entry :function-table fn-table
                                                 :runtime-table rt-table :return-raw nil
                                                 :lambda-offsets lam-offsets)
                                  bc fn-table rt-table lam-offsets))))
                   (%mv *mvm-last-mv*)
                   ;; Cleared as soon as latched — see the sibling seam above.
                   (%mvclr (setq *mvm-last-mv* nil)))
              (setq *e2-active-defun-names* %adn-saved)
              ;; WS5 #203: restore the guard flags on the SUCCESS path too, or a
              ;; completed native run leaves *jit-native-ran* set and the NEXT
              ;; form's handler re-signals a setup failure it should have
              ;; quietly interpreted.  After %mv is latched, as above.
              (setq *jit-native-ran* %jnr-saved)
              (setq *jit-infra-fallback* %jif-saved)
              (if %mv
                  (if (eql (car %mv) 0)
                      (values)
                      (values-list (cons %prim (cdr %mv))))
                  %prim)))
          :no-entry))))
  )
;; Single-expression convenience.
(defun mvm-eval (form) (mvm-eval-forms (list form)))

;;; ============================================================
;;; WS3 Phase 3 — mvm-eval lambda-body-against-env entry (%e2ic)
;;; ============================================================
;;;
;;; The tree-walker (%eval-in-env) could not be deleted because it was the
;;; only engine that could evaluate a LAMBDA BODY AGAINST A CAPTURED ENV —
;;; the %interp-closure call path (compile nil '(lambda …), coerce 'function,
;;; runtime define-compiler-macro expanders, walker-created closures) and
;;; DEFTYPE expansion (%expand-deftype).  This block gives mvm-eval that entry:
;;;
;;;   %e2ic-compile PARAMS BODY ENV → native trampoline (or NIL = fallback)
;;;
;;; Design: compile `(lambda PARAMS (symbol-macrolet SM . BODY))` via mvm-eval,
;;; where SM maps each captured env binding NAME to `(cdr 'PAIR)` — PAIR
;;; being the walker's OWN alist binding cons, passed by identity through
;;; the mvm-eval quote pool (*e2-const-pool*).  Reads see the live cell value;
;;; `(setq NAME v)` expands (compile-setq symbol-macro path) to
;;; `(set-cdr 'PAIR v)` — mutating the SAME cons the walker and any sibling
;;; closures share, so mutation semantics match the walker exactly.
;;; mvm-eval returns the lambda as a re-entrant native trampoline
;;; (%mvm-wrap-escaping-result → %mvm-make-trampoline), cached per closure
;;; (5th slot of the %interp-closure list) so repeated calls pay only the
;;; ~0.6M-cycle interpret, not the ~16M-cycle compile.
;;;
;;; WS3 STEP 4 (tree-walker DELETED from production images): there is no
;;; walker fallback any more.  A shape outside mvm-eval's lambda support —
;;;   - junk lambda list (NIL / non-symbol atom element, unknown &-marker;
;;;     MACRO lambda lists — dotted tails, nested destructuring, &whole/
;;;     &environment/&body — are handled since the WS3 finisher via
;;;     compile-lambda's %transform-macro-lambda-list),
;;;   - a captured binding whose name is unresolvable,
;;;   - mvm-eval COMPILE failure (conditions during the body's execution are NOT
;;;     caught — they propagate, matching production eval semantics)
;;; — now signals an honest ERROR instead of silently degrading to a second
;;; evaluator.  The legacy fork builds get the walker from tree-walker.lisp
;;; (which overrides %call-interp-closure/%expand-deftype there).
;;; (The nested-lambda-over-captured-cells fallback is GONE: compile-lambda
;;; now threads symbol-macro bindings into nested compilation units —
;;; %collect-free-vars compiles SM names via their expansions instead of
;;; snapshot-capturing them — so an inner lambda over a captured name reads
;;; and setqs the SAME live env cons the walker and sibling closures share.
;;; The env-held-interp-closure fallback is ALSO gone: FLET/LABELS locals in
;;; a captured env compile to flet wrappers + SM entries — see
;;; %e2ic-env-pairs / %e2ic-flet-bindings.)
;;;
(defvar *e2ic-deftype-cache* nil
  "name-string → (entry . trampoline-or-:walker) for %expand-deftype's mvm-eval
   route.  The registered (params . body) ENTRY cons is stored alongside so a
   re-registered deftype (entry no longer eq) recompiles.")

(defun %e2ic-mvm-eval-nocache (form)
  "mvm-eval FORM with *mvm-eval-cache* bypassed (see *mvm-eval-no-cache*): the form
   embeds captured env conses via the quote pool, so EQUAL-keyed caching
   would alias two different closures' cells.  setq + unwind-protect (not a
   let of the special — compiled let of a special is unreliable in-image).

   CLASS-3 (JIT interp-closure nested-call boundary): compile+build this
   interp-closure trampoline with the JIT DISABLED.  An %interp-closure's
   trampoline is ALWAYS run via mvm-interpret (%mvm-make-trampoline re-enters
   the interpreter; *jit-native-count* does not move for its body), so
   JIT-translating its %mvm-eval-thunk is pure overhead — AND it triggers a
   native<->interp boundary fault: when this thunk is built under the JIT and
   the resulting interp-closure body makes a REAL out-of-module call whose
   callee is itself an interp trampoline (a user DEFUN persisted via
   %mvm-make-trampoline), invoking that inner trampoline from the outer
   interp bridge — while a JIT-native frame is on the stack — jumps to a
   corrupted native target (RIP=RAX=an unaligned exec-page address) and the
   boot SIGSEGV handler longjmps out.  `(gcd a b)` in an interp-closure works
   (gcd's symbol-function is a native builtin, not a trampoline); `(g x)` for
   a user defun faults (g's symbol-function is a trampoline).  Forcing the
   interp-closure module through the interpret path removes the extra native
   frame, so the nested interp->interp bridge call runs correctly — matching
   the JIT-off baseline exactly.  The inhibit is done via *jit-inhibit* (NOT
   `(setq *use-jit* nil)`): the ANSI gate BAKES %jit-enabled-p to a constant
   that ignores *use-jit*, so *jit-inhibit* + the %jit-active-p seam gate is
   the only inhibit that works in BOTH the CLI and the gate image.  Lexically
   saved + setq-restored (do NOT dynamically rebind the special: compiled let
   of a special is unreliable in-image — see *mvm-eval-no-cache* above)."
  (let ((%saved *mvm-eval-no-cache*)
        (%savedinh (if (boundp (quote *jit-inhibit*)) *jit-inhibit* nil)))
    (setq *mvm-eval-no-cache* t)
    (setq *jit-inhibit* t)
    (unwind-protect
        (mvm-eval form)
      (setq *mvm-eval-no-cache* %saved)
      (setq *jit-inhibit* %savedinh))))

(defun %e2ic-ll-marker (x)
  "If X is a lambda-list &-marker symbol, return its NAME string; else NIL."
  (let ((nm (%eval-sym-name x)))
    (if (and nm (> (length nm) 0) (= (%prim-aref nm 0) 38))  ; 38 = &
        nm
        nil)))

(defun %e2ic-simple-ll-p (params)
  "T when PARAMS is a lambda list the mvm-eval compile path handles.  Since
   the WS3 finisher (stage 2), MACRO-style lambda lists are ACCEPTED too —
   dotted tails, nested destructuring in the required section, and
   &whole/&environment/&body — because compile-lambda rewrites them to a
   plain (&rest …) + DESTRUCTURING-BIND form (%transform-macro-lambda-list,
   stage 1).  This is what lets walker-created macro expanders (runtime
   DEFMACRO / MACROLET / DEFINE-COMPILER-MACRO closures) and destructuring
   DEFTYPE lambda lists compile+run via %e2ic instead of the tree-walker.
   NIL (walker fallback) only for junk: a NIL element, a non-symbol
   non-cons atom in a binding position, or an unknown &-marker.
   (&OPTIONAL+&KEY combos accepted since 2026-07-08 — preprocess-params'
   &key→&rest transform handles the combination.)"
  (let ((ps params))
    (loop
      (cond
        ((null ps) (return t))
        ((not (consp ps)) (return (symbolp ps))) ; dotted tail var
        (t
         (let ((p (car ps)))
           (cond
             ((null p) (return nil))
             ((symbolp p)
              (let ((mk (%e2ic-ll-marker p)))
                (when mk
                  (unless (or (string-equal mk "&OPTIONAL")
                              (string-equal mk "&REST")
                              (string-equal mk "&KEY")
                              (string-equal mk "&AUX")
                              (string-equal mk "&ALLOW-OTHER-KEYS")
                              (string-equal mk "&WHOLE")
                              (string-equal mk "&ENVIRONMENT")
                              (string-equal mk "&BODY"))
                    (return nil)))))             ; unknown &-marker
             ((consp p) nil)   ; nested pattern / spec — compile side handles
             (t (return nil)))
           (setq ps (cdr ps))))))))

(defun %e2ic-ll-var-names-1 (params out)
  "Extend OUT with the NAME string of every variable PARAMS binds — FULL
   macro-lambda-list grammar: nested required patterns (recursive), dotted
   tail vars, &whole/&environment vars, spec vars and supplied-p vars.
   Section-aware: a cons in the REQUIRED section is a sub-pattern to
   recurse into; the same cons after an &-marker is a (var init
   [supplied-p]) / ((:kw var) …) spec.  Precision matters both ways: a
   MISSED name leaves a symbol-macrolet env entry colliding with the
   real parameter binding; an EXTRA name silently drops a live captured
   cell (body reads an unbound global instead)."
  (let ((ps params)
        (in-required t))
    (loop
      (cond
        ((null ps) (return out))
        ((not (consp ps))                        ; dotted tail var
         (let ((nm (%eval-sym-name ps)))
           (when nm (setq out (cons nm out))))
         (return out))
        (t
         (let ((p (car ps)))
           (cond
             ((and (symbolp p) (%e2ic-ll-marker p))
              (let ((mk (%e2ic-ll-marker p)))
                (if (or (string-equal mk "&WHOLE")
                        (string-equal mk "&ENVIRONMENT"))
                    ;; The NEXT element is the bound var — consume it here.
                    (progn
                      (setq ps (cdr ps))
                      (when (and (consp ps) (symbolp (car ps)))
                        (let ((nm (%eval-sym-name (car ps))))
                          (when nm (setq out (cons nm out))))))
                    (setq in-required nil))))
             ((symbolp p)
              (let ((nm (%eval-sym-name p)))
                (when nm (setq out (cons nm out)))))
             ((consp p)
              (if in-required
                  (setq out (%e2ic-ll-var-names-1 p out))
                  (progn
                    (let ((v (car p)))
                      (let ((var (if (consp v) (car (cdr v)) v)))
                        (let ((nm (%eval-sym-name var)))
                          (when nm (setq out (cons nm out))))))
                    (when (and (cdr p) (cdr (cdr p))
                               (symbolp (car (cdr (cdr p)))))
                      (let ((snm (%eval-sym-name (car (cdr (cdr p))))))
                        (when snm (setq out (cons snm out)))))))))
           (setq ps (cdr ps))))))))

(defun %e2ic-ll-var-names (params)
  "NAME strings of every variable a lambda list binds (params, nested
   pattern vars, dotted tails, &whole/&environment vars, spec vars,
   supplied-p vars) — used to drop captured-env bindings a parameter
   shadows."
  (reverse (%e2ic-ll-var-names-1 params nil)))

(defun %e2ic-env-pairs (env params)
  "Captured-env binding conses to expose in the compiled unit: dedup by NAME
   keeping the FIRST (innermost) occurrence, drop names a lambda param
   shadows.  Returns (VALUE-PAIRS . FN-PAIRS): FN-PAIRS are bindings whose
   value is an %interp-closure (what FLET/LABELS store in the walker's env —
   it conflates the namespaces, guarding call-position lookups by the
   interp-closure shape; see cl-eval's %eval-funcall).  FN-PAIRS get BOTH a
   symbol-macrolet entry (value refs, matching the walker's unguarded
   variable lookup) AND an flet wrapper (call position + #'NAME).  Returns
   the marker symbol :E2IC-BAD when a binding's name is unresolvable."
  (let ((pnames (%e2ic-ll-var-names params))
        (seen nil)
        (vout nil)
        (fout nil)
        (bad nil))
    (dolist (pair env)
      (when (and (not bad) (consp pair))
        (let ((nm (%eval-sym-name (car pair))))
          (cond
            ((null nm) (setq bad t))
            ((member nm seen :test (function string-equal)) nil)
            ((member nm pnames :test (function string-equal))
             (setq seen (cons nm seen)))
            ((%interp-closure-p (cdr pair))
             (setq seen (cons nm seen))
             (setq fout (cons pair fout)))
            (t
             (setq seen (cons nm seen))
             (setq vout (cons pair vout)))))))
    (if bad (quote :e2ic-bad) (cons (reverse vout) (reverse fout)))))

(defun %e2ic-sm-bindings (pairs)
  "symbol-macrolet bindings: NAME → (cdr 'PAIR), PAIR by identity via the
   mvm-eval quote pool."
  (let ((out nil))
    (dolist (pair pairs (reverse out))
      (setq out (cons (list (car pair)
                            (list (quote cdr) (list (quote quote) pair)))
                      out)))))

(defun %e2ic-flet-bindings (pairs)
  "flet bindings exposing captured %interp-closure env bindings as LOCAL
   FUNCTIONS: (NAME (&rest A) (apply (cdr \'PAIR) A)).  The (cdr \'PAIR)
   read happens at CALL time, so a setq of the same name (via its
   symbol-macrolet entry) redirects subsequent local calls too — exactly
   the walker\'s live-env behavior.  APPLY dispatches interp-closures
   through %call-interp-closure (cl-printer apply), so the callee gets its
   own %e2ic compile+cache on first call; recursion (LABELS) terminates
   because each level is one cached wrapper hop."
  (let ((out nil))
    (dolist (pair pairs (reverse out))
      (let ((av (gensym "%E2ICA")))
        ;; Tail shape (values-list (multiple-value-list …)): APPLY's
        ;; interp-closure fast path preserves the callee's multiple values,
        ;; but a bare (apply …) tail is not values-shaped, so the compiled
        ;; wrapper's epilogue would set-mv-count 1 and truncate them (probe
        ;; F7).  VALUES-LIST at the tail makes tail-form-is-values-p skip
        ;; that epilogue — MV parity with the walker holds through the
        ;; wrapper.
        (setq out (cons (list (car pair)
                              (list (quote &rest) av)
                              (list (quote values-list)
                                    (list (quote multiple-value-list)
                                          (list (quote apply)
                                                (list (quote cdr)
                                                      (list (quote quote) pair))
                                                av))))
                        out))))))

(defun %e2ic-compile (params body env)
  "Compile an interp-closure\'s PARAMS/BODY/ENV to a native re-entrant
   trampoline via mvm-eval, or NIL when the shape needs the walker.  Only the
   COMPILE step is guarded by handler-case — the body does not run here, so
   falling back cannot double side effects.  Captured env: value bindings
   become symbol-macrolet entries over the live env conses; interp-closure
   bindings (flet/labels locals) get BOTH an SM entry and an flet wrapper
   (see %e2ic-env-pairs / %e2ic-flet-bindings)."
  (if (not (%e2ic-simple-ll-p params))
      nil
      (let ((pairs (%e2ic-env-pairs env params)))
        (cond
          ((eq pairs (quote :e2ic-bad)) nil)
          (t
           (let* ((vpairs (car pairs))
                  (fpairs (cdr pairs))
                  (inner (if fpairs
                             (list (cons (quote flet)
                                         (cons (%e2ic-flet-bindings fpairs)
                                               body)))
                             body))
                  (form (if (or vpairs fpairs)
                            (list (quote lambda) params
                                  (cons (quote symbol-macrolet)
                                        (cons (%e2ic-sm-bindings
                                                (append vpairs fpairs))
                                              inner)))
                            (cons (quote lambda) (cons params body)))))
             (handler-case
                 (let ((tramp (%e2ic-mvm-eval-nocache form)))
                   (if (functionp tramp) tramp nil))
               (t (c) nil))))))))

(defun %e2ic-cached (fn)
  "The per-closure compile cache: slot 5 of the %interp-closure list
   (NIL = untried, :E2IC-WALKER = known-fallback, else the trampoline).
   Walker readers touch only slots 1-3, so the extension is invisible."
  (let ((tail (cdr (cdr (cdr (cdr fn))))))
    (if (consp tail) (car tail) nil)))

(defun %e2ic-cache-set (fn val)
  (let ((tail (cdr (cdr (cdr fn)))))
    (when (consp tail)
      (set-cdr tail (cons val nil))))
  val)

(defun %e2ic-apply (tramp args)
  "Apply the compiled trampoline and re-emit the interpret run's multiple
   values (same *mvm-last-mv* protocol as %mvm-eval-run-tuple) so MV parity
   with production mvm-eval holds through the closure boundary."
  (let* ((%r (apply tramp args))
         (%mv *mvm-last-mv*)
         ;; Cleared as soon as latched — see the sibling seams above.
         (%mvclr (setq *mvm-last-mv* nil)))
    (if %mv
        (if (eql (car %mv) 0)
            (values)
            (values-list (cons %r (cdr %mv))))
        %r)))

(defvar *e2ic-fallback-count* 0
  "Number of interp-closure / deftype-expander invocations %e2ic-compile
   could NOT serve.  Historical: counted tree-walker fallbacks until the
   walker was DELETED (the deletion census measured ZERO hits across the
   full ANSI corpus + gauntlet); now counts SIGNALED unsupported-shape
   errors — any nonzero value marks a fresh mvm-eval capability gap.
   BOOTS AS NIL, not 0: defvar init-thunks never run in the ANSI image
   (CLAUDE.md Active Limitation 7) — increment ONLY via %e2ic-bump-fallback.")

(defun %e2ic-bump-fallback ()
  "NIL-safe increment of *e2ic-fallback-count*.  The defvar's `0' init-form
   never runs (init-all-globals is skipped in the ANSI image), so the
   counter boots as NIL.  A bare (+ 1 NIL) tag-checks into GENERIC-ADD,
   whose (t (%fixnum-+ a b)) clause silently returns NIL+2 = #xDEAD0003;
   further bumps walk the garbage to #xDEAD0009 — OBJECT tag 9 — after
   which the first obj-subtag predicate (bignump etc.) dereferences the
   unmapped #xDEAD0000 header → SIGSEGV inside the walker-fallback /
   deftype-expansion path (i.e. mid-macroexpansion or mid-typep during
   handler-case condition matching), which leaks signal-dispatch state and
   let conditions escape the per-form handler-case → the CHUNK-CRASH
   regression on the fallback families (format-b/d/o/x, macrolet, some,
   notany, times, defmacro, handler-case…)."
  (setq *e2ic-fallback-count*
        (if *e2ic-fallback-count* (+ 1 *e2ic-fallback-count*) 1)))

(defun %call-interp-closure (fn args)
  "The ONLY interp-closure engine (the tree-walker is DELETED): compiles
   the closure body against its captured env ONCE (cached on the closure),
   applies the trampoline.  An unsupported shape / compile failure SIGNALS
   an honest error (cached as :e2ic-fail; *e2ic-fallback-count* bumps as
   the diagnostic — the deletion census measured zero such shapes)."
  (let ((c (%e2ic-cached fn)))
    (cond
      ((eq c (quote :e2ic-fail))
       (%e2ic-bump-fallback)
       (error "mvm-eval: interp-closure shape unsupported (cached compile failure)"))
      (c (%e2ic-apply c args))
      (t
       (let ((tramp (%e2ic-compile (cadr fn) (caddr fn) (cadddr fn))))
         (%e2ic-cache-set fn (if tramp tramp (quote :e2ic-fail)))
         (if tramp
             (%e2ic-apply tramp args)
             (progn
               (%e2ic-bump-fallback)
               (error "mvm-eval: interp-closure compile failed (params=~S)"
                      (cadr fn)))))))))

(defun %expand-deftype (type)
  "OVERRIDE (mvm-eval images; last-defun-wins) of ansi-bridge's engine stub:
   route the deftype body eval through the mvm-eval lambda-body entry, cached
   per registration (name → (entry . trampoline)).  A deftype body mvm-eval
   can't compile SIGNALS (the tree-walker is deleted)."
  (let* ((head (if (consp type) (car type) type))
         (args (if (consp type) (cdr type) nil))
         (entry (%deftype-lookup head)))
    (cond
      ((null entry) nil)
      (t
       (let* ((nm (%eval-sym-name head))
              (hit (if (and nm *e2ic-deftype-cache*)
                       (gethash nm *e2ic-deftype-cache*)
                       nil)))
         (if (and hit (eq (car hit) entry))
             (if (eq (cdr hit) (quote :e2ic-fail))
                 (progn (%e2ic-bump-fallback)
                        (error "mvm-eval: deftype expander compile failed (type=~S)"
                               type))
                 (%e2ic-apply (cdr hit) args))
             (let ((tramp (%e2ic-compile (car entry) (cdr entry) nil)))
               (unless *e2ic-deftype-cache*
                 (setq *e2ic-deftype-cache*
                       (make-hash-table :test (quote equal))))
               (when nm
                 (puthash nm *e2ic-deftype-cache*
                          (cons entry (if tramp tramp (quote :e2ic-fail)))))
               (if tramp
                   (%e2ic-apply tramp args)
                   (progn (%e2ic-bump-fallback)
                          (error "mvm-eval: deftype expander compile failed (type=~S)"
                                 type))))))))))

;;; ============================================================
;;; DISASSEMBLE — the real one (overrides cl-eval.lisp's fallback)
;;; ============================================================
;;;
;;; POSITION IS LOAD-BEARING.  This must live AFTER *compiler-source* in the
;;; build's source assembly (bridge -> mvm.lisp -> interp -> compiler.lisp ->
;;; mvm-eval.lisp).  Calls are resolved BY NAME AT BUILD TIME, so the same code
;;; placed in cl-eval.lisp (inside the bridge) binds make-mvm-buffer and
;;; mvm-compile-toplevel to %%unresolved-fn, which returns NIL, and the
;;; disassembler then dies with a TYPE-ERROR on the NIL buffer.  That is not a
;;; hypothetical: it is what the first attempt did, and the build log named it
;;; ("1 x MODUS.MVM::MAKE-MVM-BUFFER" under "unresolved calls").
;;;
;;; Modus prints MVM BYTECODE, not native code, and that is the honest choice:
;;; native code exists only for forms the JIT has translated, which happens on
;;; EXECUTION, not definition, and the image's baked functions retain no
;;; bytecode at all.  Bytecode is also arch-independent, so this same output
;;; appears on x64, aarch64 and i386.

(defun %disassemble-form (form)
  "Compile FORM (a DEFUN form) through the SAME pipeline mvm-eval uses --
   mvm-compile-toplevel -> emit-bytecode-for-ir -- and print the resulting
   MVM bytecode symbolically.  Returns T if anything was printed.

   Reusing the production pipeline is the point: a disassembler on its own
   private path could disagree with what actually executes, which would make
   it worse than no disassembler at all."
  (let ((all-ir nil) (ok nil))
    (let ((result (mvm-compile-toplevel form)))
      (cond
        ((null result) nil)
        ((and (consp result) (eq (car result) :multi-result))
         (dolist (sub (cdr result))
           (when (and (car sub) (cdr sub))
             (setq all-ir (cons (cons (car sub) (cdr sub)) all-ir)))))
        (t (when (and (car result) (cdr result))
             (setq all-ir (cons (cons (car result) (cdr result)) all-ir))))))
    (setq all-ir (reverse all-ir))
    (dolist (e all-ir)
      (let* ((info (car e))
             (ir (cdr e))
             (size (let ((s 0))
                     (dolist (insn ir) (setq s (+ s (ir-instruction-size insn))))
                     s))
             (buf (make-mvm-buffer :bytes (make-array (+ size 256))))
             (lp (compute-label-positions ir)))
        (emit-bytecode-for-ir buf ir lp)
        (format t "; ~A  (~D bytes of MVM bytecode)~%"
                (string (function-info-name info)) size)
        (disassemble-mvm (mvm-buffer-used-bytes buf))
        (setq ok t)))
    ok))

(defun disassemble (fn)
  "CLHS DISASSEMBLE.  FN is an extended function designator OR a lambda
   expression.  Output format is implementation-defined; the return is NIL.

   A LAMBDA EXPRESSION is compiled fresh and fully disassembled to MVM
   bytecode.  For a named function there is no retained source or bytecode,
   so we say so plainly instead of printing something misleading."
  (let ((done nil))
    (when (and (consp fn) (symbolp (car fn))
               (string-equal (string (car fn)) "LAMBDA"))
      (setq done (%disassemble-form
                  (cons (quote defun)
                        (cons (quote %disassembled-lambda) (cdr fn))))))
    (unless done
      (format t "; disassemble: no bytecode retained for this object.~%")
      (format t ";   Pass a lambda expression to see compiler output, e.g.~%")
      (format t ";   (disassemble '(lambda (x) (* x x)))~%")))
  nil)

;;; PERF (#306): compiler.lisp's COMPUTE-NAME-HASH (the HOST definition, which
;;; upcases a fresh copy of the name with STRING-UPCASE and walks it with the
;;; generic AREF) is spliced into the image AFTER prelude.lisp's raw version,
;;; so last-defun-wins made every in-image name hash allocate a string —
;;; ~650k calls per alexandria quickload; STRING-UPCASE was 29% of the PC
;;; profile.  This override (spliced after compiler.lisp) restores the raw
;;; %PRIM-AREF loop with inline ASCII upcasing.  Bit-identical result.
(defun compute-name-hash (name-string)
  ;; A wrapped (multi-dimensional / adjustable / base-char) string stores its
  ;; characters behind a #x34 header: %PRIM-AREF would read the wrapper's
  ;; slots (find-symbol.17 / shadow.8 build names with MAKE-ARRAY
  ;; :element-type 'base-char).  Flatten it first.
  (when (%mda-p name-string) (setq name-string (%flat-string name-string)))
  (let ((h1 40389) (h2 48879)          ; #x9DC5 / #xBEEF
        (len (array-length name-string))
        (i 0))
    (loop
      (when (>= i len) (return nil))
      (let ((c (%prim-aref name-string i)))
        (when (and (>= c 97) (<= c 122))
          (setq c (- c 32)))
        (setq c (logand c 65535))
        (setq h1 (logand (* (logxor h1 c) 403) 65535))
        (setq h2 (logand (* (logxor h2 c) 89) 65535)))
      (setq i (+ i 1)))
    (let ((combined (logior (ash (logand h1 +name-hash-hi-mask+) +name-hash-shift+)
                            (logand h2 +name-hash-lo-mask+))))
      (if (= combined 0) 1 combined))))

;;; PERF: in-image identity key for the macroexpansion memo (compiler.lisp's
;;; host stub uses SXHASH).  The tagged word of the form object; entries are
;;; EQ-validated so a GC-moved form simply misses.
(defun %form-key (form) (%val->word form))
