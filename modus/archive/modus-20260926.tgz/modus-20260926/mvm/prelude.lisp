;;;; prelude.lisp - Library functions for MVM self-compilation
;;;;
;;;; These are MVM-compilable implementations of Common Lisp library
;;;; functions used by the MVM compiler, translators, and cross-compilation
;;;; pipeline. They are loaded as source and compiled by MVM, providing
;;;; runtime definitions for self-hosting.
;;;;
;;;; All functions here must use only features MVM can compile:
;;;; - defun with positional args only (no &key, &optional, &rest)
;;;; - let, let*, if, cond, loop, setq, progn, when, unless
;;;; - car, cdr, cons, consp, null, not, eq, atom
;;;; - Arithmetic, comparisons, logand, logior, logxor, ash
;;;; - %serial-byte, mem-ref


(in-package :modus.mvm)

;;; ============================================================
;;; List Utilities
;;; ============================================================

(defun not (x)
  "Logical negation — same as null."
  (null x))

;;; ============================================================
;;; Function-cell wrappers for primitive ops
;;; ============================================================
;;; eql, eq, =, etc. are inline opcodes — they have no callable function
;;; entry, so #'eql is a NIL/garbage pointer. Tests that pass `:test #'eql`
;;; or `:test-not 'eql` get silently wrong answers. compile-function-ref
;;; rewrites #'eql etc. to these wrappers.
(defun %eql-fn (a b) (eql a b))
(defun %eq-fn (a b) (eq a b))
(defun %equal-fn (a b) (equal a b))
(defun %lt-fn (a b) (< a b))
(defun %gt-fn (a b) (> a b))
(defun %le-fn (a b) (<= a b))
(defun %ge-fn (a b) (>= a b))
(defun %eq-num-fn (a b) (= a b))
(defun %ne-num-fn (a b) (/= a b))

(defun nth (n list)
  "Return the Nth element of LIST (0-indexed). Signals TYPE-ERROR if N
   is not a non-negative fixnum (matches the ANSI requirement that N
   be of type unsigned-byte)."
  (when (or (not (fixnump n)) (< n 0))
    (%signal-type-error))
  (let ((i 0)
        (cur list))
    (loop
      (when (null cur) (return nil))
      (when (= i n) (return (car cur)))
      (setq i (+ i 1))
      (setq cur (cdr cur)))))

(defun nthcdr (n list)
  "Return the Nth cdr of LIST. Signals TYPE-ERROR on negative or
   non-fixnum N."
  (when (or (not (fixnump n)) (< n 0))
    (%signal-type-error))
  (let ((i 0)
        (cur list))
    (loop
      (when (= i n) (return cur))
      (when (null cur) (return nil))
      (setq i (+ i 1))
      (setq cur (cdr cur)))))

(defun last (list &rest n-arg)
  "Return the last N cons cells of LIST. N defaults to 1.
   Signals TYPE-ERROR if N is not a non-negative fixnum,
   or if LIST is neither a list nor NIL,
   or if more than one optional argument is supplied."
  ;; ANSI: (last list &optional (n 1)). Extra args → program-error.
  (when (and n-arg (cdr n-arg))
    (error "last: too many arguments"))
  (when (and list (not (consp list)))
    (error "last: first argument is not a list"))
  (let ((n (if n-arg (car n-arg) 1)))
    (when (or (not (fixnump n)) (< n 0))
      (%signal-type-error))
    (if (null list)
        nil
        (let ((len 0) (cur list))
          ;; Count length
          (loop
            (when (atom cur) (return nil))
            (setq len (+ len 1))
            (setq cur (cdr cur)))
          ;; Skip to (len - n)th element
          (if (<= len n)
              list
              (let ((skip (- len n))
                    (cur list))
                (loop
                  (when (= skip 0) (return cur))
                  (setq skip (- skip 1))
                  (setq cur (cdr cur)))))))))

(defun nreverse (list)
  "Destructively reverse LIST in place."
  (let ((prev nil)
        (cur list))
    (loop
      (when (null cur) (return prev))
      (let ((next (cdr cur)))
        (set-cdr cur prev)
        (setq prev cur)
        (setq cur next)))))

(defun reverse (list)
  "Return a new list that is the reverse of LIST."
  (let ((result nil)
        (cur list))
    (loop
      (when (null cur) (return result))
      (setq result (cons (car cur) result))
      (setq cur (cdr cur)))))

(defun append2 (list1 list2)
  "Append two lists non-destructively."
  (if (null list1)
      list2
      (cons (car list1) (append2 (cdr list1) list2))))

(defun append (&rest lists)
  "Append any number of lists."
  (if (null lists) nil
    (if (null (cdr lists)) (car lists)
      (let ((result (append2 (car lists) (cadr lists)))
            (rest (cddr lists)))
        (loop
          (when (null rest) (return result))
          (setq result (append2 result (car rest)))
          (setq rest (cdr rest)))))))

(defun nconc2 (list1 list2)
  "Destructively append LIST2 to the end of LIST1."
  (if (null list1)
      list2
      (let ((tail (last list1)))
        (set-cdr tail list2)
        list1)))

(defun nconc (&rest lists)
  "Destructively concatenate any number of lists."
  (if (null lists) nil
    (let ((result (car lists))
          (rest (cdr lists)))
      (loop
        (when (null rest) (return result))
        (setq result (nconc2 result (car rest)))
        (setq rest (cdr rest))))))

(defun copy-list (list)
  "Return a shallow copy of LIST."
  (if (null list)
      nil
      (let ((result (cons (car list) nil))
            (tail nil)
            (cur (cdr list)))
        (setq tail result)
        (loop
          (when (null cur) (return result))
          (let ((new-cell (cons (car cur) nil)))
            (set-cdr tail new-cell)
            (setq tail new-cell)
            (setq cur (cdr cur)))))))

;;; ============================================================
;;; Search and Membership
;;; ============================================================

(defun member (item list &rest options)
  "Return the tail of LIST starting from the first element EQL to ITEM.
   Signals TYPE-ERROR if LIST is not a list.
   Honors ANSI &key TEST/TEST-NOT/KEY.
   Per CLHS 3.4.1.4.1, leftmost keyword wins on duplicates."
  (when (and (not (null list)) (not (consp list)))
    (%signal-type-error))
  (%subst-check-kwargs options)
  (let ((test nil) (test-not nil) (key nil)
        (test-set nil) (tn-set nil) (key-set nil)
        (a options))
    (loop (when (null a) (return))
      (cond ((eq (car a) :test)
             (unless test-set (setq test (cadr a)) (setq test-set t))
             (setq a (cddr a)))
            ((eq (car a) :test-not)
             (unless tn-set (setq test-not (cadr a)) (setq tn-set t))
             (setq a (cddr a)))
            ((eq (car a) :key)
             (unless key-set (setq key (cadr a)) (setq key-set t))
             (setq a (cddr a)))
            (t (setq a (cdr a)))))
    (let ((cur list))
      (loop
        (when (null cur) (return nil))
        (let* ((v (if key (funcall key (car cur)) (car cur)))
               (matched
                (cond
                  (test (funcall test item v))
                  (test-not (not (funcall test-not item v)))
                  (t (eql item v)))))
          (when matched (return cur)))
        (setq cur (cdr cur))))))

(defun member-string (item list)
  "Return the tail of LIST starting from the first element STRING-EQUAL to ITEM."
  (let ((cur list))
    (loop
      (when (null cur) (return nil))
      (when (string-equal (car cur) item) (return cur))
      (setq cur (cdr cur)))))

(defun assoc (key alist &rest options)
  "Find the first pair in ALIST whose car matches KEY. Honors :TEST,
   :TEST-NOT, :KEY. Default test is inline `eql`.
   Per CLHS 3.4.1.4.1, leftmost keyword wins on duplicates."
  (%subst-check-kwargs options)
  (let ((test nil) (test-not nil) (key-fn nil)
        (test-set nil) (tn-set nil) (key-set nil)
        (a options))
    (loop (when (null a) (return))
      (cond ((eq (car a) :test)
             (unless test-set (setq test (cadr a)) (setq test-set t))
             (setq a (cddr a)))
            ((eq (car a) :key)
             (unless key-set (setq key-fn (cadr a)) (setq key-set t))
             (setq a (cddr a)))
            ((eq (car a) :test-not)
             (unless tn-set (setq test-not (cadr a)) (setq tn-set t))
             (setq a (cddr a)))
            (t (setq a (cdr a)))))
    (when (and test-not (not test))
      (let ((f test-not))
        (setq test (lambda (x y) (not (funcall f x y))))))
    (let ((cur alist))
      (loop
        (when (null cur) (return nil))
        (let ((pair (car cur)))
          (cond ((null pair) nil)        ; skip NIL alist entries (SBCL-compat)
                ((not (consp pair)) (error "assoc: not a cons"))
                (t (let ((c (if key-fn (funcall key-fn (car pair)) (car pair))))
                     (when (if test (funcall test key c) (eql key c))
                       (return pair))))))
        (setq cur (cdr cur))))))

(defun assoc-string (key alist)
  "Find the first pair in ALIST whose car is STRING-EQUAL to KEY."
  (let ((cur alist))
    (loop
      (when (null cur) (return nil))
      (let ((pair (car cur)))
        (when (consp pair)
          (when (string-equal (car pair) key) (return pair)))
        (setq cur (cdr cur))))))

(defun find-in-list (item list)
  "Find ITEM in LIST using EQL."
  (let ((cur list))
    (loop
      (when (null cur) (return nil))
      (when (eql (car cur) item) (return (car cur)))
      (setq cur (cdr cur)))))

(defun position-in-list (item list)
  "Return the index of ITEM in LIST (EQL test), or nil."
  (let ((cur list)
        (idx 0))
    (loop
      (when (null cur) (return nil))
      (when (eql (car cur) item) (return idx))
      (setq idx (+ idx 1))
      (setq cur (cdr cur)))))

(defun position (item seq &rest options)
  "Return the index of ITEM in SEQ (list or array). Honors :TEST, :KEY,
   :START, :END, :FROM-END. Default test is inline `eql`."
  (let ((test nil) (key nil) (start 0) (end nil) (from-end nil)
        (a options))
    (loop (when (null a) (return))
      (cond ((eq (car a) :test) (setq test (cadr a)) (setq a (cddr a)))
            ((eq (car a) :key)  (setq key  (cadr a)) (setq a (cddr a)))
            ((eq (car a) :start) (setq start (cadr a)) (setq a (cddr a)))
            ((eq (car a) :end)  (setq end  (cadr a)) (setq a (cddr a)))
            ((eq (car a) :from-end) (setq from-end (cadr a)) (setq a (cddr a)))
            ((eq (car a) :test-not)
             (let ((f (cadr a)))
               (setq test (lambda (x y) (not (funcall f x y)))))
             (setq a (cddr a)))
            (t (setq a (cdr a)))))
    (cond
      ((null seq) nil)
      ((consp seq)
       ;; Walk to start, then iterate to end (or list end)
       (let ((cur seq) (i 0) (result nil))
         (loop (when (or (null cur) (= i start)) (return nil))
           (setq cur (cdr cur)) (setq i (+ i 1)))
         (loop
           (when (null cur) (return result))
           (when (and end (= i end)) (return result))
           (let ((v (if key (funcall key (car cur)) (car cur))))
             (when (if test (funcall test item v) (eql item v))
               (if from-end (setq result i) (return i))))
           (setq cur (cdr cur)) (setq i (+ i 1)))))
      (t  ;; vector
       (let ((len (array-length seq))
             (result nil))
         (when (null end) (setq end len))
         (let ((i start))
           (loop (when (= i end) (return result))
             (let ((v (if key (funcall key (aref seq i)) (aref seq i))))
               (when (if test (funcall test item v) (eql item v))
                 (if from-end (setq result i) (return i))))
             (setq i (+ i 1)))))))))

(defun remove-if (pred seq)
  "Return a new sequence with elements for which PRED returns non-nil removed.
   Polymorphic over list / string / plain array — returns the same shape.
   Note: this short form ignores keyword args; the keyword-aware version
   in cl-sequences.lisp shadows this for callers via apply."
  (cond
    ((or (null seq) (consp seq))
     (let ((result nil)
           (cur seq))
       (loop
         (when (null cur) (return (nreverse result)))
         (unless (funcall pred (car cur))
           (setq result (cons (car cur) result)))
         (setq cur (cdr cur)))))
    ((stringp seq)
     ;; Count kept, allocate sized string, copy slot-wise (slots are fixnums).
     (let ((len (array-length seq))
           (kept 0))
       (let ((i 0))
         (loop (when (= i len) (return nil))
           (unless (funcall pred (aref seq i))
             (setq kept (+ kept 1)))
           (setq i (+ i 1))))
       (let ((out (%make-string-array kept)) (i 0) (j 0))
         (loop (when (= i len) (return out))
           (unless (funcall pred (aref seq i))
             (aset out j (aref seq i))
             (setq j (+ j 1)))
           (setq i (+ i 1))))))
    (t
     (let ((len (array-length seq))
           (kept 0))
       (let ((i 0))
         (loop (when (= i len) (return nil))
           (unless (funcall pred (aref seq i))
             (setq kept (+ kept 1)))
           (setq i (+ i 1))))
       (let ((out (make-array kept)) (i 0) (j 0))
         (loop (when (= i len) (return out))
           (unless (funcall pred (aref seq i))
             (aset out j (aref seq i))
             (setq j (+ j 1)))
           (setq i (+ i 1))))))))

;;; ============================================================
;;; Higher-Order Functions
;;; ============================================================

(defun mapcar1 (fn list)
  "Apply FN to each element of LIST, collecting results."
  (let ((result nil)
        (cur list))
    (loop
      (when (null cur) (return (nreverse result)))
      (setq result (cons (funcall fn (car cur)) result))
      (setq cur (cdr cur)))))

(defun mapcar (fn list &rest more-lists)
  "Apply FN to each element of LIST (and MORE-LISTS if provided).
   Fast paths for 1/2/3 lists avoid apply-of-rest fragility."
  (cond
    ((null more-lists) (mapcar1 fn list))
    ((null (cdr more-lists))
     (let ((c1 list) (c2 (car more-lists)) (result nil))
       (loop
         (when (or (null c1) (null c2)) (return (nreverse result)))
         (setq result (cons (funcall fn (car c1) (car c2)) result))
         (setq c1 (cdr c1)) (setq c2 (cdr c2)))))
    ((null (cddr more-lists))
     (let ((c1 list) (c2 (car more-lists)) (c3 (cadr more-lists)) (result nil))
       (loop
         (when (or (null c1) (null c2) (null c3)) (return (nreverse result)))
         (setq result (cons (funcall fn (car c1) (car c2) (car c3)) result))
         (setq c1 (cdr c1)) (setq c2 (cdr c2)) (setq c3 (cdr c3)))))
    (t (let ((result nil)
             (lists (cons list more-lists)))
         (loop
           (when (some #'null lists) (return (nreverse result)))
           (setq result (cons (apply fn (mapcar1 #'car lists)) result))
           (setq lists (mapcar1 #'cdr lists)))))))

(defun some (fn list)
  "Return the first non-nil result of applying FN to elements of LIST."
  (let ((cur list))
    (loop
      (when (null cur) (return nil))
      (let ((result (funcall fn (car cur))))
        (when result (return result)))
      (setq cur (cdr cur)))))

(defun every (fn list &rest more-lists)
  "Return T if FN returns non-nil for all elements."
  (if (null more-lists)
      ;; Single list
      (let ((cur list))
        (loop
          (when (null cur) (return t))
          (when (null (funcall fn (car cur))) (return nil))
          (setq cur (cdr cur))))
      ;; Two lists
      (let ((a list) (b (car more-lists)))
        (loop
          (when (or (null a) (null b)) (return t))
          (when (null (funcall fn (car a) (car b))) (return nil))
          (setq a (cdr a))
          (setq b (cdr b))))))

(defun reduce (fn seq &rest args)
  "Fold FN over SEQ (list or vector). Honors :initial-value, :from-end,
   :start, :end, :key.  Without :initial-value:
     - empty seq: return (funcall fn) with no args
     - single elt: return that element unchanged
     - else: starts with the first element"
  (%check-kw-allowed args '(:initial-value :from-end :start :end :key))
  (let ((init :no-init) (init-given nil)
        (from-end nil) (start 0) (end nil) (key nil)
        (a args))
    (loop (when (null a) (return))
      (cond ((eq (car a) :initial-value)
             (setq init (cadr a)) (setq init-given t) (setq a (cddr a)))
            ((eq (car a) :from-end) (setq from-end (cadr a)) (setq a (cddr a)))
            ((eq (car a) :start) (setq start (cadr a)) (setq a (cddr a)))
            ((eq (car a) :end)   (setq end   (cadr a)) (setq a (cddr a)))
            ((eq (car a) :key)   (setq key   (cadr a)) (setq a (cddr a)))
            (t (setq a (cdr a)))))
    ;; Materialise as a list slice [start..end). Cheap conversion: walk
    ;; the original sequence (works for lists, vectors, fill-pointer
    ;; arrays via aref/length), collect the elements we'll fold.
    (let* ((elts (let ((lst nil) (i 0) (n (if seq (length seq) 0))
                       (eff-end (if end end (if seq (length seq) 0))))
                   (cond
                     ;; Wrapper cons — index via elt (wrapper-aware)
                     ((and (consp seq) (array-wrapper-p seq))
                      (loop (when (>= i eff-end) (return nil))
                        (when (>= i start)
                          (let ((v (if key (funcall key (elt seq i)) (elt seq i))))
                            (setq lst (cons v lst))))
                        (setq i (+ i 1))))
                     ((or (null seq) (consp seq))
                      ;; Walk list once
                      (let ((cur seq))
                        (loop (when (null cur) (return nil))
                          (when (and (>= i start) (< i eff-end))
                            (let ((v (if key (funcall key (car cur)) (car cur))))
                              (setq lst (cons v lst))))
                          (setq cur (cdr cur))
                          (setq i (+ i 1)))))
                     (t
                      ;; Vector/string indexing
                      (loop (when (>= i eff-end) (return nil))
                        (when (>= i start)
                          (let ((v (if key (funcall key (elt seq i)) (elt seq i))))
                            (setq lst (cons v lst))))
                        (setq i (+ i 1)))))
                   (nreverse lst))))
      (cond
        ((and (null elts) init-given) init)
        ((null elts) (funcall fn))
        ((and (null (cdr elts)) (not init-given)) (car elts))
        (from-end
         ;; Right-fold: (fn e1 (fn e2 (fn e3 init)))
         (let* ((rev (reverse elts))
                (acc (if init-given init (car rev)))
                (cur (if init-given rev (cdr rev))))
           (loop (when (null cur) (return acc))
             (setq acc (funcall fn (car cur) acc))
             (setq cur (cdr cur)))))
        (t
         ;; Left-fold: (fn (fn (fn init e1) e2) e3)
         (let* ((acc (if init-given init (car elts)))
                (cur (if init-given elts (cdr elts))))
           (loop (when (null cur) (return acc))
             (setq acc (funcall fn acc (car cur)))
             (setq cur (cdr cur)))))))))

(defun mapc (fn list)
  "Apply FN to each element of LIST for side effects. Return LIST."
  (let ((cur list))
    (loop
      (when (null cur) (return list))
      (funcall fn (car cur))
      (setq cur (cdr cur)))))

;;; ============================================================
;;; Length and Counting
;;; ============================================================

(defun list-length (list)
  "Return the length of LIST, or NIL for circular lists.
   Uses tortoise-and-hare cycle detection.
   Signals a type-error if LIST is not a proper list (i.e., dotted or
   non-list).  Per ANSI CLHS list-length:
     - proper list → length
     - circular     → NIL
     - improper     → type-error"
  (when (and list (not (consp list)))
    (%signal-type-error))
  (let ((n 0)
        (fast list)
        (slow list))
    (loop
      ;; Fast pointer moves 2 steps; bail with type-error on dotted tail.
      (when (null fast) (return n))
      (when (not (consp fast)) (%signal-type-error))
      (setq fast (cdr fast))
      (setq n (+ n 1))
      (when (null fast) (return n))
      (when (not (consp fast)) (%signal-type-error))
      (setq fast (cdr fast))
      (setq n (+ n 1))
      ;; Slow pointer moves 1 step
      (setq slow (cdr slow))
      ;; If they meet, it's circular
      (when (eq fast slow) (return nil)))))

(defun cddddr (x) (cdr (cdddr x)))
(defun 1+ (x) (+ x 1))
(defun 1- (x) (- x 1))

(defun copy-tree (tree)
  "Return a fresh copy of TREE (all conses copied recursively)."
  (if (consp tree)
      (cons (copy-tree (car tree)) (copy-tree (cdr tree)))
      tree))

(defvar *%no-cons-array-wrappers* nil
  "T in an image whose arrays are never CONS-based wrappers -- the CLI, where
   MAKE-ARRAY builds every non-simple array as the #x34 MDA header.  There a
   cons shaped like a wrapper -- (5 . #(1 2)), ((1 . 2) . #(3)) -- is an
   ordinary user CONS, but the shape predicates below classified it as a
   fill-pointer / displaced array: (arrayp (cons 5 (vector 1 2))) => T,
   (length (cons 5 (vector 1 2 3))) => 5, and the printer read raw memory
   out of it (the upstream random-printer FAULTs).  NIL (the default, and
   what an image that never sets it reads) keeps the ANSI gate runner's
   rewriter-built wrappers working.")

(defun %length-cdr-is-array-tail-p (x)
  "True if X is a real array, a string, or a one-cons-deep wrapper around
   one.  Used by LENGTH to disambiguate a fp / displaced wrapper from an
   ordinary list whose car happens to be a fixnum or cons.

   Bounded at one cons hop (so this is O(1), not O(list-length)) — long
   ANSI lists like `(make-list 200000)` would otherwise blow the stack.
   The adjustable wrapper layer (cons 8765432 ...) is peeled by LENGTH
   before invoking this helper, so we only need to recognise fp / displaced
   shapes here."
  (cond
    ((null x) nil)
    ((arrayp x) t)
    ((stringp x) t)
    ((not (consp x)) nil)
    (t (let ((cd (cdr x)))
         (cond
           ((null cd) nil)
           ((arrayp cd) t)
           ((stringp cd) t)
           (t nil))))))

(defun length (seq)
  "Return the length of SEQ (list or array).
   For array wrappers (commit 7c9a463: adj/fp/displaced/multi-dim wrappers
   over plain arrays), returns the ANSI length:
     fp wrapper       → fill pointer
     adj-only wrapper → length of underlying
     displaced        → declared size
     multi-dim        → length of flat backing array
     native MDA #x34  → fp if present, else array-length of data
   Plain conses route through list-length as before.
   A wrapper is disambiguated from an ordinary list by its CDR (chain)
   eventually pointing at an array/string rather than NIL/list."
  (cond
    ((null seq) 0)
    ;; No cons-based wrappers in this image: a cons is a list.
    ((and (consp seq) *%no-cons-array-wrappers*) (list-length seq))
    ((consp seq)
     (cond
       ;; adjustable wrapper marker — always a wrapper, peel and recurse
       ((eql (car seq) 8765432)
        (length (cdr seq)))
       ;; multi-dim wrapper marker
       ((and (eql (car seq) 9867654) (consp (cdr seq)))
        (array-length (cddr seq)))
       ;; fp / displaced wrapper — disambiguate from list by walking cdr chain
       ((%length-cdr-is-array-tail-p (cdr seq))
        (cond
          ((fixnump (car seq)) (car seq))                  ; fp → fill pointer
          ((consp (car seq))   (car (car seq)))            ; displaced → size
          (t (list-length seq))))                          ; defensive
       ;; ordinary list
       (t (list-length seq))))
    ;; Native MDA (subtag #x34) — fp first, else walk dims.  Cannot use
    ;; (array-length (%mda-data seq)) — for displaced MDAs, data slot
    ;; holds the displaced-to target which may be larger.
    ((%mda-p seq)
     (let ((fp (%mda-fp seq)))
       (cond
         (fp fp)
         (t (let ((dims (%mda-dims seq)) (total 1))
              (loop (when (null dims) (return total))
                (setq total (* total (car dims)))
                (setq dims (cdr dims))))))))
    (t (array-length seq))))

;;; ============================================================
;;; Array Utilities
;;; ============================================================

;;; ------------------------------------------------------------------
;;; Bulk element copy — the slot-to-slot fast path.
;;;
;;; The sequence copiers (set-subseq, replace, copy-seq, subseq,
;;; concatenate) were all written as per-element loops over the PUBLIC
;;; accessors, e.g. `(setf (elt dst i) (elt src i))'.  On a string that is
;;; brutal: `elt' is a full generic dispatch, and because public string
;;; access is CL-conformant it lifts each stored CHAR CODE into a
;;; CHARACTER via code-char, only for the setter to drive it straight back
;;; down to a code.  Two dispatched calls plus a pointless code→char→code
;;; round trip, per character.
;;;
;;; Measured on x64 before this existed (2000 iterations x 4096 chars,
;;; externally wall-clock timed because GET-INTERNAL-REAL-TIME is a call
;;; counter, not a clock — see the timer task):
;;;   set-subseq 1003 ms   concatenate 895 ms   copy-seq 503 ms
;;;   replace/subseq 397 ms          SBCL: all at memcpy speed, ~0 ms
;;; i.e. ~122 ns PER CHARACTER for set-subseq.
;;;
;;; Strings store char CODES in ordinary word slots, so a string→string
;;; copy is just slot→slot: the entire code→char→code round trip is
;;; provably redundant.  %BULK-COPY does the loop over %word-aref /
;;; %word-aset, which are inline intrinsics (obj-ref / obj-set) rather
;;; than calls, and hoists every type test OUT of the loop.
(defun %bulk-copy-ok-p (dst src)
  "True when DST and SRC are both plain word-slot arrays holding the SAME
   element representation, so raw slot-to-slot copying is exact.

   Deliberately conservative — every rejected case falls back to the
   generic element loop, which is slow but correct:
     • conses are fill-pointer / displaced / adjustable WRAPPERS, whose
       slots are not the elements (compile-aref routes these to
       %wrapper-aref for exactly this reason);
     • %mda-p objects keep their elements in a separate %mda-data store;
     • subtag #x11 is a byte-packed u8 vector, which needs %u8-ref /
       %u8-set — %word-aref would read a whole word across 8 elements;
     • a string slot holds a char CODE while a general-vector slot holds a
       TAGGED value, so copying words between the two kinds would store
       codes where characters belong.  Require the kinds to match.
   Note this makes no assumption about WHICH subtag strings use — if
   strings ever become byte-packed (the base-string task), the #x11 test
   rejects them here and correctness is preserved without a change."
  (and (not (consp dst)) (not (consp src))
       (not (%mda-p dst)) (not (%mda-p src))
       (not (eq (obj-subtag dst) #x11))
       (not (eq (obj-subtag src) #x11))
       (not (eq (obj-subtag dst) #x12))
       (not (eq (obj-subtag src) #x12))
       (if (%prim-stringp dst)
           (%prim-stringp src)
           (not (%prim-stringp src)))))

(defun %u8-bare-p (x)
  "True for a plain byte-packed (subtag #x11) u8 vector: no fill-pointer /
   displaced wrapper (a cons) and no %mda-p header."
  (and x (not (consp x)) (not (%mda-p x)) (eq (obj-subtag x) #x11)))

(defun %bulk-copy-u8-ok-p (dst src)
  "Both plain u8 vectors: copy bytes with %u8-ref / %u8-set (the word
   copier's #x11 exclusion, done right instead of falling to the generic
   element loop — a bordered 320x180 frame copy took 16 ms that way)."
  (and (%u8-bare-p dst) (%u8-bare-p src)))

(defun %bulk-copy-u8 (dst dstart src sstart n)
  "Byte copy SRC[sstart…] → DST[dstart…], memmove semantics like %bulk-copy.
   Distinct objects (or a same-object copy that moves DOWN) go eight bytes
   at a time through raw word loads/stores on the packed data — the object
   pointer is tag 9 and the data starts 16 bytes past the header, so byte
   K lives at raw address (word - 9 + 16 + K) = word + 7 + K.  Nothing in
   the loop allocates, so the raw addresses cannot move under it.  Hosted
   x64 / aarch64 both allow unaligned 64-bit access."
  (declare (type fixnum dstart sstart n))
  (cond
    ;; same object, destination above the source AND the ranges overlap:
    ;; copy descending, byte-wise.  Disjoint ranges take the word path.
    ((and (eq dst src) (> dstart sstart) (< (- dstart sstart) n))
     (let ((i (- n 1)))
       (declare (type fixnum i))
       (loop
         (when (< i 0) (return dst))
         (%u8-set dst (+ dstart i) (%u8-ref src (+ sstart i)))
         (setq i (- i 1)))))
    (t
     (let ((i 0)
           (da (+ (%val->word dst) 7 dstart))
           (sa (+ (%val->word src) 7 sstart)))
       (declare (type fixnum i da sa))
       (loop
         (when (> (+ i 8) n) (return))
         (setf (mem-ref (+ da i) :u64) (mem-ref (+ sa i) :u64))
         (setq i (+ i 8)))
       (loop
         (when (>= i n) (return dst))
         (%u8-set dst (+ dstart i) (%u8-ref src (+ sstart i)))
         (setq i (+ i 1)))))))

(defun %bulk-copy (dst dstart src sstart n)
  "Copy N elements SRC[sstart…] → DST[dstart…] by raw word slots.
   Caller must have checked %bulk-copy-ok-p and the bounds.

   memmove semantics, not memcpy: when the two are the SAME object and
   the destination starts after the source, a forward loop would overwrite
   source elements before reading them, so copy descending in that case.
   CLHS requires this — REPLACE on one sequence with overlapping ranges
   must behave as if it copied through a temporary."
  (if (and (eq dst src) (> dstart sstart))
      (let ((i (- n 1)))
        (loop
          (when (< i 0) (return dst))
          (%word-aset dst (+ dstart i) (%word-aref src (+ sstart i)))
          (setq i (- i 1))))
      (let ((i 0))
        (loop
          (when (>= i n) (return dst))
          (%word-aset dst (+ dstart i) (%word-aref src (+ sstart i)))
          (setq i (+ i 1))))))

(defun copy-seq (array)
  "Copy an array, returning a new array with the same elements."
  (let* ((len (array-length array))
         ;; a packed single-float vector copies to a packed one
         (result (if (and array (not (consp array)) (not (%mda-p array))
                          (eq (obj-subtag array) #x12))
                     (%make-f32-vector len)
                     (make-array (array-length array)))))
    (if (%bulk-copy-ok-p result array)
        (%bulk-copy result 0 array 0 len)
        (let ((i 0))
          (loop
            (when (= i len) (return result))
            (aset result i (aref array i))
            (setq i (+ i 1)))))
    result))

;;; ============================================================
;;; String Utilities
;;; ============================================================

(defun char-upcase (ch)
  "Return uppercase version of character CH."
  (let ((code (char-code ch)))
    (if (if (>= code 97) (<= code 122) nil)
        (code-char (- code 32))
        ch)))

(defun char-downcase (ch)
  "Return lowercase version of character CH."
  (let ((code (char-code ch)))
    (if (if (>= code 65) (<= code 90) nil)
        (code-char (+ code 32))
        ch)))

(defun %flat-string (s)
  "A plain #x31 copy of string S (S may be a wrapped/MDA string), char codes
   normalised — for raw %PRIM-AREF loops that must not see a wrapper."
  (let* ((len (array-length s)) (flat (%make-string-array len)) (i 0))
    (loop
      (when (>= i len) (return flat))
      (%prim-aset flat i (%ensure-char-code (aref s i)))
      (setq i (+ i 1)))))

(defun string-upcase (str)
  "Return a new string with all characters uppercased.
   Uses %make-string-array so the result is actually a string (subtag),
   and converts char-upcase's returned character back to a fixnum char-code
   to match the convention that string slots hold fixnum char-codes."
  (when (%mda-p str) (setq str (%flat-string str)))
  (let ((len (array-length str))
        (result (%make-string-array (array-length str))))
    (let ((i 0))
      (loop
        (when (= i len) (return result))
        ;; Raw slot access: ASCII letters upcase inline; anything else goes
        ;; through CHAR-UPCASE (the generic AREF path was ~125 ns per char).
        (let ((c (%ensure-char-code (%prim-aref str i))))
          (if (and (>= c 97) (<= c 122))
              (%prim-aset result i (- c 32))
              (if (< c 128)
                  (%prim-aset result i c)
                  (let ((up (char-upcase (code-char c))))
                    (%prim-aset result i (if (characterp up) (char-code up) up))))))
        (setq i (+ i 1))))))

(defun string-downcase (str)
  "Return a new string with all characters lowercased."
  (let ((len (array-length str))
        (result (%make-string-array (array-length str))))
    (let ((i 0))
      (loop
        (when (= i len) (return result))
        (let ((ch (aref str i)))
          (let ((dn (char-downcase ch)))
            (aset result i (if (characterp dn) (char-code dn) dn))))
        (setq i (+ i 1))))))

;;; ============================================================
;;; Equality
;;; ============================================================

(defun string-equal (a b &rest args)
  "Case-insensitive string compare (ANSI semantics: chars match if
   they would compare CHAR-EQUAL, i.e. case-folded for ASCII letters).
   STRING= is the case-sensitive variant.  Most callers in
   cl-packages.lisp / make-condition initarg matching want this case-
   insensitive form so cross-file keyword identity works.

   Honors :START1/:END1/:START2/:END2 — internal 2-arg callers still
   work (args is NIL, bounds default to full strings)."
  (let* ((s1 0) (e1 nil) (s2 0) (e2 nil) (o args) (allow-other nil))
    ;; Pre-scan for :allow-other-keys — LEFTMOST-wins (CLHS 3.4.1.4): the
    ;; value of the FIRST occurrence governs, so stop at the first one.
    ;; string-equal.error.6 passes ":allow-other-keys nil :allow-other-keys
    ;; t :foo bar" and expects a program-error (leading nil => :foo illegal).
    (let ((scan args))
      (loop (when (or (null scan) (null (cdr scan))) (return))
        (when (eq (car scan) :allow-other-keys)
          (when (cadr scan) (setq allow-other t))
          (return))
        (setq scan (cddr scan))))
    (loop (when (null o) (return))
      (when (null (cdr o))
        (error "string-equal: odd-length keyword arg list"))
      (let ((k (car o)))
        (cond ((eq k :start1) (setq s1 (cadr o)))
              ((eq k :end1)   (setq e1 (cadr o)))
              ((eq k :start2) (setq s2 (cadr o)))
              ((eq k :end2)   (setq e2 (cadr o)))
              ((eq k :allow-other-keys) nil)
              (allow-other nil)
              (t (error "string-equal: bad keyword"))))
      (setq o (cddr o)))
    ;; CLHS: STRING-EQUAL takes STRING DESIGNATORS, not strings -- a character,
    ;; a symbol (NIL included), or a string.  These used to go straight into
    ;; ARRAY-LENGTH, so (string-equal "0.0.1" nil) faulted instead of returning
    ;; NIL.  Coerce first; STRING is the identity on real strings, so the
    ;; common path is unchanged.
    (let* ((a (string a))
           (b (string b))
           (len-a (array-length a))
           (len-b (array-length b))
           (ee1 (or e1 len-a))
           (ee2 (or e2 len-b))
           (slen1 (- ee1 s1))
           (slen2 (- ee2 s2)))
      (if (= slen1 slen2)
          (let ((i 0)
                (raw (and (%prim-stringp a) (not (%mda-p a))
                          (%prim-stringp b) (not (%mda-p b)))))
            (loop
              (when (= i slen1) (return t))
              ;; AREF on a string now yields a CHARACTER; normalize to a
              ;; raw code for the case-fold + numeric compare.  RAW = both
              ;; are plain #x31 strings, so read the codes straight from the
              ;; slots (no AREF dispatch / code-char boxing / call per char).
              (let ((ca (%ensure-char-code (if raw (%prim-aref a (+ s1 i)) (aref a (+ s1 i)))))
                    (cb (%ensure-char-code (if raw (%prim-aref b (+ s2 i)) (aref b (+ s2 i))))))
                (when (and (>= ca 65) (<= ca 90)) (setq ca (+ ca 32)))
                (when (and (>= cb 65) (<= cb 90)) (setq cb (+ cb 32)))
                (unless (= ca cb) (return nil)))
              (setq i (+ i 1))))
          nil))))

(defun equal (a b)
  "Structural equality: EQL for atoms, recursive for conses,
   case-SENSITIVE element-wise for strings.  ANSI: EQUAL on strings
   is case-sensitive; STRING-EQUAL is the case-insensitive variant."
  (if (eql a b)
      t
      (if (consp a)
          (if (consp b)
              (if (equal (car a) (car b))
                  (equal (cdr a) (cdr b))
                  nil)
              nil)
          (if (stringp a)
              (if (stringp b)
                  (string= a b)
                  nil)
              (%equal-other a b)))))

(defun %equal-other (a b)
  "EQUAL's remaining CLHS cases, off the cons/string fast path: BIT VECTORS
   compare element-wise (respecting fill pointers) -- (equal #*01 (copy-seq
   #*01)) was NIL -- and PATHNAMES compare by namestring."
  (cond
    ((bit-vector-p a)
     (and (bit-vector-p b)
          (let ((n (length a)))
            (and (= n (length b))
                 (let ((i 0) (ok t))
                   (loop
                     (when (or (not ok) (>= i n)) (return ok))
                     (unless (eql (aref a i) (aref b i)) (setq ok nil))
                     (setq i (+ i 1))))))))
    ((pathnamep a)
     (and (pathnamep b) (string= (namestring a) (namestring b))))
    (t nil)))

;;; ============================================================
;;; Sort (insertion sort — simple, O(n²), stable)
;;; ============================================================

(defun sort-list (list pred)
  "Sort LIST using PRED as comparison function. Destructive, stable."
  (if (null list)
      nil
      (if (null (cdr list))
          list
          (let ((sorted nil)
                (cur list))
            (loop
              (when (null cur) (return sorted))
              (let ((item (car cur))
                    (next (cdr cur)))
                ;; Insert item into sorted list
                (if (null sorted)
                    (progn
                      (setq sorted (cons item nil)))
                    (if (funcall pred item (car sorted))
                        ;; Insert at front
                        (setq sorted (cons item sorted))
                        ;; Find insertion point
                        (let ((prev sorted)
                              (scan (cdr sorted))
                              (inserted nil))
                          (loop
                            (when inserted (return nil))
                            (when (null scan)
                              (set-cdr prev (cons item nil))
                              (setq inserted t))
                            (unless inserted
                              (when (funcall pred item (car scan))
                                (set-cdr prev (cons item scan))
                                (setq inserted t))
                              (unless inserted
                                (setq prev scan)
                                (setq scan (cdr scan))))))))
                (setq cur next)))))))

;;; ============================================================
;;; Apply (limited: call with list of args, up to 4 args)
;;; ============================================================

;; APPLY lives in cl-printer.lisp.  It used to be defined here too —
;; the bare-metal compiler's "last defun wins" rule meant the printer
;; version silently overrode this one and extending this body did
;; nothing.  Removed 2026-06-01; see [[reference_apply_cl_printer_override]].
;; If you want to extend the ladder or add a `%spread-call` primitive,
;; edit the cl-printer copy.

;;; ============================================================
;;; Format stub (for self-compilation — writes string to serial)
;;; ============================================================

(defun write-string-serial (str)
  "Write a string to serial output, character by character."
  (let ((len (array-length str))
        (i 0))
    (loop
      (when (= i len) (return nil))
      ;; write-char-serial wants a raw char-CODE; read the byte directly via
      ;; %prim-aref (public AREF now lifts string elements to characters).
      (write-char-serial (%prim-aref str i))
      (setq i (+ i 1)))))

(defun print-dec (n)
  "Print an integer in decimal to serial output."
  (if (< n 0)
      (progn
        (write-char-serial 45)  ;; #\-
        (print-dec (- 0 n)))
      (if (= n 0)
          (write-char-serial 48)  ;; #\0
          (let ((digits nil))
            (let ((tmp n))
              (loop
                (when (= tmp 0) (return nil))
                (setq digits (cons (+ 48 (mod tmp 10)) digits))
                (setq tmp (truncate tmp 10))))
            (let ((cur digits))
              (loop
                (when (null cur) (return nil))
                (write-char-serial (car cur))
                (setq cur (cdr cur))))))))

(defun print-hex (n)
  "Print an integer in hexadecimal to serial output."
  (if (= n 0)
      (write-char-serial 48)  ;; #\0
      (let ((digits nil)
            (tmp n))
        (loop
          (when (= tmp 0) (return nil))
          (let ((digit (logand tmp 15)))
            (if (< digit 10)
                (setq digits (cons (+ 48 digit) digits))
                (setq digits (cons (+ 55 digit) digits))))
          (setq tmp (ash tmp -4)))
        (let ((cur digits))
          (loop
            (when (null cur) (return nil))
            (write-char-serial (car cur))
            (setq cur (cdr cur)))))))

;;; ============================================================
;;; Multiple Values Support
;;; ============================================================
;;;
;;; MV-COUNT at 0x600010: number of values (tagged fixnum)
;;; MV-VALUES at 0x600020: up to 20 extra values (8 bytes each)
;;; Primary value is returned normally; extra values stored here.
;;; Any non-values form implicitly sets MV-COUNT to 1.

(defun %mv-to-list (primary)
  "Collect multiple values into a list. PRIMARY is the first value."
  (let ((count (mem-ref #x10000090 :u64)))
    (if (zerop count)
        nil
        (if (= count 1)
            (cons primary nil)
            (let ((result nil)
                  (i (- count 2)))
              (loop
                (when (< i 0) (return (cons primary result)))
                (setq result (cons (mem-ref (+ #x10000098 (* i 8)) :u64) result))
                (setq i (- i 1))))))))

;;; ============================================================
;;; Boxed IEEE float slot accessors (#201)
;;; ============================================================
;;;
;;; A boxed float (subtag #x60 double, #x64/#x65/#x66 single/short/long) has
;;; FOUR slots, each holding one 16-bit chunk of the IEEE-754 double:
;;;
;;;   slot 0 = bits 63..48    slot 1 = bits 47..32
;;;   slot 2 = bits 31..16    slot 3 = bits 15..0
;;;
;;; Each chunk is 0..65535, so the stored MACHINE WORD (chunk << 1, the fixnum
;;; tag) is 0..131070 — always positive, always low-bit-0, so the conservative
;;; collector reads the slot as a fixnum and never follows the float's raw bit
;;; pattern as a pointer.  Unlike the old 2 x 32-bit layout, chunk << 1 fits a
;;; 32-bit machine word, so the layout is width-neutral (x64 / aarch64 / i386).
;;; See docs/i386-float-blocker.md and mvm/float-slot-overrides.lisp.
;;;
;;; EVERY reader of a float's IEEE bits goes through these three functions.
;;; AREF on a float slot yields the chunk, NOT a 32-bit half — do not open-code
;;; (aref f 0) as "hi32" anywhere.

(defun %float-hi32 (f)
  "High 32 IEEE bits of boxed float F, UNSIGNED (0..2^32-1)."
  (logior (ash (%prim-aref f 0) 16) (%prim-aref f 1)))

(defun %float-lo32 (f)
  "Low 32 IEEE bits of boxed float F, UNSIGNED (0..2^32-1)."
  (logior (ash (%prim-aref f 2) 16) (%prim-aref f 3)))

;;; ---- Packed single-float vectors (subtag #x12) ------------------------
;;; The lanes hold raw IEEE32 bits; Modus's single-float VALUE is still the
;;; boxed 4-slot object with an IEEE64 payload (numeric tower N1), so every
;;; aref widens 32→64 and every aset narrows 64→32 with round-to-nearest-even
;;; (the double payload of a single-float need not be exactly representable
;;; after arithmetic).  These stay until floats are unboxed (docs/simd-plan.md).

(defun %make-f32-vector (n)
  "Allocate a packed single-float vector of N lanes, zero-filled (= 0.0f0)."
  (%alloc-f32 n))

(defun %f32-bits-ref-rt (a i) (%f32-bits-ref a i))
(defun %f32-bits-set-rt (a i bits) (%f32-bits-set a i bits))

(defun %bits->single (b)
  "IEEE32 bit pattern B (0..2^32-1) → a fresh boxed single-float."
  (let* ((s (ash b -31))
         (e8 (logand (ash b -23) 255))
         (m23 (logand b 8388607))
         (hi 0) (lo 0))
    (cond
      ((= e8 0)
       (if (= m23 0)
           (setq hi (ash s 31) lo 0)                    ; ±0.0
           ;; subnormal single → normal double: shift the mantissa up
           (let ((e -126) (m m23))
             (loop (when (>= m 8388608) (return nil))
                   (setq m (ash m 1)) (setq e (- e 1)))
             (let* ((mant52 (ash (logand m 8388607) 29))
                    (exp11 (+ e 1023)))
               (setq hi (logior (ash s 31) (ash exp11 20) (ash mant52 -32))
                     lo (logand mant52 4294967295))))))
      ((= e8 255)                                       ; inf / nan
       (let ((mant52 (ash m23 29)))
         (setq hi (logior (ash s 31) (ash 2047 20) (ash mant52 -32))
               lo (logand mant52 4294967295))))
      (t
       (let* ((mant52 (ash m23 29))
              (exp11 (+ (- e8 127) 1023)))
         (setq hi (logior (ash s 31) (ash exp11 20) (ash mant52 -32))
               lo (logand mant52 4294967295)))))
    (%float-set-bits (%make-single2) hi lo)))

(defun %single->bits (f)
  "Boxed float F (any float subtag) → the nearest IEEE32 bit pattern,
   round-to-nearest-even; overflow → ±infinity."
  (let* ((hi (%float-hi32 f)) (lo (%float-lo32 f))
         (s (ash hi -31))
         (exp11 (logand (ash hi -20) 2047))
         (mant52 (logior (ash (logand hi 1048575) 32) lo)))
    (cond
      ((= exp11 2047)                                   ; inf / nan
       (logior (ash s 31) (ash 255 23) (if (= mant52 0) 0 4194304)))
      ((and (= exp11 0) (= mant52 0)) (ash s 31))       ; ±0.0
      (t
       (let* ((e (if (= exp11 0) -1022 (- exp11 1023))) ; unbiased
              (full (if (= exp11 0) mant52 (logior mant52 4503599627370496))))
         ;; normalize a double subnormal (cannot reach single's range anyway)
         (cond
           ((> e 127) (logior (ash s 31) (ash 255 23)))
           ((< e -150) (ash s 31))                       ; below single subnormals
           (t
            ;; drop DROP low bits of FULL (53 significant bits) to a 24-bit
            ;; significand; single subnormals drop more.
            (let* ((drop (if (< e -126) (+ 29 (- -126 e)) 29))
                   (q (ash full (- drop)))
                   (rem (logand full (- (ash 1 drop) 1)))
                   (half (ash 1 (- drop 1))))
              (when (or (> rem half) (and (= rem half) (oddp q)))
                (setq q (+ q 1)))
              (cond
                ((< e -126)                             ; subnormal result
                 (if (>= q 8388608)
                     (logior (ash s 31) (ash 1 23))     ; rounded up to the smallest normal
                     (logior (ash s 31) q)))
                (t
                 (when (>= q 16777216) (setq q (ash q -1) e (+ e 1)))
                 (if (> e 127)
                     (logior (ash s 31) (ash 255 23))
                     (logior (ash s 31) (ash (+ e 127) 23) (logand q 8388607)))))))))))))

;; Element access uses the NATIVE fcvt conversion opcodes (:f32-load /
;; :f32-store — cvtss2sd/cvtsd2ss on x64, fcvt on aarch64); the bit-level
;; Lisp conversions above (%bits->single / %single->bits) remain the
;; interpreter arm and the reference the probe cross-checks against.
(defun %f32-aref (a i) (%f32-load a i))
(defun %f32-aset (a i x)
  "Store float X into lane I of the packed vector A; returns X."
  (%f32-store a i (if (floatp x) x (float x 1.0f0)))
  x)
;;; ---- f32x4 vectors (SIMD plan, layer 2a) -----------------------------
;;; The VALUE form of a 4-lane vector is a packed single-float vector of
;;; length 4.  These are the runtime (boxed, correct-everywhere) definitions;
;;; the compiler inlines the same names into the FP-register vector ops when
;;; they appear in a call-free tree over declared arrays.
(defun %f32v-ref (a i)
  "Lanes A[i..i+3] as a fresh 4-lane vector (unaligned)."
  (let ((v (%make-f32-vector 4)))
    (%f32-aset v 0 (%f32-aref a i)) (%f32-aset v 1 (%f32-aref a (+ i 1)))
    (%f32-aset v 2 (%f32-aref a (+ i 2))) (%f32-aset v 3 (%f32-aref a (+ i 3)))
    v))
(defun %f32v-set (a i v)
  "Store the 4 lanes of V at A[i..i+3]; returns V."
  (%f32-aset a i (%f32-aref v 0)) (%f32-aset a (+ i 1) (%f32-aref v 1))
  (%f32-aset a (+ i 2) (%f32-aref v 2)) (%f32-aset a (+ i 3) (%f32-aref v 3))
  v)
(defun %f32v-broadcast (x)
  (let ((v (%make-f32-vector 4)))
    (%f32-aset v 0 x) (%f32-aset v 1 x) (%f32-aset v 2 x) (%f32-aset v 3 x) v))
(defun %f32v-broadcast-ref (a i) (%f32v-broadcast (%f32-aref a i)))
(defun %f32v-map2 (f v w)
  (let ((r (%make-f32-vector 4)))
    (%f32-aset r 0 (funcall f (%f32-aref v 0) (%f32-aref w 0)))
    (%f32-aset r 1 (funcall f (%f32-aref v 1) (%f32-aref w 1)))
    (%f32-aset r 2 (funcall f (%f32-aref v 2) (%f32-aref w 2)))
    (%f32-aset r 3 (funcall f (%f32-aref v 3) (%f32-aref w 3)))
    r))
(defun %f32v+ (v w) (%f32v-map2 #'+ v w))
(defun %f32v- (v w) (%f32v-map2 #'- v w))
(defun %f32v* (v w) (%f32v-map2 #'* v w))
(defun %f32v/ (v w) (%f32v-map2 #'/ v w))

(defun %f32-aref-rt (a i) (%bits->single (%f32-bits-ref a i)))
(defun %f32-aset-rt (a i x)
  (%f32-bits-set a i (%single->bits (if (floatp x) x (float x 1.0f0)))) x)

(defun %float-set-bits (f hi lo)
  "Store the 32-bit halves HI/LO into boxed float F as four 16-bit chunks.
   HI/LO may be signed (the arithmetic path stores hi32 sign-extended) or
   unsigned; both are masked to 32 bits first.  Returns F."
  (let ((h (logand hi 4294967295))
        (l (logand lo 4294967295)))
    (%prim-aset f 0 (ash h -16))
    (%prim-aset f 1 (logand h 65535))
    (%prim-aset f 2 (ash l -16))
    (%prim-aset f 3 (logand l 65535))
    f))

;;; ============================================================
;;; Object Printer
;;; ============================================================

;; Caller sets this before write-object to bound output on potentially
;; cyclic / huge structures. Each element of a cons/array consumes one.
;; At 0 we print "..." once and stop. Set to big positive to not bound.
(defvar *write-object-budget* 0)

(defun write-object (obj)
  "Print a Lisp object to serial output (prin1-style).
   Bounded by *write-object-budget* if positive.
   Atomic types (fixnum, NIL, T) are always printed — they can't be cyclic
   and consumers like rt-run-test rely on them printing unconditionally."
  (cond
    ;; Atomic, bounded-size types: print unconditionally without touching budget.
    ((fixnump obj) (print-dec obj))
    ((null obj)    (write-char-serial 78) (write-char-serial 73) (write-char-serial 76))
    ((eq obj t)    (write-char-serial 84))
    ;; Budget-exhausted sentinel.
    ((= *write-object-budget* 0)
     ;; First time budget hits zero: emit "..." sentinel and flip to -1
     ;; so subsequent calls produce no output.
     (setq *write-object-budget* -1)
     (write-char-serial 46) (write-char-serial 46) (write-char-serial 46))
    ((< *write-object-budget* 0)
     nil)
    (t
     (setq *write-object-budget* (- *write-object-budget* 1))
     (cond
       ((null obj)
        (write-char-serial 78) (write-char-serial 73) (write-char-serial 76))
       ((eq obj t)
        (write-char-serial 84))
       ((fixnump obj)
        (print-dec obj))
       ((consp obj)
        (write-char-serial 40)
        (write-object (car obj))
        (let ((tail (cdr obj)))
          (loop
            (cond
              ((null tail) (return nil))
              ((<= *write-object-budget* 0)
               ;; Budget exhausted mid-list: emit ellipsis once and stop.
               (write-char-serial 32) (write-char-serial 46)
               (write-char-serial 46) (write-char-serial 46)
               (return nil))
              ((consp tail)
               ;; Each list element consumes one unit of budget so cons-of-fixnum
               ;; lists (which print fixnums unconditionally without decrementing)
               ;; are still bounded.
               (setq *write-object-budget* (- *write-object-budget* 1))
               (write-char-serial 32)
               (write-object (car tail))
               (setq tail (cdr tail)))
              (t
               (write-char-serial 32)
               (write-char-serial 46)
               (write-char-serial 32)
               (write-object tail)
               (return nil)))))
        (write-char-serial 41))
       ((stringp obj)
        (write-char-serial 34)
        (write-string-serial obj)
        (write-char-serial 34))
       ((symbolp obj)
        ;; Prefer the symbol's actual name when recoverable.  3-slot CL
        ;; symbols carry the name string at slot 2; 1-slot native syms
        ;; only carry a hash, fall back to the #<S<hash>> shape.
        (let ((nm (handler-case (symbol-name obj) (t (c) nil))))
          (cond
            ((and (stringp nm) (> (array-length nm) 0))
             (write-string-serial nm))
            (t
             (write-char-serial 35) (write-char-serial 60) (write-char-serial 83)
             (print-dec (aref obj 0))
             (write-char-serial 62)))))
       ((and (not (fixnump obj)) (not (consp obj)) (not (null obj))
             (= (obj-subtag obj) #x32))
        (write-char-serial 35) (write-char-serial 40)
        (let ((len (array-length obj)) (i 0))
          (loop
            (when (= i len) (return nil))
            (when (<= *write-object-budget* 0)
              (write-char-serial 32) (write-char-serial 46)
              (write-char-serial 46) (write-char-serial 46)
              (return nil))
            (when (> i 0)
              ;; Same per-element charge as the cons case — fixnums don't
              ;; consume budget on their own, so the array itself must.
              (setq *write-object-budget* (- *write-object-budget* 1))
              (write-char-serial 32))
            (write-object (aref obj i))
            (setq i (+ i 1))))
        (write-char-serial 41))
       ((characterp obj)
        ;; #\X (print the literal character after a #\ prefix)
        (write-char-serial 35) (write-char-serial 92)
        (write-char-serial (char-code obj)))
       ((and (not (fixnump obj)) (not (consp obj)) (not (null obj))
             (let ((st (obj-subtag obj))) (or (= st #x60) (and (>= st #x64) (<= st #x66)))))
        ;; Boxed IEEE float (any of #x60..#x63: double/single/short/long;
        ;; numeric tower N1) — print integer-part.fractional-part by
        ;; decoding mantissa/exponent.  Approximation: split via
        ;; %ieee-float-to-rat, scale to ~1e9, emit integer.fractional.
        (let* ((rat (%ieee-float-to-rat obj))
               (num (if (ratiop rat) (aref rat 0) rat))
               (den (if (ratiop rat) (aref rat 1) 1))
               (sign (if (< num 0) -1 1))
               (abs-num (if (< num 0) (- 0 num) num))
               (whole (truncate abs-num den))
               (frac-num (- abs-num (* whole den)))
               (frac (truncate (* frac-num 1000000) den)))
          (when (= sign -1) (write-char-serial 45))     ; -
          (print-dec whole)
          (write-char-serial 46)                         ; .
          ;; pad frac with leading zeros to 6 digits
          (let ((pad 100000))
            (loop
              (when (or (= pad 1) (>= frac pad)) (return nil))
              (write-char-serial 48)   ; 0
              (setq pad (truncate pad 10))))
          (print-dec frac)))
       (t
        ;; Emit a type-hinting sentinel that includes the subtag as a
        ;; decimal. "#<?123>" is still a distinctive "unknown type"
        ;; token but lets us tell different unprintable types apart
        ;; in test output.
        ;;
        ;; AND SAY SO WHEN THE HEADER IS A FORWARDING POINTER.  The Cheney
        ;; collector leaves `new_addr | 0x0F' in a moved object's header word
        ;; and OBJ-SUBTAG is that word's LOW BYTE, so a low nibble of #xF is
        ;; not a subtag at all — it is the tail of a forwarding pointer, and
        ;; the value being printed is a STALE reference to an object the
        ;; collector has already moved.  No subtag runtime/tags.lisp defines
        ;; has low nibble #xF, so the test is exact and not a heuristic.  The
        ;; distinction matters: "#<?111>" reads as an unprintable type and
        ;; sends you to the printer, "#<?F111>" reads as a missed GC root and
        ;; sends you to the collector.
        (write-char-serial 35) (write-char-serial 60) (write-char-serial 63)
        (when (and (not (fixnump obj)) (not (consp obj)) (not (null obj)))
          (let ((st (obj-subtag obj)))
            (when (= (logand st 15) 15)
              (write-char-serial 70))          ; F — stale forwarding header
            (print-dec st)))
        (write-char-serial 62))))))

(defun princ-object (obj)
  "Print a Lisp object to serial output (princ-style, no escapes)."
  (cond
    ((null obj)
     (write-char-serial 78)    ; N
     (write-char-serial 73)    ; I
     (write-char-serial 76))   ; L
    ((eq obj t)
     (write-char-serial 84))   ; T
    ((fixnump obj)
     (print-dec obj))
    ((consp obj)
     (write-object obj))       ; same as write-object for cons
    ((stringp obj)
     (write-string-serial obj)) ; no quotes for princ
    (t
     (write-object obj))))

;;; ============================================================
;;; Format
;;; ============================================================

(defun format (stream control &rest args)
  "Basic format: supports ~A ~S ~D ~% ~X ~B directives.
   STREAM: t = serial output, nil = not yet supported.
   Returns nil."
  (let ((len (array-length control))
        (i 0)
        (arg-rest args))
    (loop
      (when (>= i len) (return nil))
      (let ((ch (aref control i)))
        (if (= ch 126)  ; ~
            (progn
              (setq i (+ i 1))
              (when (>= i len) (return nil))
              (let ((directive (aref control i)))
                (cond
                  ;; ~A — aesthetic (princ)
                  ((or (= directive 65) (= directive 97))  ; A or a
                   (princ-object (car arg-rest))
                   (setq arg-rest (cdr arg-rest)))
                  ;; ~S — standard (prin1)
                  ((or (= directive 83) (= directive 115))  ; S or s
                   (write-object (car arg-rest))
                   (setq arg-rest (cdr arg-rest)))
                  ;; ~D — decimal
                  ((or (= directive 68) (= directive 100))  ; D or d
                   (print-dec (car arg-rest))
                   (setq arg-rest (cdr arg-rest)))
                  ;; ~X — hexadecimal
                  ((or (= directive 88) (= directive 120))  ; X or x
                   (print-hex (car arg-rest))
                   (setq arg-rest (cdr arg-rest)))
                  ;; ~% — newline
                  ((= directive 37)  ; %
                   (write-char-serial 10))
                  ;; ~~ — literal tilde
                  ((= directive 126)  ; ~
                   (write-char-serial 126))
                  ;; Unknown directive — print as-is
                  (t
                   (write-char-serial 126)
                   (write-char-serial directive)))))
            (write-char-serial ch)))
      (setq i (+ i 1))))
  nil)

;;; ============================================================
;;; Hash Tables (cons-cell alist, no arrays needed)
;;; ============================================================
;;;
;;; Structure: wrapper cons cell whose car is an alist of
;;; (key . value) pairs and whose cdr is metadata.
;;;
;;;   ht   = (cons alist meta)
;;;   meta = nil                      (legacy: equal test, no metadata)
;;;        | (cons %ht-tag (cons test (cons rsize (cons rthresh size))))
;;;
;;; %HT-TAG = 442386510 (= #x1A571A8E) is a fixnum sentinel that lets
;;; HASH-TABLE-P distinguish a real hash-table from an arbitrary cons.
;;; TEST is one of the symbols EQ EQL EQUAL EQUALP.
;;; O(n) lookup — sufficient for the small tables ANSI exercises.

(defun make-hash-table (&rest options)
  "Create a hash table.  Honoring OPTIONS (`&key TEST SIZE
   REHASH-SIZE REHASH-THRESHOLD`) is delegated to make-hash-table-args.
   The no-arg path builds a %HT-TAG-tagged table (alist still in the CAR,
   so internal callers that car/set-car the alist are unaffected) so
   HASH-TABLE-P can distinguish a real hash-table from an arbitrary cons.
   The TEST slot is NIL (not the symbol EQL) — INIT-SYMBOL-TABLE calls this
   at the very first instruction of boot, before the symbol intern table
   exists, so quoting 'EQL here would intern into an uninitialised table
   and fault.  HASH-TABLE-TEST maps a NIL test slot to EQL.

   The no-arg path now carries the SAME proper 5-list metadata tail as
   make-hash-table-args — (test rsize rthresh size bucket-holder) with
   test = NIL — so legacy tables ALSO graduate to the O(1) 256-bucket
   index once they cross %HT-BUCKET-THRESHOLD entries.  The holder's
   STRCMP? is T because the NIL-test comparator is %EQUAL-FN (strings
   compare by content), exactly like an explicit EQUAL table.  This is
   what fixes the asdf-gauntlet `wedge': the symbol intern table,
   *SYM-NAME-TABLE* (7.5k entries), *SYMBOL-FUNCTION-TABLE* (2.7k) and
   friends are all 0-arg tables, and their O(n) linear gethash walks
   made mvm-eval compiles of uiop forms take minutes each (quadratic
   blowup that presented as a deterministic rc=124 hang).  No symbol is
   quoted here — conses/fixnums/NIL/T only — so the boot-order
   constraint above still holds."
  (if (null options)
      (cons nil
            (cons (%ht-tag)
                  (cons nil                       ; test (NIL → %equal-fn)
                        (cons 2                   ; rehash-size
                              (cons 1             ; rehash-threshold
                                    (cons 16      ; size
                                          (cons (cons nil (cons 0 t)) ; bucket-holder (vec count . strcmp?)
                                                nil)))))))
      (make-hash-table-args options)))

(defun %ht-keytest (ht)
  "Return the key-comparator FUNCTION for HT's stored :TEST.

   Reads the raw test slot of the metadata directly (NOT via
   HASH-TABLE-TEST) and dispatches.  This is on the GETHASH/PUTHASH hot
   path and runs DURING %INTERN-SYMBOL-PKG at the very first instruction
   of boot — so the NIL-test fast path (every 0-arg / legacy table, incl.
   the symbol intern table itself) must return EQL WITHOUT quoting any
   symbol.  Quoting 'EQL here would call %INTERN-SYMBOL-PKG → GETHASH →
   %HT-KEYTEST → ... infinite recursion → stack overflow at boot.
   Symbol comparison (which interns 'EQ/'EQUAL/'EQUALP) is reached only
   for explicit-:TEST tables, all created after the symbol table exists.

   The NIL fast path returns %EQUAL-FN — NOT %EQL-FN — to exactly match
   the historical hardcoded-EQUAL behavior of every 0-arg / legacy table.
   Several internal 0-arg tables key on STRINGS (e.g. *MACRO-FUNCTION-
   TABLE* via %MACRO-SYM-KEY, the SFT name strings) and would MISS under
   EQL.  This is strictly no worse than the pre-fix behavior, and only
   explicit-:TEST tables get the newly-correct EQ/EQL/EQUALP dispatch."
  (let ((m (%ht-meta ht)))
    (let ((tn (if m (car m) nil)))
      (cond ((null tn)        (function %equal-fn)) ; 0-arg / legacy: EQUAL
            ((eq tn 'eq)      (function %eq-fn))
            ((eq tn 'eql)     (function %eql-fn))
            ((eq tn 'equalp)  (function equalp))
            (t                (function %equal-fn))))))

(defun gethash (key ht &optional default)
  "Look up KEY in hash table HT.  Returns (values value present-p);
   if not present, value is DEFAULT (nil if not supplied) and
   present-p is NIL.  We compute the (value present-p) pair as a cons
   inside the search loop and call `values' once at the tail — calling
   `values' inside `return' was losing the second value (loop+return
   appears to clobber MV-count on its way out).

   HOT PATH: the holder is read with plain CAR/CDR and the :NOHASH sentinel
   is compared as its literal fixnum (-424242001, see %HT-NOHASH) — every
   helper call here showed up as its own line in the in-image profile."
  (let ((found-pair nil)
        (use-linear t)
        (holder (let ((c (cdr ht)))          ; %ht-bucket-holder, inlined
                  (if (and (consp c) (eq (car c) (%ht-tag)))
                      (car (cdr (cdr (cdr (cdr (cdr c))))))
                      nil))))
    (when holder
      (let ((vec (car holder)))
        (when (null vec)
          ;; still small: build the index once the table crosses the threshold
          (when (>= (car (cdr holder)) 32)
            (setq vec (%ht-rebuild-index ht holder (cdr (cdr holder))))))
        (when (and vec (not (eq vec -424242001)))
          (if (fixnump key)
              ;; FIXNUM FAST PATH, fully inline (same mix as %ht-hash): this is
              ;; every SYMBOL-VALUE / SET-SYMBOL-VALUE of a special, every
              ;; keyword literal and every name-hash keyed compiler table.
              (let* ((k (if (< key 0) (- key) key))
                     (h (logand (logxor k (logxor (ash k -8) (ash k -16)))
                                (- (%prim-array-length vec) 1)))
                     (cur (%word-aref vec h)))
                (setq use-linear nil)
                (loop
                  (when (null cur) (return nil))
                  (let ((e (car cur)))
                    (when (eq (car e) key) (setq found-pair (cdr e)) (return nil)))
                  (setq cur (cdr cur))))
              ;; O(1) bucket path.  :NOHASH key (e.g. a string in an EQ/EQL
              ;; table) falls through to the linear path.
              (let ((r (%ht-bucket-find vec key (cdr (cdr holder)))))
                (unless (eq r -424242001)
                  (setq use-linear nil)
                  (setq found-pair r)))))))
    (when use-linear
      ;; Linear alist path (legacy / small / nohash table / :nohash key).
      (let ((cmp (%ht-keytest ht)) (cur (car ht)))
        (loop
          (when (null cur) (return nil))
          (let ((pair (car cur)))
            (when (funcall cmp (car pair) key)
              (setq found-pair pair)
              (return nil)))
          (setq cur (cdr cur)))))
    (if found-pair
        (values (cdr found-pair) t)
        (values default nil))))

(defun puthash (key ht value)
  "Set KEY to VALUE in hash table HT. Returns VALUE.
   Maintains both the authoritative CAR alist and (for large explicit-:TEST
   tables) the O(1) bucket index + the holder's entry count."
  (let* ((holder (let ((c (cdr ht)))          ; %ht-bucket-holder, inlined
                   (if (and (consp c) (eq (car c) (%ht-tag)))
                       (car (cdr (cdr (cdr (cdr (cdr c))))))
                       nil)))
         (vec (and holder (%ht-active-vec-h ht holder)))
         (strcmp? (and vec (%ht-h-strcmp holder)))
         (existing (and vec
                        (if (fixnump key)
                            ;; fixnum fast path (mirrors GETHASH)
                            (let* ((k (if (< key 0) (- key) key))
                                   (h (logand (logxor k (logxor (ash k -8) (ash k -16)))
                                              (- (%prim-array-length vec) 1)))
                                   (cur (%word-aref vec h))
                                   (r nil))
                              (loop
                                (when (null cur) (return nil))
                                (let ((e (car cur)))
                                  (when (eq (car e) key) (setq r (cdr e)) (return nil)))
                                (setq cur (cdr cur)))
                              r)
                            (%ht-bucket-find vec key strcmp?)))))
    (cond
      ;; ---- Bucket path: key IS bucketable and already present → update. ----
      ((and vec existing (not (eq existing (%ht-nohash))))
       (set-cdr existing value)               ; update shared pair in place
       value)
      ;; ---- Bucket path: key IS bucketable and absent → add + index. ----
      ((and vec (null existing))
       (let ((new-pair (cons key value)))
         (set-car ht (cons new-pair (car ht)))
         (%ht-h-set-count holder (+ (%ht-h-count holder) 1))
         ;; Keep chains short: once the table holds more than 2 entries per
         ;; bucket, rebuild the index at the next power of two (the rebuild
         ;; walks the alist, which already contains NEW-PAIR).
         (if (and (> (%ht-h-count holder) (* 2 (%prim-array-length vec)))
                  (< (%prim-array-length vec) 65536))
             (%ht-rebuild-index ht holder strcmp?)
             (%ht-bucket-put vec key new-pair strcmp?))
         value))
      ;; ---- Linear alist path (legacy / small / nohash table, OR a :NOHASH
      ;;      key under an active bucket).  Also bumps the holder count so a
      ;;      small explicit-:TEST table can later flip to the bucket index. ----
      (t
       (let ((cmp (%ht-keytest ht)) (cur (car ht)))
         (loop
           (when (null cur)
             (let ((new-pair (cons key value)))
               (set-car ht (cons new-pair (car ht)))
               (when holder (%ht-h-set-count holder (+ (%ht-h-count holder) 1))))
             (return value))
           (let ((pair (car cur)))
             (when (funcall cmp (car pair) key)
               (set-cdr pair value)
               (return value)))
           (setq cur (cdr cur))))))))

(defun remhash (key ht)
  "Remove KEY from hash table HT. Returns T if removed, NIL otherwise.
   Keeps the bucket index (if any) and the holder count in sync."
  (let* ((entries (car ht))
         (cmp (%ht-keytest ht))
         (holder (%ht-bucket-holder ht))
         (vec (and holder (%ht-active-vec-h ht holder)))
         (removed nil))
    (cond
      ((null entries) (setq removed nil))
      ((funcall cmp (car (car entries)) key)
       (set-car ht (cdr entries))
       (setq removed t))
      (t
       (let ((prev entries) (cur (cdr entries)))
         (loop
           (when (null cur) (return nil))
           (when (funcall cmp (car (car cur)) key)
             (set-cdr prev (cdr cur))
             (setq removed t)
             (return t))
           (setq prev cur)
           (setq cur (cdr cur))))))
    (when removed
      (when vec (%ht-bucket-rem vec key (%ht-h-strcmp holder)))
      (when holder (%ht-h-set-count holder (- (%ht-h-count holder) 1))))
    removed))

(defun maphash (fn ht)
  "Call FN with each key-value pair in HT."
  (let ((cur (car ht)))
    (loop
      (when (null cur) (return nil))
      (let ((pair (car cur)))
        (funcall fn (car pair) (cdr pair)))
      (setq cur (cdr cur)))))

;;; -------- ANSI hash-table accessors (added 2026-04-27) --------
;;;
;;; The legacy MAKE-HASH-TABLE above creates (cons nil nil) — equal-keyed,
;;; no recorded test/size/threshold.  These accessors return ANSI-required
;;; defaults for legacy tables; for tables created via the metadata-aware
;;; path (cl-eval.lisp's make-hash-table-args, exposed at runtime as the
;;; CL `MAKE-HASH-TABLE`), they pull the real values from the cdr.

(defun %ht-tag () 442386510)   ; #x1A571A8E

(defun %ht-meta (ht)
  "Return the (test rsize rthresh size) tail-cons, or NIL for legacy."
  (let ((c (cdr ht)))
    (if (and (consp c) (eql (car c) (%ht-tag)))
        (cdr c)
        nil)))

(defun hash-table-p (ht)
  "True iff HT is a hash-table created by MAKE-HASH-TABLE.
   Requires the (cons alist (cons %ht-tag meta)) shape — every table
   MAKE-HASH-TABLE now produces (incl. the 0-arg path) is tagged, so an
   arbitrary cons such as (cons X nil) or a 1-element list no longer
   false-positives."
  (and (consp ht)
       (let ((c (cdr ht)))
         (and (consp c) (eql (car c) (%ht-tag))))))

(defun hash-table-test (ht)
  "Return the test designator for HT — one of EQ EQL EQUAL EQUALP.
   0-arg tables carry a NIL test slot (see MAKE-HASH-TABLE) and report
   EQL (the ANSI default)."
  (let ((m (%ht-meta ht)))
    (if (and m (car m)) (car m) 'eql)))

(defun hash-table-rehash-size (ht)
  "Return the rehash-size of HT (default 2)."
  (let ((m (%ht-meta ht)))
    (if (and m (consp (cdr m))) (car (cdr m)) 2)))

(defun hash-table-rehash-threshold (ht)
  "Return the rehash-threshold of HT (default 1)."
  (let ((m (%ht-meta ht)))
    (if (and m (consp (cdr m)) (consp (cddr m))) (car (cddr m)) 1)))

(defun hash-table-size (ht)
  "Return the declared size of HT (default 16).
   Tolerates both the legacy improper meta tail (test rsize rthresh . SIZE)
   and the new proper 5-list (test rsize rthresh SIZE bucket-holder)."
  (let ((m (%ht-meta ht)))
    (if (and m (consp (cdr m)) (consp (cddr m)))
        (let ((sz-cell (cddr (cdr m))))   ; (cdddr m)
          (if (consp sz-cell)
              (car sz-cell)               ; proper 5-list: 4th element
              sz-cell))                   ; legacy improper: the tail itself
        16)))

;;; -------- O(1) bucket index over the alist (large equal/eq/eql tables) ----
;;; Modus's hash table keeps its authoritative alist in the CAR so that
;;; maphash / hash-table-count / the several internal callers that car/set-car
;;; the alist directly keep working unchanged.  For TABLES CREATED WITH AN
;;; EXPLICIT :TEST (never direct-car'd internally) we additionally maintain a
;;; 256-bucket name->pair index in the metadata's bucket-holder, built lazily
;;; once the table crosses %HT-BUCKET-THRESHOLD entries.  This turns the
;;; O(n) gethash/puthash alist scan into ~O(1) — the ASDF `ensure-package`
;;; define-package wall was ~10s per 1000-key equal table (O(n^2) probing).
;;; Small tables (the overwhelming majority, incl. every boot-time table)
;;; stay on the pure-alist path: the bucket-holder is only present on
;;; explicit-:TEST tables, and only activated past the threshold.

(defun %ht-nohash ()
  "Fixnum sentinel for `key/table is not structurally hashable'.
   Was the keyword :NOHASH — but a keyword literal compiles to a runtime
   %INTERN-KEYWORD call per evaluation, which (a) is a gethash on the
   keyword table on the gethash hot path itself, and (b) faults in
   builds that never call INIT-KEYWORD-TABLE (build-mvm) once legacy
   0-arg tables carry a bucket-holder.  A fixnum compares by EQ in one
   instruction and needs no table."
  -424242001)

(defun %ht-bucket-threshold () 32)

;;; Bucket-holder layout: (vec-or-flag count . strcmp?).
;;;   car  = vector | nil (small/unbuilt) | :nohash (bucketing disabled)
;;;   cadr = entry count (fixnum)
;;;   cddr = STRCMP? — T iff string keys compare by CONTENT (EQUAL tables);
;;;          NIL otherwise (EQ/EQL → string keys are identity, so NOT bucketed).
;;; Storing the precomputed STRCMP? boolean (not the test symbol) lets the hot
;;; path avoid a per-op (eq test 'equal) symbol compare and a HASH-TABLE-TEST
;;; meta walk — that overhead is what erased the bucket win.
(defun %ht-h-vec    (h) (car h))
(defun %ht-h-count  (h) (car (cdr h)))
(defun %ht-h-strcmp (h) (cdr (cdr h)))
(defun %ht-h-set-vec   (h v) (set-car h v))
(defun %ht-h-set-count (h n) (set-car (cdr h) n))

(defun %ht-bucket-holder (ht)
  "Return the (vec-or-flag count . strcmp?) bucket-holder cons for HT, or NIL
   for something that is not a tagged table.  HOT PATH: this runs on every
   GETHASH/PUTHASH.  Both MAKE-HASH-TABLE paths build the proper 5-list meta
   (test rsize rthresh size holder), so after the tag check the holder is a
   fixed cdr-walk with no per-link CONSP probes (the probing version alone was
   12% of the in-image profile of a library load)."
  (let ((c (cdr ht)))
    (if (and (consp c) (eq (car c) (%ht-tag)))
        (car (cdr (cdr (cdr (cdr (cdr c))))))
        nil)))

(defun %ht-hash (key strcmp? mask)
  "Cheap bucket index for KEY, or :NOHASH for a key we can't index by structure.
   STRINGS are only bucketed when STRCMP? (EQUAL tables, content compare); under
   EQ/EQL distinct string objects with equal contents are DISTINCT keys, so
   string keys are :NOHASH there (correct linear fallback).  Fixnums / chars /
   symbols / nil / t index identically under all tests (immediates / interned).
   String hash is CASE-SENSITIVE.  MASK = bucket-count minus one (the
   bucket vector is a power of two in length and GROWS with the table)."
  (cond
    ((stringp key)
     (if strcmp?
         (let ((h 2166136261) (len (array-length key)) (i 0))
           (loop
             (when (>= i len) (return nil))
             (setq h (logand (* (logxor h (%prim-aref key i)) 16777619) #xFFFFFFFF))
             (setq i (+ i 1)))
           (logand h mask))
         (%ht-nohash)))
    ;; MIX the fixnum, do not truncate it.  `(logand key 255)' keeps only the
    ;; low 8 bits, and the single biggest user of a fixnum-keyed EQL table is
    ;; the INTERPRETER's memory model, whose keys are ADDRESSES — whose low
    ;; 3-4 bits are always zero by alignment.  Truncation therefore mapped
    ;; every address into 32 of the 256 buckets (16 when 16-byte aligned) and
    ;; every access linearly scanned a chain 8-16x too long.  Measured on the
    ;; x64 CLI, 8000 keys x 200 probes, varying ONLY the key spacing:
    ;;     stride  1 (256 buckets used) -> 1 s
    ;;     stride  8 ( 32 buckets used) -> 4 s
    ;;     stride 16 ( 16 buckets used) -> 8 s
    ;; i.e. time scales inversely with the bucket count actually reached.
    ;;
    ;; Folding the high bits down mixes the alignment zeros away while staying
    ;; branch-free and allocation-free (all intermediates stay fixnums, so no
    ;; bignum path and nothing to collect).  Must agree between %ht-bucket-find
    ;; and %ht-bucket-put — both call THIS function, so they cannot diverge.
    ((fixnump key)
     (let ((k (if (< key 0) (- key) key)))
       (logand (logxor k (logxor (ash k -8) (ash k -16))) mask)))
    ((characterp key) (logand (char-code key) mask))
    ((null key) 17)
    ((eq key t) 19)
    ((%cl-sym-p key) (logand (%cl-sym-hash key) mask))
    ((%native-mvm-sym-p key) (logand (%native-mvm-sym-hash key) mask))
    (t (%ht-nohash))))

(defun %ht-vec-set (vec i val)
  "Var-index ASET forced to dest=frame-slot (CLAUDE.md var-index ASET bug)."
  (let ((dummy (aset vec i val))) dummy))

(defun %ht-new-bucket-vec (n)
  "N NIL-filled buckets (alloc-array zero-inits to fixnum 0, NOT NIL)."
  (let ((vec (make-array n)) (i 0))
    (loop
      (when (>= i n) (return vec))
      (%ht-vec-set vec i nil)
      (setq i (+ i 1)))))

(defun %ht-bucket-find (vec key strcmp?)
  "Find the (key . pair) entry in VEC's bucket for KEY; returns the alist PAIR,
   NIL (absent), or :NOHASH (key not bucketable -> caller must use the linear
   alist path).  Bucket entries store the SAME pair cons that lives in the
   table's CAR alist.  HOT PATH: the bucket is read with the leaf %WORD-AREF
   (the generic AREF's multi-dim/string dispatch was 6% of a library-load
   profile by itself), and identity keys compare with EQ -- every bucketable
   non-string key (fixnum, char, NIL, T, symbol) is an immediate or an interned
   object, so EQ is exact there; bignums/floats never reach a bucket."
  (let ((h (%ht-hash key strcmp? (- (%prim-array-length vec) 1))))
    (if (eq h (%ht-nohash))
        (%ht-nohash)
        (let ((cur (%word-aref vec h)))
          (if (and strcmp? (stringp key))
              ;; string-content path
              (loop
                (when (null cur) (return nil))
                (let ((e (car cur)))
                  (when (let ((ek (car e))) (and (stringp ek) (string= ek key)))
                    (return (cdr e))))
                (setq cur (cdr cur)))
              ;; identity path
              (loop
                (when (null cur) (return nil))
                (let ((e (car cur)))
                  (when (eq (car e) key) (return (cdr e))))
                (setq cur (cdr cur))))))))

(defun %ht-bucket-put (vec key pair strcmp?)
  "Index PAIR (the alist cons) under KEY in VEC.  Caller guarantees KEY isn't
   already present (gethash/puthash check first).  No-op for :NOHASH keys."
  (let ((h (%ht-hash key strcmp? (- (%prim-array-length vec) 1))))
    (unless (eq h (%ht-nohash))
      (let ((old (%word-aref vec h)))
        (%ht-vec-set vec h (cons (cons key pair) old)))))
  pair)

(defun %ht-bucket-rem (vec key strcmp?)
  "Remove KEY's entry from VEC's bucket."
  (let ((h (%ht-hash key strcmp? (- (%prim-array-length vec) 1))))
    (unless (eq h (%ht-nohash))
      (let ((result nil) (cur (%word-aref vec h)))
        (loop
          (when (null cur) (return nil))
          (let ((ek (car (car cur))))
            (unless (if (and strcmp? (stringp key))
                        (and (stringp ek) (string= ek key))
                        (eql ek key))
              (setq result (cons (car cur) result))))
          (setq cur (cdr cur)))
        (%ht-vec-set vec h (nreverse result))))))

(defun %ht-rebuild-index (ht holder strcmp?)
  "Build (or RE-build, larger) the bucket index from HT's current alist and
   store it in HOLDER's car.  The bucket count is a power of two sized so the
   average chain stays at or under 2 entries (min 256, max 65536): a fixed
   256 buckets over the 7.5k-entry symbol tables meant 30-entry chains on
   every GETHASH.  If any key isn't structurally hashable, mark :NOHASH and
   bail (the table permanently falls back to the linear alist scan)."
  (let ((cnt (%ht-h-count holder)) (n 256))
    (loop
      (when (or (>= n (* 2 cnt)) (>= n 65536)) (return nil))
      (setq n (* n 2)))
    (let ((vec (%ht-new-bucket-vec n)) (cur (car ht)) (ok t))
      (loop
        (when (null cur) (return nil))
        (let* ((pair (car cur)) (k (car pair)))
          (when (eq (%ht-hash k strcmp? 255) (%ht-nohash)) (setq ok nil) (return nil))
          (%ht-bucket-put vec k pair strcmp?))
        (setq cur (cdr cur)))
      (if ok
          (progn (%ht-h-set-vec holder vec) vec)
          (progn (%ht-h-set-vec holder (%ht-nohash)) (%ht-nohash))))))

(defun %ht-active-vec-h (ht holder)
  "Return the active bucket vector for HT (HOLDER already fetched), building it
   lazily once the table crosses the threshold.  Returns NIL when HT should use
   the alist path (still-small table, or a :NOHASH-disabled table)."
  (let ((v (%ht-h-vec holder)))
    (cond
      ((eq v (%ht-nohash)) nil)                 ; permanently disabled
      (v v)                                ; already built
      ((>= (%ht-h-count holder) (%ht-bucket-threshold))
       (let ((r (%ht-rebuild-index ht holder (%ht-h-strcmp holder))))
         (if (eq r (%ht-nohash)) nil r)))
      (t nil))))

(defun hash-table-count (ht)
  "Return the number of entries in HT."
  (let ((cur (car ht)) (n 0))
    (loop
      (when (null cur) (return n))
      (setq n (+ n 1))
      (setq cur (cdr cur)))))

(defun clrhash (ht)
  "Remove all entries from HT.  Returns HT.  Also resets the bucket index
   holder (vec -> nil, count -> 0) so a re-filled table re-indexes lazily."
  (set-car ht nil)
  (let ((holder (%ht-bucket-holder ht)))
    (when holder
      ;; Zero the count and reset the vec so a re-filled table re-indexes
      ;; lazily — but KEEP a :NOHASH-disabled table disabled (EQUALP tables,
      ;; and any table that earlier saw a non-bucketable key).  STRCMP? in
      ;; (cddr holder) is preserved.
      (unless (eq (%ht-h-vec holder) (%ht-nohash))
        (%ht-h-set-vec holder nil))
      (%ht-h-set-count holder 0)))
  ht)

;;; --- Metadata-aware constructor.  Kept as a separate name so the
;;; --- 0-arg make-hash-table above (called from many internal init
;;; --- sites) keeps its fixed arity — adding &rest there can interact
;;; --- badly with funcall-of-let-allocated-lambda (CLAUDE.md known bug).

(defun %ht-canonicalize-test (v)
  "Map :TEST argument V to one of EQ / EQL / EQUAL / EQUALP. Default EQL.

   Symbol path: native MVM symbols (subtag #x50, single hash slot)
   carry only their FNV-1a name-hash; SYMBOL-NAME returns \"\" for them
   so we have to compare the hash directly.  CL-symbols (cons-tagged)
   go through SYMBOL-NAME → STRING= as a fallback.

   Function path: when the source said #'EQ etc, compile-function-ref
   already rewrote that to the address of the corresponding %FOO-FN
   wrapper, and #'EQUALP loads the address of EQUALP itself.  EQL the
   FN-ADDR fixnums for an exact match."
  (cond
    ((null v) 'eql)
    ((%native-mvm-sym-p v)
     (let ((h (%native-mvm-sym-hash v)))
       (cond ((eql h 104921875) 'eq)  ; EQ
             ((eql h 366437383) 'eql)  ; EQL
             ((eql h 322164795) 'equal)  ; EQUAL
             ((eql h 127106355) 'equalp)  ; EQUALP
             (t 'eql))))
    ((symbolp v)
     (let ((n (symbol-name v)))
       (cond ((string= n "EQ") 'eq)
             ((string= n "EQL") 'eql)
             ((string= n "EQUAL") 'equal)
             ((string= n "EQUALP") 'equalp)
             (t 'eql))))
    ((eql v (function %eq-fn))    'eq)
    ((eql v (function %eql-fn))   'eql)
    ((eql v (function %equal-fn)) 'equal)
    ((eql v (function equalp))    'equalp)
    (t 'eql)))

(defun make-hash-table-args (options)
  "Internal worker: parse OPTIONS plist (`(:test eq :size 100 ...)`) and
   build a metadata-bearing hash-table.  Defaults: test=eql, rsize=2,
   rthresh=1, size=16."
  (let ((test 'eql) (rsize 2) (rthresh 1) (size 16) (cur options))
    (loop
      (when (null cur) (return nil))
      (when (null (cdr cur)) (return nil))
      (let ((k (car cur)) (v (cadr cur)))
        (cond
          ((eq k :test)             (setq test (%ht-canonicalize-test v)))
          ((eq k :size)             (setq size v))
          ((eq k :rehash-size)      (setq rsize v))
          ((eq k :rehash-threshold) (setq rthresh v))))
      (setq cur (cddr cur)))
    ;; Metadata is a PROPER 5-list: (test rsize rthresh size bucket-holder).
    ;; bucket-holder = (vec-or-flag count . strcmp?) — a mutable cell that
    ;; gethash/puthash/remhash use to maintain an O(1) bucket index once the
    ;; table grows past %HT-BUCKET-THRESHOLD entries.  car nil = no index yet
    ;; (still small); car :NOHASH = bucketing disabled (EQUALP, or a key we
    ;; can't structure-hash was inserted); car <vector> = active index.  cddr
    ;; STRCMP? (precomputed: T for EQUAL tables) lets the hot path decide
    ;; string-by-content vs identity WITHOUT a per-op HASH-TABLE-TEST meta walk
    ;; or symbol compare — that overhead is what erased the bucket win.
    ;; The 0-arg / legacy MAKE-HASH-TABLE path (NIL test) does NOT get this
    ;; tail — it stays the pure-alist shape so boot-critical tables (the symbol
    ;; intern table, macro table, ...) are byte-identical and never bucketed.
    ;; EQUALP gets the index pre-disabled (car=:NOHASH): EQUALP string keys are
    ;; case-INSENSITIVE and EQUALP conflates e.g. 1/1.0, but the index is
    ;; EQUAL-grade — so EQUALP tables stay on the correct linear path.
    (let ((holder (cons (if (eq test 'equalp) (%ht-nohash) nil)
                        (cons 0 (eq test 'equal)))))
      (cons nil
            (cons (%ht-tag)
                  (list test rsize rthresh size holder))))))

;;; ============================================================
;;; Gensym (for macro expansion)
;;; ============================================================

(defvar *gensym-counter* 0)

(defun gensym (&optional prefix)
  "Generate a unique integer ID. PREFIX is ignored on bare metal.
   ANSI gensym takes &optional prefix; making this an &optional matches
   that and lets compile-call's arity check distinguish (gensym) (valid)
   from (gensym 1 2 3) (invalid)."
  (let ((n *gensym-counter*))
    (setq *gensym-counter* (+ *gensym-counter* 1))
    n))

;;; ============================================================
;;; String construction (for format replacement)
;;; ============================================================

(defun princ-to-string (obj)
  "Identity — on bare metal, values are used as-is."
  obj)

(defun string (x)
  "Identity — on bare metal, symbols are already name-hashes or strings."
  x)

;;; ============================================================
;;; Multiple Values (bare-metal stub)
;;; ============================================================
;;;
;;; values is a compiler special form (compile-values).
;;; This function handles the funcall/apply case: (apply #'values list).
;;; It manually sets the MV buffer and returns the primary value.
;;; The function epilogue does NOT emit set-mv-count 1 (special-cased in compiler).
(defun values (&rest args)
  "Return multiple values. Sets MV buffer for count and extra values."
  (let ((n (length args)))
    (setf (mem-ref #x10000090 :u64) n)
    (let ((cur (if (null args) nil (cdr args)))
          (idx 0))
      (loop
        (when (null cur) (return nil))
        (setf (mem-ref (+ #x10000098 (* idx 8)) :u64) (car cur))
        (setq idx (+ idx 1))
        (setq cur (cdr cur))))
    (if (null args) nil (car args))))

;;; ============================================================
;;; Global Variable Store (bare-metal)
;;; ============================================================
;;;
;;; The MVM compiler emits calls to SYMBOL-VALUE and SET-SYMBOL-VALUE
;;; for defvar/defparameter globals. On bare metal, we implement these
;;; using an alist stored at fixed address 0x600000.
;;; (Was 0x400000 but image+fn-table can extend past 0x400000 for large
;;; builds like fixpoint-ssh. 0x600000 is above page tables at 0x500000.)
;;; Keys are tagged name hashes (fixnums), values are arbitrary.
;;; mem-ref :u64 returns raw bits, which for tagged Lisp values is
;;; the value itself (cons pointers, fixnums, etc.).

;; The global special-variable store at #x10000080 is a HASH TABLE keyed by
;; name-hash (a 60-bit FIXNUM per compute-name-hash — so %ht-hash buckets it
;; O(1)).  It was a hand-rolled LINEAR ALIST until this commit: every global
;; read/write walked the whole chain (symbol-value/set-symbol-value/boundp),
;; and each non-matching node paid an EQL→%IEEE-FLOAT-P comparator call.  UIOP
;; defines hundreds of specials, so the walk cost grew with the corpus and the
;; asdf-gauntlet's big WITH-UPGRADABILITY blocks (which read/write many globals)
;; hit an O(#globals × #accesses) quadratic — minutes/form at forms ~99–109.
;; This is the SAME family as 194bbfb (unindexed alist) but a DIFFERENT site.
;; A 0-arg make-hash-table graduates to the O(1) 256-bucket index past its
;; threshold; the head slot is forwarded by GC exactly like the keyword table
;; (#x10000148) and pkg-by-hash table (#x10000170), which are already
;; hash-table objects at BSS slots — so NO GC change is needed.  (The store
;; head is a hash-table = a cons whose car is the alist and whose cdr carries
;; the %HT-TAG metadata; a value of raw 0 means "not yet created".)
;;; ============================================================
;;; THE RUNTIME-TABLE LOCK
;;; ============================================================
;;;
;;; THE PROBLEM IT EXISTS FOR.  The globals hash table below, the symbol intern
;;; table at #x10000088, the keyword table at #x10000148, the package-by-hash
;;; table at #x10000170 and the macro expander table in mvm/cl-eval.lisp are ONE
;;; SET OF SHARED MUTABLE STRUCTURES.  Every thread interns into them, and a
;;; concurrent PUTHASH is not merely a lost entry: two threads that both miss the
;;; same GETHASH both allocate a symbol and both store it, so `(eq 'foo 'foo)'
;;; stops holding ACROSS THREADS — the one invariant the whole symbol system
;;; rests on.  Until this existed, a second thread could run computation but not
;;; Lisp, and the threaded selftests said so in their headers.
;;;
;;; IT IS A GATE, AND THE GATE IS OFF EVERYWHERE BY DEFAULT.  #x10000DB8 is a
;;; BSS word; nothing writes it unless a program deliberately declares that it
;;; is running more than one thread through the runtime.  While it reads zero —
;;; which is every image ever built, every bare-metal target, every ANSI gate
;;; runner and every ordinary ./modus — %RT-ENTER and %RT-LEAVE are one 32-bit
;;; load and a branch, and the two functions they would call are the NO-OPS
;;; defined here.  A hosted x86-64 image overrides those two
;;; (net/hosted-sync.lisp) with the real thing: a RECURSIVE futex mutex that
;;; also makes region 0 the active heap for the duration, so that everything
;;; allocated while the shared tables are being mutated lands in ONE region
;;; rather than in the mutating thread's own — a symbol reachable only from a
;;; table in region 0 would otherwise be collected the next time its own
;;; thread's region was.
;;;
;;; WHY THE NO-OPS ARE DEFINED HERE RATHER THAN LEFT UNRESOLVED.  An unresolved
;;; call resolves to %UNRESOLVED-FN, which is harmless at runtime but shows up
;;; in every build's unresolved-function census; and the census is a ratchet.
;;; Two one-line defuns keep every non-hosted image's count exactly where it was.
(defun %rt-threads-live-p ()
  "Non-zero when more than one thread is running Lisp through the shared
   runtime tables.  Zero — the BSS default — everywhere else."
  (mem-ref #x10000DB8 :u32))

(defun %rt-enter-locked () 0)
(defun %rt-leave-locked () 0)

(defun %rt-enter ()
  (if (= (mem-ref #x10000DB8 :u32) 0) 0 (%rt-enter-locked)))

(defun %rt-leave ()
  (if (= (mem-ref #x10000DB8 :u32) 0) 0 (%rt-leave-locked)))

(defun %globals-table ()
  "The globals hash-table object at #x10000080, or NIL if not yet created."
  (let ((head (mem-ref #x10000080 :u64)))
    (if (or (eql head 0) (not (consp head))) nil head)))

;;; ============================================================
;;; PER-THREAD DYNAMIC BINDINGS
;;; ============================================================
;;;
;;; A DYNAMIC BINDING MADE ON A WORKER MUST NOT BE PUBLISHED INTO REGION 0.
;;; Modus shallow-binds specials: COMPILE-LET-WITH-SPECIALS saves the global
;;; cell into a lexical, writes the new value with SET-SYMBOL-VALUE and puts
;;; the old one back in an unwind-protect.  On a worker thread that is the one
;;; forbidden direction of the rule per-region collection rests on:
;;;
;;;   (let ((*tx* (list 0))) …)   on a worker
;;;     1. (LIST 0) conses in the WORKER's region;
;;;     2. the bind writes that cons into the globals table, which lives in
;;;        REGION 0.
;;;
;;; The worker's collector is copying, so the cons is evacuated or reclaimed
;;; and the region-0 slot is never updated: the cell is re-issued as fresh
;;; allocation while *TX* still names it, and its CAR comes back a CHARACTER
;;; or a FUNCTION.  Measured with a between-arm control in
;;; test/glass-tx-cell.lisp: `txfr' (*tx* = a fresh cons) goes FR[pre]=0 ->
;;; FR[post]=1 while `bothnilfr' (*tx* = NIL — nothing to publish) stays 0,
;;; with the same nesting, the same lock and the same 17 collections of the
;;; worker's region between them.
;;;
;;; SO THE BINDING LIVES IN THE THREAD'S OWN STORAGE, WHICH IS WHAT SBCL DOES
;;; WITH PER-SYMBOL TLS INDICES.  Three shapes were rejected first and none of
;;; them should be re-proposed:
;;;   * keeping the value alive in the binding's stack record — it stops being
;;;     COLLECTED but the copying collector still MOVES it, and nothing updates
;;;     the region-0 slot: a use-after-free traded for a stale pointer;
;;;   * copying the value on publish (the CL:INTERN arena route) — interning
;;;     copies a STRING whose identity nobody holds, but a special can be bound
;;;     to any object and EQ IS OBSERVABLE: *TX* must be the same cons TX+
;;;     increments;
;;;   * evaluating the initform in the arena — fixes (let ((*x* (list 0)))) and
;;;     not (let ((*x* some-existing-worker-object))), i.e. it passes the test
;;;     and leaves the general case broken.
;;;
;;; WHERE IT LIVES.  Each thread's 4 KB PER-THREAD WINDOW block (net/hosted-
;;; sync.lisp's %THR-TLS-BLOCK) has its top unused: the window's own slots stop
;;; at offset 0xC37.  Offsets 0xC50..0xFFF of a WORKER's block are private
;;; memory nothing else addresses — the process-global words that share those
;;; ADDRESSES (0x10000DB8, 0x10000DF0, 0x10000E00…, 0x10000F08) are main-image
;;; BSS, not part of any worker's block, which is why this area is addressed
;;; ABSOLUTELY from the thread's own base rather than being claimed as new
;;; window offsets.  (The claim in the campaign notes that "0xC38..0xFFF are
;;; unclaimed" is about window OFFSETS and is false as an address range.)
;;;
;;;   blk+0xC50   address of the next free entry (0 = never used yet)
;;;   blk+0xC58   depth, as a TAGGED fixnum — the collector reads it and
;;;               untags with one SHR, exactly like the MV count
;;;   blk+0xC60   entry 0: [key][value], 16 bytes, 58 of them to blk+0x1000
;;;
;;; THE VALUE SLOTS ARE A GC ROOT OF THE OWNING THREAD'S REGION.  A raw
;;; per-thread word is NOT a root — the precise root set is the fixed list in
;;; EMIT-GC-TRAMPOLINE — so translate-x64's trampoline grew a loop over exactly
;;; DEPTH value words, reached through EMIT-TLS-BASE just as the MV-extras loop
;;; is.  The collector runs on the thread that hit its own limit, so the stack
;;; it walks is that thread's.  Without it this would be the rejected shape
;;; above with the staleness merely moved.
;;;
;;; AND EVERY UNARMED THREAD TAKES TODAY'S PATH.  The gate is
;;; (mem-ref #x10000DB8 :u32) — the SAME word %RT-ENTER already tests, zero in
;;; every image that has not declared it is running Lisp on more than one
;;; thread — so a single-threaded ./modus, every bare-metal image and every
;;; ANSI gate runner pays one 32-bit load and a branch on the read path and
;;; reaches the identical code.  The MAIN thread of an armed image is unarmed
;;; too: its FS base is 0 (nothing ever wrote the self slot), %DYNB-BLOCK
;;; answers 0, and it shallow-binds exactly as before.  That is deliberate and
;;; it is not a gap: main IS region 0's mutator, so a binding main publishes
;;; into the globals table creates no cross-region pointer.
(defun %dynb-block ()
  "This thread's per-thread window BLOCK, or 0 when it has none.

   Reads the self slot THROUGH the window (offset 0xC30 is a window slot, so
   the access carries the FS override), which is what makes it answer about
   THIS thread.  The slot holds the segment BASE, not the block, so the main
   thread's BSS zero is both the correct base and the correct answer here."
  (let ((lo (mem-ref #x10000C30 :u32))
        (hi (mem-ref #x10000C34 :u32)))
    (if (eql hi 0)
        (if (eql lo 0) 0 (+ #x10000000 lo))
        (+ #x10000000 (+ (* (* hi 65536) 65536) lo)))))

(defun %dynb-depth (blk)
  "Number of live dynamic bindings on this thread's stack.  Stored TAGGED so
   the collector can untag it with one SHR, as it does the MV count."
  (mem-ref (+ blk #xC58) :u64))

(defun %dynb-next (blk)
  "Address of the next free entry's KEY word."
  (let ((a (mem-ref (+ blk #xC50) :u64)))
    (if (eql a 0) (+ blk #xC60) a)))

(defun %dynb-set-top (blk next depth)
  "Publish the stack top.  ORDER IS THE CONTRACT: a caller writes the entry
   BEFORE calling this, because the collector scans exactly DEPTH entries and
   would otherwise walk a word the previous occupant left behind."
  (setf (mem-ref (+ blk #xC50) :u64) next)
  (setf (mem-ref (+ blk #xC58) :u64) depth)
  depth)

(defun %dynb-find (key a i)
  "Address of the VALUE word of the innermost binding of KEY, or 0.  A is the
   KEY word of entry I; walk DOWN so an inner binding shadows an outer one.

   NO MULTIPLICATION AND NO GLOBAL READ ANYWHERE ON THIS PATH — it is called
   from SYMBOL-VALUE, so anything that itself read a global would recurse."
  (if (< i 0)
      0
      (if (eql (mem-ref a :u64) key)
          (+ a 8)
          (%dynb-find key (- a 16) (- i 1)))))

(defun %dynb-unwind (blk key a i)
  "Pop the innermost binding of KEY, and everything above it, by truncating
   the stack to entry I.  Answers 1 when it found one, 0 when it did not.

   TRUNCATE RATHER THAN POP, and the difference is load-bearing.  A LET* of
   two specials evaluates its inits INSIDE the unwind-protect, so a throw out
   of the second init leaves the first bound and the second not, while the
   cleanup still runs BOTH restores; and the restores run in binding order,
   not reverse.  Truncation is right in both cases — by the time this
   cleanup runs every INNER binding has already been popped by its own
   cleanup, so nothing above I is live."
  (if (< i 0)
      0
      (if (eql (mem-ref a :u64) key)
          (progn (%dynb-set-top blk a i) 1)
          (%dynb-unwind blk key (- a 16) (- i 1)))))

(defun %dynb-overflow (key)
  "58 nested special bindings on one thread.  An honest error rather than a
   silent shallow bind: a shallow bind here is the region-0 publication this
   whole mechanism exists to prevent, and it would additionally desynchronise
   the stack so the matching %DYNUNBIND truncated somebody else's entry."
  (error "dynamic binding stack exhausted (58 nested specials) for key ~S" key))

(defun %dynbind (key val)
  "Establish a dynamic binding of the global named by KEY (a name hash).
   A drop-in replacement for the SET-SYMBOL-VALUE that COMPILE-LET-WITH-
   SPECIALS used to emit, and identical to it on every unarmed thread.

   THE UNARMED ARM GOES THROUGH %GV-SET, NOT SET-SYMBOL-VALUE.  %GV-SET is
   SET-SYMBOL-VALUE with the in-place update the compiled SETQ of a special
   already uses: it probes the globals table's bucket layout directly with
   %GV-CELL and SET-CDRs the pair, where SET-SYMBOL-VALUE reaches the same
   table through the generic PUTHASH.  A LET of a special paid that twice,
   once to install and once to restore, and a dynamic binding is not a rare
   operation -- it is every WITH-* macro in the system.

   ONLY THE UNARMED ARM, and the narrowing is measured rather than cautious.
   The arm below it -- threads declared, but this thread has no binding
   block, i.e. the main thread of an armed image -- looks equally safe and
   is not: substituting %GV-SET there as well makes test/hosted-dynbind.lisp
   die with a READER-ERROR the moment the worker starts, on a build where
   every other change in the tree passes it.  The mechanism was not chased,
   so the honest statement is that SET-SYMBOL-VALUE does something on that
   path that this does not (it takes %RT-ENTER / %RT-LEAVE, which is both a
   lock and a region hop) and that the difference matters once a second
   thread exists.  The arm that IS taken has established that the image
   never declared threads at all, where there is nothing for either to do."
  (if (eql (mem-ref #x10000DB8 :u32) 0)
      (%gv-set key val)
      (let ((blk (%dynb-block)))
        (if (eql blk 0)
            (set-symbol-value key val)
            (let ((d (%dynb-depth blk))
                  (a (%dynb-next blk)))
              (if (>= d 58)
                  (%dynb-overflow key)
                  (progn
                    ;; Entry first, top second — see %DYNB-SET-TOP.
                    (setf (mem-ref a :u64) key)
                    (setf (mem-ref (+ a 8) :u64) val)
                    (%dynb-set-top blk (+ a 16) (+ d 1))
                    val)))))))

(defun %dynunbind (key saved)
  "Undo the matching %DYNBIND.  SAVED is the value the compiler read before
   the binding was made; it is what the shallow path restores and what the
   deep path ignores, because the deep path's outer value is still sitting in
   the entry below the one it truncates away."
  (if (eql (mem-ref #x10000DB8 :u32) 0)
      (%gv-set key saved)
      (let ((blk (%dynb-block)))
        (if (eql blk 0)
            (set-symbol-value key saved)
            (let ((d (%dynb-depth blk)))
              (if (<= d 0)
                  saved
                  (progn (%dynb-unwind blk key (- (%dynb-next blk) 16) (- d 1))
                         saved)))))))

(defun symbol-value (name-or-hash)
  "Look up a global variable by name hash or symbol object.
   O(1) via the globals hash table at #x10000080."
  ;; CLHS: (symbol-value nil) ≡ nil, (symbol-value 't) ≡ t — constants
  ;; with no table entry needed.  Without this, (aref nil 0) would fault.
  (when (null name-or-hash) (return-from symbol-value nil))
  (when (eq name-or-hash t) (return-from symbol-value t))
  (let ((key (if (integerp name-or-hash) name-or-hash
                 (aref name-or-hash 0))))
    ;; THIS THREAD'S OWN DYNAMIC BINDINGS COME FIRST — see PER-THREAD DYNAMIC
    ;; BINDINGS above.  The gate is the word %RT-ENTER already tests, so an
    ;; image that never declared itself threaded pays one 32-bit load and a
    ;; branch and reaches the identical code below; the main thread of a
    ;; threaded image pays two more and reaches it too, because its window
    ;; base is zero.  A binding found here needs NO LOCK and no region hop:
    ;; the storage is this thread's and nothing else can be in it.
    (unless (eql (mem-ref #x10000DB8 :u32) 0)
      (let ((blk (%dynb-block)))
        (unless (eql blk 0)
          (let ((a (%dynb-find key (- (%dynb-next blk) 16)
                               (- (%dynb-depth blk) 1))))
            (unless (eql a 0)
              (return-from symbol-value (values (mem-ref a :u64))))))))
    ;; THE READ IS LOCKED TOO, and not out of caution: PUTHASH grows and
    ;; REHASHES this table, and a reader walking it mid-rehash sees a structure
    ;; that is momentarily neither the old one nor the new one.  Under a single
    ;; thread %RT-ENTER is a load and a branch.
    (%rt-enter)
    (let ((tbl (%globals-table)))
    ;; GETHASH returns (VALUES value present-p) — TWO values.  Returning it
    ;; directly in tail position PROPAGATES both, leaving MV-COUNT=2 for the
    ;; caller.  The old linear-alist SYMBOL-VALUE returned exactly one value,
    ;; and callers depend on that: e.g. BOOLE reads its BOOLE-* op constants
    ;; (globals) via SYMBOL-VALUE inside its COND, then returns a bare value —
    ;; the leaked MV-COUNT=2 survives to `(multiple-value-list (boole …))`,
    ;; which then reports length 2 (boole.2 collected spuriously) or corrupts
    ;; the funcall MV path into a wild call (boole.1/.3 → RIP=0xDEAD0004).
    ;; Truncate to a single value with (VALUES …), which forces MV-COUNT=1.
      (let ((v (if tbl (gethash key tbl) nil)))
        (%rt-leave)
        (values v)))))

(defun set-symbol-value (name-hash value)
  "Set a global variable by its tagged name hash.  O(1) via the globals
   hash table at #x10000080, created lazily on first use."
  ;; A SETQ OF A SPECIAL THIS THREAD HAS BOUND MUST HIT THAT BINDING, not the
  ;; process-wide cell — otherwise (let ((*x* …)) (setq *x* …)) on a worker
  ;; would put the worker's object back into region 0 through the side door.
  ;; Assignment to a special this thread has NOT bound still writes the shared
  ;; table: that is a different operation with a different (and still open)
  ;; cross-region story, and it is not what a LET does.
  (unless (eql (mem-ref #x10000DB8 :u32) 0)
    (let ((blk (%dynb-block)))
      (unless (eql blk 0)
        (let ((a (%dynb-find name-hash (- (%dynb-next blk) 16)
                             (- (%dynb-depth blk) 1))))
          (unless (eql a 0)
            (setf (mem-ref a :u64) value)
            (return-from set-symbol-value value))))))
  (%rt-enter)
  (let ((tbl (%globals-table)))
    (unless tbl
      (setq tbl (make-hash-table))
      (setf (mem-ref #x10000080 :u64) tbl))
    ;; A pair that does not exist yet is about to be CREATED, and a memoised
    ;; pointer to some earlier pair for this key would then address a cell the
    ;; table no longer consults.  Drop the memo before the insert.  The cache
    ;; word is tested FIRST so an image built without the cache (the default)
    ;; pays one load and a branch here, not a table probe per insert.
    (unless (fixnump (mem-ref #x10000FA0 :u64))
      (unless (%gv-cell name-hash) (%gv-cache-flush)))
    (puthash name-hash tbl value))
  (%rt-leave)
  value)

(defun %gv-cell (%gv-key)
  "The (key . value) pair for global KEY (a name-hash fixnum) in the globals
   table, or NIL if absent / table not yet built.  HOT PATH: this is the
   compiled read/write of every special variable (compile-variable-ref and
   compile-setq emit %GV-REF / %GV-SET).  A tight probe of the existing
   table — same bucket layout as GETHASH's fixnum path (see %HT-HASH) — with
   none of GETHASH's generality: a special read went 112 ns -> ~25 ns.  Falls
   back to NIL (= use the slow path) while the table is still small (no
   bucket vector yet)."
  (let ((%gv-ht (mem-ref #x10000080 :u64)))
    ;; EQ, not EQL: EQL is a full function here, and any callee of this probe
    ;; that reads a special re-enters %GV-REF -> %GV-CELL (boot stack overflow).
    (if (or (eq %gv-ht 0) (not (consp %gv-ht)))
        nil
        (let* ((%gv-c (cdr %gv-ht))
               (%gv-holder (and (consp %gv-c) (car (cdr (cdr (cdr (cdr (cdr %gv-c))))))))
               (%gv-vec (and %gv-holder (car %gv-holder))))
          (if (or (null %gv-vec) (fixnump %gv-vec))
              (%gv-cell-slow %gv-key %gv-ht)
              ;; ONE HASH FUNCTION, CALLED — never a second copy of the mix.
              ;; This used to inline %HT-HASH's fixnum arithmetic for speed.
              ;; The copy and the original are the same source and still
              ;; disagreed once compiled: on the JS MVM (web/mvm.js) the same
              ;; key and mask gave bucket 0x74F here and 0x8DE in %HT-HASH, so
              ;; every global read missed its bucket, %GV-SET re-inserted
              ;; instead of updating, and *SYMBOL-FUNCTION-TABLE* read back NIL
              ;; at boot.  %HT-BUCKET-FIND and %HT-BUCKET-PUT already state the
              ;; rule this violated: both call THIS function, so they cannot
              ;; diverge.  A duplicated hash is a latent bug on any target
              ;; whose codegen differs at the two sites.
              (let ((%gv-h (%ht-hash %gv-key nil
                                     (- (%prim-array-length %gv-vec) 1))))
                (if (fixnump %gv-h)
                    (let ((%gv-cur (%word-aref %gv-vec %gv-h)))
                      (loop
                        (when (null %gv-cur) (return nil))
                        (let ((%gv-e (car %gv-cur)))
                          (when (eq (car %gv-e) %gv-key) (return (cdr %gv-e))))
                        (setq %gv-cur (cdr %gv-cur))))
                    ;; :NOHASH — not a bucketable key; the alist is the answer
                    (%gv-cell-slow %gv-key %gv-ht))))))))

(defun %gv-cell-slow (%gv-key %gv-ht)
  "Linear-alist probe for a globals table that has no bucket index yet."
  (let ((%gv-cur (car %gv-ht)))
    (loop
      (when (null %gv-cur) (return nil))
      (let ((%gv-pair (car %gv-cur)))
        (when (eq (car %gv-pair) %gv-key) (return %gv-pair)))
      (setq %gv-cur (cdr %gv-cur)))))

(defun %dynb-value-addr (key)
  "Address of THIS THREAD's innermost dynamic binding of KEY, or 0.

   The one place the three COMPILED read paths ask the question, so they
   cannot drift apart again -- which is exactly what happened: %DYNBIND puts
   a worker's binding in that thread's own storage, SYMBOL-VALUE was taught
   to look there, and the compiled reads (which is what a reference to a
   special in compiled code actually becomes) were not.  The gate is the
   word %RT-ENTER and %DYNBIND already test, so an unarmed image pays one
   32-bit load and a branch."
  (if (eql (mem-ref #x10000DB8 :u32) 0)
      0
      (let ((blk (%dynb-block)))
        (if (eql blk 0)
            0
            (%dynb-find key (- (%dynb-next blk) 16) (- (%dynb-depth blk) 1))))))

(defun %gv-ref (%gv-key)
  "Compiled special-variable READ: value of global KEY, NIL if absent
   (SYMBOL-VALUE's contract for an integer key).  Locals are %GV-prefixed on
   purpose: a plain name that is also a known global would compile as a
   DYNAMIC bind, which calls %GV-SET, which calls this — infinite recursion
   at boot (seen with the first version).

   THIS THREAD'S OWN DYNAMIC BINDINGS COME FIRST, for the same reason
   SYMBOL-VALUE consults them: %DYNBIND puts a worker's binding in that
   thread's own storage and NOT in the globals table, so a read that goes
   straight to the table does not see the binding it is inside.  This is the
   COMPILED read — what every reference to a special in compiled code
   becomes — so without this the per-thread mechanism is established by the
   binding and then ignored by every reader of it.  The gate is the word
   %RT-ENTER and %DYNBIND already test: an image that never declared itself
   threaded pays one 32-bit load and a branch and reaches the identical line
   below, and the main thread of a threaded image pays two more and reaches
   it too, because its window base is zero."
  ;; The arming-word test is INLINE, not inside the helper: a CALL here is not
  ;; "one load and a branch", and this is the read every reference to a
  ;; special in compiled code becomes.  Measured with the helper called
  ;; unconditionally: PRIN1-TO-STRING +30%.
  (if (eql (mem-ref #x10000DB8 :u32) 0)
      (let ((%gv-cl (%gv-cell %gv-key)))
        (if %gv-cl (cdr %gv-cl) nil))
      (let ((%gv-a (%dynb-value-addr %gv-key)))
        (if (eql %gv-a 0)
            (let ((%gv-cl (%gv-cell %gv-key)))
              (if %gv-cl (cdr %gv-cl) nil))
            (mem-ref %gv-a :u64)))))

;;; ---- The global-cell cache (see the block comment above
;;; ---- %COMPILE-GLOBAL-READ-AOT in mvm/compiler.lisp) ----
;;;
;;; #x10000FA0 holds a vector of 16384 cells, indexed by a slot the COMPILER
;;; assigned to each global name at build time.  An AOT read loads the vector,
;;; loads its slot, and CDRs the pair; only a miss reaches here.  The literals
;;; are spelled out rather than shared through a constant because prelude and
;;; compiler are compiled as separate units and a defconstant that disagreed
;;; would alias two globals onto one slot silently.

(defun %gv-cache-init-once ()
  "Create the cache vector, at most once.  The guard word at #x10000FA8 is
   what makes this safe to call from the miss path: MAKE-ARRAY itself reads
   specials, and each of those reads misses and calls back in here, so an
   unguarded version recurses until the stack ends."
  (when (eq (mem-ref #x10000FA8 :u64) 0)
    (setf (mem-ref #x10000FA8 :u64) 2)   ; tagged fixnum 1
    ;; NIL-filled, not merely zero-filled.  ALLOC-ARRAY zero-inits to FIXNUM 0
    ;; on the arches that have the zero-init (x64, i386); the read site's CONSP
    ;; test rejects a 0 anyway, but a bare-metal arena that is not zeroed would
    ;; otherwise hand the read a word that could be cons-TAGGED garbage, and a
    ;; cached pointer is exactly the thing that must never be garbage.
    ;; Publish the vector LAST: until #x10000FA0 is non-fixnum every read takes
    ;; the miss path, which is what makes the fill loop's own special reads
    ;; (and MAKE-ARRAY's) safe.
    (let ((%gv-cv (make-array 16384)) (%gv-i 0))
      (loop
        (when (>= %gv-i 16384) (return nil))
        (%ht-vec-set %gv-cv %gv-i nil)
        (setq %gv-i (+ %gv-i 1)))
      (setf (mem-ref #x10000FA0 :u64) %gv-cv))))

(defun %gv-cache-flush ()
  "Drop every memoised cell.  Called whenever a global's pair is CREATED,
   which is the only event that can make a memoised pointer point at a pair
   the table no longer consults."
  (let ((%gv-cv (mem-ref #x10000FA0 :u64)))
    (if (fixnump %gv-cv)
        nil
        (let ((%gv-i 0))
          (loop
            (when (>= %gv-i 16384) (return nil))
            (%ht-vec-set %gv-cv %gv-i nil)
            (setq %gv-i (+ %gv-i 1)))))))

(defun %gv-ref-fill (%gv-key %gv-slot)
  "AOT special-variable read, slow path: the value of global KEY, NIL when it
   has no cell -- %GV-REF's contract exactly -- memoising the cell in cache
   slot SLOT when there is one.  A global with no cell is NOT cached, so one
   created later by SETQ is picked up by the next read.
   The slot is re-checked before probing: the inline read already did, so that
   costs one load there, and it is what makes the CALL-only emission
   (*GV-CACHE-MODE* :call) a real fallback rather than a slowdown."
  (let ((%gv-cv (mem-ref #x10000FA0 :u64)))
    (if (fixnump %gv-cv)
        (progn (%gv-cache-init-once) (%gv-ref %gv-key))
        (let ((%gv-hit (%word-aref %gv-cv %gv-slot)))
          (if (if (consp %gv-hit) (eq (car %gv-hit) %gv-key) nil)
              (cdr %gv-hit)
              (let ((%gv-cl (%gv-cell %gv-key)))
                (if (consp %gv-cl)
                    ;; The store is BOUND, not sequenced: a variable-index
                    ;; ASET in a non-last position compiles with dest=nil and
                    ;; may not land (CLAUDE.md Active Limitation 2) --
                    ;; %HT-VEC-SET does the same.
                    (let ((%gv-st (%word-aset %gv-cv %gv-slot %gv-cl)))
                      %gv-st
                      (cdr %gv-cl))
                    nil)))))))

(defun %gv-set-def (%gv-key %gv-val)
  "The DEFVAR/DEFPARAMETER store: %GV-SET under a name the bytecode
   interpreter recognises as a storage sink (see %MVM-STORE-FN-NAME-P)."
  (%gv-set %gv-key %gv-val))

(defun %gv-set (%gv-key %gv-val)
  "Compiled special-variable WRITE: update in place when the global exists,
   else insert through SET-SYMBOL-VALUE (which also creates the table).

   A SETQ OF A SPECIAL THIS THREAD HAS BOUND MUST HIT THAT BINDING, which is
   the rule SET-SYMBOL-VALUE already states and this -- the COMPILED write,
   i.e. what every SETQ of a special in compiled code becomes -- did not
   follow.  The read twin of the same omission is in %GV-REF.  Without it a
   worker's (let ((*x* 1)) (setq *x* 9) ...) wrote 9 into the PROCESS-WIDE
   cell, so the binding did not see its own assignment and main was left
   holding 9 after the worker exited: bits 16 and 32 of
   test/hosted-dynbind.lisp, plus its *DA*-on-main check.

   Assignment to a special this thread has NOT bound still writes the shared
   table.  That is a different operation with its own open cross-region
   story, and it is not what a LET does."
  ;; Inline gate, as in %GV-REF: a call on the store path is not free either.
  (if (eql (mem-ref #x10000DB8 :u32) 0)
      (let ((%gv-cl (%gv-cell %gv-key)))
        (if %gv-cl
            (progn (set-cdr %gv-cl %gv-val) %gv-val)
            (progn (%gv-cache-flush) (set-symbol-value %gv-key %gv-val))))
      (let ((%gv-a (%dynb-value-addr %gv-key)))
        (if (eql %gv-a 0)
            (let ((%gv-cl (%gv-cell %gv-key)))
              (if %gv-cl
                  (progn (set-cdr %gv-cl %gv-val) %gv-val)
                  (progn (%gv-cache-flush) (set-symbol-value %gv-key %gv-val))))
            (progn (setf (mem-ref %gv-a :u64) %gv-val) %gv-val)))))

;;; ============================================================
;;; Interned Symbols
;;; ============================================================
;;;
;;; Symbols are 1-slot objects with subtag #x50.
;;;   Slot 0: name-hash (tagged fixnum, dual-FNV-1a)
;;;
;;; The intern table at 0x620000 maps name-hash → symbol object.
;;; %intern-symbol is called by compile-quote for every quoted symbol
;;; and by the reader's mksym for every parsed symbol.
;;; Since intern returns the same object for the same name, eq works.

(defun init-symbol-table ()
  "Initialize the intern table at 0x620000."
  (setf (mem-ref #x10000088 :u64) (make-hash-table)))

(defun init-keyword-table ()
  "Initialize the keyword intern table at #x10000148.
   Distinct from the symbol table so KEYWORDP can identify keywords without
   a per-symbol package slot.  See compile-keyword in mvm/compiler.lisp."
  (setf (mem-ref #x10000148 :u64) (make-hash-table)))

(defun %intern-symbol (name-hash)
  "Legacy 1-arg intern.  Delegates to %INTERN-SYMBOL-PKG with pkg-hash=0
   (i.e. no known home package).  Kept for back-compat with anything
   that interns a symbol without knowing its package — gensyms,
   constructed names, the old read path before the reader started
   passing *package*.  All `'foo' literals in source compile through
   %INTERN-SYMBOL-PKG instead and arrive package-tagged."
  (%intern-symbol-pkg name-hash 0))


(defun %intern-symbol-pkg (name-hash pkg-hash)
  "Intern a symbol identified by (NAME-HASH, PKG-HASH), under the runtime-table
   lock.  See %RT-ENTER: the lock is a load and a branch until a program
   declares that it is running Lisp on more than one thread, and from then on it
   both serialises the table and makes region 0 the heap the symbol is allocated
   in — a symbol reachable only from a table in region 0 would be collected the
   next time its own thread's region was.

   THE WRAPPER IS A SEPARATE FUNCTION because this compiler resolves every call
   to the LAST defun of a name, so a hosted image cannot wrap a function by
   redefining it and calling the old one.  Splitting the body out is the only
   shape that lets the lock be added in ONE place and still be overridable."
  (%rt-enter)
  (let ((r (%intern-symbol-pkg-1 name-hash pkg-hash)))
    (%rt-leave)
    r))

(defun %intern-symbol-pkg-1 (name-hash pkg-hash)
  "Intern a symbol identified by (NAME-HASH, PKG-HASH).  Per CLHS
   11.1.2 — see SYMBOLS_PLAN.md — symbol identity is per-package: the
   same NAME-HASH in two different packages produces two distinct
   symbol objects.  This is a reversal of the prior unified model
   where `(eq cl-test::x ds4::x)' was T.

   Returns the canonical symbol for the (NAME-HASH, PKG-HASH) pair;
   multiple calls with the same pair return `eq' results.

   The symbol is always 3-slot [hash, package, name].  PKG-HASH = 0
   means `no home package' (uninterned gensyms): those still share by
   NAME-HASH alone via the single-key path so that
   `(eq (gensym) (gensym))' false but `(eq '#:G '#:G)' from the same
   literal holds.

   Storage: the symbol intern table at #x10000088 is keyed by a
   composite of NAME-HASH and PKG-HASH.  pkg-hash=0 uses the bare
   name-hash so the legacy uninterned path stays compatible.

   GC-safety: %ALLOC-SYM3 can trigger GC, which moves the hash table
   to to-space and updates the root slot at #x10000088.  Re-read the
   root AFTER the allocation."
  (setf (mem-ref #x10000C80 :u64) (+ (mem-ref #x10000C80 :u64) 1))
  ;; Composite key: name-hash for no-package syms (legacy / uninterned),
  ;; otherwise combine name-hash + pkg-hash so that the same name in two
  ;; packages keys to two distinct slots.  Multiplier is a large prime;
  ;; mod 2^62 keeps the result in fixnum range.  MUST use %fixnum-+ / %fixnum-*
  ;; (raw, wrapping :add / :mul): plain + and * now promote on overflow to a
  ;; BIGNUM, and in-image (logand <bignum> mask) is lossy — that produced an
  ;; inconsistent intern key and symbols failed to resolve ("implicit
  ;; global <param>").  The mask makes the wraparound irrelevant.
  (let ((key (if (= pkg-hash 0)
                 name-hash
                 (logand (%fixnum-+ name-hash (%fixnum-* pkg-hash +fixnum-half-max+))
                         #x3FFFFFFFFFFFFFFF))))
    (let ((table (mem-ref #x10000088 :u64)))
      (let ((existing (gethash key table)))
        (cond
          (existing
           ;; Same (name, pkg) pair — return cached.
           (setf (mem-ref #x10000C80 :u64) (- (mem-ref #x10000C80 :u64) 1))
           existing)
          (t
           (let ((sym (%alloc-sym3)))
             (aset sym 0 name-hash)
             ;; Look up the home package.  pkg-hash=0 means none.
             ;;
             ;; A NON-zero pkg-hash means compile-quote knew this literal's
             ;; home package at build time — it is a genuine interned
             ;; symbol, never a gensym (those pass pkg-hash=0).  But the
             ;; build-host package may not have a runtime counterpart in
             ;; the pkg-by-hash table: ANSI-test deftest bodies and our own
             ;; source are READ into host packages like MODUS.MVM /
             ;; COMMON-LISP-USER, only some of which are registered.  When
             ;; the lookup misses, leaving slot 1 NIL is WRONG: the printer
             ;; then treats the symbol as uninterned and emits `#:NAME`
             ;; (format-s, print-cons, print-array all expect bare `NAME`).
             ;; So a known-but-unresolved home package falls back to the
             ;; default user package (CL-USER) — the symbol IS interned,
             ;; just in a package whose hash we don't carry.  Genuine
             ;; uninterned symbols keep slot 1 = NIL via the pkg-hash=0
             ;; branch; keywords never reach here (they intern through
             ;; %INTERN-KEYWORD).
             (let ((pkg nil))
               (when (> pkg-hash 0)
                 (let ((pkg-tab (mem-ref #x10000170 :u64)))
                   (when pkg-tab
                     (setq pkg (gethash pkg-hash pkg-tab))
                     (when (null pkg)
                       ;; Unresolved known package — default to CL-USER,
                       ;; looked up from the same table by its canonical
                       ;; name hash (self-heals if registration changes).
                       (setq pkg (gethash 51798093 pkg-tab))))))  ; COMMON-LISP-USER
               (aset sym 1 pkg))
             (aset sym 2 "")    ; name — SYMBOL-NAME reverse-fills via *SYM-NAME-TABLE*
             ;; Re-read the root — %ALLOC-SYM3 may have triggered GC.
             (let ((live-table (mem-ref #x10000088 :u64)))
               (puthash key live-table sym))
             (setf (mem-ref #x10000C80 :u64) (- (mem-ref #x10000C80 :u64) 1))
             sym)))))))

;;; Pkg-by-hash root.  We DON'T use a Lisp special variable because
;;; referencing `*pkg-by-hash*' from %INTERN-SYMBOL-PKG would recurse
;;; to intern that variable's name and blow the stack at boot.  The
;;; slot at #x10000170 holds a hash-table object; readers go through
;;; (mem-ref #x10000170 :u64) and trust the GC to walk the slot as a
;;; root (same convention as the symbol intern table at #x10000088).
(defun %init-pkg-by-hash ()
  (setf (mem-ref #x10000170 :u64) (make-hash-table)))

(defun %intern-keyword (name-hash)
  "Intern a keyword by name hash, under the runtime-table lock.  Split into a
   wrapper and a body for the reason %INTERN-SYMBOL-PKG gives.

   THIS ONE IS HOT: compile-keyword emits a call to it for EVERY `:foo' literal
   in compiled code, so it runs on every evaluation of every keyword, FORMAT's
   included.  That is exactly why it must be locked once a second thread exists,
   and exactly why the lock has to cost nothing until then."
  (%rt-enter)
  (let ((r (%intern-keyword-1 name-hash)))
    (%rt-leave)
    r))

(defun %intern-keyword-1 (name-hash)
  "Intern a keyword by name hash.  Same shape as %INTERN-SYMBOL but uses
   the keyword table at #x10000148 and allocates a #x53-subtag object so
   KEYWORDP can identify it.  Compile-keyword in compiler.lisp emits
   `(li v0 hash) (call %INTERN-KEYWORD)' for every `:foo' literal in
   compiled code; the runtime reader's `intern KEYWORD' path lands here
   too via cl-packages.lisp.  Eq across both routes is preserved by the
   shared name-hash → object table."
  (let ((table (mem-ref #x10000148 :u64)))
    (let ((existing (gethash name-hash table)))
      (if existing
          existing
          (let ((kw (%make-keyword-obj)))
            (aset kw 0 name-hash)
            ;; Re-read the root (see %intern-symbol comment) — GC during
            ;; %make-keyword-obj may have relocated the table.
            (let ((live-table (mem-ref #x10000148 :u64)))
              (puthash name-hash live-table kw))
            kw)))))

;;; ============================================================
;;; Error handling (bare-metal stubs)
;;; ============================================================
;;;
;;; On bare metal, errors halt the system. MVM-compiled code calls
;;; these with variable arity — extra args are silently ignored.

(defun error (msg &rest args)
  "Signal an error. If handler-case is active, longjmp to it.
   Otherwise print error indicator and halt.
   ANSI's error is (datum &rest args); we mirror that signature here
   in prelude so all later callers see the &rest version even if
   compiled before cl-conditions.lisp redefines this function."
  (declare (ignore args))
  (if (%error-handler-active-p)
      (%hc-longjmp)
      (progn
        (write-string-serial "ERR:")
        (write-char-serial 10)
        (halt))))

(defun warn (msg &rest args)
  "Print warning indicator. Extra args ignored on bare metal."
  (declare (ignore args))
  (write-string-serial "WARN:")
  (write-char-serial 10))

;; FORMAT lives in cl-printer.lisp.  A nil-stub at this location used
;; to mask the real prelude FORMAT above (L1010); both are then masked
;; in turn by cl-printer's.  Removed 2026-06-01 as part of the
;; redefinition audit.

;;; ============================================================
;;; Type checking stubs
;;; ============================================================

(defun typep (obj type)
  "Type checking stub — returns nil on bare metal."
  nil)

(defun type-of (obj)
  "Type-of stub — returns nil on bare metal."
  nil)

;;; ============================================================
;;; Hash / symbol stubs
;;; ============================================================

;; Dual-FNV-1a 60-bit hash. Must match the build-time definition in
;; cross.lisp so that a symbol's stored hash (set by the compiler at
;; compile-quote time) matches what (compute-name-hash "NAME") yields
;; at runtime — used by the package hash→name map to round-trip
;; native MVM symbols back to their name string.
(defun compute-name-hash (name-string)
  "Dual-FNV-1a hash for a name string. 60-bit collision-resistant."
  ;; 16-BIT STATE, bit-identical to the 32-bit FNV form — see the note on
  ;; COMPUTE-NAME-HASH in mvm/compiler.lisp.  This matters most HERE: a 32-bit
  ;; state is a BIGNUM on i386's 30-bit tower, so the old form allocated
  ;; through the generic bignum engine once per character of every name
  ;; hashed at runtime.  The largest intermediate below is 2^25.
  (let ((h1 40389) (h2 48879)          ; #x9DC5 / #xBEEF
        (len (array-length name-string))
        (i 0))
    (loop
      (when (>= i len) (return nil))
      (let ((c (%prim-aref name-string i)))   ; raw char-CODE for arithmetic hash
        ;; Uppercase if lowercase ASCII letter (matches string-upcase
        ;; path in build-time version).
        (when (and (>= c 97) (<= c 122))
          (setq c (- c 32)))
        (setq c (logand c 65535))
        (setq h1 (logand (* (logxor h1 c) 403) 65535))
        (setq h2 (logand (* (logxor h2 c) 89) 65535)))
      (setq i (+ i 1)))
    (let ((combined (logior (ash (logand h1 +name-hash-hi-mask+) +name-hash-shift+)
                            (logand h2 +name-hash-lo-mask+))))
      (if (zerop combined) 1 combined))))

(defun name-eq (sym name-string)
  "Runtime version of MODUS.HASH:NAME-EQ — true iff SYM's name matches
   NAME-STRING (case-insensitively, via the dual-FNV-1a hash).

   This MUST exist at runtime: the compiler's SETF macro expander
   (compiler.lisp ~1707) — which is extracted and compiled into the
   image so runtime EVAL can macroexpand SETF — dispatches every place
   type with `(name-eq (car place) \"CAR\"/\"GETHASH\"/...)`.  Without a
   runtime NAME-EQ the call resolved to %UNRESOLVED-FN (→ NIL), so NO
   place branch matched and `(setf (gethash k h) v)` fell through to the
   broken generic `SET-<accessor>` fallback (which errored), making
   runtime-EVAL `(setf (gethash k h) v)` signal instead of storing.

   Mirrors %EVAL-SYM-EQ: native MVM symbols (subtag #x50, single hash
   slot) carry only a hash — SYMBOL-NAME may return \"\" for them — so we
   compare the stored hash slot DIRECTLY to (compute-name-hash NAME-STRING).
   CL symbols (3-slot) and the gensym/string cases go through SYMBOL-NAME."
  (cond
    ((null sym) nil)
    ((eq sym t) nil)
    ((consp sym) nil)
    ((characterp sym) nil)
    ((%cl-sym-p sym)
     (let ((n (symbol-name sym)))
       (and n (eql (compute-name-hash n) (compute-name-hash name-string)))))
    ((%native-mvm-sym-p sym)
     (eql (aref sym 0) (compute-name-hash name-string)))
    ((integerp sym) nil)
    (t nil)))

(defun intern (name &rest pkg-arg)
  "Intern stub — returns the name hash on bare metal.
   ANSI's intern is (string &optional package). Use &rest here so the
   prelude version's signature matches cl-packages.lisp's later
   redefinition (and so callers compiled before that redefinition still
   pass arity check)."
  (declare (ignore pkg-arg))
  (if (integerp name)
      name
      (compute-name-hash name)))

(defun find-package (name)
  "Find-package stub — returns nil."
  nil)

(defun find-symbol (name)
  "Find-symbol stub — returns nil."
  nil)

;;; ============================================================
;;; Sequence utilities
;;; ============================================================

(defun subseq (seq start &rest end-arg)
  "Return a subsequence from START to END (END defaults to length)."
  ;; An EXPLICIT nil end (CL: (subseq s start nil)) means \"to the end\" —
  ;; same as omitting it.  Guarding on end-arg alone left end=NIL, which the
  ;; array path then fed to (- end start) → TYPE-ERROR (the list path tolerates
  ;; it via its (null cur) terminator).  Treat present-but-nil like absent.
  (let ((end (if (and end-arg (car end-arg)) (car end-arg) (length seq))))
  ;; NIL is a (empty) list: (subseq nil 0 0) must return NIL, not #().
  ;; The consp-only test sent NIL down the array branch, returning an
  ;; empty VECTOR — which broke the in-image compiler's static-rest
  ;; pre-pack ((append (subseq args 0 0) ...) → TYPE-ERROR) for any
  ;; 0-arg call to a req=0 &rest/&key callee in the same mvm-eval module.
  (if (or (null seq) (consp seq))
      ;; List: build new list
      (let ((result nil)
            (cur (nthcdr start seq))
            (i start))
        (loop
          (when (or (null cur) (>= i end)) (return (nreverse result)))
          (setq result (cons (car cur) result))
          (setq cur (cdr cur))
          (setq i (+ i 1))))
      ;; Array: copy elements.  Preserve string-ness so (subseq "abc" 1)
      ;; returns a STRING, not a general char-vector (aref/aset now move
      ;; characters; %make-string-array keeps the result string-typed).
      (let* ((len (- end start))
             ;; Preserve the specialized element type: a subseq of a packed
             ;; u8 (#x11) / single-float (#x12) vector is the same packed
             ;; type, so (array-element-type (subseq v …)) matches V
             ;; (ANSI subseq.specialized-vector.2).
             (result (cond
                       ((stringp seq) (%make-string-array len))
                       ((and (not (consp seq)) (not (%mda-p seq))
                             (eq (obj-subtag seq) #x11)) (%make-u8-vector len))
                       ((and (not (consp seq)) (not (%mda-p seq))
                             (eq (obj-subtag seq) #x12)) (%make-f32-vector len))
                       (t (make-array len)))))
        (let ((i 0))
          (if (%bulk-copy-ok-p result seq)
              (progn (%bulk-copy result 0 seq start len) result)
              (loop
                (when (= i len) (return result))
                (aset result i (aref seq (+ start i)))
                (setq i (+ i 1)))))))))

(defun concatenate-strings (s1 s2)
  "Concatenate two strings (arrays of chars)."
  (let ((l1 (array-length s1))
        (l2 (array-length s2)))
    (let ((result (make-array (+ l1 l2)))
          (i 0))
      (loop
        (when (= i l1) (return nil))
        (aset result i (aref s1 i))
        (setq i (+ i 1)))
      (setq i 0)
      (loop
        (when (= i l2) (return nil))
        (aset result (+ l1 i) (aref s2 i))
        (setq i (+ i 1)))
      result)))

(defun make-list (n initial-element)
  "Create a list of N elements, each set to INITIAL-ELEMENT."
  (let ((result nil)
        (i 0))
    (loop
      (when (= i n) (return result))
      (setq result (cons initial-element result))
      (setq i (+ i 1)))))

;;; UIOP/OS environment-variable helpers.
;;;
;;; UIOP (vendor/asdf/asdf.lisp) defines GETENV and GETENVP inside a single
;;; (with-upgradability () (defun getenv …) (defsetf getenv …) (defun getenvp …))
;;; form.  Under runtime EVAL that whole form ABORTS on the (defsetf getenv …)
;;; — leaving GETENVP undefined — so every later UIOP form that calls GETENVP
;;; (detect-os, default-temporary-directory, argv0, configuration probing, …)
;;; signals UNDEFINED-FUNCTION (asdf gauntlet FAILFORM 87 / 109).  Pre-defining
;;; them here in the image makes them available regardless of whether that form
;;; completes, and matches UIOP's own #+modus behaviour: Modus has no
;;; environment access yet, so GETENV returns NIL and GETENVP therefore returns
;;; NIL.  If runtime EVAL of the UIOP form ever succeeds it re-installs
;;; identical-behaving definitions (last-defun-wins).
(defun getenv (x)
  "Query the environment, as in C getenv.  Modus has no environment access
   yet, so this always returns NIL (the variable is treated as unset)."
  (declare (ignorable x))
  nil)

(defun getenvp (x)
  "Predicate: returns the named environment variable's value when it is
   present and non-empty, else NIL.  See GETENV — on Modus the environment
   is empty, so this is always NIL."
  (let ((g (getenv x)))
    (and g (stringp g) (> (length g) 0) g)))
