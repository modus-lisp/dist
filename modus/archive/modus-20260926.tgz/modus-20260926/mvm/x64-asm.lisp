;;;; x64-asm.lisp - x86-64 Instruction Encoder
;;;;
;;;; Part of Modus cross-compiler (runs on SBCL)
;;;; Minimal, purpose-built for bootstrap - not a general assembler
;;;;
;;;; References:
;;;;   - Intel SDM Volume 2 (Instruction Set Reference)
;;;;   - AMD64 Architecture Programmer's Manual Volume 3

;; Package defined in packages.lisp

(in-package :modus.asm)

;;; ============================================================
;;; Code Buffer
;;; ============================================================

(defstruct code-buffer
  ;; Default 96MB here; grows on demand by doubling (see %code-buffer-ensure).
  ;; This large default is pure waste for the ~dozen call sites that only need
  ;; a small buffer (boot stubs, scratch/test buffers): each make-code-buffer
  ;; allocates a fresh array of this size.  Grow-on-demand now handles overflow
  ;; correctly, so the big default is unnecessary.  Two lower-friction fixes are
  ;; applied instead of shrinking THIS default (which the ANSI/host builds and
  ;; the build-modus-selfhost WS5-S1 transform both key off by exact text):
  ;;   (1) the self-host build's WS5-S1 transform rewrites this to 1MB (was
  ;;       32MB) — the alloc-heavy path, since the self-compile has no host GC;
  ;;   (2) the one genuinely-large buffer — the main module output in
  ;;       translate-mvm-to-x64 — is pre-sized to ~6x the bytecode there, so it
  ;;       never grow-copies and large images (ANSI gate, self-compile) stay
  ;;       alloc-neutral regardless of this default.
  ;; NOTE: this exact `(make-array 100663296 ...)` text is matched by the
  ;; WS5-S1 string transform in build-modus-selfhost.lisp — keep it verbatim.
  (bytes (make-array 100663296 :element-type '(unsigned-byte 8)))
  (labels (make-hash-table :test 'eq))      ; label -> position
  (fixups nil)                              ; list of (position label offset-size)
  (position 0))

(defun %code-buffer-ensure (buf pos)
  "Ensure BUF's byte array can hold index POS.  Grows (doubling) and
   copies the existing bytes when the current array is too small."
  (let* ((bytes (code-buffer-bytes buf))
         (cap (length bytes)))
    (when (>= pos cap)
      (let ((new-cap cap))
        (loop while (>= pos new-cap) do (setf new-cap (* new-cap 2)))
        (let ((new-bytes (make-array new-cap :element-type '(unsigned-byte 8))))
          (replace new-bytes bytes :end1 cap)
          (setf (code-buffer-bytes buf) new-bytes))))))

(defun emit-byte (buf byte)
  ;; PERF (2026-09-02): this is the runtime JIT's innermost loop — ~30 bytes
  ;; per translated MVM op, ~130k ops per alexandria quickload.  The old body
  ;; cost ~7 calls per byte in-image (a runtime (BYTE 8 0) bytespec + generic
  ;; LDB, an unconditional ensure call, a debug null check, generic AREF and
  ;; a struct setter): translation was 3.35 s of a 12.3 s load.  Keep the
  ;; capacity check inline and the masking a primop.
  (let ((pos (code-buffer-position buf))
        (bytes (code-buffer-bytes buf)))
    (when (>= pos (length bytes))
      (%code-buffer-ensure buf pos)
      (setq bytes (code-buffer-bytes buf)))
    (setf (aref bytes pos) (logand byte 255))
    (setf (code-buffer-position buf) (+ pos 1))))

(defun emit-bytes (buf &rest bytes)
  (dolist (b bytes)
    (emit-byte buf b)))

(defun emit-u16 (buf value)
  (emit-byte buf (ldb (byte 8 0) value))
  (emit-byte buf (ldb (byte 8 8) value)))

(defun emit-u32 (buf value)
  (emit-byte buf (ldb (byte 8 0) value))
  (emit-byte buf (ldb (byte 8 8) value))
  (emit-byte buf (ldb (byte 8 16) value))
  (emit-byte buf (ldb (byte 8 24) value)))

(defun emit-u64 (buf value)
  ;; Bignum-safe 64-bit emit.  In-image, `(ldb (byte 32 32) V)` / `(ash V -32)`
  ;; / `(floor V 2^32)` are all BROKEN for a bignum-range V (compile-ash inlines
  ;; :sar on the bignum POINTER — limitation #8), so a boundary fixnum's TAGGED
  ;; word (a small bignum > most-positive-fixnum, or a negative word decoded by
  ;; decode-u64 as an unsigned bignum ≥ 2^63) emitted garbage high bytes → the
  ;; JIT loaded a wrong immediate for any near-2^62 literal.  Extract the two
  ;; 32-bit halves without a bignum shift-down: `logand` for the low half, and
  ;; `(floor V 2^31)` then a fixnum `>>1` for the high half — floor-by-2^31 is
  ;; exact where floor-by-2^32 / ash-down are not, and its result (< 2^33) is a
  ;; fixnum so the final `(ash … -1)` is a normal fixnum shift.  Byte-identical
  ;; to the old `ldb` form for every value the host/fixnum path handles, so the
  ;; image build stays byte-for-byte the same.
  (emit-u32 buf (logand value #xFFFFFFFF))
  (emit-u32 buf (logand (ash (floor value 2147483648) -1) #xFFFFFFFF)))

(defun emit-s32 (buf value)
  ;; Assert the value fits in signed 32-bit range before truncating.
  ;; rel32 branch offsets that overflow silently produce a branch to
  ;; the wrong target — historically a major source of "layout bug"
  ;; mystery crashes.  The image hasn't grown anywhere near 2GB, so
  ;; this assert should never fire under normal builds; if it does,
  ;; the diagnostic beats a triple-fault every time.
  (unless (<= -2147483648 value 2147483647)
    (format t "  DBG-S32: overflow value=~A minusp=~A fixnump=~A pos=~D val-minus-2G=~A~%"
            value (minusp value)
            (typep value 'fixnum)
            (code-buffer-position buf)
            (ignore-errors (- value 2147483647)))
    (error "emit-s32: value ~D (#x~X) out of range for signed 32-bit ~
            (rel32 branch would silently truncate); buf position ~D"
           value value (code-buffer-position buf)))
  (emit-u32 buf (if (minusp value)
                    (logand #xFFFFFFFF value)
                    value)))

;; code-buffer-position is auto-generated by defstruct code-buffer

;;; ============================================================
;;; Labels and Fixups
;;; ============================================================

(defstruct label
  (name (gensym "L"))
  (position nil))

(defun emit-label (buf label)
  ;; The label's byte position lives in the STRUCT slot; fixup-labels reads it
  ;; from there.  The code-buffer-labels hash table is write-only across the
  ;; whole tree (no gethash reader anywhere), and it is keyed by the LABEL
  ;; STRUCT — which %ht-hash cannot bucket (returns :NOHASH for non-immediate
  ;; objects), so every insert degraded to a linear alist scan.  As labels
  ;; accumulate with module size that made the self-compile O(n^2) — it was THE
  ;; dominant cost of `modus --compile` (30/30 profiler samples in
  ;; PUTHASH<-EMIT-LABEL, zero in GC).  Dropping the dead write is
  ;; behavior-neutral and collapses the quadratic.  (fixpoint-common's
  ;; emit-label override already omitted it.)
  (setf (label-position label) (code-buffer-position buf)))

(defun emit-label-ref-rel32 (buf label)
  "Emit a 32-bit relative reference to label (filled in later)"
  (push (list (code-buffer-position buf) label 4) (code-buffer-fixups buf))
  (emit-u32 buf 0))  ; placeholder

(defun fixup-labels (buf)
  "Resolve all label references.  Asserts each computed rel32 fits in
   signed 32-bit range before truncating to 4 bytes — without this an
   overflowed offset silently becomes an arbitrary branch target."
  (let ((bytes (code-buffer-bytes buf)))
    (dolist (fixup (code-buffer-fixups buf))
      (destructuring-bind (pos label size) fixup
        (let* ((target (label-position label)))
          (when target  ; skip unresolved labels
          (let ((rel (- target (+ pos size))))
          (ecase size
            (4
             (unless (<= -2147483648 rel 2147483647)
               (error "fixup-labels: rel32 ~D (#x~X) overflows ~
                      signed 32-bit at pos ~D (target ~D, label ~A) ~
                      — branch would silently truncate"
                      rel rel pos target (label-name label)))
             (setf (aref bytes pos) (ldb (byte 8 0) rel)
                   (aref bytes (+ pos 1)) (ldb (byte 8 8) rel)
                   (aref bytes (+ pos 2)) (ldb (byte 8 16) rel)
                   (aref bytes (+ pos 3)) (ldb (byte 8 24) rel))))))))))
  buf)

;;; ============================================================
;;; Registers
;;; ============================================================

;; Register encoding: (code size needs-rex-for-low-byte)
(eval-when (:compile-toplevel :load-toplevel :execute)
  (defparameter *registers*
    '((rax  0 64 nil) (rcx  1 64 nil) (rdx  2 64 nil) (rbx  3 64 nil)
      (rsp  4 64 nil) (rbp  5 64 nil) (rsi  6 64 nil) (rdi  7 64 nil)
      (r8   8 64 t)   (r9   9 64 t)   (r10 10 64 t)   (r11 11 64 t)
      (r12 12 64 t)   (r13 13 64 t)   (r14 14 64 t)   (r15 15 64 t)
      ;; 32-bit
      (eax  0 32 nil) (ecx  1 32 nil) (edx  2 32 nil) (ebx  3 32 nil)
      (esp  4 32 nil) (ebp  5 32 nil) (esi  6 32 nil) (edi  7 32 nil)
      (r8d  8 32 t)   (r9d  9 32 t)   (r10d 10 32 t)  (r11d 11 32 t)
      (r12d 12 32 t)  (r13d 13 32 t)  (r14d 14 32 t)  (r15d 15 32 t)
      ;; 8-bit
      (al   0 8 nil)  (cl   1 8 nil)  (dl   2 8 nil)  (bl   3 8 nil)
      (spl  4 8 t)    (bpl  5 8 t)    (sil  6 8 t)    (dil  7 8 t)
      (r8b  8 8 t)    (r9b  9 8 t)    (r10b 10 8 t)   (r11b 11 8 t)
      (r12b 12 8 t)   (r13b 13 8 t)   (r14b 14 8 t)   (r15b 15 8 t))))

;; NO register-symbol DEFCONSTANTs here, deliberately.  There used to be a
;; DEFINE-REGISTERS macro expanding to `(defconstant rax 'rax)` … one per row
;; above — 48 constants named RAX…R15, EAX…R15D and AL BL CL DL SPL BPL SIL DIL.
;; Nothing ever read them: every register in this encoder, in translate-x64.lisp
;; and in translate-i386.lisp is written QUOTED ('rax) or lives inside a quoted
;; list ('(rax rdx r8)), and the in-image translator gets its table from
;; %init-x64-translator's (quote rax) forms.  They were dead weight.
;;
;; Dead weight with teeth, because the image has a FLAT, NAME-HASHED namespace:
;; the compiler's *constants* table is keyed by (compute-name-hash "DL"), so a
;; DEFCONSTANT of MODUS.ASM::DL registers the name DL for every unit compiled
;; after this file, whatever package it was read in — and DL, AL, BL, CL, R8…R15
;; are ordinary local variable names all over first-party source (cl-printer's
;; %fmt-integer digit list, cl-eval's bignum compare, cl-reader's dispatch list,
;; the X25519 field-arithmetic limbs r0…r9 in net/*).  Today x64-asm.lisp is
;; baked AFTER those files so none of them are exposed, but that is an ordering
;; accident, not a guarantee.
;;
;; The expansion also used to FAIL at build time (the build read this file in
;; MODUS.MVM, splitting *REGISTERS* from the macro's reference, so the build
;; printed "WARN macroexpand DEFINE-REGISTERS failed" and emitted a runtime-error
;; stub).  That failure was load-bearing: it is why the collision never fired.
;; Deleting the macro removes the hazard instead of relying on the accident.
;; If a bare register symbol is ever genuinely wanted, quote it — do not
;; reintroduce image-wide constants for 48 two-letter names.  See task #211.

(defvar *reg-info-table* nil
  "EQ hash of register symbol -> its *registers* entry, built on first use
   (a defvar initform does not run in-image).  PERF: reg-info runs 3-4x per
   emitted instruction; the ASSOC over ~48 entries was ~25% of translation
   time in both the host profile (%ASSOC + REG-INFO) and, by inference, the
   in-image JIT.")
(defun reg-info (reg)
  (unless *reg-info-table*
    (let ((h (make-hash-table :test 'eq)))
      (dolist (e *registers*) (setf (gethash (car e) h) e))
      (setq *reg-info-table* h)))
  (or (gethash reg *reg-info-table*)
      (error "Unknown register: ~A" reg)))

(defun reg-code (reg)
  (logand 7 (second (reg-info reg))))  ; Low 3 bits

(defun reg-size (reg)
  (third (reg-info reg)))

(defun reg-needs-rex-p (reg)
  "Does this register need REX prefix? (R8-R15 or SPL/BPL/SIL/DIL)"
  (let ((info (reg-info reg)))
    (or (>= (second info) 8)        ; R8-R15
        (fourth info))))            ; SPL, BPL, SIL, DIL

(defun reg-extended-p (reg)
  "Is this R8-R15?"
  (>= (second (reg-info reg)) 8))

;;; ============================================================
;;; REX Prefix
;;; ============================================================

(defun rex-prefix (w r x b)
  "Build REX prefix byte.
   W = 64-bit operand size
   R = ModR/M reg field extension
   X = SIB index field extension
   B = ModR/M r/m or SIB base extension"
  (logior #x40
          (if w #x08 0)
          (if r #x04 0)
          (if x #x02 0)
          (if b #x01 0)))

(defun emit-rex-if-needed (buf reg1 &optional reg2 force-64)
  "Emit REX prefix if needed for these registers"
  (let* ((size (if reg1 (reg-size reg1) 64))
         (w (or force-64 (= size 64)))
         (r (and reg1 (reg-extended-p reg1)))
         (b (and reg2 (reg-extended-p reg2))))
    (when (or w r b
              (and reg1 (reg-needs-rex-p reg1))
              (and reg2 (reg-needs-rex-p reg2)))
      (emit-byte buf (rex-prefix w r nil b)))))

;;; ============================================================
;;; ModR/M and SIB
;;; ============================================================

(defun modrm (mod reg rm)
  "Build ModR/M byte"
  (logior (ash (logand mod #x3) 6)
          (ash (logand reg #x7) 3)
          (logand rm #x7)))

(defun emit-modrm-reg-reg (buf reg rm)
  "Emit ModR/M for register-to-register"
  (emit-byte buf (modrm #b11 (reg-code reg) (reg-code rm))))

;;; ============================================================
;;; Instructions
;;; ============================================================

;;; Simple instructions

(defun emit-ret (buf)
  (emit-byte buf #xC3))

(defun emit-nop (buf)
  (emit-byte buf #x90))

(defun emit-int (buf n)
  (emit-bytes buf #xCD n))

;;; Push/Pop

(defun emit-push (buf reg)
  (when (reg-extended-p reg)
    (emit-byte buf (rex-prefix nil nil nil t)))
  (emit-byte buf (+ #x50 (reg-code reg))))

(defun emit-pop (buf reg)
  (when (reg-extended-p reg)
    (emit-byte buf (rex-prefix nil nil nil t)))
  (emit-byte buf (+ #x58 (reg-code reg))))

;;; MOV

(defun emit-mov-reg-reg (buf dst src)
  "MOV dst, src (register to register)"
  (emit-rex-if-needed buf src dst)
  (emit-byte buf #x89)  ; MOV r/m64, r64
  (emit-modrm-reg-reg buf src dst))

(defun emit-mov-reg-imm (buf reg imm)
  "MOV reg, imm64"
  (let ((size (reg-size reg)))
    (cond
      ;; 64-bit immediate
      ((= size 64)
       (emit-byte buf (rex-prefix t nil nil (reg-extended-p reg)))
       (emit-byte buf (+ #xB8 (reg-code reg)))
       (emit-u64 buf imm))
      ;; 32-bit
      ((= size 32)
       (when (reg-extended-p reg)
         (emit-byte buf (rex-prefix nil nil nil t)))
       (emit-byte buf (+ #xB8 (reg-code reg)))
       (emit-u32 buf imm))
      ;; 8-bit
      ((= size 8)
       (when (reg-needs-rex-p reg)
         (emit-byte buf (rex-prefix nil nil nil (reg-extended-p reg))))
       (emit-byte buf (+ #xB0 (reg-code reg)))
       (emit-byte buf imm)))))

(defun emit-mov-reg-mem (buf reg base &optional (offset 0))
  "MOV reg, [base + offset]"
  (emit-rex-if-needed buf reg base)
  (emit-byte buf #x8B)  ; MOV r64, r/m64
  ;; RSP (code 4) in r/m means "SIB follows" - need special handling
  (let ((needs-sib (= (logand (reg-code base) 7) 4)))  ; RSP or R12
    (cond
      ((zerop offset)
       (cond
         ((= (reg-code base) 5)  ; RBP/R13 need disp8
          (emit-byte buf (modrm #b01 (reg-code reg) (reg-code base)))
          (emit-byte buf 0))
         (needs-sib
          (emit-byte buf (modrm #b00 (reg-code reg) 4))  ; r/m=4 means SIB
          (emit-byte buf #x24))  ; SIB: scale=0, index=4(none), base=4(RSP)
         (t
          (emit-byte buf (modrm #b00 (reg-code reg) (reg-code base))))))
      ((<= -128 offset 127)
       (emit-byte buf (modrm #b01 (reg-code reg) (if needs-sib 4 (reg-code base))))
       (when needs-sib
         (emit-byte buf #x24))  ; SIB
       (emit-byte buf (logand offset #xFF)))
      (t
       (emit-byte buf (modrm #b10 (reg-code reg) (if needs-sib 4 (reg-code base))))
       (when needs-sib
         (emit-byte buf #x24))  ; SIB
       (emit-s32 buf offset)))))

(defun emit-mov-mem-reg (buf base reg &optional (offset 0))
  "MOV [base + offset], reg"
  (emit-rex-if-needed buf reg base)
  (emit-byte buf #x89)  ; MOV r/m64, r64
  ;; RSP (code 4) in r/m means "SIB follows" - need special handling
  (let ((needs-sib (= (logand (reg-code base) 7) 4)))  ; RSP or R12
    (cond
      ((zerop offset)
       (cond
         ((= (reg-code base) 5)  ; RBP/R13 need disp8
          (emit-byte buf (modrm #b01 (reg-code reg) (reg-code base)))
          (emit-byte buf 0))
         (needs-sib
          (emit-byte buf (modrm #b00 (reg-code reg) 4))  ; r/m=4 means SIB
          (emit-byte buf #x24))  ; SIB: scale=0, index=4(none), base=4(RSP)
         (t
          (emit-byte buf (modrm #b00 (reg-code reg) (reg-code base))))))
      ((<= -128 offset 127)
       (emit-byte buf (modrm #b01 (reg-code reg) (if needs-sib 4 (reg-code base))))
       (when needs-sib
         (emit-byte buf #x24))  ; SIB
       (emit-byte buf (logand offset #xFF)))
      (t
       (emit-byte buf (modrm #b10 (reg-code reg) (if needs-sib 4 (reg-code base))))
       (when needs-sib
         (emit-byte buf #x24))  ; SIB
       (emit-s32 buf offset)))))

;;; ALU operations

(defmacro define-alu-reg-reg (name opcode)
  `(defun ,name (buf dst src)
     (emit-rex-if-needed buf src dst)
     (emit-byte buf ,opcode)
     (emit-modrm-reg-reg buf src dst)))

(defmacro define-alu-reg-imm (name opcode modrm-reg)
  `(defun ,name (buf reg imm)
     ;; For ALU reg, imm: register is in R/M field, so use reg as reg2 for REX.B
     (emit-rex-if-needed buf nil reg t)  ; force 64-bit, reg in R/M position
     (cond
       ((<= -128 imm 127)
        (emit-byte buf #x83)  ; sign-extended imm8
        (emit-byte buf (modrm #b11 ,modrm-reg (reg-code reg)))
        (emit-byte buf (logand imm #xFF)))
       (t
        (if (eq reg 'rax)
            (progn
              (emit-byte buf ,(+ opcode 5))  ; op RAX, imm32
              (emit-s32 buf imm))
            (progn
              (emit-byte buf #x81)
              (emit-byte buf (modrm #b11 ,modrm-reg (reg-code reg)))
              (emit-s32 buf imm)))))))

(define-alu-reg-reg emit-add-reg-reg #x01)
(define-alu-reg-reg emit-sub-reg-reg #x29)
(define-alu-reg-reg emit-cmp-reg-reg #x39)
(define-alu-reg-reg emit-and-reg-reg #x21)
(define-alu-reg-reg emit-or-reg-reg  #x09)
(define-alu-reg-reg emit-xor-reg-reg #x31)
(define-alu-reg-reg emit-test-reg-reg #x85)

(define-alu-reg-imm emit-add-reg-imm #x00 0)
(define-alu-reg-imm emit-sub-reg-imm #x28 5)
(define-alu-reg-imm emit-cmp-reg-imm #x38 7)
(define-alu-reg-imm emit-and-reg-imm #x20 4)
(define-alu-reg-imm emit-or-reg-imm  #x08 1)
(define-alu-reg-imm emit-xor-reg-imm #x30 6)
;; TEST has special encoding - don't use the macro
(defun emit-test-reg-imm (buf reg imm)
  "TEST reg, imm - sets flags based on AND without storing result"
  (cond
    ;; For small immediates that fit in a byte and only test low bits,
    ;; we can use TEST AL, imm8 (0xA8) which is simpler
    ((and (eq reg 'rax) (<= 0 imm 255))
     (emit-byte buf #xA8)
     (emit-byte buf imm))
    ;; General case: TEST r/m64, imm32 uses 0xF7 /0
    (t
     (emit-rex-if-needed buf nil reg t)  ; REX.W for 64-bit
     (emit-byte buf #xF7)
     (emit-byte buf (modrm #b11 0 (reg-code reg)))
     (emit-s32 buf imm))))

;;; Shifts

(defun emit-shl-reg-imm (buf reg count)
  ;; SHL r/m, imm8: register is in r/m field, so REX.B extends it (not REX.R)
  (emit-rex-if-needed buf nil reg)
  (if (= count 1)
      (progn
        (emit-byte buf #xD1)
        (emit-byte buf (modrm #b11 4 (reg-code reg))))
      (progn
        (emit-byte buf #xC1)
        (emit-byte buf (modrm #b11 4 (reg-code reg)))
        (emit-byte buf count))))

(defun emit-shr-reg-imm (buf reg count)
  ;; SHR r/m, imm8: register is in r/m field, so REX.B extends it (not REX.R)
  (emit-rex-if-needed buf nil reg)
  (if (= count 1)
      (progn
        (emit-byte buf #xD1)
        (emit-byte buf (modrm #b11 5 (reg-code reg))))
      (progn
        (emit-byte buf #xC1)
        (emit-byte buf (modrm #b11 5 (reg-code reg)))
        (emit-byte buf count))))

(defun emit-sar-reg-imm (buf reg count)
  ;; SAR r/m, imm8: register is in r/m field, so REX.B extends it (not REX.R)
  (emit-rex-if-needed buf nil reg)
  (if (= count 1)
      (progn
        (emit-byte buf #xD1)
        (emit-byte buf (modrm #b11 7 (reg-code reg))))
      (progn
        (emit-byte buf #xC1)
        (emit-byte buf (modrm #b11 7 (reg-code reg)))
        (emit-byte buf count))))

(defun emit-shl-reg-cl (buf reg)
  "SHL reg, CL — shift left by count in CL register."
  ;; Register is in r/m field, so REX.B extends it
  (emit-rex-if-needed buf nil reg)
  (emit-byte buf #xD3)
  (emit-byte buf (modrm #b11 4 (reg-code reg))))

(defun emit-shr-reg-cl (buf reg)
  "SHR reg, CL — logical shift right by count in CL register."
  ;; Register is in r/m field, so REX.B extends it
  (emit-rex-if-needed buf nil reg)
  (emit-byte buf #xD3)
  (emit-byte buf (modrm #b11 5 (reg-code reg))))

(defun emit-sar-reg-cl (buf reg)
  "SAR reg, CL — arithmetic shift right by count in CL register."
  ;; Register is in r/m field, so REX.B extends it
  (emit-rex-if-needed buf nil reg)
  (emit-byte buf #xD3)
  (emit-byte buf (modrm #b11 7 (reg-code reg))))

;;; Jumps and Calls

(defun emit-jmp (buf target)
  "JMP rel32 to label or offset.
   FIX: dispatch on INTEGERP, not (label-p) — the translator ALWAYS passes a
   label struct (ensure-label-at), never a raw integer offset, so a label-p
   false-negative at scale must NOT fall to the raw-s32 path (which would
   subtract the struct pointer → garbage rel32 → emit-s32 range abort)."
  (emit-byte buf #xE9)
  (if (integerp target)
      (emit-s32 buf (- target (+ (code-buffer-position buf) 4)))
      (progn
        (unless (label-p target)
          (format t "  DBG-JMP-FIX: label-p FALSE-NEGATIVE routed to label path pos=~D~%"
                  (code-buffer-position buf)))
        (emit-label-ref-rel32 buf target))))

(defun emit-jmp-reg (buf reg)
  "JMP reg (indirect)"
  (when (reg-extended-p reg)
    (emit-byte buf (rex-prefix nil nil nil t)))
  (emit-byte buf #xFF)
  (emit-byte buf (modrm #b11 4 (reg-code reg))))

(defun emit-call (buf target)
  "CALL rel32 to label or offset.  Dispatch on INTEGERP (see emit-jmp)."
  (emit-byte buf #xE8)
  (if (integerp target)
      (emit-s32 buf (- target (+ (code-buffer-position buf) 4)))
      (progn
        (unless (label-p target)
          (format t "  DBG-CALL-FIX: label-p FALSE-NEGATIVE routed to label path pos=~D~%"
                  (code-buffer-position buf)))
        (emit-label-ref-rel32 buf target))))

(defun emit-call-reg (buf reg)
  "CALL reg (indirect)"
  (when (reg-extended-p reg)
    (emit-byte buf (rex-prefix nil nil nil t)))
  (emit-byte buf #xFF)
  (emit-byte buf (modrm #b11 2 (reg-code reg))))

;;; Conditional jumps

(defparameter *condition-codes*
  '((:o  . #x0) (:no . #x1) (:b  . #x2) (:ae . #x3)
    (:e  . #x4) (:ne . #x5) (:be . #x6) (:a  . #x7)
    (:s  . #x8) (:ns . #x9) (:p  . #xA) (:np . #xB)
    (:l  . #xC) (:ge . #xD) (:le . #xE) (:g  . #xF)
    ;; Aliases
    (:z  . #x4) (:nz . #x5) (:c  . #x2) (:nc . #x3)
    (:nae . #x2) (:nb . #x3) (:nbe . #x7) (:na . #x6)
    (:nge . #xC) (:nl . #xD) (:ng . #xE) (:nle . #xF)))

(defun emit-jcc (buf cc target)
  "Conditional jump: Jcc rel32"
  (let ((code (cdr (assoc cc *condition-codes*))))
    (unless code
      (error "Unknown condition code: ~A" cc))
    (emit-bytes buf #x0F (+ #x80 code))
    (if (integerp target)
        (emit-s32 buf (- target 6))
        (progn
          (unless (label-p target)
            (format t "  DBG-JCC-FIX: label-p FALSE-NEGATIVE routed to label path pos=~D~%"
                    (code-buffer-position buf)))
          (emit-label-ref-rel32 buf target)))))

;;; LEA

(defun emit-lea (buf dst base &optional (offset 0))
  "LEA dst, [base + offset]"
  (emit-rex-if-needed buf dst base)
  (emit-byte buf #x8D)
  ;; RSP (code 4) in r/m means "SIB follows" - need special handling
  (let ((needs-sib (= (logand (reg-code base) 7) 4)))  ; RSP or R12
    (cond
      ((zerop offset)
       (cond
         ((= (reg-code base) 5)  ; RBP/R13 need disp8
          (emit-byte buf (modrm #b01 (reg-code dst) (reg-code base)))
          (emit-byte buf 0))
         (needs-sib
          (emit-byte buf (modrm #b00 (reg-code dst) 4))  ; r/m=4 means SIB
          (emit-byte buf #x24))  ; SIB: scale=0, index=4(none), base=4
         (t
          (emit-byte buf (modrm #b00 (reg-code dst) (reg-code base))))))
      ((<= -128 offset 127)
       (emit-byte buf (modrm #b01 (reg-code dst) (if needs-sib 4 (reg-code base))))
       (when needs-sib
         (emit-byte buf #x24))  ; SIB
       (emit-byte buf (logand offset #xFF)))
      (t
       (emit-byte buf (modrm #b10 (reg-code dst) (if needs-sib 4 (reg-code base))))
       (when needs-sib
         (emit-byte buf #x24))  ; SIB
       (emit-s32 buf offset)))))

;;; ============================================================
;;; Testing
;;; ============================================================

(defun test-assembler ()
  "Basic sanity test"
  (let ((buf (make-code-buffer)))
    ;; mov rax, 42
    (emit-mov-reg-imm buf 'rax 42)
    ;; add rax, rbx
    (emit-add-reg-reg buf 'rax 'rbx)
    ;; ret
    (emit-ret buf)
    (format t "Generated ~D bytes: ~{~2,'0X ~}~%"
            (code-buffer-position buf)
            (coerce (code-buffer-bytes buf) 'list))
    buf))
