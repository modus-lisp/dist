;;;; runtime-cl-macros.lisp — CL macros that need to expand at RUNTIME EVAL.
;;;;
;;;; Modus's compile-time *macro-table* contains many macros installed via
;;;; mvm-define-macro with SBCL-side lambdas — those lambdas can't cross
;;;; into the runtime image, so the runtime *macro-function-table* only
;;;; knows the macros' NAMES (as T markers), not their expanders.
;;;;
;;;; This file stores a list of (defmacro …) source forms as STRINGS so
;;;; backquote inside doesn't confuse compile-quote at build time.  At
;;;; boot, %install-runtime-cl-macros walks the list, READ-FROM-STRINGs
;;;; each entry (the runtime reader expands its backquote), and EVALs
;;;; the resulting form — which routes through cl-eval.lisp's runtime
;;;; DEFMACRO handler and builds an %interp-closure expander in
;;;; *macro-function-table*.

(defvar *modus-runtime-macros*
  (list
    "(defmacro when (test &rest body) `(if ,test (progn ,@body) nil))"

    "(defmacro unless (test &rest body) `(if ,test nil (progn ,@body)))"

    "(defmacro and (&rest forms)
       (cond ((null forms) t)
             ((null (cdr forms)) (car forms))
             (t (list 'if (car forms) (cons 'and (cdr forms)) nil))))"

    "(defmacro or (&rest forms)
       (cond ((null forms) nil)
             ((null (cdr forms)) (car forms))
             (t (let ((tmp (gensym \"OR\")))
                  (list 'let (list (list tmp (car forms)))
                        (list 'if tmp tmp (cons 'or (cdr forms))))))))"

    ;; NOTE: COND is a runtime-EVAL special form already (cl-eval.lisp);
    ;; we don't install a user macro for it because that would shadow
    ;; the special-form dispatch.

    "(defmacro setf (place value)
       (cond
         ((symbolp place) (list 'setq place value))
         ((consp place)
          (let ((acc (car place)) (args (cdr place)))
            (cond
              ((eq acc 'car) (list 'rplaca (car args) value))
              ((eq acc 'cdr) (list 'rplacd (car args) value))
              ((eq acc 'aref) (cons 'aset (append args (list value))))
              ((eq acc 'gethash) (list 'puthash (car args) (cadr args) value))
              ((eq acc 'symbol-value) (list 'set-symbol-value (car args) value))
              ((eq acc 'first) (list 'rplaca (car args) value))
              ((eq acc 'rest) (list 'rplacd (car args) value))
              ((eq acc 'nth) (list 'rplaca (list 'nthcdr (car args) (cadr args)) value))
              ;; (setf (svref a i) v) → (aset a i v)
              ((eq acc 'svref) (cons 'aset (append args (list value))))
              ;; (setf (getf plist ind) v) → reassign the plist place with
              ;; the value spliced in; set-getf returns the new list.  When
              ;; the place is a bare symbol we (setq sym (set-getf ...)),
              ;; otherwise leave the set-getf call as the expansion.
              ((eq acc 'getf)
               (if (symbolp (car args))
                   (list 'setq (car args)
                         (list 'set-getf (car args) (cadr args) value))
                   (list 'set-getf (car args) (cadr args) value)))
              ;; (setf (ldb spec n) v) → store (dpb v spec n) back into the
              ;; integer place n, but RETURN v (CLHS: setf yields the newly
              ;; stored value, not the updated place).  Bind v to a temp so
              ;; it is evaluated once and returned after the store.
              ((eq acc 'ldb)
               (let ((vt (gensym \"LDBV\")))
                 (list 'let (list (list vt value))
                       (list 'setf (cadr args)
                             (list 'dpb vt (car args) (cadr args)))
                       vt)))
              ;; (setf (mask-field spec n) v) → store (deposit-field v spec
              ;; n) back into the integer place n, RETURN v.  Same
              ;; return-newval contract as LDB.
              ((eq acc 'mask-field)
               (let ((vt (gensym \"MFV\")))
                 (list 'let (list (list vt value))
                       (list 'setf (cadr args)
                             (list 'deposit-field vt (car args) (cadr args)))
                       vt)))
              (t
               (let ((d (%find-setf-expander acc)))
                 (if d
                     (%apply-setf-expander d args value)
                     nil))))))
         (t nil)))"

    ;; INCF / DECF / PUSH / POP / PUSHNEW: CLHS 5.1.3 -- each subform of the
    ;; PLACE is evaluated ONCE, left to right (after PUSH's item).  These
    ;; used to be textual (setf PLACE (op PLACE ...)), which evaluated the
    ;; place's subforms twice: (push x (aref v (incf i))) bumped I twice and
    ;; read and wrote DIFFERENT elements (push.order.2, then garbage).
    ;; %RMW-PLACE builds the expansion from GET-SETF-EXPANSION.
    "(defmacro incf (place &rest delta)
       (%rmw-place place (lambda (acc) (list '+ acc (if delta (car delta) 1))) nil))"

    "(defmacro decf (place &rest delta)
       (%rmw-place place (lambda (acc) (list '- acc (if delta (car delta) 1))) nil))"

    "(defmacro push (val place)
       (let ((g (gensym \"PSH\")))
         (%rmw-place place (lambda (acc) (list 'cons g acc)) (list (list g val)))))"

    "(defmacro pop (place)
       (let ((tmp (gensym \"POP\")))
         (list 'let (list (list tmp nil))
               (%rmw-place place
                           (lambda (acc) (list 'cdr (list 'setq tmp acc)))
                           nil)
               (list 'car tmp))))"

    "(defmacro pushnew (val place &rest keys)
       (let ((g (gensym \"PN\")))
         (%rmw-place place
                     (lambda (acc) (cons 'adjoin (cons g (cons acc keys))))
                     (list (list g val)))))"

    ;; DO and DO* — sequential variable update (technically DO is
    ;; supposed to be parallel; we approximate as sequential, which
    ;; matches single-variable forms and most test patterns).
    "(defmacro do (var-specs end-spec &rest body)
       (let ((test (car end-spec))
             (result-forms (cdr end-spec))
             (vars nil)
             (steps nil))
         (let ((cur var-specs))
           (loop (when (null cur) (return nil))
             (let ((spec (car cur)))
               (cond
                 ((symbolp spec)
                  (setq vars (cons (list spec nil) vars)))
                 (t
                  (setq vars (cons (list (car spec) (cadr spec)) vars))
                  (when (cddr spec)
                    (setq steps (cons (list (car spec) (caddr spec)) steps))))))
             (setq cur (cdr cur))))
         (let ((step-setqs nil)
               (rev-steps (nreverse steps)))
           (dolist (s rev-steps)
             (setq step-setqs (cons (list 'setq (car s) (cadr s)) step-setqs)))
           (setq step-setqs (nreverse step-setqs))
           (let ((result-form (cond
                                ((null result-forms) nil)
                                ((null (cdr result-forms)) (car result-forms))
                                (t (cons 'progn result-forms)))))
             ;; Leading (declare ...) forms go on the LET*, not into the LOOP
             ;; body where a declaration is illegal and was silently dropped
             ;; (so a DO var declared in the body compiled untyped).
             (let ((decls nil) (rest body))
               (loop (unless (and rest (consp (car rest)) (symbolp (caar rest))
                                  (string= (symbol-name (caar rest)) \"DECLARE\"))
                       (return nil))
                     (setq decls (cons (car rest) decls))
                     (setq rest (cdr rest)))
               (list 'block 'nil
                     (cons 'let* (cons (nreverse vars)
                           (append (nreverse decls)
                                   (list (cons 'loop
                                         (cons (list 'when test (list 'return result-form))
                                               (append rest step-setqs)))))))))))))"

    "(defmacro do* (var-specs end-spec &rest body)
       (cons 'do (cons var-specs (cons end-spec body))))"

    "(defmacro dolist (spec &rest body)
       (let* ((var (car spec))
              (lst-form (cadr spec))
              (result (caddr spec))
              (lst (gensym \"DL\")))
         (list 'let (list (list lst lst-form))
               (list 'loop
                 (list 'when (list 'null lst) (list 'return result))
                 (cons 'let (cons (list (list var (list 'car lst))) body))
                 (list 'setq lst (list 'cdr lst))))))"

    "(defmacro dotimes (spec &rest body)
       (let* ((var (car spec))
              (count-form (cadr spec))
              (result (caddr spec))
              (n (gensym \"DT\")))
         ;; A literal count bounds VAR and N at compile time: declare both
         ;; (integer 0 COUNT) so the per-iteration (>= var n) and (+ var 1)
         ;; take the typed fast path (no tag test; see the compiler's
         ;; %expr-width / %decl-int-width).
         (list* 'let (list (list var 0) (list n count-form))
               (append
                (if (and (integerp count-form) (>= count-form 0))
                    (list (list 'declare (list 'type (list 'integer 0 count-form) var n)))
                    ;; VAR is always a fixnum: it counts 0..COUNT one step per
                    ;; iteration, so exceeding a fixnum would take 2^62
                    ;; iterations.  N is NOT declared (a bignum count is legal).
                    (list (list 'declare (list 'type 'fixnum var))))
                ;; The body's own leading declarations belong on this LET too
                ;; (inside the LOOP's PROGN they were silently dropped).
                (let ((decls nil) (rest body))
                  (loop (unless (and rest (consp (car rest)) (symbolp (caar rest))
                                     (string= (symbol-name (caar rest)) \"DECLARE\"))
                          (return nil))
                        (setq decls (cons (car rest) decls))
                        (setq rest (cdr rest)))
                  (setq body rest)
                  (nreverse decls))
                (list
                 (list 'loop
                   (list 'when (list '>= var n) (list 'return result))
                   (cons 'progn body)
                   ;; the counter cannot reach 2^60 iterations: bound it so
                   ;; the increment compiles to a plain add (no overflow
                   ;; check) in every loop
                   (list 'setq var (list '+ (list 'the (list 'integer 0 576460752303423487) var) 1))))))))"

    "(defmacro case (key &rest clauses)
       (let ((kv (gensym \"CASE\")))
         (let ((acc nil) (cur clauses))
           (loop
             (when (null cur) (return nil))
             (let ((clause (car cur)))
               (let ((tst (car clause)) (body (cdr clause)))
                 (cond
                   ((or (eq tst t)
                        (and (symbolp tst) (string= (symbol-name tst) \"OTHERWISE\")))
                    (setq acc (cons (cons t body) acc)))
                   ((consp tst)
                    (let ((tests nil) (vs tst))
                      (loop (when (null vs) (return nil))
                        (setq tests (cons (list 'eql kv (list 'quote (car vs))) tests))
                        (setq vs (cdr vs)))
                      (setq acc (cons (cons (cons 'or (nreverse tests)) body) acc))))
                   (t
                    (setq acc (cons (cons (list 'eql kv (list 'quote tst)) body) acc))))))
             (setq cur (cdr cur)))
           (list 'let (list (list kv key))
                 (cons 'cond (nreverse acc))))))"

    ;; ECASE / CCASE — like CASE but signal an error when no clause matches
    ;; instead of returning NIL (CLHS 5.3).  No T/OTHERWISE clause is allowed,
    ;; so every key list becomes an (or (eql ...) ...) test and the cond ends
    ;; with a (t (error ...)) fallthrough.  CCASE is a correctable error in
    ;; full CL (store-value + retry); minimally we degrade it to an ECASE-like
    ;; signal (matching the CLAUDE.md CCASE→ECASE degrade pattern).
    "(defmacro ecase (key &rest clauses)
       (let ((kv (gensym \"ECASE\")))
         (let ((acc nil) (cur clauses))
           (loop
             (when (null cur) (return nil))
             (let ((clause (car cur)))
               (let ((tst (car clause)) (body (cdr clause)))
                 (if (consp tst)
                     (let ((tests nil) (vs tst))
                       (loop (when (null vs) (return nil))
                         (setq tests (cons (list 'eql kv (list 'quote (car vs))) tests))
                         (setq vs (cdr vs)))
                       (setq acc (cons (cons (cons 'or (nreverse tests)) body) acc)))
                     (setq acc (cons (cons (list 'eql kv (list 'quote tst)) body) acc)))))
             (setq cur (cdr cur)))
           (setq acc (cons (list t (list 'error \"ECASE: no clause matches\")) acc))
           (list 'let (list (list kv key))
                 (cons 'cond (nreverse acc))))))"

    "(defmacro ccase (key &rest clauses)
       (cons 'ecase (cons key clauses)))"

    "(defmacro prog1 (first &rest rest)
       (let ((tmp (gensym \"P1\")))
         (list 'let (list (list tmp first))
               (cons 'progn rest)
               tmp)))"

    "(defmacro prog2 (first second &rest rest)
       (list 'progn first (cons 'prog1 (cons second rest))))"

    "(defmacro multiple-value-setq (vars form)
       (let ((vals (gensym \"MVS\")))
         (let ((acc nil) (i 0) (vs vars))
           (loop (when (null vs) (return nil))
             (setq acc (cons (list 'setq (car vs) (list 'nth i vals)) acc))
             (setq i (+ i 1))
             (setq vs (cdr vs)))
           (cons 'let (cons (list (list vals (list 'multiple-value-list form)))
                            (append (nreverse acc) (list (car vars))))))))"

    ;; NTH-VALUE — must expand at RUNTIME EVAL so FORM is evaluated in a
    ;; multiple-values context.  The cl-clos.lisp runtime defun is broken
    ;; for n>=1 (it reads the MV buffer AFTER it's been reset to 1 by the
    ;; funcall machinery, and only the primary survives as an ordinary
    ;; argument), so plain (nth-value 1 (values 10 20 30)) returned NIL.
    ;; Registering it as a real runtime macro makes the eval dispatcher's
    ;; macro branch win over the defun and gives MACRO-FUNCTION a proper
    ;; arity-checking wrapper (nth-value.error.1-3).
    "(defmacro nth-value (n form)
       (list 'nth n (list 'multiple-value-list form)))"

    "(defmacro return (&rest args)
       (list 'return-from nil (if args (car args) nil)))"

    "(defmacro 1+ (x) (list '+ x 1))"
    "(defmacro 1- (x) (list '- x 1))"

    "(defmacro locally (&rest body) (cons 'progn body))"
    "(defmacro the (type form) form)"
    "(defmacro declare (&rest decls) nil)"
    ;; PROCLAIM is a real function (ansi-bridge.lisp): it validates the spec
    ;; and records INLINE / NOTINLINE.  A macro here shadowed it with NIL.
    "(defmacro declaim (&rest decls)
       ;; each spec goes through PROCLAIM, which validates it and records
       ;; INLINE / NOTINLINE for the runtime compiler
       (cons 'progn (mapcar (lambda (d) (list 'proclaim (list 'quote d))) decls)))"
    ;; CHECK-TYPE used to expand to NIL — a NO-OP.  Every runtime-eval'd
    ;; library that guards its arguments with CHECK-TYPE therefore ran on with
    ;; the bad value.  That is not merely a missing error: alexandria's
    ;; READ-STREAM-CONTENT-INTO-STRING does
    ;;   (check-type buffer-size positive-integer)
    ;;   (loop :for bytes-read = (read-sequence buffer stream)
    ;;         :do  (write-sequence buffer datum :start 0 :end bytes-read)
    ;;         :while (= bytes-read buffer-size))
    ;; so with :buffer-size 0 the unchecked value makes bytes-read and
    ;; buffer-size both 0 and the loop SPINS FOREVER
    ;; (READ-STREAM-CONTENT-INTO-STRING.2 expects a TYPE-ERROR).
    ;; Signal a real TYPE-ERROR carrying :DATUM/:EXPECTED-TYPE so
    ;; `(handler-case ... (type-error () ...))' can see it.  (CLHS also
    ;; specifies a correctable STORE-VALUE restart; not provided here.)
    "(defmacro check-type (place type &rest args)
       (list 'unless (list 'typep place (list 'quote type))
             (list 'error ''type-error :datum place
                   :expected-type (list 'quote type))))"
    ;; WITH-HASH-TABLE-ITERATOR (CLHS).  Only the ANSI gate's REWRITER ever
    ;; expanded it, so the image had none: at runtime the iterator call was an
    ;; undefined function (upstream ansi-test W-H-T-I.1..11).  Same expansion
    ;; as the rewriter: snapshot the entries, pop one per call.  The name is a
    ;; LOCAL MACRO (CLHS) over an FLET named %WHTI-<name> -- interned, because a
    ;; gensym quoted into the macrolet expander is re-interned when the
    ;; expander is compiled and would no longer name the FLET.  Exhaustion
    ;; returns one NIL.
    "(defmacro with-hash-table-iterator (spec &rest body)
       (let ((ht (gensym \"WHTI-HT\")) (pairs (gensym \"WHTI-PAIRS\"))
             (pair (gensym \"WHTI-PAIR\"))
             (next (intern (concatenate (quote string) \"%WHTI-\" (symbol-name (car spec))))))
         (list 'let* (list (list ht (cadr spec)) (list pairs (list '%ht-to-alist ht)))
               (list 'flet
                     (list (list next nil
                                 (list 'if (list 'null pairs)
                                       nil
                                       (list 'let (list (list pair (list 'car pairs)))
                                             (list 'setq pairs (list 'cdr pairs))
                                             (list 'values t (list 'car pair) (list 'cdr pair))))))
                     (list* 'macrolet
                            (list (list (car spec) nil (list 'list (list 'quote next))))
                            body)))))"
    ;; PRINT-UNREADABLE-OBJECT (CLHS).  Like WITH-HASH-TABLE-ITERATOR it
    ;; existed only in the ANSI gate's rewriter, so at runtime
    ;; (print-unreadable-object (x s) ...) compiled as a CALL and the spec list
    ;; (x s) as a call of X -- upstream PRINT-UNREADABLE-OBJECT.NIL.1 called
    ;; the fixnum 1 and killed the printer chapter.
    "(defmacro print-unreadable-object (spec &rest body)
       (list '%print-unreadable-object (car spec) (cadr spec)
             (getf (cddr spec) :type) (getf (cddr spec) :identity)
             (if body (list 'function (cons 'lambda (cons nil body))) nil)))"
    ;; RESTART-BIND (CLHS 9.2) -- there was NO expander in the CLI (only the
    ;; ANSI gate runner rewrote it), so every use was an UNDEFINED-FUNCTION.
    ;; Cells are (NAME FN REPORT INTERACTIVE TEST), the shape %PUSH-RESTARTS
    ;; and INVOKE-RESTART already consume; no :CASE marker, so invoking one
    ;; just calls FN and returns its values.
    "(defmacro restart-bind (bindings &rest body)
       (list '%push-restarts
             (cons 'list
                   (mapcar (lambda (b)
                             (list 'list (list 'quote (car b)) (cadr b)
                                   (getf (cddr b) :report-function)
                                   (getf (cddr b) :interactive-function)
                                   (getf (cddr b) :test-function)))
                           bindings))
             (list 'function (cons 'lambda (cons nil body)))))"
    ;; WITH-CONDITION-RESTARTS: both forms are evaluated (CLHS 9.2); the
    ;; condition/restart association itself is not modelled yet.
    "(defmacro with-condition-restarts (condition-form restarts-form &rest body)
       (list 'progn condition-form restarts-form (cons 'progn body)))"
    "(defmacro ignore-errors (&rest body)
       (list 'handler-case (cons 'progn body) (list 'error (list 'c) (list 'values nil 'c))))"
    ;; NOT a PROGN: w-s-i-s must bind the whole printer/reader variable set
    ;; (notably *PRINT-CASE* to :UPCASE) around BODY.  Route to the existing
    ;; worker in mvm/cl-reader.lisp, which restores on both the normal and
    ;; error paths and propagates multiple values.
    "(defmacro with-standard-io-syntax (&rest body)
       (list '%with-standard-io-syntax
             (list 'function (cons 'lambda (cons nil body)))))"

    ;; TYPECASE / ETYPECASE — expand to (let ((g KEY)) (cond ((typep g 'T1) ...) ...)).
    ;; Each clause's type spec is quoted and tested with TYPEP.  An OTHERWISE/T
    ;; clause becomes the cond's (t …).  ETYPECASE adds a type-error fallthrough.
    ;; uiop/package's reify-package uses (etypecase pkg ((eql (find-package :cl)) …)).
    "(defmacro typecase (key &rest clauses)
       (let ((g (gensym \"TC\")))
         (list 'let (list (list g key))
               (cons 'cond
                 (mapcar (lambda (cl)
                           (let ((ty (car cl)) (body (cdr cl)))
                             (if (or (eq ty t) (and (symbolp ty) (string= (symbol-name ty) \"OTHERWISE\")))
                                 (cons t body)
                                 (cons (list 'typep g (list 'quote ty)) body))))
                         clauses)))))"

    "(defmacro etypecase (key &rest clauses)
       (let ((g (gensym \"ETC\")))
         (list 'let (list (list g key))
               (append
                 (cons 'cond
                   (mapcar (lambda (cl)
                             (let ((ty (car cl)) (body (cdr cl)))
                               (cons (list 'typep g (list 'quote ty)) body)))
                           clauses))
                 (list (list t (list 'error \"ETYPECASE: no clause matches\")))))))"

    ;; CTYPECASE — like ETYPECASE but a correctable (store-and-retry) error in
    ;; full CL.  Minimally we degrade it to an ETYPECASE-like signal on no
    ;; match (mirroring the CCASE→ECASE degrade); no retry/store-value yet.
    "(defmacro ctypecase (key &rest clauses)
       (let ((g (gensym \"CTC\")))
         (list 'let (list (list g key))
               (append
                 (cons 'cond
                   (mapcar (lambda (cl)
                             (let ((ty (car cl)) (body (cdr cl)))
                               (cons (list 'typep g (list 'quote ty)) body)))
                           clauses))
                 (list (list t (list 'error \"CTYPECASE: no clause matches\")))))))"

    ;; DEFINE-MODIFY-MACRO — (define-modify-macro name lambda-list fn [doc]).
    ;; Defines NAME as a macro: (name place a b …) => FN applied to the place's
    ;; value and the args, stored back.  We ignore the lambda-list's structure
    ;; and capture all post-place args via &rest, which covers the
    ;; `(&rest args)' shape ASDF's APPENDF uses.
    ;; The body delegates to %DMM-EXPAND (compiler.lisp) so the place's
    ;; subforms are evaluated EXACTLY ONCE (CLHS 5.1.3).  The old body pasted
    ;; `(setf place (fn place . args))', writing PLACE twice — e.g.
    ;; (maxf (svref v (incf p)) (incf p)) ran (incf p) three times.
    "(defmacro define-modify-macro (name lambda-list fn &rest doc)
       (list 'defmacro name (list 'place '&rest 'args)
             (list '%dmm-expand (list 'quote fn) 'place 'args)))"

    ;; DESTRUCTURING-BIND — expand to (apply (lambda PATTERN BODY) EXPR).
    ;; %bind-params handles &optional/&rest/&key/&aux AND dotted tails, so
    ;; the apply-lambda trick covers ASDF's `(destructuring-bind (car . cdr)
    ;; form …)' (a dotted macro-style lambda list).
    "(defmacro destructuring-bind (pattern expr &rest body)
       (list 'apply (cons 'lambda (cons pattern body)) expr))"

    ;; DO-SYMBOLS / DO-EXTERNAL-SYMBOLS / DO-ALL-SYMBOLS — package
    ;; iteration.  Mirror compiler.lisp's mvm-define-macro expansions so
    ;; runtime EVAL of these (used heavily by uiop/package:ensure-package)
    ;; materializes accessible symbols via %do-*-symbols-fn then walks.
    "(defmacro do-symbols (spec &rest body)
       (let ((var (car spec))
             (pkg (if (cdr spec) (cadr spec) '*package*))
             (result (and (cddr spec) (caddr spec)))
             (syms (gensym \"DS\")) (cur (gensym \"DSC\")))
         (list 'block nil
           (list 'let (list (list syms nil))
             (list '%do-symbols-fn
                   (list 'lambda (list var) (list 'setq syms (list 'cons var syms)))
                   pkg)
             (list 'let (list (list cur syms))
               (list 'loop
                 (list 'when (list 'null cur) (list 'return result))
                 (list 'let (list (list var (list 'car cur)))
                   (cons 'progn body))
                 (list 'setq cur (list 'cdr cur))))))))"

    "(defmacro do-external-symbols (spec &rest body)
       (let ((var (car spec))
             (pkg (if (cdr spec) (cadr spec) '*package*))
             (result (and (cddr spec) (caddr spec)))
             (syms (gensym \"DES\")) (cur (gensym \"DESC\")))
         (list 'block nil
           (list 'let (list (list syms nil))
             (list '%do-external-symbols-fn
                   (list 'lambda (list var) (list 'setq syms (list 'cons var syms)))
                   pkg)
             (list 'let (list (list cur syms))
               (list 'loop
                 (list 'when (list 'null cur) (list 'return result))
                 (list 'let (list (list var (list 'car cur)))
                   (cons 'progn body))
                 (list 'setq cur (list 'cdr cur))))))))"

    ;; CLHS 22.4 PPRINT-LOGICAL-BLOCK.  The layout itself is runtime code
    ;; in cl-printer.lisp (%PPRINT-LB-BEGIN / -END); this binds the user's
    ;; stream variable to the block's stream so the body's output and its
    ;; PPRINT-NEWLINEs are captured in order.  It used to be a do-nothing
    ;; FUNCTION in the shipped image (only the ANSI corpus rewriter knew it).
    "(defmacro pprint-logical-block (spec &rest body)
       (let* ((ss (car spec))
              (sym (cond ((null ss) '*standard-output*) ((eq ss t) '*terminal-io*) (t ss)))
              (obj (cadr spec))
              (kw (cddr spec))
              (sv (gensym \"PPS\"))
              (lv (gensym \"PPL\")))
         `(let ((,sv (%resolve-output-stream ,sym)) (,lv ,obj))
            (if (%pp-level-exceeded-p)
                (write-string \"#\" ,sv)
                (if (not (listp ,lv))
                    (write ,lv :stream ,sv)
                    (let ((,sym (%pprint-lb-begin ,sv ,lv ,(getf kw :prefix) ,(getf kw :per-line-prefix))))
                      (catch :%pp-tag ,@body)
                      (%pprint-lb-end ,sym ,(getf kw :suffix)))))
            nil)))"

    "(defmacro pprint-pop () '(%pprint-pop-fn))"

    "(defmacro pprint-exit-if-list-exhausted () '(%pprint-exit-fn))"

    "(defmacro do-all-symbols (spec &rest body)
       (let ((var (car spec))
             (result (and (cdr spec) (cadr spec)))
             (syms (gensym \"DAS\")) (cur (gensym \"DASC\")))
         (list 'block nil
           (list 'let (list (list syms nil))
             (list '%do-all-symbols-fn
                   (list 'lambda (list var) (list 'setq syms (list 'cons var syms))))
             (list 'let (list (list cur syms))
               (list 'loop
                 (list 'when (list 'null cur) (list 'return result))
                 (list 'let (list (list var (list 'car cur)))
                   (cons 'progn body))
                 (list 'setq cur (list 'cdr cur))))))))"))

(defun %rt-install-one (src)
  "Read SRC (a defmacro source string) and eval.  Caller wraps in
   handler-case if it wants resilience — wrapping each call here
   triggered a stability bug where installs 3+ stopped registering.
   A NIL SRC (unrolled (nth k) past the list end) is a no-op so the
   unroll can safely overshoot the current entry count."
  (when src
    (eval (read-from-string src))))


(defun %install-runtime-cl-macros ()
  "Eval each entry of *modus-runtime-macros* at boot.  The walks
   below are unrolled because a (loop … (%rt-install-one (car forms))
   (setq forms (cdr forms))) sequence somehow leaves later iterations
   unable to register the macro — even with each individual call in a
   fresh handler-case frame, calls 4+ install a #<INTERP-CLOSURE> but
   set-macro-function doesn't seem to actually puthash it.  Cause not
   yet diagnosed; unrolling sidesteps the issue completely."
  (when (boundp '*modus-runtime-macros*)
    (let ((lst *modus-runtime-macros*))
      ;; NO handler-case here — wrapping each install with handler-case
      ;; triggers a stability bug where installs 3+ fail to register.
      ;; If a source string is malformed, we WILL crash here.  Caller
      ;; must wrap the whole call if it wants resilience.
      (%rt-install-one (nth 0 lst))
      (%rt-install-one (nth 1 lst))
      (%rt-install-one (nth 2 lst))
      (%rt-install-one (nth 3 lst))
      (%rt-install-one (nth 4 lst))
      (%rt-install-one (nth 5 lst))
      (%rt-install-one (nth 6 lst))
      (%rt-install-one (nth 7 lst))
      (%rt-install-one (nth 8 lst))
      (%rt-install-one (nth 9 lst))
      (%rt-install-one (nth 10 lst))
      (%rt-install-one (nth 11 lst))
      (%rt-install-one (nth 12 lst))
      (%rt-install-one (nth 13 lst))
      (%rt-install-one (nth 14 lst))
      (%rt-install-one (nth 15 lst))
      (%rt-install-one (nth 16 lst))
      (%rt-install-one (nth 17 lst))
      (%rt-install-one (nth 18 lst))
      (%rt-install-one (nth 19 lst))
      (%rt-install-one (nth 20 lst))
      (%rt-install-one (nth 21 lst))
      (%rt-install-one (nth 22 lst))
      (%rt-install-one (nth 23 lst))
      (%rt-install-one (nth 24 lst))
      (%rt-install-one (nth 25 lst))
      (%rt-install-one (nth 26 lst))
      (%rt-install-one (nth 27 lst))
      (%rt-install-one (nth 28 lst))
      (%rt-install-one (nth 29 lst))
      (%rt-install-one (nth 30 lst))
      (%rt-install-one (nth 31 lst))
      (%rt-install-one (nth 32 lst))
      (%rt-install-one (nth 33 lst))
      (%rt-install-one (nth 34 lst))
      (%rt-install-one (nth 35 lst))
      (%rt-install-one (nth 36 lst))
      (%rt-install-one (nth 37 lst))
      (%rt-install-one (nth 38 lst))
      (%rt-install-one (nth 39 lst))
      (%rt-install-one (nth 40 lst))
      (%rt-install-one (nth 41 lst))
      (%rt-install-one (nth 42 lst))
      (%rt-install-one (nth 43 lst))
      (%rt-install-one (nth 44 lst))
      (%rt-install-one (nth 45 lst))
      (%rt-install-one (nth 46 lst))
      (%rt-install-one (nth 47 lst))
      (%rt-install-one (nth 48 lst))
      (%rt-install-one (nth 49 lst))
      (%rt-install-one (nth 50 lst))
      (%rt-install-one (nth 51 lst))
      (%rt-install-one (nth 52 lst))
      (%rt-install-one (nth 53 lst))
      (%rt-install-one (nth 54 lst))
      (%rt-install-one (nth 55 lst))
      (%rt-install-one (nth 56 lst))
      (%rt-install-one (nth 57 lst))
      (%rt-install-one (nth 58 lst))
      (%rt-install-one (nth 59 lst))
      (%rt-install-one (nth 60 lst))
      (%rt-install-one (nth 61 lst))
      (%rt-install-one (nth 62 lst))
      (%rt-install-one (nth 63 lst))
      (%rt-install-one (nth 64 lst))
      (%rt-install-one (nth 65 lst))
      (%rt-install-one (nth 66 lst))
      (%rt-install-one (nth 67 lst))
      (%rt-install-one (nth 68 lst))
      (%rt-install-one (nth 69 lst))
      (%rt-install-one (nth 70 lst))
      (%rt-install-one (nth 71 lst))
      (%rt-install-one (nth 72 lst))
      (%rt-install-one (nth 73 lst))
      (%rt-install-one (nth 74 lst))
      (%rt-install-one (nth 75 lst))
      (%rt-install-one (nth 76 lst))
      (%rt-install-one (nth 77 lst))
      (%rt-install-one (nth 78 lst))
      (%rt-install-one (nth 79 lst))
      (%rt-install-one (nth 80 lst))
      (%rt-install-one (nth 81 lst))
      (%rt-install-one (nth 82 lst))
      (%rt-install-one (nth 83 lst))
      (%rt-install-one (nth 84 lst))
      (%rt-install-one (nth 85 lst))
      (%rt-install-one (nth 86 lst))
      (%rt-install-one (nth 87 lst))
      (%rt-install-one (nth 88 lst))
      (%rt-install-one (nth 89 lst))
      (%rt-install-one (nth 90 lst))
      (%rt-install-one (nth 91 lst))
      (%rt-install-one (nth 92 lst))
      (%rt-install-one (nth 93 lst))
      (%rt-install-one (nth 94 lst))
      (%rt-install-one (nth 95 lst))
      ;; The unroll above is a FIXED LENGTH.  Entries past it were silently
      ;; never installed: at 46 entries against 41 unrolled calls, PPRINT-
      ;; LOGICAL-BLOCK, PPRINT-POP, DO-ALL-SYMBOLS ... were plain undefined
      ;; functions.  Say so loudly if the list outgrows it again.
      (when (> (length lst) 96)
        (write-string-serial ";; WARNING: *modus-runtime-macros* has more entries than %install-runtime-cl-macros unrolls; the rest are NOT installed")
        (write-char-serial 10))))
  ;; Re-assert standard CL symbol exports.  %init-packages exports them
  ;; at boot, but a subsequent boot-time read of a &rest-bearing form
  ;; demotes CL:&REST from :external back to :internal (other lambda-list
  ;; keywords stay :external).  CLHS requires &REST be :external in
  ;; COMMON-LISP; an :internal &REST is not inherited by use-CL packages,
  ;; so uiop's define-package :use-reexport path — which find-symbol*'s
  ;; every CL external — signals on &REST.  Re-running the export is
  ;; idempotent (only ever promotes :internal -> :external for the
  ;; standard names) and leaves reader / package state otherwise intact.
  (handler-case (%export-standard-cl-symbols) (t (c) nil))
  ;; Advertise the host platform in *features* so ASDF/UIOP's detect-os
  ;; recognises Modus as a Unix.  The generic (build-generic.lisp) binary
  ;; runs as a Linux ELF process, so :unix and :linux are accurate.
  ;; Without :unix, UIOP's os-unix-p returns NIL and detect-os signals
  ;; "Congratulations for trying ASDF on an operating system that is
  ;; neither Unix, nor Windows…".  pushnew-style guarded so repeated
  ;; installs stay idempotent.
  (handler-case
      (progn
        (when (boundp '*features*)
          (unless (member :unix *features*)
            (setq *features* (cons :unix *features*)))
          (unless (member :linux *features*)
            (setq *features* (cons :linux *features*)))
          ;; Byte order.  Real implementations advertise this directly
          ;; (SBCL pushes :LITTLE-ENDIAN on x86/x86-64/arm64); the whole
          ;; point of trivial-features is to normalise it, and its SBCL
          ;; backend (tf-sbcl.lisp) is pure SB-ALIEN FFI that Modus cannot
          ;; read — so Modus has to supply the feature itself.
          ;;
          ;; Without it, babel's define-character-encoding forms
          ;;     :use-bom      #+big-endian :utf-16be #+little-endian :utf-16le
          ;;     :bom-encoding #+big-endian #(#xfe #xff) #+little-endian #(#xff #xfe)
          ;;     :ambiguous    #+little-endian t #+big-endian nil
          ;; lose BOTH branches of each pair, so the MAKE-INSTANCE initarg
          ;; plist ends up ODD-length and CLHS 7.1.2 validation signals
          ;; PROGRAM-ERROR — killing all 9 UTF-16 / UTF-32 / UCS-2
          ;; encodings.  (:utf-8 / :utf-8b have no reader conditionals and
          ;; were the two that survived.)
          ;;
          ;; Every consumer of this file is little-endian: x86-64 (generic,
          ;; generic-cli, x64-cl-repl, modus-selfhost) and i386 (i386-cli).
          ;; A big-endian target (ppc/ppc32/68k) must push :BIG-ENDIAN in
          ;; its own boot path instead of loading this default.
          (unless (or (member :little-endian *features*)
                      (member :big-endian *features*))
            (setq *features* (cons :little-endian *features*)))
          ;; Advertise :modus so UIOP recognises this implementation.  The
          ;; vendored asdf.lisp guards its "ASDF is not supported on your
          ;; implementation" hard error with
          ;;   #-(or abcl … mkcl modus sbcl scl xcl) (error …)
          ;; so without :modus that error fires (and, more importantly, UIOP's
          ;; per-impl dispatch has no Modus branch to land on).  :modus selects
          ;; the generic fall-throughs.  :modus only suppresses the
          ;; unsupported-impl error; it says nothing about which
          ;; implementation-specific branches a library should take.
          ;;
          ;; THAT question is answered separately, and the answer is
          ;; :GENERA — see net/genera-compat.lisp, which installs the
          ;; Genera surface (SCL / SYS / SI / PROCESS / CLI / GRAY-STREAMS /
          ;; FUTURE-COMMON-LISP) and then pushes :genera.  It is NOT pushed
          ;; here, because the feature must never be visible before the
          ;; support it promises exists.  (An earlier revision of this
          ;; comment claimed :genera was unusable because it "reexports
          ;; FUTURE-COMMON-LISP, which Modus lacks".  Measured, that is
          ;; wrong: cl-ppcre's (:use :future-common-lisp) is satisfied by
          ;; making FUTURE-COMMON-LISP a nickname of COMMON-LISP — on Modus
          ;; the CL package IS the ANSI package — and cl-ppcre loads
          ;; bit-identically with :genera on.  Task #237.)
          (unless (member :modus *features*)
            (setq *features* (cons :modus *features*)))))
    (t (c) nil)))
