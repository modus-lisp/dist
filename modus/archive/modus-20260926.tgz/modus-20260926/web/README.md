# Modus in the browser

A JavaScript interpreter for MVM bytecode that runs the hosted Modus CLI image
in a Web Worker (and under node).  No native code is involved: the image is
compiled to MVM bytecode by the normal build pipeline and stopped before the
translator; `mvm.js` executes that bytecode against a flat linear memory that
reproduces the hosted x86-64 machine (BSS block at `0x10000000`, machine stack,
Cheney semispace heap, x64 object and frame layouts, the x64 trap table).

## Files

| file | what |
|---|---|
| `../mvm/build-web.lisp` | x64 CLI wrapper's arch slots + web-only overrides; dumps `modus.mvmw` |
| `mvm.js` | the interpreter: memory, GC, calls, traps, syscalls, snapshots |
| `host-node.js`, `run-node.js` | node host (real fds) and CLI runner |
| `host-browser.js`, `worker.js`, `index.html`, `serve.js` | browser host (in-memory FS, stdin ring in a SharedArrayBuffer), the worker, the page, a COOP/COEP static server |
| `t/headless.js` | smoke test: drives the page in headless Chrome over the DevTools pipe |
| `modus.mvmw` | generated: bytecode + function table + constant pool (~13 MB) |
| `modus.core.gz` | generated: a core snapshot taken at CLI-TOPLEVEL (~1 MB) |

## GitHub Pages

The REPL runs as a static site. GitHub Pages cannot send the COOP/COEP headers
that `SharedArrayBuffer` (and thus the blocking stdin) needs, so
`coi-serviceworker.js` installs a service worker that re-serves same-origin
responses with those headers and reloads once; the second load is
cross-origin isolated. This is verified against a header-less server
(`node web/serve.js --no-coi`), which is exactly the Pages condition.

Deploy (pushes an orphan `gh-pages` branch of just the browser files plus the
gzipped `modus.mvmw.gz` ~1.3 MB and `modus.core.gz` ~0.9 MB):

```sh
web/deploy-pages.sh                 # origin gh-pages
```

Then in the repo: **Settings → Pages → Deploy from a branch → `gh-pages` /
(root)**. The REPL appears at `https://<user>.github.io/<repo>/`, boots from
the core in well under a second, and needs no server.

## Build and run

```sh
# 1. the bytecode module (~3 min; MODUS_NO_JIT keeps the x64 translator out)
MODUS_NO_JIT=1 sbcl --dynamic-space-size 8192 --script mvm/build-web.lisp

# 2. a core snapshot, so nobody waits for the boot (~8 min once)
node web/run-node.js --trace 1 --save-core web/modus.core.gz --eval '(print 1)' --quit

# 3. run under node
node web/run-node.js --core web/modus.core.gz --eval '(print (+ 1 2))' --quit
node web/run-node.js --core web/modus.core.gz            # REPL on stdin

# 4. run in a browser
node web/serve.js 18080     # then open http://localhost:18080/
node web/serve.js 18080 --no-coi   # emulate GitHub Pages (no COOP/COEP; the service worker supplies them)
node web/t/headless.js 'http://localhost:18080/?eval=(print%20(*%206%207))'
```

The page must be served cross-origin isolated (`serve.js` sets the headers)
because the worker blocks on stdin with `Atomics.wait`.

## Deep links

The page reads the location **hash** so a URL can set things up and drop you at
a live prompt:

- `#eval=FORM` — evaluate FORM at startup (repeatable, ordered).
- `#load=URL`  — fetch URL (relative to the page or absolute; CORS applies)
  into the in-memory filesystem and `LOAD` it (repeatable, ordered).

Encode with `encodeURIComponent`, e.g.
`.../repl/#eval=%28print%20%28%2B%201%202%29%29`. Hash actions run and then the
REPL stays interactive. The query string `?eval=FORM` is the batch form: it runs
and exits (used by the test harness).

Gotcha: the page fetches `modus.mvmw.gz` before the plain file, so after
rebuilding the module regenerate the gzip (`gzip -kf web/modus.mvmw`, which
`deploy-pages.sh` does) or the browser will keep loading the stale image.

## Completion and the symbol explorer

The page can introspect the *live* image, not a static list. A tiny compiled
RPC baked into the build (`%web-rpc`) reads a request from a fixed memory
buffer and writes a text response to another: `c` prefix-complete, `a`
substring-apropos (both walk `*sym-name-table*`, all ~9000 interned names),
and `d` describe (kind — special-operator / macro / function / variable /
unknown — plus a bounded printed value).

The worker can't take a message while it's blocked reading stdin, so it
services the request re-entrantly from inside that idle read (the same
mechanism `callLisp` uses for checked arithmetic), woken by an
`Atomics.notify` on the stdin control; the machine registers are saved and
restored around the call so a bad query can't corrupt the REPL. The small
helpers are pre-translated at startup so the first completion is quick.

- **Tab / live dropdown** on the REPL input: prefix completion, arrow keys,
  Enter/Tab to accept, Esc to dismiss.
- **Symbol explorer** (the `☰ symbols` button): a substring filter, the
  matching symbols, and a detail pane with the kind badge, the value, and
  buttons to insert the name or run `(describe …)` in the REPL.

Because it queries the live image, runtime `defun`s and `defvar`s are
completed and described immediately.

## Sample library (`samples/`)

Graphical Lisp samples that drive the page's DOM and a WebGL canvas — no image
rebuild, they run on three custom syscalls (`5000` send a command batch, `5001`
poll input events, `5002` block for an event) dispatched entirely in `mvm.js`.
The **▶ samples** button in the bar fetches `samples/gui.lisp` plus a sample and
loads them; or `(load "…/gui.lisp")` then `(load "…/calc.lisp")` and run it.

- `gui.lisp` — the bridge: `gui-reset`/`gui-el`/`gui-text`/`gui-style`/`gui-on`
  build DOM, `gui-canvas`/`gui-bg`/`gui-sprites` drive a colored-quad WebGL
  renderer, and `gui-wait`/`gui-events` are the event loop (click / key / a
  per-frame tick).  Commands and events are tab-separated text lines.
- `calc.lisp` — `(calc)` opens a DOM calculator; Esc closes it.
- `snake.lisp` — `(snake)` is a WebGL game (arrows to steer, Space to restart,
  Esc to quit), self-paced from the worker clock.

## Startup speed

A cold core restore has an empty JS-translation cache, so the first thing you
evaluate would otherwise translate ~345 compiler/reader functions on demand and
run them interpreted until they get hot.  Two things address that: keyword
interning is memoized in `mvm.js` (the compiler re-interns the same `:foo`
literals millions of times through the symbol hash table — the profiler showed
`%INTERN-KEYWORD` / `%HT-*` dominating a load; the memo drops the hash traffic
~9×), and the worker force-compiles the hot set (`warmset.js`) right after the
restore, behind the load spinner.  Regenerate `warmset.js` after any module
rebuild: `DUMP_COMPILED=warmset.tmp node web/run-node.js --core web/modus.core.gz
--load web/samples/gui.lisp … --quit` then wrap the JSON as `self.MVM_WARMSET`.

## Quicklisp (offline, bundled)

`ql:quickload` is ready at the prompt.  The page auto-loads
`modus-quicklisp/setup.lisp` at boot (the browser analogue of a `~/.modusrc`
`(load …)`), which defines the `QL` package over the image's baked
`install-tarball` pipeline (untar → parse the `.asd` → topo-sort → load).  It is
**offline** — a system is a plain `.tar` under `systems/`, not a network fetch:

```lisp
> (ql:quickload :sha1)          ; untars systems/sha1.tar and loads it
> (sha1:sha1-hex "abc")         ; => "A9993E364706816ABA3E25717850C26C9CD0D89D"
```

Bundle more systems by dropping `<name>.tar` in `systems/` and listing the name
in `index.html`'s startup staging.  The image is a CL subset, so real libraries
are hit-or-miss — small, portable ones work.  Two caveats: compiling a library
takes a while (the interpreter is doing real work), and reference a package
(`sha1:…`) only *after* the `quickload` that creates it — naming it earlier in
the same form makes the reader hang on the not-yet-existing package.  Networked
`ql:quickload` from a real dist is out: no ql client bootstrap, and
quicklisp.org isn't cross-origin-isolation friendly.

## What the interpreter does and does not do

- Every vreg lives in the frame (per-frame copies), so callee-saved registers
  and GC roots fall out of the stack layout; the frame keeps translate-x64's
  slot offsets so `&rest` argument copying and frame slots match.
- Words are 64-bit, carried as int32 pairs; `mul`, checked arithmetic, `div`
  and the crypto multiplies fall back to BigInt only when a value leaves the
  53-bit range.
- The collector is a Cheney copy with conservative, bitmap-validated roots
  (stack, BSS block, VR), like the native trampoline.
- A bad dereference (`car` of a fixnum) does what the native SIGSEGV stub
  does: longjmp through the armed `handler-case` with T, which is how it
  becomes a `TYPE-ERROR`.
- The image's runtime JIT seam is served by a web arm (`build-web.lisp`,
  appended last so it wins): an eval'd module's bytecode is copied into an
  exec page inside linear memory, `%jit-icache-flush` relocates its call and
  fn-addr operands in place (out-of-module callees through a table the Lisp
  side resolves), quoted constants are read through a GC-updated vector at
  run time, and `%jit-call` runs the page on this interpreter.  So
  user-defined functions run at interpreter speed instead of doubly
  interpreted (fib 20: 71 s → 1.2 s).  Function values are
  `(phys-index << 4) | 3`; the module's own bytecode is relocated the same
  way at load.
- Translation to JS.  A bytecode function called more than a threshold
  (`--compile-threshold`, default 20) is translated into JS: basic blocks
  become `switch` cases, V0–V8 live in JS locals and are spilled to the
  memory frame around calls, traps, collections and delegated
  instructions, V9–V15 and the frame slots stay in memory, so the GC and
  longjmp see exactly what they see for interpreted code.  A driver loop
  runs translated functions without JS recursion (a Lisp call never grows
  the JS stack), large functions are emitted as chunks small enough for
  V8 to optimize, and cold or untranslatable code stays interpreted; the
  two mix freely.  Steady state, node, `web/t/bench.lisp`:

  | | interpreted | translated |
  |---|---|---|
  | fib 27 | 712 ms | 98 ms |
  | tak 18 12 6 | 69 ms | 13 ms |
  | sort 100k fixnums with `#'<` | 1433 ms | 645 ms |
  | format 3000 pairs to a string | 3126 ms | 1118 ms |
  | 10k string keys into an EQUAL table | 7455 ms | 2485 ms |
  | read a 3000-element list from a string | 11035 ms | 3639 ms |

- I/O.  Files: node uses real descriptors; the browser has an in-memory
  filesystem rooted at `/home/web` — drop files on the page (or use the
  picker) and they appear at the next prompt, and every file the program
  writes is offered as a download in the bar.  Network: the image's
  socket layer (`socket`/`connect`/`write`/`read`/`close`, plus a private
  syscall 4242 for name resolution) is answered as one HTTP request per
  connection, so `(http-get "http://host/path")` works: node performs it
  with curl, the browser with `fetch` on the page thread (subject to CORS;
  same-origin and CORS-enabled hosts work, port 443 maps to https).  The
  C-string and I/O scratch buffers are moved into the BSS block
  (`*cli-arch-io-scratch-source*`) because the x64 defaults fall inside the
  interpreter's heap arena.
- Not supported: threads (`%spawn-thread`), listening sockets, port I/O.

## Debugging flags (`run-node.js`)

`--trace 1` (progress + GC log), `--trace 2` (every instruction; with
`--trace-from N --trace-count M --trace-regs` for a window), `--max-steps N`,
`--profile` (call counts + sampled self time per function), `--watch FN`
(print args at each entry), `--debug`.

## Web-only source overrides (`build-web.lisp`)

Same answers, cheaper on an interpreter: `eql` exits early for the non-numeric
cases.  (There used to be a 4096-bucket hash-table override here too; mainline
grew a growable index in fa2b77a and the stale copy then re-indexed every table
on every insert — see the paragraph where it used to live.)  The i386 image was
tried first and abandoned: its 30-bit fixnums push interning and hashing
through the bignum tower.

The arch slots also pin the file-I/O scratch addresses (`*cstr-scratch*`,
`*io-buf-addr*`) into the BSS block **twice**: once in the kernel prologue, so
they are right from the first instruction, and again after `init-all-globals`,
which re-runs cl-fileio's defvar thunks.  Both defaults the shared boot text
leaves in place — `#x0FF00000` and `#x1DE00000` — are fatal here: one is below
`VBASE` and one is inside the heap arena.
