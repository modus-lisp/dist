;;;; test/test.lisp — differential oracle for pagetree.
;;;;
;;;; (1) MODEL TEST: long random put/del/get sequences over random byte-vector
;;;;     keys/values vs an in-RAM reference (hash-table + sorted key list).  After
;;;;     each op AND after a reopen, assert tget parity and that an ordered cursor
;;;;     scan equals the sorted reference.  Includes multi-page keys/values to
;;;;     force splits and overflow.
;;;; (2) CRASH-RECOVERY TEST: build a store on a mem-device with :fail-after N,
;;;;     commit several txns, then run a txn that dies mid-commit (injected
;;;;     fault); reopen over the SAME device and assert the last successfully
;;;;     committed state survives and no partial txn is visible.  Fuzz N.
;;;;
;;;; Runs on the mem device + baseline pager.  (run-tests) => T iff all pass.

(defpackage #:pagetree/test
  (:use #:cl)
  (:local-nicknames (#:pt #:pagetree)
                    (#:dev #:pagetree.device)
                    (#:pager #:pagetree.pager)
                    (#:bt #:pagetree.btree))
  (:export #:run-tests))

(in-package #:pagetree/test)

;;; ---------------------------------------------------------------------
;;;  Deterministic PRNG (portable, reproducible across runs)
;;; ---------------------------------------------------------------------

(defvar *seed* 0)
(defun nextr ()
  "xorshift32-ish; returns a fixnum in [0, 2^31)."
  (let ((x *seed*))
    (setf x (logand (logxor x (ash x 13)) #xffffffff))
    (setf x (logand (logxor x (ash x -17)) #xffffffff))
    (setf x (logand (logxor x (ash x 5)) #xffffffff))
    (setf *seed* (if (zerop x) #x1234567 x))
    (logand x #x7fffffff)))
(defun rnd (n) (mod (nextr) n))

(defun rand-bytes (minlen maxlen)
  (let* ((len (+ minlen (rnd (1+ (- maxlen minlen)))))
         (v (make-array len :element-type '(unsigned-byte 8))))
    (dotimes (i len v) (setf (aref v i) (rnd 256)))))

;;; ---------------------------------------------------------------------
;;;  Reference model: hash-table + (lazily) sorted keys
;;; ---------------------------------------------------------------------

(defun bv= (a b)
  (and (= (length a) (length b))
       (dotimes (i (length a) t) (unless (= (aref a i) (aref b i)) (return nil)))))

(defun bv< (a b)
  (let ((la (length a)) (lb (length b)))
    (dotimes (i (min la lb))
      (let ((x (aref a i)) (y (aref b i)))
        (cond ((< x y) (return-from bv< t)) ((> x y) (return-from bv< nil)))))
    (< la lb)))

(defstruct model (table (make-hash-table :test 'equalp)))
(defun model-put (m k v) (setf (gethash (coerce k 'list) (model-table m)) (cons k v)))
(defun model-del (m k) (remhash (coerce k 'list) (model-table m)))
(defun model-get (m k)
  (let ((e (gethash (coerce k 'list) (model-table m)))) (when e (cdr e))))
(defun model-sorted (m)
  "List of (key . value) sorted by key."
  (let ((pairs '()))
    (maphash (lambda (kl e) (declare (ignore kl)) (push e pairs)) (model-table m))
    (sort pairs #'bv< :key #'car)))

;;; ---------------------------------------------------------------------
;;;  Assertions / harness
;;; ---------------------------------------------------------------------

(defvar *fails* 0)
(defvar *checks* 0)

(defun chk (ok fmt &rest args)
  (incf *checks*)
  (unless ok
    (incf *fails*)
    (format t "~&  FAIL: ~?~%" fmt args))
  ok)

(defun scan-store (store)
  "Ordered (key . value) list via a read-txn cursor."
  (pt:with-read-txn (txn store)
    (let ((cur (pt:tcursor txn)) (out '()))
      (when (pt:cursor-first cur)
        (loop
          (push (cons (copy-seq (pt:cursor-key cur))
                      (copy-seq (pt:cursor-value cur)))
                out)
          (unless (pt:cursor-next cur) (return))))
      (nreverse out))))

(defun pairs-equal (a b)
  "A, B are lists of (key . value); equal as ordered sequences?"
  (and (= (length a) (length b))
       (every (lambda (x y) (and (bv= (car x) (car y)) (bv= (cdr x) (cdr y))))
              a b)))

(defun check-parity (store model label)
  "Assert tget parity for every model key + a few absent keys, and that an
   ordered cursor scan equals the sorted reference."
  (let ((ref (model-sorted model)))
    ;; point-lookup parity
    (pt:with-read-txn (txn store)
      (dolist (e ref)
        (let ((got (pt:tget txn (car e))))
          (unless (and got (bv= got (cdr e)))
            (chk nil "~a: tget mismatch for a present key (len ~d)" label (length (car e)))
            (return)))))
    ;; ordered-scan parity
    (let ((scan (scan-store store)))
      (chk (pairs-equal scan ref)
           "~a: ordered scan != reference (scan ~d, ref ~d)"
           label (length scan) (length ref)))))

;;; ---------------------------------------------------------------------
;;;  Test 1 — model / random op sequence
;;; ---------------------------------------------------------------------

(defun model-test (&key (seed 12345) (ops 4000) (big-prob 8) (verbose t))
  "Random put/del/get vs reference; parity after each op and after reopen."
  (let ((*seed* (if (zerop seed) 1 seed))
        (model (make-model))
        (store (pt:open-store nil))
        (keys (make-array 0 :adjustable t :fill-pointer 0)))
    (flet ((some-key ()
             ;; reuse an existing key sometimes (to exercise replace/delete),
             ;; else mint a fresh one; occasionally a large multi-page key.
             (cond ((and (> (length keys) 0) (< (rnd 100) 60))
                    (aref keys (rnd (length keys))))
                   ((< (rnd 100) big-prob)
                    (let ((k (rand-bytes 200 1200)))
                      (vector-push-extend k keys) k))
                   (t (let ((k (rand-bytes 1 24)))
                        (vector-push-extend k keys) k))))
           (some-val ()
             (if (< (rnd 100) big-prob)
                 (rand-bytes 1500 9000)   ; force overflow + leaf splits
                 (rand-bytes 0 40))))
      (declare (ignorable #'some-key))
      (dotimes (i ops)
        (let ((op (rnd 100)))
          (cond
            ((< op 60)                    ; put
             (let ((k (some-key)) (v (some-val)))
               (pt:with-write-txn (txn store) (pt:tput txn k v))
               (model-put model k v)))
            ((< op 80)                    ; delete
             (let ((k (some-key)))
               (pt:with-write-txn (txn store) (pt:tdel txn k))
               (model-del model k)))
            (t                            ; get (parity spot-check)
             (let ((k (some-key)))
               (pt:with-read-txn (txn store)
                 (let ((got (pt:tget txn k)) (ref (model-get model k)))
                   (chk (cond ((null ref) (null got))
                              ((null got) nil)
                              (t (bv= got ref)))
                        "op ~d: point-get parity (key len ~d)" i (length k))))))))
        ;; periodic full parity + reopen check
        (when (zerop (mod (1+ i) 500))
          (check-parity store model (format nil "after ~d ops" (1+ i)))
          ;; reopen over the SAME device — must survive
          (let* ((dev (pagetree::store-device store))
                 (store2 (let ((s (pt::make-store
                                   :device dev
                                   :pager (pager:make-pager dev)
                                   :path nil)))
                           (setf (pt::store-btree s)
                                 (bt:btree-open (pt::store-pager s)))
                           s)))
            (check-parity store2 model (format nil "after reopen @ ~d ops" (1+ i)))
            (setf store store2))))
      (check-parity store model "final")
      (when verbose
        (format t "~&  model-test: ~d ops, ~d distinct keys, ~d live entries~%"
                ops (length keys) (hash-table-count (model-table model))))
      (pt:close-store store))))

;;; ---------------------------------------------------------------------
;;;  Test 2 — crash recovery (no-WAL, double-meta atomic commit)
;;; ---------------------------------------------------------------------

(defun open-over-device (dev)
  "Open a fresh store (new pager + btree) over an EXISTING device — a reopen."
  (let ((s (pt::make-store :device dev :pager (pager:make-pager dev) :path nil)))
    (setf (pt::store-btree s) (bt:btree-open (pt::store-pager s)))
    s))

(defun crash-test-one (n &key (seed 999) (committed-txns 6) (per-txn 40))
  "Build committed state, then attempt a txn that crashes at the Nth device
   write.  Reopen and assert the last committed state is intact (and the crashed
   txn left no partial state).  Returns T on pass."
  (let* ((*seed* (if (zerop seed) 1 seed))
         (dev (dev:make-mem-device))
         (store (open-over-device dev))
         (model (make-model))
         (ok t)
         (did-fault nil))
    ;; Committed keys live in the 0x00.. space; the doomed txn writes ONLY into
    ;; the disjoint 0xFF.. space, so committed keys can never be overwritten by
    ;; it.  That makes the atomicity invariant crisp:
    ;;   * every committed key keeps its committed value, ALWAYS;
    ;;   * the doomed (0xFF) keys are EITHER all present (txn committed before the
    ;;     fault point) OR all absent (txn rolled back) — never partial.
    (flet ((committed-key () (let ((k (rand-bytes 1 19)))
                               (concatenate '(simple-array (unsigned-byte 8) (*))
                                            #(#x00) k)))
           (doomed-key (j) (let ((k (rand-bytes 1 8)))
                             (concatenate '(simple-array (unsigned-byte 8) (*))
                                          (vector #xff j) k))))
      ;; --- commit several good txns ---
      (dotimes (tx committed-txns)
        (pt:with-write-txn (txn store)
          (dotimes (j per-txn)
            (let ((k (committed-key))
                  (v (if (< (rnd 100) 20) (rand-bytes 1500 6000) (rand-bytes 0 40))))
              (pt:tput txn k v)
              (model-put model k v)))))
      (let ((committed-ref (model-sorted model))
            (doomed '()))
        ;; precompute the doomed txn's keys/values so we can recognize them.
        ;; Mix big (overflow-forcing) values in so the commit writes MANY pages
        ;; — widening the window the fuzzed fault point N sweeps through.
        (dotimes (j per-txn)
          (push (cons (doomed-key j)
                      (if (evenp j) (rand-bytes 1500 5000) (rand-bytes 0 60)))
                doomed))
        (setf doomed (nreverse doomed))
        ;; --- attempt a doomed txn: arm the fault, then write ---
        (setf (dev::mem-fail-after dev) n)
        (setf (dev::mem-writes dev) 0)
        (handler-case
            (pt:with-write-txn (txn store)
              (dolist (kv doomed) (pt:tput txn (car kv) (cdr kv))))
          (error () (setf did-fault t)))   ; the injected fault — expected
        ;; --- disarm and reopen over the same device ---
        (setf (dev::mem-fail-after dev) nil)
        (let* ((store2 (open-over-device dev))
               (scan (scan-store store2))
               (rec (make-hash-table :test 'equalp)))
          (dolist (p scan) (setf (gethash (coerce (car p) 'list) rec) (cdr p)))
          ;; (1) every committed key present with its committed value
          (dolist (e committed-ref)
            (let ((rv (gethash (coerce (car e) 'list) rec)))
              (unless (and rv (bv= rv (cdr e))) (setf ok nil))))
          ;; (2) doomed keys all-or-nothing (atomic, no partial txn)
          (let ((present 0))
            (dolist (kv doomed)
              (when (gethash (coerce (car kv) 'list) rec) (incf present)))
            (unless (or (= present 0) (= present (length doomed)))
              (setf ok nil)))            ; torn txn => fail
          ;; (3) the tree is well-formed: scan strictly sorted
          (loop for (a b) on scan while b
                do (unless (bv< (car a) (car b)) (setf ok nil)))
          (pt:close-store store2))))
    (values ok did-fault)))

(defun crash-test (&key (seed 999))
  "Fuzz the fault point N across the whole write sequence."
  (let ((all t) (tested 0) (faulted 0))
    (loop for n from 1 to 160 do
      (incf tested)
      (multiple-value-bind (ok did-fault) (crash-test-one n :seed (+ seed n))
        (when did-fault (incf faulted))
        (unless ok
          (setf all nil)
          (chk nil "crash recovery failed at fault point N=~d" n))))
    (chk all "crash recovery survived all ~d fuzzed fault points" tested)
    (chk (> faulted 0) "crash recovery: faults actually fired (~d/~d points)"
         faulted tested)
    (format t "~&  crash-test: ~d/~d fault points landed mid-write~%" faulted tested)
    all))

;;; ---------------------------------------------------------------------
;;;  Extra: overflow round-trip sanity
;;; ---------------------------------------------------------------------

(defun overflow-test ()
  "Explicitly exercise multi-page values (overflow chains) and re-read."
  (let ((store (pt:open-store nil))
        (*seed* 77))
    (let ((k1 #(1 2 3)) (k2 #(9 9 9))
          (big (rand-bytes 12000 12000))   ; ~3 overflow pages
          (small #(42)))
      (pt:with-write-txn (txn store)
        (pt:tput txn k1 big)
        (pt:tput txn k2 small))
      (pt:with-read-txn (txn store)
        (chk (bv= (pt:tget txn k1) big) "overflow: big value round-trips")
        (chk (bv= (pt:tget txn k2) small) "overflow: small value alongside"))
      ;; overwrite the big value with another big one (frees + rewrites chain)
      (let ((big2 (rand-bytes 8000 8000)))
        (pt:with-write-txn (txn store) (pt:tput txn k1 big2))
        (pt:with-read-txn (txn store)
          (chk (bv= (pt:tget txn k1) big2) "overflow: big value replaced")))
      ;; delete the big value
      (pt:with-write-txn (txn store) (pt:tdel txn k1))
      (pt:with-read-txn (txn store)
        (chk (null (pt:tget txn k1)) "overflow: big value deleted")
        (chk (bv= (pt:tget txn k2) small) "overflow: neighbor intact after delete")))
    (pt:close-store store)))

;;; ---------------------------------------------------------------------
;;;  Extra: abort discards uncommitted work
;;; ---------------------------------------------------------------------

(defun abort-test ()
  (let ((store (pt:open-store nil)))
    (pt:with-write-txn (txn store) (pt:tput txn #(1) #(10)))
    ;; an explicit abort inside a write txn must discard
    (let ((txn (pt::begin-txn store :write)))
      (pt:tput txn #(2) #(20))
      (pt:abort-txn txn))
    (pt:with-read-txn (txn store)
      (chk (bv= (pt:tget txn #(1)) #(10)) "abort: committed key survives")
      (chk (null (pt:tget txn #(2))) "abort: aborted key absent"))
    ;; an unwind (non-local exit) must also abort
    (ignore-errors
     (pt:with-write-txn (txn store)
       (pt:tput txn #(3) #(30))
       (error "boom")))
    (pt:with-read-txn (txn store)
      (chk (null (pt:tget txn #(3))) "abort-on-unwind: key absent"))
    (pt:close-store store)))

;;; ---------------------------------------------------------------------
;;;  Test 3 — persistent free-page reclamation (P2)
;;; ---------------------------------------------------------------------
;;;
;;; Many rounds of (open -> insert a batch -> delete a batch -> commit -> close)
;;; over the SAME device.  Because the freelist now PERSISTS across reopen, freed
;;; pages are reused session-to-session, so under steady-state churn the device
;;; page count must stay BOUNDED — it must NOT grow roughly linearly with rounds.
;;; We assert: (a) data parity holds after every round (including after reopen),
;;; (b) the page count is bounded, and (c) the persisted free set is internally
;;; consistent (no page both free and live; no duplicates).

(defun live-pages (store)
  "The set (hash-table page-index->t) of pages reachable from the live meta:
   the tree + the live freelist chain + the meta slots."
  (let* ((bt (pagetree::store-btree store))
         (pager (pagetree::store-pager store))
         (seen (make-hash-table)))
    (setf (gethash 0 seen) t (gethash 1 seen) t)         ; meta slots
    (labels ((walk-tree (n)
               (when (and (plusp n) (not (gethash n seen)))
                 (setf (gethash n seen) t)
                 (let ((buf (pager:pager-get pager n)))
                   (case (aref buf 0)
                     (2 ; interior
                      (let ((it (bt::decode-interior buf)))
                        (loop for c across (bt::interior-children it) do (walk-tree c))))
                     (3 ; leaf — also follow its packed overflow blob chain
                      (let ((lf (bt::decode-leaf buf)))
                        (when (plusp (bt::leaf-blob-head lf))
                          (walk-overflow (bt::leaf-blob-head lf)))))))))
             (walk-overflow (n)
               (loop while (plusp n)
                     do (setf (gethash n seen) t)
                        (multiple-value-bind (next chunk) (bt::decode-overflow-chunk (pager:pager-get pager n))
                          (declare (ignore chunk))
                          (setf n next))))
             (walk-freelist (n)
               (loop while (plusp n)
                     do (setf (gethash n seen) t)
                        (multiple-value-bind (next idx) (bt::decode-freelist-chunk (pager:pager-get pager n))
                          (declare (ignore idx))
                          (setf n next)))))
      (walk-tree (bt:btree-root bt))
      (walk-freelist (bt::btree-committed-freelist-head bt)))
    seen))

(defun freelist-consistent-p (store)
  "Reopen-derived check: the persisted free set is disjoint from the live page
   set, has no duplicates, and every index is in-range.  Returns T on success."
  (let* ((bt (pagetree::store-btree store))
         (pager (pagetree::store-pager store))
         (pc (dev:dev-page-count (pagetree::store-device store)))
         (free (bt::load-freelist-chain pager (bt::btree-committed-freelist-head bt)))
         (live (live-pages store))
         (seen (make-hash-table))
         (ok t))
    (dolist (n free)
      (when (gethash n seen) (setf ok nil))      ; duplicate in freelist
      (setf (gethash n seen) t)
      (when (or (< n bt::+first-data-page+) (>= n pc)) (setf ok nil)) ; out of range
      (when (gethash n live) (setf ok nil)))     ; free AND live => corruption
    ok))

(defun churn-test (&key (rounds 60) (batch 80) (seed 4242) (verbose t))
  "Reopen-churn: dozens of rounds of insert/delete over ONE device, asserting
   data parity, a consistent persisted freelist, and BOUNDED page growth."
  (let* ((*seed* (if (zerop seed) 1 seed))
         (dev (dev:make-mem-device))
         (model (make-model))
         (live-keys (make-array 0 :adjustable t :fill-pointer 0))
         (counts '()))
    (dotimes (r rounds)
      (let ((store (open-over-device dev)))
        ;; INSERT a fresh batch of keys (mix small + overflow values)
        (pt:with-write-txn (txn store)
          (dotimes (j batch)
            (let ((k (rand-bytes 6 18))
                  (v (if (< (rnd 100) 15) (rand-bytes 1500 5000) (rand-bytes 0 40))))
              (pt:tput txn k v)
              (model-put model k v)
              (vector-push-extend k live-keys))))
        ;; DELETE a batch (drop ~ a batch's worth of existing keys, so the live
        ;; set stays roughly steady => steady-state churn).
        (pt:with-write-txn (txn store)
          (dotimes (j batch)
            (when (> (length live-keys) 0)
              (let* ((idx (rnd (length live-keys)))
                     (k (aref live-keys idx)))
                (pt:tdel txn k)
                (model-del model k)
                ;; swap-remove from live-keys
                (setf (aref live-keys idx) (aref live-keys (1- (length live-keys))))
                (decf (fill-pointer live-keys))))))
        (pt:close-store store))
      (push (dev:dev-page-count dev) counts)
      ;; reopen and verify parity + freelist consistency every few rounds
      (when (zerop (mod (1+ r) 10))
        (let ((store (open-over-device dev)))
          (check-parity store model (format nil "churn round ~d" (1+ r)))
          (chk (freelist-consistent-p store)
               "churn round ~d: persisted freelist consistent (disjoint from live, no dups)"
               (1+ r))
          (pt:close-store store))))
    (setf counts (nreverse counts))
    ;; --- BOUNDED GROWTH: page count must not grow ~linearly with rounds. ---
    ;; A leaking store would add ~constant pages PER round (file grows linearly).
    ;; With reclamation the count plateaus.  Compare the average growth across the
    ;; SECOND HALF of the run to a generous per-round threshold: with reclamation
    ;; the second-half slope is ~0; a linear leak would be many pages/round.
    (let* ((mid (floor (length counts) 2))
           (first-half-max (reduce #'max (subseq counts 0 mid)))
           (early (nth mid counts))
           (late (car (last counts)))
           (slope (/ (- late early) (max 1 (- (1- (length counts)) mid)))))
      (when verbose
        (format t "~&  churn-test: ~d rounds x ~d ins/~d del; page counts: ~a~%"
                rounds batch batch counts)
        (format t "  churn-test: first-half max=~d  second-half slope=~,3f pages/round~%"
                first-half-max slope))
      ;; (a) the device stayed bounded — total pages never exceeded a small ceiling
      ;;     proportional to the working set (NOT to the number of rounds).  With
      ;;     reclamation the whole run fits in ~ one batch's worth of pages; we use
      ;;     a generous ceiling that a linear leak (>= ~5 pages/round * 60 rounds
      ;;     = 300+) would blow straight through.
      (chk (< (car (last counts)) (* 6 batch))
           "bounded growth: final page count ~d < ~d (no linear leak across reopens)"
           (car (last counts)) (* 6 batch))
      ;; (b) steady-state: the second-half slope is essentially flat (a real leak
      ;;     would keep the slope near the per-round alloc count, several pages).
      (chk (< slope 1)
           "bounded growth: steady-state slope ~,3f pages/round < 1 (reclamation works)"
           slope))
    t))

;;; ---------------------------------------------------------------------
;;;  Test 4 — crash recovery with reopen churn (freelist round-trips)
;;; ---------------------------------------------------------------------
;;;
;;; Like crash-test, but FIRST drives several reopen+churn rounds so the store is
;;; running on a PERSISTED, reused freelist when the doomed txn crashes.  Proves
;;; the recovered meta and its freelist stay mutually consistent even when the
;;; crash lands mid-commit on top of a reclaimed free set.

(defun churn-then-crash-one (n &key (seed 555) (warmup-rounds 8) (batch 40))
  "Warm up with reopen-churn (so the freelist is persisted + reused), then attempt
   a doomed txn crashing at the Nth write.  Reopen and assert: committed state
   intact, doomed txn all-or-nothing, scan strictly sorted, AND the recovered
   freelist is consistent with the recovered meta.  Returns (values ok did-fault)."
  (let* ((*seed* (if (zerop seed) 1 seed))
         (dev (dev:make-mem-device))
         (model (make-model))
         (live-keys (make-array 0 :adjustable t :fill-pointer 0))
         (ok t) (did-fault nil))
    ;; --- warmup: reopen-churn to build a persisted, reused freelist ---
    (dotimes (r warmup-rounds)
      (let ((store (open-over-device dev)))
        (pt:with-write-txn (txn store)
          (dotimes (j batch)
            (let ((k (concatenate '(simple-array (unsigned-byte 8) (*)) #(#x00) (rand-bytes 1 12)))
                  (v (if (< (rnd 100) 20) (rand-bytes 1500 4000) (rand-bytes 0 40))))
              (pt:tput txn k v) (model-put model k v) (vector-push-extend k live-keys))))
        (pt:with-write-txn (txn store)
          (dotimes (j (floor batch 2))
            (when (> (length live-keys) 0)
              (let* ((idx (rnd (length live-keys))) (k (aref live-keys idx)))
                (pt:tdel txn k) (model-del model k)
                (setf (aref live-keys idx) (aref live-keys (1- (length live-keys))))
                (decf (fill-pointer live-keys))))))
        (pt:close-store store)))
    ;; --- the doomed txn (disjoint 0xFF key space), crashing at write N ---
    (let ((committed-ref (model-sorted model))
          (doomed '())
          (store (open-over-device dev)))
      (dotimes (j 30)
        (push (cons (concatenate '(simple-array (unsigned-byte 8) (*)) (vector #xff j) (rand-bytes 1 8))
                    (if (evenp j) (rand-bytes 1500 4000) (rand-bytes 0 60)))
              doomed))
      (setf doomed (nreverse doomed))
      (setf (dev::mem-fail-after dev) n (dev::mem-writes dev) 0)
      (handler-case
          (pt:with-write-txn (txn store)
            (dolist (kv doomed) (pt:tput txn (car kv) (cdr kv))))
        (error () (setf did-fault t)))
      (setf (dev::mem-fail-after dev) nil)
      ;; --- reopen over the same device and verify ---
      (let* ((store2 (open-over-device dev))
             (scan (scan-store store2))
             (rec (make-hash-table :test 'equalp)))
        (dolist (p scan) (setf (gethash (coerce (car p) 'list) rec) (cdr p)))
        (dolist (e committed-ref)
          (let ((rv (gethash (coerce (car e) 'list) rec)))
            (unless (and rv (bv= rv (cdr e))) (setf ok nil))))
        (let ((present 0))
          (dolist (kv doomed) (when (gethash (coerce (car kv) 'list) rec) (incf present)))
          (unless (or (= present 0) (= present (length doomed))) (setf ok nil)))
        (loop for (a b) on scan while b do (unless (bv< (car a) (car b)) (setf ok nil)))
        ;; the recovered freelist must be consistent with the recovered meta
        (unless (freelist-consistent-p store2) (setf ok nil))
        (pt:close-store store2)))
    (values ok did-fault)))

(defun churn-crash-test (&key (seed 700))
  "Fuzz the doomed-commit fault point on a freelist-active (warmed-up) store."
  (let ((all t) (faulted 0) (tested 0))
    (loop for n from 1 to 120 do
      (incf tested)
      (multiple-value-bind (ok did-fault) (churn-then-crash-one n :seed (+ seed n))
        (when did-fault (incf faulted))
        (unless ok (setf all nil) (chk nil "churn+crash recovery failed at fault N=~d" n))))
    (chk all "churn+crash: recovery survived all ~d fuzzed fault points" tested)
    (chk (> faulted 0) "churn+crash: faults actually fired (~d/~d points)" faulted tested)
    (format t "~&  churn-crash-test: ~d/~d fault points landed mid-write~%" faulted tested)
    all))

;;; ---------------------------------------------------------------------
;;;  Test 5 — on-disk compactness (packed overflow)
;;; ---------------------------------------------------------------------
;;;
;;; A UTXO-like bulk load (36-byte keys; ~95% small 30-80 B values, ~5% large
;;; 300-3000 B "script" values) over the mem device, then a walk of the LIVE
;;; tree to assert: (a) the live store is comfortably under the old one-page-per-
;;; overflow-value design's footprint, and (b) overflow is genuinely PACKED —
;;; the live overflow pages are far fewer than the number of large values (which
;;; one-page-per-value could never achieve).

(declaim (inline %sm64))
(defun %sm64 (x)
  (let* ((z (logand (+ x #x9e3779b97f4a7c15) #xffffffffffffffff)))
    (setf z (logand (* (logxor z (ash z -30)) #xbf58476d1ce4e5b9) #xffffffffffffffff))
    (setf z (logand (* (logxor z (ash z -27)) #x94d049bb133111eb) #xffffffffffffffff))
    (logxor z (ash z -31))))

(defun %utxo-key (i)
  (let ((k (make-array 36 :element-type '(unsigned-byte 8))))
    (dotimes (w 4)
      (let ((h (%sm64 (logxor i (* w #x1111111111111111)))))
        (dotimes (b 8) (setf (aref k (+ (* w 8) b)) (logand (ash h (* -8 b)) #xff)))))
    k))

(defun %utxo-val (i)
  (let* ((h (%sm64 (logxor i #x5555555555555555)))
         (largep (zerop (mod i 20)))
         (len (if largep (+ 300 (mod h 2700)) (+ 30 (mod h 50))))
         (v (make-array len :element-type '(unsigned-byte 8))))
    (dotimes (b len v) (setf (aref v b) (logand (ash (%sm64 (+ h b)) -17) #xff)))))

(defun compactness-test (&key (n 40000))
  "Bulk-load a UTXO-like dataset and assert compact, PACKED on-disk layout."
  (let* ((dev (dev:make-mem-device))
         (store (open-over-device dev))
         (large-count 0))
    (loop for base from 0 below n by 8000 do
      (pt:with-write-txn (tx store)
        (loop for i from base below (min n (+ base 8000)) do
          (when (zerop (mod i 20)) (incf large-count))
          (pt:tput tx (%utxo-key i) (%utxo-val i)))))
    (pt:close-store store)
    ;; reopen and walk the live tree
    (let* ((s (open-over-device dev))
           (bt (pagetree::store-btree s))
           (pager (pagetree::store-pager s))
           (leaves 0) (interiors 0) (ovpages 0) (ovvals 0)
           (seen (make-hash-table)))
      (labels ((walk-blob (p)
                 (loop while (plusp p) do
                   (incf ovpages)
                   (multiple-value-bind (next chunk)
                       (bt::decode-overflow-chunk (pager:pager-get pager p))
                     (declare (ignore chunk))
                     (setf p next))))
               (walk (m)
                 (when (and (plusp m) (not (gethash m seen)))
                   (setf (gethash m seen) t)
                   (let ((buf (pager:pager-get pager m)))
                     (case (aref buf 0)
                       (2 (incf interiors)
                          (let ((it (bt::decode-interior buf)))
                            (loop for c across (bt::interior-children it) do (walk c))))
                       (3 (incf leaves)
                          (let ((lf (bt::decode-leaf buf)))
                            (loop for v across (bt::leaf-vals lf)
                                  when (and (consp v) (eq (car v) :overflow)) do (incf ovvals))
                            (when (plusp (bt::leaf-blob-head lf))
                              (walk-blob (bt::leaf-blob-head lf))))))))))
        (walk (bt:btree-root bt)))
      (let* ((live (+ leaves interiors ovpages 2)) ; +2 meta slots
             (bpe (/ (* live (dev:dev-page-size dev)) (float n))))
        (format t "~&  compactness-test: ~d entries, ~d live pages ~
                   (leaf ~d, int ~d, overflow ~d for ~d large vals) => ~,1f B/entry~%"
                n live leaves interiors ovpages ovvals bpe)
        ;; (a) clearly under the old one-page-per-overflow-value footprint.  That
        ;; design alone spent >= one 4 KB page per large value PLUS the leaves; on
        ;; this workload it measured ~317 B/entry live.  We require a clear win.
        (chk (< bpe 300)
             "compactness: ~,1f B/entry live < 300 (old design ~~317)" bpe)
        ;; (b) overflow is PACKED: far fewer overflow pages than large values
        ;; (one-page-per-value would need >= OVVALS pages).
        (chk (and (> ovvals 0) (< ovpages ovvals))
             "compactness: overflow packed (~d pages for ~d large values)"
             ovpages ovvals))
      (pt:close-store s))
    t))

;;; ---------------------------------------------------------------------
;;;  Test 6 — batched apply equivalence (NEW: btree-apply-batch)
;;; ---------------------------------------------------------------------
;;;
;;; The fast sorted-bulk path (tapply-batch / btree-apply-batch) MUST produce a
;;; tree byte-identical to applying the same ops one-by-one with tput/tdel in key
;;; order — same ordered scan AND same whole-tree page digest (every live page's
;;; bytes, in a canonical pre-order walk).  We fuzz across many batches that force
;;; leaf splits, interior splits, overflow add/replace/delete, and key updates.

(defun set-digest (store)
  "An order-INDEPENDENT-of-physical-layout but order-DEPENDENT-on-key content
   digest: FNV-1a-64 folded over the ordered (key,value) stream produced by a
   cursor scan.  This is exactly the cl-consensus-style set commitment — two
   stores with the same digest hold the IDENTICAL logical KV mapping (same keys,
   same values, same order), regardless of how leaves/interiors were physically
   partitioned.  A bulk build legitimately partitions pages differently from
   incremental insertion (that is its whole point — balanced, dense leaves); the
   guarantee we require and assert is that the LOGICAL CONTENT and the read path
   are byte-identical, which is what this digest captures."
  (let ((h #xcbf29ce484222325))
    (flet ((mix (byte)
             (setf h (logand (* (logxor h byte) #x100000001b3)
                             #xffffffffffffffff))))
      (dolist (e (scan-store store) h)
        (let ((k (car e)) (v (cdr e)))
          (mix 1) (mix (logand (length k) #xff)) (mix (logand (ash (length k) -8) #xff))
          (dotimes (j (length k)) (mix (aref k j)))
          (mix 2) (mix (logand (length v) #xff)) (mix (logand (ash (length v) -8) #xff))
          (dotimes (j (length v)) (mix (aref v j))))))))

(defun tree-wellformed-p (store)
  "Structural validity of the live tree: a cursor scan is strictly key-sorted,
   every leaf/interior page is correctly typed, no page is visited twice (no
   cycles / aliasing), and every overflow value reassembles to its declared
   length.  Returns T iff well-formed."
  (let* ((bt (pagetree::store-btree store))
         (pager (pagetree::store-pager store))
         (seen (make-hash-table))
         (ok t))
    (labels ((walk (n)
               (when (plusp n)
                 (when (gethash n seen) (setf ok nil) (return-from walk))
                 (setf (gethash n seen) t)
                 (let ((buf (pager:pager-get pager n)))
                   (case (aref buf 0)
                     (2 (let ((it (bt::decode-interior buf)))
                          (unless (= (length (bt::interior-children it))
                                     (1+ (length (bt::interior-keys it))))
                            (setf ok nil))
                          (loop for c across (bt::interior-children it) do (walk c))))
                     (3 (let ((lf (bt::decode-leaf buf)))
                          ;; overflow values must reassemble to the declared length
                          (dotimes (i (length (bt::leaf-vals lf)))
                            (let ((v (aref (bt::leaf-vals lf) i)))
                              (when (and (consp v) (eq (car v) :overflow))
                                (let ((bytes (bt::read-blob-slice
                                              bt (bt::leaf-blob-head lf)
                                              (aref (bt::leaf-ovpgs lf) i) (cdr v))))
                                  (unless (= (length bytes) (cdr v)) (setf ok nil))))))))
                     (t (setf ok nil)))))))
      (walk (bt:btree-root bt)))
    ;; strictly sorted scan
    (let ((scan (scan-store store)))
      (loop for (a b) on scan while b
            do (unless (bv< (car a) (car b)) (setf ok nil))))
    ok))

(defun apply-ops-per-key (store ops)
  "Apply OPS (list of (key . val|:delete)) one-by-one via tput/tdel in one txn."
  (pt:with-write-txn (txn store)
    (dolist (op ops)
      (if (eq (cdr op) :delete)
          (pt:tdel txn (car op))
          (pt:tput txn (car op) (cdr op))))))

(defun apply-ops-batch (store ops)
  "Apply OPS in one tapply-batch call (it sorts + coalesces) in one txn."
  (pt:with-write-txn (txn store)
    (pagetree::tapply-batch txn ops)))

(defun batch-equiv-one (&key (seed 1) (rounds 12) (batch 120) (big-prob 12))
  "Drive the SAME random op sequence through the per-key path and the batched
   path over two fresh stores; after EACH round assert identical ordered scan AND
   identical whole-tree digest.  Mixes large (overflow) values, key replacement,
   and deletes so splits/merges/overflow all get exercised."
  (let ((*seed* (if (zerop seed) 1 seed))
        (s-key (pt:open-store nil))   ; per-key reference store
        (s-bat (pt:open-store nil))   ; batched store
        (keys (make-array 0 :adjustable t :fill-pointer 0))
        (ok t))
    (flet ((some-key (allow-new)
             (cond ((and (> (length keys) 0) (< (rnd 100) 50))
                    (aref keys (rnd (length keys))))
                   ((and allow-new (< (rnd 100) big-prob))
                    (let ((k (rand-bytes 200 1100))) (vector-push-extend k keys) k))
                   (allow-new (let ((k (rand-bytes 1 30))) (vector-push-extend k keys) k))
                   ((> (length keys) 0) (aref keys (rnd (length keys))))
                   (t (let ((k (rand-bytes 1 30))) (vector-push-extend k keys) k))))
           (some-val ()
             (if (< (rnd 100) big-prob) (rand-bytes 1400 7000) (rand-bytes 0 50))))
      (dotimes (r rounds)
        ;; build a batch of ops with UNIQUE keys within the round (so per-key
        ;; application order can't disagree with the batch's last-write-wins;
        ;; the batch path also coalesces, but unique keys make the oracle crisp).
        (let ((ops '()) (used (make-hash-table :test 'equalp)))
          (dotimes (b batch)
            (let* ((del (< (rnd 100) 25))
                   (k (some-key (not del))))
              (unless (gethash (coerce k 'list) used)
                (setf (gethash (coerce k 'list) used) t)
                (push (cons k (if del :delete (some-val))) ops))))
          (setf ops (nreverse ops))
          (apply-ops-per-key s-key ops)
          (apply-ops-batch   s-bat ops))
        ;; compare after each round: identical ordered scan, identical set digest,
        ;; and the batched tree is structurally well-formed.
        (let ((sk (scan-store s-key)) (sb (scan-store s-bat)))
          (unless (pairs-equal sk sb) (setf ok nil)))
        (unless (= (set-digest s-key) (set-digest s-bat)) (setf ok nil))
        (unless (tree-wellformed-p s-bat) (setf ok nil)))
      (pt:close-store s-key)
      (pt:close-store s-bat)
      ok)))

(defun batch-equiv-test ()
  "Fuzz batched-apply equivalence across several seeds + a big single batch."
  (let ((all t))
    (dolist (seed '(1 7 42 1234 99999))
      (unless (batch-equiv-one :seed seed :rounds 14 :batch 140)
        (setf all nil)
        (chk nil "batch-apply equivalence failed (seed ~d)" seed)))
    ;; one large single-shot batch from empty (forces deep multi-level build)
    (let ((*seed* 555)
          (s-key (pt:open-store nil))
          (s-bat (pt:open-store nil))
          (ops '()))
      (dotimes (i 3000)
        (push (cons (rand-bytes 8 36)
                    (if (zerop (mod i 17)) (rand-bytes 1500 6000) (rand-bytes 0 60)))
              ops))
      ;; throw in deletes of some keys present in the same batch (coalesce path)
      (apply-ops-per-key s-key ops)
      (apply-ops-batch   s-bat ops)
      (unless (and (pairs-equal (scan-store s-key) (scan-store s-bat))
                   (= (set-digest s-key) (set-digest s-bat))
                   (tree-wellformed-p s-bat))
        (setf all nil)
        (chk nil "batch-apply equivalence failed (large single batch)"))
      (pt:close-store s-key) (pt:close-store s-bat))
    (chk all "batch-apply: tree byte-identical to per-key path across all fuzz cases")
    ;; an explicit overflow + delete + replace equivalence spot-check
    (let ((s-key (pt:open-store nil)) (s-bat (pt:open-store nil)) (*seed* 31337))
      (let ((ops (list (cons #(1 2 3) (rand-bytes 9000 9000))     ; multi-page overflow
                       (cons #(1 2 4) #(7))                        ; tiny inline
                       (cons #(0 0 1) (rand-bytes 4000 4000))      ; overflow
                       (cons #(5) #(9 9 9)))))
        (apply-ops-per-key s-key ops) (apply-ops-batch s-bat ops)
        ;; now replace one overflow with inline, delete another, in a second batch
        (let ((ops2 (list (cons #(1 2 3) #(1))                     ; overflow -> inline
                          (cons #(0 0 1) :delete)                  ; delete overflow
                          (cons #(2 2 2) (rand-bytes 5000 5000))))) ; new overflow
          (apply-ops-per-key s-key ops2) (apply-ops-batch s-bat ops2)))
      (chk (and (pairs-equal (scan-store s-key) (scan-store s-bat))
                (= (set-digest s-key) (set-digest s-bat))
                (tree-wellformed-p s-bat))
           "batch-apply: overflow add/replace/delete equivalent to per-key")
      (pt:close-store s-key) (pt:close-store s-bat))
    ;; --- crash-atomicity of a batch commit over a mem device ---
    ;; A batched txn that dies mid-commit must leave the LAST committed state
    ;; intact (no partial batch), proving the batch path preserves the no-WAL
    ;; double-meta commit discipline.  We fuzz the fault point.
    (let ((*seed* 24680) (atomic-ok t) (faulted 0))
      (loop for n from 1 to 80 do
        (let* ((dev (dev:make-mem-device))
               (store (open-over-device dev))
               (model (make-model)))
          ;; commit a clean batch as the "last committed state"
          (let ((committed '()))
            (dotimes (j 200)
              (push (cons (concatenate '(simple-array (unsigned-byte 8) (*)) #(#x00) (rand-bytes 1 18))
                          (if (< (rnd 100) 20) (rand-bytes 1500 5000) (rand-bytes 0 50)))
                    committed))
            (pt:with-write-txn (txn store)
              (pagetree::tapply-batch txn committed))
            (dolist (kv committed) (model-put model (car kv) (cdr kv))))
          (let ((committed-ref (model-sorted model))
                (doomed '()))
            (dotimes (j 200)
              (push (cons (concatenate '(simple-array (unsigned-byte 8) (*)) (vector #xff) (rand-bytes 1 18))
                          (if (evenp j) (rand-bytes 1500 5000) (rand-bytes 0 60)))
                    doomed))
            ;; arm the fault, attempt a doomed batch
            (setf (dev::mem-fail-after dev) n (dev::mem-writes dev) 0)
            (handler-case
                (pt:with-write-txn (txn store)
                  (pagetree::tapply-batch txn doomed))
              (error () (incf faulted)))
            (setf (dev::mem-fail-after dev) nil)
            ;; reopen and verify last committed state intact + doomed all-or-nothing
            (let* ((s2 (open-over-device dev))
                   (scan (scan-store s2))
                   (rec (make-hash-table :test 'equalp)))
              (dolist (p scan) (setf (gethash (coerce (car p) 'list) rec) (cdr p)))
              (dolist (e committed-ref)
                (let ((rv (gethash (coerce (car e) 'list) rec)))
                  (unless (and rv (bv= rv (cdr e))) (setf atomic-ok nil))))
              (let ((present 0))
                (dolist (kv doomed) (when (gethash (coerce (car kv) 'list) rec) (incf present)))
                (unless (or (= present 0) (= present (length doomed))) (setf atomic-ok nil)))
              (loop for (a b) on scan while b do (unless (bv< (car a) (car b)) (setf atomic-ok nil)))
              (pt:close-store s2)))))
      (chk atomic-ok "batch-apply: crash mid-commit preserves last committed state (no partial batch)")
      (chk (> faulted 0) "batch-apply: crash faults actually fired (~d/80 points)" faulted)
      (unless atomic-ok (setf all nil)))
    all))

;;; ---------------------------------------------------------------------
;;;  Test 7 — bulk-build equivalence (NEW: tbulk-build / btree-bulk-build)
;;; ---------------------------------------------------------------------
;;;
;;; The bottom-up bulk loader MUST produce a tree holding the IDENTICAL logical
;;; KV mapping as inserting the same entries one-by-one with tput in key order —
;;; same ordered scan AND same set-digest (the cl-consensus-style ordered content
;;; commitment).  The PHYSICAL page partition legitimately differs (denser leaves;
;;; that is the whole point), so we assert logical/read-path equivalence + tree
;;; well-formedness, and that the bulk-built tree SURVIVES A REOPEN (proving the
;;; build commits durably through the normal no-WAL double-meta path).

(defun apply-ops-bulk (store ops)
  "Bulk-build STORE (must be empty) from OPS (list of (key . val)) in one txn."
  (pt:with-write-txn (txn store)
    (pagetree::tbulk-build txn ops)))

(defun bulk-equiv-one (&key (seed 1) (n 4000) (big-prob 10))
  "Build the SAME unique-key dataset two ways — per-key tput vs bulk-build — over
   fresh stores; assert identical ordered scan + set digest, that the bulk tree is
   well-formed, and that it survives a reopen over its own device."
  (let ((*seed* (if (zerop seed) 1 seed))
        (s-key (pt:open-store nil))
        (s-bulk (pt:open-store nil))
        (used (make-hash-table :test 'equalp))
        (ops '())
        (ok t))
    (flet ((some-val ()
             (if (< (rnd 100) big-prob) (rand-bytes 1400 7000) (rand-bytes 0 50))))
      (dotimes (i n)
        (let ((k (if (< (rnd 100) big-prob) (rand-bytes 200 1100) (rand-bytes 1 30))))
          (unless (gethash (coerce k 'list) used)
            (setf (gethash (coerce k 'list) used) t)
            (push (cons k (some-val)) ops))))
      (setf ops (nreverse ops))
      (apply-ops-per-key s-key ops)
      (apply-ops-bulk    s-bulk ops)
      (let ((ref-scan (scan-store s-key))
            (ref-dig (set-digest s-key))
            (dev (pagetree::store-device s-bulk)))
        (unless (pairs-equal (scan-store s-bulk) ref-scan) (setf ok nil))
        (unless (= (set-digest s-bulk) ref-dig) (setf ok nil))
        (unless (tree-wellformed-p s-bulk) (setf ok nil))
        ;; reopen the bulk store over the same device — the build must be durable.
        (pt:close-store s-bulk)
        (let ((s2 (open-over-device dev)))
          (unless (pairs-equal (scan-store s2) ref-scan) (setf ok nil))
          (unless (= (set-digest s2) ref-dig) (setf ok nil))
          (unless (tree-wellformed-p s2) (setf ok nil))
          (pt:close-store s2)))
      (pt:close-store s-key)
      ok)))

(defun bulk-equiv-test ()
  "Fuzz bulk-build equivalence across seeds, plus a UTXO-like load and edge cases."
  (let ((all t))
    (dolist (seed '(1 7 42 1234 99999))
      (unless (bulk-equiv-one :seed seed :n 4000)
        (setf all nil) (chk nil "bulk-build equivalence failed (seed ~d)" seed)))
    ;; UTXO-like: 36-byte keys, ~5% large "script" values — the real workload the
    ;; loader exists for.  Unique keys by construction.
    (let ((s-key (pt:open-store nil)) (s-bulk (pt:open-store nil))
          (ops '()) (m (make-hash-table :test 'equalp)))
      (dotimes (i 20000)
        (let ((k (%utxo-key i)))
          (unless (gethash (coerce k 'list) m)
            (setf (gethash (coerce k 'list) m) t)
            (push (cons k (%utxo-val i)) ops))))
      (apply-ops-per-key s-key ops)
      (apply-ops-bulk    s-bulk ops)
      (unless (and (pairs-equal (scan-store s-key) (scan-store s-bulk))
                   (= (set-digest s-key) (set-digest s-bulk))
                   (tree-wellformed-p s-bulk))
        (setf all nil) (chk nil "bulk-build equivalence failed (UTXO-like 20k)"))
      (pt:close-store s-key) (pt:close-store s-bulk))
    ;; edge: empty input => empty tree
    (let ((s (pt:open-store nil)))
      (apply-ops-bulk s '())
      (chk (null (scan-store s)) "bulk-build: empty input => empty tree")
      (pt:close-store s))
    ;; edge: singleton input
    (let ((s-key (pt:open-store nil)) (s-bulk (pt:open-store nil))
          (ops (list (cons #(5 5) #(1 2 3)))))
      (apply-ops-per-key s-key ops) (apply-ops-bulk s-bulk ops)
      (chk (and (pairs-equal (scan-store s-key) (scan-store s-bulk))
                (tree-wellformed-p s-bulk))
           "bulk-build: singleton input equivalent to per-key")
      (pt:close-store s-key) (pt:close-store s-bulk))
    ;; overflow-heavy build (forces packed overflow chains under the bulk path)
    (let ((s-key (pt:open-store nil)) (s-bulk (pt:open-store nil))
          (*seed* 8181) (raw '()) (m (make-hash-table :test 'equalp)) (ops '()))
      (dotimes (i 600)
        (push (cons (rand-bytes 8 36)
                    (if (evenp i) (rand-bytes 3000 9000) (rand-bytes 0 40)))
              raw))
      (dolist (op (nreverse raw))
        (unless (gethash (coerce (car op) 'list) m)
          (setf (gethash (coerce (car op) 'list) m) t)
          (push op ops)))
      (apply-ops-per-key s-key ops) (apply-ops-bulk s-bulk ops)
      (chk (and (pairs-equal (scan-store s-key) (scan-store s-bulk))
                (= (set-digest s-key) (set-digest s-bulk))
                (tree-wellformed-p s-bulk))
           "bulk-build: overflow-heavy build equivalent to per-key")
      (pt:close-store s-key) (pt:close-store s-bulk))
    ;; unsorted + duplicate-key input: tbulk-build sorts + coalesces (last wins),
    ;; so it must match a per-key apply of the SAME ops in input order.
    (let ((s-key (pt:open-store nil)) (s-bulk (pt:open-store nil)) (*seed* 4711)
          (ops '()))
      (dotimes (i 1500)
        (push (cons (rand-bytes 4 20)
                    (if (zerop (mod i 13)) (rand-bytes 1500 5000) (rand-bytes 0 40)))
              ops))
      ;; deliberately leave duplicates AND unsorted order in OPS.
      (apply-ops-per-key s-key ops)      ; last write wins, applied in order
      (apply-ops-bulk    s-bulk ops)     ; sorts + coalesces last-wins internally
      (chk (and (pairs-equal (scan-store s-key) (scan-store s-bulk))
                (= (set-digest s-key) (set-digest s-bulk))
                (tree-wellformed-p s-bulk))
           "bulk-build: unsorted+duplicate input sorts/coalesces like per-key")
      (pt:close-store s-key) (pt:close-store s-bulk))
    (chk all "bulk-build: tree logically identical to per-key path across fuzz cases")
    all))

;;; ---------------------------------------------------------------------
;;;  Runner
;;; ---------------------------------------------------------------------

(defun run-tests ()
  (let ((*fails* 0) (*checks* 0))
    (format t "~&== pagetree differential oracle ==~%")
    (format t "~&[overflow round-trip]~%")     (overflow-test)
    (format t "~&[abort semantics]~%")          (abort-test)
    (format t "~&[model: random ops vs reference + reopen]~%")
    (model-test :seed 12345 :ops 4000)
    (model-test :seed 24681 :ops 4000)
    (format t "~&[crash recovery: fuzzed fault points]~%")
    (crash-test :seed 1000)
    (format t "~&[persistent freelist: reopen-churn bounded growth]~%")
    (churn-test :seed 4242)
    (format t "~&[crash recovery on a reused persisted freelist]~%")
    (churn-crash-test :seed 700)
    (format t "~&[compactness: UTXO-like bulk load, packed overflow]~%")
    (compactness-test)
    (format t "~&[batch-apply: tree byte-identical to per-key path]~%")
    (batch-equiv-test)
    (format t "~&[bulk-build: bottom-up loader logically identical to per-key path]~%")
    (bulk-equiv-test)
    (format t "~&----------------------------------~%")
    (format t "~&checks: ~d   failures: ~d   => ~:[FAIL~;PASS~]~%"
            *checks* *fails* (zerop *fails*))
    (zerop *fails*)))
