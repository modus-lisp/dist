;;;; bench/bench.lisp — pagetree UTXO-workload benchmark harness.
;;;;
;;;; Standalone.  Load AFTER the system:
;;;;
;;;;     (require :asdf)
;;;;     (asdf:load-system "pagetree")
;;;;     (load "bench/bench.lisp")
;;;;     (bench:run-bench)                       ; full sweep, default sizing
;;;;     (bench:run-bench :n 2000000)            ; pick the dataset size
;;;;     (bench:run-bench :page-sizes '(4096)
;;;;                      :cache-mbs '(256 512)) ; restrict the sweep
;;;;
;;;; Uses ONLY the public pagetree API (open-store / with-write-txn /
;;;; with-read-txn / tput / tget / tdel / tcursor ...), plus the two sizing
;;;; readers we were told are fair game: pagetree.device:dev-page-count and
;;;; pagetree.device:dev-page-size.  It does NOT touch library internals and
;;;; does NOT modify any src file.
;;;;
;;;; Models the cl-consensus UTXO workload:
;;;;   keys  = 36-byte outpoints (32-byte txid || 4-byte index), well distributed
;;;;           (a splitmix64 hash of a counter spread across all 36 bytes — UTXO
;;;;           keys are effectively random, NOT sequential).
;;;;   vals  = small "coin" blobs ~30-80 bytes, with ~5% large values (a few
;;;;           hundred B .. a few KB) to exercise overflow pages (big scripts).
;;;;   txns  = batched per-block checkpoints (~8k ops per write-txn).
;;;;
;;;; RSS is read from /proc/self/status (Linux only).  This is the harness, not
;;;; the library — the one platform-specific read is fenced here and degrades to
;;;; NIL off Linux.

(defpackage #:bench
  (:use #:cl #:pagetree)            ; pull in the public KV API symbols
  (:export #:run-bench))

(in-package #:bench)

;;; ----------------------------------------------------------------------
;;;  Deterministic, well-distributed key + value generation
;;; ----------------------------------------------------------------------

(declaim (inline splitmix64))
(defun splitmix64 (x)
  "One step of splitmix64: a good integer hash (x -> 64-bit avalanche)."
  (let* ((z (logand (+ x #x9e3779b97f4a7c15) #xffffffffffffffff)))
    (setf z (logand (* (logxor z (ash z -30)) #xbf58476d1ce4e5b9) #xffffffffffffffff))
    (setf z (logand (* (logxor z (ash z -27)) #x94d049bb133111eb) #xffffffffffffffff))
    (logxor z (ash z -31))))

(defun make-key (i)
  "A 36-byte outpoint for counter I.  Four splitmix64 words (i, i+1, i+2, i+3
   salted) fill 32 bytes of txid; the last 4 bytes are an index derived from I.
   Well-distributed across the whole keyspace — adjacent I land far apart."
  (declare (type (unsigned-byte 62) i))
  (let ((k (make-array 36 :element-type '(unsigned-byte 8)))
        (h0 (splitmix64 i))
        (h1 (splitmix64 (logxor i #x1111111111111111)))
        (h2 (splitmix64 (logxor i #x2222222222222222)))
        (h3 (splitmix64 (logxor i #x3333333333333333))))
    (macrolet ((spill (word base)
                 `(dotimes (b 8)
                    (setf (aref k (+ ,base b)) (logand (ash ,word (* -8 b)) #xff)))))
      (spill h0 0) (spill h1 8) (spill h2 16) (spill h3 24))
    ;; 4-byte output index: a small spread value
    (let ((idx (logand (splitmix64 (logxor i #x4444444444444444)) #xffff)))
      (setf (aref k 32) (logand idx #xff)
            (aref k 33) (logand (ash idx -8) #xff)
            (aref k 34) 0
            (aref k 35) 0))
    k))

(defparameter *small-min* 30)
(defparameter *small-max* 80)
(defparameter *large-frac-num* 1)   ; 1/20 = 5% large values
(defparameter *large-frac-den* 20)
(defparameter *large-min* 300)
(defparameter *large-max* 3000)

(defun make-val (i)
  "A coin blob for counter I.  ~95% small (30-80 B), ~5% large (300 B .. 3 KB,
   forcing overflow pages).  Length and contents are a deterministic function of
   I so a later read can be checked if desired."
  (declare (type (unsigned-byte 62) i))
  (let* ((h (splitmix64 (logxor i #x5555555555555555)))
         (largep (zerop (mod i *large-frac-den*)))
         (len (if largep
                  (+ *large-min* (mod h (- *large-max* *large-min*)))
                  (+ *small-min* (mod h (- *small-max* *small-min*)))))
         (v (make-array len :element-type '(unsigned-byte 8)))
         (seed h))
    (dotimes (b len)
      (setf seed (logand (+ (* seed 6364136223846793005) 1442695040888963407)
                         #xffffffffffffffff))
      (setf (aref v b) (logand (ash seed -33) #xff)))
    v))

;;; ----------------------------------------------------------------------
;;;  RSS / timing helpers
;;; ----------------------------------------------------------------------

(defun rss-bytes ()
  "Resident set size of this process in bytes, or NIL if unavailable.
   Linux-only read of /proc/self/status VmRSS — fenced to the harness."
  (ignore-errors
    (with-open-file (s "/proc/self/status" :direction :input
                                           :if-does-not-exist nil)
      (when s
        (loop for line = (read-line s nil nil)
              while line do
              (when (and (> (length line) 6)
                         (string= "VmRSS:" line :end2 6))
                ;; "VmRSS:   123456 kB"
                (let* ((p (position-if #'digit-char-p line))
                       (q (and p (position-if-not #'digit-char-p line :start p))))
                  (return (* 1024 (parse-integer line :start p :end q))))))))))

(defun now () (get-internal-real-time))
(defun secs (t0 t1) (/ (float (- t1 t0) 1d0) internal-time-units-per-second))

(defun fmt-bytes (n)
  (cond ((null n) "   n/a")
        ((>= n (* 1024 1024 1024)) (format nil "~,2f GB" (/ n 1073741824d0)))
        ((>= n (* 1024 1024))      (format nil "~,1f MB" (/ n 1048576d0)))
        ((>= n 1024)               (format nil "~,1f KB" (/ n 1024d0)))
        (t (format nil "~d B" n))))

;;; ----------------------------------------------------------------------
;;;  Workload phases
;;; ----------------------------------------------------------------------

(defparameter *batch* 8000 "ops per write-txn (per-block checkpoint)")

(defun phase-bulk-insert (store n)
  "Insert keys 0..N-1 in batched write-txns.  Returns (values seconds ops/sec)."
  (let ((t0 (now)))
    (loop for base from 0 below n by *batch* do
      (let ((hi (min n (+ base *batch*))))
        (with-write-txn (tx store)
          (loop for i from base below hi do
            (tput tx (make-key i) (make-val i))))))
    (let ((dt (secs t0 (now))))
      (values dt (/ n dt)))))

(defun phase-point-lookups (store n samples &key (offset 0) (seed 12345))
  "SAMPLES random point lookups over keys 0..N-1 (a fresh read-txn each, as a
   spend check would be).  OFFSET shifts which keys we draw (to dodge any warm
   cache from insertion order).  Returns (values seconds ops/sec hits)."
  (declare (ignore offset))
  (let ((hits 0) (rng seed) (t0 (now)))
    (with-read-txn (tx store)
      (dotimes (s samples)
        (setf rng (splitmix64 rng))
        (let ((i (mod rng n)))
          (when (tget tx (make-key i)) (incf hits)))))
    (let ((dt (secs t0 (now))))
      (values dt (/ samples dt) hits))))

(defun phase-mixed-churn (store n ops &key (seed 999))
  "Interleave inserts (new keys >= N) and deletes (existing keys < N) in batched
   write-txns — the UTXO create/spend churn.  Returns (values seconds ops/sec)."
  (let ((rng seed) (next n) (t0 (now)) (done 0))
    (loop while (< done ops) do
      (with-write-txn (tx store)
        (dotimes (b *batch*)
          (when (>= done ops) (return))
          (setf rng (splitmix64 rng))
          (if (evenp rng)
              ;; spend: delete an existing key
              (tdel tx (make-key (mod (ash rng -1) n)))
              ;; create: insert a fresh key
              (progn (tput tx (make-key next) (make-val next)) (incf next)))
          (incf done))))
    (let ((dt (secs t0 (now))))
      (values dt (/ ops dt)))))

;;; ----------------------------------------------------------------------
;;;  Disk-safety budget
;;;
;;;  The host root fs is tight (a few GB free), and a prior unbounded sweep
;;;  filled it: a single 1M-entry store at a 16 KB page size is ~1 GB, and the
;;;  churn phase grows it further (it inserts fresh keys beyond N).  So we:
;;;
;;;    * keep every single store under *MAX-STORE-BYTES* (default ~1 GB) by
;;;      ESTIMATING its on-disk size up front and SCALING N DOWN for that cell
;;;      (or skipping it if even a tiny N would not fit);
;;;    * delete each cell's temp file the instant the cell finishes AND on error
;;;      (run-one already wraps the store in unwind-protect; the budget keeps the
;;;      live file small in the first place);
;;;    * allow the temp dir to be relocated (e.g. to a roomier mount) via
;;;      *BENCH-TMPDIR*.
;;;
;;;  The estimate is deliberately conservative (it OVER-counts) so a full sweep
;;;  completes on a host with only a few GB free.
;;; ----------------------------------------------------------------------

(defparameter *max-store-bytes* (* 1024 1024 1024)
  "Hard cap on any single temp store's on-disk size.  N is scaled down per cell
   so the estimated store (incl. churn growth) stays under this.")

(defparameter *bench-tmpdir* "/tmp/"
  "Directory for temp store files.  Point it at a roomier mount if /tmp is tight.
   Must end in a path separator.")

(defparameter *min-n* 50000
  "Don't bother running a cell whose disk budget forces N below this.")

(defun est-bytes-per-entry (page-size)
  "A CONSERVATIVE (over-)estimate of FINAL on-disk bytes per requested entry for
   PAGE-SIZE, INCLUDING churn growth (the churn phase inserts fresh keys beyond N
   and frees pages that are not compacted back, so the file ends bigger than the
   pure build).  Bigger pages waste far more on leaf-fill slack, so this grows
   steeply with page size.  Calibrated ABOVE the measured post-churn disk/N
   (4 KB measured ~426 -> est 600; 16 KB measured ~1703 -> est 2200) so the cap
   is never blown by an under-estimate."
  (+ 200d0 (* 0.122d0 page-size)))   ; 4096->~700, 8192->~1199, 16384->~2199

(defun est-store-bytes (n page-size)
  "Estimated peak on-disk size for N requested entries at PAGE-SIZE.  est-bytes-
   per-entry already folds in churn growth, so we just multiply, round UP to
   whole pages, and pad 10% headroom."
  (let* ((raw   (* n (est-bytes-per-entry page-size)))
         (pages (ceiling raw page-size)))
    (round (* 1.10d0 pages page-size))))

(defun fit-n (requested-n page-size &optional (budget *max-store-bytes*))
  "Largest N <= REQUESTED-N whose estimated store fits in BUDGET at PAGE-SIZE.
   Returns NIL if even *MIN-N* would not fit (caller should skip the cell)."
  (if (<= (est-store-bytes requested-n page-size) budget)
      requested-n
      ;; Invert the estimate: budget ~= 1.10 * n * bpe  =>  n ~= budget/(1.10*bpe).
      ;; Then trim downward 10% at a time until the (page-rounded, padded)
      ;; estimate truly fits.
      (let* ((bpe   (est-bytes-per-entry page-size))
             (guess (max 0 (floor (/ budget (* 1.10d0 bpe))))))
        (loop for nn = guess then (floor (* nn 9) 10)   ; back off 10% at a time
              while (>= nn *min-n*)
              when (<= (est-store-bytes nn page-size) budget)
                do (return nn)
              finally (return nil)))))

;;; ----------------------------------------------------------------------
;;;  One (page-size, cache-bytes) run
;;; ----------------------------------------------------------------------

(defstruct result
  page-size cache-mb n
  ins-ops lk-warm-ops lk-warm-us lk-cold-ops lk-cold-us
  churn-ops pages disk-bytes bytes-per-entry rss)

(defun tmp-path (page-size cache-mb)
  (format nil "~apagetree-bench-ps~d-c~d-~d.pt"
          *bench-tmpdir* page-size cache-mb (random 1000000)))

(defun run-one (n page-size cache-mb &key (lookups 200000))
  "Run the full workload for one (page-size, cache-bytes) point.  Builds a
   file-backed store, drives the phases, collects numbers, deletes the file.
   The temp file is deleted on normal completion AND on any error (unwind-protect)."
  (let* ((path (tmp-path page-size cache-mb))
         (cache-bytes (* cache-mb 1024 1024))
         (r (make-result :page-size page-size :cache-mb cache-mb :n n)))
    (ignore-errors (delete-file path))
    (unwind-protect
         (let ((store (open-store path :page-size page-size
                                       :cache-bytes cache-bytes :create t)))
           (unwind-protect
                (progn
                  ;; --- bulk insert ---
                  (multiple-value-bind (dt ops) (phase-bulk-insert store n)
                    (declare (ignore dt))
                    (setf (result-ins-ops r) ops))
                  (setf (result-rss r) (rss-bytes))

                  ;; --- warm point lookups (cache hot from the just-finished build) ---
                  (multiple-value-bind (dt ops hits) (phase-point-lookups store n lookups :seed 7)
                    (declare (ignore dt hits))
                    (setf (result-lk-warm-ops r) ops
                          (result-lk-warm-us r) (/ 1d6 ops)))

                  ;; --- cold-ish point lookups: drop the store object and reopen
                  ;;     with the SAME small cache, so the working set (whole tree
                  ;;     on disk) far exceeds cache and most gets miss the cache.
                  (close-store store)
                  (setf store (open-store path :page-size page-size
                                               :cache-bytes cache-bytes))
                  (multiple-value-bind (dt ops hits) (phase-point-lookups store n lookups :seed 4242)
                    (declare (ignore dt hits))
                    (setf (result-lk-cold-ops r) ops
                          (result-lk-cold-us r) (/ 1d6 ops)))

                  ;; --- mixed churn ---
                  (multiple-value-bind (dt ops)
                      (phase-mixed-churn store n (max 200000 (floor n 4)))
                    (declare (ignore dt))
                    (setf (result-churn-ops r) ops))

                  ;; --- on-disk sizing ---
                  (close-store store)
                  (setf store (open-store path :page-size page-size :cache-bytes cache-bytes))
                  (let* ((dev (pagetree::store-device store))
                         (pc (pagetree.device:dev-page-count dev))
                         (ps (pagetree.device:dev-page-size dev)))
                    (setf (result-pages r) pc
                          (result-disk-bytes r) (* pc ps)
                          (result-bytes-per-entry r) (/ (* pc ps) (float n 1d0))))
                  r)
             (ignore-errors (close-store store))))
      (ignore-errors (delete-file path)))))

;;; ----------------------------------------------------------------------
;;;  Reporting
;;; ----------------------------------------------------------------------

(defun print-header (n)
  (format t "~&~%==== pagetree UTXO-workload benchmark ====~%")
  (format t "entries(req)=~:d  batch(per-txn)=~:d  vals=~d-~dB (~d% large ~d-~dB)~%"
          n *batch* *small-min* *small-max*
          (round (* 100 (/ *large-frac-num* *large-frac-den*))) *large-min* *large-max*)
  (format t "keys=36B outpoints (splitmix64-spread)  device=file (~a)~%"
          *bench-tmpdir*)
  (format t "disk cap/store=~a  (N scaled down per cell to fit)~%~%"
          (fmt-bytes *max-store-bytes*))
  (format t "~5@a ~6@a ~9@a | ~10@a | ~10@a ~8@a | ~10@a ~8@a | ~10@a | ~7@a ~10@a | ~9@a~%"
          "ps" "cache" "N" "insert" "lk-warm" "us/op" "lk-cold" "us/op"
          "churn" "B/entry" "disk" "RSS")
  (format t "~5@a ~6@a ~9@a | ~10@a | ~10@a ~8@a | ~10@a ~8@a | ~10@a | ~7@a ~10@a | ~9@a~%"
          "" "(MB)" "" "ops/s" "ops/s" "" "ops/s" "" "ops/s" "" "" "")
  (format t "~a~%" (make-string 128 :initial-element #\-)))

(defun print-result (r)
  (format t "~5d ~6d ~9:d | ~10:d | ~10:d ~8,2f | ~10:d ~8,2f | ~10:d | ~7,1f ~10a | ~9a~%"
          (result-page-size r) (result-cache-mb r) (result-n r)
          (round (result-ins-ops r))
          (round (result-lk-warm-ops r)) (result-lk-warm-us r)
          (round (result-lk-cold-ops r)) (result-lk-cold-us r)
          (round (result-churn-ops r))
          (result-bytes-per-entry r)
          (fmt-bytes (result-disk-bytes r))
          (fmt-bytes (result-rss r))))

;;; ----------------------------------------------------------------------
;;;  Entry point
;;; ----------------------------------------------------------------------

(defun run-bench (&key (n 2000000)
                       (page-sizes '(4096 8192 16384))
                       (cache-mbs '(256 512))
                       (lookups 200000))
  "Run the full sweep over PAGE-SIZES x CACHE-MBS at N entries.  Prints a results
   table and returns the list of RESULT structs."
  (print-header n)
  (let ((results '()))
    (dolist (ps page-sizes)
      (dolist (cmb cache-mbs)
        ;; Disk safety: clamp this cell's N so the temp store stays under the cap.
        (let ((nn (fit-n n ps)))
          (cond
            ((null nn)
             (format t "~5d ~6d ~9@a | SKIPPED — even N=~:d would exceed the ~a cap~%"
                     ps cmb "--" *min-n* (fmt-bytes *max-store-bytes*))
             (finish-output))
            (t
             (when (< nn n)
               (format t "  [cell ps=~d c=~dMB: N scaled ~:d -> ~:d to fit ~a cap]~%"
                       ps cmb n nn (fmt-bytes *max-store-bytes*)))
             (let ((r (run-one nn ps cmb :lookups lookups)))
               (push r results)
               (print-result r)
               (finish-output)))))))
    (format t "~a~%" (make-string 128 :initial-element #\-))
    (format t "warm = lookups right after build (cache hot).  ~
               cold = store reopened with same cache, keys drawn at random ~
               (working set >> cache).~%")
    (format t "N may differ per row: each cell's dataset is scaled down so its ~
               temp store stays under ~a.~%" (fmt-bytes *max-store-bytes*))
    (nreverse results)))
