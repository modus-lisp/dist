;;;; pagetree.asd

(defsystem "pagetree"
  :description "Pure Common Lisp, dependency-free embedded persistent key-value
                store: a copy-on-write B+tree over a paged block device, with an
                in-Lisp LRU buffer cache and crash-atomic (no-WAL) commits.  The
                only platform contact surface is a tiny block-device protocol
                (file-backed on SBCL/Linux; a driver on the modus Lisp OS).  No
                FFI, no sb-posix, no mmap.  Built for cl-consensus's UTXO store
                and for Raspberry-Pi-class hardware."
  :version "0.0.1"
  :author "ynniv"
  :license "MIT"
  :depends-on ()
  :serial t
  :components
  ((:module "src"
    :serial t
    :components ((:file "packages")
                 ;; Layer 0 — block device (the only platform seam)
                 (:file "device")        ; protocol + in-RAM backend
                 (:file "device-file")   ; standard-CL-stream file backend
                 ;; Layer 1 — pager + LRU buffer cache + free-page allocator
                 (:file "pager")
                 ;; Layer 2 — copy-on-write B+tree + KV API
                 (:file "node")          ; page (de)serialization: meta/interior/leaf/overflow
                 (:file "btree")         ; CoW insert/lookup/delete, atomic meta commit
                 (:file "store"))))      ; open/close, with-read/write-txn, cursors
  :in-order-to ((test-op (test-op "pagetree/test"))))

(defsystem "pagetree/test"
  :description "Differential oracle: random op sequences vs an in-RAM reference
                model, fault-injection crash-recovery tests, ordered-scan checks."
  :depends-on ("pagetree")
  :serial t
  :components ((:module "test" :components ((:file "test")))))
