# pagetree — design & plan

> Working name. Rename freely — nothing depends on it yet.

A **pure Common Lisp, dependency-free, embedded persistent key-value store**: a
copy-on-write B+tree over a paged block device, with an in-Lisp buffer cache and
crash-atomic commits — **no FFI, no `sb-posix`, no syscalls beyond block
read/write**. It runs on SBCL/Linux today and on **modus** (a Lisp OS, not a
Linux ABI) tomorrow, because the only platform contact surface is one tiny block
device protocol we define ourselves.

Built as a standalone library (like `secp256k1-fast`) so `cl-consensus`, `modus`,
and anything else can share it.

## Why this exists

`cl-consensus`'s UTXO store today is `utxo-disk.lisp` — a 60 GB sparse,
random-access, `sb-posix:mmap`'d open-addressing slot table, plus a hand-rolled
WAL for crash-safety. Two problems:

1. **It can't run on modus at all** — `mmap`/`vector-sap` are SBCL-on-Linux. modus
   has no Linux ABI. This is a hard blocker, not an optimization.
2. **It's wrong for a Raspberry Pi** (the prime modus target: 4–8 GB RAM, SSD via
   M.2 HAT / USB): a ~30 GB working set can't be cached in Pi RAM, it's 4–10× the
   size of Core's chainstate, and random in-place writes are unkind to flash.

A compact, RAM-bounded, pure-CL store fixes both at once — and **subsumes the WAL**
(CoW + atomic root swap gives crash-safety for free).

## Storage-engine choice: copy-on-write B+tree (not LSM)

Workload is **read-heavy point lookups** (spend → does this outpoint exist, give me
its coin) with writes **batched per checkpoint**. Target media is **SSD**.

- B+tree minimizes **read amplification** (one root-to-leaf path) — the dominant op,
  and it matters even more on slow media.
- **CoW gives crash-atomicity with no WAL**: modified pages are written to *free*
  pages (never overwriting live data); commit is a single atomic meta-page swap.
- Ordered storage makes the **set-digest scan** (`gettxoutsetinfo`-style) a
  sequential walk and keeps the file **compact** (no hash-table load-factor slack —
  exactly what bloated the current udb).
- LSM's one advantage (sequential, endurance-friendly writes) is the thing **SSD
  makes least relevant**, while its complexity tax (memtable + leveled compaction +
  bloom filters) stays. Not worth it here. (Reconsider only if the profile turns
  write-heavy or microSD-endurance-critical — neither holds.)
- Proof point: LMDB *is* a CoW B+tree and is the standard for read-heavy embedded
  stores on SSD (Monero runs it on Pi-class hardware).

## Architecture — three layers, only Layer 0 is platform-specific

### Layer 0 — block device (the seam)
A fixed-size page array. The entire OS contact surface, ~5 ops:
```
(dev-read-page  dev n buf)   ; fill BUF (PAGE-SIZE bytes) with page N
(dev-write-page dev n buf)   ; persist BUF as page N
(dev-sync       dev)         ; durability barrier
(dev-grow       dev k)       ; extend by K pages, return new first index
(dev-page-count dev)
```
- **File backend (now):** standard CL streams — `file-position` +
  `read-sequence`/`write-sequence`. Pure ANSI CL. `dev-sync` uses
  `finish-output` (+ an optional `force-output`/fsync hook left as a per-backend
  detail so the file backend can be made durable without leaking into upper layers).
- **modus backend (later):** its disk driver. Nothing above Layer 0 changes.
- **mem backend (tests):** an in-RAM vector of pages — for fast property/crash tests.

### Layer 1 — pager + buffer cache (pure CL)
- LRU/clock cache of decoded pages, sized by a **RAM budget** (the hardware knob:
  2 GB Pi vs 8 GB Pi vs desktop). Pin/unpin, dirty tracking.
- **Free-page allocator**: a freelist of reclaimable page indices (pages freed by a
  committed txn, reusable once no live reader references them). v1: simple freelist;
  grow the device when empty.
- Flushes dirty pages to Layer 0 on commit.

### Layer 2 — copy-on-write B+tree + KV API
- Page types: **meta** (×2, double-buffered), **interior**, **leaf**, **overflow**
  (for values larger than a page — coins are small, but scripts can be big), and
  **freelist**.
- **Meta page**: magic, format-version, page-size, monotonic `txn-id`,
  `root-page`, `freelist-root`, `entry-count`, `checksum`. Two meta slots
  (pages 0 and 1); the live one is the valid-checksum meta with the highest
  `txn-id`.
- **Write transaction** (single writer): copy each page on the touched root-to-leaf
  path into free pages, build the new root, flush dirty pages + `dev-sync`, then
  write the new meta into the **inactive** slot + `dev-sync`. That meta write is the
  **atomic commit point**.
- **Crash-atomicity (no WAL):** a crash mid-commit either (a) never wrote the new
  meta → reopen picks the old meta = last committed state, and the half-written CoW
  pages are just unreferenced free space; or (b) tore the meta write → its checksum
  fails → reopen falls back to the other meta. Either way: last committed txn,
  intact. (We already validated this exact recovery shape with the cl-consensus WAL
  test; here it's structural.)
- **Read transaction / cursor**: a consistent snapshot rooted at a meta; supports
  point `get` and ordered iteration (for the set digest). MVCC (readers don't block
  the writer) is natural from CoW but can be deferred to a later phase if single
  reader-at-a-time suffices early.

### Public API (sketch)
```lisp
(open-store path &key page-size cache-bytes create) → store
(close-store store)
(with-write-txn (txn store) ...)         ; commits on normal exit, aborts on unwind
(with-read-txn  (txn store) ...)
(tput txn key val)                       ; key/val = byte vectors
(tget txn key) → val | nil
(tdel txn key)
(tcursor txn) / cursor-first / cursor-next ; ordered scan
```

## Integration with cl-consensus
Behind the existing `utxo` interface (`utxo-get/add/spend`, `flush`, digest):
- key = outpoint: `txid(32) || index(varint)` (36-ish bytes)
- value = compact coin: `height<<1 | coinbase` (varint), `value` (varint), script
- the per-checkpoint **staging buffer becomes one write txn**; `flush-utxo` →
  `with-write-txn` over the batch. Replaces `utxo-disk.lisp` **and** the WAL.
- the set digest iterates the cursor in key order.

## Testing — differential oracle (mirrors secp256k1-fast's philosophy)
1. **Model test:** random op sequences (put/del/get/scan) against an in-RAM
   hash-table + sorted-list reference; assert identical results, including ordered
   scans. Run on the **mem backend** for speed, then the file backend.
2. **Crash test:** the mem/file backend injects a fault (stop after N page writes /
   tear the meta write); reopen must yield the last *committed* txn, never a partial
   one. Fuzz the fault point.
3. **Integration:** run a cl-consensus IBD segment on it and assert the UTXO
   **set-digest is byte-identical** to the current udb (the existing
   order-independent commitment) — the real consensus-grade oracle.

## Portability / modus
Layers 1–2 are ANSI CL only: no `sb-posix`, no SAPs, no FFI, no threads required
for correctness (single-writer; an optional reader-writer lock for MVCC is the only
concurrency, and that can be a portable mutex). modus supplies a Layer-0 driver and
everything else just works.

## Phasing
- **P1 (core):** mem + file Layer 0; pager + LRU cache; CoW B+tree get/put/del;
  double-meta atomic commit; model + crash property tests. *Deliverable: a correct,
  crash-safe embedded KV store.*
- **P2:** ordered cursor (digest), overflow pages (large values), free-page
  reclamation, tunable page/cache sizing.
- **P3:** wire behind cl-consensus `utxo`; differential digest vs udb; perf-tune on
  the live chain (cache size, page size) — A/B against the flat udb.
- **P4 (if needed):** MVCC read snapshots concurrent with the writer.
- **Later:** modus Layer-0 driver; optional value compression; an SBCL-VOP fast
  path for the hot page-codec/compare (kept behind the portable reference, à la
  secp256k1-fast).

## Non-goals (v1)
Multi-writer concurrency, networked access, secondary indexes, range deletes,
compression. Keep it a single-file, single-writer, crash-safe ordered KV store.
