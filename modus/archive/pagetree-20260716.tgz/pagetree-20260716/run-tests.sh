#!/bin/sh
# run-tests.sh — load pagetree + run its differential-oracle test suite.
# Exits 0 iff every check passes, non-zero otherwise.
#
# Usage:  ./run-tests.sh            # uses `sbcl` on PATH
#         LISP=sbcl ./run-tests.sh  # override the Lisp implementation
#
# Pure ANSI CL, no external dependencies.

set -eu

# Repo root = directory containing this script.
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
LISP=${LISP:-sbcl}

exec "$LISP" --non-interactive --disable-debugger --eval '(require :asdf)' \
  --eval "(push #p\"$ROOT/\" asdf:*central-registry*)" \
  --eval '(handler-case
              (progn
                (asdf:load-system "pagetree/test")
                (if (funcall (read-from-string "pagetree/test:run-tests"))
                    (uiop:quit 0)
                    (uiop:quit 1)))
            (serious-condition (c)
              (format *error-output* "~&run-tests.sh: ~a~%" c)
              (uiop:quit 2)))'
