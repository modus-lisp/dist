;;;; src/device-file.lisp — Layer 0: file-backed block device (standard CL streams).
;;;;
;;;; A file-device maps the page array onto a single file: page N occupies the
;;;; byte range [N*page-size, (N+1)*page-size).  Raw pages, no on-disk header —
;;;; the btree owns pages 0/1 as its meta pages.  Implemented with ONLY standard
;;;; ANSI CL stream I/O (open / file-position / file-length / read-sequence /
;;;; write-sequence) so it ports unchanged to modus: no sb-posix, no SAPs, no FFI.

(in-package #:pagetree.device)

(defclass file-device ()
  ((stream    :initarg :stream     :reader fd-stream)
   (page-size :initarg :page-size  :reader fd-page-size)
   (path      :initarg :path       :reader fd-path)
   ;; Authoritative page count.  We must NOT derive this from FILE-LENGTH on the
   ;; fly: CL stream FILE-LENGTH does not reflect bytes that are buffered but not
   ;; yet flushed, so a grow-then-count before a sync would under-report.  We
   ;; seed it from the on-disk length at open and advance it on dev-grow.
   (page-count :initarg :page-count :accessor fd-page-count)))

(defun make-file-device (path &key (page-size +default-page-size+) create)
  "Open PATH as a block device of PAGE-SIZE byte pages.

   CREATE controls how a missing/existing file is treated:
     nil (default) — open an existing file; error if it does not exist.
     :if-exists/t  — create if absent, otherwise open the existing file.
     :supersede    — always create fresh, truncating any existing file.

   The file is opened :direction :io with element-type (unsigned-byte 8).  Its
   length must be a whole multiple of PAGE-SIZE (it always is when only this
   device has written it)."
  (check-type page-size (integer 1))
  (let ((stream
          (ecase create
            ((nil)
             ;; Open existing only.  :if-does-not-exist :error is the default,
             ;; but be explicit for clarity / portability.
             (open path :element-type '(unsigned-byte 8) :direction :io
                        :if-exists :overwrite
                        :if-does-not-exist :error))
            ((t :if-exists)
             ;; Open if present, create if not.  :overwrite keeps existing bytes
             ;; and leaves the position at the start.
             (open path :element-type '(unsigned-byte 8) :direction :io
                        :if-exists :overwrite
                        :if-does-not-exist :create))
            ((:supersede)
             ;; Always fresh / truncated.
             (open path :element-type '(unsigned-byte 8) :direction :io
                        :if-exists :supersede
                        :if-does-not-exist :create)))))
    (let ((len (file-length stream)))
      (unless (zerop (mod len page-size))
        (close stream)
        (error "file-device: file ~s length ~d is not a multiple of page-size ~d"
               path len page-size))
      (make-instance 'file-device :stream stream :page-size page-size :path path
                                  :page-count (floor len page-size)))))

(defmethod dev-page-size ((d file-device))
  (fd-page-size d))

(defmethod dev-page-count ((d file-device))
  (fd-page-count d))

(defmethod dev-read-page ((d file-device) n buf)
  "Fill BUF with page N.  BUF must be a (page-size) (unsigned-byte 8) vector."
  (let* ((ps     (fd-page-size d))
         (stream (fd-stream d))
         (offset (* n ps)))
    (file-position stream offset)
    (let ((got (read-sequence buf stream :end ps)))
      (unless (= got ps)
        (error "file-device: short read of page ~d (~d of ~d bytes)" n got ps)))
    buf))

(defmethod dev-write-page ((d file-device) n buf)
  "Persist BUF as page N.  Does not sync — call dev-sync for the durability barrier."
  (let* ((ps     (fd-page-size d))
         (stream (fd-stream d))
         (offset (* n ps)))
    (file-position stream offset)
    (write-sequence buf stream :end ps)
    (values)))

(defmethod dev-grow ((d file-device) k)
  "Append K zero pages; return the index of the first new page.  Extends by
   writing zeros at the new tail so the file length grows by exactly K pages."
  (let* ((ps    (fd-page-size d))
         (start (fd-page-count d)))
    (when (plusp k)
      (let ((stream (fd-stream d))
            (zeros  (make-array ps :element-type '(unsigned-byte 8)
                                   :initial-element 0)))
        (file-position stream (* start ps))
        (dotimes (i k)
          (write-sequence zeros stream)))
      (incf (fd-page-count d) k))
    start))

(defmethod dev-sync ((d file-device))
  "Durability barrier.  In ANSI CL the strongest portable flush is FINISH-OUTPUT,
   which pushes buffered bytes to the OS but does NOT guarantee they reached
   stable storage across a power loss (that needs fsync, which is not ANSI CL).
   This is acceptable for P1; the modus backend will provide real durability."
  (finish-output (fd-stream d))
  (values))

(defun close-file-device (d)
  "Close the underlying file.  (Not part of the Layer-0 protocol; a convenience
   for tests and explicit teardown — flushes then releases the handle.)"
  (finish-output (fd-stream d))
  (close (fd-stream d))
  (values))
