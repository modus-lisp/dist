;;;; src/btree.lisp — Layer 2: copy-on-write B+tree over the pager.
;;;;
;;;; Copy-on-write discipline (the pager evicts CLEAN pages at will, never dirty
;;;; ones): we NEVER mutate a page fetched with pager-get in place.  To change
;;;; page N we pager-alloc a fresh page, decode N into an in-memory struct,
;;;; mutate the struct, encode it into the new page, pager-dirty it, and
;;;; pager-free the old N.  Every page on the touched root-to-leaf path is thus
;;;; re-allocated; the old root/path become unreferenced free space.
;;;;
;;;; Commit (atomic, no WAL):
;;;;   1. pager-flush + pager-sync   — all new tree pages are on stable storage
;;;;   2. write the new META into the INACTIVE of the two meta slots (0/1)
;;;;   3. pager-flush + pager-sync   — the meta write is the commit point
;;;; A crash before step 3 leaves the old meta live (last committed state); a
;;;; torn meta in step 3 fails its checksum and reopen falls back to the other.
;;;;
;;;; Values too large to fit inline in a leaf are spilled to an OVERFLOW chain.

(in-package #:pagetree.btree)

;;; META lives in pages 0 and 1.  The first real tree/data page is 2.
(defconstant +meta-slot-0+ 0)
(defconstant +meta-slot-1+ 1)
(defconstant +first-data-page+ 2)

(defstruct btree
  pager
  (root 0)                ; root page index (0 = empty tree)
  (txn-id 0)              ; txn-id of the LAST committed meta
  (entry-count 0)
  (high-water +first-data-page+) ; pages [0, high-water) are owned by the store
  (live-slot +meta-slot-0+)      ; which meta slot is currently live
  ;; The on-disk freelist chain referenced by the LAST COMMITTED meta.  Like
  ;; committed-tree pages, these pages are still live until the NEXT commit's meta
  ;; supersedes them, so they must be deferred (pending-frees), never reused, until
  ;; that commit is durable.
  (committed-freelist-head 0)
  (committed-free-count 0)
  ;; CoW + freelist hazard control.  Pages belonging to the LAST COMMITTED tree
  ;; must NOT be reused until AFTER this txn commits (the live meta still points
  ;; at them; reusing+overwriting them before commit would corrupt the recovery
  ;; tree if we crash mid-commit).  So during a txn we DEFER such frees here and
  ;; only return them to the pager freelist after a successful commit.  Pages
  ;; ALLOCATED within the current txn, by contrast, are referenced by no
  ;; committed meta and are safe to free (reuse) immediately.
  (txn-allocated (make-hash-table)) ; page-index -> t  (alloc'd this txn)
  (pending-frees '()))               ; committed-tree pages freed this txn

;;; Spill threshold: a value at most this big stays INLINE in the leaf; larger
;;; values go to the leaf's PACKED overflow blob (see node.lisp's LEAF section
;;; and the blob helpers below).
;;;
;;; The old design ALSO spilled values over 1/4 page, but burned a whole 4 KB
;;; page per spilled value — a 300 B script cost 4096 B, which dominated the
;;; on-disk size.  The fix is not the threshold but the PACKING: a leaf's
;;; overflow values now share ONE tight chain (see node.lisp), so spilling costs
;;; ~the value's own bytes, not a page.  With packing in place the exact
;;; threshold barely matters; we keep it at 1/4 page so small coins (and the
;;; lower part of the "large" range) stay inline in dense leaves — the spend
;;; hot path then needs no extra page read — and only larger values overflow.
(defun inline-value-limit () (floor +page-size+ 4))

;;; ====================================================================
;;;  Open / bootstrap
;;; ====================================================================

(defun bootstrap-btree (pager)
  "Fresh store: device has no meta.  Create an empty tree and write meta into
   slot 0.  (Caller has already grown the device to hold pages 0 & 1.)"
  (let ((bt (make-btree :pager pager
                        :root 0
                        :txn-id 0
                        :entry-count 0
                        :high-water +first-data-page+
                        :live-slot +meta-slot-1+))) ; so first commit lands in slot 0
    ;; Persist the empty tree as txn 1 in slot 0.
    (btree-commit bt)
    bt))

(defun read-meta-slot (pager slot)
  "Decode the meta in SLOT, or NIL if absent/torn."
  (decode-meta (pager:pager-get pager slot)))

(defun load-freelist-chain (pager head)
  "Walk the on-disk freelist chain starting at page HEAD (0 = empty) and return
   a list of all free page indices it records."
  (let ((out '())
        (p head))
    (loop while (/= p 0)
          do (multiple-value-bind (next indices)
                 (decode-freelist-chunk (pager:pager-get pager p))
               (setf out (nconc indices out))
               (setf p next)))
    out))

(defun restore-freelist (bt)
  "Load the persisted free set into the pager so freed pages are reused across
   sessions.  The freelist-chain pages THEMSELVES are NOT free (they hold the
   list) — they belong to the committed state and are reclaimed only on the next
   commit, so they must not appear in the restored free set."
  (let ((free (load-freelist-chain (btree-pager bt)
                                   (btree-committed-freelist-head bt))))
    (pager::pager-set-freelist (btree-pager bt) free)))

(defun btree-open (pager)
  "Open (or bootstrap) the tree over PAGER.  Picks the valid-checksum meta with
   the highest txn-id from the two slots; bootstraps an empty tree if neither is
   present (fresh device)."
  (let ((pc (dev:dev-page-count (pagetree.pager::pager-device pager))))
    (when (< pc 2)
      ;; Fresh device — make room for the two meta slots, then bootstrap.
      (dev:dev-grow (pagetree.pager::pager-device pager) (- 2 pc))
      (return-from btree-open (bootstrap-btree pager))))
  (let* ((m0 (read-meta-slot pager +meta-slot-0+))
         (m1 (read-meta-slot pager +meta-slot-1+)))
    (cond
      ((and (null m0) (null m1))
       ;; Device has pages but no valid meta — treat as fresh.
       (bootstrap-btree pager))
      (t
       (multiple-value-bind (m slot)
           (cond ((null m0) (values m1 +meta-slot-1+))
                 ((null m1) (values m0 +meta-slot-0+))
                 ((>= (meta-txn-id m0) (meta-txn-id m1))
                  (values m0 +meta-slot-0+))
                 (t (values m1 +meta-slot-1+)))
         (let ((bt (make-btree :pager pager
                               :root (meta-root m)
                               :txn-id (meta-txn-id m)
                               :entry-count (meta-entry-count m)
                               :high-water (max +first-data-page+ (meta-high-water m))
                               :live-slot slot
                               :committed-freelist-head (meta-freelist-head m)
                               :committed-free-count (meta-free-count m))))
           (restore-freelist bt)
           bt))))))

;; btree-root is the defstruct accessor, which is exactly what the API exports.

;;; ====================================================================
;;;  Page helpers — always copy-on-write
;;; ====================================================================

(defun note-allocated (bt n)
  (setf (gethash n (btree-txn-allocated bt)) t)
  (when (>= n (btree-high-water bt))
    (setf (btree-high-water bt) (1+ n))))

(defun btree-alloc (bt)
  "pager-alloc tracked as a current-txn allocation."
  (let ((n (pager:pager-alloc (btree-pager bt))))
    (note-allocated bt n)
    n))

(defun alloc-and-encode (bt encoder)
  "pager-alloc a fresh page, call (ENCODER buf) to fill it, dirty it, return n."
  (let* ((pager (btree-pager bt))
         (n (btree-alloc bt))
         (buf (pager:pager-get pager n)))
    (funcall encoder buf)
    (pager:pager-dirty pager n)
    n))

(defun free-page (bt n)
  "Free page N with CoW-safe semantics.  If N was allocated within THIS txn it
   is unreferenced by any committed meta — return it for immediate reuse.  If it
   belongs to the last committed tree, DEFER the free until after commit so it is
   never overwritten while the live meta still points at it."
  (cond
    ((gethash n (btree-txn-allocated bt))
     (remhash n (btree-txn-allocated bt))
     (pager:pager-free (btree-pager bt) n))
    (t (push n (btree-pending-frees bt)))))

;;; ---- packed, leaf-local overflow blobs ----
;;;
;;; A leaf's overflow values are CONCATENATED, in entry order, into one blob
;;; written to a single overflow chain (tight: only the chain's last page is
;;; partial).  The leaf header holds the chain head; an overflow entry carries
;;; only its vlen, and its slice is located by the running sum of preceding
;;; overflow vlens.  The chain is owned 1:1 by the leaf and rewritten/freed with
;;; it under copy-on-write, so packing needs no cross-leaf reference counting.

(defun write-overflow (bt value)
  "Spill the byte vector VALUE (a leaf's whole overflow blob) into a fresh tightly
   packed overflow chain; return the head page index (0 for an empty blob)."
  (when (zerop (length value))
    (return-from write-overflow 0))
  (let* ((cap (overflow-capacity))
         (len (length value))
         (chunks (max 1 (ceiling len cap)))
         (pages (loop repeat chunks collect (btree-alloc bt))))
    (loop for tail on pages
          for idx from 0
          for start = (* idx cap)
          for this-len = (min cap (- len start))
          for next = (if (cdr tail) (cadr tail) 0)
          for p = (car tail)
          do (let ((buf (pager:pager-get (btree-pager bt) p)))
               (encode-overflow buf next value start this-len)
               (pager:pager-dirty (btree-pager bt) p)))
    (first pages)))

(defun read-overflow (bt first-page)
  "Reassemble the full blob byte vector from an overflow chain at FIRST-PAGE."
  ;; Walk the chain once collecting chunks, then copy each exactly once into a
  ;; pre-sized buffer.  Growing an adjustable array per page is O(n^2) — every
  ;; ADJUST-ARRAY recopies the whole accumulated blob, so a large (100+ MB) blob
  ;; pegs a core for many minutes.  (Mirror of LEAF-PACK-BLOB's copy-once build.)
  (let ((chunks '())
        (total 0)
        (p first-page))
    (loop while (/= p 0)
          do (multiple-value-bind (next chunk)
                 (decode-overflow-chunk (pager:pager-get (btree-pager bt) p))
               (push chunk chunks)
               (incf total (length chunk))
               (setf p next)))
    (let ((out (make-array total :element-type '(unsigned-byte 8)))
          (pos 0))
      (dolist (chunk (nreverse chunks) out)
        (replace out chunk :start1 pos)
        (incf pos (length chunk))))))

(defun read-blob-slice (bt head offset len)
  "Return the LEN-byte value at byte OFFSET within the overflow blob at chain
   HEAD."
  (let ((blob (read-overflow bt head)))
    (subseq blob offset (+ offset len))))

(defun free-overflow (bt first-page)
  "Free every page in an overflow chain."
  (let ((p first-page))
    (loop while (/= p 0)
          do (multiple-value-bind (next chunk)
                 (decode-overflow-chunk (pager:pager-get (btree-pager bt) p))
               (declare (ignore chunk))
               (free-page bt p)
               (setf p next)))))

;;; ====================================================================
;;;  Sizing — decide when a node must split
;;; ====================================================================

(defun leaf-entry-size (lf i)
  "On-page byte cost of entry I of leaf LF."
  (let* ((key (aref (leaf-keys lf) i))
         (val (aref (leaf-vals lf) i))
         (ovpage (aref (leaf-ovpgs lf) i))
         (overflowp (overflow-val-p val))
         (vlen (if overflowp (overflow-val-len val) (length val))))
    (leaf-entry-bytes (length key) vlen overflowp ovpage)))

(defun leaf-encoded-size (lf)
  "Bytes a leaf would occupy when encoded."
  (let ((sz +leaf-hdr+))
    (dotimes (i (length (leaf-keys lf)) sz)
      (incf sz (leaf-entry-size lf i)))))

(defun interior-encoded-size (it)
  (let ((sz (+ +int-hdr+ (* 8 (length (interior-children it))))))
    (dotimes (i (length (interior-keys it)) sz)
      (incf sz (interior-key-bytes (length (aref (interior-keys it) i)))))))

(defun leaf-overfull-p (lf)
  (and (> (length (leaf-keys lf)) 1)
       (> (leaf-encoded-size lf) +page-size+)))

(defun interior-overfull-p (it)
  (and (> (length (interior-keys it)) 1)
       (> (interior-encoded-size it) +page-size+)))

;;; ====================================================================
;;;  Lookup
;;; ====================================================================

(defun leaf-find (lf key)
  "Index of KEY in leaf LF, or NIL.  Linear (entries are few per page)."
  (dotimes (i (length (leaf-keys lf)) nil)
    (when (key= (aref (leaf-keys lf) i) key) (return i))))

(defun interior-child-index (it key)
  "Index of the child to descend into for KEY."
  (let ((nkeys (length (interior-keys it))))
    (dotimes (i nkeys nkeys)
      (when (key< key (aref (interior-keys it) i)) (return i)))))

(defun btree-lookup (bt key)
  "Return the value byte-vector for KEY, or NIL if absent.

   The whole descent is allocation-free until a hit: each interior is probed
   in place (INTERIOR-PROBE reads only the child pointer for KEY — no struct,
   no key copies) and the leaf is probed in place (LEAF-PROBE locates KEY's
   value without decoding the entries).  Only on a hit do we materialize: an
   inline value is copied out of the page buffer (it may be evicted after we
   return); an overflow value is sliced from the leaf's packed blob."
  (let ((pager (btree-pager bt))
        (n (btree-root bt)))
    (when (zerop n) (return-from btree-lookup nil))
    (loop
      (let ((buf (pager:pager-get pager n)))
        (ecase (page-type buf)
          (#.+pt-interior+
           (setf n (interior-probe buf key)))
          (#.+pt-leaf+
           (return
             (multiple-value-bind (found vlen overflowp blob-off vstart blob-head)
                 (leaf-probe buf key)
               (when found
                 (if overflowp
                     (read-blob-slice bt blob-head blob-off vlen)
                     (subseq buf vstart (+ vstart vlen))))))))))))

;;; ====================================================================
;;;  Insert  (copy-on-write, bottom-up MULTI-WAY splits)
;;; ====================================================================
;;;
;;; insert-rec returns (values new-page seps children) where:
;;;   new-page  — replacement page index for the subtree at N (CoW)
;;;   seps      — NIL, or a list of separator keys promoted to the parent
;;;   children  — NIL, or the parallel list of additional right-sibling pages
;;; A node may split into MORE than two pieces (variable-length entries), so the
;;; split result is a list, not a single sibling; the parent splices them in.

(defun sorted-insert-pos (lf key)
  "Position at which KEY should be inserted in sorted leaf LF."
  (dotimes (i (length (leaf-keys lf)) (length (leaf-keys lf)))
    (when (key< key (aref (leaf-keys lf) i)) (return i))))

(defun leaf-vector-insert (lf pos key val ovpg)
  (vector-push-extend nil (leaf-keys lf))
  (vector-push-extend nil (leaf-vals lf))
  (vector-push-extend nil (leaf-ovpgs lf))
  (loop for i from (1- (length (leaf-keys lf))) downto (1+ pos)
        do (setf (aref (leaf-keys lf) i) (aref (leaf-keys lf) (1- i))
                 (aref (leaf-vals lf) i) (aref (leaf-vals lf) (1- i))
                 (aref (leaf-ovpgs lf) i) (aref (leaf-ovpgs lf) (1- i))))
  (setf (aref (leaf-keys lf) pos) key
        (aref (leaf-vals lf) pos) val
        (aref (leaf-ovpgs lf) pos) ovpg))

(defun make-empty-leaf () (make-leaf))

;;; ---- multi-way split --------------------------------------------------
;;;
;;; Variable-length entries (inline values up to nearly a page; keys up to a
;;; page) mean an overfull node can exceed TWO pages, or have an interior entry
;;; so large that a single 2-way split cannot produce two <=page halves (the
;;; oversized entry's two neighbour-runs may BOTH overflow when joined to it).
;;; A 2-way split is therefore not always sufficient.  We instead GREEDILY
;;; bin-pack the entries left-to-right into as many pages as needed: open a new
;;; page whenever the next entry would not fit the current one.  This always
;;; succeeds (each entry fits a page on its own — the inline limit + key bound
;;; guarantee it) and keeps every page but the last densely packed.
;;;
;;; SPLIT-LEAF-MULTI returns (values leaves seps), parallel so that LEAVES has
;;; one more element than SEPS and SEPS[i] is the first key of LEAVES[i+1] (the
;;; B+tree separator: a copy, since leaf keys stay in leaves).

(defun split-leaf-multi (lf)
  "Split LF into a list of leaves, each <= one page, returning (values leaves
   seps) where SEPS[i] is the first key of LEAVES[i+1].

   We choose NPARTS = max(2, ceil(total/page)) and fill parts toward a BALANCED
   target of total/NPARTS bytes each (rolling a new part once the current passes
   the target) — never exceeding a page.  Balancing (not packing each part full)
   leaves every part with headroom, so a freshly split leaf doesn't immediately
   re-split on the next insert (which would thrash fill downward).  A single
   oversized entry still lands alone in its own part: NPARTS and the hard page
   cap accommodate it."
  (let* ((n (length (leaf-keys lf)))
         (total (- (leaf-encoded-size lf) +leaf-hdr+))
         (nparts (max 2 (ceiling (leaf-encoded-size lf) +page-size+)))
         (target (ceiling total nparts))
         (leaves '())
         (cur (make-empty-leaf))
         (cur-bytes +leaf-hdr+)
         (made 1))
    (flet ((roll ()
             (push cur leaves)
             (setf cur (make-empty-leaf) cur-bytes +leaf-hdr+)
             (incf made)))
      (dotimes (i n)
        (let ((esz (leaf-entry-size lf i)))
          (when (and (> (length (leaf-keys cur)) 0)
                     (or (> (+ cur-bytes esz) +page-size+)          ; hard page cap
                         (and (< made nparts)                       ; balance target
                              (> (+ cur-bytes esz) (+ +leaf-hdr+ target)))))
            (roll))
          (vector-push-extend (aref (leaf-keys lf) i) (leaf-keys cur))
          (vector-push-extend (aref (leaf-vals lf) i) (leaf-vals cur))
          (vector-push-extend (aref (leaf-ovpgs lf) i) (leaf-ovpgs cur))
          (incf cur-bytes esz)))
      (push cur leaves))
    (setf leaves (nreverse leaves))
    (values leaves
            (loop for tail on (cdr leaves)
                  collect (copy-seq (aref (leaf-keys (car tail)) 0))))))

(defun split-interior-multi (it)
  "Split interior IT into a list of interiors, each <= one page, PROMOTING a
   separator between consecutive pieces (the separator key between the last child
   of one piece and the first child of the next is removed from both and
   promoted).  Returns (values interiors promoted-seps), parallel so INTERIORS
   has one more element than PROMOTED-SEPS.

   Like SPLIT-LEAF-MULTI, we target a BALANCED piece size (total/NPARTS) so the
   pieces keep headroom and don't immediately re-split, rather than packing each
   piece full."
  (let* ((total (interior-encoded-size it))
         (nparts (max 2 (ceiling total +page-size+)))
         (target (ceiling total nparts))
         (pieces '())
         (proms '())
         (cur (make-interior))
         (cur-bytes (+ +int-hdr+ 8))     ; header + first child pointer
         (made 1))
    ;; Walk children left-to-right; each child after the first is preceded by a
    ;; separator key (interior-keys[c-1]).  When opening a new piece we PROMOTE
    ;; the separator that would have joined the two pieces.
    (vector-push-extend (aref (interior-children it) 0) (interior-children cur))
    (loop for c from 1 below (length (interior-children it))
          for sep = (aref (interior-keys it) (1- c))
          for child = (aref (interior-children it) c)
          for add = (+ (interior-key-bytes (length sep)) 8)
          do (cond
               ((or (> (+ cur-bytes add) +page-size+)               ; hard page cap
                    (and (< made nparts)                            ; balance target
                         (> (+ cur-bytes add) target)
                         (> (length (interior-children cur)) 1)))
                ;; close CUR; SEP is promoted (joins CUR's piece to the next).
                (push cur pieces)
                (push (copy-seq sep) proms)
                (setf cur (make-interior) cur-bytes (+ +int-hdr+ 8))
                (incf made)
                (vector-push-extend child (interior-children cur))
                (incf cur-bytes 8))
               (t
                (vector-push-extend (copy-seq sep) (interior-keys cur))
                (vector-push-extend child (interior-children cur))
                (incf cur-bytes add))))
    (push cur pieces)
    (values (nreverse pieces) (nreverse proms))))

(defun inline-fits-p (klen vlen)
  "T iff a single leaf entry with key length KLEN and inline value length VLEN
   fits within one page (so the leaf holding it alone is always encodable).
   This is the real inline gate — it accounts for the KEY, not just the value,
   so a large key forces even a moderate value to overflow.  We also cap the
   value at the inline-value-limit to keep small-coin leaves well packed."
  (and (<= vlen (inline-value-limit))
       (<= (+ +leaf-hdr+ (leaf-entry-bytes klen vlen nil)) +page-size+)))

(defun materialize-value (bt key val)
  "Decide inline vs overflow for VAL given KEY.  Returns (values stored ovpg):
   STORED is the byte vector (inline) or a (:overflow-bytes . bytes) marker whose
   bytes are repacked into the leaf's blob at COW time; OVPG is unused (0)."
  (declare (ignore bt))
  (if (inline-fits-p (length key) (length val))
      (values val 0)
      (values (cons :overflow-bytes (coerce val '(simple-array (unsigned-byte 8) (*))))
              0)))

(defun leaf-load-overflow (bt lf)
  "Materialize LF's overflow values into RAM so the leaf can be repacked under
   CoW.  Replaces every lazy (:overflow . vlen) marker with (:overflow-bytes .
   bytes) sliced from the on-disk blob, then returns the OLD blob-head chain to
   free (0 if none).  Idempotent-ish: entries already :overflow-bytes (freshly
   inserted) are left as-is.  Reads the blob at most once."
  (let ((head (leaf-blob-head lf))
        (any nil))
    (loop for v across (leaf-vals lf)
          when (and (consp v) (eq (car v) :overflow)) do (setf any t))
    (when (and any (/= head 0))
      (let ((blob (read-overflow bt head)))
        (dotimes (i (length (leaf-vals lf)))
          (let ((v (aref (leaf-vals lf) i)))
            (when (and (consp v) (eq (car v) :overflow))
              (let ((off (aref (leaf-ovpgs lf) i))
                    (len (cdr v)))
                (setf (aref (leaf-vals lf) i)
                      (cons :overflow-bytes (subseq blob off (+ off len))))
                (setf (aref (leaf-ovpgs lf) i) 0))))))) ; offsets recomputed on cow
    ;; clear the head on the in-memory leaf; cow rebuilds it
    (setf (leaf-blob-head lf) 0)
    head))

(defun leaf-pack-blob (bt lf)
  "Build LF's overflow blob from its :overflow-bytes entries (in entry order),
   write it as a fresh tight chain, set LF's BLOB-HEAD, and assign per-entry blob
   offsets.  No-op (head 0) if LF has no overflow values."
  (let ((total 0))
    (loop for v across (leaf-vals lf)
          when (and (consp v) (eq (car v) :overflow-bytes))
            do (incf total (length (cdr v))))
    (cond
      ((zerop total) (setf (leaf-blob-head lf) 0))
      (t
       (let ((blob (make-array total :element-type '(unsigned-byte 8)))
             (off 0))
         (dotimes (i (length (leaf-vals lf)))
           (let ((v (aref (leaf-vals lf) i)))
             (when (and (consp v) (eq (car v) :overflow-bytes))
               (let ((bytes (cdr v)))
                 (replace blob bytes :start1 off)
                 (setf (aref (leaf-ovpgs lf) i) off)
                 (incf off (length bytes))))))
         (setf (leaf-blob-head lf) (write-overflow bt blob)))))))

(defun cow-leaf (bt lf)
  "Pack LF's overflow blob (if any) into a fresh chain, then encode LF into a
   fresh page; return its index.  The caller is responsible for freeing the
   leaf's OLD blob chain (via LEAF-LOAD-OVERFLOW's return)."
  (leaf-pack-blob bt lf)
  (alloc-and-encode bt (lambda (buf) (encode-leaf lf buf))))

(defun cow-leaf-keep-blob (bt lf)
  "Encode LF into a fresh page WITHOUT rewriting its overflow blob: LF's lazy
   (:overflow . vlen) markers and BLOB-HEAD are preserved, so the existing chain
   stays live and shared by the new leaf page.  Valid only when the leaf's set of
   overflow values (and their order/offsets in the blob) is unchanged — e.g. a
   plain inline insert/replace with no split."
  (alloc-and-encode bt (lambda (buf) (encode-leaf lf buf))))

(defun cow-interior (bt it)
  (alloc-and-encode bt (lambda (buf) (encode-interior it buf))))

(defun insert-rec (bt n key val)
  "Insert KEY/VAL into the subtree rooted at page N (CoW).  Returns
   (values new-page seps children): NEW-PAGE is the leftmost replacement page;
   on a split, SEPS and CHILDREN are PARALLEL lists (CHILDREN are the additional
   right-sibling pages, SEPS[i] the separator key between the running group and
   CHILDREN[i]).  Both NIL when no split occurred."
  (let ((buf (pager:pager-get (btree-pager bt) n)))
    (ecase (page-type buf)
      (#.+pt-leaf+
       (let* ((lf (decode-leaf buf))
              (existing (leaf-find lf key))
              (new-overflows (not (inline-fits-p (length key) (length val))))
              (old-overflow (and existing (overflow-val-p (aref (leaf-vals lf) existing))))
              ;; The blob only needs repacking when an overflow value is added,
              ;; removed, or replaced.  A plain inline insert/replace into a leaf
              ;; that doesn't split leaves the blob untouched — we then keep the
              ;; existing chain (no rewrite), avoiding write amplification.
              (touches-overflow (or new-overflows old-overflow)))
         (cond
           (touches-overflow
            (let ((old-blob (leaf-load-overflow bt lf)))
              (multiple-value-bind (stored ovpg) (materialize-value bt key val)
                (if existing
                    (setf (aref (leaf-vals lf) existing) stored
                          (aref (leaf-ovpgs lf) existing) ovpg)
                    (leaf-vector-insert lf (sorted-insert-pos lf key) key stored ovpg)))
              (free-page bt n)
              (when (/= old-blob 0) (free-overflow bt old-blob))
              (cond
                ((leaf-overfull-p lf)
                 (multiple-value-bind (leaves seps) (split-leaf-multi lf)
                   (let ((pages (mapcar (lambda (l) (cow-leaf bt l)) leaves)))
                     (values (first pages) seps (rest pages)))))
                (t (values (cow-leaf bt lf) nil nil)))))
           (t
            ;; pure inline change; blob (lazy markers + offsets) stays valid.
            (multiple-value-bind (stored ovpg) (materialize-value bt key val)
              (if existing
                  (setf (aref (leaf-vals lf) existing) stored
                        (aref (leaf-ovpgs lf) existing) ovpg)
                  (leaf-vector-insert lf (sorted-insert-pos lf key) key stored ovpg)))
            (free-page bt n)
            (cond
              ((leaf-overfull-p lf)
               ;; split needs to repartition the blob across the new leaves.
               (let ((old-blob (leaf-load-overflow bt lf)))
                 (multiple-value-bind (leaves seps) (split-leaf-multi lf)
                   (let ((pages (mapcar (lambda (l) (cow-leaf bt l)) leaves)))
                     (when (/= old-blob 0) (free-overflow bt old-blob))
                     (values (first pages) seps (rest pages))))))
              (t (values (cow-leaf-keep-blob bt lf) nil nil)))))))
      (#.+pt-interior+
       (let* ((it (decode-interior buf))
              (ci (interior-child-index it key))
              (child (aref (interior-children it) ci)))
         (free-page bt n)
         (multiple-value-bind (new-child seps children) (insert-rec bt child key val)
           (setf (aref (interior-children it) ci) new-child)
           (when seps
             ;; splice the additional children/separators after position ci.
             (interior-splice-children it ci seps children))
           (cond
             ((interior-overfull-p it)
              (multiple-value-bind (pieces proms) (split-interior-multi it)
                (let ((pages (mapcar (lambda (p) (cow-interior bt p)) pieces)))
                  (values (first pages) proms (rest pages)))))
             (t (values (cow-interior bt it) nil nil)))))))))

(defun interior-splice-children (it ci seps children)
  "After child position CI of interior IT, splice in the parallel lists SEPS and
   CHILDREN: each CHILDREN[i] becomes a new child to the right, with SEPS[i] as
   the separator preceding it.  The original child at CI stays in place; the new
   ones are inserted at CI+1, CI+2, ... in order."
  (loop for sep in seps
        for ch in children
        for at from (1+ ci)
        do ;; insert separator key at position (1- at) ... we keep keys/children
           ;; aligned: child[j] is bounded above by key[j-1].  Inserting child at
           ;; position AT pairs with key at position (1- AT).
           (vector-push-extend nil (interior-keys it))
           (loop for i from (1- (length (interior-keys it))) downto at
                 do (setf (aref (interior-keys it) i) (aref (interior-keys it) (1- i))))
           (setf (aref (interior-keys it) (1- at)) sep)
           (vector-push-extend nil (interior-children it))
           (loop for i from (1- (length (interior-children it))) downto (1+ at)
                 do (setf (aref (interior-children it) i) (aref (interior-children it) (1- i))))
           (setf (aref (interior-children it) at) ch)))

(defun btree-insert (bt key val)
  "Insert/replace KEY -> VAL.  Keys/values are (unsigned-byte 8) vectors."
  (let ((root (btree-root bt)))
    (when (zerop root)
      ;; empty tree: create the first leaf
      (let ((lf (make-empty-leaf)))
        (multiple-value-bind (stored ovpg) (materialize-value bt key val)
          (leaf-vector-insert lf 0 key stored ovpg))
        (setf (btree-root bt) (cow-leaf bt lf))
        (incf (btree-entry-count bt))
        (return-from btree-insert bt)))
    (let ((present (btree-lookup-present-p bt key)))
      (multiple-value-bind (new-root seps children) (insert-rec bt root key val)
        (cond
          (seps
           ;; root split: a new interior parents the running child + all siblings.
           ;; The interior itself may exceed a page (many promoted separators), so
           ;; build it then split-and-stack until a single root <= a page remains.
           (let ((it (make-interior)))
             (vector-push-extend new-root (interior-children it))
             (loop for sep in seps
                   for ch in children
                   do (vector-push-extend sep (interior-keys it))
                      (vector-push-extend ch (interior-children it)))
             (setf (btree-root bt) (build-root bt it))))
          (t (setf (btree-root bt) new-root)))
        (unless present (incf (btree-entry-count bt)))))
    bt))

;;; ====================================================================
;;;  Batched apply  (copy-on-write, ONE coordinated left-to-right pass)
;;; ====================================================================
;;;
;;; BTREE-INSERT/DELETE descend root-to-leaf and CoW-copy the whole path PER KEY.
;;; For a sorted run of K keys — the UTXO checkpoint-flush workload — that is ~K
;;; re-descents and ~K path copies even though most keys route through the same
;;; interior pages and land in a handful of adjacent leaves.
;;;
;;; APPLY-REC instead takes a batch SORTED by key and applies it in a single
;;; coordinated recursive pass.  At each node it visits the touched children ONCE
;;; (partitioning the sorted op-run by child), copies the node ONCE for the whole
;;; batch, and writes each affected leaf ONCE (split into as many leaves as needed
;;; in one go).  The result is byte-identical to applying the ops one-by-one with
;;; BTREE-INSERT/BTREE-DELETE in key order:
;;;
;;;   * Routing is the SAME function (INTERIOR-CHILD-INDEX) keyed off the SAME
;;;     separators; because the batch is sorted and separators are monotone, the
;;;     keys routing to a given child form a CONTIGUOUS sub-run — so partitioning
;;;     loses nothing.  After splicing in a child's split results, later children
;;;     of THIS interior route by separators that are all > every key just added
;;;     below the earlier children, so their routing is unaffected (exactly as if
;;;     the inserts had happened sequentially, since each only ever splits its own
;;;     subtree and promotes separators that sit to its right).
;;;   * The leaf-level apply uses the SAME per-entry insert/replace/delete and the
;;;     SAME overflow (blob load / materialize / repack) and SAME split
;;;     (SPLIT-LEAF-MULTI) and interior split (SPLIT-INTERIOR-MULTI / BUILD-ROOT)
;;;     machinery as the per-key path, so the on-disk format and the resulting
;;;     tree shape match.
;;;   * CoW discipline is unchanged: every touched page is FREE-PAGE'd and a fresh
;;;     page allocated; deferred-free of committed pages until commit+sync is
;;;     untouched.  The batch only changes HOW MANY times we copy each page within
;;;     one txn (once per batch, not once per key) — never WHICH pages are live,
;;;     nor the commit/recovery protocol.
;;;
;;; An OP is a cons (KEY . VAL): VAL is a byte vector for put, or the keyword
;;; :DELETE for a delete.  OPS is a simple-vector sorted ascending by key with no
;;; duplicate keys (the caller — e.g. cl-consensus flushing its staging hash table
;;; — coalesces duplicates before sorting, which matches "last write wins").

(defun op-key (op) (car op))
(defun op-delete-p (op) (eq (cdr op) :delete))

(defun batch-touches-overflow-p (bt lf ops lo hi)
  "T iff applying OPS[lo,hi) to leaf LF adds, replaces, or removes any overflow
   value — i.e. the leaf's packed blob must be rebuilt.  A batch of pure inline
   puts/deletes that neither introduces an overflow value nor touches an existing
   one leaves the blob untouched (keep-blob fast path)."
  (declare (ignore bt))
  (loop for i from lo below hi
        for op = (aref ops i)
        for key = (op-key op)
        for existing = (leaf-find lf key)
        for old-overflow = (and existing (overflow-val-p (aref (leaf-vals lf) existing)))
        for new-overflow = (and (not (op-delete-p op))
                                (not (inline-fits-p (length key) (length (cdr op)))))
        thereis (or old-overflow new-overflow)))

(defun leaf-apply-op (bt lf op)
  "Apply a single OP (put or :delete) to in-memory leaf LF.  Returns the entry-
   count delta (+1 insert, -1 delete-of-present, 0 replace / delete-absent).
   Assumes any overflow blob has already been materialized when needed (callers
   load it first when BATCH-TOUCHES-OVERFLOW-P)."
  (let* ((key (op-key op))
         (existing (leaf-find lf key)))
    (cond
      ((op-delete-p op)
       (cond (existing (leaf-vector-delete lf existing) -1)
             (t 0)))
      (t
       (multiple-value-bind (stored ovpg) (materialize-value bt key (cdr op))
         (cond
           (existing
            (setf (aref (leaf-vals lf) existing) stored
                  (aref (leaf-ovpgs lf) existing) ovpg)
            0)
           (t
            (leaf-vector-insert lf (sorted-insert-pos lf key) key stored ovpg)
            1)))))))

(defun apply-rec (bt n ops lo hi)
  "Apply the sorted op-run OPS[lo,hi) to the subtree rooted at page N (CoW), in
   ONE pass.  Returns (values new-page seps children delta): NEW-PAGE is the
   leftmost replacement page; on a split SEPS and CHILDREN are parallel lists of
   the promoted separators and additional right-sibling pages; DELTA is the net
   change in entry-count for this subtree.  Both SEPS and CHILDREN NIL when no
   split occurred.  Mirrors INSERT-REC's split-result protocol exactly so the
   parent splices results identically to the per-key path."
  (let ((buf (pager:pager-get (btree-pager bt) n)))
    (ecase (page-type buf)
      (#.+pt-leaf+
       (let* ((lf (decode-leaf buf))
              (touches-overflow (batch-touches-overflow-p bt lf ops lo hi))
              (delta 0))
         (cond
           (touches-overflow
            ;; The blob will change: materialize it once, apply all ops, then
            ;; repack (and free the old chain) — once for the whole run.
            (let ((old-blob (leaf-load-overflow bt lf)))
              (loop for i from lo below hi
                    do (incf delta (leaf-apply-op bt lf (aref ops i))))
              (free-page bt n)
              (when (/= old-blob 0) (free-overflow bt old-blob))
              (cond
                ((leaf-overfull-p lf)
                 (multiple-value-bind (leaves seps) (split-leaf-multi lf)
                   (let ((pages (mapcar (lambda (l) (cow-leaf bt l)) leaves)))
                     (values (first pages) seps (rest pages) delta))))
                (t (values (cow-leaf bt lf) nil nil delta)))))
           (t
            ;; Pure inline puts/deletes: the blob (lazy markers + offsets) stays
            ;; valid unless we SPLIT (which repartitions it across new leaves).
            (loop for i from lo below hi
                  do (incf delta (leaf-apply-op bt lf (aref ops i))))
            (free-page bt n)
            (cond
              ((leaf-overfull-p lf)
               (let ((old-blob (leaf-load-overflow bt lf)))
                 (multiple-value-bind (leaves seps) (split-leaf-multi lf)
                   (let ((pages (mapcar (lambda (l) (cow-leaf bt l)) leaves)))
                     (when (/= old-blob 0) (free-overflow bt old-blob))
                     (values (first pages) seps (rest pages) delta)))))
              (t (values (cow-leaf-keep-blob bt lf) nil nil delta)))))))
      (#.+pt-interior+
       (let* ((it (decode-interior buf))
              (delta 0))
         (free-page bt n)
         ;; Walk the sorted run, partitioning it into per-child contiguous groups
         ;; via INTERIOR-CHILD-INDEX (the same routing the per-key path uses).
         ;; Recurse ONCE per touched child, splicing each child's split results in
         ;; immediately; because keys are sorted and separators monotone, later
         ;; groups route to children at strictly higher positions, and the splice
         ;; only inserts NEW children/separators to the RIGHT of the current one,
         ;; so a position recomputed for the next group stays correct.
         (let ((i lo))
           (loop while (< i hi) do
             ;; current child position for OPS[i]
             (let* ((ci (interior-child-index it (op-key (aref ops i))))
                    (j (1+ i)))
               ;; extend the group while the next op routes to the SAME child
               (loop while (and (< j hi)
                                (= (interior-child-index it (op-key (aref ops j))) ci))
                     do (incf j))
               (let ((child (aref (interior-children it) ci)))
                 (multiple-value-bind (new-child seps children d)
                     (apply-rec bt child ops i j)
                   (incf delta d)
                   (setf (aref (interior-children it) ci) new-child)
                   (when seps
                     (interior-splice-children it ci seps children))))
               (setf i j))))
         (cond
           ((interior-overfull-p it)
            (multiple-value-bind (pieces proms) (split-interior-multi it)
              (let ((pages (mapcar (lambda (p) (cow-interior bt p)) pieces)))
                (values (first pages) proms (rest pages) delta))))
           (t (values (cow-interior bt it) nil nil delta))))))))

(defun btree-apply-sorted (bt ops)
  "Apply OPS — a SIMPLE-VECTOR of (KEY . VAL) conses SORTED ascending by KEY with
   no duplicate keys, VAL a byte vector (put) or :DELETE (delete) — to BT in one
   coordinated CoW pass.  Semantically identical to BTREE-INSERT/BTREE-DELETE'ing
   the ops one-by-one in the same order, but copies each interior page once per
   batch and writes each leaf once.  Does NOT commit (caller commits the txn)."
  (let ((nops (length ops)))
    (when (zerop nops) (return-from btree-apply-sorted bt))
    (let ((root (btree-root bt)))
      (when (zerop root)
        ;; Empty tree: build the first leaf from the (sorted) puts in the batch,
        ;; then let the normal overfull-split path lift it into a tree.  Deletes
        ;; against an empty tree are no-ops.
        (let ((lf (make-empty-leaf))
              (delta 0))
          (loop for k from 0 below nops
                for op = (aref ops k)
                unless (op-delete-p op)
                  do (multiple-value-bind (stored ovpg)
                         (materialize-value bt (op-key op) (cdr op))
                       (leaf-vector-insert lf (length (leaf-keys lf))
                                           (op-key op) stored ovpg)
                       (incf delta)))
          (cond
            ((zerop (length (leaf-keys lf))) nil) ; only deletes, nothing to do
            ((leaf-overfull-p lf)
             (multiple-value-bind (leaves seps) (split-leaf-multi lf)
               (let ((pages (mapcar (lambda (l) (cow-leaf bt l)) leaves))
                     (it (make-interior)))
                 (vector-push-extend (first pages) (interior-children it))
                 (loop for sep in seps
                       for ch in (rest pages)
                       do (vector-push-extend sep (interior-keys it))
                          (vector-push-extend ch (interior-children it)))
                 (setf (btree-root bt) (build-root bt it)))))
            (t (setf (btree-root bt) (cow-leaf bt lf))))
          (incf (btree-entry-count bt) delta))
        (return-from btree-apply-sorted bt))
      ;; Non-empty tree: one recursive pass.
      (multiple-value-bind (new-root seps children delta) (apply-rec bt root ops 0 nops)
        (cond
          (seps
           (let ((it (make-interior)))
             (vector-push-extend new-root (interior-children it))
             (loop for sep in seps
                   for ch in children
                   do (vector-push-extend sep (interior-keys it))
                      (vector-push-extend ch (interior-children it)))
             (setf (btree-root bt) (build-root bt it))))
          (t (setf (btree-root bt) new-root)))
        (incf (btree-entry-count bt) delta))
      bt)))

(defun sort-batch (ops)
  "Coerce OPS (a sequence of (KEY . VAL) conses, VAL a byte vector or :DELETE)
   into a SIMPLE-VECTOR sorted ascending by key, with duplicate keys coalesced so
   that the LAST occurrence IN INPUT ORDER wins — matching the semantics of
   applying the ops sequentially (last write wins).

   CL:SORT is NOT guaranteed stable, so we cannot rely on sort order to identify
   the input-last duplicate.  Instead we sort on a (key, input-index) compound
   order: ties on key break by input index ASCENDING, so within each equal-key
   run the LAST element is the one with the greatest input index = the input-last
   write.  We then keep that last element of each run.

   Callers whose keys are already unique (the cl-consensus UTXO staging buffer is
   a hash table => unique keys) are unaffected; this only disambiguates the
   degenerate duplicate-key case."
  (let* ((n (length ops))
         (tagged (make-array n)))
    ;; tag each op with its input index so we can (a) make the sort total/stable
    ;; on equal keys and (b) recover input order for last-write-wins.
    (let ((i 0))
      (map nil (lambda (op) (setf (aref tagged i) (cons i op)) (incf i)) ops))
    (sort tagged (lambda (a b)
                   (let ((ka (op-key (cdr a))) (kb (op-key (cdr b))))
                     (cond ((key< ka kb) t)
                           ((key< kb ka) nil)
                           ;; equal keys: order by input index ascending, so the
                           ;; LAST in a run is the input-last write.
                           (t (< (car a) (car b)))))))
    (let ((out (make-array n :fill-pointer 0)))
      (loop for i from 0 below n
            for entry = (aref tagged i)
            for op = (cdr entry)
            do (if (and (> (fill-pointer out) 0)
                        (key= (op-key (aref out (1- (fill-pointer out)))) (op-key op)))
                   (setf (aref out (1- (fill-pointer out))) op) ; keep later input idx
                   (vector-push op out)))
      (coerce out 'simple-vector))))

(defun btree-apply-batch (bt ops &key (sorted nil))
  "Public batch entry point.  OPS is a sequence of (KEY . VAL) conses, VAL a
   byte vector (put) or :DELETE.  When :SORTED is NIL (default) OPS is sorted by
   key and duplicate keys coalesced (last wins) first; pass :SORTED T only when
   OPS is ALREADY a simple-vector sorted ascending with unique keys (skips the
   sort).  Applies the batch in one CoW pass; does NOT commit."
  (btree-apply-sorted bt (if sorted
                             (if (typep ops 'simple-vector) ops (coerce ops 'simple-vector))
                             (sort-batch ops))))

(defun btree-insert-batch (bt keys-vals &key (sorted nil))
  "Insert/replace a batch of KEY -> VAL pairs in one CoW pass (no deletes).
   KEYS-VALS is a sequence of (KEY . VAL) conses (VAL a byte vector).  See
   BTREE-APPLY-BATCH for the :SORTED contract.  Does NOT commit."
  (btree-apply-batch bt keys-vals :sorted sorted))

(defun build-root (bt it)
  "Turn the in-memory interior IT (which may be larger than a page) into a root
   page index, splitting into multiple levels as needed until the top is a
   single <=page node.  Returns the root page index."
  (loop
    (cond
      ((not (interior-overfull-p it))
       (return (cow-interior bt it)))
      (t
       (multiple-value-bind (pieces proms) (split-interior-multi it)
         (let ((pages (mapcar (lambda (p) (cow-interior bt p)) pieces))
               (parent (make-interior)))
           (vector-push-extend (first pages) (interior-children parent))
           (loop for sep in proms
                 for ch in (rest pages)
                 do (vector-push-extend sep (interior-keys parent))
                    (vector-push-extend ch (interior-children parent)))
           (setf it parent)))))))

;;; ====================================================================
;;;  Bulk build  (bottom-up, sequential — the fast from-empty loader)
;;; ====================================================================
;;;
;;; BTREE-INSERT and BTREE-APPLY-BATCH both DESCEND the tree per key (or per
;;; per-child op-run): for a from-empty load of N entries with RANDOM keys
;;; scattered across a growing tree, that is ~O(N·height) page touches and CoW
;;; copies — the cost that makes a 168M-coin UTXO migration crawl (~800 ops/s and
;;; falling as the tree grows).  When the ENTIRE dataset is available and can be
;;; SORTED up front, we can do far better: build the tree BOTTOM-UP in one
;;; sequential pass, writing every page EXACTLY ONCE and never descending.  Pack
;;; the sorted entries left-to-right into leaves; from the resulting
;;; (leaf-page . min-key) list build one interior level; repeat until a single
;;; root remains.  Cost is O(N) sequential page writes — the leaf encoder runs
;;; once per leaf, the interior encoder once per interior, and no key is ever
;;; routed.  Dirty pages are flushed to the device periodically so peak RAM is
;;; bounded by FLUSH-EVERY pages, not by the dataset size.
;;;
;;; Crash-safety is unchanged: nothing is durable until BTREE-COMMIT writes the
;;; single new meta; a crash mid-build leaves the OLD (empty) meta live and the
;;; half-written pages are unreferenced free tail, reclaimed/overwritten on retry.
;;;
;;; The result is a VALID B+tree holding exactly the input mapping: its physical
;;; page partition differs from incremental insertion (denser, balanced leaves)
;;; but the ordered key/value content — hence every lookup, the cursor scan, and
;;; the set-digest — is identical.  Separators are copies of subtree min-keys
;;; (standard B+tree bulk load), so routing matches INTERIOR-CHILD-INDEX exactly:
;;; child[i] holds keys < keys[i] = min-key of child[i+1]'s subtree.

(defun %bulk-build-leaf-level (bt next-fn leaf-cap flush-state)
  "Pull (KEY . VAL) conses from NEXT-FN (sorted ascending, unique) and pack them
   left-to-right into leaves, each filled to at most LEAF-CAP bytes (LEAF-CAP is
   already clamped to <= one page; a single entry always fits a page by the inline
   gate, so this never overflows a page).  Calls FLUSH-STATE after closing each
   leaf.  Returns (values level count): LEVEL a list of (page-index . min-key) in
   ascending order, COUNT the total number of entries."
  (let ((level '())
        (count 0)
        (cur (make-empty-leaf))
        (cur-bytes +leaf-hdr+)
        (cur-min nil)
        (prev-key nil))
    (flet ((close-leaf ()
             (when (> (length (leaf-keys cur)) 0)
               (let ((pg (cow-leaf bt cur)))
                 (push (cons pg cur-min) level)
                 (funcall flush-state))
               (setf cur (make-empty-leaf) cur-bytes +leaf-hdr+ cur-min nil))))
      (loop
        (let ((op (funcall next-fn)))
          (when (null op) (return))
          (let ((key (car op)) (val (cdr op)))
            (when (and prev-key (not (key< prev-key key)))
              (error "btree-bulk-build: input keys not strictly ascending"))
            (setf prev-key key)
            (multiple-value-bind (stored ovpg) (materialize-value bt key val)
              (let* ((overflowp (overflow-val-p stored))
                     (vlen (if overflowp (length (cdr stored)) (length stored)))
                     (esz (leaf-entry-bytes (length key) vlen overflowp)))
                ;; close the current leaf before it would exceed the fill target
                ;; (but always keep at least one entry per leaf — a lone oversized
                ;; entry lands in its own leaf, still <= a page by the inline gate).
                (when (and (> (length (leaf-keys cur)) 0)
                           (> (+ cur-bytes esz) leaf-cap))
                  (close-leaf))
                (when (zerop (length (leaf-keys cur)))
                  (setf cur-min (copy-seq key)))
                (leaf-vector-insert cur (length (leaf-keys cur)) key stored ovpg)
                (incf cur-bytes esz)
                (incf count))))))
      (close-leaf))
    (values (nreverse level) count)))

(defun %bulk-build-interior-level (bt level int-cap flush-state)
  "Group the (PAGE . MIN-KEY) entries of LEVEL (ascending, length >= 2) into
   interior nodes, each at most INT-CAP bytes (clamped <= one page).  The first
   child of a node carries no separator; each subsequent child contributes its
   subtree MIN-KEY as the separator preceding it; the node's own min-key is its
   first child's min-key (carried up to the parent level).  Calls FLUSH-STATE
   after closing each node.  Returns the parent level: (PAGE . MIN-KEY) ascending."
  (let ((out '())
        (cur (make-interior))
        (cur-bytes (+ +int-hdr+ 8))     ; header + first child pointer
        (cur-min nil)
        (firstp t))
    (flet ((close-int ()
             (let ((pg (cow-interior bt cur)))
               (push (cons pg cur-min) out)
               (funcall flush-state))
             (setf cur (make-interior) cur-bytes (+ +int-hdr+ 8) cur-min nil firstp t)))
      (dolist (entry level)
        (let ((child (car entry)) (mk (cdr entry)))
          (cond
            (firstp
             (vector-push-extend child (interior-children cur))
             (setf cur-min mk firstp nil))
            (t
             (let ((add (+ (interior-key-bytes (length mk)) 8)))
               (cond
                 ((> (+ cur-bytes add) int-cap)
                  ;; doesn't fit: close CUR, start a fresh node with this child first.
                  (close-int)
                  (vector-push-extend child (interior-children cur))
                  (setf cur-min mk firstp nil))
                 (t
                  (vector-push-extend (copy-seq mk) (interior-keys cur))
                  (vector-push-extend child (interior-children cur))
                  (incf cur-bytes add))))))))
      (close-int))
    (nreverse out)))

(defun btree-bulk-build (bt next-fn &key (leaf-fill 0.70) (interior-fill 0.90)
                                         (flush-every 8192))
  "Build a FRESH B+tree in BT from a sorted, ascending, duplicate-free stream of
   (KEY . VAL) conses delivered by NEXT-FN — a thunk returning the next cons or NIL
   at end of stream (VAL a byte vector; deletes are meaningless against an empty
   tree).  BT MUST be empty (root 0, entry-count 0).  Builds the leaf level then
   each interior level bottom-up (see the section header), encoding every page
   exactly once.  LEAF-FILL / INTERIOR-FILL are target fill fractions per page —
   headroom is left so a subsequent incremental insert need not immediately split.
   FLUSH-EVERY bounds the dirty-page working set (dirty pages are written to the
   device every FLUSH-EVERY node allocations, after which they are clean and
   evictable).  Sets BT's ROOT and ENTRY-COUNT; does NOT commit (caller commits).
   NEXT-FN must yield keys/values it will not mutate afterward."
  (unless (and (zerop (btree-root bt)) (zerop (btree-entry-count bt)))
    (error "btree-bulk-build requires an empty tree (root 0, no entries)"))
  (let* ((leaf-cap (min +page-size+ (max (1+ +leaf-hdr+)
                                         (floor (* leaf-fill +page-size+)))))
         (int-cap  (min +page-size+ (max (+ +int-hdr+ 16)
                                         (floor (* interior-fill +page-size+)))))
         (since 0))
    (flet ((flush-state ()
             (incf since)
             (when (>= since flush-every)
               (pager:pager-flush (btree-pager bt))
               (setf since 0))))
      (multiple-value-bind (level count)
          (%bulk-build-leaf-level bt next-fn leaf-cap #'flush-state)
        (cond
          ((null level)
           (setf (btree-root bt) 0 (btree-entry-count bt) 0))
          (t
           ;; lift level-by-level until a single root node remains.
           (loop while (cdr level)
                 do (setf level (%bulk-build-interior-level bt level int-cap #'flush-state)))
           (setf (btree-root bt) (car (first level))
                 (btree-entry-count bt) count)))))
    ;; flush the tail dirty pages now (commit will sync) so the post-build cache
    ;; is immediately back within budget.
    (pager:pager-flush (btree-pager bt))
    bt))

(defun btree-bulk-build-vector (bt ops &key sorted (leaf-fill 0.70)
                                            (interior-fill 0.90) (flush-every 8192))
  "Bulk-build BT from OPS, a sequence of (KEY . VAL) conses.  When :SORTED is NIL
   OPS is sorted ascending and duplicate keys coalesced (last wins) and any :DELETE
   ops dropped first; pass :SORTED T when OPS is ALREADY a simple-vector sorted
   ascending with unique keys and no deletes.  Convenience over BTREE-BULK-BUILD."
  (let* ((vec (cond (sorted (if (typep ops 'simple-vector) ops (coerce ops 'simple-vector)))
                    (t (remove-if #'op-delete-p (sort-batch ops)))))
         (n (length vec))
         (i 0))
    (btree-bulk-build bt
                      (lambda () (when (< i n) (prog1 (aref vec i) (incf i))))
                      :leaf-fill leaf-fill :interior-fill interior-fill
                      :flush-every flush-every)))

(defun btree-lookup-present-p (bt key)
  "T iff KEY exists (without reassembling overflow values).  Allocation-free
   descent: interiors and the leaf are probed in place."
  (let ((pager (btree-pager bt))
        (n (btree-root bt)))
    (when (zerop n) (return-from btree-lookup-present-p nil))
    (loop
      (let ((buf (pager:pager-get pager n)))
        (ecase (page-type buf)
          (#.+pt-interior+
           (setf n (interior-probe buf key)))
          (#.+pt-leaf+
           (return (and (leaf-probe buf key) t))))))))

;;; ====================================================================
;;;  Delete  (copy-on-write, with rebalance/merge)
;;; ====================================================================
;;;
;;; delete-rec returns (values new-page underflow-p deleted-p) where new-page is
;;; the CoW replacement for the subtree at N, underflow-p says the subtree is now
;;; below minimum occupancy (parent must rebalance/merge), deleted-p says a key
;;; was actually removed.

;;; Minimum occupancy: a node may shrink to 1 entry/child without forcing a merge
;;; only when it is the root.  For non-root nodes we treat "under half a page of
;;; payload" as underflow, but to keep merges always legal we use a simple count
;;; floor too: a leaf underflows at 0 entries; an interior underflows at 0 keys
;;; (1 child).  Merges are guarded by the combined-encoded-size <= page-size
;;; check, so this is correct though not maximally compact — adequate and simple.

(defun leaf-underflow-p (lf)
  (zerop (length (leaf-keys lf))))

(defun interior-underflow-p (it)
  (zerop (length (interior-keys it))))   ; only one child left

(defun delete-rec (bt n key)
  (let ((buf (pager:pager-get (btree-pager bt) n)))
    (ecase (page-type buf)
      (#.+pt-leaf+
       (let* ((lf (decode-leaf buf))
              (i (leaf-find lf key)))
         (cond
           ((null i) (values n nil nil))   ; not present, no CoW needed
           ((overflow-val-p (aref (leaf-vals lf) i))
            ;; deleting an overflow value: repack the survivors' blob.
            (let ((old-blob (leaf-load-overflow bt lf)))
              (leaf-vector-delete lf i)
              (free-page bt n)
              (when (/= old-blob 0) (free-overflow bt old-blob))
              (values (cow-leaf bt lf) (leaf-underflow-p lf) t)))
           (t
            ;; deleting an inline value: the blob (lazy markers + offsets) is
            ;; untouched — keep the existing chain, no rewrite.
            (leaf-vector-delete lf i)
            (free-page bt n)
            (values (cow-leaf-keep-blob bt lf) (leaf-underflow-p lf) t)))))
      (#.+pt-interior+
       (let* ((it (decode-interior buf))
              (ci (interior-child-index it key))
              (child (aref (interior-children it) ci)))
         (multiple-value-bind (new-child uf deleted) (delete-rec bt child key)
           (cond
             ((not deleted)
              ;; nothing changed below; no CoW of this interior needed.
              (values n nil nil))
             (t
              (free-page bt n)
              (setf (aref (interior-children it) ci) new-child)
              (when uf (rebalance-child bt it ci))
              (cond
                ((interior-underflow-p it)
                 (values (cow-interior bt it) t t))
                (t (values (cow-interior bt it) nil t)))))))))))

(defun leaf-vector-delete (lf i)
  (let ((n (length (leaf-keys lf))))
    (loop for j from i below (1- n)
          do (setf (aref (leaf-keys lf) j) (aref (leaf-keys lf) (1+ j))
                   (aref (leaf-vals lf) j) (aref (leaf-vals lf) (1+ j))
                   (aref (leaf-ovpgs lf) j) (aref (leaf-ovpgs lf) (1+ j))))
    (decf (fill-pointer (leaf-keys lf)))
    (decf (fill-pointer (leaf-vals lf)))
    (decf (fill-pointer (leaf-ovpgs lf)))))

;;; Rebalance child CI of interior IT which has underflowed.  We pull in a
;;; sibling: borrow if the sibling is comfortably full, else merge.  To keep the
;;; implementation simple and always-correct we MERGE the underflowed child with
;;; an adjacent sibling whenever the merged node fits in a page; otherwise we
;;; borrow one entry from the fuller sibling.  Children of IT are already CoW
;;; copies fetched fresh here (we re-CoW them).

(defun rebalance-child (bt it ci)
  (let* ((nch (length (interior-children it)))
         ;; pick a sibling (prefer left)
         (left-i (if (> ci 0) (1- ci) nil))
         (right-i (if (< ci (1- nch)) (1+ ci) nil)))
    (cond
      (left-i (merge-or-borrow bt it left-i ci))
      (right-i (merge-or-borrow bt it ci right-i))
      (t nil)))) ; only child; underflow propagates up

(defun page-is-leaf-p (bt n)
  (= (page-type (pager:pager-get (btree-pager bt) n)) +pt-leaf+))

(defun merge-or-borrow (bt it li ri)
  "LI, RI are adjacent child positions in IT (LI = RI-1).  The separator
   IT.keys[LI] sits between them.  Merge the two children into one if they fit,
   else borrow across them.  Updates IT in place (children/keys), CoW'ing the
   rewritten child page(s) and freeing the old ones."
  (let* ((lp (aref (interior-children it) li))
         (rp (aref (interior-children it) ri))
         (sep (aref (interior-keys it) li)))
    (if (page-is-leaf-p bt lp)
        (merge-or-borrow-leaves bt it li ri lp rp)
        (merge-or-borrow-interiors bt it li ri lp rp sep))))

(defun combined-leaf-size (a b)
  "Conservative OVERESTIMATE (full encodings minus one shared header)."
  (+ (leaf-encoded-size a)
     (- (leaf-encoded-size b) +leaf-hdr+)))

(defun merge-or-borrow-leaves (bt it li ri lp rp)
  (let ((la (decode-leaf (pager:pager-get (btree-pager bt) lp)))
        (lb (decode-leaf (pager:pager-get (btree-pager bt) rp))))
    ;; Materialize BOTH overflow blobs first: entries move between leaves, so
    ;; their values must be carried as bytes (offsets are blob-relative and would
    ;; otherwise be wrong in the destination leaf's repacked blob).  Free both old
    ;; chains; cow-leaf repacks each result.
    (let ((ba (leaf-load-overflow bt la))
          (bb (leaf-load-overflow bt lb)))
      (when (/= ba 0) (free-overflow bt ba))
      (when (/= bb 0) (free-overflow bt bb)))
    (cond
      ((<= (combined-leaf-size la lb) +page-size+)
       ;; MERGE rp into lp
       (loop for i below (length (leaf-keys lb))
             do (vector-push-extend (aref (leaf-keys lb) i) (leaf-keys la))
                (vector-push-extend (aref (leaf-vals lb) i) (leaf-vals la))
                (vector-push-extend (aref (leaf-ovpgs lb) i) (leaf-ovpgs la)))
       (free-page bt lp) (free-page bt rp)
       (let ((new (cow-leaf bt la)))
         (setf (aref (interior-children it) li) new)
         (interior-remove-key-child it li ri)))
      (t
       ;; BORROW: move one entry from the fuller leaf to the emptier across sep.
       (let ((emptier (if (< (length (leaf-keys la)) (length (leaf-keys lb))) :left :right)))
         (free-page bt lp) (free-page bt rp)
         (cond
           ((eq emptier :left)
            ;; move first entry of lb to end of la
            (vector-push-extend (aref (leaf-keys lb) 0) (leaf-keys la))
            (vector-push-extend (aref (leaf-vals lb) 0) (leaf-vals la))
            (vector-push-extend (aref (leaf-ovpgs lb) 0) (leaf-ovpgs la))
            (leaf-vector-delete lb 0)
            (setf (aref (interior-keys it) li) (copy-seq (aref (leaf-keys lb) 0))))
           (t
            ;; move last entry of la to front of lb
            (let ((j (1- (length (leaf-keys la)))))
              (leaf-vector-insert lb 0 (aref (leaf-keys la) j)
                                  (aref (leaf-vals la) j) (aref (leaf-ovpgs la) j))
              (leaf-vector-delete la j))
            (setf (aref (interior-keys it) li) (copy-seq (aref (leaf-keys lb) 0)))))
         (setf (aref (interior-children it) li) (cow-leaf bt la)
               (aref (interior-children it) ri) (cow-leaf bt lb)))))))

(defun combined-interior-size (a sep b)
  "Conservative OVERESTIMATE of the merged interior's encoded size (sum of both
   full encodings + the separator).  Overestimating only makes us borrow instead
   of merge — always safe; merging only happens when it definitely fits."
  (+ (interior-encoded-size a)
     (interior-key-bytes (length sep))
     (interior-encoded-size b)))

(defun merge-or-borrow-interiors (bt it li ri lp rp sep)
  (let ((ia (decode-interior (pager:pager-get (btree-pager bt) lp)))
        (ib (decode-interior (pager:pager-get (btree-pager bt) rp))))
    (cond
      ((<= (combined-interior-size ia sep ib) +page-size+)
       ;; MERGE: ia + sep + ib
       (vector-push-extend (copy-seq sep) (interior-keys ia))
       (loop for k below (length (interior-keys ib))
             do (vector-push-extend (aref (interior-keys ib) k) (interior-keys ia)))
       (loop for c below (length (interior-children ib))
             do (vector-push-extend (aref (interior-children ib) c) (interior-children ia)))
       (free-page bt lp) (free-page bt rp)
       (let ((new (cow-interior bt ia)))
         (setf (aref (interior-children it) li) new)
         (interior-remove-key-child it li ri)))
      (t
       ;; BORROW across sep (rotate one child+key).
       (free-page bt lp) (free-page bt rp)
       (cond
         ((< (length (interior-keys ia)) (length (interior-keys ib)))
          ;; rotate left: sep down into ia, ib.keys[0] up to sep, ib.child[0] to ia
          (vector-push-extend (copy-seq sep) (interior-keys ia))
          (vector-push-extend (aref (interior-children ib) 0) (interior-children ia))
          (setf (aref (interior-keys it) li) (copy-seq (aref (interior-keys ib) 0)))
          (interior-remove-key-child ib 0 0))
         (t
          ;; rotate right: sep down into ib front, ia.keys[last] up to sep, ia.child[last] to ib front
          (let ((lastk (1- (length (interior-keys ia))))
                (lastc (1- (length (interior-children ia)))))
            (interior-prepend ib (copy-seq sep) (aref (interior-children ia) lastc))
            (setf (aref (interior-keys it) li) (copy-seq (aref (interior-keys ia) lastk)))
            (decf (fill-pointer (interior-keys ia)))
            (decf (fill-pointer (interior-children ia))))))
       (setf (aref (interior-children it) li) (cow-interior bt ia)
             (aref (interior-children it) ri) (cow-interior bt ib))))))

(defun interior-prepend (it key child0)
  "Insert CHILD0 at front of children and KEY at front of keys."
  (vector-push-extend nil (interior-keys it))
  (loop for i from (1- (length (interior-keys it))) downto 1
        do (setf (aref (interior-keys it) i) (aref (interior-keys it) (1- i))))
  (setf (aref (interior-keys it) 0) key)
  (vector-push-extend nil (interior-children it))
  (loop for i from (1- (length (interior-children it))) downto 1
        do (setf (aref (interior-children it) i) (aref (interior-children it) (1- i))))
  (setf (aref (interior-children it) 0) child0))

(defun interior-remove-key-child (it ki ci)
  "Remove key at KI and child at CI from interior IT."
  (loop for j from ki below (1- (length (interior-keys it)))
        do (setf (aref (interior-keys it) j) (aref (interior-keys it) (1+ j))))
  (decf (fill-pointer (interior-keys it)))
  (loop for j from ci below (1- (length (interior-children it)))
        do (setf (aref (interior-children it) j) (aref (interior-children it) (1+ j))))
  (decf (fill-pointer (interior-children it))))

(defun btree-delete (bt key)
  "Delete KEY if present."
  (let ((root (btree-root bt)))
    (when (zerop root) (return-from btree-delete bt))
    (multiple-value-bind (new-root uf deleted) (delete-rec bt root key)
      (declare (ignore uf))
      (when deleted
        (decf (btree-entry-count bt))
        ;; collapse a root interior that has shrunk to a single child
        (let ((nrbuf (pager:pager-get (btree-pager bt) new-root)))
          (when (= (page-type nrbuf) +pt-interior+)
            (let ((it (decode-interior nrbuf)))
              (when (= (length (interior-children it)) 1)
                (let ((only (aref (interior-children it) 0)))
                  (free-page bt new-root)
                  (setf new-root only))))))
        ;; if the root leaf is now empty, the tree is empty
        (let ((nrbuf (pager:pager-get (btree-pager bt) new-root)))
          (when (and (= (page-type nrbuf) +pt-leaf+)
                     (zerop (length (leaf-keys (decode-leaf nrbuf)))))
            (free-page bt new-root)
            (setf new-root 0)))
        (setf (btree-root bt) new-root)))
    bt))

;;; ====================================================================
;;;  Cursor — ordered forward iteration
;;; ====================================================================
;;;
;;; A simple stack-based in-order walk.  Each cursor element is (page . idx).
;;; cursor-first descends to the leftmost leaf; cursor-next advances.

(defstruct (cursor (:constructor %make-cursor))
  btree
  stack         ; list of (page-index . next-child-index) for interiors
  leaf          ; current decoded leaf or NIL
  leaf-idx)     ; index within current leaf

(defun btree-cursor (bt) (%make-cursor :btree bt))

(defun cursor-descend-left (cur page)
  "From PAGE, descend to the leftmost leaf, pushing interior frames."
  (let ((bt (cursor-btree cur)))
    (loop
      (let ((buf (pager:pager-get (btree-pager bt) page)))
        (ecase (page-type buf)
          (#.+pt-interior+
           (let ((it (decode-interior buf)))
             ;; push frame: we're consuming child 0, next is child 1
             (push (cons it 1) (cursor-stack cur))
             (setf page (aref (interior-children it) 0))))
          (#.+pt-leaf+
           (setf (cursor-leaf cur) (decode-leaf buf)
                 (cursor-leaf-idx cur) 0)
           (return)))))))

(defun cursor-first (cur)
  "Position CUR at the first (smallest) key.  Returns T if any, NIL if empty."
  (let* ((bt (cursor-btree cur))
         (root (btree-root bt)))
    (setf (cursor-stack cur) nil (cursor-leaf cur) nil (cursor-leaf-idx cur) nil)
    (when (zerop root) (return-from cursor-first nil))
    (cursor-descend-left cur root)
    (cursor-skip-empty-leaves cur)))

(defun leaf-lower-bound (lf key)
  "Index of the first entry in leaf LF whose key is >= KEY (its length if none)."
  (let ((n (length (leaf-keys lf))))
    (dotimes (i n n)
      (unless (key< (aref (leaf-keys lf) i) key) (return i)))))

(defun cursor-seek (cur key)
  "Position CUR at the first entry whose key is >= KEY (lower bound).  Returns T
   if such an entry exists, NIL if KEY is past the last key.  Descends like
   BTREE-LOOKUP, but records the next unconsumed child at each interior so that
   CURSOR-NEXT continues the in-order walk from the seek point."
  (let* ((bt (cursor-btree cur))
         (page (btree-root bt)))
    (setf (cursor-stack cur) nil (cursor-leaf cur) nil (cursor-leaf-idx cur) nil)
    (when (zerop page) (return-from cursor-seek nil))
    (loop
      (let ((buf (pager:pager-get (btree-pager bt) page)))
        (ecase (page-type buf)
          (#.+pt-interior+
           (let* ((it (decode-interior buf))
                  (ci (interior-child-index it key)))
             ;; we descend into child CI; the next subtree to visit is CI+1
             (push (cons it (1+ ci)) (cursor-stack cur))
             (setf page (aref (interior-children it) ci))))
          (#.+pt-leaf+
           (let ((lf (decode-leaf buf)))
             (setf (cursor-leaf cur) lf
                   (cursor-leaf-idx cur) (leaf-lower-bound lf key))
             (return))))))
    ;; if every key in the landing leaf is < KEY, walk on to the next subtree
    (cursor-skip-empty-leaves cur)))

(defun cursor-skip-empty-leaves (cur)
  "Ensure CUR sits on a non-empty leaf entry, advancing across empty leaves.
   Returns T if positioned on an entry, NIL if exhausted."
  (loop
    (let ((lf (cursor-leaf cur)))
      (when (and lf (< (cursor-leaf-idx cur) (length (leaf-keys lf))))
        (return t))
      ;; current leaf exhausted; pop interior frames to find next subtree
      (unless (cursor-advance-subtree cur)
        (return nil)))))

(defun cursor-advance-subtree (cur)
  "Pop frames until one has an unconsumed child, descend its left spine.
   Returns T if a new leaf was loaded, NIL if the tree is exhausted."
  (let ((bt (cursor-btree cur)))
    (loop
      (when (null (cursor-stack cur))
        (setf (cursor-leaf cur) nil)
        (return nil))
      (destructuring-bind (it . next) (first (cursor-stack cur))
        (cond
          ((< next (length (interior-children it)))
           (setf (cdr (first (cursor-stack cur))) (1+ next))
           (cursor-descend-left cur (aref (interior-children it) next))
           (return t))
          (t (pop (cursor-stack cur))))))))

(defun cursor-next (cur)
  "Advance to the next entry.  Returns T if positioned on an entry, else NIL."
  (let ((lf (cursor-leaf cur)))
    (when (null lf) (return-from cursor-next nil))
    (incf (cursor-leaf-idx cur))
    (cursor-skip-empty-leaves cur)))

(defun cursor-key (cur)
  (let ((lf (cursor-leaf cur)))
    (when (and lf (< (cursor-leaf-idx cur) (length (leaf-keys lf))))
      (aref (leaf-keys lf) (cursor-leaf-idx cur)))))

(defun cursor-value (cur)
  (let ((lf (cursor-leaf cur)))
    (when (and lf (< (cursor-leaf-idx cur) (length (leaf-keys lf))))
      (let* ((i (cursor-leaf-idx cur))
             (val (aref (leaf-vals lf) i)))
        (cond
          ((and (consp val) (eq (car val) :overflow))
           ;; slice from the leaf's packed blob (offset in OVPGS, head in leaf).
           (read-blob-slice (cursor-btree cur) (leaf-blob-head lf)
                            (aref (leaf-ovpgs lf) i) (cdr val)))
          ((and (consp val) (eq (car val) :overflow-bytes)) (cdr val))
          (t val))))))

;;; ====================================================================
;;;  Persistent freelist — serialize the free set, commit-atomic
;;; ====================================================================
;;;
;;; THE FREE SET AS OF THIS COMMIT.  Three disjoint groups of pages become free
;;; (or stay free) when this txn commits:
;;;   R = the pager freelist now      — pages already free in the committed state
;;;                                     (reusable RIGHT NOW; not in the old tree).
;;;   P = pending-frees this txn      — committed-tree pages we freed; still live
;;;                                     under the OLD meta, so NOT reusable yet.
;;;   O = old freelist-chain pages    — they hold the OLD meta's freelist; also
;;;                                     still live under the OLD meta, NOT reusable.
;;; After this commit's meta is durable, all of R∪P∪O are free and reusable.
;;;
;;; SELF-ALLOCATION SAFETY.  Storing the set itself consumes pages (the freelist
;;; pages), and we must write them BEFORE the meta (same sync as the tree data).
;;; A page we write pre-meta MUST NOT be one the OLD live meta still references —
;;; else a crash before the meta swap would corrupt OLD-meta recovery.  So the
;;; freelist-page storage may come ONLY from R (free in the committed state) or
;;; from a fresh dev-grow — exactly what btree-alloc/pager-alloc draw from; never
;;; from P or O.  Those allocations are txn-allocated (unreferenced by any meta),
;;; so they are safe pre-meta writes.
;;;
;;; CONVERGENCE.  Let S = R∪P∪O (the candidate free set).  We must pick K
;;; freelist pages and persist F = S minus whichever of those K came out of S
;;; (alloc from R removes from S; a grown page does not).  K must satisfy
;;; ceil(|F| / cap) <= K.  Since drawing a freelist page from S shrinks |F| by 1
;;; while adding 1 to K, both sides move the right way; iterating K upward from
;;; ceil(|S|/cap) converges immediately.  We compute K against the worst case
;;; (none drawn from S, |F| = |S|), so K is always sufficient regardless of how
;;; many allocations actually grew the device; any slack just leaves the last
;;; freelist page partly empty (or one spare page on the chain), reclaimed next
;;; commit.

(defun compute-free-set (bt)
  "The set S = R∪P∪O of pages free as of this commit, as a list (no dups; the
   three groups are disjoint by construction)."
  (let ((s (pager::pager-freelist-indices (btree-pager bt))))   ; R
    (dolist (n (btree-pending-frees bt)) (push n s))            ; P
    ;; O — the old committed freelist chain pages (the pages themselves, which
    ;; held the previous free set; they are now reclaimable).
    (let ((p (btree-committed-freelist-head bt)))
      (loop while (/= p 0)
            do (multiple-value-bind (next idx)
                   (decode-freelist-chunk (pager:pager-get (btree-pager bt) p))
                 (declare (ignore idx))
                 (push p s)
                 (setf p next))))
    s))

(defun freelist-pages-needed (n cap)
  "How many freelist pages K to persist N free indices, accounting for the fact
   that each freelist page we draw from the free set would itself shrink N.  We
   size for the WORST case (no page drawn from the set), so K is always enough."
  (if (zerop n) 0 (ceiling n cap)))

(defun write-freelist (bt)
  "Serialize the free set as of this commit into a fresh on-disk freelist chain.
   Returns (values head count) for the new META.  Pages for the chain are
   allocated via BTREE-ALLOC (drawn from R or a fresh grow — never from P/O), so
   writing them pre-meta cannot corrupt OLD-meta recovery.  Self-allocation-safe
   per the convergence note above."
  (let* ((cap (freelist-capacity))
         (s (compute-free-set bt))
         (k (freelist-pages-needed (length s) cap)))
    (when (zerop k)
      (return-from write-freelist (values 0 0)))
    ;; Allocate the K chain pages first.  Each alloc may consume a page from S
    ;; (if it came from R, it's an EQ member of S) — remove those from the set we
    ;; persist so we never record a page that now holds the freelist itself.
    (let ((chain (loop repeat k collect (btree-alloc bt)))
          (taken (make-hash-table)))
      (dolist (n chain) (setf (gethash n taken) t))
      (let* ((free (remove-if (lambda (n) (gethash n taken)) s))
             (free-vec (coerce free 'vector))
             (count (length free-vec)))
        ;; Distribute COUNT entries across the K pages (<= cap each).  K was sized
        ;; for the worst case so it always fits; the tail page may be short/empty.
        (loop with off = 0
              for tail on chain
              for page = (car tail)
              for next = (if (cdr tail) (cadr tail) 0)
              for this = (min cap (max 0 (- count off)))
              do (let ((buf (pager:pager-get (btree-pager bt) page)))
                   (encode-freelist buf next free-vec off this)
                   (pager:pager-dirty (btree-pager bt) page))
                 (incf off this))
        (values (first chain) count)))))

;;; ====================================================================
;;;  Commit — flush, sync, swap meta, sync
;;; ====================================================================

(defun btree-commit (bt)
  "Atomically commit the current tree state.  Serialize the free set into a fresh
   on-disk freelist chain, flush+sync all data + freelist pages, then write the
   new META (referencing that chain) into the inactive slot and flush+sync — the
   commit point.  The freelist becomes live atomically with the meta."
  (let* ((pager (btree-pager bt))
         (new-txn (1+ (btree-txn-id bt)))
         (target (if (= (btree-live-slot bt) +meta-slot-0+) +meta-slot-1+ +meta-slot-0+)))
    ;; 1a. serialize the free set into a fresh freelist chain (allocates only from
    ;;     R / fresh grow — never from the still-live P/O pages).
    (multiple-value-bind (fl-head fl-count) (write-freelist bt)
      (let ((m (make-meta :txn-id new-txn
                          :root (btree-root bt)
                          :freelist-head fl-head
                          :free-count fl-count
                          :entry-count (btree-entry-count bt)
                          :high-water (btree-high-water bt))))
        ;; 1b. all tree/data/freelist pages durable BEFORE the meta references them
        (pager:pager-flush pager)
        (pager:pager-sync pager)
        ;; 2. write the new meta into the inactive slot.  The two meta slots are
        ;;    FIXED page locations (0/1) — not CoW-relocatable — so we encode into
        ;;    the slot's buffer and dirty it in the same synchronous step (nothing
        ;;    reads or evicts between, and a torn write fails the checksum on
        ;;    reopen, falling back to the other slot).
        (let ((buf (pager:pager-get pager target)))
          (encode-meta m buf)
          (pager:pager-dirty pager target))
        ;; 3. the commit point
        (pager:pager-flush pager)
        (pager:pager-sync pager)
        (setf (btree-txn-id bt) new-txn
              (btree-live-slot bt) target)
        ;; The just-committed meta no longer references the OLD tree's pages, the
        ;; OLD freelist chain, or the now-superseded deferred frees — and the meta
        ;; swap is durable — so all deferred pages (P) AND the old freelist chain
        ;; (O) are now safe to reuse.  Return them to the pager freelist; that
        ;; in-memory set now matches exactly the free set we just persisted.
        (dolist (n (btree-pending-frees bt)) (pager:pager-free pager n))
        (let ((p (btree-committed-freelist-head bt)))
          (loop while (/= p 0)
                do (multiple-value-bind (next idx)
                       (decode-freelist-chunk (pager:pager-get pager p))
                     (declare (ignore idx))
                     (pager:pager-free pager p)
                     (setf p next))))
        (setf (btree-pending-frees bt) '()
              (btree-committed-freelist-head bt) fl-head
              (btree-committed-free-count bt) fl-count)
        (clrhash (btree-txn-allocated bt))
        bt))))
