;;;; src/store.lisp — public KV API: store lifecycle, transactions, cursors.
;;;;
;;;; Ties device + pager + btree together.  Single-writer: at most one write
;;;; txn at a time; reads see the last committed root.  with-write-txn commits
;;;; on normal exit and aborts on a non-local exit (unwind).

(in-package #:pagetree)

(define-condition pagetree-error (error)
  ((message :initarg :message :initform nil :reader pagetree-error-message))
  (:report (lambda (c s)
             (format s "pagetree error~@[: ~a~]" (pagetree-error-message c)))))

(define-condition corrupt-store (pagetree-error) ())

;;; ---------------------------------------------------------------------
;;;  Store / transaction objects
;;; ---------------------------------------------------------------------

(defstruct store
  device
  pager
  btree            ; the open btree (its root tracks the last committed state)
  path
  (write-active nil)) ; a write txn is in flight

(defstruct txn
  store
  (mode :read)     ; :read or :write
  (open t))        ; nil once committed/aborted

;;; ---------------------------------------------------------------------
;;;  open / close
;;; ---------------------------------------------------------------------

(defun open-store (path &key page-size cache-bytes create)
  "Open (or create) a store.  PATH NIL => in-RAM (mem device); otherwise a file
   device.  Returns a STORE."
  (declare (ignore create))
  (let* ((ps (or page-size pagetree.device:+default-page-size+))
         (device (if (null path)
                     (pagetree.device:make-mem-device :page-size ps)
                     (pagetree.device:make-file-device path :page-size ps :create t)))
         (pager (if cache-bytes
                    (pagetree.pager:make-pager device :cache-bytes cache-bytes)
                    (pagetree.pager:make-pager device)))
         (btree (pagetree.btree:btree-open pager)))
    (make-store :device device :pager pager :btree btree :path path)))

(defun close-store (store)
  "Flush and close the store.  (Mem devices simply drop; nothing to do.)"
  (when (store-pager store)
    (pagetree.pager:pager-flush (store-pager store))
    (pagetree.pager:pager-sync (store-pager store)))
  (setf (store-pager store) nil
        (store-btree store) nil)
  t)

;;; ---------------------------------------------------------------------
;;;  Transactions
;;; ---------------------------------------------------------------------

(defun begin-txn (store mode)
  (when (and (eq mode :write) (store-write-active store))
    (error 'pagetree-error :message "a write transaction is already active"))
  (when (eq mode :write) (setf (store-write-active store) t))
  (make-txn :store store :mode mode))

(defun commit-txn (txn)
  "Commit a write txn (no-op for a read txn).  After commit the txn is closed."
  (unless (txn-open txn)
    (error 'pagetree-error :message "transaction is already closed"))
  (let ((store (txn-store txn)))
    (when (eq (txn-mode txn) :write)
      (pagetree.btree:btree-commit (store-btree store))
      (setf (store-write-active store) nil)))
  (setf (txn-open txn) nil)
  t)

(defun abort-txn (txn)
  "Abort a txn.  For a write txn, re-open the btree from the last committed meta
   so any uncommitted CoW pages are discarded (they're just unreferenced free
   space; the live meta still points at the old root)."
  (unless (txn-open txn)
    (return-from abort-txn t))
  (let ((store (txn-store txn)))
    (when (eq (txn-mode txn) :write)
      ;; Discard in-memory dirty state and re-derive the tree from the live meta.
      (let* ((device (store-device store))
             (pager (pagetree.pager:make-pager device)))
        (setf (store-pager store) pager
              (store-btree store) (pagetree.btree:btree-open pager)))
      (setf (store-write-active store) nil)))
  (setf (txn-open txn) nil)
  t)

(defmacro with-write-txn ((txn store) &body body)
  "Run BODY with a write txn bound to TXN; commit on normal exit, abort on a
   non-local exit (unwind)."
  (let ((ok (gensym "OK")) (s (gensym "STORE")))
    `(let* ((,s ,store)
            (,txn (begin-txn ,s :write))
            (,ok nil))
       (unwind-protect
            (multiple-value-prog1 (progn ,@body)
              (commit-txn ,txn)
              (setf ,ok t))
         (unless ,ok
           (when (txn-open ,txn) (abort-txn ,txn)))))))

(defmacro with-read-txn ((txn store) &body body)
  "Run BODY with a read txn bound to TXN (snapshot = last committed root)."
  (let ((s (gensym "STORE")))
    `(let* ((,s ,store)
            (,txn (begin-txn ,s :read)))
       (unwind-protect (progn ,@body)
         (when (txn-open ,txn) (setf (txn-open ,txn) nil))))))

;;; ---------------------------------------------------------------------
;;;  KV operations
;;; ---------------------------------------------------------------------

(defun %bt (txn) (store-btree (txn-store txn)))

(defun %as-bytes (v)
  (if (typep v '(simple-array (unsigned-byte 8) (*)))
      v
      (coerce v '(simple-array (unsigned-byte 8) (*)))))

(defun tput (txn key val)
  "Insert/replace KEY -> VAL (byte vectors).  Requires a write txn."
  (unless (eq (txn-mode txn) :write)
    (error 'pagetree-error :message "tput requires a write transaction"))
  (pagetree.btree:btree-insert (%bt txn) (%as-bytes key) (%as-bytes val))
  t)

(defun tget (txn key)
  "Return the value for KEY, or NIL."
  (pagetree.btree:btree-lookup (%bt txn) (%as-bytes key)))

(defun tapply-batch (txn ops &key sorted)
  "Apply a BATCH of operations in ONE coordinated copy-on-write pass — the fast
   path for flushing a staging buffer (e.g. cl-consensus's per-checkpoint UTXO
   set).  Requires a write txn.

   OPS is a sequence of (KEY . VAL) conses where VAL is a byte vector (put) or
   the keyword :DELETE (delete).  Keys/values may be any (unsigned-byte 8)
   sequence; they are coerced as needed.  Unless :SORTED is T (meaning OPS is
   ALREADY a simple-vector sorted ascending by key with unique keys), OPS is
   sorted by key and duplicate keys coalesced (last wins) first.

   Semantically identical to TPUT/TDEL'ing the ops one-by-one in key order, but
   amortizes the root-to-leaf descent and page copies across the whole batch.
   Commits with the enclosing write txn (does not commit itself)."
  (unless (eq (txn-mode txn) :write)
    (error 'pagetree-error :message "tapply-batch requires a write transaction"))
  (let ((vec (if sorted
                 (if (typep ops 'simple-vector) ops (coerce ops 'simple-vector))
                 ;; normalize key/val byte types up front, then let the btree sort.
                 (let ((out (make-array (length ops))))
                   (let ((i 0))
                     (map nil (lambda (op)
                                (setf (aref out i)
                                      (cons (%as-bytes (car op))
                                            (if (eq (cdr op) :delete)
                                                :delete
                                                (%as-bytes (cdr op)))))
                                (incf i))
                          ops))
                   out))))
    (pagetree.btree:btree-apply-batch (%bt txn) vec :sorted sorted))
  t)

(defun tbulk-build (txn ops &key sorted (leaf-fill 0.70) (interior-fill 0.90)
                                 (flush-every 8192))
  "Bulk-build the store's tree from OPS in one BOTTOM-UP sequential pass — the fast
   path for loading a LARGE dataset into an EMPTY store (migrating or rebuilding a
   UTXO set, IBD from a checkpoint, etc.).  Unlike TPUT/TAPPLY-BATCH, which descend
   the tree per key, this writes every page exactly once: O(N) sequential writes
   instead of O(N·height) descents+copies, so it does not degrade as the tree
   grows — the cure for the random-key bulk-load wall.

   OPS is a sequence of (KEY . VAL) conses (VAL a byte vector); keys/values may be
   any (unsigned-byte 8) sequence (coerced as needed).  Unless :SORTED is T, OPS is
   sorted ascending and duplicate keys coalesced (last wins) first; pass :SORTED T
   only when OPS is ALREADY a simple-vector sorted ascending with unique keys and
   no deletes.  LEAF-FILL/INTERIOR-FILL are the per-page target fill fractions
   (headroom left for later incremental inserts); FLUSH-EVERY bounds peak RAM
   during the build.  Requires a write txn AND an EMPTY store (no committed data);
   commits with the enclosing write txn (does not commit itself)."
  (unless (eq (txn-mode txn) :write)
    (error 'pagetree-error :message "tbulk-build requires a write transaction"))
  (let ((vec (if sorted
                 (if (typep ops 'simple-vector) ops (coerce ops 'simple-vector))
                 ;; normalize key/val byte types; the btree layer sorts + coalesces.
                 (let ((out (make-array (length ops))) (i 0))
                   (map nil (lambda (op)
                              (setf (aref out i)
                                    (cons (%as-bytes (car op))
                                          (if (eq (cdr op) :delete)
                                              :delete
                                              (%as-bytes (cdr op)))))
                              (incf i))
                        ops)
                   out))))
    (pagetree.btree:btree-bulk-build-vector (%bt txn) vec :sorted sorted
                                            :leaf-fill leaf-fill
                                            :interior-fill interior-fill
                                            :flush-every flush-every))
  t)

(defun tbulk-build-stream (txn next-fn &key (leaf-fill 0.70) (interior-fill 0.90)
                                            (flush-every 8192))
  "Bulk-build the store's tree from a STREAM: NEXT-FN is a thunk returning the next
   (KEY . VALUE) cons (KEY/VALUE already (unsigned-byte 8) vectors) in STRICT
   ascending key order with no duplicates, or NIL at end.  Same bottom-up O(N)
   sequential build as TBULK-BUILD, but driven by a generator rather than a
   materialized sequence — so a caller can MERGE two sorted sources (e.g. an
   existing tree's cursor with a sorted change-set) straight into a fresh tree
   without ever holding the whole result in RAM.  Requires a write txn AND an empty
   store; commits with the enclosing write txn."
  (unless (eq (txn-mode txn) :write)
    (error 'pagetree-error :message "tbulk-build-stream requires a write transaction"))
  (pagetree.btree:btree-bulk-build (%bt txn) next-fn
                                   :leaf-fill leaf-fill :interior-fill interior-fill
                                   :flush-every flush-every)
  t)

(defun tdel (txn key)
  "Delete KEY if present.  Requires a write txn."
  (unless (eq (txn-mode txn) :write)
    (error 'pagetree-error :message "tdel requires a write transaction"))
  (pagetree.btree:btree-delete (%bt txn) (%as-bytes key))
  t)

;;; ---------------------------------------------------------------------
;;;  Cursor (ordered forward scan)
;;; ---------------------------------------------------------------------

(defstruct cursor inner)

(defun tcursor (txn)
  (make-cursor :inner (pagetree.btree:btree-cursor (%bt txn))))

(defun cursor-first (cur)
  (pagetree.btree::cursor-first (cursor-inner cur)))

(defun cursor-seek (cur key)
  "Position CUR at the first entry whose key is >= KEY (lower bound).  Returns T
   if positioned on an entry, NIL if KEY is past the last key.  The basis for
   prefix range scans: seek to the prefix, then CURSOR-NEXT while the key still
   has it."
  (pagetree.btree:cursor-seek (cursor-inner cur) (%as-bytes key)))

(defun cursor-next (cur)
  (pagetree.btree::cursor-next (cursor-inner cur)))

(defun cursor-key (cur)
  (pagetree.btree::cursor-key (cursor-inner cur)))

(defun cursor-value (cur)
  (pagetree.btree::cursor-value (cursor-inner cur)))
