;;;; src/device.lisp  — Layer 0: block-device protocol + in-RAM backend.
;;;;
;;;; The ONLY platform seam.  A device is a fixed-page-size array of pages.
;;;; Everything above (pager, btree) is pure ANSI CL.  Backends: mem (here, for
;;;; tests + fault injection), file (device-file.lisp), modus driver (later).

(in-package #:pagetree.device)

(defconstant +default-page-size+ 4096)

;;; Protocol — implement these for each backend.
(defgeneric dev-read-page (dev n buf)
  (:documentation "Fill BUF (a (page-size) (unsigned-byte 8) vector) with page N."))
(defgeneric dev-write-page (dev n buf)
  (:documentation "Persist BUF as page N."))
(defgeneric dev-sync (dev)
  (:documentation "Durability barrier: prior writes are on stable storage."))
(defgeneric dev-grow (dev k)
  (:documentation "Append K zero pages; return the index of the first new page."))
(defgeneric dev-page-count (dev))
(defgeneric dev-page-size (dev))

;;; -------------------------------------------------------------------------
;;; In-RAM backend.  Pages persist for the life of the object (so a "reopen"
;;; in a crash test = a new pager/btree over the SAME mem-device).  FAIL-AFTER
;;; injects a crash: the Nth dev-write-page (and onward) signals, simulating a
;;; process death mid-commit — for the no-WAL recovery tests.
;;; -------------------------------------------------------------------------
(defclass mem-device ()
  ((pages :initform (make-array 0 :adjustable t :fill-pointer 0))
   (page-size :initarg :page-size :reader %ps)
   (fail-after :initarg :fail-after :accessor mem-fail-after)
   (writes :initform 0 :accessor mem-writes)))

(defun make-mem-device (&key (page-size +default-page-size+) fail-after)
  "An in-RAM device.  FAIL-AFTER N => the Nth write onward errors (crash sim)."
  (make-instance 'mem-device :page-size page-size :fail-after fail-after))

(defmethod dev-page-size ((d mem-device)) (%ps d))
(defmethod dev-page-count ((d mem-device)) (fill-pointer (slot-value d 'pages)))

(defmethod dev-read-page ((d mem-device) n buf)
  (replace buf (aref (slot-value d 'pages) n))
  buf)

(defmethod dev-write-page ((d mem-device) n buf)
  (when (and (mem-fail-after d) (>= (incf (mem-writes d)) (mem-fail-after d)))
    (error "mem-device: injected write fault (write ~d)" (mem-writes d)))
  (replace (aref (slot-value d 'pages) n) buf)
  (values))

(defmethod dev-grow ((d mem-device) k)
  (let* ((pages (slot-value d 'pages)) (start (fill-pointer pages)))
    (dotimes (i k)
      (vector-push-extend
       (make-array (%ps d) :element-type '(unsigned-byte 8) :initial-element 0)
       pages))
    start))

(defmethod dev-sync ((d mem-device)) (values))
