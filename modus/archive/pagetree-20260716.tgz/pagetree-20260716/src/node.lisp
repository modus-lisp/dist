;;;; src/node.lisp — Layer 2: page codec (meta / interior / leaf / overflow).
;;;;
;;;; On-page byte layouts and (de)serialization to/from a (page-size) buffer.
;;;; Pure ANSI CL.  All multi-byte integers are little-endian.
;;;;
;;;; Page kinds (byte 0 = type tag):
;;;;   +pt-meta+      double-buffered, checksummed superblock (pages 0 & 1)
;;;;   +pt-interior+  sorted separator keys + child page indices
;;;;   +pt-leaf+      sorted key/value entries (values inline or via overflow)
;;;;   +pt-overflow+  a chunk of a value too large to fit inline in a leaf
;;;;
;;;; A "node" in memory is a plain struct decoded from a page; encoding writes it
;;;; back into a fresh page buffer.  The btree owns page allocation; this file is
;;;; only the codec + a couple of size estimators used by the split logic.

(in-package #:pagetree.btree)

(defconstant +page-size+ pagetree.device:+default-page-size+)

;;; ---- little-endian integer accessors -----------------------------------
;;;
;;; A page buffer is always a (SIMPLE-ARRAY (UNSIGNED-BYTE 8) (*)) handed back
;;; by the pager (it MAKE-ARRAYs exactly that element type, and dev-read-page
;;; fills it).  PAGE-BUF is the type the read hot path declares so SBCL compiles
;;; AREF to a direct bounds-checked ub8 load instead of the generic
;;; HAIRY-DATA-VECTOR-REF path that dominated the lookup profile.
(deftype page-buf () '(simple-array (unsigned-byte 8) (*)))

(declaim (inline u8ref (setf u8ref)))
(defun u8ref (buf i) (aref buf i))
(defun (setf u8ref) (v buf i) (setf (aref buf i) v))

(defun rd-uint (buf off n)
  "Read an N-byte little-endian unsigned integer from BUF at OFF."
  (let ((v 0))
    (dotimes (i n v)
      (setf v (logior v (ash (aref buf (+ off i)) (* 8 i)))))))

;;; Fast, allocation-free typed little-endian readers for the lookup hot path.
;;; Identical results to RD-UINT but with the buffer typed as a simple ub8 array
;;; and fixnum offsets, so AREF + the shift/or fold to inline machine ops.
(declaim (inline fast-rd-u16 fast-rd-u64))
(declaim (ftype (function (page-buf fixnum) (unsigned-byte 16)) fast-rd-u16))
(defun fast-rd-u16 (buf off)
  (declare (optimize (speed 3) (safety 1))
           (type page-buf buf) (type fixnum off))
  (logior (aref buf off)
          (the (unsigned-byte 16) (ash (aref buf (+ off 1)) 8))))

(declaim (ftype (function (page-buf fixnum) (unsigned-byte 64)) fast-rd-u64))
(defun fast-rd-u64 (buf off)
  (declare (optimize (speed 3) (safety 1))
           (type page-buf buf) (type fixnum off))
  (let ((v 0))
    (declare (type (unsigned-byte 64) v))
    (dotimes (i 8 v)
      (declare (type (integer 0 8) i))
      (setf v (logior v (the (unsigned-byte 64)
                             (ash (aref buf (+ off i)) (the (integer 0 56) (* 8 i)))))))))

(defun wr-uint (buf off n v)
  "Write V as an N-byte little-endian unsigned integer into BUF at OFF."
  (dotimes (i n)
    (setf (aref buf (+ off i)) (logand (ash v (* -8 i)) #xff)))
  (+ off n))

(declaim (inline rd-u16 wr-u16 rd-u32 wr-u32 rd-u64 wr-u64))
(defun rd-u16 (buf off) (rd-uint buf off 2))
(defun wr-u16 (buf off v) (wr-uint buf off 2 v))
(defun rd-u32 (buf off) (rd-uint buf off 4))
(defun wr-u32 (buf off v) (wr-uint buf off 4 v))
(defun rd-u64 (buf off) (rd-uint buf off 8))
(defun wr-u64 (buf off v) (wr-uint buf off 8 v))

;;; ---- LEB128 varints -----------------------------------------------------
;;;
;;; Unsigned little-endian base-128: 7 payload bits/byte, high bit = "more".
;;; Used for the per-leaf-entry klen/vlen/ovpage so a typical small-coin entry
;;; carries a ~3-byte header (flags + 1B klen + 1B vlen) rather than a fixed 15.

(defun varint-size (v)
  "Bytes the unsigned integer V occupies as a LEB128 varint."
  (let ((n 1))
    (loop while (>= v #x80) do (setf v (ash v -7)) (incf n))
    n))

(defun wr-varint (buf off v)
  "Write unsigned V as a LEB128 varint into BUF at OFF; return the next offset."
  (loop
    (let ((b (logand v #x7f)))
      (setf v (ash v -7))
      (cond ((zerop v) (setf (aref buf off) b) (return (1+ off)))
            (t (setf (aref buf off) (logior b #x80)) (incf off))))))

(defun rd-varint (buf off)
  "Read a LEB128 varint from BUF at OFF; return (values value next-offset)."
  (let ((v 0) (shift 0))
    (loop
      (let ((b (aref buf off)))
        (incf off)
        (setf v (logior v (ash (logand b #x7f) shift)))
        (when (zerop (logand b #x80)) (return (values v off)))
        (incf shift 7)))))

;;; Typed varint reader for the lookup hot path.  klen/vlen are small (a key is
;;; <= a page, a coin value is small), so a fixnum accumulator is always safe
;;; and the loop body folds to inline ub8 loads + shifts.  Same result as
;;; RD-VARINT.
(declaim (inline fast-rd-varint))
(declaim (ftype (function (page-buf fixnum) (values fixnum fixnum)) fast-rd-varint))
(defun fast-rd-varint (buf off)
  (declare (optimize (speed 3) (safety 1))
           (type page-buf buf) (type fixnum off))
  (let ((v 0) (shift 0))
    (declare (type fixnum v) (type (integer 0 63) shift))
    (loop
      (let ((b (aref buf off)))
        (declare (type (unsigned-byte 8) b))
        (incf off)
        (setf v (logior v (the fixnum (ash (logand b #x7f) shift))))
        (when (zerop (logand b #x80)) (return (values v off)))
        (incf shift 7)))))

;;; ---- page type tags ----------------------------------------------------

(defconstant +pt-meta+     1)
(defconstant +pt-interior+ 2)
(defconstant +pt-leaf+     3)
(defconstant +pt-overflow+ 4)
(defconstant +pt-freelist+ 5)

(declaim (inline page-type))
(defun page-type (buf) (aref buf 0))

;;; ---- META page ---------------------------------------------------------
;;;
;;;   off 0   u8   type   (+pt-meta+)
;;;       1   u8[8] magic
;;;       9   u32  format-version
;;;      13   u32  page-size
;;;      17   u64  txn-id              (monotonic)
;;;      25   u64  root-page           (index of tree root; 0 = no root yet)
;;;      33   u64  freelist-head       (reserved; 0)
;;;      41   u64  free-count          (reserved; 0)
;;;      49   u64  entry-count
;;;      57   u64  page-high-water     (next page index device should hold)
;;;     ...   zero ...
;;;   last 4  u32  checksum over bytes [0 .. page-size-5]

;; A constant byte vector: guard against DEFCONSTANT-UNEQL on reload (vectors
;; aren't EQL across re-evaluation).
(defmacro define-byte-constant (name bytes)
  `(defparameter ,name
     (load-time-value
      (coerce ',bytes '(simple-array (unsigned-byte 8) (*))))))

(define-byte-constant +meta-magic+
    (#x70 #x67 #x74 #x72 #x65 #x65 #x00 #x01)) ; "pgtree\0\1"
(defconstant +format-version+ 1)

(defstruct meta
  (magic-ok t)
  (format-version +format-version+)
  (page-size +page-size+)
  (txn-id 0)
  (root 0)
  (freelist-head 0)
  (free-count 0)
  (entry-count 0)
  (high-water 0))

(defun fnv1a-32 (buf end)
  "FNV-1a 32-bit hash over BUF[0..end) — a cheap torn-write detector."
  (let ((h #x811c9dc5))
    (dotimes (i end h)
      (setf h (logand (* (logxor h (aref buf i)) #x01000193) #xffffffff)))))

(defun meta-checksum (buf)
  "Checksum over all bytes except the trailing 4-byte checksum field."
  (fnv1a-32 buf (- (length buf) 4)))

(defun encode-meta (m buf)
  "Serialize META M into page buffer BUF (already zeroed)."
  (fill buf 0)
  (setf (aref buf 0) +pt-meta+)
  (replace buf +meta-magic+ :start1 1)
  (wr-u32 buf 9  (meta-format-version m))
  (wr-u32 buf 13 (meta-page-size m))
  (wr-u64 buf 17 (meta-txn-id m))
  (wr-u64 buf 25 (meta-root m))
  (wr-u64 buf 33 (meta-freelist-head m))
  (wr-u64 buf 41 (meta-free-count m))
  (wr-u64 buf 49 (meta-entry-count m))
  (wr-u64 buf 57 (meta-high-water m))
  (wr-u32 buf (- (length buf) 4) (meta-checksum buf))
  buf)

(defun valid-meta-p (buf)
  "T iff BUF is a meta page with correct magic and checksum."
  (and (= (aref buf 0) +pt-meta+)
       (loop for i below 8 always (= (aref buf (+ 1 i)) (aref +meta-magic+ i)))
       (= (rd-u32 buf (- (length buf) 4)) (meta-checksum buf))))

(defun decode-meta (buf)
  "Decode a meta page; NIL if magic/checksum bad (torn or absent)."
  (when (valid-meta-p buf)
    (make-meta :magic-ok t
               :format-version (rd-u32 buf 9)
               :page-size (rd-u32 buf 13)
               :txn-id (rd-u64 buf 17)
               :root (rd-u64 buf 25)
               :freelist-head (rd-u64 buf 33)
               :free-count (rd-u64 buf 41)
               :entry-count (rd-u64 buf 49)
               :high-water (rd-u64 buf 57))))

;;; ---- LEAF page ---------------------------------------------------------
;;;
;;; Slotted layout, entries stored contiguously and in sorted key order.
;;;   off 0  u8   type (+pt-leaf+)
;;;       1  u16  count
;;;       3  u64  blob-head   (first page of this leaf's PACKED OVERFLOW blob,
;;;                            0 if the leaf has no overflow values)
;;;      11  ...  entries
;;; each entry (VARINT-packed header — a small coin costs ~3 header bytes):
;;;   u8       flags    (bit0 = value-is-overflow)
;;;   varint   klen
;;;   varint   vlen     (logical value length, even when overflowed)
;;;   key bytes (klen)
;;;   val bytes (vlen)  -- ONLY when NOT overflow
;;;
;;; PACKED, LEAF-LOCAL OVERFLOW.  Values larger than the inline limit do NOT each
;;; get their own page-aligned chain (the old layout burned a whole 4 KB page on
;;; a 300 B value).  Instead, ALL of a leaf's overflow values are CONCATENATED,
;;; in entry order, into a SINGLE blob stored in one overflow chain whose head is
;;; in the leaf header.  An overflow value's slice in that blob is recovered by a
;;; running sum of the preceding overflow entries' vlens — so the entry itself
;;; carries no page pointer or offset, just its flag + vlen.  Because a leaf is
;;; always rewritten as a unit under copy-on-write, its blob chain is rewritten
;;; (repacked) and the old chain freed with it: the chain is owned 1:1 by the
;;; leaf, so freeing is clean and no cross-leaf reference counting is needed.
;;; Packing several values into shared pages cuts the per-value page waste that
;;; dominated the old on-disk size.
;;;
;;; The previous layout used a fixed 15-byte entry header (u16 klen, u8 flags,
;;; u32 vlen, u64 ovpage); klen/vlen are now 1 byte each for small coins and the
;;; per-entry page pointer is gone, cutting the header from 15 to ~3 bytes.
;;;
;;; An in-memory leaf holds parallel vectors of keys / values / per-entry blob
;;; offsets.  For an overflow entry VAL is a (:overflow . vlen) marker and OVPGS
;;; holds the value's byte offset into the leaf blob; for an inline entry VAL is
;;; the byte vector and OVPGS is 0.  BLOB-HEAD is the chain head (managed by the
;;; btree layer, which owns the pager).

(defconstant +leaf-hdr+ 11)
(defconstant +ov-flag+ 1)

(defstruct leaf
  (keys      (make-array 0 :adjustable t :fill-pointer 0)) ; vector of byte-vectors
  (vals      (make-array 0 :adjustable t :fill-pointer 0)) ; byte-vector (inline) or (:overflow . vlen)
  (ovpgs     (make-array 0 :adjustable t :fill-pointer 0)) ; blob byte-offset (overflow) or 0 (inline)
  (blob-head 0))                                           ; overflow-blob chain head (0 = none)

(defun decode-leaf (buf)
  "Decode a leaf page into a LEAF struct.  Inline values are copied out; for an
   overflow entry VAL holds a (:overflow . vlen) marker and OVPGS holds the
   value's byte offset into the leaf's overflow blob (chain head in BLOB-HEAD)."
  (let* ((count (rd-u16 buf 1))
         (lf (make-leaf :blob-head (rd-u64 buf 3)))
         (off +leaf-hdr+)
         (blob-off 0))
    (dotimes (i count lf)
      (let ((flags (aref buf off)))
        (incf off)
        (multiple-value-bind (klen o1) (rd-varint buf off)
          (multiple-value-bind (vlen o2) (rd-varint buf o1)
            (let* ((overflowp (logtest flags +ov-flag+))
                   (kstart o2)
                   (key (subseq buf kstart (+ kstart klen))))
              (vector-push-extend key (leaf-keys lf))
              (cond
                (overflowp
                 (vector-push-extend (cons :overflow vlen) (leaf-vals lf))
                 (vector-push-extend blob-off (leaf-ovpgs lf))
                 (incf blob-off vlen)
                 (setf off (+ kstart klen)))
                (t
                 (let ((vstart (+ kstart klen)))
                   (vector-push-extend (subseq buf vstart (+ vstart vlen))
                                       (leaf-vals lf))
                   (vector-push-extend 0 (leaf-ovpgs lf))
                   (setf off (+ vstart vlen))))))))))))

(defun leaf-entry-bytes (klen vlen overflowp &optional (ovpage 0))
  "On-page byte cost of a leaf entry (flags + varint header + key + inline val).
   OVPAGE is accepted for call-site symmetry but no longer stored per entry."
  (declare (ignore ovpage))
  (+ 1                                  ; flags
     (varint-size klen)
     (varint-size vlen)
     klen
     (if overflowp 0 vlen)))

(defun encode-leaf (lf buf)
  "Serialize LEAF LF into a zeroed page buffer BUF.  Writes the blob-chain head
   into the header; overflow entries write only flags+klen+vlen+key (their value
   lives in the leaf's overflow blob).  Returns BUF."
  (fill buf 0)
  (setf (aref buf 0) +pt-leaf+)
  (let ((count (length (leaf-keys lf)))
        (off +leaf-hdr+))
    (wr-u16 buf 1 count)
    (wr-u64 buf 3 (leaf-blob-head lf))
    (dotimes (i count buf)
      (let* ((key (aref (leaf-keys lf) i))
             (val (aref (leaf-vals lf) i))
             (overflowp (overflow-val-p val))
             (klen (length key))
             (vlen (if overflowp (overflow-val-len val) (length val))))
        (setf (aref buf off) (if overflowp +ov-flag+ 0))
        (incf off)
        (setf off (wr-varint buf off klen))
        (setf off (wr-varint buf off vlen))
        (replace buf key :start1 off)
        (incf off klen)
        (unless overflowp
          (replace buf val :start1 off)
          (incf off vlen))))))

;;; An overflow value in a decoded leaf is one of two markers:
;;;   (:overflow . vlen)        — value still lives in the leaf's on-disk blob
;;;                               (offset in OVPGS); used by the lazy read paths.
;;;   (:overflow-bytes . bytes) — value materialized in RAM (loaded or freshly
;;;                               inserted); the source for repacking the blob.
(declaim (inline overflow-val-p))
(defun overflow-val-p (val)
  (and (consp val) (member (car val) '(:overflow :overflow-bytes) :test #'eq) t))

(defun overflow-val-len (val)
  (if (eq (car val) :overflow-bytes) (length (cdr val)) (cdr val)))

;;; ---- in-page leaf probe (lookup without fully decoding the leaf) -------
;;;
;;; A point lookup only needs whether KEY is present and, if so, its inline
;;; value bytes or overflow handle.  Walking the encoded entries in sorted order
;;; and comparing keys in place avoids allocating a fresh byte-vector for every
;;; value on every get (the common spend-check hot path).  Entries are sorted
;;; ascending, so we stop early once a stored key exceeds KEY.

(declaim (inline buf-key-cmp))
(declaim (ftype (function (page-buf fixnum fixnum page-buf) (integer -1 1)) buf-key-cmp))
(defun buf-key-cmp (buf koff klen key)
  "Compare the KLEN bytes of BUF at KOFF against byte-vector KEY.
   Returns -1, 0, or 1 for stored<key, stored=key, stored>key.  Compares in
   place — no copy of either key is made."
  (declare (optimize (speed 3) (safety 1))
           (type page-buf buf key) (type fixnum koff klen))
  (let* ((lk (length key))
         (m (min klen lk)))
    (declare (type fixnum lk m))
    (dotimes (i m)
      (declare (type fixnum i))
      (let ((x (aref buf (the fixnum (+ koff i)))) (y (aref key i)))
        (declare (type (unsigned-byte 8) x y))
        (cond ((< x y) (return-from buf-key-cmp -1))
              ((> x y) (return-from buf-key-cmp 1)))))
    (cond ((< klen lk) -1) ((> klen lk) 1) (t 0))))

(defun leaf-probe (buf key)
  "Scan encoded leaf BUF for KEY.  Returns NIL if absent, else
   (values t vlen overflowp blob-offset val-start blob-head): for an overflow
   value, BLOB-OFFSET is its byte offset into the leaf's overflow blob and
   BLOB-HEAD is that blob's chain head; for an inline value, VAL-START is its
   in-buffer byte offset.  Entries are sorted, so we stop early once a stored
   key exceeds KEY.

   Allocation-free: it never decodes the leaf into a struct nor copies any key
   or value; it walks the encoded entries in place with typed accessors and
   compares each stored key against KEY directly in the page buffer."
  (declare (optimize (speed 3) (safety 1))
           (type page-buf buf))
  (let ((key (the page-buf (if (typep key 'page-buf) key
                               (coerce key 'page-buf))))
        (count (fast-rd-u16 buf 1))
        (blob-head (fast-rd-u64 buf 3))
        (off +leaf-hdr+)
        (blob-off 0))
    (declare (type fixnum count off blob-off))
    (dotimes (i count nil)
      (declare (type fixnum i))
      (let ((flags (aref buf off)))
        (declare (type (unsigned-byte 8) flags))
        (incf off)
        (multiple-value-bind (klen o1) (fast-rd-varint buf off)
          (multiple-value-bind (vlen o2) (fast-rd-varint buf o1)
            (declare (type fixnum klen vlen o2))
            (let* ((overflowp (logtest flags +ov-flag+))
                   (kstart o2)
                   (cmp (buf-key-cmp buf kstart klen key)))
              (declare (type fixnum kstart))
              (cond
                ((zerop cmp)
                 (return-from leaf-probe
                   (values t vlen overflowp blob-off (+ kstart klen) blob-head)))
                ((plusp cmp)
                 (return-from leaf-probe nil))
                (t
                 (when overflowp (incf blob-off vlen))
                 (setf off (+ kstart klen (if overflowp 0 vlen))))))))))))

;;; ---- INTERIOR page -----------------------------------------------------
;;;
;;;   off 0  u8   type (+pt-interior+)
;;;       1  u16  nkeys                (children = nkeys+1)
;;;       3  u64  child[0]
;;;       3+8*(nkeys+1) ...  keys
;;; each key (separator): u16 klen, key bytes.
;;; Routing: child[i] holds keys < keys[i]; child[nkeys] holds keys >= keys[nkeys-1].

(defconstant +int-hdr+ 3)

(defstruct interior
  (keys     (make-array 0 :adjustable t :fill-pointer 0))  ; nkeys byte-vectors
  (children (make-array 0 :adjustable t :fill-pointer 0))) ; nkeys+1 fixnums

(defun decode-interior (buf)
  (let* ((nkeys (rd-u16 buf 1))
         (nch (1+ nkeys))
         (it (make-interior))
         (off +int-hdr+))
    (dotimes (i nch)
      (vector-push-extend (rd-u64 buf off) (interior-children it))
      (incf off 8))
    (dotimes (i nkeys it)
      (let* ((klen (rd-u16 buf off))
             (kstart (+ off 2))
             (key (subseq buf kstart (+ kstart klen))))
        (vector-push-extend key (interior-keys it))
        (setf off (+ kstart klen))))))

(defun interior-key-bytes (klen) (+ 2 klen))

;;; ---- in-page interior probe (descend without decoding the node) --------
;;;
;;; A point-lookup descent only needs the child pointer to follow for KEY — not
;;; the whole decoded interior (which conses a struct + adjustable vectors and
;;; SUBSEQs every separator).  INTERIOR-PROBE walks the on-page separators in
;;; place, comparing each against KEY with BUF-KEY-CMP (no key copy), and returns
;;; the matching child page index directly out of the page buffer.
;;;
;;; Routing matches DECODE-INTERIOR + INTERIOR-CHILD-INDEX exactly: child[i]
;;; holds keys < keys[i]; we return child[i] for the first i with key < keys[i],
;;; else child[nkeys].  Children are stored first (child[0..nkeys] as u64 at
;;; offset +int-hdr+), then the nkeys separators (u16 klen, key bytes); so the
;;; key area starts at +int-hdr+ + 8*(nkeys+1) and child[i] sits at
;;; +int-hdr+ + 8*i.
(declaim (ftype (function (page-buf t) (unsigned-byte 64)) interior-probe))
(defun interior-probe (buf key)
  "Return the child page index to descend into for KEY from encoded interior
   BUF, without decoding the node.  Same routing as DECODE-INTERIOR +
   INTERIOR-CHILD-INDEX."
  (declare (optimize (speed 3) (safety 1))
           (type page-buf buf))
  (let* ((key (the page-buf (if (typep key 'page-buf) key
                                (coerce key 'page-buf))))
         (nkeys (fast-rd-u16 buf 1))
         (key-off (+ +int-hdr+ (the fixnum (* 8 (the fixnum (+ nkeys 1)))))))
    (declare (type fixnum nkeys key-off))
    (dotimes (i nkeys
                ;; key >= every separator: descend the rightmost child[nkeys].
                (fast-rd-u64 buf (+ +int-hdr+ (the fixnum (* 8 nkeys)))))
      (declare (type fixnum i))
      (let* ((klen (fast-rd-u16 buf key-off))
             (kstart (+ key-off 2)))
        (declare (type fixnum klen kstart))
        ;; descend child[i] when KEY < keys[i] (stored > key, i.e. cmp = 1).
        (when (= (buf-key-cmp buf kstart klen key) 1)
          (return (fast-rd-u64 buf (+ +int-hdr+ (the fixnum (* 8 i))))))
        (setf key-off (+ kstart klen))))))

(defun encode-interior (it buf)
  (fill buf 0)
  (setf (aref buf 0) +pt-interior+)
  (let* ((nkeys (length (interior-keys it)))
         (nch (length (interior-children it)))
         (off +int-hdr+))
    (assert (= nch (1+ nkeys)))
    (wr-u16 buf 1 nkeys)
    (dotimes (i nch)
      (wr-u64 buf off (aref (interior-children it) i))
      (incf off 8))
    (dotimes (i nkeys buf)
      (let* ((key (aref (interior-keys it) i))
             (klen (length key)))
        (wr-u16 buf off klen)
        (replace buf key :start1 (+ off 2))
        (setf off (+ off 2 klen))))))

;;; ---- OVERFLOW page -----------------------------------------------------
;;;
;;;   off 0  u8   type (+pt-overflow+)
;;;       1  u64  next-page  (0 = last chunk)
;;;       9  u32  chunk-len
;;;      13  ...  data

(defconstant +ov-hdr+ 13)
(defun overflow-capacity () (- +page-size+ +ov-hdr+))

(defun encode-overflow (buf next chunk start len)
  "Write one overflow chunk: NEXT page, LEN bytes of CHUNK starting at START."
  (fill buf 0)
  (setf (aref buf 0) +pt-overflow+)
  (wr-u64 buf 1 next)
  (wr-u32 buf 9 len)
  (replace buf chunk :start1 +ov-hdr+ :start2 start :end2 (+ start len))
  buf)

(defun decode-overflow-chunk (buf)
  "Return (values next-page chunk-bytes)."
  (let ((next (rd-u64 buf 1))
        (len (rd-u32 buf 9)))
    (values next (subseq buf +ov-hdr+ (+ +ov-hdr+ len)))))

;;; ---- FREELIST page -----------------------------------------------------
;;;
;;; A persisted chunk of the free-page set, chained when it exceeds one page.
;;; The META's FREELIST-HEAD points at the first page; FREE-COUNT is the total
;;; number of free indices across the whole chain (a redundancy check).
;;;
;;;   off 0  u8   type (+pt-freelist+)
;;;       1  u64  next-page   (0 = last chunk in the chain)
;;;       9  u32  count       (number of u64 entries ON THIS page)
;;;      13  ...  count * u64 free page indices (little-endian)
;;;
;;; Freelist pages are NOT checksummed individually: they are made durable in the
;;; same pager-sync as the tree data (BEFORE the meta), and only become live when
;;; the meta that references them becomes live (the atomic commit point).  A crash
;;; before the meta swap leaves the old meta + its old freelist chain live and
;;; intact; the newly written freelist pages are simply unreferenced free space.

(defconstant +fl-hdr+ 13)
(defun freelist-capacity ()
  "Number of u64 page-index entries one freelist page can hold."
  (floor (- +page-size+ +fl-hdr+) 8))

(defun encode-freelist (buf next indices start count)
  "Write one freelist chunk into zeroed BUF: NEXT chain pointer, then COUNT
   entries taken from sequence INDICES beginning at START.  Returns BUF."
  (fill buf 0)
  (setf (aref buf 0) +pt-freelist+)
  (wr-u64 buf 1 next)
  (wr-u32 buf 9 count)
  (let ((off +fl-hdr+))
    (dotimes (i count buf)
      (wr-u64 buf off (aref indices (+ start i)))
      (incf off 8))))

(defun decode-freelist-chunk (buf)
  "Return (values next-page list-of-indices) for one freelist chunk."
  (let ((next (rd-u64 buf 1))
        (count (rd-u32 buf 9))
        (out '())
        (off +fl-hdr+))
    (dotimes (i count)
      (push (rd-u64 buf off) out)
      (incf off 8))
    (values next (nreverse out))))

;;; ---- key comparison ----------------------------------------------------

(defun key< (a b)
  "Lexicographic compare of two (unsigned-byte 8) vectors: T iff A < B."
  (let ((la (length a)) (lb (length b)))
    (dotimes (i (min la lb))
      (let ((x (aref a i)) (y (aref b i)))
        (cond ((< x y) (return-from key< t))
              ((> x y) (return-from key< nil)))))
    (< la lb)))

(defun key= (a b)
  (and (= (length a) (length b))
       (dotimes (i (length a) t)
         (unless (= (aref a i) (aref b i)) (return nil)))))
