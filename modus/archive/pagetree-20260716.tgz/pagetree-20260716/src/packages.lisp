;;;; src/packages.lisp

(defpackage #:pagetree
  (:use #:cl)
  (:documentation
   "Pure-CL copy-on-write B+tree embedded KV store.  Public KV API + store
    lifecycle live here; the layered internals (device / pager / node / btree)
    are in sibling packages.")
  (:export
   ;; store lifecycle
   #:open-store #:close-store
   ;; transactions
   #:with-write-txn #:with-read-txn #:commit-txn #:abort-txn
   ;; KV ops (keys/values are (unsigned-byte 8) vectors)
   #:tput #:tget #:tdel
   ;; batched apply (fast sorted bulk put/delete — staging-buffer flush)
   #:tapply-batch
   ;; bottom-up bulk build (fast from-empty load of a large sorted dataset)
   #:tbulk-build #:tbulk-build-stream
   ;; ordered cursor (for set-digest scans + prefix range scans)
   #:tcursor #:cursor-first #:cursor-seek #:cursor-next #:cursor-key #:cursor-value
   ;; conditions
   #:pagetree-error #:corrupt-store))

;;; Layer 0 — block device: the sole platform seam.  A fixed-size page array.
(defpackage #:pagetree.device
  (:use #:cl)
  (:nicknames #:pt-dev)
  (:export
   #:device #:dev-read-page #:dev-write-page #:dev-sync #:dev-grow #:dev-page-count
   #:dev-page-size #:+default-page-size+
   ;; backends
   #:make-mem-device          ; in-RAM (tests + fault injection)
   #:make-file-device))       ; standard-CL-stream file backend (device-file.lisp)

;;; Layer 1 — pager + LRU buffer cache + free-page allocator.
(defpackage #:pagetree.pager
  (:use #:cl)
  (:local-nicknames (#:dev #:pagetree.device))
  (:nicknames #:pt-pager)
  (:export
   #:pager #:make-pager #:pager-get #:pager-dirty #:pager-alloc #:pager-free
   #:pager-flush #:pager-sync #:pager-cache-bytes))

;;; Layer 2 — page codec + copy-on-write B+tree.
(defpackage #:pagetree.btree
  (:use #:cl)
  (:local-nicknames (#:pager #:pagetree.pager) (#:dev #:pagetree.device))
  (:nicknames #:pt-btree)
  (:export
   #:+page-size+ #:btree-open #:btree-lookup #:btree-insert #:btree-delete
   #:btree-commit #:btree-root #:btree-cursor #:cursor-seek
   ;; batched apply (sorted bulk insert/delete in one CoW pass)
   #:btree-apply-batch #:btree-insert-batch
   ;; bottom-up bulk build (build a fresh tree from sorted input in one pass)
   #:btree-bulk-build #:btree-bulk-build-vector))
