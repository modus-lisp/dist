;;;; src/pager.lisp  — Layer 1: pager + buffer cache + free-page allocator.
;;;;
;;;; Public API (UNCHANGED from the baseline — the btree depends on it exactly):
;;;;
;;;;   make-pager device &key cache-bytes  -> pager
;;;;   pager-get   p n     -> page buffer (read-through on miss; caller may mutate)
;;;;   pager-dirty p n      ; mark page N dirty (flush it on the next pager-flush)
;;;;   pager-alloc p        -> n  ; a fresh zeroed page (reuse freelist, else grow)
;;;;   pager-free  p n      ; return page N for reuse
;;;;   pager-flush p        ; write all dirty pages to the device (no sync)
;;;;   pager-sync  p        ; device durability barrier
;;;;
;;;; Invariant the btree relies on: a buffer returned by pager-get for page N is
;;;; the SAME object until that page is freed — so CoW must alloc a new page and
;;;; copy, never mutate a live page in place expecting isolation.
;;;;
;;;; CACHE / EVICTION  (CLOCK / second-chance — was strict LRU)
;;;;   The cache is RAM-budgeted: total cached bytes are tracked, and when they
;;;;   exceed CACHE-BYTES, CLEAN pages are evicted until back within budget.
;;;;
;;;;   Recency is approximated with the CLOCK (second-chance) algorithm instead of
;;;;   strict LRU.  Entries sit on an O(1) circular ring; each carries one
;;;;   REFERENCE bit.  The single per-visit cost on the hot read path (pager-get
;;;;   hit) is *setting that bit* — no list unlink/relink.  That removes the
;;;;   LRU bookkeeping that dominated the lookup hot path.
;;;;
;;;;   Eviction sweeps a "hand" around the ring: an entry whose ref bit is set is
;;;;   given a second chance (bit cleared, hand advances); an entry with a clear
;;;;   ref bit that is CLEAN is evicted.  This is the classic LRU approximation
;;;;   (one ref bit ≈ recency) used by real buffer managers.
;;;;
;;;;   HARD INVARIANT (unchanged): only CLEAN pages are ever evicted.  A dirty
;;;;   page lives in the cache until pager-flush writes it (whereupon it becomes
;;;;   clean and eligible again).  Eviction relies solely on "clean => evictable":
;;;;   the btree uses copy-on-write, so re-reading an evicted clean page yields
;;;;   equal bytes.  No pin/unpin.  The cache may legitimately exceed CACHE-BYTES
;;;;   if the dirty working set alone is larger than the budget — dirty pages are
;;;;   never dropped to honor the budget (correctness beats the soft cap).  The
;;;;   clock sweep simply skips dirty entries (it neither evicts them nor clears
;;;;   their ref bit), so a buffer held by a caller is stable until freed.

(in-package #:pagetree.pager)

;;; -------------------------------------------------------------------------
;;; Cache entry: a node in the CLOCK ring AND the value in the lookup table.
;;; -------------------------------------------------------------------------
(defstruct (centry (:constructor %make-centry))
  index            ; page index (key)
  buf              ; (unsigned-byte 8) buffer  (the SAME object handed to caller)
  dirty            ; t when this page has unflushed mutations
  (ref nil)        ; CLOCK reference bit: set on use, cleared by the sweep
  prev             ; circular ring link
  next)            ; circular ring link

(defstruct (pager (:constructor %make-pager))
  device
  (table (make-hash-table))   ; page-index -> centry
  (hand nil)                  ; CLOCK hand: the next eviction candidate, or nil
  (count 0)                   ; number of entries on the ring
  (freelist '())              ; reusable page indices (in-memory only)
  (used-bytes 0)              ; sum of (length buf) over all cached entries
  (cache-bytes 0))            ; soft RAM budget

(defun make-pager (device &key (cache-bytes (* 256 1024 1024)))
  (%make-pager :device device :cache-bytes cache-bytes))

(declaim (inline %psize))
(defun %psize (p) (dev:dev-page-size (pager-device p)))

;;; -------------------------------------------------------------------------
;;; CLOCK ring maintenance (circular doubly-linked list).
;;;
;;; HAND points at the next candidate the evictor will examine.  Newly inserted
;;; entries go in just BEHIND the hand (i.e. they are the most-recently examined
;;; spot and will be looked at last), giving a fresh page a full sweep before it
;;; can be considered for eviction.
;;; -------------------------------------------------------------------------
(defun %ring-insert (p e)
  "Splice E into the ring immediately before HAND (so HAND still points at the
   same candidate and E is the last entry the hand will reach)."
  (let ((h (pager-hand p)))
    (cond
      ((null h)
       ;; First entry: a singleton ring pointing at itself; it is the hand.
       (setf (centry-prev e) e
             (centry-next e) e
             (pager-hand p) e))
      (t
       ;; Insert between (centry-prev h) and h.
       (let ((pv (centry-prev h)))
         (setf (centry-prev e) pv
               (centry-next e) h
               (centry-next pv) e
               (centry-prev h) e)))))
  (incf (pager-count p)))

(defun %ring-remove (p e)
  "Unlink E from the ring, fixing up HAND if it pointed at E."
  (let ((pv (centry-prev e))
        (nx (centry-next e)))
    (cond
      ((eq e nx)                       ; singleton: ring becomes empty
       (setf (pager-hand p) nil))
      (t
       (setf (centry-next pv) nx
             (centry-prev nx) pv)
       (when (eq (pager-hand p) e)
         (setf (pager-hand p) nx))))
    (setf (centry-prev e) nil
          (centry-next e) nil))
  (decf (pager-count p)))

(defun %insert (p index buf dirty)
  "Create a cache entry for INDEX/BUF, install it, account its bytes, and (if
   needed) evict clean pages to get back within budget.  Returns the entry.  A
   freshly inserted entry starts referenced (ref=t) so it survives the first
   sweep that reaches it."
  (let ((e (%make-centry :index index :buf buf :dirty dirty :ref t)))
    (setf (gethash index (pager-table p)) e)
    (%ring-insert p e)
    (incf (pager-used-bytes p) (length buf))
    (%maybe-evict p)
    e))

;;; -------------------------------------------------------------------------
;;; Eviction: the CLOCK sweep.  Advance the hand; on each entry:
;;;   - DIRTY  -> skip untouched (never evicted; ref bit left alone).
;;;   - ref=t  -> second chance: clear ref, advance.
;;;   - ref=nil & clean -> evict.
;;; The loop terminates: once back within budget it stops; otherwise it stops
;;; when no clean entry remains droppable (a full revolution sees only dirty
;;; pages — every clean page would have had its ref cleared on the first pass and
;;; been evicted on the second).  We bound the work by counting consecutive
;;; non-evictable (dirty) inspections so an all-dirty ring can't spin forever.
;;; -------------------------------------------------------------------------
(defun %maybe-evict (p)
  (let ((budget (pager-cache-bytes p)))
    (when (and (plusp budget) (> (pager-used-bytes p) budget))
      ;; SKIPS counts consecutive entries we passed over WITHOUT clearing a ref
      ;; bit or evicting (i.e. dirty entries).  If that reaches the ring size, the
      ;; whole ring is dirty/pinned and nothing more can be dropped — bail.
      (let ((skips 0))
        (loop
          (let ((e (pager-hand p)))
            (when (null e) (return))            ; empty ring
            (cond
              ((centry-dirty e)
               ;; Pinned: cannot evict, leave ref bit untouched, move on.
               (incf skips)
               (when (>= skips (pager-count p)) (return))
               (setf (pager-hand p) (centry-next e)))
              ((centry-ref e)
               ;; Second chance: clear the bit and advance.  This counts as
               ;; progress, so reset the dirty-skip counter.
               (setf (centry-ref e) nil
                     skips 0
                     (pager-hand p) (centry-next e)))
              (t
               ;; Clean, unreferenced: evict it.  Advance the hand off it first.
               (setf (pager-hand p) (centry-next e))
               (remhash (centry-index e) (pager-table p))
               (decf (pager-used-bytes p) (length (centry-buf e)))
               (%ring-remove p e)
               (setf skips 0)
               (when (<= (pager-used-bytes p) budget) (return))))))))))

;;; -------------------------------------------------------------------------
;;; Public API.
;;; -------------------------------------------------------------------------
(defun pager-get (p n)
  "The cached buffer for page N (read-through on miss).  Caller may mutate it,
   then must pager-dirty N for it to persist.  The returned object is stable
   until page N is freed; a CLEAN page may be evicted and re-read transparently
   (yielding equal bytes), but is reconstructed as a fresh equal buffer only on
   a subsequent miss — never silently swapped while a caller holds it.

   HOT PATH: a cache hit just sets the entry's reference bit (no ring surgery)."
  (let ((e (gethash n (pager-table p))))
    (if e
        (progn
          ;; Mark referenced for the CLOCK sweep.  Avoid a redundant write when
          ;; already set (keeps the common re-hit branch a pure read + return).
          (unless (centry-ref e) (setf (centry-ref e) t))
          (centry-buf e))
        (let ((buf (make-array (%psize p) :element-type '(unsigned-byte 8))))
          (dev:dev-read-page (pager-device p) n buf)
          (centry-buf (%insert p n buf nil))))))

(defun pager-dirty (p n)
  "Mark page N dirty so the next pager-flush writes it.  Dirty pages are pinned
   against eviction until flushed."
  (let ((e (gethash n (pager-table p))))
    (when e
      (setf (centry-dirty e) t
            (centry-ref e) t)))
  (values))

(defun pager-alloc (p)
  "Allocate a page (reuse a freed index, else grow the device); its cached buffer
   is freshly zeroed and marked dirty.  Returns the page index."
  (let ((n (if (pager-freelist p)
               (pop (pager-freelist p))
               (dev:dev-grow (pager-device p) 1))))
    ;; A freed index may still have a stale entry; replace it cleanly.
    (let ((old (gethash n (pager-table p))))
      (when old
        (decf (pager-used-bytes p) (length (centry-buf old)))
        (remhash n (pager-table p))
        (%ring-remove p old)))
    (let ((buf (make-array (%psize p) :element-type '(unsigned-byte 8)
                                      :initial-element 0)))
      (%insert p n buf t))
    n))

(defun pager-free (p n)
  "Return page N for reuse.  Drops its cache entry (it is no longer live, so the
   stability contract no longer applies) and clears any dirty state."
  (let ((e (gethash n (pager-table p))))
    (when e
      (decf (pager-used-bytes p) (length (centry-buf e)))
      (remhash n (pager-table p))
      (%ring-remove p e)))
  (push n (pager-freelist p))
  (values))

(defun pager-flush (p)
  "Write every dirty page to the device (durability still needs pager-sync).
   Flushed pages become clean and thus eligible for eviction; run the evictor
   afterward so the budget is honored once the dirty pins are released."
  (let ((dev (pager-device p)))
    (maphash (lambda (n e)
               (declare (ignore n))
               (when (centry-dirty e)
                 (dev:dev-write-page dev (centry-index e) (centry-buf e))
                 (setf (centry-dirty e) nil)))
             (pager-table p)))
  (%maybe-evict p)
  (values))

(defun pager-sync (p)
  "Device durability barrier."
  (dev:dev-sync (pager-device p))
  (values))

;;; -------------------------------------------------------------------------
;;; Persistent-freelist support.  The freelist is in-memory here; the btree
;;; layer serializes/restores it across reopen.  These let it read the current
;;; reusable set and (re)load one parsed from disk on open.  Order does not
;;; matter — the set is a set.
;;; -------------------------------------------------------------------------
(defun pager-freelist-indices (p)
  "A fresh list of the page indices currently free (reusable) in this pager."
  (copy-list (pager-freelist p)))

(defun pager-set-freelist (p indices)
  "Replace the in-memory freelist with INDICES (a list of page indices).  Used on
   open to restore the persisted free set so freed pages are reused across
   sessions."
  (setf (pager-freelist p) (copy-list indices))
  (values))
