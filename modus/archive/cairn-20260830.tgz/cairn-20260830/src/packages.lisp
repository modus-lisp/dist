;;;; packages.lisp — cairn

(defpackage #:cairn
  (:use #:cl)
  (:shadow #:merge)                     ; cairn:merge is git merge, not cl:merge
  (:documentation
   "cairn — a git implementation in pure Common Lisp.  A cairn is a trail marker
    built one stone at a time; a git history is the same — each commit a stone,
    the chain of them marking where the work has been.  Clean-room: the object
    model, the loose/packed object stores, refs, the index, add/commit, checkout,
    status/diff/merge, and the smart transfer protocol over HTTPS (seal) and SSH
    (conch), all from scratch.  No libgit2, no libcurl, no shelling out to git,
    no FFI.  SHA-1 from seal, DEFLATE from cram.")
  (:export
   ;; hashing / compression primitives
   #:sha1 #:sha1-hex #:zlib-decompress #:zlib-compress #:inflate #:deflate
   ;; repository
   #:open-repository #:repository #:repo-path #:with-repository
   ;; pluggable storage backend (host filesystem by default; cabinet is opt-in)
   #:make-repository-on-backend #:init-repository #:with-store-transaction
   #:make-host-backend #:make-cabinet-backend #:open-cabinet-repository
   #:make-pagetree-backend #:open-pagetree-repository
   ;; objects
   #:read-object #:object-type #:object-data #:hash-object
   #:parse-commit #:parse-tree
   #:commit-tree #:commit-parents #:commit-message #:commit-author #:commit-committer
   #:commit-summary #:tree-entries #:tree-entry-mode #:tree-entry-name #:tree-entry-sha
   ;; refs
   #:resolve-ref #:head-commit #:list-refs #:ref-target
   ;; plumbing / porcelain
   #:cat-file #:cat-file-string #:log-commits #:ls-tree #:rev-parse
   ;; transport (smart HTTP over seal)
   #:clone #:discover-refs #:fetch-pack #:index-pack #:checkout #:push-http
   ;; write side
   #:write-object #:add #:write-tree #:commit #:update-ref #:head-ref
   #:read-index #:write-index #:index-entry #:ie-path #:ie-sha #:ie-mode
   ;; status / diff
   #:status #:print-status #:diff
   ;; push + git-over-SSH (via conch)
   #:write-packfile #:objects-to-send #:reachable-objects
   #:clone-ssh #:push-ssh #:parse-ssh-url
   ;; git-over-SSH server (cairn's own upload-pack/receive-pack)
   #:serve-git #:git-exec-handler #:serve-upload-pack #:serve-receive-pack
   ;; fetch / pull
   #:fetch #:pull #:remote-url
   ;; merge (three-way, recursive; conflict handling via *merge-resolver*)
   #:merge #:merge-base #:all-merge-bases #:diff3-merge #:*merge-resolver*
   #:*merge-ours-label* #:*merge-theirs-label*))
