;;;; ddl.lisp — CREATE / DROP / ALTER, and maintenance of sqlite_schema.

(in-package #:sqlite-pure)

(defun schema-table () (find-table-in *db* "sqlite_schema"))

(defun drop-btrees (roots)
  "Free whole b-trees.  In an auto-vacuum database roots stay packed: each
dropped root's slot is filled by the largest root, whose sqlite_schema row
is repointed; roots are dropped largest first, as SQLite does."
  (if (autovacuum-p *db*)
      (dolist (root (sort (copy-list roots) #'>))
        (clear-btree *db* root :keep-root t)
        (let ((moved (release-root *db* root)))
          (when moved (retarget-schema-root moved root))))
      ;; largest root first, as destroyTable() orders them
      (dolist (root (sort (copy-list roots) #'>)) (clear-btree *db* root))))

(defun retarget-schema-root (old new)
  (let ((rows '()))
    (map-table *db* 1 (lambda (rowid payload) (push (cons rowid (decode-record payload)) rows)))
    (dolist (r rows)
      (destructuring-bind (rowid type name tbl root sql &rest more) r
        (declare (ignore more))
        (when (eql root old)
          ;; an UPDATE of sqlite_schema: rewritten in place when the same size
          (table-insert *db* 1 rowid (encode-record (list type name tbl new sql)) :overwrite t))))))

(defun ddl-target (schema temp)
  "The database a CREATE statement writes to."
  (cond (temp (temp-db *db* t))
        (schema (schema-db *db* schema))
        (t (conn *db*))))

(defun bump-schema-cookie ()
  (set-header-u32 *db* +hdr-schema-cookie+ (1+ (header-u32 *db* +hdr-schema-cookie+)))
  (setf (db-schema *db*) nil))

(defun add-schema-row (type name tbl root sql)
  (let ((rowid (1+ (or (table-max-rowid *db* 1) 0))))
    (table-insert *db* 1 rowid (encode-record (list type name tbl root (or sql :null))))
    rowid))

(defparameter +null-schema-record+ (coerce '(6 0 0 0 0 0) 'octets)
  "The empty record sqlite3StartTable writes as a placeholder schema row.")

(defun add-placeholder-schema-row ()
  "sqlite3StartTable's placeholder row in sqlite_schema; returns its rowid.
sqlite3EndTable later rewrites it (REWRITE-PLACEHOLDER).  A file format not
yet set (a database created by PRAGMA auto_vacuum) is set now, with the
text encoding."
  (when (zerop (header-u32 *db* +hdr-schema-format+))
    (set-header-u32 *db* +hdr-schema-format+ 4)
    (set-header-u32 *db* +hdr-text-encoding+ (ecase (db-encoding *db*) (:utf-8 1) (:utf-16le 2) (:utf-16be 3))))
  (let ((rowid (1+ (or (table-max-rowid *db* 1) 0))))
    (table-insert *db* 1 rowid +null-schema-record+)
    rowid))

(defun rewrite-placeholder (rowid type name tbl root sql)
  (table-insert *db* 1 rowid (encode-record (list type name tbl root (or sql :null)))))

(defun add-table-schema-row (type name tbl root sql)
  "A table, view or virtual table's schema row, written as StartTable and
EndTable write it: a placeholder first, then the real record."
  (let ((row (add-placeholder-schema-row)))
    (rewrite-placeholder row type name tbl root sql)
    row))

(defun schema-rows-where (pred)
  (remove-if-not pred (schema-rows (db-schema* *db*))))

(defun delete-schema-rows (pred)
  (dolist (r (schema-rows-where pred))
    (table-delete *db* 1 (first r))))

(defun rewrite-schema-row (r &key (type (second r)) (name (third r)) (tbl (fourth r))
                                  (root (fifth r)) (sql (sixth r)))
  (table-insert *db* 1 (first r) (encode-record (list type name tbl root (or sql :null)))))

(defun name-in-use-p (name)
  (let ((s (db-schema* *db*)))
    (or (gethash (schema-key name) (schema-tables s))
        (gethash (schema-key name) (schema-indexes s)))))

(defun check-new-name (name kind)
  (when (and (>= (length name) 7) (name= (subseq name 0 7) "sqlite_")
             (not (db-writable-schema (conn *db*))))
    (sql-error "object name reserved for internal use: ~a" name))
  ;; sqlite3StartTable / sqlite3CreateIndex: tables and views share one
  ;; namespace with indexes (triggers have their own), and the message
  ;; says which kind of object is in the way
  (let* ((s (db-schema* *db*))
         (tb (gethash (schema-key name) (schema-tables s)))
         (ix (gethash (schema-key name) (schema-indexes s))))
    (if (eq kind :index)
        (cond (ix (sql-error "index ~a already exists" name))
              (tb (sql-error "there is already a table named ~a" name)))
        (cond (tb (sql-error "~a ~a already exists" (if (table-view-select tb) "view" "table") name))
              (ix (sql-error "there is already an index named ~a" name))))))

;;; SQL text as SQLite stores it: "CREATE TABLE " + the text from the name on.

(defun stored-create-sql (text keyword)
  (let* ((toks (tokenize text))
         (i (position-if (lambda (tk) (kw-tok-p tk keyword)) toks)))
    (if (null i)
        text
        (let ((unique (loop for k below i thereis (kw-tok-p (aref toks k) "UNIQUE"))))
          (incf i)
          (when (kw-tok-p (aref toks i) "IF") (incf i 3))
          (format nil "CREATE ~:[~;UNIQUE ~]~a ~a" unique keyword
                  (subseq text (tok-pos (aref toks i))))))))

(defun quote-ident (name)
  (if (and (plusp (length name))
           (ident-start-p (char name 0))
           (every #'ident-char-p name)
           (not (reserved-p name)))
      name
      (format nil "\"~a\"" (substitute-string "\"" "\"\"" name))))

;;; ------------------------------------------------------------------
;;; CREATE TABLE

(defun create-table-from-ast (ast sql)
  ;; as SQLite codes it: the table's b-tree and a placeholder schema row,
  ;; the constraint indexes (b-tree and row each), then the real row
  (let* ((name (getf (cdr ast) :name))
         (tb (table-from-ast name ast 0 sql))
         (root (create-btree *db* (if (table-without-rowid tb) +leaf-index+ +leaf-table+)))
         (row (add-placeholder-schema-row)))
    (loop for u in (table-unique-constraints tb)
          for k from 1
          unless (and (third u) (table-without-rowid tb))
          do (let ((iroot (create-btree *db* +leaf-index+)))
               (add-schema-row "index" (format nil "sqlite_autoindex_~a_~d" name k) name iroot nil)))
    (rewrite-placeholder row "table" name name root sql)
    (when (and (table-autoincrement tb) (null (find-table-in *db* "sqlite_sequence")))
      (let ((seq-sql "CREATE TABLE sqlite_sequence(name,seq)"))
        (add-schema-row "table" "sqlite_sequence" "sqlite_sequence"
                        (create-btree *db* +leaf-table+) seq-sql)))
    (bump-schema-cookie)))

(defun affinity-type-name (aff)
  (case aff (:integer "INT") (:real "REAL") (:numeric "NUM") (:text "TEXT") (t "")))

(defun exec-create-table (st text)
  (destructuring-bind (&key name schema temp if-not-exists as-select &allow-other-keys) (cdr st)
   (let ((*db* (ddl-target schema temp)))
    (when (find-table-in *db* name)
      (if if-not-exists
          (return-from exec-create-table nil)
          (sql-error "table ~a already exists" name)))
    (check-new-name name :table)
    (when *prepare-only*
      (when as-select (compile-select as-select (make-scope)))
      (prepared-here))
    (if as-select
        (multiple-value-bind (fn cols) (compile-select as-select (make-scope))
          (let* ((rows (funcall fn nil))
                 (names (dedupe-names (mapcar #'first cols)))
                 ;; SQLite 3.40's layout: CREATE TABLE t(a INT,b TEXT,c)
                 (sql (format nil "CREATE TABLE ~a(~{~a~^,~})" (quote-ident name)
                              (loop for n in names
                                    for c in cols
                                    for ty = (affinity-type-name (second c))
                                    collect (format nil "~a~:[ ~a~;~*~]" (quote-ident n)
                                                    (string= ty "") ty)))))
            (create-table-from-ast (car (first (parse-sql sql))) sql)
            (let ((tb (find-table-in *db* name))
                  (ctx nil))
              (setf ctx (make-write-ctx :table tb))
              (dolist (r rows)
                (let ((row (make-array (1+ (length r)))))
                  (replace row r)
                  (setf (svref row (length r)) :null)
                  (apply-row-affinity tb row)
                  (finalize-rowid tb row)
                  (write-row tb row))))))
        ;; sqlite3EndTable: the text ends at the column list's ")" — or, with
        ;; table options, at the last token before the ";" (so trailing
        ;; whitespace and comments are kept)
        (create-table-from-ast st (stored-create-sql
                                   (statement-text st (if (or (getf (cdr st) :without-rowid)
                                                              (getf (cdr st) :strict))
                                                          :raw :tight)
                                                   text)
                                   "TABLE")))
    nil)))

(defun dedupe-names (names)
  (let ((seen '()))
    (loop for n in names
          collect (let ((cand n) (k 0))
                    (loop while (member cand seen :test #'name=)
                          do (setf cand (format nil "~a:~d" n (incf k))))
                    (push cand seen)
                    cand))))

;;; ------------------------------------------------------------------
;;; CREATE INDEX

(defun populate-index (table idx)
  "sqlite3RefillIndex: every key, sorted, appended through a bulk-load cursor."
  (let ((*index-cmp* (index-full-cmp table idx))
        (seen (make-hash-table :test #'equal))
        (keys '()))
    (map-table-rows table
                    (lambda (row)
                      (when (index-applies-p table idx row)
                        (let ((key (index-key table idx row)))
                          (when (index-unique idx)
                            (let ((prefix (subseq key 0 (length (index-columns idx)))))
                              (unless (member :null prefix)
                                (let ((k (group-key prefix (index-collations idx))))
                                  (when (gethash k seen)
                                    (constraint-error "UNIQUE constraint failed: ~a"
                                                      (constraint-columns-text table idx)))
                                  (setf (gethash k seen) t)))))
                          (push key keys)))))
    (setf keys (stable-sort (nreverse keys) (lambda (a b) (minusp (funcall *index-cmp* a b)))))
    (dolist (key keys)
      (index-insert *db* (index-root idx) key :bulk t))))

(defun refill-index (table idx)
  "sqlite3RefillIndex for REINDEX: read every key, clear the index b-tree
(keeping its root page), and bulk-load the keys in order.  A WITHOUT
ROWID table's key index is the table itself: its rows are read before the
b-tree is cleared, as SQLite fills its sorter before OP_Clear."
  (let ((*index-cmp* (index-full-cmp table idx))
        (seen (make-hash-table :test #'equal))
        (keys '()))
    (map-table-rows table
                    (lambda (row)
                      (when (index-applies-p table idx row)
                        (let ((key (index-key table idx row)))
                          (when (index-unique idx)
                            (let ((prefix (subseq key 0 (length (index-columns idx)))))
                              (unless (member :null prefix)
                                (let ((k (group-key prefix (index-collations idx))))
                                  (when (gethash k seen)
                                    (constraint-error "UNIQUE constraint failed: ~a"
                                                      (constraint-columns-text table idx)))
                                  (setf (gethash k seen) t)))))
                          (push key keys)))))
    (setf keys (stable-sort (nreverse keys) (lambda (a b) (minusp (funcall *index-cmp* a b)))))
    (clear-btree (table-owner table) (index-root idx) :keep-root t)
    (dolist (key keys)
      (index-insert (table-owner table) (index-root idx) key :bulk t))))

(defun sqlite-hash-order (names)
  "The order SQLite's Hash (hash.c) iterates NAMES in, after inserting them
in the given order: strHash, the bucket array doubling once 10 elements
outnumber twice its size, and insertElement's placement."
  (let ((elems '()) (buckets nil) (htsize 0) (count 0))
    (labels ((str-hash (s)
               (let ((h 0))
                 (loop for c across (utf8-encode s)
                       do (setf h (ldb (byte 32 0) (* (ldb (byte 32 0) (+ h (if (<= 65 c 90) (+ c 32) c)))
                                                      #x9e3779b1))))
                 h))
             (insert (name bucket)
               ;; before the bucket's first element, else at the very front
               (let ((head (and bucket (plusp (car (aref buckets bucket))) (cdr (aref buckets bucket)))))
                 (when bucket
                   (incf (car (aref buckets bucket)))
                   (setf (cdr (aref buckets bucket)) name))
                 (if head
                     (let ((pos (position head elems :test #'eq)))
                       (setf elems (append (subseq elems 0 pos) (list name) (nthcdr pos elems))))
                     (push name elems)))))
      (dolist (name names elems)
        (incf count)
        (when (and (>= count 10) (> count (* 2 htsize)))
          (setf htsize (* 2 count)
                buckets (make-array htsize :initial-element nil))
          (dotimes (i htsize) (setf (aref buckets i) (cons 0 nil)))
          (let ((old elems))
            (setf elems '())
            (dolist (e old) (insert e (mod (str-hash e) htsize)))))
        (insert name (and buckets (mod (str-hash name) htsize)))))))

(defun tables-in-hash-order (db)
  "DB's tables and views in the order SQLite's schema hash (tblHash)
visits them, as built by loading the schema: the schema table itself,
then each table or view in sqlite_schema rowid order."
  (let* ((rows (schema-rows (db-schema* db)))
         (names (cons (if (name= (db-name db) "temp") "sqlite_temp_master" "sqlite_master")
                      (loop for (nil type name nil nil sql) in rows
                            when (and (member type '("table" "view") :test #'equal) (stringp sql)
                                      (stringp name))
                              collect name))))
    (loop for n in (sqlite-hash-order (mapcar #'copy-seq names))
          for tb = (find-table-in db n)
          when tb collect tb)))

(defun reindex-table (table collation)
  "reindexTable: every index of TABLE, or those with a column in COLLATION."
  (unless (table-virtual-p table)
    (dolist (idx (sqlite-index-list table))
      (when (or (null collation)
                (some (lambda (c) (and (integerp (first c))
                                       (string-equal (collation-name (second c)) collation)))
                      (index-columns idx)))
        (let ((*db* (table-owner table)))
          (refill-index table idx))))))

(defun collation-known-p (name)
  (or (member name '("BINARY" "NOCASE" "RTRIM") :test #'string-equal)
      (gethash (string-upcase-ascii name) (db-user-collations (conn *db*)))))

(defun exec-reindex (st)
  "sqlite3Reindex: REINDEX, REINDEX collation, REINDEX [schema.]table-or-index."
  (destructuring-bind (&key name schema) (cdr st)
    (flet ((all (collation)
             (dolist (d (temp-first-list *db*))
               (dolist (tb (tables-in-hash-order d))
                 (reindex-table tb collation)))))
      (cond
        ((null name) (all nil))
        ((and (null schema) (collation-known-p name)) (all name))
        (t
         (when schema (schema-db *db* schema))
         (let ((tb (lookup-table *db* name nil schema)))
           (if tb
               (reindex-table tb nil)
               (let ((idx (lookup-index *db* name schema)))
                 (unless idx (sql-error "unable to identify the object to be reindexed"))
                 (let ((table (lookup-table *db* (index-table idx) t schema)))
                   (let ((*db* (table-owner table)))
                     (refill-index table idx)))))))))
    (values nil nil)))

(defun exec-create-index (st text)
  (destructuring-bind (&key name schema table if-not-exists &allow-other-keys) (cdr st)
   (let* ((tb (lookup-table *db* table t schema))
          (*db* (table-owner tb)))
    (when (gethash (schema-key name) (schema-indexes (db-schema* *db*)))
      (if if-not-exists
          (return-from exec-create-index nil)
          (sql-error "index ~a already exists" name)))
    (check-new-name name :index)
    (prepared-here)
    (let ((tb (find-table-in *db* table)))
      (when (table-view-select tb) (sql-error "views may not be indexed"))
      (when (table-vtab tb) (sql-error "virtual tables may not be indexed"))
      (when (= (table-root tb) 1) (sql-error "table ~a may not be indexed" table))
      ;; sqlite3CreateIndex: the text runs to the ";" (or the end of input)
      (let* ((sql (stored-create-sql (statement-text st :raw text) "INDEX"))
             (idx (index-from-ast st 0 sql tb)))
        (dolist (c (index-columns idx))
          (let ((e (first c)))
            (when (and (consp e) (eq (car e) :col))
              (sql-error "no such column: ~a" (third e)))))
        (setf (index-root idx) (create-btree *db* +leaf-index+))
        (add-schema-row "index" name (table-name tb) (index-root idx) sql)
        (populate-index tb idx)
        (bump-schema-cookie)))
    nil)))

(defun exec-create-view (st text)
  (destructuring-bind (&key name schema temp if-not-exists select &allow-other-keys) (cdr st)
   (let ((*db* (ddl-target schema temp)))
    (when (find-table-in *db* name)
      (if if-not-exists
          (return-from exec-create-view nil)
          (sql-error "view ~a already exists" name)))
    (check-new-name name :view)
    ;; validate the body now, as SQLite does
    (compile-select select (make-scope))
    (prepared-here)
    (add-table-schema-row "view" name name 0 (stored-create-sql text "VIEW"))
    (bump-schema-cookie)
    nil)))

(defun exec-create-trigger (st text)
  (destructuring-bind (&key name schema temp if-not-exists table &allow-other-keys) (cdr st)
   (let* ((tb (lookup-table *db* table t (unless temp schema)))
          (*db* (if temp (temp-db *db* t) (table-owner tb))))
    (when (table-vtab tb) (sql-error "cannot create triggers on virtual tables"))
    (when (gethash (schema-key name) (schema-triggers (db-schema* *db*)))
      (if if-not-exists
          (return-from exec-create-trigger nil)
          (sql-error "trigger ~a already exists" name)))
    (prepared-here)
    (progn
      ;; sqlite3FinishTrigger: the text ends at END
      (add-schema-row "trigger" name (table-name tb) 0
                      (stored-create-sql (statement-text st :tight text) "TRIGGER"))
      (bump-schema-cookie))
    nil)))

;;; ------------------------------------------------------------------
;;; DROP

(defun object-db (kind name schema)
  "The database holding the index or trigger NAME."
  (loop for d in (if schema (list (schema-db *db* schema)) (temp-first (conn-dbs *db*)))
        when (gethash (schema-key name) (if (eq kind :index)
                                            (schema-indexes (db-schema* d))
                                            (schema-triggers (db-schema* d))))
          return d))

(defun exec-drop (st)
  (destructuring-bind (&key kind name schema if-exists) (cdr st)
    (let ((*db* (case kind
                  ((:table :view) (let ((tb (lookup-table *db* name nil schema)))
                                    (if tb (table-owner tb) *db*)))
                  (t (or (object-db kind name schema) *db*)))))
    (ecase kind
      ((:table :view)
       (let ((tb (find-table-in *db* name)))
         (when (or (null tb) (if (eq kind :view)
                                 (null (table-view-select tb))
                                 (table-view-select tb)))
           (if (or if-exists (and tb nil))
               (return-from exec-drop nil)
               (if (and tb (eq kind :table))
                   (sql-error "use DROP VIEW to delete view ~a" name)
                   (if tb
                       (sql-error "use DROP TABLE to delete table ~a" name)
                       (sql-error "no such ~(~a~): ~a" kind name)))))
         (when (= (table-root tb) 1) (sql-error "table ~a may not be dropped" name))
         (when (and (eq kind :table) (name= name "sqlite_sequence"))
           (sql-error "table sqlite_sequence may not be dropped"))
         (prepared-here)
         ;; sqlite3CodeDropTable: the triggers' rows, the sqlite_sequence row,
         ;; the other schema rows, then the b-trees (largest root first)
         (dolist (r (reverse (schema-rows-where (lambda (r) (and (equal (second r) "trigger") (stringp (fourth r))
                                                                  (name= (fourth r) name))))))
           (table-delete *db* 1 (first r)))
         (when (and (table-autoincrement tb) (sequence-table))
           (let ((seq (sequence-table)))
             (dolist (row (scan-table-rows seq nil nil))
               (when (and (stringp (svref row 0)) (name= (svref row 0) name))
                 (delete-row seq row)))))
         (delete-schema-rows (lambda (r) (and (stringp (fourth r)) (name= (fourth r) name)
                                              (not (equal (second r) "trigger")))))
         (unless (or (table-view-select tb) (table-vtab tb))
           (drop-btrees (cons (table-root tb)
                              (loop for idx in (table-indexes tb)
                                    unless (index-pk-index idx) collect (index-root idx)))))
         (when (table-vtab tb) (vtab-drop tb))
         (bump-schema-cookie)))
      (:index
       (let ((idx (gethash (schema-key name) (schema-indexes (db-schema* *db*)))))
         (unless idx
           (if if-exists (return-from exec-drop nil) (sql-error "no such index: ~a" name)))
         (when (index-auto idx)
           (sql-error "index associated with UNIQUE or PRIMARY KEY constraint cannot be dropped"))
         (prepared-here)
         (delete-schema-rows (lambda (r) (and (equal (second r) "index") (name= (third r) name))))
         (drop-btrees (list (index-root idx)))
         (bump-schema-cookie)))
      (:trigger
       (unless (gethash (schema-key name) (schema-triggers (db-schema* *db*)))
         (if if-exists (return-from exec-drop nil) (sql-error "no such trigger: ~a" name)))
       (prepared-here)
       (delete-schema-rows (lambda (r) (and (equal (second r) "trigger") (name= (third r) name))))
       (bump-schema-cookie))))
    nil))

;;; ------------------------------------------------------------------
;;; ALTER TABLE

(defun replace-token-text (sql pred new &optional always-quote)
  "Replace identifier tokens of SQL satisfying PRED with NEW (quoted)."
  (let ((toks (tokenize sql)) (out (make-string-output-stream)) (pos 0))
    (loop for tk across toks
          do (when (and (eq (tok-kind tk) :id) (funcall pred tk))
               (write-string sql out :start pos :end (tok-pos tk))
               (write-string (if always-quote
                                 (format nil "\"~a\"" (substitute-string "\"" "\"\"" new))
                                 (quote-ident new))
                             out)
               (setf pos (tok-end tk))))
    (write-string sql out :start pos)
    (get-output-stream-string out)))

(defun exec-alter (st)
  (destructuring-bind (&key table schema rename-to rename-column to add-column drop-column sql) (cdr st)
    (let* ((tb (lookup-table *db* table t schema))
           (*db* (table-owner tb)))
      (when (table-view-select tb) (sql-error "cannot alter view ~a" table))
      (when (and (>= (length table) 7) (name= (subseq table 0 7) "sqlite_"))
        (sql-error "table ~a may not be altered" table))
      (when (table-vtab tb)
        (cond (rename-column (sql-error "cannot rename columns of virtual table \"~a\"" table))
              ((or add-column drop-column) (sql-error "virtual tables may not be altered"))))
      (cond
        (rename-to
         (when (name-in-use-p rename-to)
           (unless (name= rename-to table)
             (sql-error "there is already another table or index with this name: ~a" rename-to)))
         (dolist (r (schema-rows (db-schema* *db*)))
           (when (and (stringp (fourth r)) (name= (fourth r) table))
             (let* ((type (second r))
                    (nm (third r))
                    (rsql (sixth r))
                    (new-name (cond ((equal type "table") rename-to)
                                    ((and (equal type "index")
                                          (let ((pre (format nil "sqlite_autoindex_~a_" table)))
                                            (and (> (length nm) (length pre))
                                                 (name= (subseq nm 0 (length pre)) pre))))
                                     (format nil "sqlite_autoindex_~a_~a" rename-to
                                             (subseq nm (+ 17 (length table)))))
                                    (t nm)))
                    (new-sql (when (stringp rsql)
                               (let ((seen-on (not (equal type "table"))) (done nil))
                                 (declare (ignorable seen-on))
                                 (replace-token-text
                                  rsql
                                  (lambda (tk)
                                    (and (name= (tok-value tk) table)
                                         (or (not (equal type "table")) (not done))
                                         (setf done t)))
                                  rename-to t)))))
               (rewrite-schema-row r :name new-name :tbl rename-to :sql new-sql))))
         (vtab-rename tb rename-to)
         (when (sequence-table)
           (let ((seq (sequence-table)))
             (dolist (row (scan-table-rows seq nil nil))
               (when (and (stringp (svref row 0)) (name= (svref row 0) table))
                 (let ((new (copy-seq row)))
                   (setf (svref new 0) rename-to)
                   (write-row seq new))))))
         (bump-schema-cookie))
        (add-column
         (when (find-column tb (getf add-column :name))
           (sql-error "duplicate column name: ~a" (getf add-column :name)))
         (when (getf add-column :primary-key) (sql-error "Cannot add a PRIMARY KEY column"))
         (when (getf add-column :unique) (sql-error "Cannot add a UNIQUE column"))
         (when (and (getf add-column :not-null)
                    (let ((d (getf add-column :default)))
                      (or (null d) (equal d '(:lit :null)))))
           (sql-error "Cannot add a NOT NULL column with default value NULL"))
         (let* ((r (find-if (lambda (r) (and (equal (second r) "table") (name= (third r) table)))
                            (schema-rows (db-schema* *db*))))
                (old (sixth r))
                (close (table-sql-close-paren old))
                (new (concatenate 'string
                                  (string-right-trim '(#\Space #\Tab #\Newline) (subseq old 0 close))
                                  ", " sql (subseq old close))))
           (rewrite-schema-row r :sql new))
         (bump-schema-cookie))
        (rename-column
         (let ((ci (or (find-column tb rename-column)
                       (sql-error "no such column: \"~a\"" rename-column))))
           (declare (ignore ci))
           (when (find-column tb to) (sql-error "duplicate column name: ~a" to))
           (dolist (r (schema-rows (db-schema* *db*)))
             (when (and (stringp (fourth r)) (name= (fourth r) table) (stringp (sixth r)))
               (rewrite-schema-row
                r :sql (replace-token-text (sixth r)
                                           (lambda (tk) (name= (tok-value tk) rename-column))
                                           to))))
           (bump-schema-cookie)))
        (drop-column
         (drop-column-impl tb drop-column))))
    nil))

(defun table-sql-close-paren (sql)
  "Offset of the parenthesis closing the column list of CREATE TABLE."
  (let ((depth 0))
    (loop for tk across (tokenize sql)
          do (when (eq (tok-kind tk) :op)
               (cond ((string= (tok-value tk) "(") (incf depth))
                     ((string= (tok-value tk) ")")
                      (decf depth)
                      (when (zerop depth) (return-from table-sql-close-paren (tok-pos tk)))))))
    (length sql)))

(defun drop-column-impl (tb name)
  (when (table-without-rowid tb)
    (sql-error "DROP COLUMN on WITHOUT ROWID tables is not supported"))
  (let* ((ci (or (find-column tb name) (sql-error "no such column: \"~a\"" name)))
         (col (aref (table-columns tb) ci)))
    (when (or (column-pk col) (member ci (table-pk tb)))
      (sql-error "cannot drop PRIMARY KEY column: \"~a\"" name))
    (when (column-unique col) (sql-error "cannot drop UNIQUE column: \"~a\"" name))
    (dolist (idx (table-indexes tb))
      (when (member ci (index-columns idx) :key #'first)
        (sql-error "error in index ~a after drop column: no such column: ~a" (index-name idx) name)))
    (when (<= (length (table-columns tb)) 1)
      (sql-error "cannot drop column \"~a\": no other columns exist" name))
    ;; Remove the column definition from the SQL text: the tokens from the
    ;; column's name to the next top-level comma (or the closing paren).
    (let* ((r (find-if (lambda (r) (and (equal (second r) "table") (name= (third r) (table-name tb))))
                       (schema-rows (db-schema* *db*))))
           (sql (sixth r))
           (toks (tokenize sql))
           (depth 0) (col-index -1) (start nil) (end nil) (prev-comma nil))
      (loop for k from 0 below (length toks)
            for tk = (aref toks k)
            do (cond ((and (eq (tok-kind tk) :op) (string= (tok-value tk) "("))
                      (incf depth)
                      (when (= depth 1) (setf col-index 0 start (tok-end tk) prev-comma (tok-pos tk))))
                     ((and (eq (tok-kind tk) :op) (string= (tok-value tk) ")"))
                      (when (and (= depth 1) (= col-index ci)) (setf end (tok-pos tk)) (return))
                      (decf depth))
                     ((and (= depth 1) (eq (tok-kind tk) :op) (string= (tok-value tk) ","))
                      (when (= col-index ci) (setf end (tok-pos tk)) (return))
                      (incf col-index)
                      (setf start (tok-end tk) prev-comma (tok-pos tk)))))
      (let ((new (if (= ci 0)
                     (concatenate 'string (subseq sql 0 start)
                                  (string-left-trim " " (subseq sql (min (length sql) (1+ end)))))
                     (concatenate 'string (subseq sql 0 prev-comma) (subseq sql end)))))
        ;; rewrite every row without the column
        (let ((rows (scan-table-rows tb nil nil)))
          (rewrite-schema-row r :sql new)
          (setf (db-schema *db*) nil)
          (let ((ntb (find-table-in *db* (table-name tb))))
            (dolist (row rows)
              (let ((nrow (concatenate 'vector (subseq row 0 ci) (subseq row (1+ ci)))))
                (table-insert *db* (table-root ntb) (svref nrow (1- (length nrow)))
                              (encode-record (table-record ntb nrow))))))))
      (bump-schema-cookie))))
