;;;; inspect/offline-test.lisp — offline gate for the crypto + ntor foundation.
;;;;
;;;; Proves the cipher suite against published vectors (X25519 / RFC-7748, HKDF /
;;;; RFC-5869) and the ntor handshake by full client<->server agreement: both
;;;; sides must derive identical circuit keys and the client must accept the
;;;; server's AUTH (and reject a tampered one).  The unforgeable end-to-end check
;;;; — a real CREATE2 against a live relay — comes with the link/circuit layer.

(defpackage #:cl-tor.test
  (:use #:cl)
  (:local-nicknames (#:u #:cl-tor.util) (#:c #:cl-tor.crypto) (#:n #:cl-tor.ntor)
                    (#:d #:cl-tor.directory) (#:rc #:cl-tor.relay-crypto))
  (:export #:run))

(in-package #:cl-tor.test)

(defvar *pass* 0) (defvar *fail* 0)
(defun check (name got want &key (test #'equalp))
  (if (funcall test got want)
      (progn (incf *pass*) (format t "  ok   ~a~%" name))
      (progn (incf *fail*) (format t "  FAIL ~a~%        got:  ~a~%        want: ~a~%"
                                   name got want))))
(defun check-true (name got)
  (if got (progn (incf *pass*) (format t "  ok   ~a~%" name))
      (progn (incf *fail*) (format t "  FAIL ~a (expected true)~%" name))))

(defun test-x25519 ()
  (format t "~%X25519 (RFC-7748 vector):~%")
  (check "scalarmult"
         (u:bytes->hex (c:x25519 (u:hex->bytes "a546e36bf0527c9d3b16154b82465edd62144c0ac1fc5a18506a2244ba449ac4")
                                 (u:hex->bytes "e6db6867583030db3594c1a424b15f7c726624ec26b3353b10a903a6d0ab1c4c")))
         "c3da55379de9c6908e94ea4df28d084f32eccf03491c71f754b4075577a28552" :test #'string=)
  ;; basepoint scalarmult: public(scalar) for the RFC-7748 "Alice" key
  (check "basepoint pubkey"
         (u:bytes->hex (c:x25519-public (u:hex->bytes "77076d0a7318a57d3c16c17251b26645df4c2f87ebc0992ab177fba51db92c2a")))
         "8520f0098930a754748b7ddcb43ef75a0dbf3a0d26381af4eba4a98eaa9b4e6a" :test #'string=))

(defun test-hkdf ()
  ;; RFC-5869 Test Case 1 (SHA-256): given PRK, expand INFO to 42 bytes.
  (format t "~%HKDF-Expand (RFC-5869 case 1):~%")
  (check "expand"
         (u:bytes->hex (c:hkdf-expand
                        (u:hex->bytes "077709362c2e32df0ddc3f0dc47bba6390b6c73bb50f9c3122ec844ad7c2b3e5")
                        (u:hex->bytes "f0f1f2f3f4f5f6f7f8f9") 42))
         "3cb25f25faacd57a90434f64d0362f2a2d2d0a90cf1a5a4c5db02d56ecc4c5bf34007208d5b887185865"
         :test #'string=))

(defun test-ntor ()
  (format t "~%ntor handshake (client<->server agreement):~%")
  ;; A relay's long-term ntor onion keypair + identity.
  (multiple-value-bind (b bigb) (c:gen-x25519)
    (let ((id (c:random-bytes 20)))
      (multiple-value-bind (onion-skin state) (n:client-create bigb id)
        (check "onion-skin length" (length onion-skin) n:+onionskin-len+ :test #'=)
        (multiple-value-bind (reply server-keys) (n:server-handshake onion-skin b bigb id)
          (check-true "server accepted onion-skin (addressed to it)" reply)
          (let ((client-keys (n:client-finish state reply)))
            (check-true "client accepted server AUTH" client-keys)
            (when (and client-keys server-keys)
              (check "Kf agrees" (n:circuit-keys-kf client-keys) (n:circuit-keys-kf server-keys))
              (check "Kb agrees" (n:circuit-keys-kb client-keys) (n:circuit-keys-kb server-keys))
              (check "Df agrees" (n:circuit-keys-df client-keys) (n:circuit-keys-df server-keys))
              (check "Db agrees" (n:circuit-keys-db client-keys) (n:circuit-keys-db server-keys)))
            ;; tamper: flip one AUTH byte -> client must reject
            (let ((bad (copy-seq reply)))
              (setf (aref bad 40) (logxor (aref bad 40) 1))
              (check-true "client rejects tampered AUTH" (null (n:client-finish state bad))))
            ;; wrong relay: skin addressed to a different identity -> server declines
            (multiple-value-bind (skin2 st2) (n:client-create bigb (c:random-bytes 20))
              (declare (ignore st2))
              (check-true "server declines skin for a different id"
                          (null (n:server-handshake skin2 b bigb id))))))))))

(defun test-aes-ctr ()
  (format t "~%AES-128-CTR (involution):~%")
  (let* ((key (c:random-bytes 16))
         (pt (c:random-bytes 100))
         (e (c:ctr-apply (c:aes128-ctr-cipher key) pt))
         (d (c:ctr-apply (c:aes128-ctr-cipher key) e)))
    (check-true "encrypt then decrypt round-trips" (equalp pt d))
    (check-true "ciphertext differs from plaintext" (not (equalp pt e)))))

(defun test-base64 ()
  (format t "~%base64 (RFC-4648 vectors, padded + unpadded):~%")
  (flet ((dec (s) (map 'string #'code-char (u:base64-decode s))))
    (check "Zm9vYmFy"  (dec "Zm9vYmFy") "foobar" :test #'string=)
    (check "Zm9vYmE="  (dec "Zm9vYmE=") "fooba" :test #'string=)
    (check "Zg (unpadded)" (dec "Zg") "f" :test #'string=)
    (check "20-byte id len" (length (u:base64-decode "AAAErLudKby6FyVrs1ko3b/Iq6k")) 20 :test #'=)))

(defparameter +sample-consensus+
  (format nil "network-status-version 3 microdesc~%~
r alpha AAAErLudKby6FyVrs1ko3b/Iq6k 2038-01-01 00:00:00 152.53.144.50 8443 0~%~
m MZjFbMLLC+a+LTqejOFlnJWdO6bIPXr0vWWPZQQVihY~%~
s Fast Guard Running Stable V2Dir Valid~%~
w Bandwidth=59000~%~
r beta AAB3U5aCNzT5U9IsI48P6F2285A 2038-01-01 00:00:00 188.195.48.170 9001 0~%~
m KoMvR0kTFTMsDDrYnH+OlkJKovaGYnJrwBqhlI6YlSs~%~
s Exit Fast Running Stable Valid~%~
w Bandwidth=600~%"))

(defun test-consensus-parse ()
  (format t "~%consensus parsing (fixed snippet):~%")
  (let* ((relays (d:parse-consensus +sample-consensus+))
         (a (first relays)) (b (second relays)))
    (check "relay count" (length relays) 2 :test #'=)
    (check "nickname" (d:relay-nickname a) "alpha" :test #'string=)
    (check "ip/port" (list (d:relay-ip a) (d:relay-or-port a)) '("152.53.144.50" 8443))
    (check "rsa-id is 20 bytes" (length (d:relay-rsa-id a)) 20 :test #'=)
    (check "flags" (d:relay-has-flag a "Guard") t :test (lambda (x y) (eq (and x t) y)))
    (check "bandwidth" (d:relay-bandwidth a) 59000 :test #'=)
    (check "md-digest" (d:relay-md-digest b) "KoMvR0kTFTMsDDrYnH+OlkJKovaGYnJrwBqhlI6YlSs" :test #'string=)))

(defun test-relay-crypto ()
  (format t "~%relay-cell crypto (framing + digest):~%")
  (let* ((seed (c:random-bytes 32))
         (h1 (rc:make-hop nil (n:keys-from-seed seed)))
         (h2 (rc:make-hop nil (n:keys-from-seed seed)))   ; identical initial state
         (data (c:random-bytes 50))
         (b1 (rc:build-relay-body h1 rc:+r-data+ 7 data))
         (b2 (rc:build-relay-body h2 rc:+r-data+ 7 data)))
    (check-true "body is 509 bytes" (= 509 (length b1)))
    (check-true "digest is deterministic for equal state+input" (equalp b1 b2))
    (multiple-value-bind (cmd recognized sid len rdata) (rc:parse-relay-body b1)
      (check "relay cmd round-trips" cmd rc:+r-data+ :test #'=)
      (check "recognized==0" recognized 0 :test #'=)
      (check "stream id round-trips" sid 7 :test #'=)
      (check "length round-trips" len 50 :test #'=)
      (check "data round-trips" rdata data))
    (check-true "rejects an unrecognized (random) cell"
                (not (rc:recognized-and-valid
                      (rc:make-hop nil (n:keys-from-seed (c:random-bytes 32)))
                      (c:random-bytes 509))))))

(defun test-rsa-math ()
  (format t "~%RSA helpers (modexp + DER parse):~%")
  (check "mod-expt vs reference" (c:mod-expt 4 13 497) (mod (expt 4 13) 497) :test #'=)
  (check "mod-expt big" (c:mod-expt 65537 17 (1- (expt 2 61))) (mod (expt 65537 17) (1- (expt 2 61))) :test #'=)
  ;; DER of a tiny RSAPublicKey: SEQUENCE{ INTEGER 0x00C0FF, INTEGER 0x010001 }
  (let ((der (u:cat #(#x30 #x0c #x02 #x04 #x00 #xc0 #xff #x01 #x02 #x03 #x01 #x00 #x01))))
    (multiple-value-bind (n e) (c:der-rsa-public-key der)
      (check "DER modulus" n #x00c0ff01 :test #'=)
      (check "DER exponent" e #x010001 :test #'=))))

(defun test-exit-policy ()
  (format t "~%exit port policy:~%")
  (let ((accept (d::make-relay :exit-ports '(:accept (80 . 80) (443 . 443) (8000 . 8100))))
        (reject (d::make-relay :exit-ports '(:reject (25 . 25) (119 . 119))))
        (none   (d::make-relay :exit-ports nil)))
    (check-true "accept allows listed (443)" (d:exit-allows-port accept 443))
    (check-true "accept allows range (8050)" (d:exit-allows-port accept 8050))
    (check-true "accept blocks unlisted (22)" (not (d:exit-allows-port accept 22)))
    (check-true "reject blocks listed (25)" (not (d:exit-allows-port reject 25)))
    (check-true "reject allows unlisted (443)" (d:exit-allows-port reject 443))
    (check-true "no policy = not an exit" (not (d:exit-allows-port none 443)))))

(defun test-path-constraints ()
  (format t "~%path constraints (/16 + nickname):~%")
  (let ((a (d::make-relay :nickname "a" :ip "1.2.3.4"))
        (b (d::make-relay :nickname "b" :ip "1.2.9.9"))      ; same /16 as a
        (c (d::make-relay :nickname "c" :ip "5.6.7.8")))
    (check "/16 extraction" (d::%net16 a) "1.2" :test #'string=)
    (check-true "same /16 rejected" (not (d::%distinct b a)))
    (check-true "different /16 accepted" (d::%distinct c a))
    (check-true "same nickname rejected" (not (d::%distinct a a)))))

(defun test-family ()
  (format t "~%relay family constraints:~%")
  (flet ((id (n) (let ((b (u:octets 20))) (setf (aref b 19) n) b))
         (hex (n) (string-upcase (u:bytes->hex (let ((b (u:octets 20))) (setf (aref b 19) n) b)))))
    (let ((a  (d::make-relay :rsa-id (id 1) :family-ids '("ed25519:FAM")))
          (b  (d::make-relay :rsa-id (id 2) :family-ids '("ed25519:FAM")))     ; shares family-id
          (c  (d::make-relay :rsa-id (id 3) :family (list (hex 4))))
          (dd (d::make-relay :rsa-id (id 4) :family (list (hex 3))))           ; mutual with c
          (f  (d::make-relay :rsa-id (id 5) :family (list (hex 6))))
          (g  (d::make-relay :rsa-id (id 6) :family '())))                     ; one-sided with f
      (check-true "shared family-id => same family" (d::%same-family a b))
      (check-true "mutual legacy family => same family" (d::%same-family c dd))
      (check-true "one-sided legacy => not same family" (not (d::%same-family f g)))
      (check-true "unrelated => not same family" (not (d::%same-family a c))))))

(defun run ()
  (setf *pass* 0 *fail* 0)
  (format t "~&=== cl-tor offline gate (crypto + ntor + directory + relay) ===~%")
  (test-x25519)
  (test-hkdf)
  (test-ntor)
  (test-aes-ctr)
  (test-base64)
  (test-consensus-parse)
  (test-relay-crypto)
  (test-rsa-math)
  (test-exit-policy)
  (test-path-constraints)
  (test-family)
  (format t "~%=== ~d passed, ~d failed ===~%" *pass* *fail*)
  (when (plusp *fail*) (error "cl-tor offline gate: ~d failures" *fail*))
  t)
