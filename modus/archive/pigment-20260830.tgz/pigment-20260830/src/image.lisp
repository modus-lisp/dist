;;;; src/image.lisp — data-URI + base64 + PNG/GIF/WebP/SVG decode to RGBA pixels.
;;;;
;;;; Enough to paint real image sources (an <img src="data:...">, a CSS data-URI
;;;; background, or bytes off the network): a base64 decoder, a data-URI
;;;; splitter, a PNG decoder (IHDR/PLTE/tRNS/IDAT via cram zlib inflate, scanline
;;;; unfiltering, color types 0/2/3/4/6, Adam7), a minimal GIF87a/89a decoder, a
;;;; WebP wrapper, and an SVG path rendered through stencil.  Returns an IMG
;;;; struct (w h rgba) where rgba is a (w*h*4) octet vector, straight-alpha.
;;;; JPEG (baseline + progressive) lives in jpeg.lisp.
(in-package #:pigment)

(defstruct img w h rgba
  ;; intrinsic sizing info for an SVG-sourced image (NIL for raster images): the
  ;; intrinsic width/height (NIL when absent) and ratio (a number, 0, or :infinite),
  ;; so a consumer can run the CSS default sizing algorithm instead of using the
  ;; rasterized bitmap size.
  (sw nil) (sh nil) (sr nil))

;;; ---- percent-decode (data: URIs; self-contained) -----------------------
(defun percent-decode (s)
  "Decode %XX escapes in a URI component to a string (each byte as Latin-1;
leaves '+' literal — data: URIs are not form-encoded)."
  (with-output-to-string (o)
    (let ((i 0) (n (length s)))
      (loop while (< i n) do
        (let ((c (char s i)))
          (if (and (char= c #\%) (< (+ i 2) n))
              (let ((hex (ignore-errors (parse-integer s :start (1+ i) :end (+ i 3) :radix 16))))
                (if hex (progn (write-char (code-char hex) o) (incf i 3))
                    (progn (write-char c o) (incf i))))
              (progn (write-char c o) (incf i))))))))

;;; ---- base64 ------------------------------------------------------------
(defparameter +b64+
  (let ((tbl (make-array 256 :initial-element -1)))
    (loop for c across "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"
          for i from 0 do (setf (aref tbl (char-code c)) i))
    tbl))

(defun base64-decode (string)
  "Decode a base64 STRING to an (unsigned-byte 8) vector."
  (let ((out (make-array (* 3 (ceiling (length string) 4)) :element-type '(unsigned-byte 8) :fill-pointer 0))
        (acc 0) (bits 0))
    (loop for ch across string
          for v = (if (< (char-code ch) 256) (aref +b64+ (char-code ch)) -1)
          when (>= v 0) do
            (setf acc (logior (ash acc 6) v) bits (+ bits 6))
            (when (>= bits 8) (decf bits 8) (vector-push-extend (logand (ash acc (- bits)) #xff) out)))
    out))

(defun parse-data-uri (uri)
  "Parse data:[<mime>][;base64],<data>.  Returns (values mime bytes) or NIL."
  (when (and (>= (length uri) 5) (string-equal (subseq uri 0 5) "data:"))
    (let* ((comma (position #\, uri)))
      (when comma
        (let* ((meta (subseq uri 5 comma)) (payload (subseq uri (1+ comma)))
               (b64 (search ";base64" meta :test #'char-equal))
               (mime (if b64 (subseq meta 0 b64) meta)))
          (values mime (if b64 (base64-decode payload)
                           (map '(vector (unsigned-byte 8)) #'char-code payload))))))))

;;; ---- PNG ---------------------------------------------------------------
(defun be32 (v i) (logior (ash (aref v i) 24) (ash (aref v (+ i 1)) 16) (ash (aref v (+ i 2)) 8) (aref v (+ i 3))))

(defun png-decode (bytes)
  "Decode a PNG byte vector to an IMG (RGBA), or NIL."
  (when (and (>= (length bytes) 8) (= (aref bytes 0) 137) (= (aref bytes 1) 80))
    (let ((i 8) (n (length bytes)) w h depth ctype (interlace 0)
          (idat (make-array 0 :element-type '(unsigned-byte 8) :adjustable t :fill-pointer 0))
          (plte nil) (trns nil))
      (loop while (< (+ i 8) n) do
        (let* ((len (be32 bytes i)) (type (map 'string #'code-char (subseq bytes (+ i 4) (+ i 8))))
               (ds (+ i 8)))
          (cond
            ((string= type "IHDR")
             (setf w (be32 bytes ds) h (be32 bytes (+ ds 4)) depth (aref bytes (+ ds 8)) ctype (aref bytes (+ ds 9))
                   interlace (aref bytes (+ ds 12))))
            ((string= type "PLTE") (setf plte (subseq bytes ds (+ ds len))))
            ((string= type "tRNS") (setf trns (subseq bytes ds (+ ds len))))
            ((string= type "IDAT") (loop for k from ds below (+ ds len) do (vector-push-extend (aref bytes k) idat)))
            ((string= type "IEND") (return)))
          (setf i (+ ds len 4))))   ; skip CRC
      (when (and w h depth ctype (only-supported-p depth ctype))
        ;; the inflater wants a SIMPLE array; COERCE leaves an adjustable/fill-pointer
        ;; vector unchanged, so build a fresh simple-array of the bytes.
        (png-finish w h depth ctype
                    (replace (make-array (length idat) :element-type '(unsigned-byte 8)) idat)
                    plte trns interlace)))))

(defun only-supported-p (depth ctype)
  ;; 8-bit for all colour types; plus sub-byte 1/2/4-bit for grayscale (0) and
  ;; palette (3), the only colour types PNG permits below 8 bits.
  (or (and (= depth 8) (member ctype '(0 2 3 4 6)))
      (and (member depth '(1 2 4)) (member ctype '(0 3)))))

(defun channels (ctype) (ecase ctype (0 1) (2 3) (3 1) (4 2) (6 4)))

(defun png-unfilter (raw ri stride h bpp)
  "Unfilter H scanlines of STRIDE bytes from RAW starting at index RI (each scanline
prefixed by a PNG filter-type byte).  BPP is the filter back-reference distance in
bytes (bytes-per-pixel, rounded up to 1 for sub-byte depths).  Returns (values rows
next-ri); ROWS is a fresh (STRIDE*H) octet vector of reconstructed bytes."
  (let* ((rows (make-array (* h stride) :element-type '(unsigned-byte 8))) (rp 0))
    (dotimes (y h)
      (let ((ft (aref raw ri))) (incf ri)
        (dotimes (xb stride)
          (let* ((rawb (aref raw ri))
                 (a (if (>= xb bpp) (aref rows (- rp bpp)) 0))
                 (b (if (> y 0) (aref rows (- rp stride)) 0))
                 (c (if (and (> y 0) (>= xb bpp)) (aref rows (- rp stride bpp)) 0))
                 (val (ecase ft
                        (0 rawb) (1 (+ rawb a)) (2 (+ rawb b)) (3 (+ rawb (floor (+ a b) 2)))
                        (4 (+ rawb (paeth a b c))))))
            (setf (aref rows rp) (logand val #xff)) (incf rp) (incf ri)))))
    (values rows ri)))

(defun png-unpack-bits (packed w h depth ctype)
  "Expand PACKED sub-byte (DEPTH 1/2/4) scanlines to one sample per byte (W*H
vector).  Grayscale (ctype 0) samples are scaled to the 0-255 range; palette
indices (ctype 3) are kept as-is."
  (let* ((stride (ceiling (* w depth) 8))
         (out (make-array (* w h) :element-type '(unsigned-byte 8)))
         (maxv (1- (ash 1 depth)))
         (gray (= ctype 0)) (op 0))
    (dotimes (y h)
      (let ((rowbase (* y stride)) (bitpos 0))
        (dotimes (x w)
          (declare (ignore x))
          (let* ((byteidx (+ rowbase (floor bitpos 8)))
                 (shift (- 8 depth (mod bitpos 8)))
                 (sample (logand (ash (aref packed byteidx) (- shift)) maxv)))
            (setf (aref out op) (if gray (round (* sample 255) maxv) sample))
            (incf op) (incf bitpos depth)))))
    out))

;; Adam7 interlace passes: (x-start y-start x-step y-step).
(defparameter +adam7+ '((0 0 8 8) (4 0 8 8) (0 4 4 8) (2 0 4 4) (0 2 2 4) (1 0 2 2) (0 1 1 2)))

(defun png-deinterlace (raw w h ch)
  "Reconstruct a non-interlaced W*H*CH sample buffer from Adam7-interlaced RAW."
  (let ((rows (make-array (* w h ch) :element-type '(unsigned-byte 8))) (ri 0) (stride (* w ch)))
    (dolist (pass +adam7+ rows)
      (destructuring-bind (sx sy dx dy) pass
        (let ((pw (ceiling (max 0 (- w sx)) dx)) (ph (ceiling (max 0 (- h sy)) dy)))
          (when (and (plusp pw) (plusp ph))
            (multiple-value-bind (prows nri) (png-unfilter raw ri (* pw ch) ph ch)
              (setf ri nri)
              (let ((pstride (* pw ch)))
                (dotimes (py ph)
                  (dotimes (px pw)
                    (let ((srcp (+ (* py pstride) (* px ch)))
                          (dstp (+ (* (+ sy (* py dy)) stride) (* (+ sx (* px dx)) ch))))
                      (dotimes (k ch) (setf (aref rows (+ dstp k)) (aref prows (+ srcp k)))))))))))))))

(defun png-finish (w h depth ctype idat plte trns interlace)
  (let* ((ch (channels ctype)) (sub8 (< depth 8))
         (stride (if sub8 (ceiling (* w depth) 8) (* w ch)))
         (raw (handler-case (cram:zlib-decompress idat :verify nil) (error () nil))))
    ;; sub-byte depths are only supported non-interlaced (Adam7 + <8bpp is rare).
    (when (and raw (not (and sub8 (= interlace 1)))
               (if (= interlace 1)
                   (plusp (length raw))
                   (>= (length raw) (* h (1+ stride)))))
      (let* ((prows (if (= interlace 1)
                        (png-deinterlace raw w h ch)
                        (png-unfilter raw 0 stride h (if sub8 1 ch))))
             (rows (if sub8 (png-unpack-bits prows w h depth ctype) prows)))
        ;; expand to RGBA
        (let ((rgba (make-array (* w h 4) :element-type '(unsigned-byte 8))))
          (dotimes (p (* w h))
            (let ((s (* p ch)) (d (* p 4)))
              (ecase ctype
                ;; tRNS for grayscale (ctype 0) is a single 16-bit key sample;
                ;; a pixel equal to it is fully transparent (depth 8 -> low byte).
                (0 (let ((g (aref rows s)))
                     (setf (aref rgba d) g (aref rgba (+ d 1)) g (aref rgba (+ d 2)) g
                           (aref rgba (+ d 3))
                           (if (and trns (>= (length trns) 2) (= g (aref trns 1))) 0 255))))
                ;; tRNS for truecolor (ctype 2) is an R,G,B key (16-bit each);
                ;; a pixel matching it is fully transparent (Acid2's eye tiles use
                ;; a black key so their two opposite pixels read through).
                (2 (let ((r (aref rows s)) (g (aref rows (+ s 1))) (bl (aref rows (+ s 2))))
                     (setf (aref rgba d) r (aref rgba (+ d 1)) g (aref rgba (+ d 2)) bl
                           (aref rgba (+ d 3))
                           (if (and trns (>= (length trns) 6)
                                    (= r (aref trns 1)) (= g (aref trns 3)) (= bl (aref trns 5)))
                               0 255))))
                (3 (let* ((idx (aref rows s)) (pi3 (* idx 3)))
                     (setf (aref rgba d) (if plte (aref plte pi3) 0)
                           (aref rgba (+ d 1)) (if plte (aref plte (+ pi3 1)) 0)
                           (aref rgba (+ d 2)) (if plte (aref plte (+ pi3 2)) 0)
                           (aref rgba (+ d 3)) (if (and trns (< idx (length trns))) (aref trns idx) 255))))
                (4 (let ((g (aref rows s))) (setf (aref rgba d) g (aref rgba (+ d 1)) g (aref rgba (+ d 2)) g (aref rgba (+ d 3)) (aref rows (+ s 1)))))
                (6 (setf (aref rgba d) (aref rows s) (aref rgba (+ d 1)) (aref rows (+ s 1)) (aref rgba (+ d 2)) (aref rows (+ s 2)) (aref rgba (+ d 3)) (aref rows (+ s 3)))))))
          (make-img :w w :h h :rgba rgba))))))

(defun paeth (a b c)
  (let* ((p (- (+ a b) c)) (pa (abs (- p a))) (pb (abs (- p b))) (pc (abs (- p c))))
    (cond ((and (<= pa pb) (<= pa pc)) a) ((<= pb pc) b) (t c))))

;;; ---- GIF (minimal, first frame, global palette) ------------------------
;;; ---- GIF ---------------------------------------------------------------
;;;
;;; This decoded nothing.  It read the logical-screen width and height out of the
;;; header and returned a canvas of that size with every pixel at alpha 0 — the
;;; docstring said "LZW omitted" and meant it.  The dimensions were right, so a
;;; caller doing layout saw a correctly sized image and painted a hole, and nothing
;;; anywhere reported a failure: 4096 of 4096 pixels transparent is not an error, it
;;; is a picture of nothing.  Found downstream, by an SVG conformance run whose
;;; <image> tests came out blank against a reference full of colour.
;;;
;;; The COMPRESSION is not here — CRAM:LZW-DECODE has it, next to the DEFLATE that
;;; PNG uses, because a codec that lives inside the one image format that first
;;; needed it gets written again by the next one.  What is left here is the part
;;; that really is GIF: the block structure, the colour tables, the transparent
;;; index, and interlacing.

(defparameter +gif-interlace+ '((0 8) (4 8) (2 4) (1 2))
  "GIF's four interlace passes as (first-row row-step).")

(defun gif-decode (bytes)
  "Decode a GIF87a/89a to an IMG (the FIRST frame; an animation's later frames are
   ignored), or NIL.  Honours the global and local colour tables, the graphic
   control extension's transparent index, and interlacing."
  (when (and (>= (length bytes) 13) (= (aref bytes 0) 71) (= (aref bytes 1) 73)
             (= (aref bytes 2) 70))                                    ; "GIF"
    (let* ((sw (logior (aref bytes 6) (ash (aref bytes 7) 8)))
           (sh (logior (aref bytes 8) (ash (aref bytes 9) 8)))
           (flags (aref bytes 10))
           (gct-p (logbitp 7 flags))
           (gct-size (ash 2 (logand flags 7)))
           (pos 13)
           (gct nil)
           (transparent nil))
      (when (or (zerop sw) (zerop sh)) (return-from gif-decode nil))
      (when gct-p
        (setf gct (subseq bytes pos (+ pos (* 3 gct-size))))
        (incf pos (* 3 gct-size)))
      (loop
        (when (>= pos (length bytes)) (return-from gif-decode nil))
        (let ((marker (aref bytes pos)))
          (cond
            ;; Extension block.
            ((= marker #x21)
             (let ((label (aref bytes (1+ pos))))
               (incf pos 2)
               (when (= label #xf9)                                    ; graphic control
                 (let ((gflags (aref bytes (1+ pos))))
                   (when (logbitp 0 gflags)
                     (setf transparent (aref bytes (+ pos 4))))))
               ;; Skip the sub-block chain whatever the label was.
               (loop for n = (aref bytes pos)
                     do (incf pos (1+ n))
                     until (zerop n))))
            ;; Image descriptor — the first one is the frame we return.
            ((= marker #x2c)
             (let* ((ix (logior (aref bytes (+ pos 1)) (ash (aref bytes (+ pos 2)) 8)))
                    (iy (logior (aref bytes (+ pos 3)) (ash (aref bytes (+ pos 4)) 8)))
                    (iw (logior (aref bytes (+ pos 5)) (ash (aref bytes (+ pos 6)) 8)))
                    (ih (logior (aref bytes (+ pos 7)) (ash (aref bytes (+ pos 8)) 8)))
                    (iflags (aref bytes (+ pos 9)))
                    (lct-p (logbitp 7 iflags))
                    (interlaced (logbitp 6 iflags))
                    (lct-size (ash 2 (logand iflags 7)))
                    (table gct))
               (incf pos 10)
               (when lct-p
                 (setf table (subseq bytes pos (+ pos (* 3 lct-size))))
                 (incf pos (* 3 lct-size)))
               (when (or (null table) (zerop iw) (zerop ih)) (return-from gif-decode nil))
               (let ((min-code-size (aref bytes pos)))
                 (incf pos)
                 (multiple-value-bind (idx)
                     (cram:lzw-decode bytes :start pos :min-code-size min-code-size
                                            :limit (* iw ih) :variant :gif)
                   (let ((rgba (make-array (* sw sh 4) :element-type '(unsigned-byte 8)
                                                       :initial-element 0))
                         (src 0))
                     (flet ((put (row)
                              (dotimes (col iw)
                                (when (< src (length idx))
                                  (let* ((i (aref idx src))
                                         (x (+ ix col)) (y (+ iy row)))
                                    (incf src)
                                    (when (and (< x sw) (< y sh)
                                               (not (and transparent (= i transparent))))
                                      (let ((d (* 4 (+ x (* y sw))))
                                            (p (* 3 i)))
                                        (when (< (+ p 2) (length table))
                                          (setf (aref rgba d)       (aref table p)
                                                (aref rgba (+ d 1)) (aref table (+ p 1))
                                                (aref rgba (+ d 2)) (aref table (+ p 2))
                                                (aref rgba (+ d 3)) 255)))))))))
                       (if interlaced
                           (loop for (start step) in +gif-interlace+
                                 do (loop for row from start below ih by step do (put row)))
                           (dotimes (row ih) (put row))))
                     (return-from gif-decode (make-img :w sw :h sh :rgba rgba)))))))
            ;; Trailer, or anything unrecognised.
            (t (return-from gif-decode nil))))))))

;;; ---- SVG (rendered through stencil to a straight-alpha bitmap) ----------
(defun rgba-canvas->img (cv)
  "Convert a premultiplied RGBA scribe canvas to a straight-alpha IMG."
  (let* ((w (sc:canvas-width cv)) (h (sc:canvas-height cv))
         (px (sc:canvas-pixels cv)) (ap (sc:canvas-alpha cv))
         (rgba (make-array (* w h 4) :element-type '(unsigned-byte 8))))
    (dotimes (j (* w h))
      (let ((a (aref ap j)) (i3 (* 3 j)) (i4 (* 4 j)))
        (if (zerop a)
            (setf (aref rgba i4) 0 (aref rgba (+ i4 1)) 0 (aref rgba (+ i4 2)) 0 (aref rgba (+ i4 3)) 0)
            (setf (aref rgba i4)       (min 255 (floor (* (aref px i3) 255) a))
                  (aref rgba (+ i4 1)) (min 255 (floor (* (aref px (+ i3 1)) 255) a))
                  (aref rgba (+ i4 2)) (min 255 (floor (* (aref px (+ i3 2)) 255) a))
                  (aref rgba (+ i4 3)) a))))
    (make-img :w w :h h :rgba rgba)))

(defun svg-data-uri-source (uri)
  "The SVG source string carried by a data:image/svg+xml URI, or NIL."
  (let ((comma (position #\, uri)))
    (when comma
      (let* ((meta (subseq uri 5 comma)) (payload (subseq uri (1+ comma)))
             (b64 (search ";base64" meta :test #'char-equal)))
        (if b64
            (map 'string #'code-char (base64-decode payload))
            (percent-decode payload))))))

(defun decode-svg-source (src &key width height)
  "Render an SVG source string through stencil to a straight-alpha IMG.  With WIDTH
   and/or HEIGHT, rasterise at that size — SVG is vector, so it's crisp at any size
   (the viewBox is fitted into the box per preserveAspectRatio); otherwise at the
   SVG's intrinsic size.  NIL on failure."
  (when (and src (plusp (length src)))
    (let ((root (ignore-errors (st:parse-svg src))))
      (when root
        (multiple-value-bind (iw ih) (st:svg-intrinsic-size root)
          (let* ((w (max 1 (round (or width iw)))) (h (max 1 (round (or height ih))))
                 (cv (sc:make-rgba-canvas w h)))
            (ignore-errors (st:render-svg-to-canvas root :width w :height h :canvas cv))
            (let ((img (rgba-canvas->img cv)))
              (multiple-value-bind (sw sh sr) (st:svg-intrinsic-dimensions root)
                (setf (img-sw img) sw (img-sh img) sh (img-sr img) sr))
              img)))))))

(defun decode-svg-image (uri)
  "Render a data:image/svg+xml URI through stencil to a straight-alpha IMG, or NIL."
  (decode-svg-source (svg-data-uri-source uri)))

;;; ---- entry -------------------------------------------------------------
(defun decode-image (uri)
  "Decode a data: URI (PNG, GIF, JPEG or SVG) to an IMG, or NIL."
  (multiple-value-bind (mime bytes) (parse-data-uri uri)
    (cond ((and mime (search "svg" mime :test #'char-equal)) (decode-svg-image uri))
          ((null bytes) nil)
          ((search "png" (or mime "") :test #'char-equal) (png-decode bytes))
          ((or (search "jpeg" (or mime "") :test #'char-equal) (search "jpg" (or mime "") :test #'char-equal))
           (jpeg-decode bytes))
          ((search "gif" (or mime "") :test #'char-equal) (gif-decode bytes))
          ((and (>= (length bytes) 2) (= (aref bytes 0) 137)) (png-decode bytes))
          ((and (>= (length bytes) 2) (= (aref bytes 0) #xff) (= (aref bytes 1) #xd8)) (jpeg-decode bytes))
          (t nil))))

(defun svg-bytes-p (bytes)
  "True when BYTES look like SVG/XML text (starts with '<' after optional BOM/space)."
  (loop for i from 0 below (min 64 (length bytes))
        for c = (aref bytes i)
        do (cond ((member c '(9 10 13 32 #xef #xbb #xbf)))   ; whitespace / UTF-8 BOM
                 ((= c (char-code #\<))
                  (return (let ((s (map 'string #'code-char (subseq bytes i (min (length bytes) (+ i 256))))))
                            (or (search "<svg" s :test #'char-equal)
                                (search "<?xml" s :test #'char-equal)))))
                 (t (return nil)))))

(defun webp-to-img (bytes)
  "Decode a WebP (VP8 lossy or VP8L lossless) via webp-pure into an RGBA IMG, or NIL.

   The ALPHA plane is webp-pure's FOURTH value and NIL when the image is opaque.
   This hardcoded 255 and dropped it, which was invisible while only lossy VP8
   decoded — VP8 has no alpha — and became a silent bug the moment VP8L landed,
   since a lossless WebP routinely carries transparency and would have come out
   with its transparent regions painted solid."
  (multiple-value-bind (w h rgb alpha) (webp-pure:decode bytes)
    (when (and w h rgb (plusp w) (plusp h))
      (let ((rgba (make-array (* w h 4) :element-type '(unsigned-byte 8))))
        (dotimes (i (* w h))
          (setf (aref rgba (* i 4))       (aref rgb (* i 3))
                (aref rgba (+ (* i 4) 1)) (aref rgb (+ (* i 3) 1))
                (aref rgba (+ (* i 4) 2)) (aref rgb (+ (* i 3) 2))
                (aref rgba (+ (* i 4) 3)) (if alpha (aref alpha i) 255)))
        (make-img :w w :h h :rgba rgba)))))

(defun decode-image-bytes (bytes &optional mime &key width height)
  "Decode raw image BYTES (from a network fetch, not a data: URI) to an IMG, or NIL.
   Dispatches on MIME when given, else on the leading magic bytes.  WIDTH/HEIGHT (if
   given) rasterise an SVG at that size; raster formats ignore them (fixed size)."
  (when (and bytes (plusp (length bytes)))
    (cond
      ((and mime (search "svg" mime :test #'char-equal))
       (decode-svg-source (map 'string #'code-char bytes) :width width :height height))
      ((and (>= (length bytes) 8) (= (aref bytes 0) 137) (= (aref bytes 1) 80)) (png-decode bytes))
      ((and (>= (length bytes) 2) (= (aref bytes 0) #xff) (= (aref bytes 1) #xd8)) (jpeg-decode bytes))
      ((webp-pure:webp-p bytes) (ignore-errors (webp-to-img bytes)))
      ((and (>= (length bytes) 3) (= (aref bytes 0) 71) (= (aref bytes 1) 73) (= (aref bytes 2) 70))
       (gif-decode bytes))               ; "GIF"
      ((and mime (search "png" mime :test #'char-equal)) (png-decode bytes))
      ((and mime (or (search "jpeg" mime :test #'char-equal) (search "jpg" mime :test #'char-equal))) (jpeg-decode bytes))
      ((and mime (search "gif" mime :test #'char-equal)) (gif-decode bytes))
      ((svg-bytes-p bytes) (decode-svg-source (map 'string #'code-char bytes) :width width :height height))
      (t nil))))
