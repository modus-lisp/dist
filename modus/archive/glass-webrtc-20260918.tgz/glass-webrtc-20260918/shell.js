// shell.js — everything that must exist BEFORE there is a connection.
//
// ===================================================================================================
// WHAT THIS FILE IS FOR
// ===================================================================================================
//
// The client used to be one 329 KB page published to nsite.  Every client change meant a new tag, a
// publish, a check-deploy, a re-pointed site-url.env and a user reloading at a NEW url — because
// publishing REPLACES the manifest and the previous tag 404s.  That happened four times in one day.
//
// So the page is split in two along the only line that is actually forced:
//
//   SHELL    what must run before a connection exists, and therefore cannot arrive over one.
//            Signalling (nostr-tools), the PeerConnection and its channels, credentials, the
//            progress screen, error reporting, and the desktop-name display.  This is published
//            to nsite, and the whole point is that it stops changing.
//
//   PAYLOAD  everything that only matters once the connection is up: noVNC, the trackpad, the
//            modifier row, paste, the quality ladder, the warp panel, the repaint watchdog.  This
//            is served by the box over a data channel, so changing it is a gateway restart.
//
// THE SPLIT IS NOT ARBITRARY AND IT IS NOT SECURITY.  Nothing here survives a first-load MITM of
// the nsite gateway and nothing is designed as though it might; the user ruled that out of scope.
// The line is drawn at "can this byte arrive over the connection it is used to set up", and that
// question has exactly one answer per feature.
//
// ===================================================================================================
// WHY THE DESKTOP IS VISIBLE BEFORE THE PAYLOAD ARRIVES
// ===================================================================================================
//
// In VIDEO_PRIMARY mode the desktop image is VP8/RTP into a <video> element.  Decoding and painting
// it is the browser's job end to end: `vidEl.srcObject = stream` and pixels appear.  noVNC is NOT in
// that path — its canvas is kept at opacity:0 and exists only so the trackpad can map touches into
// framebuffer coordinates, and so the RFB handshake can tell us the desktop's name.
//
// The monolith nonetheless could not show a frame without noVNC, for one incidental reason: it
// positioned the video by copying the CANVAS's bounding rect, so with no canvas the video stayed at
// the 1x1 box it is initialised with.  That is a layout convenience, not a dependency.
//
// So the shell owns the video's geometry itself, from `videoWidth`/`videoHeight`, which arrive with
// the first frame and are the only inputs the job actually needs.  The payload takes geometry over
// when it lands (it has to — it adds pan and zoom, which the shell knows nothing about) by calling
// `api.video.setGeometryOwner`.  Until then the picture is letterboxed to the viewport, which is
// exactly what an untransformed noVNC canvas with scaleViewport would have produced anyway.
//
// The consequence worth having: TIME-TO-FIRST-PIXEL NO LONGER WAITS FOR 190 KB OF noVNC.  Input
// lights up a moment later, when the payload lands.
//
// ===================================================================================================
// THE VERSION CONTRACT  (the part that decides whether the shell really stabilises)
// ===================================================================================================
//
// The shell is supposed to stop changing, so it must tolerate payloads NEWER than itself.  The
// interface is one object, `api`, passed to the payload's exported `init(api)`.
//
//   * SHELL_API is an integer that increments whenever a member is ADDED.
//   * The payload exports `needs` — the lowest SHELL_API it can run against.
//   * The shell runs the payload iff `needs <= SHELL_API`.
//
// THE RULE THAT MAKES THAT SAFE IS THAT `api` IS APPEND-ONLY.  A member, once shipped, keeps its
// name, its shape and its meaning forever.  Adding is free and needs no publish, because an old
// payload simply does not reach for the new member.  REMOVING or REDEFINING one is the only change
// that forces a new shell onto nsite — which is the honest statement of what "the shell stopped
// changing" costs, and it is checkable: it is a diff of this object.
//
// A payload that needs more than we are gets REFUSED rather than run half-working: it is reported on
// screen, with the two numbers, and the desktop stays visible in view-only mode.  Running it and
// hoping would produce an undebuggable page at the far end of a link nobody can attach a console to.
//
// ===================================================================================================
// FALLBACK
// ===================================================================================================
//
// If the payload never arrives the shell is ALL THE USER HAS, so it may not sit on a spinner.  It
// says what happened, in words, and offers Retry.  The desktop stays visible throughout if video is
// flowing — view-only is a much better failure than a blank page, and it is the failure this design
// makes possible.

import { generateSecretKey, getPublicKey, finalizeEvent, getEventHash } from 'https://esm.sh/nostr-tools@2.15.0/pure';
import { SimplePool } from 'https://esm.sh/nostr-tools@2.15.0/pool';
import { getConversationKey, encrypt as nip44Encrypt } from 'https://esm.sh/nostr-tools@2.15.0/nip44';
import { wrapEvent, unwrapEvent } from 'https://esm.sh/nostr-tools@2.15.0/nip59';
import { decode } from 'https://esm.sh/nostr-tools@2.15.0/nip19';

// The shell's half of the version contract.  APPEND-ONLY — see the header.
const SHELL_API = 1;

// Ask glass for 16-bit RGB555 (see novnc/core/rfb.js): ~1/3 fewer bytes per pixel through ZRLE.
// Read by the payload's RFB, so it has to be set before the payload runs — which is here.
window.__glassFbDepth = 16;
const log = (...a) => console.log('[glass-shell]', ...a);

// A STUN server so the browser also gathers a server-reflexive (public) candidate for NAT
// traversal; host candidates still cover the LAN case.  Non-trickle: we gather fully before
// signaling, since our answer is one-shot.
const pc = new RTCPeerConnection({ iceServers: [
  { urls: 'stun:stun.cloudflare.com:3478' },   // reachable through WARP (WARP is Cloudflare)
  { urls: 'stun:stun.l.google.com:19302' },
  // TURN relay for the symmetric-NAT / cellular case (coturn behind the frps).
  { urls: 'turn:turn.ynniv.com:3478', username: 'glass', credential: 'ro0DmshIO9HX7yTiKjWlBkvQalQNkAn' },
] });
pc.oniceconnectionstatechange = () => log('ice', pc.iceConnectionState);
pc.onconnectionstatechange = () => log('conn', pc.connectionState);

// ---- ALL FOUR CHANNELS ARE CREATED HERE, BEFORE THE OFFER ------------------------------------
// This is the one piece of ordering the split absolutely may not get wrong.  Signalling is
// ONE-SHOT and NON-TRICKLE and there is no renegotiation path anywhere in the system, so a channel
// that does not exist by the time `createOffer` runs can never exist at all.  The payload arrives
// long after that — so the payload cannot create its own channels, and the shell creates every
// channel any payload might want and hands them over.
//
// Only `rfb` affects the SDP (it is DCEP-negotiated, and it is what puts the m=application section
// there at all).  The other three are `negotiated: true` on fixed stream ids, which cost ZERO bytes
// to create — there is no handshake — so creating them for a payload that never comes is free.
const ch = pc.createDataChannel('rfb', { ordered: true });        // stream 0, DCEP — raw RFB
ch.binaryType = 'arraybuffer';
const ctrl = pc.createDataChannel('control', { ordered: true, negotiated: true, id: 100 });
const warpCh = pc.createDataChannel('warp', { ordered: true, negotiated: true, id: 102 });
// 104 and not 103: negotiated ids are the application's to choose, and the convention already in
// this system is "even, near the one that already works" (control 100, warp 102).  Even ids also
// stay clear of the DCEP-allocated ids the browser hands out from the bottom.
const payloadCh = pc.createDataChannel('payload', { ordered: true, negotiated: true, id: 104 });
payloadCh.binaryType = 'arraybuffer';

// ---- the connecting overlay: the connect sequence as a checklist -------------------------------
const connEl = document.getElementById('connstatus');
const connMsg = connEl.querySelector('.msg');
const stepEls = [...connEl.querySelectorAll('.steps li')];
if (stepEls[0]) stepEls[0].classList.add('now');   // the first step is live from page load
let curStep = 0;
// Advance to step I, never backwards: everything before it reads as done, it reads as current,
// everything after stays dimmed — so the list answers "what is left?" as well as "where are we?".
const setStep = (i, label) => {
  if (i > curStep) curStep = i;
  stepEls.forEach((el, k) => {
    el.classList.toggle('done', k < curStep);
    el.classList.toggle('now', k === curStep);
  });
  if (label && stepEls[curStep]) stepEls[curStep].querySelector('.lbl').textContent = label;
};
// The second line on a completed step: the one fact worth keeping from that phase.  Setting it also
// marks the step done, because knowing the answer IS the completion.
const setDetail = (i, text) => {
  const el = stepEls[i]; if (!el) return;
  el.querySelector('.det').textContent = text;
  if (i >= curStep) setStep(i + 1);
  el.classList.add('done');
};
const setConnRaw = m => { connMsg.textContent = m; };
// Stop the sequence where it stands.  The step we never finished keeps its label but stops spinning
// and turns red, so the list itself says WHICH stage failed.
const failConn = () => {
  const el = stepEls[curStep];
  stepEls.forEach(e => e.classList.remove('now'));
  if (el) el.classList.add('fail');
};
let connHidden = false;
const hideConn = () => { if (connHidden) return; connHidden = true; connEl.style.opacity = '0';
  setTimeout(() => { connEl.style.display = 'none'; setLink(linkState); }, 440); };

// ---- diagnostics ------------------------------------------------------------------------------
// Mobile has no console, so the whole connection lifecycle goes on the page.  The payload appends
// to the SAME log through api.ui.diag, so a report copied off a phone is one timeline rather than
// two — which matters most in exactly the case this split introduces, where the interesting
// question is what the shell was doing when the payload did or did not arrive.
const hud = document.getElementById('hud');
const diagEl = document.getElementById('diag');
diagEl.style.top = '90px';
const diagLines = [], tStart = performance.now();
const stamp = () => ((performance.now() - tStart) / 1000).toFixed(1).padStart(5, ' ');
function diag(msg) {
  const line = `${stamp()} ${msg}`;
  diagLines.push(line); if (diagLines.length > 60) diagLines.shift();
  diagEl.textContent = diagLines.slice(-20).join('\n');
  console.log('[diag]', line);
}
window.addEventListener('error', e => diag('JS-ERROR ' + (e.message || e.error)));
window.addEventListener('unhandledrejection', e => diag('REJECT ' + ((e.reason && e.reason.message) || e.reason)));

// ---- the link-status pill ----------------------------------------------------------------------
const linkEl = document.getElementById('linkstat');
const linkTxt = linkEl.querySelector('.txt');
const linkBtn = linkEl.querySelector('button');
const LINK_TEXT = {
  live: 'Connected',
  checking: 'Checking the connection…',
  stalled: 'No data from your desktop',
  dropped: 'Connection lost',
  reconnecting: 'Reconnecting…',
};
let linkState = 'live', linkSaidLive = false, linkArmed = false;
// The dot introduces itself ONCE per browser.  It is the only thing on screen that appears without
// having been asked for, and an unexplained indicator is worse than none: the viewer cannot tell a
// status light from a fault.  Shown on the first HEALTHY link (not the first paint), because that is
// the moment it means something, then collapsed to the dot it will be from then on.
const INTRO_KEY = 'glass-linkintro';
function introduceLink() {
  try { if (localStorage.getItem(INTRO_KEY)) return; } catch (_) { return; }
  linkTxt.textContent = 'connection ok — this dot watches it';
  linkEl.dataset.intro = '1';
  setTimeout(() => {
    delete linkEl.dataset.intro;
    if (linkState === 'live') linkTxt.textContent = LINK_TEXT.live || 'live';
  }, 4200);
  try { localStorage.setItem(INTRO_KEY, '1'); } catch (_) {}
}
// ONE function writes the status and it writes BOTH surfaces — the pill and, while the full-screen
// overlay is up, the overlay's message line.  The two cannot drift into different vocabularies for
// the same condition because there is only one place either of them is set.
function setLink(state, text) {
  const label = text || LINK_TEXT[state] || state;
  if (state !== linkState) diag('link ' + state + (text ? ' — ' + text : ''));
  linkState = state;
  linkEl.dataset.state = state;
  if (linkTxt.textContent !== label) linkTxt.textContent = label;
  // The pill shows once the card is gone -- OR whenever the card is not the thing reporting, which
  // is now the reconnect case.  Without this the reconnect had no surface at all: card suppressed,
  // pill still hidden behind CONNHIDDEN.
  linkEl.hidden = !(connHidden || state === 'reconnecting');
  if (state === 'live' && connHidden) introduceLink();
  if (!connHidden && state !== 'live' && state !== 'reconnecting') setConnRaw(label);
}

// ---- the video element: THE DESKTOP, before anything else has loaded ---------------------------
const vidEl = document.createElement('video');
vidEl.autoplay = true; vidEl.playsInline = true; vidEl.muted = true;
vidEl.style.cssText = 'position:fixed;right:14px;bottom:140px;z-index:22;width:128px;height:128px;' +
  'border-radius:10px;background:#000;object-fit:contain;display:none;pointer-events:none;box-shadow:0 0 0 1px rgba(255,255,255,.25)';
document.body.appendChild(vidEl);
// PRESENTED frames, which are not decoded frames.  getStats' framesDecoded says the decoder
// consumed the RTP; requestVideoFrameCallback fires when a frame has actually been handed to the
// compositor.  Blank WITH this climbing is a LAYOUT fault; blank WITH it stopped is a PLAYBACK
// fault.  Same symptom, opposite fixes, so both are counted rather than guessed.
let vidPresented = 0, vidPresentAt = 0;
if (vidEl.requestVideoFrameCallback) {
  const onPresent = () => { vidPresented++; vidPresentAt = performance.now();
                            markAlive('video');
                            vidEl.requestVideoFrameCallback(onPresent); };
  vidEl.requestVideoFrameCallback(onPresent);
}
// A REJECTED play() IS A MESSAGE.  autoplay+muted+playsInline satisfies every current policy, but a
// track swap, a lost media session or an iOS resume can still leave the element paused — and a
// paused <video> keeps showing its last frame, which is indistinguishable from a dead link.
let playFails = 0, lastPlayTry = 0;
const tryPlay = (why, force) => {
  if (!vidEl.play) return;
  const t = performance.now();
  if (!force && t - lastPlayTry < 400) return;
  lastPlayTry = t;
  const p = vidEl.play();
  if (p && p.catch) p.catch(err => { playFails++;
    diag(`play() rejected (${why}): ${(err && err.name) || err}`); });
};
for (const ev of ['loadedmetadata', 'loadeddata', 'canplay', 'pause', 'stalled', 'suspend'])
  vidEl.addEventListener(ev, () => { if (vidEl.paused) tryPlay(ev); });
// A TOUCH IS A USER GESTURE and a user gesture is the one thing an autoplay policy cannot refuse.
// CAPTURE on window, because the payload's trackpad handlers are capture+stopPropagation on
// #screen; PASSIVE, so this can never preventDefault and cannot change what that layer does.
window.addEventListener('touchstart', () => { if (vidEl.paused) tryPlay('touch', true); },
                        { capture: true, passive: true });

const videoPrimary = new URLSearchParams(location.search).get('video') !== '0';

// ---- video geometry, and who owns it -----------------------------------------------------------
// THE SHELL'S OWNER IS DELIBERATELY THE SIMPLEST THING THAT IS CORRECT: letterbox the frame into
// the viewport from its own intrinsic size.  It needs no canvas, so it works from the first
// presented frame — which is the whole reason the desktop is visible before the payload lands.
//
// The payload REPLACES this (it must: it adds pan and zoom, and it glues the picture to noVNC's
// canvas so touches land where they look like they land).  One slot, one owner, so the two can
// never both be writing the element's box — which is the failure mode the monolith's comments
// spend forty lines on.
let geometryOwner = null;
const shellGeometry = () => {
  if (!videoPrimary) return;
  const vw = vidEl.videoWidth, vh = vidEl.videoHeight;
  if (!vw || !vh) return;                        // no frame yet: nothing to letterbox
  const W = innerWidth, H = innerHeight;
  const s = Math.min(W / vw, H / vh);
  const w = vw * s, h = vh * s;
  vidEl.style.transform = '';
  vidEl.style.left = Math.round((W - w) / 2) + 'px';
  vidEl.style.top = Math.round((H - h) / 2) + 'px';
  vidEl.style.width = Math.round(w) + 'px';
  vidEl.style.height = Math.round(h) + 'px';
};
let syncPending = false;
const syncVideoNow = () => { syncPending = false; (geometryOwner || shellGeometry)(); };
const syncVideo = () => { if (!syncPending) { syncPending = true; requestAnimationFrame(syncVideoNow); } };
window.__syncVideo = syncVideo;
window.addEventListener('resize', syncVideo);
// AND WHEN THE PICTURE CHANGES SHAPE, which is not the same event.  A VP8 stream can
// change resolution mid-flight — it does now, because the desktop resizes itself to the
// window looking at it — and the browser reports that by firing `resize` ON THE VIDEO
// ELEMENT, updating videoWidth/videoHeight.  The window has not moved, so the listener
// above never runs, and the geometry stays computed for the old intrinsic size: a
// 393x563 desktop letterboxed as though it were still 1280x800, which is full width and
// a third of the height.
vidEl.addEventListener('resize', syncVideo);
// loadedmetadata for the same reason at the other end: the first frame of a stream whose
// size we have never seen.
vidEl.addEventListener('loadedmetadata', syncVideo);
window.addEventListener('orientationchange', syncVideo);
// iOS Safari will occasionally keep a video layer whose box was set imperatively out of the next
// composite; a property change on the element forces it back in.  Opacity is the one to poke
// because it is orthogonal to both the transform (zoom) and the box.
const nudgeLayer = () => {
  vidEl.style.opacity = '0.999'; void vidEl.offsetHeight;
  requestAnimationFrame(() => { vidEl.style.opacity = ''; });
};

pc.addEventListener('track', (e) => {
  const stream = e.streams[0] || new MediaStream([e.track]);
  if (e.track.kind === 'video') {
    diag('VIDEO track from box (VP8)');
    vidEl.srcObject = stream;
    if (videoPrimary) {
      // pointer-events:none is essential — the payload's trackpad listens on #screen BENEATH this
      // element, so without it the video swallows every touch that lands on the desktop.
      vidEl.style.cssText = 'position:fixed;z-index:5;background:#000;object-fit:fill;' +
        'pointer-events:none;left:0;top:0;width:1px;height:1px';
      window.__vidEl = vidEl; window.__videoPrimary = true;
      syncVideo();
      // Dismiss on a REAL first frame.  requestVideoFrameCallback fires per PRESENTED frame, so it
      // is the only honest signal here — 'playing' and 'unmute' both fire on negotiation, before
      // any pixels exist.  In video-primary mode there are no framebuffer updates to dismiss on.
      const firstFrame = () => { syncVideo(); hideConn();
        diag(`first video frame — ${vidEl.videoWidth}x${vidEl.videoHeight} rs${vidEl.readyState}` +
             `${vidEl.paused ? ' PAUSED' : ''}`); };
      if (vidEl.requestVideoFrameCallback) vidEl.requestVideoFrameCallback(firstFrame);
      else vidEl.addEventListener('loadeddata', firstFrame, { once: true });
      // A timed failsafe must NOT hide the overlay: a blank screen with no explanation is worse
      // than a spinner.  If nothing has arrived by now, say what state we are actually in.
      setTimeout(() => {
        if (connHidden) return;
        if (pc.iceConnectionState === 'connected' || pc.iceConnectionState === 'completed') {
          setConnRaw('Connected — waiting for the first frame…');
        } else {
          setConnRaw('Could not reach your desktop');
          connMsg.insertAdjacentHTML('afterend',
            '<div style="max-width:22em;font-size:13px;line-height:1.5;opacity:.75;margin-top:2px">' +
            'The connection did not establish (ICE ' + pc.iceConnectionState + ').<br>' +
            'Tap ≡ for the log, or reload to try again.</div>');
          failConn();
        }
      }, 12000);
      diag('video is the primary view');
    } else {
      vidEl.style.display = '';
    }
    tryPlay('track', true);
    e.track.addEventListener('unmute', () => { diag('video track unmuted (negotiated)'); if (videoPrimary) syncVideo(); });
    return;
  }
  diag('audio track from box (muted)');
  const au = document.createElement('audio'); au.autoplay = true; au.playsInline = true;
  // MUTED UNLESS SOMEBODY ALREADY ASKED.  Muted is the right default -- it does not take the audio
  // session -- but the ask can arrive BEFORE the track does, and it did: ticking the chat's
  // speaker clicks the shell's, which found no element yet, said so into a diagnostics overlay
  // nobody had open, and dropped the request.  The box then spoke to a muted element for the rest
  // of the session with every counter on the wire looking healthy.
  au.muted = !window.__wantSpeaker;
  au.srcObject = stream;
  document.body.appendChild(au);
  window.__boxAudio = au; window.__boxStream = stream;
  const p = au.play && au.play(); if (p && p.catch) p.catch(() => {});
  // ...and tell whoever asked that it is here now, so the button can stop lying in the other
  // direction: it stays struck through until there is something to unmute, then lights itself.
  window.dispatchEvent(new Event('glass-box-audio'));
});

// ---- liveness --------------------------------------------------------------------------------
// The pill is the shell's, because the pill is what says "the payload never came" as well as what
// says "the link died" — and a status surface that can only be drawn by code which may not have
// arrived is not a status surface.  The parts that need getStats (the ICE-counter signal, the
// repaint watchdog) are the PAYLOAD's, and they feed this through api.markAlive.
const LINK_PING_MS = 10000, LINK_URGE_MS = 2500, LINK_STALL_MS = 14000, LINK_DROP_MS = 30000;
const LINK_RESUME_GRACE_MS = 9000, LINK_BG_GAP_MS = 10000;
let lastAlive = performance.now();
let lastAliveWall = Date.now();
let lastPingAt = 0, probeUntil = 0;

function markAlive(why) {
  lastAlive = performance.now(); lastAliveWall = Date.now(); probeUntil = 0;
  // ...but NOT once a reload is already scheduled.  A failing link can still land the odd consent
  // response, and without this guard the pill flapped between "Reconnecting…" and "Connected" once
  // a second right up until the reload.
  if (linkState !== 'live' && !reconnecting) { diag('link alive again (' + why + ')'); setLink('live'); }
  if (why === 'control' && !linkSaidLive) { linkSaidLive = true; clearReconnAttempts(); }
}
ctrl.addEventListener('message', () => markAlive('control'));

// ---- THE RFB GREETING ARRIVES BEFORE noVNC EXISTS, AND USED TO BE LOST ------------------------
// This is the one thing the split genuinely breaks, and it is invisible until you look for it.
//
// The `rfb` channel is opened by the shell, at the top of the file, because it has to be in the
// offer.  The box's session bridges it to glass the moment it opens, and glass — like any RFB
// server — sends its protocol-version greeting immediately.  But noVNC is in the PAYLOAD, and does
// not exist for another second or several.  Nothing is listening, so the greeting goes on the floor
// and the handshake deadlocks: the box is waiting for a version reply to a greeting the client
// never saw, and the client is waiting for a greeting that already came and went.
//
// The symptom is a session that looks entirely healthy — video playing, control channel answering,
// buttons drawn — with no desktop name, no keyboard and no mouse.  Which is exactly what the
// end-to-end test found.
//
// So the shell holds the early bytes and the payload replays them into noVNC once it has one.  The
// buffer is bounded: an RFB handshake is a few hundred bytes, and if something is pouring data at
// us before the payload has landed then keeping it is not going to help.
const rfbEarly = [];
let rfbHandedOver = false, rfbDropped = 0;
ch.addEventListener('message', e => {
  markAlive('rfb');
  if (rfbHandedOver) return;
  if (rfbEarly.length < 64) rfbEarly.push(e.data); else rfbDropped++;
});

function checkLink() {
  const now = performance.now();
  // NOT ARMED UNTIL THERE HAS BEEN A CONNECTION.  Getting one takes 10-20 s of relay round trips
  // during which nothing has arrived and nothing is wrong; judging that as a stall would overwrite
  // the connect sequence's own message every time.
  if (!linkArmed) {
    const ice = pc.iceConnectionState;
    if (pc.connectionState !== 'connected' && ice !== 'connected' && ice !== 'completed') return;
    linkArmed = true; lastAlive = now; lastAliveWall = Date.now();
    diag('link watch armed');
  }
  if (reconnecting) return;
  const visible = document.visibilityState === 'visible';
  const quiet = now - lastAlive;
  if (visible && ctrl.readyState === 'open' &&
      now - lastPingAt >= ((quiet > 6000 || probeUntil) ? LINK_URGE_MS : LINK_PING_MS)) {
    lastPingAt = now;
    try { ctrl.send('{"get":1}'); } catch (_) {}
  }
  // Ask to reconnect ON THE TRANSITION only: scheduleReconnect refuses when there is no usable
  // credential, and that refusal does not latch.
  const drop = (label, why) => {
    const first = linkState !== 'dropped';
    setLink('dropped', label);
    if (first) scheduleReconnect(why);
  };
  const st = pc.connectionState, ist = pc.iceConnectionState;
  if (st === 'failed' || st === 'closed' || ist === 'failed' || ist === 'closed') {
    drop('Connection lost', 'pc ' + st + '/' + ist); return;
  }
  if (probeUntil) {
    if (now < probeUntil) { setLink('checking'); return; }
    probeUntil = 0;
    drop('Connection lost while you were away', 'no proof of life on resume'); return;
  }
  if (quiet >= LINK_DROP_MS) { drop('Connection lost', 'silent ' + Math.round(quiet / 1000) + 's'); return; }
  if (ist === 'disconnected' && quiet < LINK_STALL_MS) { setLink('stalled', 'Connection interrupted'); return; }
  if (quiet >= LINK_STALL_MS) { setLink('stalled', 'No data for ' + Math.round(quiet / 1000) + 's'); return; }
  setLink('live');
}

// RETURNING TO THE FOREGROUND.  An iOS tab that has been away has had its timers throttled or
// stopped, so none of the ages above mean anything at the moment we wake: they say we stopped
// looking, not that anything stopped arriving.  Throw them away, ask for proof NOW, judge on the
// answer within a bounded window.
function onResume() {
  const gap = Date.now() - lastAliveWall;
  if (ctrl.readyState === 'open') { lastPingAt = performance.now(); try { ctrl.send('{"get":1}'); } catch (_) {} }
  if (!linkArmed || reconnecting) { pollHook(); return; }
  if (gap < LINK_BG_GAP_MS) { pollHook(); return; }
  lastAlive = performance.now(); lastAliveWall = Date.now();
  probeUntil = performance.now() + LINK_RESUME_GRACE_MS;
  if (api.onResumeHooks) for (const h of api.onResumeHooks) { try { h(); } catch (_) {} }
  setLink('checking');
  diag('resumed after ' + (gap / 1000).toFixed(0) + 's away — probing the link');
  pollHook();
}
// The payload installs the getStats poll here; until then there is nothing to poll and the
// control-channel ping above is the whole of the liveness check, which is enough on its own.
let pollHook = () => {};

// ---- "I am going away" ------------------------------------------------------------------------
// The box cannot tell a phone whose screen locked from a route that broke: both are silence, and
// both end as "peer silent 30s".  Since this client is a phone, ordinary backgrounding is by far
// the commonest reason the box stops hearing us — so without a hint, every time the user pockets
// their phone it would be charged as a failure of whatever ICE route happened to be selected, and
// relay on cellular would look terrible for no reason but that people go outdoors.
//
// So we say so on the way out.  ONE message, best effort, never awaited and never retried: this
// fires on the path where the browser is already suspending us, and anything that blocks here
// costs the user a frame for the sake of a statistic.  If it does not arrive, nothing breaks —
// the box treats a missing hint as UNEXPLAINED, never as proof the route died, because a phone
// that genuinely lost the network cannot send this either and that is the case being counted.
function sendAway(why) {
  if (ctrl.readyState !== 'open') return;
  try { ctrl.send(JSON.stringify({ away: 1, why: why })); } catch (_) {}
}

document.addEventListener('visibilitychange', () => {
  if (document.visibilityState !== 'visible') { sendAway('hidden'); return; }
  const dead = pc.connectionState === 'failed' || pc.connectionState === 'closed' ||
               pc.iceConnectionState === 'failed' || pc.iceConnectionState === 'closed';
  if (dead) {
    diag('returned to foreground — session is ' + pc.connectionState + '/' + pc.iceConnectionState);
    scheduleReconnect('dead on resume');
    return;
  }
  tryPlay('resume', true);
  if (videoPrimary) syncVideo();
  if (ctrl.readyState === 'open') {
    ctrl.send(JSON.stringify({ request: 'keyframe' }));
    diag('returned to foreground — play() + keyframe requested');
  }
  onResume();
});
// ...and the matching way out: iOS backgrounds a tab through pagehide without always firing a
// visibilitychange first, so the hint would be missed on the platform that needs it most.
window.addEventListener('pagehide', () => sendAway('pagehide'));
// iOS Safari can restore a page from the back/forward cache without a visibilitychange.
window.addEventListener('pageshow', e => {
  if (!e.persisted) return;
  diag('restored from bfcache — probing the link');
  onResume();
});
setInterval(() => { pollHook(); checkLink(); }, 1000);

pc.addEventListener('iceconnectionstatechange', () => {
  diag('ice ' + pc.iceConnectionState);
  if (pc.iceConnectionState === 'failed') {
    if (!connHidden) { setConnRaw('Could not reach your desktop'); failConn(); }
    scheduleReconnect('ice failed');
  }
});
pc.addEventListener('connectionstatechange', () => diag('conn ' + pc.connectionState));
pc.addEventListener('icegatheringstatechange', () => diag('gather ' + pc.iceGatheringState));
pc.addEventListener('icecandidateerror', e => diag(`cand-err ${e.errorCode} ${e.url || ''} ${(e.errorText || '').slice(0,40)}`));
ch.addEventListener('open', () => { diag('datachannel OPEN'); setStep(3); });
ch.addEventListener('close', () => diag('datachannel CLOSE'));
ctrl.addEventListener('open', () => { diag('control channel OPEN'); ctrl.send('{"get":1}'); });

// ---- the box's identity, and which box this is -------------------------------------------------
const params = new URLSearchParams(location.search);
const hraw = location.hash.replace(/^#/, '');
const hp = new URLSearchParams(hraw.includes('=') ? hraw : ('box=' + hraw));
const BOX_KEY = 'glass-box';
const storeBox = b => { try { localStorage.setItem(BOX_KEY, b); } catch (_) {} };
const loadBox = () => {
  try {
    const b = localStorage.getItem(BOX_KEY);
    if (b) return b;
    for (let i = 0; i < localStorage.length; i++) {
      const k = localStorage.key(i) || '';
      const m = k.match(/^glass-(?:device|code):(.+)$/);
      if (m && m[1] !== 'default') return m[1];
    }
  } catch (_) {}
  return '';
};
const urlBox = hp.get('box') || params.get('box') || '';
if (urlBox) storeBox(urlBox);
// ROTATION SITE: derived from the gateway's NOSTR_SEC.  Rotate that and this is stale, and a fresh
// browser silently dials a box that no longer exists.  Rotated 2026-08-12.
const boxArg = urlBox || loadBox() ||
  '804f867fba14b70a9a84542a982a79d3775356a3d105e03af4bf4fd6ed7cfb55';

// ---- LEARNT-NAME: which box is this? -----------------------------------------------------------
// The question worth answering while someone watches the progress list is "is this the right
// desktop", and it has to be answered BEFORE the first packet — which rules out the box telling us,
// because glass sends its name in the RFB handshake, three steps too late.  So the box tells us
// once and we remember it, against this box's pubkey.
//
// IT IS SHELL-RESIDENT BY DEFINITION: it renders before the first byte.  Only `learnWho` — which
// runs on the RFB handshake — belongs to the payload's half of the session, so it is on `api`.
const nameKey = 'glass-name:' + boxArg;
const whoNm = document.querySelector('#connstatus .who .nm');
const whoId = document.querySelector('#connstatus .who .id');
const showWho = () => {
  let known = '';
  try { known = localStorage.getItem(nameKey) || ''; } catch (_) {}
  whoNm.textContent = known || 'this desktop — not seen before';
  whoNm.classList.toggle('unknown', !known);
  whoId.textContent = boxArg.slice(0, 12) + '…';
};
const learnWho = name => {
  const n = (name || '').trim();
  if (!n) return;
  let had = '';
  try { had = localStorage.getItem(nameKey) || ''; } catch (_) {}
  if (n === had) return;
  try { localStorage.setItem(nameKey, n); } catch (_) {}
  showWho();
  diag('desktop name: ' + n + (had ? ' (was "' + had + '")' : ''));
};
showWho();

// ---- credentials -------------------------------------------------------------------------------
// The token is nonce.exp.mac with exp a unix time, so the browser can judge its own credential
// without asking anyone: an expired link is reported as expired instead of surfacing later as a
// mysterious connection failure.
const codeExp = c => { const p = String(c || '').split('.'); const e = parseInt(p[1], 10);
                       return (p.length === 3 && isFinite(e)) ? e * 1000 : 0; };
const codeAlive = (c, marginMs = 0) => { const e = codeExp(c); return e > 0 && (e - marginMs) > Date.now(); };
const CODE_KEY = 'glass-code:' + boxArg;
const storeCode = c => { try { if (codeAlive(c)) localStorage.setItem(CODE_KEY, c); } catch (_) {} };
const loadCode = () => { try { const c = localStorage.getItem(CODE_KEY); return codeAlive(c) ? c : ''; } catch (_) { return ''; } };
const urlCode = hp.get('code') || params.get('code') || '';
if (urlCode && codeAlive(urlCode)) storeCode(urlCode);
let code = (codeAlive(urlCode) ? urlCode : '') || loadCode() || urlCode;
window.__expiredCode = Boolean(code) && !codeAlive(code);
const boxPub = boxArg.startsWith('npub') ? decode(boxArg).data : boxArg;
const relays = (params.get('relays') ||
  'wss://relay.damus.io,wss://nos.lol,wss://relay.primal.net').split(',');
const nowSec = () => Math.floor(Date.now() / 1000);
const pastTs = () => nowSec() - Math.floor(Math.random() * 172800);

const hex = u8 => [...u8].map(b => b.toString(16).padStart(2, '0')).join('');
const unhex = h => new Uint8Array(h.match(/../g).map(x => parseInt(x, 16)));
const DEV_KEY = 'glass-device:' + boxArg;
// ---- WHEN DOES THIS BROWSER'S ENROLMENT RUN OUT? -----------------------------------------------
// The box now answers that, and this is where the answer is kept.  It arrives in the answer
// envelope beside the renewal code (`expires`, a unix time, the desktop's own number from the
// store that will be consulted next time), and it is the only channel it could arrive on: A DENIAL
// IS ANSWERED WITH SILENCE by design, so a browser holding a dead device key cannot ask.
//
// WHAT THAT REPLACES is a guess: stamp the last admission, presume a hardcoded day, hope the box
// agrees.  The guess is KEPT as the fallback for a box that does not send an expiry — an older
// gateway, or a desktop that has not been restarted — and is nothing more than that.  Between them
// the rule is: the box's word if we have it, the stamp otherwise, and either way THIS ONLY DECIDES
// WHETHER TO OFFER THE WAY BACK IN EARLY.  It never decides whether to try; see the offer below.
const OK_KEY = 'glass-lastok:' + boxArg;
const EXP_KEY = 'glass-enrol:' + boxArg;
const DEVICE_TTL_MS = 24 * 3600 * 1000;   // the fallback guess; a hint, not a contract
const markAdmitted = () => { try { localStorage.setItem(OK_KEY, String(Date.now())); } catch (_) {} };
// STORED, OR CLEARED.  An admission that carries no expiry has to DROP the one we had, or a box
// rolled back to a build that does not send one would leave us judging today's enrolment against
// a number from last week — the one way a fact can be worse than a guess is by going stale
// silently while still looking like a fact.
const noteEnrolExpiry = s => {
  try {
    const n = Math.floor(Number(s));
    if (isFinite(n) && n > 0) localStorage.setItem(EXP_KEY, String(n));
    else localStorage.removeItem(EXP_KEY);
  } catch (_) {}
};
const enrolExpiry = () => { try { const n = +(localStorage.getItem(EXP_KEY) || 0);
                                  return isFinite(n) && n > 0 ? n * 1000 : 0; } catch (_) { return 0; } };
const staleEnrolment = () => {
  try {
    if (!hasDevice()) return false;              // nothing to be stale
    const e = enrolExpiry();
    if (e) return e <= Date.now();               // the box's own word about its own store
    const t = +(localStorage.getItem(OK_KEY) || 0);
    return !t || (Date.now() - t) > DEVICE_TTL_MS;
  } catch (_) { return false; }
};
const hasDevice = () => { try { const h = localStorage.getItem(DEV_KEY); return !!h && h.length === 64; }
                          catch (_) { return false; } };
const deviceSecret = () => {
  try {
    let h = localStorage.getItem(DEV_KEY);
    if (!h || h.length !== 64) { h = hex(generateSecretKey()); localStorage.setItem(DEV_KEY, h); }
    return unhex(h);
  } catch (_) { return generateSecretKey(); }
};

// ---- signing in: A TAP, AND NEVER OTHERWISE ----------------------------------------------------
// A NIP-07 signer is not a fallback and must not be reached for as one.  Touching window.nostr pops
// the signer's approval sheet, and doing that on a cold load — which is what "try the signer when
// there is no code and no device" amounts to — is a prompt nobody asked for, on a page that has not
// yet established there is anything wrong.  So the signer is offered as a BUTTON on the failure
// screen and nowhere else, and THIS FLAG is the entire record of "somebody tapped it".
//
// sessionStorage because the retry is a RELOAD (see SCHEDULERECONNECT for why every retry in this
// file is): it has to survive the navigation and it has to die with the tab.  CONSUMED on read, so
// one tap is one attempt — a flag that stuck would turn a single tap into a signer prompt on every
// subsequent load of that tab, which is the thing it exists to prevent.
const SIGNIN_KEY = 'glass-signin:' + boxArg;
// PEEK, not take: the waiting loop above must be able to ask whether a sign-in was requested
// without spending the request, or a slow signer would consume the flag and then not be there.
const signInAsked = () => { try { return Boolean(sessionStorage.getItem(SIGNIN_KEY)); }
                            catch (_) { return false; } };
const askSignIn = () => { try { sessionStorage.setItem(SIGNIN_KEY, '1'); } catch (_) {} };
const takeSignIn = () => {
  let w = false;
  try { w = sessionStorage.getItem(SIGNIN_KEY) === '1'; sessionStorage.removeItem(SIGNIN_KEY); }
  catch (_) {}
  return w;
};
// Reading the PROPERTY is free — an extension injects an object, and no sheet appears until one of
// its methods is called.  So this is the whole of what the failure screen is allowed to ask.
const haveSigner = () => { try { return Boolean(window.nostr); } catch (_) { return false; } };

// ---- reconnect ---------------------------------------------------------------------------------
const reconnKey = () => 'glass-reconn:' + boxArg;
const reconnAttempts = () => { try { return +(sessionStorage.getItem(reconnKey()) || 0) || 0; }
                               catch (_) { return 0; } };
const setReconnAttempts = n => { try { sessionStorage.setItem(reconnKey(), String(n)); } catch (_) {} };
const clearReconnAttempts = () => { try { sessionStorage.removeItem(reconnKey()); } catch (_) {} };
let reconnecting = false;
function scheduleReconnect(why) {
  if (reconnecting) return;
  if (!(codeAlive(loadCode()) || hasDevice())) {
    diag('not reconnecting: no usable credential (' + why + ')');
    if (window.__showNoCredential) window.__showNoCredential();
    return;
  }
  const n = reconnAttempts();
  if (n >= 6) {
    setLink('dropped', 'Could not reconnect — tap Reconnect to retry');
    setConnRaw('Could not reconnect');
    failConn();
    diag('giving up after ' + n + ' reconnect attempts (' + why + ')');
    return;
  }
  reconnecting = true;
  setReconnAttempts(n + 1);
  const delay = Math.min(30000, 1000 * Math.pow(2, n));
  const label = 'Reconnecting…' + (n ? ' (attempt ' + (n + 1) + ')' : '');
  // THE CARD DOES NOT COME BACK.  It used to: connHidden went false and the four-step panel was
  // re-staged over a desktop the viewer could still see, for a reconnect that usually takes a
  // second.  The card is a FIRST-TIME ceremony -- four steps, each explaining a stage you have
  // never seen -- and a reconnect is not a first time.  The pill already says the same thing in a
  // corner, which is why it exists.
  //
  // It is still escalated on the way OUT: giving up (above) re-stages the card, because at that
  // point the connection genuinely is not happening and a dot is too quiet for that.
  setLink('reconnecting', label);
  diag('reconnect in ' + delay + 'ms — ' + why + ' (attempt ' + (n + 1) + ')');
  // A RELOAD, so there is nothing to leak: every peer connection, interval, listener and decoder in
  // this page dies with the document.
  setTimeout(() => location.reload(), delay);
}
linkBtn.addEventListener('click', e => {
  e.stopPropagation();
  diag('reconnect requested by hand');
  clearReconnAttempts();
  reconnecting = false;
  scheduleReconnect('manual');
});

// ===================================================================================================
// THE API HANDED TO THE PAYLOAD.  APPEND-ONLY.  See the version contract in the header.
// ===================================================================================================
const api = {
  v: SHELL_API,
  pc,
  chans: { rfb: ch, ctrl, warp: warpCh, payload: payloadCh },
  // Everything that arrived on the RFB channel before there was anything to receive it — see the
  // note at RFB-EARLY.  Called once, by the payload, immediately after it constructs noVNC; it
  // stops the buffering and hands over what was held.  Calling it twice returns nothing, which is
  // the right answer to "replay it again".
  takeEarlyRfb() {
    if (rfbHandedOver) return [];
    rfbHandedOver = true;
    const held = rfbEarly.splice(0);
    if (held.length) diag(`replaying ${held.length} early RFB message(s)` +
                          (rfbDropped ? ` (${rfbDropped} dropped)` : ''));
    return held;
  },
  video: {
    el: vidEl,
    primary: videoPrimary,
    // ONE owner at a time.  Returns the owner it replaced, so a payload could in principle chain,
    // and so "who is drawing this box" is always a single answer.
    setGeometryOwner(fn) { const prev = geometryOwner; geometryOwner = fn || null; syncVideo(); return prev; },
    sync: syncVideo,
    nudge: nudgeLayer,
    play: tryPlay,
    presented: () => vidPresented,
    presentedAt: () => vidPresentAt,
    playFails: () => playFails,
  },
  ui: { diag, setLink, setStep, setDetail, setConnRaw, failConn, hideConn,
        connEl, connMsg, hud, diagEl, linkEl,
        isConnHidden: () => connHidden, linkState: () => linkState },
  markAlive,
  scheduleReconnect,
  learnWho,
  // the payload's getStats poll; the shell calls it once a second and on resume
  setPoll(fn) { pollHook = fn || (() => {}); },
  onResumeHooks: [],
  box: boxArg,
  code: () => code,
  params, hp,
  stamp: () => performance.now() - tStart,
};
window.__glass = api;

// ===================================================================================================
// THE PAYLOAD LOADER
// ===================================================================================================
//
// TRANSPORT is stream 104, negotiated, ordered.  Ordered matters: the chunks are reassembled by
// ARRIVAL ORDER and carry no sequence numbers, which is only safe because SCTP ordered delivery on
// one stream is exactly that guarantee.
//
// EXECUTION is a blob: URL and a dynamic import().  That is not a preference, it is the only route
// the nsite origin permits, and it was verified against the live response headers rather than
// assumed:
//
//     content-security-policy: default-src 'self'; script-src 'self' 'unsafe-inline' blob: https:; …
//
// `blob:` is in script-src, and there is NO 'unsafe-eval' — so `new Function` and `eval` are
// refused, and the obvious implementation of "run some JS I was handed" would have shipped a client
// that dies on the origin it is published to.  A blob URL is a real module with a real specifier,
// so the payload can also carry static imports of its own if it ever needs to.
//
// CACHING is keyed by the sha256 of the bytes the box sent, which is also how the box decides
// whether to send anything at all: we say what we have, and a box serving the same build answers
// {"t":"same"} and puts nothing on the wire.  It is an optimisation and it is written like one —
// every localStorage access is wrapped, a miss just means a transfer, and a hash mismatch throws
// the cache away rather than trusting it.

const PAYLOAD_CACHE_SHA = 'glass-payload-sha', PAYLOAD_CACHE_SRC = 'glass-payload-src';
const cacheGet = () => { try { const s = localStorage.getItem(PAYLOAD_CACHE_SHA),
                                     j = localStorage.getItem(PAYLOAD_CACHE_SRC);
                               return (s && j) ? { sha: s, src: j } : null; } catch (_) { return null; } };
const cachePut = (sha, src) => { try { localStorage.setItem(PAYLOAD_CACHE_SHA, sha);
                                       localStorage.setItem(PAYLOAD_CACHE_SRC, src); } catch (_) {} };
const cacheDrop = () => { try { localStorage.removeItem(PAYLOAD_CACHE_SHA);
                                localStorage.removeItem(PAYLOAD_CACHE_SRC); } catch (_) {} };

const sha256hex = async (bytes) => {
  const d = await crypto.subtle.digest('SHA-256', bytes);
  return hex(new Uint8Array(d));
};

let payloadState = 'idle';         // idle | asking | receiving | running | failed
let payloadRan = false;
let rxChunks = [], rxLen = 0, rxWant = null;

// The fallback surface.  A payload that never arrives leaves the shell as the whole client, so it
// has to SAY so — and offer the one thing that might help.  It deliberately does not hide the
// desktop: if video is flowing, view-only is a far better failure than a blank page, and saying
// "you can look but not touch" is only honest if you can still look.
const payloadFail = (why, detail) => {
  payloadState = 'failed';
  diag('payload: ' + why + (detail ? ' — ' + detail : ''));
  let bar = document.getElementById('payloadfail');
  if (!bar) {
    bar = document.createElement('div');
    bar.id = 'payloadfail';
    document.body.appendChild(bar);
  }
  bar.innerHTML = '';
  const txt = document.createElement('span');
  txt.textContent = (vidPresented > 0 ? 'View only — ' : '') + why;
  const btn = document.createElement('button');
  btn.type = 'button'; btn.textContent = 'Retry';
  btn.addEventListener('click', () => { bar.remove(); askPayload('retry'); });
  bar.append(txt, btn);
  if (detail) { const d = document.createElement('small'); d.textContent = detail; bar.appendChild(d); }
};

// Run a payload source string.  Everything that can go wrong here is reported rather than thrown:
// this is the far end of a link with no console on it.
const runPayload = async (src, sha) => {
  if (payloadRan) return;
  let url = null;
  try {
    url = URL.createObjectURL(new Blob([src], { type: 'text/javascript' }));
    const mod = await import(url);
    const needs = (typeof mod.needs === 'number') ? mod.needs : 0;
    // THE VERSION CHECK.  Refuse rather than half-run — see the contract in the header.
    if (needs > SHELL_API) {
      payloadFail('This desktop needs a newer client',
                  `payload wants shell API ${needs}, this shell is ${SHELL_API} — reload from a fresh link`);
      return;
    }
    if (typeof mod.init !== 'function') {
      payloadFail('The desktop sent something this client cannot run', 'payload exports no init()');
      return;
    }
    payloadRan = true; payloadState = 'running';
    const t0 = performance.now();
    await mod.init(api);
    diag(`payload running (api ${needs}<=${SHELL_API}, init ${Math.round(performance.now() - t0)}ms)`);
    if (sha) cachePut(sha, src);
    const bar = document.getElementById('payloadfail'); if (bar) bar.remove();
  } catch (err) {
    // A cached payload that will not run is a cache to throw away, not a permanent state.
    cacheDrop();
    payloadFail('The desktop client failed to start', (err && (err.message || err.name)) || String(err));
  } finally {
    if (url) URL.revokeObjectURL(url);
  }
};

const askPayload = (why) => {
  if (payloadRan) return;
  // THE COLLAPSED-BACK BUILD.  mksplit.py can emit both halves into one page (standalone.html),
  // which is the escape hatch if the payload channel is ever the problem — publish that and you are
  // exactly where the single-page client was.  There, the payload has already run at load time, so
  // asking the box for a second copy would run a SECOND init() over the first: two trackpads on
  // #screen, two button rows, two RFB objects on one channel.
  if (window.__glassPayloadInline) {
    payloadRan = true; payloadState = 'running';
    diag('payload is inline in this build — not asking the box');
    return;
  }
  if (payloadCh.readyState !== 'open') { diag('payload: channel ' + payloadCh.readyState); return; }
  payloadState = 'asking'; rxChunks = []; rxLen = 0; rxWant = null;
  const cached = cacheGet();
  const msg = { t: 'hello', api: SHELL_API, have: cached ? cached.sha : '',
                enc: (typeof DecompressionStream === 'function') ? ['gzip', 'raw'] : ['raw'] };
  try { payloadCh.send(JSON.stringify(msg)); } catch (err) { diag('payload: send failed ' + err); return; }
  diag('payload: asked (' + why + ')' + (cached ? ' have ' + cached.sha.slice(0, 12) : ' no cache'));
  // A box without the payload channel — an older build, or one started without PAYLOAD_CHANNEL —
  // simply never answers.  Say so rather than leaving a spinner; that is the whole fallback rule.
  setTimeout(() => {
    if (payloadRan || payloadState === 'receiving') return;
    if (payloadState === 'failed') return;
    payloadFail('This desktop is not serving the client',
                'no answer on the payload channel — the box may be running an older gateway');
  }, 12000);
};

payloadCh.addEventListener('open', () => { diag('payload channel OPEN'); askPayload('open'); });
payloadCh.addEventListener('close', () => diag('payload channel CLOSE'));
payloadCh.addEventListener('message', async (e) => {
  // Binary is a chunk of the transfer; a string is control.  They share one ordered stream, so a
  // chunk can never overtake the "begin" that describes it.
  if (typeof e.data !== 'string') {
    if (!rxWant) return;                                  // a chunk with no transfer: ignore
    const u8 = new Uint8Array(e.data);
    rxChunks.push(u8); rxLen += u8.length;
    if (rxLen >= rxWant.len) await finishTransfer();
    return;
  }
  let m = null; try { m = JSON.parse(e.data); } catch (_) { return; }
  if (!m) return;
  markAlive('payload');
  if (m.t === 'same') {
    const cached = cacheGet();
    if (cached && cached.sha === m.sha) {
      diag('payload: cache hit ' + m.sha.slice(0, 12) + ' (' + cached.src.length + ' B, nothing sent)');
      await runPayload(cached.src, cached.sha);
    } else {
      cacheDrop();
      payloadFail('The desktop client is missing', 'box says cached but this client has no copy');
    }
    return;
  }
  if (m.t === 'none') { payloadFail('This desktop is not serving the client', m.why || ''); return; }
  if (m.t === 'begin') {
    payloadState = 'receiving';
    rxWant = { sha: m.sha, len: m.len, enc: m.enc || 'raw', at: performance.now() };
    rxChunks = []; rxLen = 0;
    diag(`payload: receiving ${m.len} B ${rxWant.enc} sha ${String(m.sha).slice(0, 12)}`);
    if (!connHidden) setConnRaw('Loading the desktop client…');
  }
});

async function finishTransfer() {
  const want = rxWant; rxWant = null;
  const bytes = new Uint8Array(rxLen);
  let off = 0; for (const c of rxChunks) { bytes.set(c, off); off += c.length; }
  rxChunks = [];
  const ms = Math.round(performance.now() - want.at);
  try {
    const got = await sha256hex(bytes);
    if (got !== want.sha) {
      payloadFail('The desktop client arrived damaged', `sha ${got.slice(0, 12)} != ${String(want.sha).slice(0, 12)}`);
      return;
    }
    let src;
    if (want.enc === 'gzip') {
      const ds = new DecompressionStream('gzip');
      const buf = await new Response(new Blob([bytes]).stream().pipeThrough(ds)).arrayBuffer();
      src = new TextDecoder().decode(buf);
    } else {
      src = new TextDecoder().decode(bytes);
    }
    diag(`payload: ${rxLen} B in ${ms}ms (${(rxLen / 1024 / (ms / 1000)).toFixed(0)} KB/s) -> ${src.length} B source`);
    await runPayload(src, want.sha);
  } catch (err) {
    payloadFail('The desktop client could not be unpacked', (err && (err.message || err.name)) || String(err));
  }
}

// ---- signalling --------------------------------------------------------------------------------
const stepFor = {
  'gathering ICE candidates…': 0,
  'sending one-time-code offer…': 1,
  'gift-wrapping offer to the box…': 1,
  'offer sent — waiting for the box': 1,
  'answer received — establishing WebRTC…': 2,
};
const setStatus = s => { hud.textContent = s; log(s);
  const i = stepFor[s]; if (i !== undefined) setStep(i); else setConnRaw(s); };

// NIP-07 gift wrap: sign the seal through the signer (secret never exposed), wrap under a throwaway
// key.  The code path instead uses nostr-tools wrapEvent with an ephemeral key we own.
async function giftWrap07(signer, myPub, message) {
  const rumor = { pubkey: myPub, created_at: nowSec(), kind: 14, tags: [['p', boxPub]], content: message };
  rumor.id = getEventHash(rumor);
  const sealContent = await signer.nip44.encrypt(boxPub, JSON.stringify(rumor));
  const seal = await signer.signEvent({ kind: 13, created_at: pastTs(), tags: [], content: sealContent });
  const esk = generateSecretKey();
  const wrapContent = nip44Encrypt(JSON.stringify(seal), getConversationKey(esk, boxPub));
  return finalizeEvent({ kind: 1059, created_at: pastTs(), tags: [['p', boxPub]], content: wrapContent }, esk);
}
async function giftUnwrap07(signer, wrap) {
  const seal = JSON.parse(await signer.nip44.decrypt(wrap.pubkey, wrap.content));
  if (seal.pubkey !== boxPub) return null;                            // authenticate the box
  const rumor = JSON.parse(await signer.nip44.decrypt(seal.pubkey, seal.content));
  return rumor.content;
}

async function requestFreshCode(pool, sk) {
  const mine = getPublicKey(sk);
  return new Promise(resolve => {
    let done = false, sub = null;
    const finish = v => { if (!done) { done = true; try { sub && sub.close(); } catch (_) {} resolve(v); } };
    try {
      sub = pool.subscribeMany(relays, [{ kinds: [1059], '#p': [mine] }], {
        onevent: ev => {
          try {
            const r = unwrapEvent(ev, sk);
            if (r && r.pubkey === boxPub) {
              const m = String(r.content).match(/code=([A-Za-z0-9.\-_]+)/);
              if (m && codeAlive(m[1])) finish(m[1]);
            }
          } catch (_) {}
        },
      });
      pool.publish(relays, wrapEvent({ kind: 14, content: 'link', tags: [['p', boxPub]] }, sk, boxPub));
    } catch (_) { finish(null); }
    setTimeout(() => finish(null), 15000);
  });
}

const noCredential = msg => { const e = new Error(msg); e.noCredential = true; return e; };

async function makeIdentity() {
  // THE SIGNER GOES FIRST ONLY WHEN IT WAS ASKED FOR, and TAKESIGNIN is what asking looks like —
  // set by the button on the failure screen, consumed here.  Ordered before the device branch on
  // purpose: the case this exists for is a device key that IS present and IS stale, so a signer
  // that only ran when there was no device key would never run at all.
  // WAIT FOR THE SIGNER, when one was asked for.  An iOS signer extension (nostash) injects
  // window.nostr AFTER this module runs, so a bare check here is a race this side loses every
  // time: the flag stays unconsumed, we fall through to the stale code, fail, offer the button
  // again, and reload into the identical race.  The failure card below already polls for exactly
  // this reason (SIGNERLOOKS) -- that knowledge just never reached the branch that needs it.
  //
  // Bounded, and only on the path that ASKED: the ordinary load must not wait on an extension
  // that is not coming.
  if (signInAsked() && !haveSigner()) {
    diag('sign-in asked for — waiting for the signer to appear');
    for (let i = 0; i < 20 && !haveSigner(); i++) await new Promise(r => setTimeout(r, 150));
    if (!haveSigner())
      throw noCredential('Your Nostr signer did not appear. Open it once, then try again.');
  }
  if (haveSigner() && takeSignIn()) {
    const signer = window.nostr;
    if (!signer.nip44)
      throw noCredential('Your Nostr signer cannot do NIP-44 encryption, which this box requires.');
    const pub = await signer.getPublicKey();
    // The stale credential is NOT sent along.  A dead code makes the box's admission answer
    // `expired' before it falls through to the allowlist, which is a denial reason in the log for
    // a login that in fact succeeded — and the offer is being signed as somebody the allowlist
    // knows, so the code was never going to be what admitted it.
    code = '';
    diag('signing in with the NIP-07 signer (asked for by hand)');
    return { pub, mode: 'nip07',
             wrapOffer: (payload) => giftWrap07(signer, pub, payload),
             unwrap: (ev) => giftUnwrap07(signer, ev) };
  }
  // hasDevice(), not deviceSecret(): the latter MINTS a key when none exists, and a brand-new key is
  // by definition not enrolled — we would sign a well-formed offer the box then refuses.
  if (code || hasDevice()) {
    const sk = deviceSecret();
    return {
      pub: getPublicKey(sk), mode: code ? 'code' : 'device',
      wrapOffer: (payload) => wrapEvent({ kind: 14, content: payload, tags: [['p', boxPub]] }, sk, boxPub),
      unwrap: (ev) => { try { const r = unwrapEvent(ev, sk); return (r && r.pubkey === boxPub) ? r.content : null; }
                        catch { return null; } },
    };
  }
  // …and with neither, this does NOT quietly reach for window.nostr.  It used to, and that was the
  // one place in the file that prompted a signer nobody had touched.  The failure screen offers it
  // instead, which costs one tap and buys the guarantee.
  throw noCredential('No login code and no enrolled device.');
}

(async () => {
  let id;
  // ---- the failure screen, and the one thing that can be done about it -------------------------
  // Three ways to arrive here and they are all the same fact — nothing this browser holds will get
  // it in.  A denied offer is answered with SILENCE by design (the box will not confirm to an
  // unknown sender that it is listening), so "refused" and "unreachable" are indistinguishable from
  // here and the screen must not claim to know which.  What it CAN do is offer the credential the
  // page has not used: a signer, if one is present, on a tap.
  let noCredEl = null, noCredBtn = null, signerLooks = 0;
  // PENDING is the case where the page has NOT concluded anything: the box told us, last time, when
  // this enrolment would run out, that moment has passed, and the offer is going out anyway.  So
  // the card shows the ways back in WITHOUT claiming failure — it does not overwrite the connect
  // sequence's own message and does not mark the step failed, because nothing has failed yet.  The
  // two callers want opposite things from the same card and this is the whole of the difference.
  const clearWaysBackIn = () => {
    if (noCredEl) { noCredEl.remove(); noCredEl = null; }
    if (noCredBtn) { noCredBtn.remove(); noCredBtn = null; }
  };
  window.__clearWaysBackIn = clearWaysBackIn;
  const showNoCredential = (why, opts) => {
    const pending = Boolean(opts && opts.pending);
    const when = codeExp(code) ? new Date(codeExp(code))
                               : (enrolExpiry() ? new Date(enrolExpiry()) : null);
    if (!pending)
      setConnRaw(why || (code ? 'This link has expired' : 'This terminal is not enrolled'));
    // Rendered fresh each time rather than appended: the watchdog and SCHEDULERECONNECT can both
    // reach this, and a card that grew a second copy of its own advice would read as a bug.
    clearWaysBackIn();
    noCredEl = document.createElement('div');
    noCredEl.id = 'nocred';
    noCredEl.style.cssText = 'max-width:22em;font-size:13px;line-height:1.5;opacity:.75;margin-top:2px';
    const signer = haveSigner();
    noCredEl.innerHTML =
      (pending
        ? (when ? 'This browser’s access ran out on ' + when.toLocaleString() + '. Trying it anyway.<br>'
                : 'This browser’s access may have run out. Trying it anyway.<br>')
        : (when ? 'It was valid until ' + when.toLocaleString() + '.<br>' : '')) +
      (signer ? 'Sign in with your Nostr key to enrol this browser again, or DM <b>link</b> to the box for a new one.'
              : 'DM <b>link</b> to the box for a new one.');
    connMsg.insertAdjacentElement('afterend', noCredEl);
    if (signer) {
      const btn = noCredBtn = document.createElement('button');
      btn.type = 'button';
      btn.id = 'signin';
      btn.textContent = 'Sign in with Nostr';
      btn.style.cssText = 'margin-top:10px;align-self:flex-start;pointer-events:auto;' +
        'touch-action:manipulation;-webkit-tap-highlight-color:transparent;' +
        'border:1px solid rgba(124,252,155,.55);background:transparent;color:#7CFC9B;' +
        'border-radius:11px;padding:8px 14px;font:600 13px/1 -apple-system,system-ui,sans-serif';
      // THE ONLY PLACE THE SIGNER IS EVER ASKED FOR.  Not even here does this handler call it: it
      // records the tap and reloads, and MAKEIDENTITY does the asking on the way back up.  A reload
      // is the retry this file already uses everywhere (SCHEDULERECONNECT says why), and it is the
      // only honest one — the PeerConnection on this page has already gathered, offered and failed.
      btn.addEventListener('click', e => {
        e.stopPropagation();
        askSignIn();
        diag('sign-in requested by hand — reloading to offer as the signer');
        setConnRaw('Signing in…');
        btn.disabled = true;
        clearReconnAttempts();
        location.reload();
      });
      noCredEl.insertAdjacentElement('afterend', btn);
    } else if (signerLooks++ < 6) {
      // An extension injects window.nostr on its own schedule, and this screen can be painted on
      // the first turn of the event loop (no code, no device).  Absent-at-render is therefore not
      // absent, and the difference is a button that never appears — so look again for three
      // seconds.  This does NOT call the signer; it reads a property, which is free.
      setTimeout(() => { if (haveSigner()) showNoCredential(why, opts); }, 500);
    }
    if (!pending) failConn();
    diag((pending ? 'enrolment expired — offering the ways back in while we try'
                  : 'no usable credential') +
         (when ? ' (expired ' + when.toISOString() + ')' : '') +
         (signer ? ' — offering the signer' : ' — no signer to offer'));
  };
  window.__showNoCredential = showNoCredential;

  // SHOW THE WAYS BACK IN AT ONCE WHEN THE BOX SAID THIS ENROLMENT HAS RUN OUT.  The attempt still
  // goes out — the expiry is a PREDICTION, the box may have been restarted with a longer TTL, an
  // allowlisted signer may be about to admit us anyway, and a working credential must never be
  // pre-empted by a guess about it — but the sign-in button and the DM-a-link instruction are on
  // the page beside the spinner instead of half a minute later.  The old order made the page LOOK
  // broken for thirty seconds before admitting it knew nothing new, and it knew this at load.
  //
  // NO TIMER AND NO SIGNER TEST ANY MORE, which is the whole of the change here:
  //   * the 900 ms wait existed because the old signal was a guess about a hardcoded TTL and it
  //     was worth letting a fast answer beat it.  The box's own expiry is not that, so waiting
  //     buys nothing and costs the thing the delay was hiding.
  //   * and the card is shown WITHOUT a signer present, because "DM link to the box" is the way
  //     back in for everybody who does not have one — which is most phones.  Gating it on a signer
  //     meant the browsers with the fewest options were told the least.  (SIGNERLOOKS still
  //     re-renders the card if an extension shows up late; it just is not a precondition.)
  if (staleEnrolment() && !codeAlive(code)) {
    showNoCredential(null, { pending: true });
  }

  // ---- TAP TO OPEN, when and only when a CODE would be spent ------------------------------------
  // A login code is one-time: redeeming it trades it for an enrolment, so a successful tap also
  // means nobody else got there first.  That property is only worth having if the code cannot be
  // spent WITHOUT a person -- and a link in a DM gets fetched by preview bots, some of which render
  // the page in a headless browser.  One of those would connect, bind the code to its own throwaway
  // key, and the human's tap would then be refused as a leak.  A false alarm that locks you out.
  //
  // So the gate is on REDEMPTION, not on connecting.  A returning terminal has an enrolment and
  // spends nothing, so it opens straight away; only a load actually carrying a fresh code waits for
  // a finger.  That also puts the connect on a user gesture, which iOS wants anyway before it will
  // play the desktop's audio or video -- see TRYPLAY and the touchstart hook.
  const willSpendCode = Boolean(urlCode) && codeAlive(urlCode) && !hasDevice();
  if (willSpendCode) {
    await new Promise(resolve => {
      setStep(0, 'Ready when you are');
      const wrap = document.createElement('div');
      wrap.style.cssText = 'display:flex;flex-direction:column;gap:8px;margin-top:4px';
      const btn = document.createElement('button');
      btn.textContent = 'Open desktop';
      btn.style.cssText = 'appearance:none;border:0;border-radius:10px;padding:11px 14px;' +
        'font:600 14px/1.2 -apple-system,system-ui,sans-serif;background:#2f6f4f;color:#eaf5ee;' +
        'touch-action:manipulation;cursor:pointer';
      const note = document.createElement('div');
      note.textContent = 'This link opens once. Tapping it uses it up.';
      note.style.cssText = 'font-size:12px;color:#8a949c';
      btn.addEventListener('click', () => { wrap.remove(); resolve(); }, { once: true });
      wrap.append(btn, note);
      connMsg.after(wrap);
      diag('holding a one-time code until tapped');
    });
  }

  try { id = await makeIdentity(); }
  catch (e) {
    // A signer that was tapped and then declined lands here too, and it must land on the SAME
    // screen — otherwise the one action the page offered leaves it with no way to offer it again.
    showNoCredential(e.noCredential ? undefined : ('Sign-in failed: ' + e.message));
    return;
  }
  const pool = new SimplePool();

  // REPLAY: this filter has no since/limit, so relays hand us every gift wrap ever addressed to this
  // device key — including answers from previous sessions, which decrypt perfectly and look exactly
  // like a fresh one.  So we correlate: the box echoes back the ice-ufrag of the offer it is
  // answering, and that is minted per PeerConnection.  Ours or it is not our answer.
  let answered = false, myUfrag = null;
  // ---- DO NOT DECRYPT THE BACKLOG -------------------------------------------------------------
  // Relays hand a new subscription every stored event matching the filter, and this filter matches
  // EVERY gift wrap ever sent to this key.  With a device key that costs nothing: unwrapping is
  // local, and the old answers are discarded on their ufrag.  With a NIP-07 signer it costs TWO
  // PERMISSION PROMPTS EACH (seal, then rumor) — a hundred taps before the one that matters.
  //
  // And a wrap cannot be judged without decrypting it: NIP-59 backdates created_at by up to two
  // days ON PURPOSE, so recency is exactly what the envelope is designed to hide.  The only honest
  // signal is EOSE — stored before it, live after it — and our answer is necessarily live, because
  // we subscribe here and publish the offer below.
  //
  // So the backlog is HELD, not decrypted.  If the live path produces an answer nobody ever pays
  // for it.  If it does not, we drain what we kept, newest first, and the old cost returns only in
  // the case that was already failing.  SINCE bounds what we are handed to the backdating window.
  const backlog = [];
  let live = false;
  const drainBacklog = () => {
    if (answered || !backlog.length) return;
    diag(`no live answer — decrypting ${backlog.length} held wrap(s)`);
    const held = backlog.splice(0).reverse();
    for (const ev of held) onWrap(ev);
  };
  const onWrap = async (ev) => {
      if (answered) return;
      try {
        let answer = await id.unwrap(ev);
        try {
          const env = JSON.parse(answer);
          if (env && env.sdp) {
            if (!myUfrag || env.ufrag !== myUfrag) {
              diag(`ignored a replayed answer (ufrag ${env.ufrag || 'none'}, want ${myUfrag || 'pending'})`);
              return;
            }
            markAdmitted();   // an answer IS the admission; nothing else proves it
            // …and the box says how long the enrolment it just renewed is good for.  Absent from
            // an older box's envelope, in which case this CLEARS what we held and we are back on
            // the stamp above.
            noteEnrolExpiry(env.expires);
            if (env.expires) diag('enrolment good until ' + new Date(env.expires * 1000).toLocaleString());
            // We are in.  Whatever the page predicted at load, the prediction is now answered, so
            // the ways-back-in card goes away rather than sitting under a working desktop.
            if (window.__clearWaysBackIn) window.__clearWaysBackIn();
            if (env.code) { storeCode(env.code); code = env.code; diag('credential renewed'); }
            answer = env.sdp;
          }
        } catch (_) { /* not JSON — a bare SDP, which only the pre-envelope box ever sent */ }
        if (answer && answer.includes('m=application')) {
          answered = true;
          const ac = (answer.match(/a=candidate[^\r\n]*/g) || []);
          diag(`answer ${answer.length}B, ${ac.length} cand (${ac.filter(c=>c.includes('srflx')).length} srflx)`);
          clearTimeout(window.__answerWatchdog);
          await pc.setRemoteDescription({ type: 'answer', sdp: answer });
          const ms = window.__offerAt ? Math.round(performance.now() - window.__offerAt) : null;
          setDetail(1, ms != null ? `answered in ${(ms / 1000).toFixed(1)}s` : 'answered');
          setStatus('answer received — establishing WebRTC…');
        }
      } catch (_) { /* not for us / not from the box */ }
  };
  pool.subscribeMany(relays,
    [{ kinds: [1059], '#p': [id.pub], since: Math.floor(Date.now() / 1000) - 2 * 86400 }], {
      onevent: ev => { if (live) onWrap(ev); else backlog.push(ev); },
      // A relay that never says EOSE would otherwise hold the backlog forever, so the timeout is
      // the real gate and EOSE is the fast one.
      oneose: () => { live = true; },
    });
  setTimeout(() => { live = true; }, 4000);
  setTimeout(drainBacklog, 12000);

  // Audio starts MUTED both ways.  A sendrecv transceiver with no track still negotiates the
  // m=audio line, and replaceTrack() attaches the real mic later without renegotiation (which our
  // one-shot Nostr signalling could not do anyway).  THE TRANSCEIVER IS THE SHELL'S because it has
  // to be in the offer; the microphone BUTTON is the payload's.
  try {
    window.__micSender = pc.addTransceiver('audio', { direction: 'sendrecv' }).sender;
    diag('audio negotiated (mic muted)');
  } catch (_) { try { pc.addTransceiver('audio', { direction: 'recvonly' }); } catch (_) {} }
  try { pc.addTransceiver('video', { direction: 'recvonly' }); diag('video recvonly requested'); } catch (_) {}
  setStatus('gathering ICE candidates…');
  await pc.setLocalDescription(await pc.createOffer());
  myUfrag = ((pc.localDescription.sdp || '').match(/a=ice-ufrag:(\S+)/) || [])[1] || null;
  // Non-trickle, but a blocked/slow STUN must NOT hang gathering (seen: 49s on cellular).
  await new Promise(res => {
    let done = false;
    const finish = why => { if (!done) { done = true; diag('gather ' + why); res(); } };
    if (pc.iceGatheringState === 'complete') return finish('complete');
    pc.addEventListener('icegatheringstatechange', () => { if (pc.iceGatheringState === 'complete') finish('complete'); });
    setTimeout(() => finish('timeout-10s'), 10000);
  });
  const cands = pc.localDescription.sdp.match(/a=candidate[^\r\n]*/g) || [];
  const nSrflx = cands.filter(c => c.includes('srflx')).length;
  const nRelay = cands.filter(c => c.includes('relay')).length;
  diag(`offer ${cands.length} cand: ${cands.length - nSrflx - nRelay} host ${nSrflx} srflx ${nRelay} relay`);
  setDetail(0, `${cands.length} routes · ${nRelay} relay`);
  window.__offerAt = performance.now();
  const payload = JSON.stringify(code ? { sdp: pc.localDescription.sdp, code } : { sdp: pc.localDescription.sdp });
  setStatus(id.mode === 'code' ? 'sending one-time-code offer…' : 'gift-wrapping offer to the box…');
  const wrap = await id.wrapOffer(payload);
  await Promise.any(pool.publish(relays, wrap));
  diag('offer published (' + id.mode + ')');
  setStatus('offer sent — waiting for the box');
  window.__answerWatchdog = setTimeout(async () => {
    if (pc.remoteDescription) return;
    // A `link' DM is signed with the DEVICE key and is answered for an enrolled device or an
    // allowlisted owner — so after a signed-in offer went unanswered there is nothing left for it
    // to prove, and fifteen seconds spent finding that out is fifteen seconds the screen spends
    // lying about what it is waiting for.
    if (!hasDevice() || id.mode === 'nip07') return window.__showNoCredential();
    diag('no answer — asking the box for a fresh code');
    setConnRaw('Renewing access…');
    const fresh = await requestFreshCode(pool, deviceSecret());
    if (fresh) { storeCode(fresh); diag('renewed — reloading'); location.reload(); }
    else window.__showNoCredential();
  }, 18000);
})();
