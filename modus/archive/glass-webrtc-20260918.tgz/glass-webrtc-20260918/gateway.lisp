;;;; gateway.lisp — serve glass over WebRTC to a browser (noVNC on the data channel).
;;;;
;;;; hunchentoot serves the noVNC page + one POST /signal for the SDP exchange.  For each
;;;; browser we set up the webrtc-data answerer (ICE-lite -> DTLS -> SCTP), and when the data
;;;; channel opens we open a TCP connection to glass's RFB server and pump bytes both ways:
;;;;   glass -> channel  (one message per read; SCTP fragments + the peer reassembles)
;;;;   channel -> glass  (noVNC's RFB client messages)
;;;; The gateway is transparent to RFB: noVNC is the client, glass is the server.

(require :asdf)
;; Bigger GC nursery: the SCTP/DTLS send path conses ~7 KB/packet, so at a few thousand
;; packets/s the default nursery collects often enough to skim ~6% off throughput.  Trade some
;; resident memory for fewer collections during a full-frame blast.  (Measured ~6%; the rest of
;; the throughput ceiling is CPU-bound in AES-GCM, not GC.)
#+sbcl (setf (sb-ext:bytes-consed-between-gcs) (* 256 1024 1024))
(handler-bind ((warning #'muffle-warning))
  (asdf:load-system "webrtc-data")
  ;; glass, for GLASS:OPEN-CONNECTION alone: the desktop can be a port or a SOCKET FILE, and the
  ;; endpoint syntax that says which lives in glass so that both ends of it cannot drift.  It
  ;; starts nothing and listens on nothing — see gateway-nostr.lisp, which loads it for the
  ;; audio, microphone and admission halves as well.
  (asdf:load-system "glass")
  (ql:quickload '(:hunchentoot) :silent t))

(in-package #:webrtc-data)

(defparameter *dir*
  ;; WHERE THIS FILE'S ASSETS ARE — novnc/ and index.html sit beside the source.
  ;;
  ;; *LOAD-PATHNAME* alone was right while this was only ever LOADed as a script, and
  ;; wrong the moment it became an ASDF system: compiling through ASDF loads a FASL out
  ;; of ~/.cache, so the directory of the thing being loaded is the cache, and noVNC
  ;; would be looked for in there.  Ask ASDF where the system's source is when the
  ;; system is registered, and fall back to the load path for a plain script load,
  ;; which is still how kiln's boot files start it.
  (or (ignore-errors (asdf:system-source-directory "glass-webrtc"))
      (uiop:pathname-directory-pathname
       (or *load-pathname* *default-pathname-defaults*))))
;; noVNC: $NOVNC_DIR, else the vendored copy next to this demo (novnc/, includes our TRLE decoder).
(defparameter *novnc* (truename (or (uiop:getenv "NOVNC_DIR")
                                    (merge-pathnames "novnc/" *dir*))))
(defparameter *index* (uiop:read-file-string (merge-pathnames "index.html" *dir*)))
(defparameter *port*       (or (ignore-errors (parse-integer (uiop:getenv "GW_PORT"))) 8765))
(defparameter *epoch* (get-internal-real-time))   ; series time origin (ms since load)
(defparameter *glass-host* (or (uiop:getenv "GLASS_HOST") "127.0.0.1")
  "Where the desktop is: a hostname beside GLASS_PORT (the default, unchanged), or a SOCKET FILE
   — `unix:/home/claude/.glass/run/seat-0.rfb', or a bare absolute path.  127.0.0.1 is not a
   boundary: every process of every uid on the box can open a loopback port.  A socket file at
   mode 0600 is owner-only and the kernel enforces it.")
(defparameter *glass-port* (or (ignore-errors (parse-integer (uiop:getenv "GLASS_PORT"))) 5900))

(defun glass-connect ()
  ;; no Nagle: we forward tiny RFB messages (FramebufferUpdateRequests, key/pointer events)
  ;; toward glass — Nagle would batch them and add ~40ms of interactive latency per round trip.
  ;; glass sets TCP_NODELAY on its accept socket; we set it on our end of the same connection.
  ;; (On a socket file there is no Nagle to disable, and OPEN-CONNECTION ignores the refusal.)
  (values (glass:open-connection :host *glass-host* :port *glass-port*)))

(defvar *last-assoc* nil)   ; most recent SCTP association, for the /stats endpoint

(defun run-session (conn)
  "Drive DTLS, then run the data channel; bridge it to glass once it opens."
  (let ((glass nil))
    (unwind-protect
        (handler-case
            (progn
              (webrtc-dtls-run conn)
              (webrtc-serve-datachannel
               conn :duration 3600.0
               :on-ready
               (lambda (assoc sid)
                 (setf glass (glass-connect) *last-assoc* assoc)
                 (format *error-output* "~&[gw] channel open (stream ~a) -> glass ~a~%"
                         sid (glass:endpoint-string :host *glass-host* :port *glass-port*))
                 ;; glass -> browser: read RFB, send each read as ONE message — SCTP now
                 ;; fragments it internally and the peer reassembles, so noVNC sees one
                 ;; onmessage per read instead of one per 1KB (far fewer data-channel events)
                 (bt:make-thread
                  (lambda ()
                    (let ((buf (make-array 16384 :element-type '(unsigned-byte 8))))
                      (handler-case
                          (loop
                            (multiple-value-bind (b n) (sb-bsd-sockets:socket-receive glass buf nil)
                              (declare (ignore b))
                              (when (or (null n) (zerop n)) (return))
                              (sctp-send-binary assoc sid (subseq buf 0 n))))
                        (error () nil))))
                  :name "glass->ch")
                 ;; transport-health monitor: log SCTP rates every 2s until the peer aborts
                 (bt:make-thread
                  (lambda ()
                    (let ((prev (sctp-stats assoc)) (t0 (get-internal-real-time)))
                      (loop until (eq (getf (sctp-stats assoc) :state) :aborted) do
                        (sleep 1.0)
                        (let* ((now (sctp-stats assoc))
                               (dt (max 1d-3 (/ (float (- (get-internal-real-time) t0) 1d0)
                                                internal-time-units-per-second))))
                          (flet ((d (k) (- (getf now k) (getf prev k))))
                            (format *error-output*
                                    "~&[stats] out ~,1f KB/s  in ~,1f KB/s  rtx ~a (~,1f%)  drops ~a  ~
                                     cwnd ~a  rwnd ~a  flight ~a  outq ~a  srtt ~a  rto ~,2f~%"
                                    (/ (d :bytes-out) 1024d0 dt) (/ (d :bytes-in) 1024d0 dt)
                                    (d :rtx)
                                    (if (plusp (d :data-out)) (* 100d0 (/ (d :rtx) (d :data-out))) 0d0)
                                    (d :drops)
                                    (getf now :cwnd) (getf now :peer-rwnd) (getf now :flight)
                                    (getf now :send-q)
                                    (let ((s (getf now :srtt-ms))) (if s (format nil "~,1fms" s) "-"))
                                    (getf now :rto))
                            ;; machine-readable series line (parsed by the perf harness)
                            (format *error-output*
                                    "~&PERFSVR ~,1f ~,2f ~,2f ~a ~a ~a ~,1f ~a ~a ~,2f~%"
                                    (/ (float (- (get-internal-real-time) *epoch*) 1d0)
                                       internal-time-units-per-second)
                                    (/ (d :bytes-out) 1024d0 dt) (/ (d :bytes-in) 1024d0 dt)
                                    (d :rtx) (d :drops) (getf now :cwnd)
                                    (or (getf now :srtt-ms) -1) (getf now :flight) (getf now :send-q)
                                    (getf now :rto))
                            (finish-output *error-output*))   ; flush: survive an ungraceful kill
                          (setf prev now t0 (get-internal-real-time))))))
                  :name "gw-stats"))
               :on-message
               (lambda (assoc sid payload)
                 (declare (ignore assoc sid))
                 (when (and glass (plusp (length payload)))
                   (sb-bsd-sockets:socket-send glass (as-u8vec payload) (length payload))))))
          (error (e) (format *error-output* "~&[gw] session error: ~a~%" e)))
      ;; cleanup: close the glass connection so glass's per-client thread exits too
      (when glass (ignore-errors (sb-bsd-sockets:socket-close glass)))
      (format *error-output* "~&[gw] session closed~%"))))

(defun handle-signal ()
  "POST /signal: body is the browser's offer SDP; return our answer SDP."
  (setf (hunchentoot:content-type*) "application/sdp")
  (let* ((offer (parse-sdp (hunchentoot:raw-post-data :force-text t)))
         ;; ICE_LOCAL_IP pins the advertised host candidate (multi-homed / netns / container
         ;; deploys, where auto-detect can't reach 8.8.8.8); nil = auto-detect.
         (agent (make-ice :local-ip (uiop:getenv "ICE_LOCAL_IP")))
         (conn (webrtc-dtls-setup agent :remote-fingerprint (sdp-fingerprint offer)))
         ;; GATHER_SRFLX=1 → advertise our public (STUN) address for NAT traversal; setting
         ;; TURN_SERVER/TURN_USER/TURN_PASS additionally Allocates a TURN relay candidate, which
         ;; covers symmetric NAT. Both add a round-trip; leave off for LAN.
         (answer (ice-answer agent offer :fingerprint (dtls-conn-fingerprint conn)
                             :gather-srflx (and (uiop:getenv "GATHER_SRFLX") t)
                             :gather-relay (and (uiop:getenv "TURN_SERVER") t))))
    (ice-serve agent)
    ;; full-agent checks (punch our NAT mapping open toward the peer) when NAT traversal is on
    (when (uiop:getenv "GATHER_SRFLX") (ice-start-checks agent))
    (bt:make-thread (lambda () (run-session conn)) :name "webrtc-session")
    answer))

(defun handle-index ()
  (setf (hunchentoot:content-type*) "text/html") *index*)

(defun handle-drop ()
  "GET /drop?rate=R — set *SCTP-DROP-RATE* (a dev knob for simulating outbound loss)."
  (setf (hunchentoot:content-type*) "text/plain")
  (let ((r (ignore-errors (read-from-string (hunchentoot:get-parameter "rate")))))
    (when (realp r)
      (setf (symbol-value (find-symbol "*SCTP-DROP-RATE*" :webrtc-data)) (float r 1d0))))
  (format nil "drop-rate=~a~%" (symbol-value (find-symbol "*SCTP-DROP-RATE*" :webrtc-data))))

(defun handle-stats ()
  "GET /stats — the current session's SCTP transport stats as JSON."
  (setf (hunchentoot:content-type*) "application/json")
  (if *last-assoc*
      (format nil "{~{~a~^,~}}"
              (loop for (k v) on (sctp-stats *last-assoc*) by #'cddr
                    collect (format nil "\"~(~a~)\":~a"
                                    k (cond ((null v) -1) ((symbolp v) (format nil "\"~(~a~)\"" v))
                                            ((floatp v) (format nil "~,2f" v)) (t v)))))
      "{}"))

(defvar *acceptor* nil "The running hunchentoot acceptor, or NIL.")

(defun start-gateway (&key (port *port*) (address "0.0.0.0") (park t))
  "Install the routes, start the server, and (unless PARK is NIL) never return.

   SEPARATED FROM LOADING, which is what lets this file be part of a system rather
   than only a script.  It used to be four top-level forms: set the dispatch table,
   START the acceptor, print a banner, and (LOOP (SLEEP 5)).  Loading the file was
   therefore the same act as running the gateway — so an ASDF component of it would
   bind a port as a side effect of COMPILE-OP, and then never return from
   LOAD-SYSTEM.  Nothing could depend on this code without also starting it.

   PARK is what kiln's boot files want: they load this and expect it to hold the
   process open.  A caller that has its own event loop passes :PARK NIL and gets the
   acceptor back."
  (setf hunchentoot:*dispatch-table*
        (list (hunchentoot:create-folder-dispatcher-and-handler "/novnc/" *novnc*)
              (hunchentoot:create-regex-dispatcher "^/signal$" #'handle-signal)
              (hunchentoot:create-regex-dispatcher "^/drop$" #'handle-drop)
              (hunchentoot:create-regex-dispatcher "^/stats$" #'handle-stats)
              (hunchentoot:create-regex-dispatcher "^/$" #'handle-index)))
  (setf *acceptor*
        (hunchentoot:start (make-instance 'hunchentoot:easy-acceptor
                                          :port port :address address)))
  (format t "~&@@ gateway on http://~a:~a  (glass ~a, noVNC ~a)~%"
          address port (glass:endpoint-string :host *glass-host* :port *glass-port*) *novnc*)
  (finish-output)
  (when park (loop (sleep 5)))
  *acceptor*)

(defun stop-gateway ()
  "Stop the acceptor if one is running.  There was no way to do this before."
  (when *acceptor*
    (ignore-errors (hunchentoot:stop *acceptor*))
    (setf *acceptor* nil)
    t))
