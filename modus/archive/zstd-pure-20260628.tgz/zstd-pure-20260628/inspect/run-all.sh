#!/usr/bin/env sh
# inspect/run-all.sh — offline gate (decode libzstd vectors; XXH64 KATs).
set -e
here=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
export CL_SOURCE_REGISTRY="(:source-registry (:tree \"$here\") :inherit-configuration)"
exec sbcl --non-interactive \
  --eval '(handler-bind ((warning (function muffle-warning))) (asdf:load-system "zstd-pure/test"))' \
  --eval '(uiop:quit (if (ignore-errors (zstd-pure.test:run)) 0 1))'
