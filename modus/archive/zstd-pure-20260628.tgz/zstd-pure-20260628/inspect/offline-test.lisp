;;;; inspect/offline-test.lisp — offline gate (reads committed vectors).
;;;;
;;;; Vectors under inspect/vectors/ were produced by libzstd (python zstandard);
;;;; <name>.raw is the original, <name>.lN.zst the level-N frame.  Decoding each
;;;; .zst must reproduce its .raw byte-for-byte.  XXH64 is checked against known
;;;; answers.  Run: sbcl --eval '(asdf:test-system "zstd-pure")'

(defpackage #:zstd-pure.test
  (:use #:cl)
  (:local-nicknames (#:z #:zstd-pure) (#:u #:zstd-pure.util) (#:xxh #:zstd-pure.xxhash))
  (:export #:run))

(in-package #:zstd-pure.test)

(defvar *pass* 0) (defvar *fail* 0)
(defun ok (name good)
  (if good (progn (incf *pass*) (format t "  ok   ~a~%" name))
      (progn (incf *fail*) (format t "  FAIL ~a~%" name))))

(defun slurp (path)
  (with-open-file (s path :element-type '(unsigned-byte 8) :if-does-not-exist nil)
    (when s
      (let ((b (make-array (file-length s) :element-type '(unsigned-byte 8))))
        (read-sequence b s) b))))

(defun vectors-dir ()
  (asdf:system-relative-pathname "zstd-pure" "inspect/vectors/"))

(defun str-octets (s) (map '(simple-array (unsigned-byte 8) (*)) #'char-code s))

(defun test-xxh64 ()
  (format t "~%XXH64 (known answers):~%")
  (ok "xxh64 \"\""   (= (xxh:xxh64 (str-octets ""))     #xef46db3751d8e999))
  (ok "xxh64 \"a\""  (= (xxh:xxh64 (str-octets "a"))    #xd24ec4f1a98c6e5b))
  (ok "xxh64 test"   (= (xxh:xxh64 (str-octets "test")) #x4fdcca5ddb678139)))

(defun test-vectors ()
  "Decode every committed .zst vector and compare to its .raw original
(byte-for-byte).  The .raw name is the prefix before the first dot."
  (format t "~%decode vs libzstd vectors:~%")
  (dolist (zf (sort (directory (merge-pathnames "*.zst" (vectors-dir)))
                    #'string< :key #'namestring))
    (let* ((nm (pathname-name zf))                       ; e.g. "text.l3"
           (base (subseq nm 0 (position #\. nm)))
           (raw (slurp (merge-pathnames (format nil "~a.raw" base) (vectors-dir)))))
      (when raw
        (ok (format nil "~a (~d B)" nm (length raw))
            (ignore-errors (equalp (z:decompress (slurp zf)) raw)))))))

(defun test-compress ()
  "Round-trip: our compressor's output must decode back to the original."
  (format t "~%compress -> decompress round-trip:~%")
  (flet ((rt (label data)
           (ok (format nil "~a (~d B)" label (length data))
               (ignore-errors (equalp (z:decompress (z:compress data)) data)))))
    (rt "empty" (str-octets ""))
    (rt "tiny" (str-octets "hi"))
    (rt "text" (str-octets (with-output-to-string (s) (dotimes (i 100) (write-string "the quick brown fox. " s)))))
    (rt "repeat" (make-array 5000 :element-type '(unsigned-byte 8) :initial-element 65))
    (let ((v (make-array 70000 :element-type '(unsigned-byte 8))))   ; multi-block, mixed
      (dotimes (i 70000) (setf (aref v i) (if (< (mod i 7) 5) 97 (mod i 256))))
      (rt "mixed-70k" v))
    (rt "checksum" (str-octets "checksummed content here, repeated. "))))

(defun run ()
  (setf *pass* 0 *fail* 0)
  (format t "~&=== zstd-pure offline gate ===~%")
  (test-xxh64)
  (test-vectors)
  (test-compress)
  (format t "~%=== ~d passed, ~d failed ===~%" *pass* *fail*)
  (when (plusp *fail*) (error "zstd-pure: ~d failures" *fail*))
  t)
