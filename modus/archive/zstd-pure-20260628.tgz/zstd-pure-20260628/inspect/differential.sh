#!/usr/bin/env sh
# inspect/differential.sh — generate varied inputs with libzstd (python zstandard)
# and verify zstd-pure decodes each byte-for-byte.  Needs: python3 + zstandard.
set -e
here=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
tmp=$(mktemp -d)
python3 - "$tmp" <<'PY'
import zstandard as z, os, sys, random
d=sys.argv[1]; random.seed(1)
t=b"the quick brown fox. "; l=b"Lorem ipsum dolor sit amet. "
cases={"empty":b"","one":b"x","k1":t*60,"k64":l*1200,
       "rand":os.urandom(140000),"big":(t+l)*4000,"huge":l*90000,
       "zeros":b"\0"*200000,"counter":bytes(range(256))*2000}
for n,data in cases.items():
    open(f"{d}/{n}.raw","wb").write(data)
    for lvl in (1,3,9,19,22):
        for ck in (0,1):
            open(f"{d}/{n}.{lvl}{ck}.zst","wb").write(
              z.ZstdCompressor(level=lvl,write_checksum=bool(ck),write_content_size=True).compress(data))
PY
export CL_SOURCE_REGISTRY="(:source-registry (:tree \"$here\") :inherit-configuration)"
sbcl --non-interactive \
  --eval '(handler-bind ((warning (function muffle-warning))) (asdf:load-system "zstd-pure"))' \
  --eval "(in-package :zstd-pure)" \
  --eval "(flet ((rd (f) (with-open-file (s f :element-type (quote (unsigned-byte 8))) (let ((b (make-array (file-length s) :element-type (quote (unsigned-byte 8))))) (read-sequence b s) b)))) (let ((p 0) (fl 0)) (dolist (zf (directory \"$tmp/*.zst\")) (let ((raw (rd (merge-pathnames (concatenate (quote string) (subseq (pathname-name zf) 0 (position #\. (pathname-name zf))) \".raw\") zf)))) (handler-case (if (equalp (decompress (rd zf)) raw) (incf p) (progn (incf fl) (format t \"MISMATCH ~a~%\" (file-namestring zf)))) (error (e) (incf fl) (format t \"ERROR ~a ~a~%\" (file-namestring zf) e))))) (format t \"~%differential vs libzstd: ~d passed, ~d failed~%\" p fl) (uiop:quit (if (zerop fl) 0 1))))"
rc=$?
rm -rf "$tmp"; exit $rc
