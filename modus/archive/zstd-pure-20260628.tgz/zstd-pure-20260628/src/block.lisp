;;;; src/block.lisp — blocks: raw/RLE + the compressed block (literals section,
;;;; sequences section, and sequence execution / LZ77).

(in-package #:zstd-pure)

;;; ---- output buffer (also the back-reference window) --------------------

(defun make-out (&optional (hint 0))
  (make-array (max hint 64) :element-type '(unsigned-byte 8) :adjustable t :fill-pointer 0))

(declaim (inline %ensure))
(defun %ensure (out n)
  (let ((need (+ (fill-pointer out) n)))
    (when (> need (array-dimension out 0))
      (adjust-array out (max need (* 2 (array-dimension out 0)))))))

(defun out-append (out src start end)
  (let ((n (- end start)) (fp (fill-pointer out)))
    (%ensure out n)
    (setf (fill-pointer out) (+ fp n))
    (replace out src :start1 fp :start2 start :end2 end)))

(defun out-fill (out byte n)
  (let ((fp (fill-pointer out)))
    (%ensure out n)
    (setf (fill-pointer out) (+ fp n))
    (fill out byte :start fp :end (+ fp n))))

(defun out-copy-match (out offset len)
  "Copy LEN bytes from OFFSET back in OUT to its end (LZ77 match; handles overlap)."
  (let ((src (- (fill-pointer out) offset)) (fp (fill-pointer out)))
    (when (< src 0) (zerr "match offset ~d exceeds output length ~d" offset fp))
    (%ensure out len)
    (setf (fill-pointer out) (+ fp len))
    (dotimes (i len) (setf (aref out (+ fp i)) (aref out (+ src i))))))

;;; ---- per-frame decoder state (persists across compressed blocks) -------

(defstruct dstate
  (huff nil)                              ; previous Huffman table (for Treeless)
  (ll nil) (of nil) (ml nil)              ; previous FSE tables (for Repeat_Mode)
  (rep (make-array 3 :element-type 'fixnum :initial-contents '(1 4 8))))

;;; ---- sequence code tables (Baseline + extra Number_of_Bits) ------------

(defparameter +ll-base+
  #(0 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 18 20 22 24 28 32 40 48 64 128 256 512
    1024 2048 4096 8192 16384 32768 65536))
(defparameter +ll-bits+
  #(0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 1 1 1 2 2 3 3 4 6 7 8 9 10 11 12 13 14 15 16))
(defparameter +ml-base+
  #(3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27 28 29 30 31 32
    33 34 35 37 39 41 43 47 51 59 67 83 99 131 259 515 1027 2051 4099 8195 16387 32771 65539))
(defparameter +ml-bits+
  #(0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 1 1 1 2 2 3 3 4 4 5 7
    8 9 10 11 12 13 14 15 16))

(defun resolve-offset (rep offval ll)
  "Translate a sequence's raw OFFVAL into an actual back-reference offset and keep
the three repeated offsets up to date (zstd repeat-offset rules)."
  (if (> offval 3)
      (let ((off (- offval 3)))
        (setf (aref rep 2) (aref rep 1) (aref rep 1) (aref rep 0) (aref rep 0) off)
        off)
      (let ((repcode (+ (1- offval) (if (zerop ll) 1 0))))
        (if (zerop repcode)
            (aref rep 0)
            (let ((off (if (= repcode 3) (1- (aref rep 0)) (aref rep repcode))))
              (when (>= repcode 2) (setf (aref rep 2) (aref rep 1)))
              (setf (aref rep 1) (aref rep 0) (aref rep 0) off)
              off)))))

;;; ---- literals section --------------------------------------------------

(defun decode-literals (r ds)
  "Decode the literals section at R (advancing it).  Returns an OCTETS buffer."
  (let* ((b0 (u:r-u8 r)) (lbt (logand b0 3)) (sf (logand (ash b0 -2) 3)))
    (if (<= lbt 1)
        ;; Raw / RLE
        (let ((regen (case sf
                       ((0 2) (ash b0 -3))
                       (1 (logior (ash b0 -4) (ash (u:r-u8 r) 4)))
                       (3 (let ((b1 (u:r-u8 r)) (b2 (u:r-u8 r)))
                            (logior (ash b0 -4) (ash b1 4) (ash b2 12)))))))
          (if (= lbt 0)
              (u:r-bytes r regen)                          ; Raw
              (let ((byte (u:r-u8 r)) (lit (u:make-octets regen)))  ; RLE
                (fill lit byte) lit)))
        ;; Compressed (2) / Treeless (3)
        (multiple-value-bind (regen comp nstreams)
            (ecase sf
              (0 (let ((v (logior b0 (ash (u:r-u8 r) 8) (ash (u:r-u8 r) 16))))
                   (values (logand (ash v -4) #x3ff) (logand (ash v -14) #x3ff) 1)))
              (1 (let ((v (logior b0 (ash (u:r-u8 r) 8) (ash (u:r-u8 r) 16))))
                   (values (logand (ash v -4) #x3ff) (logand (ash v -14) #x3ff) 4)))
              (2 (let ((v (logior b0 (ash (u:r-u8 r) 8) (ash (u:r-u8 r) 16) (ash (u:r-u8 r) 24))))
                   (values (logand (ash v -4) #x3fff) (logand (ash v -18) #x3fff) 4)))
              (3 (let ((v (logior b0 (ash (u:r-u8 r) 8) (ash (u:r-u8 r) 16)
                                  (ash (u:r-u8 r) 24) (ash (u:r-u8 r) 32))))
                   (values (logand (ash v -4) #x3ffff) (logand (ash v -22) #x3ffff) 4))))
          (let* ((litdata (u:r-bytes r comp))
                 (stream-start 0))
            (if (= lbt 2)                                  ; Compressed: read the tree
                (let ((sub (u:make-reader litdata 0 comp)))
                  (setf (dstate-huff ds) (read-huffman-tree sub)
                        stream-start (u:reader-pos sub)))
                (unless (dstate-huff ds)                   ; Treeless: reuse previous
                  (zerr "treeless literals with no prior Huffman table")))
            (let ((table (dstate-huff ds))
                  (lit (u:make-octets regen)))
              (if (= nstreams 1)
                  (huff-decode-into table (u:make-rbitr litdata stream-start comp) lit 0 regen)
                  (let* ((s1 (logior (aref litdata stream-start) (ash (aref litdata (+ stream-start 1)) 8)))
                         (s2 (logior (aref litdata (+ stream-start 2)) (ash (aref litdata (+ stream-start 3)) 8)))
                         (s3 (logior (aref litdata (+ stream-start 4)) (ash (aref litdata (+ stream-start 5)) 8)))
                         (total (- comp stream-start))
                         (s4 (- total 6 s1 s2 s3))
                         (rsz (ceiling regen 4))
                         (off (+ stream-start 6)))
                    (loop for i below 4
                          for ssize in (list s1 s2 s3 s4)
                          for dst = (* i rsz)
                          for rs = (if (= i 3) (- regen (* 3 rsz)) rsz)
                          do (huff-decode-into table (u:make-rbitr litdata off (+ off ssize)) lit dst rs)
                             (incf off ssize))))
              lit))))))

;;; ---- sequences section -------------------------------------------------

(defun %num-sequences (r)
  (let ((b0 (u:r-u8 r)))
    (cond ((< b0 128) b0)
          ((< b0 255) (+ (ash (- b0 128) 8) (u:r-u8 r)))
          (t (let ((b1 (u:r-u8 r)) (b2 (u:r-u8 r))) (+ b1 (ash b2 8) #x7f00))))))

(defun %seq-table (r mode kind ds)
  "Return the FSE table for one symbol type per its MODE, updating DS for repeats."
  (let ((tab
         (ecase mode
           (0 (ecase kind                                  ; Predefined
                (:ll (predefined-table +ll-default+ 6))
                (:of (predefined-table +of-default+ 5))
                (:ml (predefined-table +ml-default+ 6))))
           (1 (fse-rle-table (u:r-u8 r)))                  ; RLE
           (2 (multiple-value-bind (table consumed)        ; FSE_Compressed
                  (read-fse-distribution (u:make-fbitr (u:reader-bytes r) (u:reader-pos r) (u:reader-end r))
                                         (if (eq kind :of) 8 9))
                (incf (u:reader-pos r) consumed) table))
           (3 (ecase kind                                  ; Repeat
                (:ll (dstate-ll ds)) (:of (dstate-of ds)) (:ml (dstate-ml ds)))))))
    (unless tab (zerr "repeat mode for ~a with no prior table" kind))
    (ecase kind (:ll (setf (dstate-ll ds) tab)) (:of (setf (dstate-of ds) tab))
           (:ml (setf (dstate-ml ds) tab)))
    tab))

(defun decode-sequences (r block-end ds out literals)
  (let ((nseq (%num-sequences r)))
    (when (zerop nseq)
      (out-append out literals 0 (length literals))
      (return-from decode-sequences))
    (let* ((modes (u:r-u8 r))
           (ll-tab (%seq-table r (ldb (byte 2 6) modes) :ll ds))
           (of-tab (%seq-table r (ldb (byte 2 4) modes) :of ds))
           (ml-tab (%seq-table r (ldb (byte 2 2) modes) :ml ds))
           (br (u:make-rbitr (u:reader-bytes r) (u:reader-pos r) block-end))
           (rep (dstate-rep ds))
           (lit-pos 0))
      (setf (u:reader-pos r) block-end)
      (let ((ll-st (fse-init ll-tab br)) (of-st (fse-init of-tab br)) (ml-st (fse-init ml-tab br)))
        (dotimes (i nseq)
          (let* ((of-code (fse-symbol of-tab of-st))
                 (ml-code (fse-symbol ml-tab ml-st))
                 (ll-code (fse-symbol ll-tab ll-st))
                 (offval (+ (ash 1 of-code) (u:r-read br of-code)))
                 (ml (+ (aref +ml-base+ ml-code) (u:r-read br (aref +ml-bits+ ml-code))))
                 (ll (+ (aref +ll-base+ ll-code) (u:r-read br (aref +ll-bits+ ll-code))))
                 (offset (resolve-offset rep offval ll)))
            (out-append out literals lit-pos (+ lit-pos ll))
            (incf lit-pos ll)
            (out-copy-match out offset ml)
            (when (< i (1- nseq))
              (setf ll-st (fse-update ll-tab ll-st br)
                    ml-st (fse-update ml-tab ml-st br)
                    of-st (fse-update of-tab of-st br)))))
        (out-append out literals lit-pos (length literals))))))

;;; ---- block dispatch ----------------------------------------------------

(defun decode-compressed-block (r out block-size ds)
  (let ((block-end (+ (u:reader-pos r) block-size)))
    (decode-sequences r block-end ds out (decode-literals r ds))))

(defun decode-block (r out ds)
  "Decode one block, appending to OUT.  Returns T if last."
  (let* ((bh (u:r-u24 r))
         (last? (logbitp 0 bh))
         (btype (ldb (byte 2 1) bh))
         (bsize (ash bh -3)))
    (ecase btype
      (0 (let ((blk (u:r-bytes r bsize))) (out-append out blk 0 bsize)))   ; Raw
      (1 (out-fill out (u:r-u8 r) bsize))                                  ; RLE
      (2 (decode-compressed-block r out bsize ds))                        ; Compressed
      (3 (zerr "reserved block type")))
    last?))
