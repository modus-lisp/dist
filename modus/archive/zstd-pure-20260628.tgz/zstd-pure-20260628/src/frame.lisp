;;;; src/frame.lisp — zstd frame header parsing (RFC 8878 / zstd format spec §3).

(in-package #:zstd-pure)

(define-condition zstd-error (error)
  ((msg :initarg :msg :reader zstd-error-msg))
  (:report (lambda (c s) (format s "zstd: ~a" (zstd-error-msg c)))))

(defun zerr (fmt &rest args) (error 'zstd-error :msg (apply #'format nil fmt args)))

(defconstant +zstd-magic+ #xFD2FB528)
(defconstant +skippable-magic-lo+ #x184D2A50)   ; 0x184D2A50 .. 0x184D2A5F

(defstruct frame-header
  (content-size nil)          ; decompressed size, or NIL if unknown
  (window-size 0 :type integer)
  (dictionary-id 0 :type integer)
  (single-segment nil)
  (has-checksum nil))

(defun parse-frame-header (r)
  "Parse a zstd frame header from reader R (positioned just past the magic).
Returns a FRAME-HEADER."
  (let* ((desc (u:r-u8 r))
         (fcs-flag (ldb (byte 2 6) desc))
         (single-segment (logbitp 5 desc))
         (reserved (logbitp 3 desc))
         (checksum (logbitp 2 desc))
         (did-flag (ldb (byte 2 0) desc)))
    (when reserved (zerr "reserved bit set in frame header descriptor"))
    (let ((window-size 0))
      ;; Window_Descriptor (absent iff single-segment)
      (unless single-segment
        (let* ((wd (u:r-u8 r))
               (wlog (+ 10 (ldb (byte 5 3) wd)))
               (base (ash 1 wlog))
               (add (* (ash base -3) (ldb (byte 3 0) wd))))
          (setf window-size (+ base add))))
      ;; Dictionary_ID
      (let* ((did-size (case did-flag (0 0) (1 1) (2 2) (3 4)))
             (dict-id (u:r-uint r did-size))
             ;; Frame_Content_Size
             (fcs-size (case fcs-flag
                         (0 (if single-segment 1 0))
                         (1 2) (2 4) (3 8)))
             (fcs (when (plusp fcs-size)
                    (let ((v (u:r-uint r fcs-size)))
                      (if (= fcs-size 2) (+ v 256) v)))))
        (when single-segment (setf window-size (or fcs 0)))
        (make-frame-header :content-size fcs
                           :window-size window-size
                           :dictionary-id dict-id
                           :single-segment single-segment
                           :has-checksum checksum)))))
