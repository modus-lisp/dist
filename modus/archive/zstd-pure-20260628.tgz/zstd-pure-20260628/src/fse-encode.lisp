;;;; src/fse-encode.lisp — FSE encoding tables + the encode state machine,
;;;; mirroring zstd's FSE_buildCTable / FSE_encodeSymbol / FSE_flushCState.

(in-package #:zstd-pure)

(defstruct ctable (log 0 :type fixnum) state-table dnb dfs)

(defun build-ctable (norm nsym table-log)
  "Build an FSE encoding table from a normalized distribution NORM (with -1 for
'less than 1' symbols), as in FSE_buildCTable."
  (let* ((tsize (ash 1 table-log)) (mask (1- tsize))
         (step (+ (ash tsize -1) (ash tsize -3) 3))
         (cumul (make-array (1+ nsym) :element-type 'fixnum :initial-element 0))
         (tsym (make-array tsize :element-type 'fixnum :initial-element 0))
         (high (1- tsize)))
    (loop for u from 1 to nsym do
      (if (= (aref norm (1- u)) -1)
          (progn (setf (aref cumul u) (1+ (aref cumul (1- u))) (aref tsym high) (1- u)) (decf high))
          (setf (aref cumul u) (+ (aref cumul (1- u)) (aref norm (1- u))))))
    (let ((pos 0))                                   ; spread symbols (same rule as decode)
      (dotimes (s nsym)
        (when (> (aref norm s) 0)
          (dotimes (i (aref norm s))
            (setf (aref tsym pos) s)
            (setf pos (logand (+ pos step) mask))
            (loop while (> pos high) do (setf pos (logand (+ pos step) mask)))))))
    (let ((st (make-array tsize :element-type 'fixnum :initial-element 0))
          (cum (copy-seq cumul)))
      (dotimes (u tsize)                             ; next-state table
        (let ((s (aref tsym u))) (setf (aref st (aref cum s)) (+ tsize u)) (incf (aref cum s))))
      (let ((dnb (make-array nsym :element-type '(unsigned-byte 32) :initial-element 0))
            (dfs (make-array nsym :element-type 'fixnum :initial-element 0))
            (total 0))
        (dotimes (s nsym)
          (let ((f (aref norm s)))
            (cond
              ((= f 0) (setf (aref dnb s) (logand (- (ash (1+ table-log) 16) tsize) #xFFFFFFFF)))
              ((or (= f -1) (= f 1))
               (setf (aref dnb s) (logand (- (ash table-log 16) tsize) #xFFFFFFFF)
                     (aref dfs s) (1- total)) (incf total))
              (t (let* ((mbo (- table-log (1- (integer-length (1- f)))))
                        (msp (ash f mbo)))
                   (setf (aref dnb s) (logand (- (ash mbo 16) msp) #xFFFFFFFF)
                         (aref dfs s) (- total f)) (incf total f))))))
        (make-ctable :log table-log :state-table st :dnb dnb :dfs dfs)))))

(defstruct cstate (value 0 :type fixnum) ctable)

(defun init-cstate2 (ct sym)
  "FSE_initCState2: set the initial state for the first-encoded symbol."
  (let* ((dnb (aref (ctable-dnb ct) sym))
         (nbo (ash (logand (+ dnb (ash 1 15)) #xFFFFFFFF) -16))
         (v (logand (- (ash nbo 16) dnb) #xFFFFFFFF)))
    (make-cstate :ctable ct
                 :value (aref (ctable-state-table ct) (+ (ash v (- nbo)) (aref (ctable-dfs ct) sym))))))

(defun encode-symbol (bw cs sym)
  "FSE_encodeSymbol: emit the current state's low bits, then transition."
  (let* ((ct (cstate-ctable cs)) (v (cstate-value cs))
         (nbo (ash (logand (+ v (aref (ctable-dnb ct) sym)) #xFFFFFFFF) -16)))
    (bw-add bw v nbo)
    (setf (cstate-value cs)
          (aref (ctable-state-table ct) (+ (ash v (- nbo)) (aref (ctable-dfs ct) sym))))))

(defun flush-cstate (bw cs)
  (bw-add bw (cstate-value cs) (ctable-log (cstate-ctable cs))))

;;; predefined encoding tables (lazy)
(defvar *ll-ctable* nil) (defvar *of-ctable* nil) (defvar *ml-ctable* nil)
(defun ll-ctable () (or *ll-ctable* (setf *ll-ctable* (build-ctable +ll-default+ (length +ll-default+) 6))))
(defun of-ctable () (or *of-ctable* (setf *of-ctable* (build-ctable +of-default+ (length +of-default+) 5))))
(defun ml-ctable () (or *ml-ctable* (setf *ml-ctable* (build-ctable +ml-default+ (length +ml-default+) 6))))
