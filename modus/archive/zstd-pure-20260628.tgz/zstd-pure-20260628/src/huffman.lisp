;;;; src/huffman.lisp — Huffman tree description + coded-stream decode.
;;;;
;;;; The tree is described by per-symbol weights (the last is implied, completing
;;;; to a power of two).  Weights are either direct 4-bit fields or FSE-compressed
;;;; (2 interleaved states).  Number_of_Bits = Max_Bits + 1 - Weight; symbols are
;;;; sorted by (weight, symbol) and assigned ascending canonical codes, which we
;;;; expand into a 2^Max_Bits lookup table for O(1) decode.

(in-package #:zstd-pure)

(defstruct huff-table (max-bits 0 :type fixnum) sym nb)

(defun %weights->table (weights nweights)
  "Given the decoded WEIGHTS[0:nweights-1] of present-or-absent symbols (the final
implied weight already appended), build a HUFF-TABLE."
  (let ((sum 0))
    (dotimes (i nweights)
      (when (> (aref weights i) 0) (incf sum (ash 1 (1- (aref weights i))))))
    (when (zerop sum) (zerr "huffman: all-zero weights"))
    ;; the complete weight set sums to exactly 2^max-bits, so max-bits = log2(sum)
    (let* ((max-bits (1- (integer-length sum)))
           (tsize (ash 1 max-bits))
           (sym (make-array tsize :element-type 'fixnum :initial-element 0))
           (nb  (make-array tsize :element-type 'fixnum :initial-element 0))
           (order (sort (loop for s below nweights when (> (aref weights s) 0) collect s)
                        (lambda (a b) (or (< (aref weights a) (aref weights b))
                                          (and (= (aref weights a) (aref weights b)) (< a b))))))
           (pos 0))
      (dolist (s order)
        (let* ((w (aref weights s)) (bits (- (1+ max-bits) w)) (cnt (ash 1 (- max-bits bits))))
          (dotimes (k cnt) (setf (aref sym pos) s (aref nb pos) bits) (incf pos))))
      (unless (= pos tsize) (zerr "huffman: weights don't fill the table"))
      (make-huff-table :max-bits max-bits :sym sym :nb nb))))

(defun read-huffman-tree (r)
  "Parse a Huffman_Tree_Description from byte reader R (advancing it).
Returns a HUFF-TABLE."
  (let ((header (u:r-u8 r))
        (weights (make-array 256 :element-type 'fixnum :initial-element 0))
        (nweights 0))
    (if (>= header 128)
        ;; direct representation: (header-127) weights, 4 bits each, 2 per byte
        (let* ((n (- header 127)) (data (u:r-bytes r (ceiling n 2))))
          (dotimes (i n)
            (setf (aref weights i)
                  (if (evenp i) (ash (aref data (ash i -1)) -4) (logand (aref data (ash i -1)) #xf))))
          (setf nweights n))
        ;; FSE-compressed weights: HEADER = byte size of the FSE stream
        (let ((data (u:r-bytes r header)))
          (multiple-value-bind (table consumed) (read-fse-distribution (u:make-fbitr data 0 header) 6)
            ;; Two interleaved states share one table.  Mirror zstd: decode a
            ;; symbol AND update its state (which reads bits, possibly into the
            ;; zero padding past the stream); once that read overflows the real
            ;; bits, decode the other state's final symbol and stop.
            (let* ((br (u:make-rbitr data consumed header))
                   (s1 (fse-init table br)) (s2 (fse-init table br)))
              (loop
                (setf (aref weights nweights) (fse-symbol table s1)) (incf nweights)
                (setf s1 (fse-update table s1 br))
                (when (< (u:r-total-left br) 0)
                  (setf (aref weights nweights) (fse-symbol table s2)) (incf nweights) (return))
                (setf (aref weights nweights) (fse-symbol table s2)) (incf nweights)
                (setf s2 (fse-update table s2 br))
                (when (< (u:r-total-left br) 0)
                  (setf (aref weights nweights) (fse-symbol table s1)) (incf nweights) (return)))))))
    ;; complete the final implied weight to the nearest power of two
    (let ((sum 0))
      (dotimes (i nweights) (when (> (aref weights i) 0) (incf sum (ash 1 (1- (aref weights i))))))
      (let* ((max-bits (integer-length sum))
             (left (- (ash 1 max-bits) sum)))
        (setf (aref weights nweights) (integer-length left))  ; log2(left)+1
        (incf nweights)))
    (%weights->table weights nweights)))

(defun huff-decode-into (table br dst start count)
  "Decode COUNT Huffman symbols from reverse reader BR into DST starting at START."
  (let ((mb (huff-table-max-bits table)) (sym (huff-table-sym table)) (nb (huff-table-nb table)))
    (dotimes (i count)
      (let ((code (u:r-peek br mb)))
        (setf (aref dst (+ start i)) (aref sym code))
        (u:r-consume br (aref nb code))))))
