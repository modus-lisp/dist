;;;; src/util.lisp — byte vectors and a little-endian byte reader.

(in-package #:zstd-pure.util)

(deftype octets () '(simple-array (unsigned-byte 8) (*)))

(declaim (inline make-octets))
(defun make-octets (n &key (initial-element 0))
  (make-array n :element-type '(unsigned-byte 8) :initial-element initial-element))

(defun to-octets (seq)
  "Coerce SEQ to a fresh OCTETS vector."
  (if (typep seq 'octets) seq (coerce seq '(simple-array (unsigned-byte 8) (*)))))

;;; A cursor over a byte vector.  All multi-byte integers in zstd are little-endian.
(defstruct (reader (:constructor make-reader (bytes &optional (pos 0) (end (length bytes)))))
  (bytes nil :type octets)
  (pos 0 :type fixnum)
  (end 0 :type fixnum))

(define-condition zstd-read-error (error)
  ((msg :initarg :msg :reader zstd-read-error-msg))
  (:report (lambda (c s) (format s "zstd read error: ~a" (zstd-read-error-msg c)))))

(declaim (inline r-remaining r-eof-p))
(defun r-remaining (r) (- (reader-end r) (reader-pos r)))
(defun r-eof-p (r) (>= (reader-pos r) (reader-end r)))

(defun r-u8 (r)
  (when (r-eof-p r) (error 'zstd-read-error :msg "unexpected end of input"))
  (prog1 (aref (reader-bytes r) (reader-pos r))
    (incf (reader-pos r))))

(defun r-bytes (r n)
  "Read N raw bytes as a fresh OCTETS vector."
  (when (> n (r-remaining r)) (error 'zstd-read-error :msg "short read"))
  (let ((out (make-octets n)) (b (reader-bytes r)) (p (reader-pos r)))
    (dotimes (i n) (setf (aref out i) (aref b (+ p i))))
    (incf (reader-pos r) n)
    out))

(defun r-uint (r n)
  "Read an N-byte little-endian unsigned integer (N in 0..8)."
  (let ((v 0))
    (dotimes (i n v)
      (setf v (logior v (ash (r-u8 r) (* 8 i)))))))

(declaim (inline r-u16 r-u24 r-u32))
(defun r-u16 (r) (r-uint r 2))
(defun r-u24 (r) (r-uint r 3))
(defun r-u32 (r) (r-uint r 4))
