;;;; src/compress.lisp — a pure-CL zstd compressor.
;;;;
;;;; Produces valid zstd frames: a greedy LZ77 match finder yields sequences with
;;;; raw literals, and the sequences are FSE-coded with the predefined tables.
;;;; Incompressible blocks fall back to raw.  Not a ratio champion (raw literals,
;;;; greedy, predefined tables), but correct: output decodes under both this
;;;; library and libzstd.

(in-package #:zstd-pure)

(defconstant +block-max+ 131072)          ; 1<<17, max regenerated block size
(defconstant +min-match+ 4)               ; 4-byte hashing

(defun %push-uint (out v n)
  (dotimes (i n) (vector-push-extend (logand (ash v (* -8 i)) #xff) out)))

;;; ---- sequence code lookups (value -> code) -----------------------------

(defun %code-for (base value)
  (loop for c from (1- (length base)) downto 0 when (<= (aref base c) value) return c))
(defun ll-code (litlen)  (%code-for +ll-base+ litlen))
(defun ml-code (matchlen) (%code-for +ml-base+ matchlen))
(defun of-code (offset)  (1- (integer-length (+ offset 3))))   ; offBase = offset+3

;;; ---- greedy match finder ----------------------------------------------

(declaim (inline %rd32 %hash4))
(defun %rd32 (b i) (logior (aref b i) (ash (aref b (+ i 1)) 8) (ash (aref b (+ i 2)) 16) (ash (aref b (+ i 3)) 24)))
(defun %hash4 (x) (logand (ash (logand (* x 2654435761) #xFFFFFFFF) -17) #x7FFF))  ; 15-bit hash

(defun match-block (b bs be)
  "Greedy LZ77 over B[bs:be].  Returns (values literals seqs), seqs a list of
(litlen offset matchlen) and LITERALS the concatenated literal bytes."
  (let ((htab (make-array #x8000 :element-type 'fixnum :initial-element -1))
        (lits (make-array 256 :element-type '(unsigned-byte 8) :adjustable t :fill-pointer 0))
        (seqs '()) (i bs) (litstart bs))
    (flet ((emit-lits (from to) (loop for k from from below to do (vector-push-extend (aref b k) lits))))
      (loop while (<= (+ i +min-match+) be) do
        (let* ((h (%hash4 (%rd32 b i))) (cand (aref htab h)))
          (setf (aref htab h) i)
          (if (and (>= cand bs) (= (%rd32 b cand) (%rd32 b i)))
              (let ((ml +min-match+))
                (loop while (and (< (+ i ml) be) (= (aref b (+ cand ml)) (aref b (+ i ml)))) do (incf ml))
                (emit-lits litstart i)
                (push (list (- i litstart) (- i cand) ml) seqs)
                (loop for k from (1+ i) below (min be (+ i ml)) do  ; index the matched region
                  (when (<= (+ k +min-match+) be) (setf (aref htab (%hash4 (%rd32 b k))) k)))
                (incf i ml) (setf litstart i))
              (incf i))))
      (emit-lits litstart be))
    (values (u:to-octets lits) (nreverse seqs))))

;;; ---- block assembly ----------------------------------------------------

(defun %write-literals-header (out regen)
  (cond ((< regen 32) (vector-push-extend (ash regen 3) out))                        ; Raw, 1-byte
        ((< regen 4096)
         (vector-push-extend (logior #x04 (ash (logand regen #xf) 4)) out)           ; lbt0 sf01
         (vector-push-extend (ash regen -4) out))
        (t (vector-push-extend (logior #x0c (ash (logand regen #xf) 4)) out)         ; lbt0 sf11
           (vector-push-extend (logand (ash regen -4) #xff) out)
           (vector-push-extend (ash regen -12) out))))

(defun %encode-sequences (seqs)
  "FSE-code SEQS (predefined tables) into the sequences bitstream bytes."
  (let ((bw (make-bw)) (sv (coerce seqs 'vector)) (n (length seqs))
        (llc (ll-ctable)) (ofc (of-ctable)) (mlc (ml-ctable)))
    (flet ((ll (s) (first s)) (off (s) (second s)) (mln (s) (third s)))
      (let* ((last (aref sv (1- n)))
             (lc (ll-code (ll last))) (mc (ml-code (mln last))) (oc (of-code (off last)))
             (sll (init-cstate2 llc lc)) (sof (init-cstate2 ofc oc)) (sml (init-cstate2 mlc mc)))
        (bw-add bw (ll last) (aref +ll-bits+ lc))
        (bw-add bw (- (mln last) 3) (aref +ml-bits+ mc))
        (bw-add bw (+ (off last) 3) oc)
        (loop for k from (- n 2) downto 0 do
          (let* ((s (aref sv k)) (lc (ll-code (ll s))) (mc (ml-code (mln s))) (oc (of-code (off s))))
            (encode-symbol bw sof oc) (encode-symbol bw sml mc) (encode-symbol bw sll lc)
            (bw-add bw (ll s) (aref +ll-bits+ lc))
            (bw-add bw (- (mln s) 3) (aref +ml-bits+ mc))
            (bw-add bw (+ (off s) 3) oc)))
        (flush-cstate bw sml) (flush-cstate bw sof) (flush-cstate bw sll)
        (bw-finish bw)))))

(defun %num-seq-bytes (out nseq)
  (cond ((< nseq 128) (vector-push-extend nseq out))
        ((< nseq #x7f00) (vector-push-extend (+ (ash nseq -8) 128) out) (vector-push-extend (logand nseq #xff) out))
        (t (vector-push-extend 255 out) (let ((v (- nseq #x7f00)))
             (vector-push-extend (logand v #xff) out) (vector-push-extend (ash v -8) out)))))

(defun compress-block (b bs be out last?)
  "Compress B[bs:be]; append a block (compressed or raw) to OUT."
  (let ((blen (- be bs)))
    (multiple-value-bind (lits seqs) (match-block b bs be)
      ;; assemble a candidate compressed block in a scratch buffer
      (let ((payload (make-array 64 :element-type '(unsigned-byte 8) :adjustable t :fill-pointer 0)))
        (%write-literals-header payload (length lits))
        (loop for x across lits do (vector-push-extend x payload))
        (if (null seqs)
            (vector-push-extend 0 payload)                      ; 0 sequences
            (progn (%num-seq-bytes payload (length seqs))
                   (vector-push-extend 0 payload)               ; modes: all Predefined
                   (loop for x across (%encode-sequences seqs) do (vector-push-extend x payload))))
        (if (< (fill-pointer payload) blen)
            (let ((bh (logior (if last? 1 0) (ash 2 1) (ash (fill-pointer payload) 3))))  ; Compressed
              (%push-uint out bh 3)
              (loop for x across payload do (vector-push-extend x out)))
            (let ((bh (logior (if last? 1 0) (ash 0 1) (ash blen 3))))                    ; Raw fallback
              (%push-uint out bh 3)
              (loop for k from bs below be do (vector-push-extend (aref b k) out))))))))

(defun compress (input &key checksum)
  "Compress INPUT (octets/sequence) into a zstd frame.  Returns OCTETS."
  (let* ((b (u:to-octets input)) (n (length b))
         (out (make-array 64 :element-type '(unsigned-byte 8) :adjustable t :fill-pointer 0)))
    (%push-uint out +zstd-magic+ 4)
    ;; single-segment frame header with content size + optional checksum
    (let ((fcs-flag (cond ((<= n 255) 0) ((<= n (+ 65535 256)) 1) ((<= n #xffffffff) 2) (t 3))))
      (vector-push-extend (logior (ash fcs-flag 6) (ash 1 5) (if checksum (ash 1 2) 0)) out)
      (ecase fcs-flag
        (0 (vector-push-extend n out))
        (1 (%push-uint out (- n 256) 2))
        (2 (%push-uint out n 4))
        (3 (%push-uint out n 8))))
    (if (zerop n)
        (%push-uint out 1 3)                                    ; empty: last raw block, size 0
        (loop for bs from 0 below n by +block-max+
              for be = (min n (+ bs +block-max+))
              do (compress-block b bs be out (>= be n))))
    (when checksum
      (%push-uint out (logand (xxh:xxh64 b) #xffffffff) 4))
    (u:to-octets out)))
