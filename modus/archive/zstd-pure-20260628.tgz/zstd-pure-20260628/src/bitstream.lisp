;;;; src/bitstream.lisp — the two bit-reading conventions zstd uses.
;;;;
;;;; FORWARD (LSB-first): the FSE distribution header is read forward, low bit of
;;;; each byte first.
;;;;
;;;; REVERSE (zstd backward): FSE and Huffman bitstreams are written forward and
;;;; read backward.  The last byte's highest set bit is a sentinel (padding); the
;;;; useful bits are everything below it, then all bits of each earlier byte,
;;;; consumed most-significant-first.  Past the start, missing bits read as 0.

(in-package #:zstd-pure.util)

;;; ---- forward, LSB-first ------------------------------------------------

(defstruct (fbitr (:constructor %make-fbitr))
  (bytes nil :type octets) (pos 0 :type fixnum) (start 0 :type fixnum)
  (end 0 :type fixnum) (acc 0 :type integer) (nbits 0 :type fixnum))

(defun make-fbitr (bytes start end)
  (%make-fbitr :bytes bytes :pos start :start start :end end))

(defun f-read (br n)
  "Read N bits, LSB-first."
  (loop while (< (fbitr-nbits br) n) do
    (let ((b (if (< (fbitr-pos br) (fbitr-end br)) (aref (fbitr-bytes br) (fbitr-pos br)) 0)))
      (incf (fbitr-pos br))
      (setf (fbitr-acc br) (logior (fbitr-acc br) (ash b (fbitr-nbits br))))
      (incf (fbitr-nbits br) 8)))
  (prog1 (logand (fbitr-acc br) (1- (ash 1 n)))
    (setf (fbitr-acc br) (ash (fbitr-acc br) (- n)))
    (decf (fbitr-nbits br) n)))

(defun f-consumed-bytes (br)
  "Whole bytes consumed so far (the distribution ends on a byte boundary)."
  (- (fbitr-pos br) (floor (fbitr-nbits br) 8) (fbitr-start br)))

;;; ---- reverse (zstd backward), MSB-first --------------------------------

(defstruct (rbitr (:constructor %make-rbitr))
  (bytes nil :type octets) (pos 0 :type fixnum) (start 0 :type fixnum)
  (acc 0 :type integer) (nbits 0 :type fixnum)
  (real 0 :type fixnum) (consumed 0 :type fixnum))

(defun make-rbitr (bytes start end)
  "A reverse bit reader over BYTES[start:end].  Strips the sentinel/padding."
  (let ((last (aref bytes (1- end))))
    (when (zerop last) (error "zstd: reverse bitstream last byte is zero"))
    (let* ((hb (1- (integer-length last)))            ; sentinel position 0..7
           (real (+ hb (* 8 (- (1- end) start))))     ; total useful bits in the stream
           (br (%make-rbitr :bytes bytes :pos (- end 2) :start start :real real)))
      (setf (rbitr-acc br) (logand last (1- (ash 1 hb)))
            (rbitr-nbits br) hb)
      br)))

(defun %r-ensure (br n)
  (loop while (< (rbitr-nbits br) n) do
    (let ((b (if (>= (rbitr-pos br) (rbitr-start br)) (aref (rbitr-bytes br) (rbitr-pos br)) 0)))
      (decf (rbitr-pos br))
      (setf (rbitr-acc br) (logior (ash (rbitr-acc br) 8) b))
      (incf (rbitr-nbits br) 8))))

(defun r-peek (br n)
  "The next N bits (MSB-first) without consuming them."
  (if (zerop n) 0 (progn (%r-ensure br n) (ash (rbitr-acc br) (- (- (rbitr-nbits br) n))))))

(defun r-consume (br n)
  (let ((rem (- (rbitr-nbits br) n)))
    (setf (rbitr-acc br) (logand (rbitr-acc br) (1- (ash 1 rem)))
          (rbitr-nbits br) rem))
  (incf (rbitr-consumed br) n))

(defun r-read (br n)
  "Read N bits, most-significant-first (consuming the stream backward)."
  (if (zerop n) 0 (prog1 (r-peek br n) (r-consume br n))))

(defun r-total-left (br)
  "Real bits still available (negative once reading into zero-padding)."
  (- (rbitr-real br) (rbitr-consumed br)))
