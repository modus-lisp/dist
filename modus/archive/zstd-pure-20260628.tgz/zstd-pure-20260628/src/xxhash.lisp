;;;; src/xxhash.lisp — XXH64 (Yann Collet).  zstd's optional content checksum is
;;;; the low 32 bits of XXH64(decompressed-content, seed=0).

(in-package #:zstd-pure.xxhash)

(defconstant +m64+ #xFFFFFFFFFFFFFFFF)
(defconstant +p1+ 11400714785074694791)
(defconstant +p2+ 14029467366897019727)
(defconstant +p3+  1609587929392839161)
(defconstant +p4+  9650029242287828579)
(defconstant +p5+  2870177450012600261)

(declaim (inline m* rotl rd64 rd32))
(defun m* (a b) (logand (* a b) +m64+))
(defun rotl (x r) (logand (logior (ash x r) (ash x (- r 64))) +m64+))

(defun rd64 (b i) (let ((v 0)) (dotimes (k 8 v) (setf v (logior v (ash (aref b (+ i k)) (* 8 k)))))))
(defun rd32 (b i) (let ((v 0)) (dotimes (k 4 v) (setf v (logior v (ash (aref b (+ i k)) (* 8 k)))))))

(declaim (inline xround mergeround))
(defun xround (acc input)
  (m* (rotl (logand (+ acc (m* input +p2+)) +m64+) 31) +p1+))
(defun mergeround (acc val)
  (logand (+ (m* (logxor acc (xround 0 val)) +p1+) +p4+) +m64+))

(defun xxh64 (bytes &key (seed 0) (start 0) (end (length bytes)))
  "XXH64 digest (64-bit) of BYTES[START:END] with SEED."
  (declare (type (simple-array (unsigned-byte 8) (*)) bytes))
  (let* ((len (- end start)) (i start) (acc 0))
    (if (>= len 32)
        (let ((a1 (logand (+ seed +p1+ +p2+) +m64+))
              (a2 (logand (+ seed +p2+) +m64+))
              (a3 (logand seed +m64+))
              (a4 (logand (- seed +p1+) +m64+))
              (limit (- end 32)))
          (loop while (<= i limit) do
            (setf a1 (xround a1 (rd64 bytes i))) (incf i 8)
            (setf a2 (xround a2 (rd64 bytes i))) (incf i 8)
            (setf a3 (xround a3 (rd64 bytes i))) (incf i 8)
            (setf a4 (xround a4 (rd64 bytes i))) (incf i 8))
          (setf acc (logand (+ (rotl a1 1) (rotl a2 7) (rotl a3 12) (rotl a4 18)) +m64+))
          (setf acc (mergeround acc a1) acc (mergeround acc a2)
                acc (mergeround acc a3) acc (mergeround acc a4)))
        (setf acc (logand (+ seed +p5+) +m64+)))
    (setf acc (logand (+ acc len) +m64+))
    ;; remaining bytes
    (loop while (<= (+ i 8) end) do
      (setf acc (logand (+ (m* (rotl (logxor acc (xround 0 (rd64 bytes i))) 27) +p1+) +p4+) +m64+))
      (incf i 8))
    (when (<= (+ i 4) end)
      (setf acc (logand (+ (m* (rotl (logxor acc (m* (rd32 bytes i) +p1+)) 23) +p2+) +p3+) +m64+))
      (incf i 4))
    (loop while (< i end) do
      (setf acc (m* (rotl (logxor acc (m* (aref bytes i) +p5+)) 11) +p1+))
      (incf i))
    ;; final avalanche
    (setf acc (logxor acc (ash acc -33)) acc (m* acc +p2+)
          acc (logxor acc (ash acc -29)) acc (m* acc +p3+)
          acc (logxor acc (ash acc -32)))
    acc))
