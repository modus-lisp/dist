;;;; src/fse.lisp — Finite State Entropy (tANS): distribution decode + table
;;;; build + the decoding state machine (read on the reverse bitstream).

(in-package #:zstd-pure)

(defstruct fse-table
  (accuracy-log 0 :type fixnum)
  (symbol nil)            ; state -> decoded symbol
  (nbits nil)             ; state -> bits to read for next state
  (baseline nil))         ; state -> baseline added to those bits

;;; ---- read a normalized distribution (forward, LSB-first) ---------------

(defun read-fse-distribution (br max-accuracy-log)
  "Read an FSE table description from forward bit reader BR.
Returns (values fse-table consumed-bytes)."
  (let* ((al (+ 5 (u:f-read br 4)))
         (size (ash 1 al)))
    (when (> al max-accuracy-log) (zerr "FSE accuracy log ~d exceeds max ~d" al max-accuracy-log))
    (let ((freqs (make-array 256 :element-type 'fixnum :initial-element 0))
          (nsym 0)
          (remaining size))
      (loop while (> remaining 0) do
        (let* ((bits (integer-length (1+ remaining)))           ; log2sup(remaining+1)
               (threshold (- (1- (ash 1 bits)) (1+ remaining)))
               (low (u:f-read br (1- bits)))
               (value (if (< low threshold)
                          low
                          (let ((high (u:f-read br 1)))
                            (if (= high 1) (- (+ low (ash 1 (1- bits))) threshold) low))))
               (proba (1- value)))
          (setf (aref freqs nsym) proba) (incf nsym)
          (decf remaining (abs proba))
          (when (zerop proba)                                    ; runs of zero-probability symbols
            (loop for rep = (u:f-read br 2)
                  do (dotimes (k rep) (setf (aref freqs nsym) 0) (incf nsym))
                  while (= rep 3)))))
      (values (build-fse-table freqs nsym al) (u:f-consumed-bytes br)))))

;;; ---- build a decoding table from a normalized distribution -------------

(defun build-fse-table (freqs nsym accuracy-log)
  (let* ((size (ash 1 accuracy-log))
         (symbol (make-array size :element-type 'fixnum :initial-element 0))
         (nbits (make-array size :element-type 'fixnum :initial-element 0))
         (base (make-array size :element-type 'fixnum :initial-element 0))
         (high size)
         (state-desc (make-array nsym :element-type 'fixnum :initial-element 0)))
    ;; "less than 1" symbols take rows from the top, retreating
    (dotimes (s nsym) (when (= (aref freqs s) -1) (decf high) (setf (aref symbol high) s)))
    ;; scatter the rest with the modular stepping rule
    (let ((step (+ (ash size -1) (ash size -3) 3)) (mask (1- size)) (pos 0))
      (dotimes (s nsym)
        (when (> (aref freqs s) 0)
          (dotimes (i (aref freqs s))
            (setf (aref symbol pos) s)
            (loop do (setf pos (logand (+ pos step) mask)) while (>= pos high))))))
    ;; per-state Number_of_Bits + Baseline
    (dotimes (s nsym) (setf (aref state-desc s) (if (= (aref freqs s) -1) 1 (max 0 (aref freqs s)))))
    (dotimes (i size)
      (let* ((s (aref symbol i)) (next (aref state-desc s)))
        (incf (aref state-desc s))
        (let ((nb (- accuracy-log (1- (integer-length next)))))
          (setf (aref nbits i) nb
                (aref base i) (- (ash next nb) size)))))
    (make-fse-table :accuracy-log accuracy-log :symbol symbol :nbits nbits :baseline base)))

(defun fse-rle-table (symbol)
  "A 1-state table that always yields SYMBOL (RLE mode)."
  (make-fse-table :accuracy-log 0
                  :symbol (make-array 1 :element-type 'fixnum :initial-element symbol)
                  :nbits (make-array 1 :element-type 'fixnum :initial-element 0)
                  :baseline (make-array 1 :element-type 'fixnum :initial-element 0)))

;;; ---- decoding state machine (reverse bitstream) -----------------------

(declaim (inline fse-init fse-symbol fse-update))
(defun fse-init (table br) (u:r-read br (fse-table-accuracy-log table)))
(defun fse-symbol (table state) (aref (fse-table-symbol table) state))
(defun fse-update (table state br)
  (+ (aref (fse-table-baseline table) state)
     (u:r-read br (aref (fse-table-nbits table) state))))

;;; ---- predefined distributions (default mode) --------------------------

(defparameter +ll-default+
  #(4 3 2 2 2 2 2 2 2 2 2 2 2 1 1 1 2 2 2 2 2 2 2 2 2 3 2 1 1 1 1 1 -1 -1 -1 -1))
(defparameter +ml-default+
  #(1 4 3 2 2 2 2 2 2 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1
    1 1 1 1 1 1 1 1 1 1 1 1 1 1 -1 -1 -1 -1 -1 -1 -1))
(defparameter +of-default+
  #(1 1 1 1 1 1 2 2 2 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 -1 -1 -1 -1 -1))

(defun predefined-table (dist accuracy-log)
  (let ((freqs (make-array (length dist) :element-type 'fixnum)))
    (dotimes (i (length dist)) (setf (aref freqs i) (aref dist i)))
    (build-fse-table freqs (length dist) accuracy-log)))
