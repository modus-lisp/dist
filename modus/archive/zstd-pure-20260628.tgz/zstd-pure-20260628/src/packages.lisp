;;;; src/packages.lisp — package layout for zstd-pure.

(defpackage #:zstd-pure.util
  (:use #:cl)
  (:export
   #:octets #:make-octets #:to-octets
   ;; byte reader (little-endian)
   #:reader #:make-reader #:reader-bytes #:reader-pos #:reader-end #:r-u8 #:r-bytes
   #:r-u16 #:r-u24 #:r-u32 #:r-uint #:r-remaining #:r-eof-p
   ;; forward (LSB-first) bit reader — FSE distribution headers
   #:fbitr #:make-fbitr #:f-read #:f-consumed-bytes
   ;; reverse (zstd backward) bit reader — FSE/Huffman bitstreams
   #:rbitr #:make-rbitr #:r-read #:r-peek #:r-consume #:r-total-left))

(defpackage #:zstd-pure.xxhash
  (:use #:cl)
  (:local-nicknames (#:u #:zstd-pure.util))
  (:export #:xxh64))

(defpackage #:zstd-pure
  (:use #:cl)
  (:local-nicknames (#:u #:zstd-pure.util)
                    (#:xxh #:zstd-pure.xxhash))
  (:export
   #:decompress #:decompress-frame
   #:compress
   #:zstd-error
   ;; introspection
   #:frame-header #:parse-frame-header
   #:frame-content-size #:frame-window-size #:frame-has-checksum))
