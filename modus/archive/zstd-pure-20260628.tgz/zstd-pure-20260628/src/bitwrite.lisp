;;;; src/bitwrite.lisp — the encoder-side bit writer (BIT_CStream).
;;;;
;;;; Bits are packed LSB-first into a forward byte stream; on close a 1-bit
;;;; sentinel is written and the final byte padded.  This is the exact inverse of
;;;; the reverse reader in bitstream.lisp: what the encoder writes first ends up
;;;; lowest in the stream and is read last by the backward decoder.

(in-package #:zstd-pure)

(defstruct (bw (:constructor make-bw))
  (bytes (make-array 64 :element-type '(unsigned-byte 8) :adjustable t :fill-pointer 0))
  (acc 0 :type integer) (nbits 0 :type fixnum))

(defun bw-add (bw value n)
  "Append the low N bits of VALUE (LSB-first)."
  (when (plusp n)
    (setf (bw-acc bw) (logior (bw-acc bw) (ash (logand value (1- (ash 1 n))) (bw-nbits bw))))
    (incf (bw-nbits bw) n)
    (loop while (>= (bw-nbits bw) 8) do
      (vector-push-extend (logand (bw-acc bw) #xff) (bw-bytes bw))
      (setf (bw-acc bw) (ash (bw-acc bw) -8))
      (decf (bw-nbits bw) 8))))

(defun bw-finish (bw)
  "Write the 1-bit sentinel and flush the final (partial) byte.  Returns OCTETS."
  (bw-add bw 1 1)
  (when (plusp (bw-nbits bw))
    (vector-push-extend (logand (bw-acc bw) #xff) (bw-bytes bw))
    (setf (bw-acc bw) 0 (bw-nbits bw) 0))
  (u:to-octets (bw-bytes bw)))
