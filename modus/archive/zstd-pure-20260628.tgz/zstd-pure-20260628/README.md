# zstd-pure

A from-scratch **Zstandard codec in pure Common Lisp** — no FFI, no
libzstd. It reads `.zst` frames and the streams every modern system sends:
HTTP `Content-Encoding: zstd`, `.tar.zst` archives, package managers, databases.

The Common Lisp ecosystem has DEFLATE/zlib/gzip (chipz, salza2, 3bz) but the
only zstd option is [`cl-zstd`](https://github.com/glv2/cl-zstd) — **C bindings
to libzstd**. This is the pure-Lisp one: clean-room, dependency-free, and
**differential-tested byte-for-byte against libzstd** (via `python zstandard`).

## Status — complete decompressor ✅

Decodes the full Zstandard format: frame header (window / content size /
dictionary id / checksum), skippable + multi-frame streams; **raw, RLE, and
compressed blocks**; **Huffman** literals (direct & FSE-compressed weights,
1- and 4-stream); **FSE/tANS** sequences (predefined / RLE / FSE / repeat tables);
**LZ77** execution with repeat offsets; and **XXH64** content-checksum verification.

**Differential-tested byte-for-byte against libzstd** (`python zstandard`):
110 cases from empty to ~6 MB, levels 1–22, with/without checksum, exercising
4-stream Huffman, multi-block streams, and RLE/structured/random/text — all decode
identically. The FSE table build also matches the format spec's Appendix A
reference tables exactly.

**Compressor** ✅ — `zstd-pure:compress` produces valid zstd frames: a greedy
LZ77 match finder yields sequences with raw literals, FSE-coded with the
predefined tables (plus an FSE *encoder*, the reverse bit writer, and raw/RLE
fallback for incompressible blocks); optional XXH64 checksum. It's correctness-
and interop-first, not a ratio champion. Verified: **150 fuzz cases** (random
sizes incl. block boundaries, checksums) all round-trip through *both* this
library and libzstd.

Not yet: dictionaries, and entropy-coded literals / repeat-offset matching in the
compressor (would improve ratio).

## Layout

```
src/
  util       byte reader (little-endian)
  bitstream  forward (LSB) + reverse (zstd backward) bit readers
  xxhash     XXH64 content checksum
  frame      frame header parsing
  fse        Finite State Entropy (tANS): distribution decode, table build, states
  huffman    Huffman tree description + 1-/4-stream coded decode
  block      raw/RLE + compressed block (literals + sequences + LZ77 execution)
  decode     top-level frame loop + checksum/size verification
inspect/
  vectors/           libzstd-produced .zst + original .raw test vectors
  offline-test.lisp  the gate (auto-discovers vectors)
  run-all.sh
```

## Use

```lisp
(asdf:load-system "zstd-pure")
(zstd-pure:decompress  <octets of a .zst stream>)   ; => octets
```

## License

MIT.
