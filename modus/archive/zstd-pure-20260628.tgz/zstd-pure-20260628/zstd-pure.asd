;;;; zstd-pure.asd

(defsystem "zstd-pure"
  :description "A from-scratch, pure Common Lisp Zstandard decompressor — no FFI,
                no libzstd.  Reads .zst frames (raw/RLE/compressed blocks, Huffman
                + FSE entropy coding, LZ77 sequences, xxhash64), differential-
                tested byte-for-byte against libzstd."
  :version "0.0.1"
  :author "ynniv"
  :license "MIT"
  :depends-on ()                        ; pure CL, no dependencies
  :serial t
  :components
  ((:module "src"
    :serial t
    :components
    ((:file "packages")
     (:file "util")          ; byte reader, little-endian ints
     (:file "bitstream")     ; forward (LSB) + reverse (zstd backward) bit readers
     (:file "xxhash")        ; xxhash64 (content checksum)
     (:file "frame")         ; frame header parsing
     (:file "fse")           ; Finite State Entropy (tANS) tables + decode
     (:file "huffman")       ; Huffman tree description + coded-stream decode
     (:file "block")         ; blocks: raw/RLE + compressed (literals + sequences + execution)
     (:file "bitwrite")      ; encoder bit writer (BIT_CStream)
     (:file "fse-encode")    ; FSE encoding tables + encode state machine
     (:file "compress")      ; the compressor (LZ77 + FSE-coded sequences)
     (:file "decode"))))     ; top-level decompress entry
  :in-order-to ((test-op (test-op "zstd-pure/test"))))

(defsystem "zstd-pure/test"
  :depends-on ("zstd-pure")
  :components ((:module "inspect"
               :components ((:file "offline-test"))))
  :perform (test-op (o c) (uiop:symbol-call :zstd-pure.test :run)))
