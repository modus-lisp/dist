# SVG on stencil — design

How SVG is parsed, modeled, rendered, and bound into a host page.

## SVG DOM

stencil's `svg-node` is a neutral element tree (name, attribute alist, ordered
children, text). A host (weft) exposes it to JavaScript by wrapping each node in
the matching SVG interface. The interfaces the web platform (and Acid3) expects:

| Interface | Nodes | Key members |
|---|---|---|
| `SVGElement` | every SVG element | `ownerSVGElement`, `viewportElement`, presentation attrs |
| `SVGSVGElement` | `<svg>` | `width`/`height`, `viewBox`, `createSVGPoint`, `getElementById` |
| `SVGGElement` | `<g>` | container |
| `SVGRectElement` | `<rect>` | `x` `y` `width` `height` `rx` `ry` (as `SVGAnimatedLength`) |
| `SVGCircleElement` / `SVGEllipseElement` | `<circle>`/`<ellipse>` | `cx` `cy` `r` / `rx` `ry` |
| `SVGLineElement` / `SVGPolylineElement` / `SVGPolygonElement` | lines | `x1..`, `points` |
| `SVGPathElement` | `<path>` | `getTotalLength`, `getPointAtLength`, `pathSegList` |
| `SVGTextContentElement` | `<text>`/`<tspan>` | `getNumberOfChars`, `getComputedTextLength` |
| `SVGGraphicsElement` | rendered elements | `getBBox`, `getCTM`, `transform` |

`SVGAnimatedLength` and friends wrap stencil's parsed attribute values; the
`baseVal`/`animVal` split is trivial without SMIL (both read the base value).

### Acid3 74 / 75 / 77

These three subtests are pure SVG DOM surface — no rendering:

- **74** — `iframe.getSVGDocument()`. The host loads an `.svg` (or XHTML with
  inline SVG) into a frame, parses it with `parse-svg`, and returns that document
  from `getSVGDocument()` (and `contentDocument`).
- **75** — the `SVGRectElement` interface must exist and a `<rect>` must be an
  instance of it, with `x/y/width/height` animated-length properties. Binding the
  interface object + prototype onto `<rect>` nodes clears it.
- **77** — `SVGTextContentElement.getNumberOfChars()` returns the character count
  of a `<text>` element. stencil already accumulates element text, so the binding
  is `length` of that string.

None of these require the renderer; they are host bindings over the stencil DOM,
so they can land independently of pixel output.

## Rendering

1. **Coordinate system.** The outermost `<svg>` establishes a viewport (its
   `width`/`height`, or the host layout box). A `viewBox` maps user space into
   that viewport; stencil fits it with a scale + translate (uniform
   `preserveAspectRatio` is a later refinement). Nested transforms compose via
   gesso's matrix stack.
2. **Shapes → paths.** Each basic shape emits gesso path ops; `path` runs the
   `d` grammar. gesso flattens curves/arcs and fills with non-zero winding.
3. **Presentation attributes + CSS.** `fill`, `stroke`, `stroke-width`,
   `opacity`, `font-size` resolve from the inline `style` then the presentation
   attribute, inheriting down the tree. A host may additionally feed values from
   its CSS cascade (presentation attributes are the lowest-priority author
   source); stencil's resolver is the fallback when no cascade is supplied.
4. **fill/stroke.** `fill` fills the path; `stroke` strokes it at `stroke-width`.
   Paints are solid colors today; gradients/patterns become gesso paint sources.
5. **Text.** `<text>`/`<tspan>` are shaped by scribe through `gesso:fill-text` at
   the element's `x`/`y` and `font-size`.

## Layout integration (host = weft)

- **Inline `<svg>`** participates in flow as a replaced element: weft sizes the
  box (intrinsic size from `width`/`height` or `viewBox`, else 300×150), then
  calls `render-svg-to-canvas` onto the page canvas at the box origin.
- **`<img src=*.svg>`** fetches the source and renders at the image box size.
- **`iframe`/`object`** holding an SVG document exposes it via
  `getSVGDocument()`.

## Roadmap

| Area | First slice | Next |
|---|---|---|
| Shapes | rect/circle/ellipse/line/polyline/polygon/path | rounded rect `rx`/`ry` |
| Paths | full `d` incl. arcs | `getTotalLength`/`getPointAtLength` |
| Paint | solid fill/stroke | gradients, patterns |
| Text | single positioned run | `textAnchor`, `dx`/`dy`, `textPath` |
| Structure | g/defs/use(skip) | `use`/`symbol`, nested svg, `preserveAspectRatio` |
| Effects | — | clipping, masking, filters |
| DOM | tree + queries | full SVG* interfaces (Acid3 74/75/77), `getBBox`/`getCTM` |

Every step stays additive on gesso; none needs FFI.
