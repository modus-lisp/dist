;;;; stencil.asd — SVG in pure Common Lisp.
(asdf:defsystem :stencil
  :description "SVG in pure Common Lisp: an XML/SVG parser, an SVG DOM, and a
renderer that paints shapes, paths and text through gesso (2D vector graphics)
onto scribe's rasterizer.  No FFI, no librsvg, no Cairo."
  :version "0.0.1"
  :author "ynniv"
  :license "MIT"
  :depends-on ("gesso" "cram")   ; cram: gzip, for .svgz (SVG 1.1 appendix on
                                ; compressed documents) — pure CL and dependency-free
  :serial t
  :components
  ((:module "src"
    :serial t
    :components
    ((:file "packages")
     (:file "dom")        ; SVG DOM node kernel + queries
     (:file "xml")        ; minimal XML parser -> SVG DOM
     (:file "units")      ; length/number/color/transform attribute parsing
     (:file "pathdata")   ; the `d` attribute -> gesso path ops
     (:file "render")))))  ; shapes/paths/text -> gesso; viewBox + presentation
