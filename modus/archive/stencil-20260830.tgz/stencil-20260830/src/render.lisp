;;;; render.lisp — walk the SVG DOM and paint it through gesso.
;;;;
;;;; Shapes become gesso paths, presentation attributes (fill/stroke/width/
;;;; opacity, inherited) become gesso paint state, and `transform` / `viewBox`
;;;; become gesso transforms.  Filling and stroking run on gesso's analytic
;;;; rasterizer; <text> is shaped by scribe via gesso:fill-text.
(in-package #:stencil)

(defun %style-prop (style name)
  "Value of CSS property NAME in an inline STYLE string, or NIL."
  (when style
    (dolist (decl (uiop:split-string style :separator ";"))
      (let ((c (position #\: decl)))
        (when c
          (let ((k (string-trim " " (subseq decl 0 c))))
            (when (string-equal k name)
              (return (string-trim " " (subseq decl (1+ c)))))))))))

(defun %prop (node name)
  "A presentation property: the inline style wins over the attribute of the same
   name, matching CSS specificity for presentation attributes."
  (or (%style-prop (attr node "style") name) (attr node name)))

(defstruct pstate (fill '(0 0 0)) (stroke :none) (stroke-width 1d0) (opacity 1d0)
                  (fill-opacity 1d0) (stroke-opacity 1d0) (color '(0 0 0)) (font-size 16d0)
                  (fill-rule :nonzero) (dash-array nil) (dash-offset 0d0))

;;; ---- paint servers (gradients) --------------------------------------------
(defvar *gradients* nil
  "During a render, a hash of id -> gradient svg-node for url(#id) paints.")

(defvar *defs* nil
  "During a render, a hash of id -> svg-node for every element, for <use href=#id>.")

(defvar *use-stack* nil
  "The <use> targets currently being expanded, innermost first.  A reference that is
   already on it is a cycle: see the guard in RENDER-NODE.")

(defun collect-ids (root)
  "A hash of id -> node for every id'd element under ROOT (for <use>)."
  (let ((tbl (make-hash-table :test 'equal)))
    (map-tree (lambda (n) (let ((id (attr n "id"))) (when id (setf (gethash id tbl) n)))) root)
    tbl))

(defun collect-gradients (root)
  "A hash of id -> node for every gradient element under ROOT."
  (let ((tbl (make-hash-table :test 'equal)))
    (map-tree (lambda (n)
                (when (member (svg-node-name n)
                              '("lineargradient" "radialgradient") :test #'string=)
                  (let ((id (attr n "id"))) (when id (setf (gethash id tbl) n)))))
              root)
    tbl))

(defun %url-id (val)
  "The id in a url(#id) reference (or url('#id')), else NIL."
  (when val
    (let ((p (search "url(" val :test #'char-equal)))
      (when p
        (let* ((open (+ p 4)) (close (position #\) val :start open)))
          (when close (string-trim " '\"#" (subseq val open close))))))))

(defun %resolve-paint (val parent &optional current-color)
  "Resolve a fill/stroke value to a colour list, :none, a (:url . id) reference, or
   the inherited PARENT value when VAL is absent.  `currentColor` resolves to the
   element's computed CSS color (SVG §12.2)."
  (cond ((null val) parent)
        ((and (stringp val) (string-equal (string-trim " " val) "currentcolor"))
         (or current-color '(0 0 0)))
        ((%url-id val) (cons :url (%url-id val)))
        (t (let ((c (parse-color val))) (or c :none)))))

(defun %frac (raw)
  "A gradient coordinate as a fraction: \"50%\" and \"0.5\" both -> 0.5."
  (if (and raw (find #\% raw)) (/ (parse-number raw) 100d0) (parse-number raw)))

(defun %grad-coord (raw obb base size)
  "Resolve a gradient coordinate RAW to user space.  OBB (objectBoundingBox) maps a
   fraction into [BASE, BASE+SIZE]; userSpaceOnUse uses the absolute value."
  (if obb (+ base (* (%frac raw) size))
      (if (and raw (find #\% raw)) (+ base (* (%frac raw) size)) (parse-number raw))))

(defun %grad-radius (raw obb bw bh)
  (if obb (* (%frac raw) (sqrt (/ (+ (* bw bw) (* bh bh)) 2d0))) (parse-number raw)))

(defun %stop-prop (node name)
  (or (%style-prop (attr node "style") name) (attr node name)))

(defun %gradient-stops (node)
  "The colour stops of gradient NODE as (offset r g b a); follows href when NODE has
   no stops of its own."
  (let ((stops '()))
    (loop for c across (svg-node-children node)
          when (string= (svg-node-name c) "stop") do
            (let* ((off (%frac (or (attr c "offset") "0")))
                   (col (or (parse-color (or (%stop-prop c "stop-color") "black")) '(0 0 0)))
                   (op (%stop-prop c "stop-opacity"))
                   (a (if op (parse-number op 1d0) 1d0)))
              (push (list (max 0d0 (min 1d0 off)) (first col) (second col) (third col) a) stops)))
    (setf stops (nreverse stops))
    (or stops
        (let ((href (or (attr node "href") (attr node "xlink:href"))))
          (when (and href (> (length href) 1) (char= (char href 0) #\#))
            (let ((ref (and *gradients* (gethash (subseq href 1) *gradients*))))
              (when ref (%gradient-stops ref))))))))

(defun build-gradient (ctx node)
  "A gesso gradient for gradient NODE, placed for the current path, or NIL."
  (let ((stops (%gradient-stops node)) (kind (svg-node-name node)))
    (when stops
      (let ((obb (not (string-equal (or (attr node "gradientunits") "objectBoundingBox")
                                    "userSpaceOnUse"))))
        (multiple-value-bind (nx ny xx xy)
            (if obb (g:path-user-bounds ctx) (values 0d0 0d0 1d0 1d0))
          (unless nx (setf nx 0d0 ny 0d0 xx 1d0 xy 1d0))
          (let* ((bx nx) (by ny) (bw (- xx nx)) (bh (- xy ny))
                 (grad
                   (cond
                     ((string= kind "lineargradient")
                      (g:make-linear-gradient
                       (%grad-coord (or (attr node "x1") "0%") obb bx bw)
                       (%grad-coord (or (attr node "y1") "0%") obb by bh)
                       (%grad-coord (or (attr node "x2") "100%") obb bx bw)
                       (%grad-coord (or (attr node "y2") "0%") obb by bh)))
                     ((string= kind "radialgradient")
                      (let ((cx (%grad-coord (or (attr node "cx") "50%") obb bx bw))
                            (cy (%grad-coord (or (attr node "cy") "50%") obb by bh))
                            (r  (%grad-radius (or (attr node "r") "50%") obb bw bh)))
                        (g:make-radial-gradient cx cy 0d0 cx cy r)))
                     (t nil))))
            (when grad
              (dolist (s stops)
                (g:add-color-stop grad (first s) (list (second s) (third s) (fourth s)) (fifth s)))
              grad)))))))

;;; ---- paint servers (patterns) ---------------------------------------------
;;;
;;; <pattern> tiles a fragment of SVG over the shape.  It was listed as deferred and
;;; drew NOTHING: url(#id) resolved to no paint and the shape was silently dropped,
;;; which is how a wallpaper built out of two patterns rendered without either of
;;; them and nothing anywhere said so.  0 of the corpus's 31 pattern tests passed.

(defvar *patterns* nil
  "During a render, a hash of id -> pattern svg-node for url(#id) paints.")

(defvar *pattern-depth* 0
  "Nesting depth of pattern tile rendering.  A pattern whose content is painted with
   the same pattern is a cycle, and the corpus contains one; without this the tile
   render recurses until the stack goes.")

(defun collect-patterns (root)
  "A hash of id -> node for every <pattern> under ROOT."
  (let ((tbl (make-hash-table :test 'equal)))
    (map-tree (lambda (n)
                (when (string= (svg-node-name n) "pattern")
                  (let ((id (attr n "id"))) (when id (setf (gethash id tbl) n)))))
              root)
    tbl))

(defun %href-node (node tbl)
  "The node NODE's href/xlink:href names, looked up in TBL."
  (let ((href (or (attr node "href") (attr node "xlink:href"))))
    (when (and href (> (length href) 1) (char= (char href 0) #\#))
      (gethash (subseq href 1) tbl))))

(defun %pattern-attr (node name &optional (depth 0))
  "Attribute NAME on NODE, or inherited from the pattern it hrefs (SVG 1.1 §13.3:
   a pattern with an href takes any attribute it does not itself specify from the
   referenced one).  DEPTH bounds an href cycle."
  (or (attr node name)
      (when (< depth 8)
        (let ((ref (%href-node node *patterns*)))
          (when ref (%pattern-attr ref name (1+ depth)))))))

(defun %pattern-content (node &optional (depth 0))
  "The children to tile: NODE's own, or — when it has none — those of the pattern it
   hrefs, which is how the corpus's href patterns supply their content."
  (if (plusp (length (svg-node-children node)))
      (svg-node-children node)
      (when (< depth 8)
        (let ((ref (%href-node node *patterns*)))
          (if ref (%pattern-content ref (1+ depth)) #())))))

(defun %ctm-scale (ctx)
  "Device pixels per user unit under the current transform, as one number: the square
   root of the absolute determinant.  The tile is rasterized at this resolution so a
   pattern in a scaled-up group is not a grid of visibly enlarged tile pixels."
  (let ((m (g:ctm ctx)))
    (let ((det (abs (- (* (elt m 0) (elt m 3)) (* (elt m 1) (elt m 2))))))
      (max 0.05d0 (min 16d0 (sqrt (max det 1d-9)))))))

(defun build-pattern (ctx node)
  "A gesso pattern for <pattern> NODE, placed for the current path, or NIL when the
   pattern is one that disables painting — a zero or negative width/height, or no
   content at all (SVG 1.1 §13.3: the element is then not rendered)."
  (when (>= *pattern-depth* 4) (return-from build-pattern nil))
  (let* ((obb (not (string-equal (or (%pattern-attr node "patternunits") "objectBoundingBox")
                                 "userSpaceOnUse")))
         (content (%pattern-content node)))
    (when (zerop (length content)) (return-from build-pattern nil))
    (multiple-value-bind (nx ny xx xy) (g:path-user-bounds ctx)
      (unless nx (setf nx 0d0 ny 0d0 xx 1d0 xy 1d0))
      (let* ((bx nx) (by ny) (bw (- xx nx)) (bh (- xy ny))
             (x (%grad-coord (or (%pattern-attr node "x") "0") obb bx bw))
             (y (%grad-coord (or (%pattern-attr node "y") "0") obb by bh))
             ;; Width/height are LENGTHS, not coordinates: under objectBoundingBox
             ;; they are a fraction OF the box, not a point IN it, so they must not
             ;; pick up the box origin the way x and y do.
             (w (if obb (* (%frac (or (%pattern-attr node "width") "0")) bw)
                    (parse-length (or (%pattern-attr node "width") "0") 0d0)))
             (h (if obb (* (%frac (or (%pattern-attr node "height") "0")) bh)
                    (parse-length (or (%pattern-attr node "height") "0") 0d0))))
        (when (or (<= w 0d0) (<= h 0d0)) (return-from build-pattern nil))
        (let* ((s (%ctm-scale ctx))
               (tpw (max 1 (min 2048 (round (* w s)))))
               (tph (max 1 (min 2048 (round (* h s)))))
               (tile (g:make-context tpw tph :alpha t))
               (vb (parse-viewbox (%pattern-attr node "viewbox")))
               (content-obb (string-equal (or (%pattern-attr node "patterncontentunits")
                                              "userSpaceOnUse")
                                          "objectBoundingBox")))
          ;; Into the tile's own space.  The pattern content's origin is the tile's
          ;; corner — NOT (x,y) in user space — so there is no translate by -x/-y here.
          (g:scale tile (/ tpw w) (/ tph h))
          (cond
            (vb (let ((sx (/ w (third vb))) (sy (/ h (fourth vb))))
                  (let ((u (min sx sy)))
                    (g:scale tile u u)
                    (g:translate tile (- (first vb)) (- (second vb))))))
            ;; viewBox wins over patternContentUnits (§13.3), so this is the else.
            (content-obb (g:scale tile bw bh)))
          (let ((*pattern-depth* (1+ *pattern-depth*)))
            (loop for c across content do (render-node tile c (make-pstate))))
          (g:make-pattern :tile (g:context-canvas tile)
                          :x x :y y :w w :h h
                          :inv (let ((pt (%pattern-attr node "patterntransform")))
                                 (when pt (g:mat-invert (parse-transform pt))))))))))

(defun %paint-source (ctx paint)
  "The gesso paint for a pstate fill/stroke value: a solid colour list, a resolved
   gradient or pattern, or NIL (for :none or an unresolvable reference)."
  (cond ((and (consp paint) (eq (car paint) :url))
         (let ((gnode (and *gradients* (gethash (cdr paint) *gradients*)))
               (pnode (and *patterns* (gethash (cdr paint) *patterns*))))
           (cond (gnode (build-gradient ctx gnode))
                 (pnode (build-pattern ctx pnode))
                 (t nil))))
        ((and (consp paint) (numberp (car paint))) paint)
        (t nil)))

(defun %inherit (node parent)
  "Resolve NODE's paint state, inheriting unspecified values from PARENT pstate.
   `color` / fill-opacity / stroke-opacity inherit; `opacity` is the element's OWN
   value (SVG §14.5) and is folded multiplicatively into the parent's so a group's
   opacity carries to non-overlapping descendants."
  (let* ((color-raw (%prop node "color"))
         (color (if color-raw (or (parse-color color-raw) (pstate-color parent))
                    (pstate-color parent)))
         (fill (%prop node "fill")) (stroke (%prop node "stroke"))
         (sw (%prop node "stroke-width")) (fs (%prop node "font-size"))
         (op (%prop node "opacity"))
         (fo (%prop node "fill-opacity")) (so (%prop node "stroke-opacity"))
         (fr (%prop node "fill-rule"))
         (da (%prop node "stroke-dasharray")) (dof (%prop node "stroke-dashoffset")))
    ;; FONT-SIZE FIRST, and then bound, because `em' on any OTHER property of this
    ;; element means this element's own font-size — only on font-size itself does it
    ;; mean the parent's (CSS Values §5.1.1).  Resolving them all at once left
    ;; stroke-dashoffset="1.5em" on a font-size="20" circle measuring against the
    ;; inherited 16, which is the kind of wrong that looks nearly right.
    (let* ((font-size (if fs (parse-length fs 16d0) (pstate-font-size parent)))
           (*font-size* font-size)
           ;; A percentage on a length that lies along no axis resolves against the
           ;; normalised diagonal (SVG 1.1 §7.10) — stroke-width and the dash lengths
           ;; are the ones that reach here.
           (diag (sqrt (/ (+ (* *viewport-width* *viewport-width*)
                             (* *viewport-height* *viewport-height*))
                          2d0))))
      (make-pstate
       :color color
       :fill (%resolve-paint fill (pstate-fill parent) color)
       :stroke (%resolve-paint stroke (pstate-stroke parent) color)
       :stroke-width (if sw (parse-length sw 1d0 diag) (pstate-stroke-width parent))
       :opacity (* (pstate-opacity parent) (if op (parse-number op 1d0) 1d0))
       :fill-opacity (if fo (parse-number fo 1d0) (pstate-fill-opacity parent))
       :stroke-opacity (if so (parse-number so 1d0) (pstate-stroke-opacity parent))
       :fill-rule (if fr (if (string-equal (string-trim " " fr) "evenodd") :evenodd :nonzero)
                      (pstate-fill-rule parent))
       :dash-array (if da (%parse-dasharray da diag) (pstate-dash-array parent))
       :dash-offset (if dof (parse-length dof 0d0 diag) (pstate-dash-offset parent))
       :font-size font-size))))

(defun %parse-dasharray (s &optional (percent-basis nil))
  "Parse an SVG stroke-dasharray value (comma/space separated LENGTHS) to a list of
   doubles, or NIL for `none`/empty (stroke-dasharray is inherited).

   PARSE-LENGTH per entry, not PARSE-NUMBERS over the lot: the entries carry units
   like everything else, and reading them as bare numbers silently turned `2em 4em'
   into a 2-and-4 unit dash."
  (when (and s (not (string-equal (string-trim " " s) "none")))
    (let* ((toks (remove "" (uiop:split-string (substitute #\Space #\, s)
                                               :separator " ")
                         :test #'string=))
           (vals (mapcar (lambda (t*) (parse-length t* 0d0 percent-basis)) toks)))
      (and vals (some #'plusp vals) vals))))

(defun %paint (ctx ps &key stroke-only fill-only)
  "Fill and/or stroke the current gesso path per pstate PS."
  (let ((fill (pstate-fill ps)) (stroke (pstate-stroke ps)))
    (unless stroke-only
      (let ((p (%paint-source ctx fill)))
        (when p (g:set-fill ctx p)
          (g:set-fill-rule ctx (pstate-fill-rule ps))
          (g:set-global-alpha ctx (* (pstate-opacity ps) (pstate-fill-opacity ps)))
          (g:fill-path ctx))))
    (unless fill-only
      (let ((p (%paint-source ctx stroke)))
        (when (and p (> (pstate-stroke-width ps) 0d0))
          (g:set-stroke ctx p) (g:set-line-width ctx (pstate-stroke-width ps))
          (g:set-line-dash ctx (pstate-dash-array ps) (pstate-dash-offset ps))
          (g:set-global-alpha ctx (* (pstate-opacity ps) (pstate-stroke-opacity ps)))
          (g:stroke-path ctx))))))

(defun %pct-basis (attr-name)
  "What a percentage on geometry attribute ATTR-NAME resolves against (SVG 1.1 §7.10):
   the viewport WIDTH for horizontal lengths, its HEIGHT for vertical ones, and for a
   length on neither axis — a circle's r — the normalised diagonal, which is the only
   value that treats the two axes alike."
  (cond ((member attr-name '("x" "x1" "x2" "cx" "rx" "width") :test #'string=)
         *viewport-width*)
        ((member attr-name '("y" "y1" "y2" "cy" "ry" "height") :test #'string=)
         *viewport-height*)
        (t (sqrt (/ (+ (* *viewport-width* *viewport-width*)
                       (* *viewport-height* *viewport-height*))
                    2d0)))))

(defun %rect-radii (rx-raw ry-raw w h)
  "The effective (values rx ry) of a <rect>, per SVG 1.1 §9.2.  Either radius alone
   supplies the other — `rx' with no `ry' is a CIRCULAR corner, not a corner half
   missing — a negative one is invalid and means auto, and both are clamped to half
   the side so a radius larger than the rect cannot fold it inside out."
  (let* ((rx (and rx-raw (parse-length rx-raw 0d0)))
         (ry (and ry-raw (parse-length ry-raw 0d0)))
         (rx (if (and rx (minusp rx)) nil rx))
         (ry (if (and ry (minusp ry)) nil ry))
         (rx (or rx ry 0d0))
         (ry (or ry rx 0d0)))
    (values (max 0d0 (min rx (/ w 2))) (max 0d0 (min ry (/ h 2))))))

(defun %emit-rect (ctx x y w h rx-raw ry-raw)
  "A <rect>, rounded when it asks to be.  rx/ry were IGNORED — every rounded rect in
   every SVG came out with square corners, and nothing said so, because a rect with
   the wrong corners is still a rect.  It showed up as a pattern test whose pattern
   was right and whose container was the wrong shape."
  (multiple-value-bind (rx ry) (%rect-radii rx-raw ry-raw w h)
    (if (or (<= rx 0d0) (<= ry 0d0))
        (g:rect ctx x y w h)
        ;; G:ELLIPSE appends its flattened arc to the open subpath, so the sides are
        ;; LINE-TOs between corner arcs and the whole thing is one closed subpath.
        (let ((x1 (+ x w)) (y1 (+ y h)) (hp (/ pi 2)))
          (g:move-to ctx (+ x rx) y)
          (g:line-to ctx (- x1 rx) y)
          (g:ellipse ctx (- x1 rx) (+ y ry) rx ry 0d0 (- hp) 0d0 nil)
          (g:line-to ctx x1 (- y1 ry))
          (g:ellipse ctx (- x1 rx) (- y1 ry) rx ry 0d0 0d0 hp nil)
          (g:line-to ctx (+ x rx) y1)
          (g:ellipse ctx (+ x rx) (- y1 ry) rx ry 0d0 hp pi nil)
          (g:line-to ctx x (+ y ry))
          (g:ellipse ctx (+ x rx) (+ y ry) rx ry 0d0 pi (* 1.5d0 pi) nil)
          (g:close-path ctx)))))

(defun %emit-shape (ctx node)
  "Emit basic-shape NODE's geometry into the CURRENT gesso path (no begin-path, so
   several shapes can union into one path — used for clipPath).  Returns
   :stroke-only for shapes with no fillable interior, :skip for a non-shape."
  (let ((name (svg-node-name node)))
    (flet ((len (a &optional (d 0d0)) (parse-length (attr node a) d (%pct-basis a))))
      (cond
        ((string= name "rect")
         (let ((w (len "width")) (h (len "height")))
           (if (or (<= w 0d0) (<= h 0d0)) :skip
               (progn (%emit-rect ctx (len "x") (len "y") w h
                                  (attr node "rx") (attr node "ry"))
                      nil))))
        ;; A NEGATIVE radius is an error and a ZERO radius disables rendering (SVG 1.1
        ;; §9.3-9.4) — neither is a shape to be drawn with the absolute value, which is
        ;; what fell out of passing them straight to gesso.
        ((string= name "circle")
         (let ((r (len "r")))
           (if (<= r 0d0) :skip
               (progn (g:arc ctx (len "cx") (len "cy") r 0d0 (* 2d0 pi) nil) nil))))
        ((string= name "ellipse")
         ;; `auto': a missing rx takes ry's value and vice versa (SVG2 §10.4); with
         ;; neither there is no ellipse at all.
         (let* ((rx-raw (attr node "rx")) (ry-raw (attr node "ry"))
                (rx (if rx-raw (len "rx") (and ry-raw (len "ry"))))
                (ry (if ry-raw (len "ry") (and rx-raw (len "rx")))))
           (if (or (null rx) (null ry) (<= rx 0d0) (<= ry 0d0)) :skip
               (progn (g:ellipse ctx (len "cx") (len "cy") rx ry 0d0 0d0 (* 2d0 pi) nil)
                      nil))))
        ((string= name "line")
         (g:move-to ctx (len "x1") (len "y1")) (g:line-to ctx (len "x2") (len "y2")) :stroke-only)
        ((or (string= name "polyline") (string= name "polygon"))
         (let ((nums (parse-numbers (attr node "points"))))
           (loop for (x y) on nums by #'cddr for first = t then nil
                 while y do (if first (g:move-to ctx x y) (g:line-to ctx x y)))
           (when (string= name "polygon") (g:close-path ctx)))
         (if (string= name "polyline") :stroke-only nil))
        ((string= name "path")
         (emit-path-data ctx (attr node "d")) nil)
        (t :skip)))))

(defun %shape-path (ctx node)
  "Build the gesso path for a basic-shape NODE (begins a fresh path).  Returns
   :stroke-only for shapes with no fillable interior (line/polyline), else NIL."
  (g:begin-path ctx)
  (%emit-shape ctx node))

;;; ---- clipping (SVG §14.3) --------------------------------------------------
(defun %clip-ref (node)
  "The clipPath element referenced by NODE's `clip-path: url(#id)`, or NIL."
  (let ((cp (%prop node "clip-path")))
    (when (and cp *defs*)
      (let ((id (%url-id cp)))
        (when id
          (let ((n (gethash id *defs*)))
            (when (and n (string= (svg-node-name n) "clippath")) n)))))))

;;; ---- masks ----------------------------------------------------------------
;;;
;;; <mask> paints a fragment offscreen and uses its LUMINANCE as an alpha channel:
;;; white shows the element, black hides it, grey is translucent.  gesso already had
;;; the substrate — a device-space soft mask multiplied into every paint — so this is
;;; wiring, not invention.  The corpus was passing 4 of 39 mask tests, and most of
;;; those were the ones where the right answer is to draw nothing.

(defvar *mask-depth* 0
  "Nesting depth of mask rendering, to stop a mask that references itself.")

(defun %mask-ref (node)
  "The <mask> element referenced by NODE's `mask=\"url(#id)\"', or NIL."
  (let ((m (%prop node "mask")))
    (when (and m *defs*)
      (let ((id (%url-id m)))
        (when id
          (let ((n (gethash id *defs*)))
            (when (and n (string= (svg-node-name n) "mask")) n)))))))

(defun %luminance-mask (mask-ctx w h alpha-only)
  "A device-space alpha array (W*H doubles in 0..1) from the rendered MASK-CTX: the
   sRGB luminance of each pixel times its alpha, or — for mask-type=\"alpha\" — the
   alpha alone.

   sRGB coefficients, which is what browsers do.  SVG 1.1 specified linearRGB here
   and the corpus has a test pinning that; matching Chromium is the harness's whole
   premise, so sRGB it is, and the linearRGB case is a known failure rather than a
   silent difference."
  (let* ((cv (g:context-canvas mask-ctx))
         (px (scribe:canvas-pixels cv)) (ap (scribe:canvas-alpha cv))
         (out (make-array (* w h) :element-type 'double-float :initial-element 0d0)))
    (dotimes (j (* w h) out)
      (let ((a (if ap (aref ap j) 255)))
        (setf (aref out j)
              (if (zerop a)
                  0d0
                  (if alpha-only
                      (/ a 255d0)
                      ;; PIXELS ARE PREMULTIPLIED, so the luminance of the premultiplied
                      ;; colour already carries the alpha factor — dividing it out here
                      ;; and multiplying it back would only add rounding.
                      (min 1d0 (/ (+ (* 0.2126d0 (aref px (* 3 j)))
                                     (* 0.7152d0 (aref px (+ (* 3 j) 1)))
                                     (* 0.0722d0 (aref px (+ (* 3 j) 2))))
                                  255d0)))))))))

(defun %node-user-bbox (ctx node)
  "The union of NODE's subtree geometry in the CURRENT user space, as
   (values x0 y0 x1 y1), or NIL when the subtree draws nothing.  Each descendant's own
   `transform' is applied on the way down, so this is the object bounding box a
   maskUnits=\"objectBoundingBox\" region is a fraction of."
  (let ((x0 nil) (y0 nil) (x1 nil) (y1 nil))
    (labels ((walk (n)
               (g:save ctx)
               (let ((tf (attr n "transform")))
                 (when tf (apply #'g:transform ctx (parse-transform tf))))
               (g:begin-path ctx)
               (unless (eq (%emit-shape ctx n) :skip)
                 (multiple-value-bind (ax ay bx by) (g:path-user-bounds ctx)
                   (when ax
                     (setf x0 (if x0 (min x0 ax) ax) y0 (if y0 (min y0 ay) ay)
                           x1 (if x1 (max x1 bx) bx) y1 (if y1 (max y1 by) by)))))
               (loop for c across (svg-node-children n) do (walk c))
               (g:restore ctx)))
      (walk node))
    (when x0 (values x0 y0 x1 y1))))

(defun %mask-region (ctx mask-node node)
  "The mask's region rectangle in USER space, as (values x y w h), or NIL to mask
   nothing out.  SVG 1.1 §14.4: maskUnits defaults to objectBoundingBox and the
   region defaults to -10%/-10%/120%/120% of it — deliberately larger than the object,
   because a mask is allowed to be blurred or offset beyond what it masks."
  (let* ((units (or (attr mask-node "maskunits") "objectBoundingBox"))
         (obb (not (string-equal units "userSpaceOnUse")))
         (rx (or (attr mask-node "x") "-10%")) (ry (or (attr mask-node "y") "-10%"))
         (rw (or (attr mask-node "width") "120%")) (rh (or (attr mask-node "height") "120%")))
    (if obb
        (multiple-value-bind (bx0 by0 bx1 by1) (%node-user-bbox ctx node)
          (when bx0
            (let ((bw (- bx1 bx0)) (bh (- by1 by0)))
              (values (+ bx0 (* (%frac rx) bw)) (+ by0 (* (%frac ry) bh))
                      (* (%frac rw) bw) (* (%frac rh) bh)))))
        (values (parse-length rx 0d0 *viewport-width*)
                (parse-length ry 0d0 *viewport-height*)
                (parse-length rw 0d0 *viewport-width*)
                (parse-length rh 0d0 *viewport-height*)))))

(defun %clip-mask-to-region (m ctx w h rx ry rw rh)
  "Zero every entry of device-space mask M outside the user-space rectangle
   RX,RY,RW,RH.  Each pixel is mapped BACK through the inverse CTM rather than the
   rectangle being mapped forward, because under a rotation the forward image of a
   rectangle is not a rectangle and clipping to its bounding box would leak the
   corners."
  (let ((inv (g:mat-invert (g:ctm ctx))))
    (when inv
      (dotimes (py h)
        (dotimes (px w)
          (let ((j (+ px (* py w))))
            (when (plusp (aref m j))
              (multiple-value-bind (ux uy) (g:mat-apply inv (+ px 0.5d0) (+ py 0.5d0))
                (unless (and (<= rx ux (+ rx rw)) (<= ry uy (+ ry rh)))
                  (setf (aref m j) 0d0))))))))))

(defun %apply-mask (ctx mask-node ps &optional node)
  "Render MASK-NODE offscreen under the CURRENT transform and install its luminance
   as the gesso soft mask.  Returns T when a mask was installed.

   The offscreen context is the same DEVICE size as the target and is given the same
   CTM, so the result is already in device space — which is what SET-SOFT-MASK wants
   and what makes a mask under a rotated group land where the group did."
  (when (>= *mask-depth* 4) (return-from %apply-mask nil))
  (let* ((cv (g:context-canvas ctx))
         (w (scribe:canvas-width cv)) (h (scribe:canvas-height cv))
         (mctx (g:make-context w h :alpha t)))
    (apply #'g:set-transform mctx (g:ctm ctx))
    (let ((*mask-depth* (1+ *mask-depth*)))
      ;; A mask's own content may be masked or clipped in turn; RENDER-NODE handles
      ;; that, so the children go through it exactly as any other subtree would.
      (loop for c across (svg-node-children mask-node)
            do (render-node mctx c (make-pstate :font-size (pstate-font-size ps)))))
    (let* ((mt (or (%prop mask-node "mask-type") (attr mask-node "mask-type")))
           (alpha-only (and mt (string-equal (string-trim " " mt) "alpha")))
           (m (%luminance-mask mctx w h alpha-only))
           (prev (g:soft-mask ctx)))
      ;; The REGION last: content outside it is not masked-out content, it is content
      ;; the mask never covered, and a mask that does not cover a pixel hides it.
      (when node
        (multiple-value-bind (rx ry rw rh) (%mask-region ctx mask-node node)
          (if (and rx (plusp rw) (plusp rh))
              (%clip-mask-to-region m ctx w h rx ry rw rh)
              ;; A degenerate region masks the element away entirely (§14.4).
              (when rx (fill m 0d0)))))
      ;; NESTED masks multiply: an element inside a masked group is hidden where
      ;; EITHER mask hides it, and taking only the inner one would let content escape
      ;; the outer mask entirely.
      (when prev
        (dotimes (j (* w h)) (setf (aref m j) (* (aref m j) (aref prev j)))))
      (g:set-soft-mask ctx m)
      t)))

(defun %clip-shape-node (n)
  "The shape a clipPath child contributes, following a <use> to its target.  Only
   shapes and text clip (SVG 1.1 §14.3); anything else contributes nothing."
  (cond ((member (svg-node-name n) '("rect" "circle" "ellipse" "polygon" "polyline"
                                     "line" "path") :test #'string=)
         n)
        ((string= (svg-node-name n) "use")
         (let ((href (or (attr n "href") (attr n "xlink:href"))))
           (when (and href (> (length href) 1) (char= (char href 0) #\#) *defs*)
             (let ((ref (gethash (subseq href 1) *defs*)))
               (when ref (%clip-shape-node ref))))))
        (t nil)))

(defun %display-none-p (n)
  "True when N is display:none, which removes it from a clipPath's geometry entirely
   (§14.3) — not merely from what is painted."
  (let ((d (%prop n "display")))
    (and d (string-equal (string-trim " " d) "none"))))

(defun %apply-clip (ctx clip-node &optional node)
  "Intersect the gesso clip with the union of CLIP-NODE's shapes.

   THREE THINGS BEYOND THE SHAPES, all of which were missing and each of which
   produced a clip of the right kind in the wrong place:

   - the `transform' ON THE CLIPPATH ELEMENT ITSELF, not just on its children;
   - clipPathUnits=\"objectBoundingBox\", where the children's coordinates are
     fractions of the clipped object's bounding box rather than user units — the
     same idea masks needed, and the reason NODE is a parameter;
   - <use> children, which resolve to the shape they name, and display:none
     children, which contribute no geometry at all."
  (let* ((obb (string-equal (or (attr clip-node "clippathunits") "userSpaceOnUse")
                            "objectBoundingBox"))
         ;; BEFORE begin-path: %NODE-USER-BBOX builds and discards paths of its own.
         (bbox (when (and obb node)
                 (multiple-value-list (%node-user-bbox ctx node)))))
    (when (and obb (null (first bbox)))
      ;; objectBoundingBox units against an object with no box: the clip is empty,
      ;; which hides the element rather than leaving it unclipped.
      (g:begin-path ctx) (g:clip ctx :nonzero)
      (return-from %apply-clip))
    (let ((rule :nonzero))
      ;; THE PATH IS BUILT UNDER THE TRANSFORM AND CLIPPED AFTER IT IS UNWOUND.  G:CLIP
      ;; writes the clip into the GSTATE, so wrapping it in a SAVE/RESTORE pair throws it
      ;; away again — which is precisely what a first version of this did, taking
      ;; clipPath from 24/52 to 4/52 with a dozen tests fully white.  The path itself
      ;; lives in the context's subpaths and is already in device space by the time it is
      ;; emitted, so it survives the RESTORE that the clip would not have.
      (g:save ctx)
      (let ((tf (attr clip-node "transform")))
        (when tf (apply #'g:transform ctx (parse-transform tf))))
      (when obb
        (destructuring-bind (bx by bx1 by1) bbox
          (g:translate ctx bx by)
          (g:scale ctx (- bx1 bx) (- by1 by))))
      (g:begin-path ctx)
      (loop for child across (svg-node-children clip-node)
            for shape = (and (not (%display-none-p child)) (%clip-shape-node child))
            when shape
              do (let ((tf (attr child "transform"))
                       (cr (%prop child "clip-rule")))
                   (when (and cr (string-equal (string-trim " " cr) "evenodd"))
                     (setf rule :evenodd))
                   (g:save ctx)
                   (when tf (apply #'g:transform ctx (parse-transform tf)))
                   ;; A <use> child contributes its target's geometry at the use's
                   ;; own x/y, so that offset has to survive the indirection.
                   (when (string= (svg-node-name child) "use")
                     (g:translate ctx (parse-length (attr child "x") 0d0)
                                  (parse-length (attr child "y") 0d0)))
                   (%emit-shape ctx shape)
                   (g:restore ctx)))
      (g:restore ctx)
      (g:clip ctx rule))))


;;; ---- <image> ---------------------------------------------------------------
;;;
;;; An <image> is a raster or an SVG placed in a box.  The raster half cannot live
;;; here: decoding PNG/JPEG/GIF/WebP is PIGMENT's job, and pigment DEPENDS ON STENCIL
;;; (it renders SVG through us), so a dependency the other way would be a cycle.  So
;;; the decoder is a HOOK the host installs, and stencil owns only what it can: the
;;; fetch, the SVG case, and the geometry.

(defvar *image-decoder* nil
  "Host hook: a function of an octet vector returning (values RGBA W H) — straight
   alpha, row 0 at the top — or NIL if it cannot decode those bytes.  weft and the
   corpus harness install PIGMENT's; with none installed a raster <image> draws
   nothing, which is the honest behaviour for a renderer that cannot see the bytes.")

(defvar *document-directory* nil
  "Directory the SVG being rendered came from, for resolving a relative <image href>.
   NIL means relative hrefs do not resolve — a renderer handed a string and no origin
   has no business guessing one.")

(defparameter %b64-chars
  "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/")

(defun %base64-decode (string)
  "STRING as an octet vector, ignoring whitespace and padding.  Here rather than
   borrowed because the whole point of this file's layer is that it has no host."
  (let ((out (make-array (ceiling (* 3 (length string)) 4)
                         :element-type '(unsigned-byte 8) :fill-pointer 0))
        (acc 0) (bits 0))
    (loop for ch across string
          for v = (position ch %b64-chars)
          when v do
            (setf acc (logior (ash acc 6) v))
            (incf bits 6)
            (when (>= bits 8)
              (decf bits 8)
              (vector-push (ldb (byte 8 bits) acc) out)))
    (coerce out '(simple-array (unsigned-byte 8) (*)))))

(defun %data-uri-parts (href)
  "(values MIME PAYLOAD-STRING BASE64-P) for a data: URI, or NIL."
  (when (and (> (length href) 5) (string-equal "data:" (subseq href 0 5)))
    (let ((comma (position #\, href)))
      (when comma
        (let ((meta (subseq href 5 comma)))
          (values (subseq meta 0 (or (position #\; meta) (length meta)))
                  (subseq href (1+ comma))
                  (search ";base64" meta :test #'char-equal)))))))

(defun %percent-decode (s)
  (with-output-to-string (o)
    (let ((i 0) (n (length s)))
      (loop while (< i n)
            do (let ((c (char s i)))
                 (if (and (char= c #\%) (< (+ i 2) n))
                     (progn (write-char (code-char (parse-integer s :start (1+ i) :end (+ i 3)
                                                                  :radix 16 :junk-allowed t))
                                        o)
                            (incf i 3))
                     (progn (write-char c o) (incf i))))))))

(defun %image-bytes (href)
  "The bytes an <image href> names: a data: URI, or a file relative to
   *DOCUMENT-DIRECTORY*.  NIL for anything else — notably http(s), because fetching
   over the network is not a rendering library's decision to make."
  (multiple-value-bind (mime payload b64) (%data-uri-parts href)
    (cond
      (payload (values (if b64 (%base64-decode payload)
                           (map '(simple-array (unsigned-byte 8) (*)) #'char-code
                                (%percent-decode payload)))
                       mime))
      ((or (search "://" href) (null *document-directory*)) nil)
      (t (let ((path (merge-pathnames href *document-directory*)))
           (when (probe-file path)
             (with-open-file (in path :element-type '(unsigned-byte 8))
               (let ((b (make-array (file-length in) :element-type '(unsigned-byte 8))))
                 (read-sequence b in)
                 (values b nil)))))))))

(defun %gunzip-if-needed (bytes)
  "BYTES, decompressed when they are gzip.  A .svgz is a gzipped .svg (SVG 1.1
   appendix B) and both the corpus and the wider web serve them, so an SVG renderer
   that cannot open one is a renderer that fails on a file type its own spec
   defines.  CRAM has the inflate; a bad stream falls back to the raw bytes rather
   than signalling, since the caller's next move — sniff, then parse — will reject
   them anyway with a better message."
  (if (and (>= (length bytes) 2) (= (aref bytes 0) #x1f) (= (aref bytes 1) #x8b))
      (or (ignore-errors (cram:gzip-decompress bytes)) bytes)
      bytes))

(defun %svg-bytes-p (bytes mime)
  "True when BYTES are SVG/XML rather than a raster: the MIME says so, or the first
   non-space character is a `<'.  The corpus has data URIs typed `data:;base64' with
   no mime at all, so sniffing is not optional."
  (or (and mime (search "svg" mime :test #'char-equal))
      (loop for i from 0 below (min 64 (length bytes))
            for c = (code-char (aref bytes i))
            unless (member c '(#\Space #\Tab #\Newline #\Return))
              return (char= c #\<))))

(defun %fit-box (iw ih bx by bw bh par)
  "Place an IW x IH image into box BX,BY,BW,BH per preserveAspectRatio PAR, as
   (values x y w h).  `none' stretches; otherwise the image scales uniformly and is
   aligned, `meet' (the default) fitting inside and `slice' covering."
  (let* ((p (string-downcase (or par "xMidYMid meet")))
         (slice (search "slice" p)))
    (if (search "none" p)
        (values bx by bw bh)
        (let* ((s (if slice (max (/ bw iw) (/ bh ih)) (min (/ bw iw) (/ bh ih))))
               (w (* iw s)) (h (* ih s))
               (fx (cond ((search "xmin" p) 0d0) ((search "xmax" p) 1d0) (t 0.5d0)))
               (fy (cond ((search "ymin" p) 0d0) ((search "ymax" p) 1d0) (t 0.5d0))))
          (values (+ bx (* (- bw w) fx)) (+ by (* (- bh h) fy)) w h)))))

(defun %render-image (ctx node ps)
  "Draw an <image>.  Rasters go through *IMAGE-DECODER*; SVG hrefs are rendered by
   stencil itself into an offscreen surface at DEVICE resolution — the recursion is
   free, and routing SVG through a host decoder would mean pigment calling us to do
   what we were already able to do."
  (let* ((wa (attr node "width")) (ha (attr node "height"))
         ;; ABSENT is not ZERO.  An absent width/height is `auto\' and takes the image\'s
         ;; intrinsic size; an EXPLICIT zero disables rendering (SVG2 §12.3).  Reading
         ;; both as 0d0 and calling that auto made width="0" draw a full-size image —
         ;; it cost a test the moment auto was added, which is the cheapest possible
         ;; way to be told the two cases are different.
         (autow (or (null wa) (string-equal (string-trim " " wa) "auto")))
         (autoh (or (null ha) (string-equal (string-trim " " ha) "auto")))
         (bw (if autow 0d0 (parse-length wa 0d0 *viewport-width*)))
         (bh (if autoh 0d0 (parse-length ha 0d0 *viewport-height*)))
         (bx (parse-length (attr node "x") 0d0 *viewport-width*))
         (by (parse-length (attr node "y") 0d0 *viewport-height*))
         (href (or (attr node "href") (attr node "xlink:href"))))
    (when (or (null href) (minusp bw) (minusp bh)
              (and (not autow) (zerop bw)) (and (not autoh) (zerop bh)))
      (return-from %render-image))
    (multiple-value-bind (bytes mime) (%image-bytes href)
      (when (null bytes) (return-from %render-image))
      (setf bytes (%gunzip-if-needed bytes))
      ;; AUTO SIZE.  A missing width or height is not zero, it is `auto\': the image
      ;; contributes its own intrinsic size, and a missing pair means draw it at its
      ;; natural size (SVG2 §12.3, which is also what browsers do).  So the raster has
      ;; to be decoded BEFORE the box is known — which is why the decode is not guarded
      ;; by the box being non-empty.
      (multiple-value-bind (rgba iw ih)
          (if (%svg-bytes-p bytes mime)
              (%rasterize-svg-bytes ctx bytes
                                    (if (plusp bw) bw *viewport-width*)
                                    (if (plusp bh) bh *viewport-height*))
              (when *image-decoder* (funcall *image-decoder* bytes)))
        (when (and rgba (plusp iw) (plusp ih))
          (let ((ar (/ (float iw 1d0) ih)))
            (cond ((and autow autoh) (setf bw (float iw 1d0) bh (float ih 1d0)))
                  (autow (setf bw (* bh ar)))
                  (autoh (setf bh (/ bw ar))))))
        (when (and rgba (plusp iw) (plusp ih) (plusp bw) (plusp bh))
          (multiple-value-bind (px py pw ph)
              (%fit-box iw ih bx by bw bh (attr node "preserveaspectratio"))
            (g:save ctx)
            (g:set-global-alpha ctx (* (pstate-opacity ps) (pstate-fill-opacity ps)))
            ;; DRAW-IMAGE-RGBA paints the unit square of the current user space, so
            ;; the placement is expressed as a transform rather than as coordinates —
            ;; which is also what makes a rotated <image> come out rotated.
            ;;
            ;; AND THE SQUARE IS Y-UP.  gesso samples the source at (1 - v), the PDF
            ;; convention it was written for in folio, so v=0 is the image's BOTTOM
            ;; row.  SVG's user space is y-down, so the box is entered at its bottom
            ;; edge with a negative y scale; without that every <image> came out
            ;; vertically mirrored — recognisably the right picture, upside down.
            (g:translate ctx px (+ py ph))
            (g:scale ctx pw (- ph))
            (g:draw-image-rgba ctx rgba iw ih)
            (g:restore ctx)))))))

(defun %rasterize-svg-bytes (ctx bytes bw bh)
  "Render an SVG href into a straight-alpha RGBA image sized to the box in DEVICE
   pixels, so a nested SVG is as sharp as the surface it lands on."
  (let* ((src (map 'string #'code-char bytes))
         (s (%ctm-scale ctx))
         (w (max 1 (min 4096 (round (* bw s))))) (h (max 1 (min 4096 (round (* bh s))))))
    (when (>= *pattern-depth* 4) (return-from %rasterize-svg-bytes nil))
    (let ((root (ignore-errors (parse-svg src))))
      (when root
        (let* ((*pattern-depth* (1+ *pattern-depth*))
               (sub (render-svg-to-canvas root :width w :height h
                                               :canvas (scribe:make-rgba-canvas w h)))
               (cv (g:context-canvas sub))
               (px (scribe:canvas-pixels cv)) (ap (scribe:canvas-alpha cv))
               (rgba (make-array (* w h 4) :element-type '(unsigned-byte 8))))
          ;; premultiplied -> straight, which is what DRAW-IMAGE-RGBA documents itself
          ;; as taking.
          (dotimes (j (* w h))
            (let ((a (if ap (aref ap j) 255)) (i3 (* 3 j)) (i4 (* 4 j)))
              (if (zerop a)
                  (setf (aref rgba i4) 0 (aref rgba (+ i4 1)) 0
                        (aref rgba (+ i4 2)) 0 (aref rgba (+ i4 3)) 0)
                  (setf (aref rgba i4) (min 255 (floor (* (aref px i3) 255) a))
                        (aref rgba (+ i4 1)) (min 255 (floor (* (aref px (+ i3 1)) 255) a))
                        (aref rgba (+ i4 2)) (min 255 (floor (* (aref px (+ i3 2)) 255) a))
                        (aref rgba (+ i4 3)) a))))
          (values rgba w h))))))

(defun %anchor-x (ctx node text x)
  "X shifted for `text-anchor\' (SVG 1.1 \u00a710.9.1): the given X is where the anchor
   sits, not necessarily where the text starts.  `middle\' centres the advance on it and
   `end\' puts the advance before it.

   This was not implemented, and it is most of what the text bucket was failing on: with
   the fonts finally matched, the residual difference on a plain centred label was two
   copies of the same word side by side in the diff — same glyphs, same size, wrong
   place.  text-anchor is INHERITED, so it is read with %PROP up the tree by the caller\'s
   pstate normally; here it is taken from the element and its ancestors directly, which
   covers the corpus\'s shape of putting it on the <text> or on a wrapping <g>."
  (let ((a (or (%prop node "text-anchor")
               (let ((p (svg-node-parent node)))
                 (loop while p
                       for v = (%prop p "text-anchor")
                       when v return v
                       do (setf p (svg-node-parent p)))))))
    (if (null a)
        x
        (let ((a (string-downcase (string-trim " " a))))
          (cond ((string= a "middle") (- x (/ (g:text-width ctx text) 2)))
                ((string= a "end") (- x (g:text-width ctx text)))
                (t x))))))

(defun render-node (ctx node parent-ps)
  "Render NODE and its subtree onto gesso context CTX, inheriting PARENT-PS."
  ;; LET* and in this order: %INHERIT resolves this node's own font-size, and a
  ;; font-size of "2em" means twice the PARENT's — so *FONT-SIZE* must still hold the
  ;; parent's value while %INHERIT runs, and the node's only afterwards.
  (let* ((name (svg-node-name node)) (ps (%inherit node parent-ps))
         (*font-size* (pstate-font-size ps)))
    ;; non-rendered / metadata elements
    (when (member name '("defs" "title" "desc" "metadata" "style" "symbol" "clippath"
                         "lineargradient" "radialgradient" "filter" "mask" "marker")
                  :test #'string=)
      (return-from render-node))
    (g:save ctx)
    (let ((tf (attr node "transform"))) (when tf (apply #'g:transform ctx (parse-transform tf))))
    (let ((clip-node (%clip-ref node))) (when clip-node (%apply-clip ctx clip-node node)))
    ;; After the clip and inside the G:SAVE, so G:RESTORE takes the soft mask back off
    ;; with everything else — a mask that outlived its element would silently dim the
    ;; rest of the document.
    (let ((mask-node (%mask-ref node))) (when mask-node (%apply-mask ctx mask-node ps node)))
    (cond
      ((member name '("svg" "g" "a" "switch") :test #'string=)
       (loop for c across (svg-node-children node) do (render-node ctx c ps)))
      ((string= name "image") (%render-image ctx node ps))
      ((string= name "use")
       ;; SVG §5.6: clone the referenced element at the use's x/y offset.
       (let* ((href (or (attr node "href") (attr node "xlink:href")))
              (ref (and href (> (length href) 1) (char= (char href 0) #\#) *defs*
                        (gethash (subseq href 1) *defs*))))
         ;; A <use> that reaches an element already being expanded is a CYCLE, and SVG
         ;; §5.6 says such a document is in error and the element is not rendered.  There
         ;; was no guard: `<use href="#a">' inside `#a' recursed until the control stack
         ;; went, which took the whole corpus run down with it twice — once as a stack
         ;; exhaustion at test 1304, and once, after unrelated changes shifted the frame
         ;; size, as a hang that never terminated at all.
         (when (and ref (not (member ref *use-stack*)))
           (let ((*use-stack* (cons ref *use-stack*)))
             (g:translate ctx (parse-length (attr node "x") 0d0)
                          (parse-length (attr node "y") 0d0))
             (render-node ctx ref ps)))))
      ((string= name "text")
       (let* ((tx (parse-length (attr node "x") 0d0)) (ty (parse-length (attr node "y") 0d0))
              (p (%paint-source ctx (pstate-fill ps))))
         (g:set-font ctx (pstate-font-size ps))
         (when (and (svg-node-text node) p)
           (g:set-fill ctx p) (g:set-global-alpha ctx (pstate-opacity ps))
           (g:fill-text ctx (svg-node-text node)
                        (%anchor-x ctx node (svg-node-text node) tx) ty))
         ;; render tspan children in flow (approximate: at their own x/y)
         (loop for c across (svg-node-children node)
               when (string= (svg-node-name c) "tspan")
                 do (render-node ctx c ps))))
      ((string= name "tspan")
       (let ((p (%paint-source ctx (pstate-fill ps))))
         (g:set-font ctx (pstate-font-size ps))
         (when (and (svg-node-text node) p)
           (g:set-fill ctx p)
           (g:fill-text ctx (svg-node-text node)
                        (%anchor-x ctx node (svg-node-text node)
                                   (parse-length (attr node "x") 0d0))
                        (parse-length (attr node "y") 0d0)))))
      (t
       (let ((kind (%shape-path ctx node)))
         (case kind
           (:skip)
           (:stroke-only (%paint ctx ps :stroke-only t))
           (t (%paint ctx ps))))))
    (g:restore ctx)))

(defun svg-intrinsic-size (root)
  "Best (values width height) in px for ROOT: width/height attrs, else viewBox
   extent, else a 300x150 default."
  (let* ((w (attr root "width")) (h (attr root "height")) (vb (parse-viewbox (attr root "viewbox"))))
    (values (cond (w (parse-length w 300d0)) (vb (third vb)) (t 300d0))
            (cond (h (parse-length h 150d0)) (vb (fourth vb)) (t 150d0)))))

(defun %svg-len-attr (s)
  "A definite (non-percent, positive) length attribute value as a double, or NIL."
  (when (and s (plusp (length s)) (not (find #\% s)))
    (let ((v (parse-length s 0d0))) (and (plusp v) v))))

(defun svg-intrinsic-dimensions (root)
  "Intrinsic (values WIDTH HEIGHT RATIO) of an SVG per CSS/SVG sizing — each NIL when
absent, feeding a consumer's CSS default sizing algorithm.  A definite (non-percent,
positive) width/height attribute is that intrinsic dimension; RATIO is width/height
when both are definite, else the viewBox aspect (vbw/vbh).  RATIO is 0 for a
zero-width viewBox and :INFINITE for a zero-height viewBox — the degenerate ratios
the sizing tests probe."
  (let* ((iw (%svg-len-attr (attr root "width")))
         (ih (%svg-len-attr (attr root "height")))
         (vb (parse-viewbox (attr root "viewbox")))
         (vbw (and vb (third vb))) (vbh (and vb (fourth vb)))
         (ratio (cond ((and iw ih) (/ iw ih))
                      ((and vbw vbh (plusp vbw) (plusp vbh)) (/ vbw vbh))
                      ((and vbw vbh (plusp vbw) (zerop vbh)) :infinite)
                      ((and vbw vbh (zerop vbw) (plusp vbh)) 0)
                      (t nil))))
    (values iw ih ratio)))

(defun render-svg-to-canvas (root &key width height (background '(255 255 255)) canvas)
  "Render SVG DOM ROOT onto a scribe canvas.  WIDTH/HEIGHT override the intrinsic
   size (the layout box); a viewBox is fitted into that box.  Returns the gesso
   context (its canvas is the rendered surface)."
  (multiple-value-bind (iw ih) (svg-intrinsic-size root)
    (let* ((w (round (or width iw))) (h (round (or height ih)))
           (ctx (g:make-context (max 1 w) (max 1 h) :background background :canvas canvas))
           (vb (parse-viewbox (attr root "viewbox"))))
      (when (and vb (> (third vb) 0) (> (fourth vb) 0))
        ;; Fit the viewBox into the WxH box per preserveAspectRatio.  The default
        ;; (xMidYMid meet) scales uniformly to fit and centers, so a viewBox whose
        ;; aspect differs from the box is letterboxed — NOT stretched (HN's votearrow
        ;; is a 32x16 viewBox in a 32x32 box; a non-uniform scale doubled it in y).
        ;; `preserveAspectRatio: none` explicitly asks for the stretch.
        (let ((par (attr root "preserveaspectratio")))
          (if (and par (search "none" par :test #'char-equal))
              (progn (g:scale ctx (/ w (third vb)) (/ h (fourth vb)))
                     (g:translate ctx (- (first vb)) (- (second vb))))
              (let* ((s (min (/ w (third vb)) (/ h (fourth vb))))
                     (offx (/ (- w (* s (third vb))) 2.0)) (offy (/ (- h (* s (fourth vb))) 2.0)))
                (g:translate ctx offx offy)
                (g:scale ctx s s)
                (g:translate ctx (- (first vb)) (- (second vb)))))))
      (let* ((*gradients* (collect-gradients root)) (*defs* (collect-ids root))
             (*patterns* (collect-patterns root))
             ;; The viewport vw/vh/vmin/vmax resolve against, in USER units: the
             ;; viewBox's extent when there is one, since that is what a user unit
             ;; means inside it, and the layout box otherwise.
             (*viewport-width* (if (and vb (plusp (third vb))) (float (third vb) 1d0)
                                   (float w 1d0)))
             (*viewport-height* (if (and vb (plusp (fourth vb))) (float (fourth vb) 1d0)
                                    (float h 1d0)))
             ;; The root's own font-size, for rem/rlh — resolved before any element
             ;; has changed *FONT-SIZE*, so `rem' means the root's and not the
             ;; nearest ancestor's.
             (*root-font-size* (let ((fs (%prop root "font-size")))
                                 (if fs (parse-length fs 16d0) 16d0)))
             (*font-size* *root-font-size*))
        (render-node ctx root (make-pstate)))
      ctx)))

(defun render-svg (source &key width height (background '(255 255 255)))
  "Parse SVG SOURCE and render it.  Returns the gesso context, or NIL if the
   source has no root element."
  (let ((root (parse-svg source)))
    (when root (render-svg-to-canvas root :width width :height height :background background))))
