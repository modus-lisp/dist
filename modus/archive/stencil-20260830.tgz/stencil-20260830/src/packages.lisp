;;;; packages.lisp — stencil package definition.
(defpackage #:stencil
  (:use #:cl)
  (:local-nicknames (#:g #:gesso))
  (:export
   ;; SVG DOM (dom.lisp)
   #:svg-node #:svg-node-name #:svg-node-attrs #:svg-node-children
   #:svg-node-text #:svg-node-parent
   #:make-svg-node #:attr #:append-child
   #:get-element-by-id #:elements-by-tag #:map-tree
   ;; parsing (xml.lisp)
   #:parse-svg
   ;; attribute parsing (units.lisp)
   #:parse-length #:parse-number #:parse-color #:parse-transform #:parse-viewbox
   ;; path data (pathdata.lisp)
   #:emit-path-data
   ;; rendering (render.lisp)
   #:render-node #:render-svg #:render-svg-to-canvas #:svg-intrinsic-size
   ;; host hooks: raster decoding lives above us (pigment depends on stencil, not
   ;; the other way round), and a relative href needs an origin we are not given.
   #:*image-decoder* #:*document-directory*
   #:svg-intrinsic-dimensions))
