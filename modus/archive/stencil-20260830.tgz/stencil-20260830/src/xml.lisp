;;;; xml.lisp — a minimal XML parser that builds an SVG DOM.
;;;;
;;;; Enough XML for SVG: elements with attributes (single/double quoted),
;;;; self-closing tags, character data, comments, processing instructions and
;;;; doctype/CDATA skipping, and the five predefined entities plus numeric
;;;; character references.  Not a validating parser — it recovers from stray
;;;; markup by resyncing at the next '<'.
(in-package #:stencil)

(defun %decode-entities (s)
  "Decode &amp; &lt; &gt; &quot; &apos; and &#nn; / &#xhh; references in S."
  (if (null (position #\& s)) s
      (with-output-to-string (o)
        (let ((i 0) (n (length s)))
          (loop while (< i n) do
            (let ((c (char s i)))
              (if (and (char= c #\&) (< (1+ i) n))
                  (let ((semi (position #\; s :start i :end (min n (+ i 12)))))
                    (if (null semi) (progn (write-char c o) (incf i))
                        (let ((ent (subseq s (1+ i) semi)))
                          (cond
                            ((string= ent "amp") (write-char #\& o))
                            ((string= ent "lt") (write-char #\< o))
                            ((string= ent "gt") (write-char #\> o))
                            ((string= ent "quot") (write-char #\" o))
                            ((string= ent "apos") (write-char #\' o))
                            ((and (plusp (length ent)) (char= (char ent 0) #\#))
                             (let* ((hex (and (> (length ent) 1) (member (char ent 1) '(#\x #\X))))
                                    (code (ignore-errors
                                           (parse-integer ent :start (if hex 2 1) :radix (if hex 16 10)))))
                               (if code (write-char (code-char code) o) (write-string (subseq s i (1+ semi)) o))))
                            (t (write-string (subseq s i (1+ semi)) o)))
                          (setf i (1+ semi)))))
                  (progn (write-char c o) (incf i)))))))))

(defun %name-end (s i n)
  (loop while (and (< i n) (not (member (char s i) '(#\Space #\Tab #\Newline #\Return #\/ #\> #\=)))) do (incf i))
  i)

(defun %skip-ws (s i n)
  (loop while (and (< i n) (member (char s i) '(#\Space #\Tab #\Newline #\Return))) do (incf i))
  i)

(defun %parse-attrs (s i n)
  "Parse attributes starting at I up to '>' or '/>'.  Returns (values alist end)."
  (let ((attrs '()))
    (loop
      (setf i (%skip-ws s i n))
      (when (or (>= i n) (member (char s i) '(#\> #\/))) (return))
      (let ((ns (%name-end s i n)))
        (if (= ns i)
            (incf i)                                    ; stray char: skip one
            (let ((name (string-downcase (subseq s i ns))) (j (%skip-ws s ns n)))
              (if (and (< j n) (char= (char s j) #\=))
                  (let ((k (%skip-ws s (1+ j) n)))
                    (if (and (< k n) (member (char s k) '(#\" #\')))
                        (let ((close (or (position (char s k) s :start (1+ k) :end n) n)))
                          (push (cons name (%decode-entities (subseq s (1+ k) close))) attrs)
                          (setf i (min n (1+ close))))
                        (let ((e (%name-end s k n)))
                          (push (cons name (%decode-entities (subseq s k e))) attrs)
                          (setf i e))))
                  (progn (push (cons name "") attrs) (setf i j)))))))
    (values (nreverse attrs) i)))

(defun parse-svg (source)
  "Parse SOURCE (an XML/SVG string) into an SVG DOM tree.  Returns the root
   element (the outermost element — typically <svg>), or NIL."
  (let* ((s source) (n (length s)) (i 0) (root nil) (stack '()))
    (labels ((cur () (first stack))
             (add-text (str)
               (when (and (cur) (plusp (length str)))
                 (let ((d (%decode-entities str)))
                   (when (some (lambda (c) (not (member c '(#\Space #\Tab #\Newline #\Return)))) d)
                     (setf (svg-node-text (cur)) (concatenate 'string (or (svg-node-text (cur)) "") d)))))))
      (loop while (< i n) do
        (let ((lt (position #\< s :start i)))
          (when (null lt) (add-text (subseq s i n)) (return))
          (when (> lt i) (add-text (subseq s i lt)))
          (setf i lt)
          (cond
            ;; comment
            ((and (<= (+ i 4) n) (string= (subseq s i (+ i 4)) "<!--"))
             (let ((e (search "-->" s :start2 (+ i 4)))) (setf i (if e (+ e 3) n))))
            ;; CDATA
            ((and (<= (+ i 9) n) (string= (subseq s i (+ i 9)) "<![CDATA["))
             (let ((e (search "]]>" s :start2 (+ i 9))))
               (when (and e (cur)) (add-text (subseq s (+ i 9) e)))
               (setf i (if e (+ e 3) n))))
            ;; doctype / other declarations
            ((and (< (1+ i) n) (char= (char s (1+ i)) #\!))
             (let ((e (position #\> s :start i))) (setf i (if e (1+ e) n))))
            ;; processing instruction
            ((and (< (1+ i) n) (char= (char s (1+ i)) #\?))
             (let ((e (search "?>" s :start2 i))) (setf i (if e (+ e 2) n))))
            ;; end tag
            ((and (< (1+ i) n) (char= (char s (1+ i)) #\/))
             (let ((e (position #\> s :start i)))
               (when stack (pop stack))
               (setf i (if e (1+ e) n))))
            ;; start tag
            (t
             (let* ((ns (%name-end s (1+ i) n))
                    (name (subseq s (1+ i) ns)))
               (if (zerop (length name))
                   (setf i (1+ i))                       ; stray '<': resync
                   (multiple-value-bind (attrs j) (%parse-attrs s ns n)
                     (let ((node (make-svg-node name attrs))
                           (self (and (< j n) (char= (char s j) #\/))))
                       (if (cur) (append-child (cur) node) (setf root node))
                       (unless self (push node stack))
                       ;; advance past '>'
                       (let ((e (position #\> s :start j))) (setf i (if e (1+ e) n))))))))))))
    root))
