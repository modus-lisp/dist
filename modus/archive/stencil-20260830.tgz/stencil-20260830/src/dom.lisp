;;;; dom.lisp — the SVG DOM node kernel.
;;;;
;;;; A small element tree (element name, attribute alist, ordered children, and
;;;; text for text-bearing nodes).  A host (weft) binds JS SVG* interfaces onto
;;;; these nodes; the renderer walks them directly.  Names are lowercased; the
;;;; `xlink:` / `xml:` prefixes on attributes are kept verbatim.
(in-package #:stencil)

(defstruct (svg-node (:constructor %make-svg-node))
  (name "")                                          ; lowercased element/tag name
  (attrs nil)                                        ; alist (name . value), names lowercased
  (children (make-array 0 :adjustable t :fill-pointer 0))
  (text nil)                                         ; accumulated character data (for <text>/<tspan>)
  (parent nil))

(defun make-svg-node (name &optional attrs)
  (%make-svg-node :name (string-downcase name) :attrs attrs))

(defun attr (node name &optional default)
  "The value of attribute NAME on NODE (case-insensitive), or DEFAULT."
  (or (cdr (assoc name (svg-node-attrs node) :test #'string-equal)) default))

(defun append-child (parent child)
  (setf (svg-node-parent child) parent)
  (vector-push-extend child (svg-node-children parent))
  child)

(defun map-tree (fn node)
  "Call FN on NODE and every descendant, in document order."
  (funcall fn node)
  (loop for c across (svg-node-children node) do (map-tree fn c)))

(defun get-element-by-id (root id)
  "The first node under ROOT whose id attribute equals ID, or NIL."
  (map-tree (lambda (n) (when (string= (or (attr n "id") "") id)
                          (return-from get-element-by-id n)))
            root)
  nil)

(defun elements-by-tag (root name)
  "All nodes under ROOT whose name is NAME (lowercased), in document order."
  (let ((out '()) (nm (string-downcase name)))
    (map-tree (lambda (n) (when (string= (svg-node-name n) nm) (push n out))) root)
    (nreverse out)))
