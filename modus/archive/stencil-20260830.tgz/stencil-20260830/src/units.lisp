;;;; units.lisp — parse SVG attribute values (numbers, lengths, colors, transforms).
(in-package #:stencil)

(defun %number-at (s i n)
  "Read a number token starting at I (after separators).  Returns (values value
   end) or (values nil i) if none."
  (let ((start i))
    (when (and (< i n) (member (char s i) '(#\+ #\-))) (incf i))
    (let ((digits nil))
      (loop while (and (< i n) (digit-char-p (char s i))) do (incf i) (setf digits t))
      (when (and (< i n) (char= (char s i) #\.))
        (incf i)
        (loop while (and (< i n) (digit-char-p (char s i))) do (incf i) (setf digits t)))
      ;; An `e' only begins an EXPONENT if digits actually follow it (after an optional
      ;; sign).  Without that lookahead "1em" consumed the "e", read-from-string choked
      ;; on "1e", and the whole length fell back to its default — so every em/ex length
      ;; was zero long before the unit was ever looked at, and adding em support to
      ;; PARSE-LENGTH changed nothing at all until this was fixed too.
      (when (and (< i n) (member (char s i) '(#\e #\E)) digits)
        (let ((j (1+ i)))
          (when (and (< j n) (member (char s j) '(#\+ #\-))) (incf j))
          (when (and (< j n) (digit-char-p (char s j)))
            (setf i j)
            (loop while (and (< i n) (digit-char-p (char s i))) do (incf i)))))
      (if digits
          (values (let ((*read-default-float-format* 'double-float))
                    (ignore-errors (coerce (read-from-string (subseq s start i)) 'double-float)))
                  i)
          (values nil start)))))

(defun parse-numbers (s)
  "Every number in S (whitespace/comma separated) as a list of double-floats."
  (when s
    (let ((n (length s)) (i 0) (out '()))
      (loop
        (loop while (and (< i n) (member (char s i) '(#\Space #\Tab #\Newline #\Return #\,))) do (incf i))
        (when (>= i n) (return))
        (multiple-value-bind (v e) (%number-at s i n)
          (if v (progn (push v out) (setf i e)) (incf i))))
      (nreverse out))))

(defun parse-number (s &optional (default 0d0))
  (or (first (parse-numbers s)) default))

;;; ---- the context a length is resolved against -----------------------------
;;;
;;; A CSS length is not a number: `1em' is a font size away from a value and `1vmin'
;;; is a viewport away.  These carry that context, as specials rather than as an
;;; argument, because PARSE-LENGTH is called from shape emission that never had a
;;; pstate threaded through it and adding one would touch every shape.

(defvar *font-size* 16d0
  "The computed font-size in user units, for em/ex/ch/ic/lh.")
(defvar *root-font-size* 16d0
  "The root element's font-size, for rem/rlh.")
(defvar *viewport-width* 0d0)
(defvar *viewport-height* 0d0)

(defun %length-unit (str)
  "The unit suffix of length STR, downcased, or \"\" for a plain number.  Taken from
   the END, which is the entire point: the old code asked (SEARCH \"in\" STR), so
   `1vmin' contained \"in\" and was silently read as ONE INCH — 96 user units instead
   of a fraction of the viewport."
  (let ((end (length str)))
    (loop while (and (plusp end)
                     (let ((c (char str (1- end))))
                       (or (alpha-char-p c) (char= c #\%))))
          do (decf end))
    (string-downcase (subseq str end))))

(defun parse-length (s &optional (default 0d0) (percent-basis nil))
  "A length as user units.  Absolute units are at 96dpi; font-relative units resolve
   against *FONT-SIZE* / *ROOT-FONT-SIZE* and viewport units against *VIEWPORT-WIDTH*
   and *VIEWPORT-HEIGHT*; a trailing % uses PERCENT-BASIS when one is given.

   ex/ch/ic are APPROXIMATED as fractions of the font size rather than measured from
   the face (x-height, the advance of `0', the advance of U+6C34).  That is a real
   difference from a browser and the corpus can see it; it is here because the wrong
   answer before was to treat `1ex' as ONE USER UNIT, which is not close to anything."
  (if (or (null s) (zerop (length s))) default
      (let* ((str (string-trim " " s))
             (v (parse-number str default))
             (u (%length-unit str))
             (vmin (min *viewport-width* *viewport-height*))
             (vmax (max *viewport-width* *viewport-height*)))
        (cond
          ((string= u "") v)
          ((string= u "px") v)
          ((string= u "%") (if percent-basis (* percent-basis (/ v 100d0)) v))
          ;; font-relative
          ((string= u "em") (* v *font-size*))
          ((string= u "rem") (* v *root-font-size*))
          ((string= u "ex") (* v 0.5d0 *font-size*))
          ((string= u "ch") (* v 0.5d0 *font-size*))
          ((string= u "ic") (* v *font-size*))
          ((string= u "lh") (* v 1.2d0 *font-size*))
          ((string= u "rlh") (* v 1.2d0 *root-font-size*))
          ;; viewport-relative
          ((string= u "vw") (* v (/ *viewport-width* 100d0)))
          ((string= u "vh") (* v (/ *viewport-height* 100d0)))
          ((string= u "vmin") (* v (/ vmin 100d0)))
          ((string= u "vmax") (* v (/ vmax 100d0)))
          ((or (string= u "vi") (string= u "vb"))
           ;; Inline/block axes of a horizontal-tb root: vi is the width, vb the height.
           (* v (/ (if (string= u "vi") *viewport-width* *viewport-height*) 100d0)))
          ;; absolute, at 96dpi
          ((string= u "pt") (* v 96d0 (/ 1d0 72d0)))
          ((string= u "pc") (* v 16d0))
          ((string= u "mm") (* v 96d0 (/ 1d0 25.4d0)))
          ((string= u "cm") (* v 96d0 (/ 1d0 2.54d0)))
          ((string= u "q")  (* v 96d0 (/ 1d0 101.6d0)))   ; a quarter-millimetre
          ((string= u "in") (* v 96d0))
          ;; AN UNKNOWN UNIT IS AN INVALID LENGTH, not a bare number: `10foo' must not
          ;; quietly become 10.  SVG treats an unparseable attribute as absent, which
          ;; is what DEFAULT is.
          (t default)))))

(defun parse-viewbox (s)
  "A viewBox \"minx miny w h\" as (list minx miny w h) doubles, or NIL."
  (let ((nums (parse-numbers s))) (when (>= (length nums) 4) (subseq nums 0 4))))

;;; ---- colors ---------------------------------------------------------------
(defparameter *svg-colors*
  ;; ALL of the CSS/SVG colour keywords.  This list was 27 of them, and an unrecognised
  ;; name does NOT fall back to black: PARSE-COLOR returns NIL, %RESOLVE-PAINT turns
  ;; that into :NONE, and the shape is painted with nothing at all.  So every SVG
  ;; naming one of the 120 missing colours lost that fill or stroke ENTIRELY, and in
  ;; silence -- found as a stroke="darkblue" outline that was simply not in the output.
  '(("aliceblue" 240 248 255) ("antiquewhite" 250 235 215) ("aqua" 0 255 255)
    ("aquamarine" 127 255 212) ("azure" 240 255 255) ("beige" 245 245 220)
    ("bisque" 255 228 196) ("black" 0 0 0) ("blanchedalmond" 255 235 205) ("blue" 0 0 255)
    ("blueviolet" 138 43 226) ("brown" 165 42 42) ("burlywood" 222 184 135)
    ("cadetblue" 95 158 160) ("chartreuse" 127 255 0) ("chocolate" 210 105 30)
    ("coral" 255 127 80) ("cornflowerblue" 100 149 237) ("cornsilk" 255 248 220)
    ("crimson" 220 20 60) ("cyan" 0 255 255) ("darkblue" 0 0 139) ("darkcyan" 0 139 139)
    ("darkgoldenrod" 184 134 11) ("darkgray" 169 169 169) ("darkgreen" 0 100 0)
    ("darkgrey" 169 169 169) ("darkkhaki" 189 183 107) ("darkmagenta" 139 0 139)
    ("darkolivegreen" 85 107 47) ("darkorange" 255 140 0) ("darkorchid" 153 50 204)
    ("darkred" 139 0 0) ("darksalmon" 233 150 122) ("darkseagreen" 143 188 143)
    ("darkslateblue" 72 61 139) ("darkslategray" 47 79 79) ("darkslategrey" 47 79 79)
    ("darkturquoise" 0 206 209) ("darkviolet" 148 0 211) ("deeppink" 255 20 147)
    ("deepskyblue" 0 191 255) ("dimgray" 105 105 105) ("dimgrey" 105 105 105)
    ("dodgerblue" 30 144 255) ("firebrick" 178 34 34) ("floralwhite" 255 250 240)
    ("forestgreen" 34 139 34) ("fuchsia" 255 0 255) ("gainsboro" 220 220 220)
    ("ghostwhite" 248 248 255) ("gold" 255 215 0) ("goldenrod" 218 165 32)
    ("gray" 128 128 128) ("green" 0 128 0) ("greenyellow" 173 255 47) ("grey" 128 128 128)
    ("honeydew" 240 255 240) ("hotpink" 255 105 180) ("indianred" 205 92 92)
    ("indigo" 75 0 130) ("ivory" 255 255 240) ("khaki" 240 230 140) ("lavender" 230 230 250)
    ("lavenderblush" 255 240 245) ("lawngreen" 124 252 0) ("lemonchiffon" 255 250 205)
    ("lightblue" 173 216 230) ("lightcoral" 240 128 128) ("lightcyan" 224 255 255)
    ("lightgoldenrodyellow" 250 250 210) ("lightgray" 211 211 211) ("lightgreen" 144 238 144)
    ("lightgrey" 211 211 211) ("lightpink" 255 182 193) ("lightsalmon" 255 160 122)
    ("lightseagreen" 32 178 170) ("lightskyblue" 135 206 250) ("lightslategray" 119 136 153)
    ("lightslategrey" 119 136 153) ("lightsteelblue" 176 196 222) ("lightyellow" 255 255 224)
    ("lime" 0 255 0) ("limegreen" 50 205 50) ("linen" 250 240 230) ("magenta" 255 0 255)
    ("maroon" 128 0 0) ("mediumaquamarine" 102 205 170) ("mediumblue" 0 0 205)
    ("mediumorchid" 186 85 211) ("mediumpurple" 147 112 219) ("mediumseagreen" 60 179 113)
    ("mediumslateblue" 123 104 238) ("mediumspringgreen" 0 250 154)
    ("mediumturquoise" 72 209 204) ("mediumvioletred" 199 21 133) ("midnightblue" 25 25 112)
    ("mintcream" 245 255 250) ("mistyrose" 255 228 225) ("moccasin" 255 228 181)
    ("navajowhite" 255 222 173) ("navy" 0 0 128) ("oldlace" 253 245 230) ("olive" 128 128 0)
    ("olivedrab" 107 142 35) ("orange" 255 165 0) ("orangered" 255 69 0)
    ("orchid" 218 112 214) ("palegoldenrod" 238 232 170) ("palegreen" 152 251 152)
    ("paleturquoise" 175 238 238) ("palevioletred" 219 112 147) ("papayawhip" 255 239 213)
    ("peachpuff" 255 218 185) ("peru" 205 133 63) ("pink" 255 192 203) ("plum" 221 160 221)
    ("powderblue" 176 224 230) ("purple" 128 0 128) ("rebeccapurple" 102 51 153)
    ("red" 255 0 0) ("rosybrown" 188 143 143) ("royalblue" 65 105 225)
    ("saddlebrown" 139 69 19) ("salmon" 250 128 114) ("sandybrown" 244 164 96)
    ("seagreen" 46 139 87) ("seashell" 255 245 238) ("sienna" 160 82 45)
    ("silver" 192 192 192) ("skyblue" 135 206 235) ("slateblue" 106 90 205)
    ("slategray" 112 128 144) ("slategrey" 112 128 144) ("snow" 255 250 250)
    ("springgreen" 0 255 127) ("steelblue" 70 130 180) ("tan" 210 180 140) ("teal" 0 128 128)
    ("thistle" 216 191 216) ("tomato" 255 99 71) ("turquoise" 64 224 208)
    ("violet" 238 130 238) ("wheat" 245 222 179) ("white" 255 255 255)
    ("whitesmoke" 245 245 245) ("yellow" 255 255 0) ("yellowgreen" 154 205 50)))

(defun %hex-val (s i k) (ignore-errors (parse-integer s :start i :end (+ i k) :radix 16)))

(defun parse-color (s)
  "Parse an SVG paint value.  Returns an (r g b) list, :none for none/transparent,
   or NIL when unrecognized (caller applies its default)."
  (when (and s (plusp (length s)))
    (let ((str (string-trim '(#\Space #\Tab #\Newline #\Return) (string-downcase s))))
      (cond
        ((or (string= str "none") (string= str "transparent")) :none)
        ((and (> (length str) 0) (char= (char str 0) #\#))
         (case (- (length str) 1)
           (3 (let ((r (%hex-val str 1 1)) (g (%hex-val str 2 1)) (b (%hex-val str 3 1)))
                (when (and r g b) (list (* r 17) (* g 17) (* b 17)))))
           ((6 8) (let ((r (%hex-val str 1 2)) (g (%hex-val str 3 2)) (b (%hex-val str 5 2)))
                    (when (and r g b) (list r g b))))
           (t nil)))
        ((and (>= (length str) 4) (string= (subseq str 0 4) "rgb("))
         (let ((nums (parse-numbers str)))
           (when (>= (length nums) 3)
             (mapcar (lambda (x) (max 0 (min 255 (round x)))) (subseq nums 0 3)))))
        (t (let ((row (assoc str *svg-colors* :test #'string=)))
             (when row (rest row))))))))

;;; ---- transforms -----------------------------------------------------------
(defun parse-transform (s)
  "Parse an SVG transform list into a gesso matrix (identity if none/empty)."
  (if (or (null s) (zerop (length s))) (g:mat-identity)
      (let ((m (g:mat-identity)) (i 0) (n (length s)))
        (loop
          (loop while (and (< i n) (member (char s i) '(#\Space #\Tab #\Newline #\Return #\,))) do (incf i))
          (when (>= i n) (return))
          (let ((op-end (position #\( s :start i)))
            (when (null op-end) (return))
            (let* ((op (string-trim " " (subseq s i op-end)))
                   (close (or (position #\) s :start op-end) n))
                   (args (parse-numbers (subseq s (1+ op-end) close)))
                   (local
                     (cond
                       ((string= op "translate")
                        (g:mat-translate (or (first args) 0d0) (or (second args) 0d0)))
                       ((string= op "scale")
                        (g:mat-scale (or (first args) 1d0) (or (second args) (or (first args) 1d0))))
                       ((string= op "rotate")
                        (if (>= (length args) 3)
                            (g:mat-mul (g:mat-mul (g:mat-translate (second args) (third args))
                                                  (g:mat-rotate (* (first args) (/ pi 180d0))))
                                       (g:mat-translate (- (second args)) (- (third args))))
                            (g:mat-rotate (* (or (first args) 0d0) (/ pi 180d0)))))
                       ((string= op "matrix")
                        (if (>= (length args) 6) (subseq args 0 6) (g:mat-identity)))
                       ((string= op "skewx")
                        (list 1d0 0d0 (tan (* (or (first args) 0d0) (/ pi 180d0))) 1d0 0d0 0d0))
                       ((string= op "skewy")
                        (list 1d0 (tan (* (or (first args) 0d0) (/ pi 180d0))) 0d0 1d0 0d0 0d0))
                       (t (g:mat-identity)))))
              (setf m (g:mat-mul m local))
              (setf i (1+ close)))))
        m)))
