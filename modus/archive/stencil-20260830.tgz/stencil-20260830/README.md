# stencil

**SVG in pure Common Lisp.** Clean-room — no FFI, no librsvg, no Cairo. A stencil
is a cut sheet you paint through; this one turns SVG markup into pixels.

stencil parses SVG, builds an SVG DOM, and renders shapes, paths and text by
painting through [`gesso`](../gesso) (2D vector graphics), which composites on
[`scribe`](../scribe)'s analytic rasterizer.

```
scribe  (font + raster + compositing)
   |
 gesso  (2D vector graphics)
   |
stencil (SVG parse + DOM + render)   <-- you are here
```

## Layering

stencil depends only on gesso (and, transitively, scribe). It owns the SVG
concerns; a host (weft) binds JavaScript SVG DOM interfaces onto stencil nodes
and places rendered SVG into page layout.

- **`parse-svg`** — a small, recovering XML parser → SVG DOM.
- **SVG DOM** — `svg-node` (name, attribute alist, ordered children, text) plus
  `get-element-by-id` / `elements-by-tag` / `map-tree`.
- **attribute parsers** — lengths, numbers, colors, `viewBox`, `transform`.
- **path data** — the `d` grammar (M/L/H/V/C/S/Q/T/A/Z, absolute + relative,
  implicit repeats, smooth reflection, elliptical arcs) driven onto a gesso path.
- **render** — basic shapes (`rect` `circle` `ellipse` `line` `polyline`
  `polygon` `path`) and `<text>`/`<tspan>`, with inherited presentation
  attributes (`fill` `stroke` `stroke-width` `opacity` `font-size`), element
  `transform`, and `viewBox` fitting.

## What works (first slice)

- Parse SVG markup to a DOM, with entity decoding and comment/PI/doctype/CDATA
  handling.
- Render the seven basic shapes and full path data through gesso's fill + stroke.
- `<text>`/`<tspan>` shaped by scribe via `gesso:fill-text`.
- Presentation attributes (inline `style` and attribute forms), inheritance,
  `transform`, and `viewBox`-to-viewport scaling.
- Self-test (`inspect/self-test.lisp`): 19 checks green — DOM queries, every
  attribute parser, shape/path/text rendering, viewBox scaling.

## Deferred

- Gradients, patterns, filters, clipping, masking, markers (parsed and skipped
  today — they need gesso paint sources / clip support first).
- `preserveAspectRatio` (currently a plain non-uniform fit), `use`/`symbol`
  references, nested-svg coordinate systems.
- SMIL animation and CSS animation.
- Text layout beyond a single positioned run (`textAnchor`, `textLength`,
  `dx`/`dy` arrays, `textPath`).

## Host integration (weft)

- **Inline `<svg>`** in HTML flow: weft lays out the element box, then calls
  `render-svg-to-canvas` with that box as the viewport, painting onto the page
  canvas.
- **`<img src=*.svg>`**: fetch, `render-svg` at the image box size.
- **SVG DOM in JS**: weft wraps stencil nodes as `SVGSVGElement` /
  `SVGRectElement` / `SVGTextContentElement` … and `iframe.getSVGDocument()`
  returns the document. See `docs/SVG.md` for the interface map (and how it
  clears Acid3 74/75/77).

## Run the tests

```
sbcl --script inspect/self-test.lisp
```

Pure Common Lisp. No FFI.
