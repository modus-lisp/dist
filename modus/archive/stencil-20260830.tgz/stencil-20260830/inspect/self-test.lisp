;;;; self-test.lisp — exercises the stencil parse -> DOM -> render pipeline.
;;;;   sbcl --script inspect/self-test.lisp
(require :asdf)
;; EVERY sibling, not three by name.  This listed stencil, gesso and scribe; scribe later
;; grew a brotli-pure dependency, and from that day `sbcl --script inspect/self-test.lisp'
;; — the command in the README — died inside ASDF before the first check ran, while the
;; README went on reporting the checks green.  A registry that names its dependencies one
;; at a time breaks the next time somebody adds one, and it breaks SILENTLY, because a
;; test suite that will not start looks a lot like a test suite with nothing to say.
(let ((here (directory-namestring *load-truename*)))
  (push (truename (merge-pathnames "../" here)) asdf:*central-registry*)
  (dolist (d (directory (merge-pathnames "../../*/" here)))
    (push d asdf:*central-registry*)))
(asdf:load-system "stencil")
(defpackage #:stencil.self-test (:use #:cl) (:local-nicknames (#:st #:stencil) (#:g #:gesso) (#:s #:scribe)))
(in-package #:stencil.self-test)

(defvar *pass* 0) (defvar *fail* 0)
(defun ok (label test) (if test (incf *pass*) (progn (incf *fail*) (format t "~&FAIL ~a~%" label))))
(defun near (a b &optional (tol 16)) (<= (abs (- a b)) tol))
(defun cnear (c want) (every #'near c want))
(defun px (ctx x y)
  (let* ((cv (g:context-canvas ctx)) (w (s:canvas-width cv)) (p (s:canvas-pixels cv)) (i (* 3 (+ (* y w) x))))
    (list (aref p i) (aref p (+ i 1)) (aref p (+ i 2)))))
(defun ink (ctx)
  (let* ((p (s:canvas-pixels (g:context-canvas ctx))) (n 0))
    (loop for i from 0 below (length p) by 3
          unless (and (= (aref p i) 255) (= (aref p (+ i 1)) 255) (= (aref p (+ i 2)) 255)) do (incf n))
    n))

;;; ---- XML parse + SVG DOM --------------------------------------------------
(let ((root (st:parse-svg "<svg width='100' height='60' viewBox='0 0 100 60'>
   <rect id='bg' x='0' y='0' width='100' height='60' fill='#eef'/>
   <g fill='red'><circle cx='30' cy='30' r='10'/><rect x='50' y='20' width='20' height='20'/></g>
   <text x='5' y='50' font-size='14'>Hi</text></svg>")))
  (ok "parse root is svg" (string= (st:svg-node-name root) "svg"))
  (ok "attr read" (string= (st:attr root "width") "100"))
  (ok "get-element-by-id" (string= (st:svg-node-name (st:get-element-by-id root "bg")) "rect"))
  (ok "elements-by-tag counts rects" (= 2 (length (st:elements-by-tag root "rect"))))
  (ok "text content captured"
      (let ((tx (first (st:elements-by-tag root "text")))) (search "Hi" (st:svg-node-text tx)))))

;;; ---- attribute parsers ----------------------------------------------------
(ok "parse-color hex3" (cnear (st:parse-color "#f00") '(255 0 0)))
(ok "parse-color hex6" (cnear (st:parse-color "#0080ff") '(0 128 255)))
(ok "parse-color named" (cnear (st:parse-color "green") '(0 128 0)))
(ok "parse-color none" (eq :none (st:parse-color "none")))
(ok "parse-color rgb()" (cnear (st:parse-color "rgb(10, 20, 30)") '(10 20 30)))
(ok "parse-viewbox" (equal (mapcar #'round (st:parse-viewbox "0 0 100 60")) '(0 0 100 60)))

;;; ---- rendering ------------------------------------------------------------
(let ((ctx (st:render-svg "<svg width='60' height='60'>
   <rect x='10' y='10' width='40' height='40' fill='rgb(0,0,255)'/></svg>")))
  (ok "rect renders fill colour" (cnear (px ctx 30 30) '(0 0 255)))
  (ok "rect leaves margin clear" (cnear (px ctx 2 2) '(255 255 255))))

(let ((ctx (st:render-svg "<svg width='60' height='60'>
   <circle cx='30' cy='30' r='20' fill='red'/></svg>")))
  (ok "circle fills centre" (cnear (px ctx 30 30) '(255 0 0)))
  (ok "circle clear at corner" (cnear (px ctx 3 3) '(255 255 255))))

(let ((ctx (st:render-svg "<svg width='80' height='80'>
   <path d='M10 40 L40 10 L70 40 Z' fill='#008000'/></svg>")))
  (ok "path (triangle) fills interior" (cnear (px ctx 40 35) '(0 128 0))))

(let ((ctx (st:render-svg "<svg width='80' height='40'>
   <path d='M5 20 C5 5 75 5 75 20' stroke='black' stroke-width='3' fill='none'/></svg>")))
  (ok "stroked bezier lays ink" (> (ink ctx) 30)))

(let ((ctx (st:render-svg "<svg width='120' height='40'>
   <text x='4' y='28' font-size='24' fill='black'>Ag</text></svg>")))
  (ok "text renders glyph ink" (> (ink ctx) 40)))

;;; viewBox scaling: a 0..10 box drawn into a 100px canvas fills the interior
(let ((ctx (st:render-svg "<svg width='100' height='100' viewBox='0 0 10 10'>
   <rect x='0' y='0' width='10' height='10' fill='navy'/></svg>")))
  (ok "viewBox scales unit rect to fill" (cnear (px ctx 50 50) '(0 0 128))))

;;; a linear gradient (objectBoundingBox) runs red -> blue across a rect
(let ((ctx (st:render-svg "<svg width='100' height='40'>
   <defs><linearGradient id='g' x1='0' y1='0' x2='1' y2='0'>
     <stop offset='0' stop-color='#ff0000'/><stop offset='1' stop-color='#0000ff'/>
   </linearGradient></defs>
   <rect x='0' y='0' width='100' height='40' fill='url(#g)'/></svg>")))
  (ok "svg linear gradient left stop red"   (and (> (first (px ctx 3 20)) 200) (< (third (px ctx 3 20)) 60)))
  (ok "svg linear gradient right stop blue" (and (< (first (px ctx 97 20)) 60) (> (third (px ctx 97 20)) 200))))

;;; a radial gradient (objectBoundingBox) runs inner -> outer across a circle
(let ((ctx (st:render-svg "<svg width='60' height='60'>
   <defs><radialGradient id='r'>
     <stop offset='0' stop-color='#ffff00'/><stop offset='1' stop-color='#008000'/>
   </radialGradient></defs>
   <circle cx='30' cy='30' r='28' fill='url(#r)'/></svg>")))
  (ok "svg radial gradient centre is inner" (let ((c (px ctx 30 30))) (and (> (first c) 200) (> (second c) 200))))
  (ok "svg radial gradient edge is outer"   (let ((c (px ctx 30 4)))  (and (< (first c) 80) (> (second c) 90)))))

(format t "~&stencil self-test: ~a passed, ~a failed~%" *pass* *fail*)
(when (plusp *fail*) (uiop:quit 1))
