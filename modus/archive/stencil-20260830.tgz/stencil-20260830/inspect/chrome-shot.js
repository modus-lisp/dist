// chrome-shot.js — the REFERENCE half of the Chrome-referenced SVG harness.
//
// stencil's own self-test asks stencil whether stencil agrees with stencil.  That kind of
// test is false-pass dominated: it cannot see a feature that is silently skipped, because
// nothing in it knows what the pixels were supposed to be.  <pattern> was missing for
// months with 23 checks green.  So the grader is a browser: Chromium renders the same SVG
// and ITS pixels are the answer.
//
// EACH TEST IS RENDERED AT ITS OWN INTRINSIC SIZE, and that size is reported back for the
// stencil side to use.  Forcing every test into one box would be wrong for the tests with
// no viewBox: an <img> scaled to 200x200 stretches user units, while a 200x200 stencil
// viewport does not, and the disagreement would be the harness's, not stencil's.
//
// The SVG is loaded as <img src="file://…">, not as a top-level document, because that is
// the shape a host actually asks stencil for (pigment:decode-svg-source, weft's <img>):
// an external image fitted into a box, sized by its own intrinsic size and viewBox.
//
// Manifest in:  <abs-svg-path>\t<out-png>   (one per line, TAB-separated)
// Manifest out (stdout): <abs-svg-path>\t<out-png>\t<width>\t<height>  for each SUCCESS,
// and a line to stderr for each failure — a test that did not render must not be graded,
// because a missing reference compared against anything is a false verdict either way.
//
//   node inspect/chrome-shot.js manifest.tsv > sizes.tsv
const { chromium } = require('/home/claude/pw/node_modules/playwright');
const fs = require('fs');
const os = require('os');
const path = require('path');

// ---- FONTS, and why this is not optional ------------------------------------------------
// 379 of the corpus's 1722 tests are text, and until this existed not one of them measured
// anything.  Chromium drew them with the system font stack and stencil with scribe's shipped
// Liberation faces, so EVERY text test differed a little everywhere — the harness's own
// histogram showed one mode straddling the pass/fail cut (45 just inside, 233 just outside,
// 1 beyond 20% wrong), which is the signature of a systematic difference rather than of
// conformance.  A score computed from that is a measurement of the threshold.
//
// The corpus ships the faces its tests name.  With SVG_FONTS_DIR set, Chromium is given a
// fontconfig that can see THOSE AND NOTHING ELSE — no system fallback, because a fallback is
// exactly the silent substitution that makes the comparison meaningless again.  The Lisp side
// points scribe at the same files.  Both then draw `font-family="Noto Sans"' with the same
// bytes, and a difference means a difference.
function fontConfig(dir) {
  const file = path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'svgfc-')), 'fonts.conf');
  fs.writeFileSync(file, `<?xml version="1.0"?>
<!DOCTYPE fontconfig SYSTEM "fonts.dtd">
<fontconfig>
  <dir>${dir}</dir>
  <cachedir>${path.dirname(file)}/cache</cachedir>
  <!-- HINTING OFF, and this is the second half of making text comparable.  Chromium hints
       glyphs through fontconfig, nudging stems onto the pixel grid, while scribe
       rasterizes the outline as drawn; the same face hinted and unhinted differs by a
       pixel here and there on every glyph.  MEASURED, both ways, with everything else
       held fixed: 103/379 with hinting on, 126/379 with it off.  (An earlier version of
       this comment asserted the same thing off a measurement taken while the Lisp side
       was silently loading NO font at all, which proved nothing whatever.) -->
  <match target="font">
    <edit name="hinting" mode="assign"><bool>false</bool></edit>
    <edit name="hintstyle" mode="assign"><const>hintnone</const></edit>
    <edit name="autohint" mode="assign"><bool>false</bool></edit>
    <edit name="antialias" mode="assign"><bool>true</bool></edit>
  </match>
  <!-- The generic families resolve inside the corpus too, so a test naming sans-serif
       gets the corpus's sans and not whatever the box happens to have. -->
  <match target="pattern"><test name="family"><string>sans-serif</string></test>
    <edit name="family" mode="assign" binding="same"><string>Noto Sans</string></edit></match>
  <match target="pattern"><test name="family"><string>serif</string></test>
    <edit name="family" mode="assign" binding="same"><string>Noto Serif</string></edit></match>
  <match target="pattern"><test name="family"><string>monospace</string></test>
    <edit name="family" mode="assign" binding="same"><string>Noto Mono</string></edit></match>
</fontconfig>
`);
  return file;
}
if (process.env.SVG_FONTS_DIR) {
  process.env.FONTCONFIG_FILE = fontConfig(process.env.SVG_FONTS_DIR);
  process.stderr.write(`chrome-shot: fonts from ${process.env.SVG_FONTS_DIR}\n`);
}

const entries = fs.readFileSync(process.argv[2], 'utf-8')
  .split('\n').map(s => s.trim()).filter(Boolean)
  .map(line => { const [svg, out] = line.split('\t'); return { svg, out }; });

// A cap, because an intrinsic size comes from the file and the file is not ours: a test
// declaring width="100000" would otherwise ask Chromium for a 10-gigapixel screenshot.
const MAX = 2000;

// THE SIZE IS COMPUTED HERE AND IMPOSED ON BOTH SIDES, rather than read back from the <img>.
// An SVG with a viewBox and no width/height has no intrinsic SIZE at all — only a ratio —
// and Chromium answers naturalWidth 0 for it, which is most of this corpus (133 of 133 in
// the first shapes run).  Reading it back also lets one renderer's sizing bug decide the
// geometry the other is graded on; imposing it means both draw into the same box and the
// comparison is about what is IN the box.  CSS default 300x150 when there is neither.
function svgSize(src) {
  const tag = src.match(/<svg\b[^>]*>/i);
  if (!tag) return null;
  const at = (n) => {
    const m = tag[0].match(new RegExp(`\\b${n}\\s*=\\s*["']([^"']*)["']`, 'i'));
    return m ? m[1].trim() : null;
  };
  // A percentage is a fraction of a viewport we do not have, so it is not a size.
  const px = (v) => {
    if (!v || v.endsWith('%')) return null;
    const n = parseFloat(v);
    return Number.isFinite(n) && n > 0 ? n : null;
  };
  const w = px(at('width')), h = px(at('height'));
  if (w && h) return { w: Math.ceil(w), h: Math.ceil(h) };
  const vb = at('viewBox');
  if (vb) {
    const p = vb.split(/[\s,]+/).map(parseFloat);
    if (p.length === 4 && p[2] > 0 && p[3] > 0) {
      // One given dimension still wins; the viewBox supplies only the one that is missing.
      const ratio = p[2] / p[3];
      if (w) return { w: Math.ceil(w), h: Math.ceil(w / ratio) };
      if (h) return { w: Math.ceil(h * ratio), h: Math.ceil(h) };
      return { w: Math.ceil(p[2]), h: Math.ceil(p[3]) };
    }
  }
  return { w: w || 300, h: h || 150 };
}

(async () => {
  const browser = await chromium.launch({
    executablePath: '/home/claude/.cache/ms-playwright/chromium-1148/chrome-linux/chrome',
    // srgb + no LCD text: the same two flags the weft harness uses, for the same reason —
    // colour management and subpixel antialiasing are per-machine, and a grader that moves
    // between machines is not a grader.
    // allow-file-access-from-files: the corpus has tests whose <image href> or <use href>
    // names a sibling file, and without it those load nothing and the reference is a
    // rendering of the failure rather than of the test.
    args: ['--force-color-profile=srgb', '--disable-lcd-text',
           '--allow-file-access-from-files'],
  });
  const ctx = await browser.newContext({ deviceScaleFactor: 1 });
  const page = await ctx.newPage();
  let ok = 0, fail = 0;

  for (const { svg, out } of entries) {
    try {
      const size = svgSize(fs.readFileSync(svg, 'utf-8'));
      if (!size) throw new Error('no size and no viewBox');
      const w = Math.min(size.w, MAX), h = Math.min(size.h, MAX);
      // THE SVG IS THE TOP-LEVEL DOCUMENT, not an <img> inside a wrapper page.  The wrapper
      // was the obvious shape and it is the wrong one: a page built with setContent has an
      // opaque origin, so Chromium blocks its file:// subresources and every screenshot came
      // back a 200x200 broken-image icon — a reference that looks like a rendering and is
      // not one.  As a document the SVG fits its viewBox to the viewport, which is the same
      // fit stencil does for an explicit :WIDTH/:HEIGHT, so the two still agree on geometry.
      await page.setViewportSize({ width: w, height: h });
      // encodeURI, because the corpus has files named `invalid-#RRGGBB-1.svg' and a raw #
      // in a file:// URL starts a FRAGMENT: Chromium looked for `invalid-' and timed out.
      // Three tests failed that way before this, and a test the reference pass drops is a
      // test the grader never sees — the quietest way for a harness to shrink its corpus.
      await page.goto('file://' + encodeURI(svg).replace(/#/g, '%23'),
                      { waitUntil: 'load', timeout: 20000 });
      // WHITE, and stated rather than assumed: an SVG document has a transparent backdrop,
      // the stencil side composites its alpha onto white, and comparing two images with
      // different backings compares the backings.  omitBackground:false is that white.
      await page.screenshot({ path: out, omitBackground: false,
                              clip: { x: 0, y: 0, width: w, height: h } });
      process.stdout.write(`${svg}\t${out}\t${w}\t${h}\n`);
      ok++;
    } catch (e) {
      process.stderr.write(`REF-FAIL\t${svg}\t${e.message}\n`);
      fail++;
    }
  }
  await browser.close();
  process.stderr.write(`chrome-shot: ${ok} rendered, ${fail} failed\n`);
})();
