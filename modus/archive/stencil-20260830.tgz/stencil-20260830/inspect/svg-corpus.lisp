;;;; svg-corpus.lisp — the STENCIL half of the Chrome-referenced SVG harness, and the grader.
;;;;
;;;; inspect/chrome-shot.js renders each test in Chromium and reports the size it used.
;;;; This renders the same file through stencil at the same size, composites both onto the
;;;; same white, and compares pixels.  Chromium's are the answer; ours are the guess.
;;;;
;;;; WHY PIXELS AND NOT A CHECKLIST.  A renderer's failures are mostly SILENT: an unknown
;;;; paint server, an unsupported attribute, a clip that is not applied — none of them
;;;; signal, all of them just draw the wrong thing.  stencil had 23 self-test checks green
;;;; while <pattern> drew nothing at all, because no check knew what the pixels should be.
;;;;
;;;; THE METRIC, and its one honest difficulty.  Two rasterizers never agree on an edge:
;;;; scribe's analytic coverage and Skia's are both right and differ by a few counts along
;;;; every boundary.  So a raw per-pixel diff is dominated by antialiasing and says nothing.
;;;; What a MISSING FEATURE looks like is different in kind: a large area at a large delta.
;;;; So a pixel counts as WRONG only past *DELTA* (a difference no amount of edge treatment
;;;; explains), and a test fails when more than *TOLERANCE* of its pixels are wrong.
;;;;
;;;; Both numbers are printed with every run, and under them a HISTOGRAM of how far each
;;;; test landed from the cut — because the honest worry about a threshold is that it is
;;;; choosing the score.  If the fractions cluster at zero and at large, the cut lies in an
;;;; empty valley and its exact value is nearly irrelevant; if they pile up either side of
;;;; it, the number is the result.  Printing it means nobody has to take that on trust.
;;;;
;;;; Buckets are the corpus's own directories, because they are already a feature map: what
;;;; comes out is not a score but a to-do list ordered by how much of SVG each line is.
;;;;
;;;; WHERE THE ORACLE IS WRONG.  Grading against a browser means inheriting the browser's
;;;; gaps: anything Chromium does not implement, we are marked wrong for implementing.  The
;;;; known case is .svgz — a gzipped SVG, which SVG 1.1 appendix B defines and Chromium will
;;;; not load over file:// without a Content-Encoding header.  stencil renders those two
;;;; tests correctly and scores 0/2 for it; the corpus's OWN reference PNGs (which ship
;;;; beside each .svg and are rendered by resvg) show the picture stencil draws.
;;;;
;;;; So when a failure looks like it might be ours-is-right, open the corpus's shipped
;;;; reference next to Chromium's.  Disagreement between those two is the tell, and it costs
;;;; one look at a PNG.
;;;;
;;;;   node inspect/chrome-shot.js man.tsv > sizes.tsv 2> refs.log
;;;;   sbcl --non-interactive --eval '(load "~/quicklisp/setup.lisp")' \
;;;;        --load inspect/svg-corpus.lisp -- sizes.tsv [out-dir]
;;;;
;;;; With OUT-DIR it writes ours/<name>.png and, for every failure, diff/<name>.png — the
;;;; wrong pixels in magenta over a dimmed reference, which is the artefact you actually
;;;; read when deciding what a bucket's failures have in common.

(require :asdf)
(require :sb-posix)
(let ((here (directory-namestring *load-truename*)))
  ;; The SIBLINGS, all of them, and not a hand-listed few: this file's ancestor pushed
  ;; stencil, gesso and scribe by name, and when scribe later grew a brotli-pure dependency
  ;; the documented `sbcl --script inspect/self-test.lisp' stopped working entirely — it
  ;; died in ASDF before the first check, and the README went on claiming the checks were
  ;; green.  A registry that names its dependencies one at a time is a registry that breaks
  ;; the next time somebody adds one.
  (push (truename (merge-pathnames "../../" here)) asdf:*central-registry*)
  (dolist (d (directory (merge-pathnames "../../*/" here)))
    (push d asdf:*central-registry*)))
(handler-bind ((warning #'muffle-warning))
  (let ((*standard-output* (make-broadcast-stream)))
    (asdf:load-system "stencil")
    (asdf:load-system "pigment")            ; PNG decode only — pigment depends on us, not
    (asdf:load-system "zpng")))             ; the other way, so this is an inspect-only edge.

(defpackage #:stencil.corpus
  (:use #:cl) (:local-nicknames (#:st #:stencil) (#:g #:gesso) (#:p #:pigment)))
(in-package #:stencil.corpus)

;;; ---- fonts ----------------------------------------------------------------------------

(defun use-corpus-fonts (dir)
  "Point scribe at the corpus's OWN faces, so stencil draws `font-family=\"Noto Sans\"'
   with the same bytes Chromium does.

   Without this the text bucket measures nothing: Chromium used the system stack and
   scribe its shipped Liberation faces, so all 379 text tests differed a little
   everywhere and the wrong-pixel histogram was one mode sitting on the pass/fail cut —
   45 tests just inside it, 233 just outside, 1 beyond 20% wrong.  Moving the threshold
   would have moved the score by two hundred tests, which is the definition of a number
   that is about the threshold and not about the renderer.

   scribe resolves a CSS family to one of a few FACE KEYS, so this replaces the key
   table rather than adding names: the corpus's tests overwhelmingly ask for Noto Sans,
   and what matters is that both sides agree on the file."
  ;; A TRAILING SLASH, or MERGE-PATHNAMES treats the last component as a FILE NAME and
  ;; resolves every face into the PARENT directory.  Without it scribe found no font,
  ;; drew no text, and the corpus's text bucket went UP by 56 tests — because a blank
  ;; canvas differs from small text by less than the 2% tolerance, while text in the
  ;; wrong face differs by more.  Drawing nothing scored better than drawing badly, and
  ;; it took a diff image to notice.
  (setf scribe::*fonts-dir*
        (pathname (if (char= (char dir (1- (length dir))) #\/) dir
                      (concatenate 'string dir "/"))))
  (setf scribe::*face-files*
        '(((:sans  :regular :roman)  "NotoSans-Regular.ttf")
          ((:sans  :regular :italic) "NotoSans-Italic.ttf")
          ((:sans  :bold    :roman)  "NotoSans-Bold.ttf")
          ((:sans  :bold    :italic) "NotoSans-Bold.ttf")
          ((:serif :regular :roman)  "NotoSerif-Regular.ttf")
          ((:serif :regular :italic) "NotoSerif-Regular.ttf")
          ((:serif :bold    :roman)  "NotoSerif-Regular.ttf")
          ((:serif :bold    :italic) "NotoSerif-Regular.ttf")
          ((:mono  :regular :roman)  "NotoMono-Regular.ttf")
          ((:mono  :regular :italic) "NotoMono-Regular.ttf")
          ((:mono  :bold    :roman)  "NotoMono-Regular.ttf")
          ((:mono  :bold    :italic) "NotoMono-Regular.ttf")))
  ;; The cache is keyed by face key, not by file, so a resolved face from before the
  ;; swap would survive it and quietly keep drawing Liberation.
  (clrhash scribe::*font-cache*)
  ;; AND PROVE IT LOADED.  This is the guard the trailing-slash bug walked straight
  ;; past: scribe answers a failed face with NIL, the text branch quietly draws nothing,
  ;; and a harness that renders no text still produces a number — a better-looking one,
  ;; as it turned out.  A grader must fail loudly when its own setup is wrong, because
  ;; every result after that point is about the setup.
  (let ((face (scribe::%open-face '(:sans :regular :roman))))
    (unless face
      (format *error-output*
              "~&FATAL: no face loaded from ~a — the grader would report a renderer that ~
               draws no text as one that agrees with the reference.~%"
              scribe::*fonts-dir*)
      (finish-output *error-output*)
      (sb-ext:exit :code 3)))
  (format t "~&  fonts: ~a~%" scribe::*fonts-dir*))


;;; ---- the raster decoder stencil cannot depend on --------------------------------------

(defun pigment-decode (bytes)
  "Decode BYTES to (values RGBA W H) with pigment, sniffing the format from the magic
   number.  This is the host half of STENCIL:*IMAGE-DECODER*: pigment depends on
   stencil (it renders SVG through it), so stencil cannot call pigment directly and the
   direction has to be inverted with a hook.  The harness is a host like any other."
  (let ((img (ignore-errors
              (cond ((and (>= (length bytes) 8) (= (aref bytes 0) 137) (= (aref bytes 1) 80))
                     (p:png-decode bytes))
                    ((and (>= (length bytes) 3) (= (aref bytes 0) #xff) (= (aref bytes 1) #xd8))
                     (p:jpeg-decode bytes))
                    ((and (>= (length bytes) 3) (= (aref bytes 0) (char-code #\G))
                          (= (aref bytes 1) (char-code #\I)))
                     (p:gif-decode bytes))
                    ((and (>= (length bytes) 12) (= (aref bytes 0) (char-code #\R))
                          (= (aref bytes 8) (char-code #\W)))
                     (p:webp-to-img bytes))
                    (t nil)))))
    (when img (values (p:img-rgba img) (p:img-w img) (p:img-h img)))))

(setf st:*image-decoder* #'pigment-decode)

;;; ---- the metric -----------------------------------------------------------------------

(defvar *delta* 48
  "Per-channel difference (0-255) past which a pixel is WRONG rather than merely antialiased
   differently.  Two analytic rasterizers disagree by single counts on an edge and by tens
   on a subpixel-wide sliver; nothing about edge treatment moves a channel by 48.")

(defvar *tolerance* 0.02
  "Fraction of a test's pixels that may be wrong before it fails.  Not zero, because edges
   ARE a real fraction of a 200x200 test full of small shapes, and a stroke half a pixel off
   can put a whole outline past *DELTA* without anything being wrong with the feature under
   test.  2% of 200x200 is 800 pixels — far more than an outline, far less than a shape.")

(defun composite-on-white (rgba w h)
  "Straight-alpha RGBA over white, as a (w*h*3) RGB vector.  Both sides land here: comparing
   images with different backings compares the backings."
  (let ((out (make-array (* w h 3) :element-type '(unsigned-byte 8))))
    (dotimes (i (* w h) out)
      (let* ((s (* i 4)) (a (/ (aref rgba (+ s 3)) 255d0)))
        (dotimes (c 3)
          (setf (aref out (+ (* i 3) c))
                (round (+ (* (aref rgba (+ s c)) a) (* 255 (- 1d0 a))))))))))

(defun canvas-on-white (cv w h)
  "A scribe RGBA canvas over white.  Its PIXELS are PREMULTIPLIED and its ALPHA is a separate
   plane (scribe/src/blend.lisp), so over-white is just `px + 255(1-a)' — no unpremultiply,
   and none of the rounding that a trip through straight alpha and back would add."
  (let ((px (scribe:canvas-pixels cv)) (ap (scribe:canvas-alpha cv))
        (out (make-array (* w h 3) :element-type '(unsigned-byte 8))))
    (dotimes (j (* w h) out)
      (let ((a (if ap (aref ap j) 255)) (i3 (* 3 j)))
        (dotimes (c 3)
          (setf (aref out (+ i3 c))
                (min 255 (+ (aref px (+ i3 c)) (round (* 255 (- 255 a)) 255)))))))))

(defun png-rgb (path w h)
  "The PNG at PATH as a (w*h*3) RGB vector composited on white, or NIL if it will not decode
   or is not the size we asked for — a reference of the wrong size is not a reference."
  (let ((img (ignore-errors (p:png-decode (read-file-bytes path)))))
    (when (and img (= (p:img-w img) w) (= (p:img-h img) h))
      (composite-on-white (p:img-rgba img) w h))))

(defun read-file-bytes (path)
  (with-open-file (s path :element-type '(unsigned-byte 8))
    (let ((b (make-array (file-length s) :element-type '(unsigned-byte 8))))
      (read-sequence b s) b)))

(defun read-file-string (path)
  (with-open-file (s path :external-format :utf-8)
    (let ((o (make-string (file-length s))))
      (subseq o 0 (read-sequence o s)))))

(defun compare (ours theirs n)
  "Wrong-pixel COUNT and the worst per-channel delta seen, over N pixels."
  (let ((wrong 0) (worst 0))
    (dotimes (i n (values wrong worst))
      (let ((d 0))
        (dotimes (c 3)
          (setf d (max d (abs (- (aref ours (+ (* i 3) c)) (aref theirs (+ (* i 3) c)))))))
        (when (> d worst) (setf worst d))
        (when (> d *delta*) (incf wrong))))))

;;; ---- rendering ------------------------------------------------------------------------

(defvar *render-timeout* 20
  "Seconds a single test may take.  A renderer that does not finish is a failure mode of its
   own — the first run of this harness met one that allocated until the heap died — and one
   test must not be able to take the run down with it.")

(defun stencil-rgb (svg-path w h)
  "Render SVG-PATH through stencil at W x H, composited on white.  Returns a second value
   describing HOW it failed when it does: a renderer that signals, one that runs forever and
   one that draws nothing are three different bugs and must not share a bucket.

   The path is announced on *ERROR-OUTPUT* BEFORE rendering, because the failure that is not
   catchable from inside Lisp — heap exhaustion — is exactly the one where the only thing
   you want to know is which file was in the renderer when it happened."
  (format *error-output* "~&AT ~a~%" svg-path)
  (force-output *error-output*)
  (handler-case
      (sb-ext:with-timeout *render-timeout*
      (let* ((src (read-file-string svg-path))
             ;; A RELATIVE href RESOLVES AGAINST THE FILE, so the grader has to say
             ;; where the file was; without this the corpus's ../../../resources/*.png
             ;; images load nothing and the tests fail for the harness's reason.
             (st:*document-directory* (make-pathname :name nil :type nil
                                                     :defaults (pathname svg-path)))
             (root (st:parse-svg src)))
        (if (null root)
            (values nil :parse-failed)
            (let ((cv (scribe:make-rgba-canvas w h)))
              (st:render-svg-to-canvas root :width w :height h :canvas cv)
              (values (canvas-on-white cv w h) nil)))))
    (sb-ext:timeout () (values nil :timeout))
    ;; SERIOUS-CONDITION, not ERROR.  A control stack exhausted by runaway recursion is a
    ;; STORAGE-CONDITION and is NOT an ERROR, so an (error …) clause lets it past: the first
    ;; full run died at test 1304 of 1722 — on structure/use/indirect-recursive-1, which is
    ;; the corpus asking exactly this question — and printed no report at all.  The bug the
    ;; corpus found took the harness with it, which is the one thing a harness must survive.
    (serious-condition (e) (values nil (format nil "~a" (type-of e))))))

;;; ---- output ---------------------------------------------------------------------------

(defun write-rgb-png (rgb w h path)
  (ensure-directories-exist path)
  (let* ((png (make-instance 'zpng:png :color-type :truecolor :width w :height h))
         (d (zpng:data-array png)))
    (dotimes (y h) (dotimes (x w)
      (let ((i (* 3 (+ x (* y w)))))
        (dotimes (c 3) (setf (aref d y x c) (aref rgb (+ i c)))))))
    (zpng:write-png png path)))

(defun write-diff-png (ours theirs w h path)
  "The reference at half strength with every WRONG pixel in magenta.  The point is to be
   readable at a glance: you are looking for the SHAPE of the disagreement, because that is
   what says whether a bucket's failures are one missing feature or twenty small ones."
  (let ((rgb (make-array (* w h 3) :element-type '(unsigned-byte 8))))
    (dotimes (i (* w h))
      (let ((d 0))
        (dotimes (c 3)
          (setf d (max d (abs (- (aref ours (+ (* i 3) c)) (aref theirs (+ (* i 3) c)))))))
        (if (> d *delta*)
            (setf (aref rgb (* i 3)) 255 (aref rgb (+ (* i 3) 1)) 0 (aref rgb (+ (* i 3) 2)) 255)
            (dotimes (c 3)
              (setf (aref rgb (+ (* i 3) c))
                    (min 255 (round (+ 128 (/ (aref theirs (+ (* i 3) c)) 2)))))))))
    (write-rgb-png rgb w h path)))

;;; ---- the run --------------------------------------------------------------------------

(defstruct result name bucket status wrong total worst)

(defun bucket-of (svg-path root)
  "The corpus directory a test lives in, two deep: `painting/marker'.  These are the corpus's
   own feature map and they are what turns a score into a to-do list."
  (let* ((rel (enough-namestring (truename svg-path) (truename root)))
         (parts (uiop:split-string rel :separator "/")))
    (format nil "~{~a~^/~}" (subseq parts 0 (min 2 (max 1 (1- (length parts))))))))

(defun run (sizes-tsv &optional out-dir corpus-root)
  ;; An empty OUT-DIR is NO out-dir, not the current one.  Passing "" to skip the PNGs made
  ;; MERGE-PATHNAMES relative to the working directory and wrote 5MB of ours/ and diff/ into
  ;; the repository — a harness that dirties the tree it grades is one `git add .' away from
  ;; committing its own output.
  (when (and out-dir (zerop (length (string out-dir)))) (setf out-dir nil))
  (let ((results '()) (root (or corpus-root (uiop:getcwd))))
    (dolist (line (uiop:split-string (read-file-string sizes-tsv) :separator (string #\Newline)))
      (let ((f (uiop:split-string (string-trim " " line) :separator (string #\Tab))))
        (when (= (length f) 4)
          (destructuring-bind (svg ref ws hs) f
            (let* ((w (parse-integer ws)) (h (parse-integer hs)) (n (* w h))
                   (name (pathname-name svg))
                   (bucket (bucket-of svg root))
                   (theirs (png-rgb ref w h)))
              (multiple-value-bind (ours why) (stencil-rgb svg w h)
                (cond
                  ((null theirs)
                   (push (make-result :name name :bucket bucket :status :no-ref) results))
                  ((null ours)
                   (push (make-result :name name :bucket bucket :status :error
                                      :total n :worst why)
                         results))
                  (t
                   (multiple-value-bind (wrong worst) (compare ours theirs n)
                     (let ((status (if (<= (/ wrong n) *tolerance*) :pass :fail)))
                       (when out-dir
                         (write-rgb-png ours w h
                                        (merge-pathnames (format nil "ours/~a-~a.png"
                                                                 (substitute #\- #\/ bucket) name)
                                                         out-dir))
                         (when (eq status :fail)
                           (write-diff-png ours theirs w h
                                           (merge-pathnames (format nil "diff/~a-~a.png"
                                                                    (substitute #\- #\/ bucket) name)
                                                            out-dir))))
                       (push (make-result :name name :bucket bucket :status status
                                          :wrong wrong :total n :worst worst)
                             results)))))))))))
    (nreverse results)))

(defun report (results)
  (let ((buckets (make-hash-table :test 'equal)))
    (dolist (r results) (push r (gethash (result-bucket r) buckets)))
    (format t "~&~%  metric: a pixel is wrong past a per-channel delta of ~d;~%~
                 ~10ta test fails past ~,1f% of its pixels wrong.~%~%" *delta* (* 100 *tolerance*))
    (format t "  ~40a ~5@a ~6@a ~6@a ~6@a  ~a~%" "bucket" "pass" "fail" "err" "noref" "rate")
    (let ((rows '()))
      (maphash (lambda (b rs)
                 (flet ((n (s) (count s rs :key #'result-status)))
                   (push (list b (n :pass) (n :fail) (n :error) (n :no-ref) (length rs)) rows)))
               buckets)
      (dolist (row (sort rows #'string< :key #'first))
        (destructuring-bind (b pass fail err noref total) row
          (format t "  ~40a ~5d ~6d ~6d ~6d  ~5,1f%~%"
                  b pass fail err noref (if (plusp total) (* 100 (/ pass total)) 0))))
      (let ((pass (count :pass results :key #'result-status))
            (total (length results)))
        (format t "~%  ~40a ~5d / ~d   ~,1f%~%" "TOTAL" pass total
                (if (plusp total) (* 100 (/ pass total)) 0)))))
  (calibration results))

(defun calibration (results)
  "How much work the THRESHOLD is doing.  If wrong-pixel fractions cluster near zero and
   near large, the cut is between two populations and its exact place hardly matters; if
   they pile up just either side of *TOLERANCE*, the number is deciding the score and the
   score is about the number.  Printed every run so that never goes unnoticed."
  (let ((graded (remove-if-not (lambda (r) (member (result-status r) '(:pass :fail))) results))
        (bins '((0 . "        0%") (0.0001 . "  0- 0.1%") (0.001 . "0.1-  1%")
                (0.01 . "  1-  2%") (0.02 . "  2-  5%") (0.05 . "  5- 20%") (0.2 . "   > 20%"))))
    (when graded
      (let* ((counts (loop for (lo . nil) in bins
                           for hi = (or (car (nth (1+ (position lo bins :key #'car)) bins)) 1.1)
                           collect (count-if
                                    (lambda (r)
                                      (let ((f (/ (result-wrong r) (result-total r))))
                                        (if (zerop lo) (zerop f) (and (> f lo) (<= f hi)))))
                                    graded)))
             ;; Scaled to the LARGEST bin, not to a fixed width with a cap.  The first
             ;; version capped bar length at 60 and divided by 2, so every bin over 120
             ;; drew the same full-width bar: 358 and 597 looked equal.  A histogram whose
             ;; tall bars all saturate is not a histogram, it is a row of maxima.
             (peak (max 1 (reduce #'max counts))))
        (format t "~%  wrong-pixel distribution (the cut is at ~,1f%):~%" (* 100 *tolerance*))
        (loop for (nil . label) in bins
              for n in counts
              do (format t "    ~a  ~4d  ~a~%" label n
                         (make-string (round (* 56 n) peak) :initial-element #\#)))))))

(let* ((args (rest (member "--" sb-ext:*posix-argv* :test #'string=)))
       (sizes (first args)) (out (second args)) (root (third args)))
  (unless sizes
    (format t "usage: … --load inspect/svg-corpus.lisp -- <sizes.tsv> [out-dir] [corpus-root]~%")
    (sb-ext:exit :code 2))
  ;; The SAME environment variable the reference pass reads, so the two sides cannot be
  ;; pointed at different fonts by pointing only one of them.
  (let ((fonts (sb-posix:getenv "SVG_FONTS_DIR")))
    (when fonts (use-corpus-fonts fonts)))
  (let ((results (run sizes out root)))
    (report results)
    ;; The failures themselves, so a run is useful without opening the PNGs.
    (format t "~%  worst offenders (most wrong pixels first):~%")
    (dolist (r (subseq (sort (remove :fail results :key #'result-status :test-not #'eq)
                             #'> :key (lambda (r) (/ (result-wrong r) (result-total r))))
                       0 (min 25 (count :fail results :key #'result-status))))
      (format t "    ~5,1f%  ~a/~a~%" (* 100 (/ (result-wrong r) (result-total r)))
              (result-bucket r) (result-name r)))))
