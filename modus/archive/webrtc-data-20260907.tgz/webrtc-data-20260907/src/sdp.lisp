;;;; src/sdp.lisp — the slice of SDP a bundled data-channel + audio session needs.
;;;;
;;;; We parse the remote OFFER (ICE ufrag/pwd, DTLS fingerprint, setup role, candidates, and the
;;;; list of media m-lines) and generate our ANSWER.  Non-trickle: all candidates live in the SDP,
;;;; so signaling is one offer/answer exchange.  Media sections share one bundled ICE/DTLS transport
;;;; (a=group:BUNDLE).  We answer every offered m-line so the m-lines line up (the browser rejects a
;;;; mismatched answer): m=application -> webrtc-datachannel; m=audio -> G.711 PCMU (payload type 0)
;;;; if the offer lists it, else rejected (port 0).

(in-package #:webrtc-data)


(defstruct (sdp-media (:conc-name sdp-media-))
  type mid (pts '()) (sctp-port 5000) (direction "sendrecv") (rtpmap '()))  ; rtpmap: ((pt . "VP8") ...)

(defstruct (sdp-session (:conc-name sdp-))
  ice-ufrag ice-pwd fingerprint setup (candidates '()) (media '()))

(defun %split (line &optional (sep #\Space))
  (loop with s = 0 with out = '() with len = (length line)
        for p = (position sep line :start s)
        do (push (subseq line s (or p len)) out)
           (if p (setf s (1+ p)) (return (nreverse out)))))

(defun %aval (line prefix)
  "If LINE starts with PREFIX, return the rest, else NIL."
  (when (and (>= (length line) (length prefix)) (string= line prefix :end1 (length prefix)))
    (string-trim '(#\Space #\Return) (subseq line (length prefix)))))

(defun parse-candidate (val)
  "candidate foundation component transport priority ip port typ type ..."
  (let ((f (%split val)))
    (make-ice-candidate :foundation (nth 0 f) :component (parse-integer (nth 1 f))
                        :transport (string-downcase (nth 2 f)) :priority (parse-integer (nth 3 f))
                        :ip (nth 4 f) :port (parse-integer (nth 5 f)) :type (nth 7 f))))

(defun parse-sdp (sdp)
  "Parse an offer/answer into an SDP-SESSION.  Session-level ICE/fingerprint/setup are shared
across all bundled m-lines; per-media a=mid / a=sctp-port / direction attach to the current section."
  (let ((s (make-sdp-session)) (cur nil))
    (dolist (raw (%split sdp #\Newline))
      (let ((line (string-trim '(#\Return #\Space) raw)) v)
        (cond
          ((%aval line "m=")                                  ; new media section
           (let* ((f (%split line)) (type (subseq (first f) 2)))
             (setf cur (make-sdp-media
                        :type type
                        :pts (loop for x in (nthcdr 3 f)       ; payload types (RTP media only)
                                   for n = (ignore-errors (parse-integer x)) when n collect n)))
             (push cur (sdp-media s))))
          ((setf v (%aval line "a=ice-ufrag:")) (setf (sdp-ice-ufrag s) v))
          ((setf v (%aval line "a=ice-pwd:")) (setf (sdp-ice-pwd s) v))
          ((setf v (%aval line "a=fingerprint:sha-256 ")) (setf (sdp-fingerprint s) v))
          ((setf v (%aval line "a=setup:")) (setf (sdp-setup s) v))
          ((setf v (%aval line "a=rtpmap:"))                  ; "97 VP8/90000" -> (97 . "VP8")
           (when cur
             (let* ((sp (position #\Space v)) (pt (ignore-errors (parse-integer v :end sp)))
                    (rest (and sp (subseq v (1+ sp))))
                    (slash (and rest (position #\/ rest)))
                    (codec (and rest (subseq rest 0 (or slash (length rest))))))
               (when pt (push (cons pt codec) (sdp-media-rtpmap cur))))))
          ((setf v (%aval line "a=mid:")) (when cur (setf (sdp-media-mid cur) v)))
          ((setf v (%aval line "a=sctp-port:")) (when cur (setf (sdp-media-sctp-port cur) (parse-integer v))))
          ((member line '("a=sendrecv" "a=sendonly" "a=recvonly" "a=inactive") :test #'string=)
           (when cur (setf (sdp-media-direction cur) (subseq line 2))))
          ((setf v (%aval line "a=candidate:")) (push (parse-candidate v) (sdp-candidates s))))))
    (setf (sdp-media s) (nreverse (sdp-media s))
          (sdp-candidates s) (nreverse (sdp-candidates s)))
    s))

;;; Convenience for callers that only care about the data channel.
(defun sdp-mid (s) (let ((m (find "application" (sdp-media s) :key #'sdp-media-type :test #'string=)))
                     (if m (sdp-media-mid m) (and (sdp-media s) (sdp-media-mid (first (sdp-media s)))))))

(defun sdp-media-codec-pt (m codec)
  "The payload type the peer assigned to CODEC (e.g. \"VP8\") in media section M, or NIL.
Payload types are dynamic (96-127) and vary per browser/offer, so we must echo back theirs."
  (car (find codec (sdp-media-rtpmap m) :key #'cdr
             :test (lambda (a b) (and b (string-equal a b))))))

(defun %candidates-block (ip port srflx-ip srflx-port relay-ip relay-port foundation priority)
  (concatenate 'string
    (format nil "a=candidate:~a 1 udp ~d ~a ~d typ host~%" foundation priority ip port)
    (if srflx-ip (format nil "a=candidate:2 1 udp ~d ~a ~d typ srflx raddr ~a rport ~d~%"
                         1694498815 srflx-ip srflx-port ip port) "")
    (if relay-ip (format nil "a=candidate:3 1 udp ~d ~a ~d typ relay raddr ~a rport ~d~%"
                         41885439 relay-ip relay-port (or srflx-ip ip) (or srflx-port port)) "")
    (format nil "a=end-of-candidates~%")))

(defun make-answer-sdp (&key ice-ufrag ice-pwd fingerprint ip port srflx-ip srflx-port
                             relay-ip relay-port media
                             (setup "active") (foundation "1")
                             (priority 2130706431) (session-id "3993324220") (lite t))
  "Build the answer SDP.  MEDIA is the offer's list of SDP-MEDIA (so our m-lines line up); if NIL,
answer a single data channel.  FINGERPRINT is our DTLS cert SHA-256 (colon-hex); IP/PORT the host
candidate; SRFLX-* / RELAY-* add server-reflexive / TURN-relay candidates; SETUP \"active\" = we are
the DTLS client; LITE advertises ICE-lite.  Audio is answered as G.711 PCMU (pt 0)."
  (let* ((media (or media (list (make-sdp-media :type "application" :mid "0" :sctp-port 5000))))
         (cands (%candidates-block ip port srflx-ip srflx-port relay-ip relay-port foundation priority))
         (shared (format nil "a=ice-ufrag:~a~%a=ice-pwd:~a~%a=fingerprint:sha-256 ~a~%a=setup:~a~%"
                         ice-ufrag ice-pwd fingerprint setup)))
    (with-output-to-string (out)
      (format out "v=0~%o=- ~a ~a IN IP4 0.0.0.0~%s=-~%t=0 0~%~@[a=ice-lite~%~*~]a=group:BUNDLE ~{~a~^ ~}~%~
                   a=msid-semantic:WMS *~%"
              session-id session-id lite (mapcar #'sdp-media-mid media))
      (loop for m in media for first = t then nil
            for own = (if first cands "") do
        (cond
          ((string= (sdp-media-type m) "audio")
           (let ((ok (member 0 (sdp-media-pts m))))            ; we only offer PCMU
             (format out "m=audio ~d UDP/TLS/RTP/SAVPF 0~%c=IN IP4 ~a~%a=rtcp-mux~%a=mid:~a~%~
                          a=~:[inactive~;sendrecv~]~%a=rtpmap:0 PCMU/8000~%~a~a"
                     (if ok port 0) ip (sdp-media-mid m) ok shared own)))
          ((string= (sdp-media-type m) "video")
           ;; VP8 only (we encode it; forcing VP8 also keeps the return direction off H.264).
           ;; sendonly: the box streams video to the browser, it sends none back.
           (let ((pt (sdp-media-codec-pt m "VP8")))
             (format out "m=video ~d UDP/TLS/RTP/SAVPF ~d~%c=IN IP4 ~a~%a=rtcp-mux~%a=mid:~a~%~
                          a=~:[inactive~;sendonly~]~%~@[a=rtpmap:~d VP8/90000~%~]~a~a"
                     (if pt port 0) (or pt 96) ip (sdp-media-mid m) pt pt shared own)))
          (t                                                   ; application / data channel
           (format out "m=application ~d UDP/DTLS/SCTP webrtc-datachannel~%c=IN IP4 ~a~%~
                        a=mid:~a~%a=sctp-port:~d~%a=max-message-size:65536~%~a~a"
                   port ip (sdp-media-mid m) (or (sdp-media-sctp-port m) 5000) shared own)))))))

;;; ---- ICE, in SDP terms -----------------------------------------------------------------
;;; ICE ITSELF NO LONGER KNOWS WHAT SDP IS.  cl-transport/ice takes a ufrag, a password and a
;;; candidate list (ICE-ACCEPT-REMOTE) and has no opinion about where they were read from —
;;; which is the whole point of it not being a WebRTC library.  This is the wrapper that speaks
;;; both, and it belongs HERE, beside the parser, because this file is the only one that ever
;;; knew both halves.
;;;
;;; The name and the arguments are unchanged, deliberately: glass-webrtc calls ICE-ANSWER and
;;; should not have to care that the agent underneath it moved to another system.

(defun ice-answer (agent remote-sdp &key fingerprint (setup "active") gather-srflx gather-relay)
  "Record the remote credentials from REMOTE-SDP and return our answer SDP.  With GATHER-SRFLX,
first discover our server-reflexive (public) address via STUN and include it as a candidate, so a
peer behind a different NAT can reach us.  With GATHER-RELAY, additionally Allocate a TURN relayed
address (env TURN_SERVER/USER/PASS unless GATHER-RELAY is a plist of :server/:user/:pass) and
advertise it as a `typ relay` candidate — this covers the symmetric-NAT case srflx can't.  Both
must run before ICE-SERVE (they use the ICE socket)."
  (ice-accept-remote agent
                     :ufrag (sdp-ice-ufrag remote-sdp)
                     :pwd (sdp-ice-pwd remote-sdp)
                     :candidates (sdp-candidates remote-sdp)
                     :gather-srflx gather-srflx :gather-relay gather-relay)
  (make-answer-sdp :ice-ufrag (ice-agent-local-ufrag agent) :ice-pwd (ice-agent-local-pwd agent)
                   :fingerprint (or fingerprint (colon-hex (u8vec 32)))   ; valid-format placeholder until DTLS
                   :ip (ice-agent-local-ip agent) :port (ice-agent-port agent)
                   :srflx-ip (ice-agent-srflx-ip agent) :srflx-port (ice-agent-srflx-port agent)
                   :relay-ip (ice-agent-relay-ip agent) :relay-port (ice-agent-relay-port agent)
                   :setup setup :media (sdp-media remote-sdp) :lite t))
