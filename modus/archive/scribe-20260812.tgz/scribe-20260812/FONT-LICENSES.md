# Shipped font licenses

The fonts in `fonts/` are **shipped with scribe** as the default face set for
`match-font` (the CSS font-matching service). They are the metric-compatible
substitutes browsers use on Linux for Arial/Helvetica, Times, and Courier, so a
consumer that asks for those families gets browser-accurate text metrics.

scribe itself (the code) is MIT — see the top-level `LICENSE`. The fonts keep
their own licenses, reproduced/identified below.

## Liberation Sans / Serif / Mono (Regular, Bold, Italic, BoldItalic)
**Liberation Fonts** — metric-compatible with Arial/Helvetica (Sans),
Times New Roman (Serif), and Courier New (Mono). Licensed under the
**SIL Open Font License, Version 1.1** (with the original Liberation builds also
having been distributed under the GPL v2 with a font-embedding exception). The
SIL OFL permits use, study, modification, embedding, and redistribution,
including bundling with software, provided the fonts are not sold on their own
and — if modified — are not distributed under the reserved "Liberation" name.

Copyright © 2012 Red Hat, Inc., with Liberation being a trademark of Red Hat.
Upstream: https://github.com/liberationfonts/liberation-fonts
Full license text: `fonts/LICENSE-Liberation.txt`.

## Twemoji (colour emoji)

`fonts/Twemoji.ttf` is Twitter's open-source emoji, as a COLR/CPAL colour font.
The emoji artwork is licensed **CC-BY 4.0**; the accompanying code is MIT.  scribe
bundles it as the default colour-emoji fallback face.

Copyright © Twitter, Inc. and other contributors.
Upstream: https://github.com/twitter/twemoji  (CC-BY 4.0)
