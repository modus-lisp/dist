;;;; stave — speech recognition in pure Common Lisp.
;;;;
;;;; No FFI, no foreign libraries, no C.  The recognizer is a streaming Zipformer
;;;; transducer exported from ONNX; mill executes its three graphs node for node,
;;;; so every intermediate value has an onnxruntime answer to be checked against.
;;;; What is in this system is the two ends mill knows nothing about: audio in —
;;;; the filterbank front end — and text out, the transducer search.

(asdf:defsystem #:stave
  :description "Streaming speech recognition in pure Common Lisp."
  :author "ynniv"
  :license "MIT"
  :depends-on (#:mill)
  :serial t
  :components ((:module "src"
                :serial t
                :components ((:file "packages")
                             (:file "wav")
                             (:file "fft")
                             (:file "fbank")
                             (:file "recognize")
                             (:file "stream")
                             (:file "lexicon")
                             (:file "beam")
                             (:file "wer")))))

;; Fetching the model needs an HTTPS client, and weft's is pure CL — but a stave that only ever
;; loads a model already on disk should not have to carry a TLS stack, so it is a separate system.
(asdf:defsystem #:stave/fetch
  :description "Download and convert the recognizer's model, in Lisp."
  :author "ynniv"
  :license "MIT"
  :depends-on (#:stave #:weft/fetch)
  :serial t
  :components ((:module "src" :serial t :components ((:file "fetch")))))
