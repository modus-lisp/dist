#!/usr/bin/env python3
"""Record kaldi's answer for the filterbank front end, on signals chosen to break it.

    dump-fbank.py OUTDIR [wav ...]

The front end is where a recognizer is easiest to get subtly wrong and hardest
to notice: features that are off by a constant, or by one frame, still decode to
something, just to the wrong thing.  So it gets its own gate, against
kaldi_native_fbank — the same implementation sherpa-onnx feeds this model — and
the gate runs on signals a recording would never contain.

Each case writes samples.npy (float32, the exact waveform handed to kaldi),
feats.npy (float32, num_frames x 80 — kaldi's answer), feats64.npy, the same
algorithm evaluated in float64, and power64.npy, each frame's total spectral
power.

Those last two are not second opinions; together they are the error bar.  A
log-mel value near the epsilon floor comes out of a sum that has almost entirely
cancelled, and there float32 is worth very little: on a 7900 Hz tone kaldi's own
answer is 3.4e-2 away from the float64 one, in a bin whose value is -15.6.  A
flat tolerance against kaldi would therefore be tightest precisely where the
arithmetic is worst, which is backwards.  How little a bin is worth is not a
matter of taste either — it is the fraction of its frame's power the bin holds,
and the error in its log grows as the reciprocal of that fraction, which is what
power64.npy is for.

kaldi stays the authority on what the algorithm IS.  The float64 version cannot
be that authority: it was written from the same reading of kaldi as the Lisp
was, and a misreading would sit in both.

Nothing here is random in the sense of being unrepeatable: the noise case is a
fixed LCG, so the same bytes come out every time on every machine.

What the synthetic cases are for:

  silence     every mel energy is zero, so every bin hits the epsilon floor.
              The one case where log() would otherwise return -inf, and the one
              that catches a floor applied in the wrong place.
  impulse     a flat spectrum, and — placed at sample 0 — the case that only
              looks right if the reflection at the start of the file is right.
  dc          remove_dc_offset has something to remove; without it every frame
              is a different answer.
  ramp        preemphasis has something to bite on, and the window's endpoints
              are where a Povey exponent of 0.85-vs-1.0 shows up.
  sine/chirp  narrow spectra land inside single mel bins, so a triangle that is
              one FFT bin too wide moves the answer instead of averaging out.
  short-*     lengths straddling a frame (400), a shift (160), and a half-shift
              (80).  snip_edges=false starts frame 0 at sample -120 and rounds
              the count by half a shift, so these are exactly the lengths where
              an off-by-one in the frame count lives.  A file shorter than a
              frame is not an error to kaldi; it reflects.
"""
import sys
from pathlib import Path

import numpy as np
import soundfile as sf
import kaldi_native_fbank as knf

SAMPLE_RATE = 16000
FEATURE_DIM = 80


def fbank(samples):
    """The configuration sherpa-onnx uses for this model, and the reason each
    line of it is not a default: dither must be zero or nothing is reproducible,
    snip_edges is off so frames are centred rather than left-aligned, and
    high_freq is negative — an offset down from Nyquist, so 7600 Hz."""
    opts = knf.FbankOptions()
    opts.frame_opts.samp_freq = SAMPLE_RATE
    opts.frame_opts.dither = 0.0
    opts.frame_opts.snip_edges = False
    opts.mel_opts.num_bins = FEATURE_DIM
    opts.mel_opts.low_freq = 20.0
    opts.mel_opts.high_freq = -400.0

    f = knf.OnlineFbank(opts)
    f.accept_waveform(SAMPLE_RATE, samples.tolist())
    f.input_finished()
    return np.array([f.get_frame(i) for i in range(f.num_frames_ready)],
                    dtype=np.float32)


FRAME_LENGTH, FRAME_SHIFT, PADDED = 400, 160, 512
EPS = float(np.float32(2.0 ** -23))     # C's FLT_EPSILON, which is what kaldi floors at


def mel(f):
    return 1127.0 * np.log(1.0 + f / 700.0)


def mel_filters():
    """The 80 triangles, over the 256 FFT bins below Nyquist."""
    nfft = PADDED // 2
    high = SAMPLE_RATE / 2 - 400.0
    bin_width = SAMPLE_RATE / PADDED
    lo, hi = mel(20.0), mel(high)
    delta = (hi - lo) / (FEATURE_DIM + 1)
    m = np.zeros((FEATURE_DIM, nfft))
    for b in range(FEATURE_DIM):
        left, center, right = lo + b * delta, lo + (b + 1) * delta, lo + (b + 2) * delta
        for i in range(nfft):
            v = mel(bin_width * i)
            if left < v < right:
                m[b, i] = ((v - left) / (center - left) if v <= center
                           else (right - v) / (right - center))
    return m


def fbank64(samples):
    """The same computation in float64: same frame placement, same reflection,
    same DC removal and preemphasis and window, same triangles, same floor.

    Values: the features, and each frame's total spectral power.  That second
    array is what lets a gate know how much a given bin is worth.  A mel bin
    holding a billionth of its frame's power is the tail of a sum that has
    almost entirely cancelled, and no float32 implementation resolves it — the
    error in its log grows as the reciprocal of that fraction."""
    x = np.asarray(samples, dtype=np.float64)
    n = len(x)
    nframes = (n + FRAME_SHIFT // 2) // FRAME_SHIFT
    win = (0.5 - 0.5 * np.cos(2 * np.pi * np.arange(FRAME_LENGTH)
                              / (FRAME_LENGTH - 1))) ** 0.85
    filters = mel_filters()
    out = np.zeros((nframes, FEATURE_DIM))
    power_total = np.zeros(nframes)
    for f in range(nframes):
        idx = np.arange(FRAME_LENGTH) + f * FRAME_SHIFT - (FRAME_LENGTH - FRAME_SHIFT) // 2
        for j in range(len(idx)):        # kaldi reflects repeatedly, not once
            while idx[j] < 0 or idx[j] >= n:
                idx[j] = -idx[j] - 1 if idx[j] < 0 else 2 * n - 1 - idx[j]
        w = x[idx].copy()
        w -= w.mean()
        w[1:] -= 0.97 * w[:-1]
        w[0] -= 0.97 * w[0]              # sample 0 is its own predecessor
        w *= win
        spec = np.fft.rfft(np.concatenate([w, np.zeros(PADDED - FRAME_LENGTH)]))
        power = (spec.real ** 2 + spec.imag ** 2)[:PADDED // 2]
        out[f] = np.log(np.maximum(filters @ power, EPS))
        power_total[f] = power.sum()
    return out, power_total


def lcg(n, seed=12345):
    """The same generator the Lisp gates use, so a case can be reproduced on
    either side without shipping the samples — though the samples ship anyway."""
    out = np.empty(n, dtype=np.float32)
    s = seed
    for i in range(n):
        s = (s * 1103515245 + 12345) % 2147483648
        out[i] = (s % 20001) / 10000.0 - 1.0
    return out


def synthetic():
    t = np.arange(4000, dtype=np.float64) / SAMPLE_RATE
    cases = {
        "silence": np.zeros(4000, dtype=np.float32),
        "impulse-0": np.concatenate(([1.0], np.zeros(3999))).astype(np.float32),
        "impulse-mid": np.concatenate((np.zeros(2000), [1.0],
                                       np.zeros(1999))).astype(np.float32),
        "dc": np.full(4000, 0.37, dtype=np.float32),
        "ramp": np.linspace(-1.0, 1.0, 4000, dtype=np.float32),
        "sine-440": (0.8 * np.sin(2 * np.pi * 440 * t)).astype(np.float32),
        "sine-7900": (0.8 * np.sin(2 * np.pi * 7900 * t)).astype(np.float32),
        "chirp": (0.7 * np.sin(2 * np.pi * (30 + 3900 * t) * t)).astype(np.float32),
        "noise": lcg(4000),
        "tiny": np.float32([0.5]),
    }
    # the frame-count boundaries: 80 is half a shift, 160 a shift, 400 a frame
    for n in (79, 80, 81, 159, 160, 161, 239, 240, 241, 399, 400, 401, 560):
        cases[f"short-{n}"] = lcg(n, seed=n * 7919 + 1)
    return cases


def main():
    if len(sys.argv) < 2:
        raise SystemExit(__doc__)
    out = Path(sys.argv[1])
    out.mkdir(parents=True, exist_ok=True)

    cases = synthetic()
    for wav in sys.argv[2:]:
        p = Path(wav)
        samples, sr = sf.read(str(p), dtype="float32", always_2d=False)
        if samples.ndim > 1:
            samples = samples[:, 0]
        if sr != SAMPLE_RATE:
            print(f"skipping {p.name}: {sr} Hz, and nothing here resamples")
            continue
        cases[p.stem] = samples

    names = []
    for name, samples in cases.items():
        d = out / name
        d.mkdir(exist_ok=True)
        feats = fbank(samples)
        exact, power = fbank64(samples)
        np.save(d / "samples.npy", samples)
        np.save(d / "feats.npy", feats)
        np.save(d / "feats64.npy", exact.astype(np.float64))
        np.save(d / "power64.npy", power.astype(np.float64))
        names.append(name)
        if len(feats):
            slack = np.abs(feats.astype(np.float64) - exact).max()
            print(f"{name:14s} {len(samples):7d} samples -> {feats.shape[0]:5d} frames"
                  f"  [{feats.min():8.3f}, {feats.max():8.3f}]"
                  f"   kaldi's own float32 error {slack:.2e}")
        else:
            print(f"{name:14s} {len(samples):7d} samples -> 0 frames")

    (out / "cases.txt").write_text("\n".join(names) + "\n")
    print(f"\n{len(names)} cases in {out}")


if __name__ == "__main__":
    main()
