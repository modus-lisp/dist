#!/usr/bin/env bash
# make-lexicon.sh — the word list the search's lexicon prior reads.
#
#     bash tools/make-lexicon.sh [cmudict.dict] [out]
#
# CMUdict is a pronouncing dictionary and this throws the pronunciations away,
# which is the whole conversion: what the prior needs is not how a word sounds —
# the model has opinions about that already, better ones — but only which
# spellings are words at all.  About 134,000 of them, names included, which is
# why STEVE and JOBS are in here and STEECHOBS is not.
#
# CMUdict is BSD-licensed and already vendored by chord for its voice front end,
# so this reads that copy rather than downloading a second one.  The output goes
# outside the repo with the rest of the assets; nothing here is generated code.
set -euo pipefail

DICT="${1:-/home/claude/chord/data/cmudict.dict}"
OUT="${2:-/mnt/lisp/stave/lexicon.txt}"

[ -f "$DICT" ] || { echo "no cmudict at $DICT" >&2; exit 1; }
mkdir -p "$(dirname "$OUT")"

{
  echo "; words, from CMUdict (BSD).  Pronunciations dropped; spellings only."
  echo "; $(basename "$DICT"), $(wc -l < "$DICT") entries"
  # field 1, minus the "(2)" that marks an alternate pronunciation of a word
  # already listed, upper-cased because that is the form the model emits.
  awk '{print $1}' "$DICT" \
    | sed -E 's/\([0-9]+\)$//' \
    | tr '[:lower:]' '[:upper:]' \
    | sort -u
} > "$OUT"

echo "$(grep -vc '^;' "$OUT") words in $OUT"
