#!/usr/bin/env bash
# get-librispeech.sh — the captioned audio inspect/wer-gate.lisp measures against.
#
#     bash tools/get-librispeech.sh [dest]      # default /mnt/lisp/stave/
#
# test-clean is the standard benchmark for this model: 2620 read-speech
# utterances, 5.4 hours, with reference transcripts that are already uppercase
# and unpunctuated, which is the form the recognizer emits.  Published word
# error rates for the zipformer streaming models are quoted on it, so a number
# measured here is a number that can be compared with somebody else's.
#
# LibriSpeech ships FLAC, and reed does not decode FLAC yet, so ffmpeg converts
# it once here.  That is corpus preparation and not part of the recognizer's
# path — the same standing as tools/make-feeds.py running onnxruntime.  When
# reed learns FLAC this step goes away.
set -euo pipefail

DEST="${1:-/mnt/lisp/stave}"
URL=https://www.openslr.org/resources/12/test-clean.tar.gz
TAR="$DEST/test-clean.tar.gz"
ROOT="$DEST/LibriSpeech/test-clean"
OUT="$DEST/librispeech-test-clean"

mkdir -p "$DEST"
[ -f "$TAR" ] || curl -L --fail -o "$TAR" "$URL"
[ -d "$ROOT" ] || tar -xzf "$TAR" -C "$DEST"

mkdir -p "$OUT"
: > "$OUT/manifest.tsv"

# Each speaker/chapter directory holds one .trans.txt: an utterance id, a space,
# and the words.  The manifest pairs the converted wav with that line, so the
# gate never has to know how LibriSpeech lays itself out.
#
# ffmpeg gets -nostdin because the loop below is reading the transcript on
# stdin, and ffmpeg reads stdin whether it has any use for it or not: without
# this it swallows the first byte of the next line and asks for 089-...flac.
n=0
while IFS= read -r trans; do
  dir=$(dirname "$trans")
  while IFS= read -r line; do
    id=${line%% *}
    text=${line#* }
    wav="$OUT/$id.wav"
    [ -f "$wav" ] || ffmpeg -nostdin -v error -y -i "$dir/$id.flac" -ac 1 -ar 16000 "$wav"
    printf '%s\t%s\t%s\n' "$id" "$wav" "$text" >> "$OUT/manifest.tsv"
    n=$((n+1))
  done < "$trans"
done < <(find "$ROOT" -name '*.trans.txt' | sort)

echo "$n utterances in $OUT/manifest.tsv"
