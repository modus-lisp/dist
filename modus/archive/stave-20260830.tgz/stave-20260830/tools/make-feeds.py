#!/usr/bin/env python3
"""Build the .npz feeds that mill's dump-fixtures.py runs each graph on, and the
transcript the whole thing has to reproduce.

    make-feeds.py MODELDIR audio.wav OUTDIR [chunk]

mill knows how to run a graph and keep every intermediate; it does not know what
a streaming Zipformer transducer wants fed to it, which is this file's whole job.

Doing that honestly means running the recognizer, not just describing it.  The
three graphs are not independent: the encoder's caches only hold anything after a
chunk has gone through, the decoder's input is the tokens the search has already
emitted, and the joiner's two inputs are the other two graphs' outputs.  Feeding
any of them zeros would gate the engine on arithmetic that is half multiplication
by zero — and a cache full of zeros cannot tell a correct attention from one that
dropped its history.  So this is a reference implementation of the loop, in
Python against onnxruntime, and the feeds are things it actually computed:

  encoder.npz   45 frames of real log-mel, and the 98 cache tensors as they
                stood after CHUNK chunks of the same file had gone through
  decoder.npz   a two-token context the search actually reached, not <blank blank>
  joiner.npz    one encoder frame and its decoder state, at a step where the
                search was about to emit something

  transcript.txt  what the greedy search produced, which is what stave's own
                  loop has to say word for word

The output is deterministic: the filterbank has dithering off, and onnxruntime
runs single-threaded so no reduction depends on the machine's core count.
"""
import sys
from pathlib import Path

import numpy as np
import onnx
import onnxruntime as ort
import soundfile as sf
import kaldi_native_fbank as knf

# What sherpa-onnx configures for this model family.  Not all defaults —
# high_freq is negative (an offset down from Nyquist), snip_edges is off, and
# dither must be zero or the features are not reproducible.
SAMPLE_RATE = 16000
FEATURE_DIM = 80
BLANK = 0


def session(path):
    so = ort.SessionOptions()
    so.intra_op_num_threads = 1
    so.inter_op_num_threads = 1
    return ort.InferenceSession(str(path), so, providers=["CPUExecutionProvider"])


def features(wav):
    samples, sr = sf.read(str(wav), dtype="float32", always_2d=False)
    if samples.ndim > 1:
        samples = samples[:, 0]
    if sr != SAMPLE_RATE:
        raise SystemExit(f"{wav}: {sr} Hz, and nothing here resamples — use 16 kHz")

    opts = knf.FbankOptions()
    opts.frame_opts.samp_freq = SAMPLE_RATE
    opts.frame_opts.dither = 0.0
    opts.frame_opts.snip_edges = False
    opts.mel_opts.num_bins = FEATURE_DIM
    opts.mel_opts.low_freq = 20.0
    opts.mel_opts.high_freq = -400.0

    fbank = knf.OnlineFbank(opts)
    fbank.accept_waveform(SAMPLE_RATE, samples.tolist())
    fbank.input_finished()
    return np.array([fbank.get_frame(i) for i in range(fbank.num_frames_ready)],
                    dtype=np.float32)


def zero_states(model, batch=1):
    """Every encoder input but `x`, at its declared shape with the batch axis
    pinned.  A stream starts with these, and they are zeros for all of them —
    including processed_lens, which is a count.  Shapes come from the model
    rather than from a table here, because the model is where they are actually
    written down and a table would be a second copy to get wrong."""
    dtypes = {1: np.float32, 7: np.int64}
    states = {}
    for i in model.graph.input:
        if i.name == "x":
            continue
        t = i.type.tensor_type
        dims = [batch if d.dim_param else d.dim_value for d in t.shape.dim]
        if t.elem_type not in dtypes:
            raise SystemExit(f"input {i.name} has element type {t.elem_type}, "
                             f"which this does not know how to zero")
        states[i.name] = np.zeros(dims, dtype=dtypes[t.elem_type])
    return states


def main():
    if not 4 <= len(sys.argv) <= 5:
        raise SystemExit(__doc__)
    models, wav, out = Path(sys.argv[1]), Path(sys.argv[2]), Path(sys.argv[3])
    want_chunk = int(sys.argv[4]) if len(sys.argv) > 4 else 1
    out.mkdir(parents=True, exist_ok=True)

    enc_path = next(models.glob("encoder-*.onnx"))
    dec_path = next(models.glob("decoder-*.onnx"))
    joi_path = next(models.glob("joiner-*.onnx"))
    tokens = {}
    for line in (models / "tokens.txt").read_text().splitlines():
        sym, i = line.rsplit(maxsplit=1)
        tokens[int(i)] = sym

    enc_model = onnx.load(str(enc_path))
    meta = {p.key: p.value for p in enc_model.metadata_props}
    window = int(enc_model.graph.input[0].type.tensor_type.shape.dim[1].dim_value)
    advance = int(meta["decode_chunk_len"])
    context = int({p.key: p.value
                   for p in onnx.load(str(dec_path)).metadata_props}["context_size"])

    enc, dec, joi = session(enc_path), session(dec_path), session(joi_path)
    enc_outs = [o.name for o in enc_model.graph.output]

    feats = features(wav)
    if len(feats) < want_chunk * advance + window:
        raise SystemExit(f"{wav} gives {len(feats)} frames; chunk {want_chunk} needs "
                         f"{want_chunk * advance + window}.  Use a longer file.")

    # The tail.  A file is not a whole number of chunks, and dropping the
    # remainder loses the last second of speech, so pad with zero frames until
    # the final chunk is full — what a streaming recognizer does when its input
    # ends.  One chunk MORE than that is needed to hear it: the downsampling
    # stack looks ahead, so the last real frames only reach the encoder's output
    # once something has followed them through.  Without this the transcript of
    # test_wavs/1.wav ends "IN HEAVE".
    #
    # Measured: with the extra chunk this loop reproduces trans.txt word for word
    # on 0.wav, and on 1.wav differs from it in one word — DISHONORED where the
    # reference reads DISHONOURED, which is the model's own spelling and not a
    # truncation.  sherpa-onnx's streaming recognizer on the same models ends
    # those two files "THE BROTHEL" and "IN HE": it flushes less at the end.  So
    # this is deliberately not bug-compatible with sherpa — what a gate compares
    # against should be the better answer, not the familiar one.
    chunks = max(1, -(-(len(feats) - window) // advance) + 2)
    feats = np.pad(feats, ((0, (chunks - 1) * advance + window - len(feats)), (0, 0)))

    states = zero_states(enc_model)
    hyp = [BLANK] * context                     # the search's token history
    dec_out = dec.run(None, {"y": np.array([hyp[-context:]], dtype=np.int64)})[0]
    saved = {}

    for c in range(chunks):
        x = feats[c * advance:c * advance + window][None, :, :]
        if c == want_chunk:
            saved["encoder"] = dict(x=x, **states)
        got = enc.run(enc_outs, {"x": x, **states})
        states = {n[len("new_"):]: v for n, v in zip(enc_outs[1:], got[1:])}

        # greedy transducer search over this chunk's frames: ask the joiner what
        # the current (encoder frame, token history) pair says, and advance the
        # history only when it says something other than blank
        for t in range(got[0].shape[1]):
            frame = got[0][:, t, :]
            logit = joi.run(None, {"encoder_out": frame, "decoder_out": dec_out})[0]
            best = int(logit[0].argmax())
            if best != BLANK:
                # a step where the search commits: the most interesting one to
                # hand the joiner and decoder gates, so keep overwriting and the
                # last such step in the file is what gets saved
                saved["joiner"] = dict(encoder_out=frame, decoder_out=dec_out)
                hyp.append(best)
                y = np.array([hyp[-context:]], dtype=np.int64)
                saved["decoder"] = dict(y=y)
                dec_out = dec.run(None, {"y": y})[0]

    for name in ("encoder", "decoder", "joiner"):
        if name not in saved:
            raise SystemExit(f"nothing to save for the {name}: the search never "
                             f"emitted a token on {wav.name}, so there is no real "
                             f"feed for it — use a file with speech in it")
        np.savez(out / f"{name}.npz", **saved[name])

    text = "".join(tokens[t] for t in hyp[context:]).replace("▁", " ").strip()
    (out / "transcript.txt").write_text(text + "\n")
    print(f"{out}/encoder.npz: chunk {want_chunk} of {wav.name}, x{list(saved['encoder']['x'].shape)}, "
          f"processed_lens={saved['encoder']['processed_lens'][0]}")
    print(f"{out}/decoder.npz: y={saved['decoder']['y'].tolist()}")
    print(f"{out}/joiner.npz:  a step where the search emitted")
    print(f"{out}/transcript.txt: {text!r}")


if __name__ == "__main__":
    main()
