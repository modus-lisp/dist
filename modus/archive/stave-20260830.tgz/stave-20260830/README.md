# stave

Speech recognition in pure Common Lisp. No FFI, no C, no foreign libraries —
chord speaks, stave writes it down.

The recognizer is a streaming Zipformer transducer: audio arrives in chunks of
0.32 s, and tokens come out as it goes rather than after the file ends. The work
per chunk is constant, which is what makes it a thing a small machine can run
rather than a thing a small machine can eventually finish.

    (let ((rec (stave:load-recognizer "models/")))
      (stave:recognize-file rec "hello.wav"))
    => "AFTER EARLY NIGHTFALL THE YELLOW LAMPS WOULD LIGHT UP HERE AND THERE ..."

MIT licensed.

## The model

stave ships no weights, and fetches them on first use — in Lisp:

    (asdf:load-system :stave/fetch)
    (let ((rec (stave:ensure-recognizer)))
      (stave:recognize-file rec "hello.wav"))

That downloads over weft's pure-CL TLS and converts each graph with mill's own ONNX reader, so
there is no `huggingface-cli`, no Python, and no protobuf library to install. Cold start from an
empty directory to a transcript is about 70 s, most of it the 262 MB encoder. Afterwards the
converted `.graph` + `.bin` load directly.

    csukuangfj/sherpa-onnx-streaming-zipformer-en-2023-06-26     Apache-2.0
    trained on LibriSpeech (openslr.org/12)                       CC BY 4.0

**Why the weights are not in git.** The encoder alone is 262 MB in one file, and GitHub rejects
anything over 100 MB. Compression does not rescue it: `gzip -9` returns 92% of the original,
because trained float32 weights are close to incompressible noise. Casting to float16 would halve
it to ~131 MB — still over the limit — and it would break the bit-exactness the node gates assert
against onnxruntime. Quantizing to int8 would fit, and would make every gate in `inspect/`
meaningless.

The upstream licence permits redistribution with attribution, so a converted build could reasonably
be published as a release asset; it is the size, not the licence, that keeps it out of the tree.

## State

**It transcribes.** Samples in, words out, in Lisp the whole way down.

    0.wav    6.6 s of audio in   3.9 s (1.70x realtime), 18 words, exact
    1.wav   16.7 s of audio in   7.2 s (2.34x realtime), 48 words, exact

Both are word for word what the same model, driven by the same greedy search
against onnxruntime in Python, produces for the same files — the bar being
equality, since a transcript is discrete and there is no being close to the right
word.

Those are the gate's own numbers, which is to say a cold process transcribing
twenty-three seconds and stopping. Warm it up and the same work runs at **3.9x
realtime** (median of eleven passes; 4.1x best), because the first pass pays for
building the packed copy of every weight and for faulting in half a gigabyte.
On a recording long enough to care about, the warm number is the one you get.

Four worker threads, not sixteen. This model's matmuls are two to four rows
against a weight of one to three megabytes, so a wide pool splits each one too
thin to cover the cost of splitting it, and on a two-socket box it then straddles
the sockets: sixteen threads measures *slower* than four (3.32x median) unless
pinned to one NUMA node, and four is steadier than either. `MILL_THREADS=4`.

It was 1.26x when it first worked. What the 3x came from is written up in
mill's `src/ops-nn.lisp` — packing the weights into the order the kernel reads
them, hoisting an odometer out of every elementwise op, and not copying three
thousand constants once per chunk. All of it is bit-exact: the same transcripts,
and the same 2.35% word error rate, before and after.

**And it transcribes well.** On 200 utterances strided across LibriSpeech
test-clean — twenty-five minutes of speech nobody here chose, against published
references:

    greedy    WER 2.35%    71 sub 12 del 10 ins over 3951 words
    beam 4    WER 2.33%    70 sub 11 del 11 ins over 3951 words

The beam is a wash on read speech, and honestly so: it recovered GAMEWELL from
CAMELL, LET'S from ITS, and HANDS HIM from HANDSOME, and it spent almost all of
that turning MOURN into MOURNED and VERNE'S into VERN'S. What the beam is
actually worth shows up on speech that is not a studio reading of a novel.

A transducer is three ONNX graphs and two ends. [mill](https://github.com/modus-lisp/mill)
runs the graphs; what belongs here is the two ends mill knows nothing about —
the filterbank front end that turns samples into features, and the transducer
search that turns encoder frames into words. Both now exist, and each is gated
against the thing it has to agree with.

The graphs were proven first, before either end existed, because a recognizer
gives one bit of feedback at the end — the transcript is wrong — and that is not
enough to find an arithmetic mistake in node 4000 of 9418.

    graph     nodes   compared   closest to the tolerance bar
    encoder    9418       9418   0.096 of the allowance
    decoder      20         20   0.002
    joiner        3          3   0.004

Every intermediate value in all three matches onnxruntime within
`1e-4 + 1e-4*|ref|`. The encoder's own output is out by 2.9e-6, and its 98
carried state tensors — the caches that make it streaming — by at most 0.020 of
their allowance.

Bringing this up cost mill two things: two-dimensional `Conv`, which the
convolutional embedding needs and chord's voice never did, and a transpose that
strided by the wrong extent. That second one is the interesting one. It is
correct on square matrices, so the decoder's 512x512 projection passed and the
joiner's 500x512 failed — twenty logits out of place, which is a different word.
mill now has a gate whose every case is non-square.

> **Absolute error means nothing on this model.** The encoder's values span some
> thirty orders of magnitude; one `Exp` reaches 2.15e13, and at that scale an
> error of 2e9 is within tolerance and *should* be there. The largest raw error
> in the graph is 8.2e7 and it is fine. The comparable number, and the one the
> gate is read by, is the fraction of the allowance a value used.

## The front end

A Zipformer hears 80-bin log-mel features, and it hears them in exactly the
dialect kaldi speaks: a Povey window (Hann raised to 0.85), the frame's DC
removed *before* preemphasis of 0.97 with sample 0 as its own predecessor,
`snip_edges` off — so frame *f* starts at sample `160f − 120` and short files
reflect off both ends, repeatedly — 80 triangles from 20 Hz to 400 Hz below
Nyquist over the 256 bins under it, and a floor at C's `FLT_EPSILON`, which is
2⁻²³ and not Lisp's `single-float-epsilon`. Every one of those is a place to be
quietly wrong, so `inspect/fbank-gate.lisp` compares against
`kaldi_native_fbank` itself, on 25 cases chosen to break it rather than to
represent it: silence, an impulse at sample 0, constant DC, a 7900 Hz tone
sitting *above* the mel band's edge, and thirteen lengths straddling a frame, a
shift and half a shift.

    206560 elements over 25 cases, against kaldi_native_fbank
    closest to the bar: 0.730 of it, error 4.292d-4 (1.wav, frame 1212 bin 5)

Frame counts are compared exactly — an off-by-one there is a different
recognizer, not a rounding difference.

> **A bar built on kaldi's error would be asking stave to win a lottery.** In a
> mel bin holding a billionth of its frame's power, the sum has almost entirely
> cancelled and float32 buys almost nothing: kaldi's own answer is 3.4e-2 from a
> float64 evaluation of kaldi's own algorithm, and its error swings three orders
> of magnitude between neighbouring bins. So the bar is
> `5e-4 + 1e-12/share`, where *share* is the fraction of its frame's total
> spectral power the bin holds — one physical quantity, no threshold. It reaches
> 1.89% of elements; 96.7% get a bar within 1% of the flat 5e-4 and the worst of
> those is 7.2e-5.

The FFT under it is a real transform done as a half-size complex one, packing
even samples real and odd imaginary. Its twiddle table stops at N/4, because
`W^(N/2−k) = −conj(W^k)` gives the mirrored output for free.

## Audio that is not a 16 kHz wav

`recognize-file` reads a RIFF wav at exactly the rate the filterbank was built
for and refuses anything else, because a recognizer that quietly resamples turns
a wrong rate into a wrong transcript rather than an error. Real audio is not
that, so `inspect/transcribe.lisp` puts the two missing steps in front of it —
and both of them are Lisp:
[reed](https://github.com/modus-lisp/reed) decodes the container and the codec,
reed downmixes and resamples, stave does the rest.

    sbcl --dynamic-space-size 8192 --disable-debugger \
      --load inspect/transcribe.lisp --end-toplevel-options talk.m4a

That is the point rather than a convenience. An `.m4a` is exactly the kind of
thing that smuggles a C dependency into a pure-Lisp pipeline at the very last
step, and this stack is aimed at a machine with no OS to borrow a decoder from.

> **The same audio decoded two ways said two different things**, once. A 14 s
> AAC clip transcribed through reed and through ffmpeg differed in two words —
> and the fault was reed's, which was keeping the AAC encoder's priming samples
> instead of dropping them as the container's `iTunSMPB` tag declared. 57 ms of
> silence moves every filterbank frame boundary, which is enough to change the
> two words the model was least sure of. With reed reading the tag the two paths
> agree word for word. A recognizer turns out to be a sharp test of a decoder's
> alignment: reed's own AAC gate cross-correlates before comparing and so could
> not see a constant delay at all.

## The search

Once per encoder frame, the joiner is asked what the encoder's 512 numbers and
the decoder's 512 numbers say together, and answers with 500 logits. The largest
is either blank — nothing was said, move to the next frame — or a token, which is
appended to the hypothesis and changes what the decoder says from then on. That
is the whole of it: greedy, no lattice, no rescoring.

Greedy is a coin flip that lands once and forever. A token emitted at frame 400
is the decoder's *input* from frame 400 onward, so one bad flip does not cost one
token, it costs the rest of the word. In a clip of the sugar-water speech the
name STEVE came out STEE because at the deciding frame `E` led `VE` by 0.9 of a
logit — and having said STEE, the decoder made STEECHOBS of what should have been
JOBS.

So `src/beam.lisp` adds modified beam search, as in icefall, which is what this
model was published against. Every surviving hypothesis is extended by exactly
one label per frame, blank included, which bounds the work at `beam` joiner calls
per frame and is the whole of what *modified* means; hypotheses that reach the
same token sequence by different routes are merged and their probabilities added,
or a beam of four fills up with one word spelled four ways. It costs almost
nothing in wall clock — the encoder is 9418 nodes and the joiner is 3.

    (stave:recognize-file rec #p"talk.wav" :beam 4)

Greedy stays the default, because what `inspect/transcript-gate.lisp` compares
against is a greedy reference loop and a search that scores *better* would fail
that gate for a reason that is not a bug. The beam is judged on word error rate
instead.

The number of tokens is not the number of frames, and nothing in here decides in
advance how many words a second of audio holds. That is the transducer's actual
trick, and it is why the search is three lines rather than an alignment.

None of the numbers that say *how* to call the graphs are written down in this
repository. The window is the encoder's own declared input shape; the advance
between chunks and the decoder's context size come from the model's ONNX
metadata, which mill now carries through the export. A graph describes one call
and cannot say how the calls follow one another, so those live with the weights
and not in a table here that could drift from them.

> **The tail is one chunk longer than it looks.** A file is not a whole number of
> chunks, so the remainder is zero-padded — and then one *more* chunk is run,
> because the downsampling stack looks ahead and the last real frames only reach
> the encoder's output once something has followed them through. Without it
> `1.wav` ends IN HEAVE rather than IN HEAVEN.

## Gates

`inspect/node-gate.lisp` runs a graph and compares each node's output against
onnxruntime's for the same node on the same input, so a wrong answer names the
node that *first* diverged — nearly always the one with the bug in it, since
everything after is downstream damage. Which of the three graphs it runs is
`STAVE_GRAPH` and `STAVE_FIXTURES`; they are gated separately because they run
separately, the encoder once per chunk and the other two once per emitted token.

    STAVE_GRAPH=.../encoder-....graph STAVE_FIXTURES=.../fixtures-encoder/ \
      sbcl --dynamic-space-size 8192 --load inspect/node-gate.lisp

Integer and boolean tensors must match exactly; there is no such thing as a
nearly-right index. Nothing here is random, so nothing is skipped: every value
the dump holds is compared, and a value with no fixture is counted and named
rather than passed over.

`inspect/transcript-gate.lisp` is the one that can fail for a reason none of the
others can see. The node gates prove each graph computes what onnxruntime
computes and say nothing about whether the graphs are being *called* right — the
window, the advance, which of 98 outputs carries to which of 98 inputs, when the
decoder is re-run, what counts as blank. All of that is invisible until a word
comes out wrong.

    sbcl --dynamic-space-size 8192 --disable-debugger \
      --load inspect/transcript-gate.lisp

`inspect/fbank-gate.lisp` needs no models, only the fixtures `tools/dump-fbank.py`
writes.

`inspect/wer-gate.lisp` asks the other question. The transcript gate proves the
graphs are driven right and says nothing about whether the result is any good;
this one runs LibriSpeech test-clean — speech nobody here chose — and counts how
often a word is wrong.

    bash tools/get-librispeech.sh                       # once, ~350 MB
    STAVE_WER_N=200 sbcl --dynamic-space-size 8192 \
      --load inspect/wer-gate.lisp

Word error rate is (substitutions + deletions + insertions) ÷ reference words,
the three reported apart because they fail differently: deletions are a
recognizer that stopped listening, insertions are one that would not stop
talking, and substitutions are the only kind that is about hearing. LibriSpeech
references are already uppercase and unpunctuated — the form this model emits —
so nothing has to be normalized away and no normalizer can quietly flatter us.
The subset is *strided* rather than the first N lines, because test-clean is
ordered by speaker and the first two hundred utterances are three readers in a
row.

Both searches are measured, and the gate's own claim is the comparison: a wider
search that loses to a narrower one is a bug in the search. The absolute bar is
a ratchet on our own measurement, not somebody else's published number — there
is no provenance file for these weights, and a bar copied off a model card that
might not be this model's would be a bar that means nothing.

## Fixtures

`tools/make-feeds.py` builds what the gates run on, and mill's
`tools/dump-fixtures.py` records onnxruntime's answer for every node.

The feeds could not be written down, only computed. The three graphs are not
independent — the encoder's caches hold nothing until chunks have gone through
them, the decoder's input is the tokens the search has already emitted, and the
joiner's two inputs are the other two graphs' outputs. Feeding any of them zeros
would gate the engine on arithmetic that is half multiplication by zero, and a
cache full of zeros cannot tell a correct attention from one that dropped its
history. So `make-feeds.py` is a reference implementation of the whole
recognizer loop in Python against onnxruntime, and the feeds are things it
actually computed at a step that matters: a warm encoder state, a two-token
context the search really reached, and a joiner call at a step where it was
about to emit.

It also writes the transcript stave's own loop has to reproduce, which is what
`inspect/transcript-gate.lisp` holds it to.

> **What the transcript is compared against, and what it is not.** The reference
> loop reproduces the `trans.txt` shipped with the model word for word on
> `0.wav`, and on `1.wav` differs in exactly one word — DISHONORED where the
> reference reads DISHONOURED, which is the model's spelling rather than a
> truncation. sherpa-onnx's own streaming recognizer on these same models ends
> those two files "THE BROTHEL" and "IN HE"; it flushes less. This is
> deliberately not bug-compatible with sherpa, on the grounds that what a gate
> compares against should be the better answer and not the familiar one.

Determinism is not incidental: the filterbank runs with dithering off, and
onnxruntime is pinned to one intra-op thread. A reduction split across N threads
sums in an N-dependent order, and a fixture that moves with the machine's core
count is not a fixture.

And it is the transcript gate that answers the question the filterbank gate
cannot. Our features differ from kaldi's by up to 4.8e-4 in bins near
cancellation; whether that matters is not a thing to argue about, and now there
is a run that settles it. It does not.

## Whose fault is a wrong word

A wrong word has two possible suspects and they take different repairs. Either
the model scored the right answer below the wrong one — which no search can fix
— or the model would have preferred it and the search pruned it before finding
out. `inspect/forced-score.lisp` settles which, by computing the exact
log-probability the model assigns to a transcript *it did not choose*: the
transducer forward algorithm over the same one-label-per-frame lattice the
searches walk, so what it measures is what they search.

Fourteen seconds of the sugar-water speech, where the greedy transcript says
STEECHOBS. Each line is the greedy transcript with one thing put right:

    -23.13  (what it said)
    -24.23  STEVE JOBS   for STEECHOBS       1.10 nats worse
    -24.91  OR DO        for WHERE DO        1.78
    -24.95  JUST STARED  for YOU STARED      1.82
    -27.24  OF YOUR LIFE for YEAR LIFE       4.11
    -27.91  SAID DO YOU  for SAID YOU        4.78

Every correct reading scores *below* the wrong one, so the search is not what is
holding any of them back — an exhaustive search would return the same transcript,
and widening the beam from 4 to 16 duly did not move STEECHOBS. The model
believes it.

And STEVE JOBS is the cheapest of the five to fix: a factor of three. Nothing
about the sounds is unclear — the vocabulary spells it ▁ST E VE ▁JO B S and the
model was within one nat of choosing that. It is the implicit language model,
which is a 19th-century-novel language model. LibriSpeech is public-domain books
read aloud; in the 52,576 words of test-clean, STEVE occurs 0 times and JOBS
occurs 0 times, and there is no `▁STEVE` or `▁JOB` piece in the 500-piece
vocabulary built from that corpus. A name is not rare in English. It is rare
*here*, and shallow fusion or contextual biasing — a few nats on a handful of
tokens, no special case for anybody — is what the number says to build.

## Next

- speed. 3.9x realtime is not a Pi. The encoder is 9418 nodes and 261 MB of
  weights, run once per 0.32 s of audio, and the profile now reads MatMul 35%,
  Conv 22%, Log and Exp 10%, and 14% in mill's own loop around the nodes. The
  first of those is at the wall for its access pattern — two rows against a
  megabyte is half a multiply per byte, and the kernel already streams the
  weights at 18 GB/s on one core. The other three are where the next 2x is:
  vectorized transcendentals, and a runner that looks values up by index rather
  than by hashing their names 3 million times a recording
- a wav file is not a microphone. The chunk driver already streams, but the
  filterbank does not: `snip_edges=false` reflects off the *end* of the signal,
  which a live front end does not have yet
- **biasing**, which `inspect/forced-score.lisp` says is the only thing left that
  would help on the errors we have. See below

## Layout

    stave.asd            the system; depends on mill
    src/packages.lisp    the package
    src/wav.lisp         RIFF in, single-floats in [-1,1] out
    src/fft.lisp         real power spectrum via a half-size complex transform
    src/fbank.lisp       kaldi's 80-bin log-mel front end
    src/recognize.lisp   the chunk loop and the greedy transducer search
    src/beam.lisp        modified beam search, for when one opinion is not enough
    src/wer.lisp         word error rate, counted without normalizing anything
    tools/make-feeds.py  the reference loop, and the feeds the node gates run on
    tools/dump-fbank.py  kaldi's answer, and a float64 one for the error bar
    tools/get-librispeech.sh  the captioned corpus the WER gate measures against
    inspect/node-gate.lisp
    inspect/fbank-gate.lisp
    inspect/transcript-gate.lisp
    inspect/wer-gate.lisp     greedy against beam, on speech nobody here chose
    inspect/forced-score.lisp what the model thinks of a transcript it didn't pick
    inspect/transcribe.lisp   mp3/m4a/opus in, via reed; not a gate, a front door
    inspect/audio.lisp        the reed decode path those two share
