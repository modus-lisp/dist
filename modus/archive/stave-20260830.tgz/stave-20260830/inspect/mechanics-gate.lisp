;;;; mechanics-gate.lisp — the parts of stave that are arithmetic, not recognition.
;;;;
;;;;     sbcl --load inspect/mechanics-gate.lisp
;;;;
;;;; Every other gate here compares against kaldi reference output or a Zipformer
;;;; export, none of which is in the repository — so on a machine without that data
;;;; they skip, and stave's CI proves only that the code loads.  This one runs
;;;; everywhere, because it tests the things whose right answer is a fact rather than a
;;;; recording:
;;;;
;;;;   * the frame arithmetic, whose docstrings state exact numbers ("79 samples give
;;;;     nothing and 80 give a frame") that nothing was checking;
;;;;   * the FFT, against signals whose spectrum is known in closed form — a constant
;;;;     puts all its power in bin 0, a sinusoid at bin k puts it at k;
;;;;   * the filterbank on silence, which must floor rather than take a log of zero;
;;;;   * word error rate, which is counting;
;;;;   * SENTENCE-CASE, whose own docstring says it is "checkable without audio".
;;;;
;;;; It is deliberately NOT a test of whether stave hears correctly.  It is a test that
;;;; the machinery around the hearing is sound, which is the part that breaks silently
;;;; when somebody refactors and has no fixtures to notice with.

(require :asdf)
(let ((here (make-pathname :name nil :type nil
                           :defaults (or *load-truename* *compile-file-truename*))))
  (asdf:initialize-source-registry
   `(:source-registry (:tree ,(merge-pathnames "../../" here))
                      (:exclude "vendor") (:exclude "deps") :inherit-configuration)))
(handler-bind ((warning #'muffle-warning))
  (let ((*standard-output* (make-broadcast-stream)))
    (asdf:load-system :stave)))

(in-package #:stave)

(defvar *pass* 0) (defvar *fail* 0)
(defun ok (name got &optional detail)
  (if got (progn (incf *pass*) (format t "  ok   ~a~@[ — ~a~]~%" name detail))
      (progn (incf *fail*) (format t "  FAIL ~a~@[ — ~a~]~%" name detail)))
  (finish-output))
(defun ~= (a b &optional (tol 1d-6)) (< (abs (- a b)) tol))

(format t "~&== frame arithmetic ==~%")
;; Straight from FBANK-NUM-FRAMES' docstring, which stated these and had nothing
;; asserting them.
(ok "79 samples give no frame" (= (fbank-num-frames 79) 0) (format nil "~d" (fbank-num-frames 79)))
(ok "80 samples give one" (= (fbank-num-frames 80) 1) (format nil "~d" (fbank-num-frames 80)))
(ok "no samples give none" (= (fbank-num-frames 0) 0))
(ok "a negative count is 0, not a negative frame count" (= (fbank-num-frames -100) 0))
(ok "one second is a hundred frames" (= (fbank-num-frames 16000) 100)
    (format nil "~d" (fbank-num-frames 16000)))
;; It rounds to the nearest shift rather than truncating: 160f+80 is the tipping point.
(ok "it rounds at half a shift, not at a whole one"
    (and (= (fbank-num-frames 239) 1) (= (fbank-num-frames 240) 2))
    (format nil "239 -> ~d, 240 -> ~d" (fbank-num-frames 239) (fbank-num-frames 240)))

(format t "~&== and the streaming half ==~%")
;; Frame f reads up to sample 160f+280, so it is settled once that many have arrived.
(ok "a frame is ready once its last sample has arrived"
    (and (= (fbank-frames-ready 279) 0) (= (fbank-frames-ready 280) 1))
    (format nil "279 -> ~d, 280 -> ~d" (fbank-frames-ready 279) (fbank-frames-ready 280)))
(ok "ready never exceeds the final count"
    (loop for n in '(0 1 79 80 160 400 1000 16000 44100)
          always (<= (fbank-frames-ready n) (fbank-num-frames n))))
;; The difference is the reflected tail — the frames that cannot exist until the end.
(ok "the tail is small and positive once there is signal"
    (loop for n in '(1000 16000 44100)
          always (<= 1 (- (fbank-num-frames n) (fbank-frames-ready n)) 3))
    (format nil "16000: ~d - ~d" (fbank-num-frames 16000) (fbank-frames-ready 16000)))

(format t "~&== the FFT, against spectra known in closed form ==~%")
(let* ((n 512) (plan (make-fft-plan n))
       ;; SINGLE-float: POWER-SPECTRUM declares (type f32v frame out) and is compiled
       ;; at (safety 0), so a double-float array is not refused — it is read as
       ;; whatever those bits mean, which is zeros and then an overflow.
       (frame (make-array n :element-type 'single-float :initial-element 0.0))
       (out (make-array (ash n -1) :element-type 'single-float)))
  ;; A constant signal is entirely bin 0.
  (fill frame 1.0)
  (power-spectrum plan frame out)
  (ok "a constant puts all its power in bin 0"
      (and (~= (aref out 0) (* 1d0 n n) 1d0)
           (loop for k from 1 below (ash n -1) always (< (aref out k) 1e-3)))
      (format nil "bin0=~,1f, max elsewhere=~,3e" (aref out 0)
              (loop for k from 1 below (ash n -1) maximize (aref out k))))
  ;; A sinusoid at exactly bin k is entirely bin k — no leakage, since it is periodic
  ;; in the window.
  (let ((k 7))
    (dotimes (i n) (setf (aref frame i) (float (cos (/ (* 2 pi k i) n)) 1.0)))
    (power-spectrum plan frame out)
    (let ((peak (loop for j from 0 below (ash n -1)
                      with best = 0 with bv = -1d0
                      do (when (> (aref out j) bv) (setf bv (aref out j) best j))
                      finally (return best))))
      (ok "a sinusoid at bin 7 peaks at bin 7" (= peak k) (format nil "peak at ~d" peak))
      (ok "…and puts nothing anywhere else"
          (loop for j from 0 below (ash n -1)
                always (or (= j k) (< (aref out j) (* 1e-4 (aref out k)))))))))
(ok "an FFT length that is not a power of two is refused"
    (handler-case (progn (make-fft-plan 500) nil) (error () t)))
(ok "…and one that is too short" (handler-case (progn (make-fft-plan 2) nil) (error () t)))

(format t "~&== the filterbank on signals with no words in them ==~%")
(let* ((fb (make-fbank))
       (silence (make-array 16000 :element-type 'single-float :initial-element 0.0))
       (feats (compute-features silence :fbank fb))
       (shape (mill:tensor-shape feats))
       (data (mill:tensor-data feats)))
  (ok "silence produces the frame count the arithmetic promised"
      (= (aref shape 0) (fbank-num-frames 16000))
      (format nil "~d frames" (aref shape 0)))
  (ok "…with one value per mel bin" (= (aref shape 1) +num-bins+)
      (format nil "~d bins" (aref shape 1)))
  ;; log(0) is -inf; the floor is what keeps silence finite.
  (ok "…and every bin is finite, because a log of zero was floored"
      (loop for i below (length data)
            always (let ((v (aref data i)))
                     (and (not (sb-ext:float-nan-p v))
                          (not (sb-ext:float-infinity-p v)))))
      "no NaN, no -inf")
  ;; Every frame of a constant signal is the same frame.
  (let* ((dc (make-array 16000 :element-type 'single-float :initial-element 0.5))
         (df (mill:tensor-data (compute-features dc :fbank fb)))
         (bins +num-bins+))
    (ok "a constant signal gives identical interior frames"
        (loop for b below bins
              always (~= (aref df (+ (* 40 bins) b)) (aref df (+ (* 60 bins) b)) 1e-5))
        "DC is removed per frame, so every interior frame sees the same thing")))

(format t "~&== word error rate is counting ==~%")
(ok "a transcript against itself is 0"
    (~= (word-error-rate "the quick brown fox" "the quick brown fox") 0d0))
(ok "one wrong word in four is a quarter"
    (~= (word-error-rate "the quick brown fox" "the quick brown dog") 0.25d0)
    (format nil "~,3f" (word-error-rate "the quick brown fox" "the quick brown dog")))
(ok "a dropped word counts once"
    (~= (word-error-rate "the quick brown fox" "the quick fox") 0.25d0))
(ok "an added word counts once"
    (~= (word-error-rate "the quick brown fox" "the very quick brown fox") 0.25d0))
(ok "an empty hypothesis loses every word"
    (~= (word-error-rate "the quick brown fox" "") 1d0))
(ok "an empty reference has no rate rather than a division by zero"
    (~= (word-error-rate "" "anything at all") 0d0))
(multiple-value-bind (rate s d i n) (word-error-rate "a b c d" "a x c")
  (declare (ignore rate))
  (ok "the parts are reported separately" (and (= s 1) (= d 1) (= i 0) (= n 4))
      (format nil "sub ~d del ~d ins ~d of ~d" s d i n)))
(ok "whitespace is not a word"
    (~= (word-error-rate "the   quick" (format nil "the~c~cquick" #\Tab #\Newline)) 0d0))

(format t "~&== and the text the recognizer hands back ==~%")
;; The example in SENTENCE-CASE's own docstring.
(ok "shouting becomes a sentence"
    (string= (sentence-case "AFTER EARLY NIGHTFALL THE YELLOW LAMPS WOULD LIGHT UP")
             "After early nightfall the yellow lamps would light up"))
(ok "empty text stays empty" (string= (sentence-case "") ""))
(ok "NIL is not an error" (string= (sentence-case nil) ""))
(ok "surrounding space is trimmed" (string= (sentence-case "  HELLO  ") "Hello"))
;; It deliberately does NOT invent punctuation or proper nouns — asserting that keeps
;; a future "improvement" from quietly inventing facts the recognizer never gave us.
(ok "it does not invent a full stop"
    (null (find #\. (sentence-case "THIS IS A SENTENCE"))))
(ok "it does not invent proper-noun capitals"
    (string= (sentence-case "I WENT TO PARIS") "I went to paris"))

(format t "~&~%~d passed, ~d failed~%" *pass* *fail*)
(finish-output)
(sb-ext:exit :code (if (plusp *fail*) 1 0))
