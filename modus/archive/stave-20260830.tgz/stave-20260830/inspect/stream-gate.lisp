;;;; stream-gate.lisp — the same audio, arriving late, must say the same thing.
;;;;
;;;;     sbcl --dynamic-space-size 8192 --load inspect/stream-gate.lisp
;;;;
;;;; src/stream.lisp claims the LISTENER is not an approximation of
;;;; RECOGNIZE-FILE but the same computation with the samples handed over a few
;;;; at a time.  That claim has exactly one honest test: feed a file in pieces
;;;; and compare the string, and do it at packet sizes chosen to land in the
;;;; wrong place.
;;;;
;;;; The awkward sizes are the point.  A stream that only ever received whole
;;;; feature frames would never exercise the two places this can go wrong — the
;;;; line between the frames that are settled and the frames that still reflect
;;;; off the end of the signal, and the chunk that becomes runnable partway
;;;; through a packet.  So the sizes here are a 20 ms G.711 frame (320 samples at
;;;; 16 kHz — a whole number of nothing), a prime, one sample, and one enormous
;;;; piece, which is the whole-file case arriving through the streaming door.
;;;;
;;;; Also gated: the FEATURES themselves, frame for frame, bit for bit.  The
;;;; transcript is the thing that matters and it is also forgiving — a feature
;;;; that is wrong in the last decimal usually still decodes to the same word,
;;;; which would let a real defect sit here looking green.  Comparing the front
;;;; end directly is what makes "identical, not merely equivalent" a measured
;;;; statement.

(asdf:load-system :stave)
(in-package #:stave)

(load (merge-pathnames "data.lisp"
                       (make-pathname :name nil :type nil
                                      :defaults (or *load-truename* *compile-file-truename*))))


(defparameter *export*
  (data-path "export/" "STAVE_EXPORT"))
(defparameter *wavs*
  (data-path "models/zipformer-en/test_wavs/" "STAVE_WAVS"))

(defparameter *cases* '("0" "1"))
(defparameter *packets* '(320 997 1 1000000))

(defun feed-in-packets (rec samples packet)
  "Transcribe SAMPLES through a LISTENER, PACKET samples at a time."
  (let ((ln (make-listener rec))
        (n (length samples)))
    (loop for at from 0 below n by packet
          do (listener-feed ln (subseq samples at (min n (+ at packet)))))
    (listener-finish ln)))

;;; ---- the front end, compared frame for frame -------------------------------

(defun stream-features (rec samples packet)
  "The features a LISTENER computes, as one tensor, for comparison with
COMPUTE-FEATURES over the same samples."
  (let ((ln (make-listener rec))
        (n (length samples)))
    (loop for at from 0 below n by packet
          do (listener-feed ln (subseq samples at (min n (+ at packet)))))
    ;; the tail frames, without the zero padding LISTENER-FINISH adds after them
    (%compute-frames ln (fbank-num-frames (ln-fed ln)))
    (values (ln-feats ln) (ln-frames ln) (ln-bins ln))))

(defun feature-mismatch (rec samples packet)
  "NIL if the streamed features are bit-identical to the whole-file ones, else a
description of the first frame and bin that differ."
  (let ((want (compute-features samples :fbank (make-fbank))))
    (multiple-value-bind (got frames bins) (stream-features rec samples packet)
      (cond
        ((/= frames (tensor-dim want 0))
         (format nil "~d frames, want ~d" frames (tensor-dim want 0)))
        (t
         (with-typed-data (w want :dtypes (:f32))
           (dotimes (i (* frames bins) nil)
             (unless (= (aref got i) (aref w i))
               (return (format nil "frame ~d bin ~d: ~,9e vs ~,9e"
                               (floor i bins) (mod i bins)
                               (aref got i) (aref w i)))))))))))

;;; ---- reset, which is the other half of a session ---------------------------

(defun two-utterances (rec a b)
  "A and B through ONE listener with a reset between them.  A session is a
sequence of utterances, and the second one must not be coloured by the first."
  (let ((ln (make-listener rec)))
    (listener-feed ln a)
    (listener-finish ln)
    (listener-reset ln)
    (listener-feed ln b)
    (listener-finish ln)
    (values (first (listener-done ln)) (listener-text ln))))

(defun main ()
  (let ((rec (load-recognizer *export*))
        (failures '()))
    (format t "~&models:  ~a~%" (namestring *export*))
    (format t "driving: window ~d frames, advance ~d~%~%" (rec-window rec) (rec-advance rec))
    (dolist (name *cases*)
      (let* ((path (merge-pathnames (format nil "~a.wav" name) *wavs*))
             (samples (read-wav path))
             (want (recognize-samples rec samples)))
        (format t "  ~a.wav (~,1f s, ~d words)~%" name
                (/ (length samples) 16000d0)
                (1+ (count #\Space want)))
        (dolist (packet *packets*)
          (let* ((label (if (> packet (length samples))
                            "all at once"
                            (format nil "~d samples (~,1f ms)" packet (/ packet 16d0))))
                 (bad (feature-mismatch rec samples packet))
                 (got (feed-in-packets rec samples packet)))
            (cond ((and (null bad) (string= got want))
                   (format t "    ~24a  features identical, transcript identical~%" label))
                  (t
                   (format t "    ~24a  DIFFERS~@[ — features ~a~]~@[~%~30t transcript: ~a~]~%"
                           label bad (unless (string= got want) got))
                   (push (format nil "~a.wav @ ~a" name label) failures)))))))
    ;; and a session of two utterances through one listener
    (let* ((a (read-wav (merge-pathnames "0.wav" *wavs*)))
           (b (read-wav (merge-pathnames "1.wav" *wavs*)))
           (want-a (recognize-samples rec a))
           (want-b (recognize-samples rec b)))
      (multiple-value-bind (got-a got-b) (two-utterances rec a b)
        (cond ((and (string= got-a want-a) (string= got-b want-b))
               (format t "~%  reset between utterances     both identical~%"))
              (t
               (format t "~%  reset between utterances     DIFFERS~%")
               (push "reset" failures)))))
    (cond ((null failures)
           (format t "~%GATE GREEN — a stream and a file compute the same thing~%"))
          (t
           (format t "~%GATE RED — ~{~a~^; ~}~%" (reverse failures))))
    (finish-output)
    (sb-ext:exit :code (if failures 1 0))))

(main)
