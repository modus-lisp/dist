;;;; node-gate.lisp — compare every node against onnxruntime, in graph order.
;;;;
;;;;     sbcl --dynamic-space-size 8192 --load inspect/node-gate.lisp
;;;;
;;;; A recognizer gives one bit of feedback at the end: the transcript is wrong.
;;;; That is not enough to find an arithmetic mistake in node 4000 of 9418.  So
;;;; the gate runs the graph and, as each node finishes, compares its output
;;;; against the value onnxruntime produced for the same node on the same input.
;;;; A wrong answer names the node that FIRST diverged, which is nearly always
;;;; the one with the bug in it — everything after is downstream damage.
;;;;
;;;; Integer and boolean tensors must match exactly; there is no such thing as a
;;;; nearly-right index.  Float tensors are compared with a tolerance, because a
;;;; different summation order is not a bug, and reported with their actual error
;;;; so that "passes" never hides a value that is drifting.
;;;;
;;;; Nothing in this model is random, so nothing is skipped: every value the dump
;;;; holds is compared, and a value with no fixture is counted and named rather
;;;; than passed over.
;;;;
;;;; STAVE_GRAPH and STAVE_FIXTURES pick which of the transducer's three graphs
;;;; is under test.  They are gated separately because they run separately — the
;;;; encoder once per chunk, the decoder and joiner once per emitted token.

(asdf:load-system :stave)
(asdf:load-system :mill/npy)      ; the .npy reader, so onnxruntime's dumps
(in-package #:stave)              ; can be read without a Python in the loop

(defparameter *fixtures*
  (data-path "fixtures-encoder/" "STAVE_FIXTURES"))
(defparameter *export*
  (data-path "export/encoder-epoch-99-avg-1-chunk-16-left-128.graph" "STAVE_GRAPH"))

(defparameter *atol* 1d-4)
(defparameter *rtol* 1d-4)

(defun load-manifest ()
  (with-open-file (s (merge-pathnames "manifest.sexp" *fixtures*) :external-format :utf-8)
    (let ((*read-eval* nil) (*package* (find-package '#:stave)))
      (read s))))

(defun fixture-index (manifest)
  "Value name -> the file number holding onnxruntime's answer for it."
  (let ((h (make-hash-table :test #'equal)))
    (loop for (n name dtype shape) in (getf manifest :values)
          do (progn dtype shape (setf (gethash name h) n)))
    h))

(defun read-fixture (n)
  (read-npy (merge-pathnames (format nil "values/~d.npy" n) *fixtures*)))

(defun feeds-from-fixtures (model)
  (loop for (name) in (model-inputs model)
        collect (cons name (read-npy (merge-pathnames (format nil "inputs/~a.npy" name)
                                                      *fixtures*)))))

(defun compare (ours theirs)
  "Values: pass-p, the error, how it was judged, and what fraction of the
allowance the error used.

That last is what this gate is actually read by.  The encoder's values span
thirty orders of magnitude — one Exp reaches 2e13 — so the largest absolute
error in the graph says nothing about whether anything is wrong; a value at 2e13
is allowed an error of 2e9 and should have one.  The fraction is comparable
across nodes, and it is the number that moves when a change breaks something."
  (cond ((not (equalp (tensor-shape ours) (tensor-shape theirs)))
         (values nil nil :shape 0d0))
        ((not (eq (tensor-dtype ours) (tensor-dtype theirs)))
         (values nil nil :dtype 0d0))
        ((member (tensor-dtype ours) '(:i64 :i32 :bool))
         (let ((d (tensor-max-abs-diff ours theirs)))
           (values (zerop d) d :exact (if (zerop d) 0d0 1d0))))
        (t (let* ((d (tensor-max-abs-diff ours theirs))
                  (scale (let ((m 0d0))
                           (with-typed-data (dt theirs :dtypes (:f32 :f64))
                             (dotimes (i (length dt))
                               (let ((a (abs (float (aref dt i) 1d0))))
                                 (when (> a m) (setf m a)))))
                           m))
                  (allowed (+ *atol* (* *rtol* scale))))
             (values (<= d allowed) d :tolerance (/ d allowed))))))

(defun order-outputs (errs declared)
  "The graph's outputs in the order the graph declares them rather than the order
the nodes happened to produce them, so that encoder_out — the one an answer
depends on — is first and the 98 carried state tensors follow."
  (sort (copy-list errs) #'<
        :key (lambda (e) (or (position (first e) declared :test #'string=) 9999))))

(defun run-gate (&key (stop-after 1) verbose)
  (let* ((manifest (load-manifest))
         (index (fixture-index manifest))
         (model (load-model *export*))
         (compared 0) (missing 0) (missing-names '())
         (worst 0d0) (worst-name nil)
         (tightest 0d0) (tightest-name nil) (tightest-err 0d0)
         (declared (mapcar #'first (model-outputs model)))
         (output-errs '())
         (failures '()))
    (format t "~&graph:    ~a~%" (file-namestring *export*))
    (format t "fixtures: ~a~%" (namestring *fixtures*))
    (format t "outputs:  ~d, first is ~a~%"
            (length (getf manifest :outputs)) (first (getf manifest :outputs)))
    (format t "nodes:    ~d, fixtures: ~d~%~%"
            (length (model-nodes model)) (length (getf manifest :values)))
    (handler-case
        (run-model
         model (feeds-from-fixtures model)
         :on-node
         (lambda (i node outs)
           (loop for name across (node-outputs node)
                 for ours in outs
                 do (cond
                      ((not (gethash name index))
                       (incf missing) (push name missing-names))
                      (t
                       (let ((theirs (read-fixture (gethash name index))))
                         (multiple-value-bind (ok err how frac) (compare ours theirs)
                           (incf compared)
                           (when (and err (> err worst))
                             (setf worst err worst-name name))
                           (when (> frac tightest)
                             (setf tightest frac tightest-name name
                                   tightest-err (or err 0d0)))
                           (when (member name declared :test #'string=)
                             (push (list name (or err 0d0) frac) output-errs))
                           (when verbose
                             (format t "~5d ~18a ~a  err ~,3e (~,3f of allowance)~%"
                                     i (node-op node) name (float (or err 0) 1d0) frac))
                           (unless ok
                             (push (list i (node-op node) (node-name node) name err how
                                         (coerce (tensor-shape ours) 'list)
                                         (coerce (tensor-shape theirs) 'list))
                                   failures)
                             (when (>= (length failures) stop-after)
                               (return-from run-gate
                                 (report compared missing missing-names worst worst-name
                                         tightest tightest-name tightest-err
                                         (order-outputs output-errs declared)
                                         (reverse failures) ours theirs)))))))))))
      (unimplemented-op (c)
        (format t "~&STOPPED: ~a~%~%" c)
        (format t "compared ~d values cleanly before that.~%" compared)
        (format t "~&still unimplemented, by node count:~%")
        (loop for (op . n) in (model-missing-ops model)
              do (format t "  ~5d  ~a~%" n op))
        (return-from run-gate nil)))
    (report compared missing missing-names worst worst-name
            tightest tightest-name tightest-err (order-outputs output-errs declared)
            (reverse failures) nil nil)))

(defun report (compared missing missing-names worst worst-name
               tightest tightest-name tightest-err output-errs failures ours theirs)
  (format t "~&~%compared ~d values against onnxruntime~%" compared)
  (when (plusp missing)
    (format t "~d had no fixture: ~{~a~^, ~}~@[ ...~]~%" missing
            (subseq (reverse missing-names) 0 (min 6 missing)) (> missing 6)))
  (format t "closest to the bar: ~,3f of the allowance, error ~,3e (~a)~%"
          tightest tightest-err tightest-name)
  (format t "largest raw error:  ~,3e (~a) — big only because that value is~%"
          worst worst-name)
  (when output-errs
    (format t "~&the graph's own outputs:~%")
    (loop for (name err frac) in output-errs
          repeat 4
          do (format t "  ~28a err ~,3e (~,3f of allowance)~%" name err frac))
    (when (> (length output-errs) 4)
      (format t "  ... and ~d more state tensors, worst ~,3f of allowance~%"
              (- (length output-errs) 4)
              (reduce #'max (mapcar #'third output-errs)))))
  (cond ((null failures)
         (format t "~%GATE GREEN — every comparable node matches within ~,1e + ~,1e*|ref|~%"
                 *atol* *rtol*)
         t)
        (t
         (format t "~%FIRST DIVERGENCE:~%")
         (loop for (i op name value err how oshape tshape) in failures
               do (format t "  node ~d: ~a ~a~%    value ~a~%    ~a~%"
                          i op name value
                          (case how
                            (:shape (format nil "shape ~a, onnxruntime says ~a" oshape tshape))
                            (:dtype "dtype disagrees")
                            (t (format nil "error ~,3e, allowed ~,1e + ~,1e*|ref| (shape ~a)"
                                       err *atol* *rtol* oshape)))))
         (when (and ours theirs (< (tensor-size ours) 200))
           (format t "~&  ours:  ") (print-tensor ours :limit 12)
           (format t "~&  theirs:") (print-tensor theirs :limit 12))
         nil)))

(defun main ()
  (let ((ok (run-gate)))
    (finish-output)
    (sb-ext:exit :code (if ok 0 1))))

(main)
