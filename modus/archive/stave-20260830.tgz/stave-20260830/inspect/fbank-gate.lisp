;;;; fbank-gate.lisp — the front end against kaldi, on signals speech never is.
;;;;
;;;;     sbcl --load inspect/fbank-gate.lisp
;;;;
;;;; The front end is the easiest part of a recognizer to get subtly wrong and
;;;; the hardest to notice getting wrong: features off by a constant, or by one
;;;; frame, still decode — just to the wrong words.  And unlike the graphs, there
;;;; is no per-node fixture to fall back on; a filterbank is one number per bin
;;;; and either it is kaldi's number or it is not.
;;;;
;;;; So the cases are chosen to break it rather than to represent it: silence,
;;;; where every bin hits the epsilon floor and a log would otherwise be -inf; an
;;;; impulse at sample 0, which is only right if the reflection off the start of
;;;; the file is right; constant DC, which is entirely removed and must come out
;;;; as silence; a 7900 Hz tone, which sits ABOVE the mel band's 7600 Hz edge so
;;;; that every bin holds nothing but the window's leakage; and a set of lengths
;;;; straddling a frame, a shift and half a shift, because snip_edges=false
;;;; starts frame 0 at sample -120 and rounds the frame count by half a shift.
;;;; Then the two real utterances, which are what the model actually has to hear.
;;;;
;;;; The frame COUNT is compared exactly.  An off-by-one there is a different
;;;; recognizer, not a rounding difference.
;;;;
;;;; The VALUES get a bar that varies per element, and how it varies is the
;;;; interesting part of this file.
;;;;
;;;;     bar = ATOL + CANCELLATION / (mel energy / frame power)
;;;;
;;;; A mel bin holding a billionth of its frame's spectral power is the tail of a
;;;; sum that has almost entirely cancelled.  The absolute error left in that sum
;;;; is set by the frame's power, not by the bin's, so the error in the bin's LOG
;;;; grows as the reciprocal of the fraction it holds — which is what the second
;;;; term says, with one constant and no threshold.
;;;;
;;;; It is not a courtesy extended to stave.  It is measured, and it is measured
;;;; on kaldi: the fixtures carry feats64.npy, the same algorithm in float64, and
;;;; against it kaldi's own float32 error reaches 3.4e-2 — seventy times the flat
;;;; bar — in bins whose value is around -15.6.  Down there kaldi's error swings
;;;; three orders of magnitude between neighbouring bins, 5.0e-6 in one bin of
;;;; the chirp and 4.7e-3 in another that carries LESS signal.  So a bar built on
;;;; kaldi's error at each element would be asking stave to win the same lottery,
;;;; and a single flat bar loose enough to survive down there would catch nothing
;;;; in the bins that carry the speech.
;;;;
;;;; The report prints how far the second term reaches, so that this cannot
;;;; quietly become a bar that passes everything: 1.89% of elements get slack
;;;; worth the name (the term at least doubles their allowance), while 96.7% get
;;;; effectively none — their bar is within 1% of ATOL — and the worst error
;;;; among those 199703 is 7.2e-5, a seventh of the flat bar.  So the leniency
;;;; is confined to the bins it was argued for, and everywhere else the gate is
;;;; a flat 5e-4 that stave clears with room.
;;;;
;;;; kaldi stays the authority on what the algorithm IS.  The float64 array is
;;;; only the error bar, and it cannot be the authority: it was written from the
;;;; same reading of kaldi as the Lisp was, so a misreading would sit in both.
;;;; That is what the comparison against kaldi is still for.

(asdf:load-system :stave)
(asdf:load-system :mill/npy)
(in-package #:stave)

(load (merge-pathnames "data.lisp"
                       (make-pathname :name nil :type nil
                                      :defaults (or *load-truename* *compile-file-truename*))))

(defun fixtures () (data-path "fixtures-fbank/" "STAVE_FBANK_FIXTURES"))

(defparameter *atol* 5d-4
  "What float32 is worth in a bin that holds a reasonable share of its frame.")

(defparameter *cancellation* 1d-12
  "The other end: how much log error one part in 1/x of the frame's power buys.
Calibrated from the measured worst case rather than chosen — at a bin holding
4.0e-10 of its frame, this allows 2.5e-3 and the observed disagreement is
1.6e-3.")

(defun case-names ()
  (with-open-file (s (merge-pathnames "cases.txt" (fixtures)))
    (loop for line = (read-line s nil) while line
          unless (string= line "") collect line)))

(defun npy (case name)
  (read-npy (merge-pathnames (format nil "~a/~a.npy" case name) (fixtures))))

(defun samples-of (tensor)
  (let ((out (make-array (tensor-size tensor) :element-type 'single-float)))
    (with-typed-data (d tensor :dtypes (:f32)) (replace out d))
    out))

(defstruct (verdict (:conc-name v-))
  (complaint nil)
  (elements 0)                          ; how many were compared
  (slack 0)                             ; how many got real help from the 2nd term
  (tightest 0d0) (where nil) (raw 0d0)  ; the closest approach to the bar
  (strict 0d0) (strict-n 0)             ; and among those the bar barely helped
  (over 0))

(defun run-case (name fb)
  (let* ((samples (samples-of (npy name "samples")))
         (want (npy name "feats"))
         (exact (npy name "feats64"))
         (power (npy name "power64"))
         (want-frames (if (= (tensor-rank want) 2) (tensor-dim want 0) 0))
         (got (compute-features samples :fbank fb))
         (frames (tensor-dim got 0))
         (bins (tensor-dim got 1))
         (v (make-verdict)))
    (cond
      ((/= frames want-frames)
       (setf (v-complaint v) (format nil "~d frames, kaldi says ~d" frames want-frames)))
      ((zerop frames))
      ((/= bins (tensor-dim want 1))
       (setf (v-complaint v) (format nil "~d bins, kaldi says ~d"
                                     bins (tensor-dim want 1))))
      (t (compare-features v got want exact power frames bins)))
    v))

(defun compare-features (v got want exact power frames bins)
  "Walk ours, kaldi's, float64's and the frame powers together."
  (with-typed-data (a got :dtypes (:f32))
    (with-typed-data (b want :dtypes (:f32))
      (with-typed-data (e exact :dtypes (:f64))
        (with-typed-data (p power :dtypes (:f64))
          (dotimes (f frames v)
            ;; A frame of exact silence has no power to take a share of, and
            ;; needs none: every bin is the floor, in both implementations, and
            ;; nothing has cancelled because nothing was added.  It gets ATOL,
            ;; and it clears it by being exactly equal.
            (let ((total (float (aref p f) 1d0))
                  (row (* f bins)))
              (dotimes (k bins)
                (let* ((i (+ row k))
                       (d (abs (- (float (aref a i) 1d0) (float (aref b i) 1d0))))
                       ;; the share of its frame this bin holds, from the float64
                       ;; answer: how much slack an element gets must not depend
                       ;; on the thing under test
                       (share (if (plusp total)
                                  (max (/ (exp (float (aref e i) 1d0)) total) 1d-30)
                                  1d0))
                       (bar (+ *atol* (/ *cancellation* share))))
                  (incf (v-elements v))
                  (when (> bar (* 2 *atol*)) (incf (v-slack v)))
                  ;; The two counters do not partition: SLACK is where the
                  ;; second term at least doubled the allowance, STRICT is where
                  ;; it did essentially nothing.  Between them is a band that
                  ;; belongs to neither, and saying so is cheaper than a number
                  ;; that would have to be explained away.
                  (when (< bar (* 1.01d0 *atol*))
                    (incf (v-strict-n v))
                    (setf (v-strict v) (max (v-strict v) d)))
                  (when (> (/ d bar) (v-tightest v))
                    (setf (v-tightest v) (/ d bar) (v-where v) (list f k) (v-raw v) d))
                  (when (> d bar) (incf (v-over v))))))))))))

(defun main ()
  ;; Nothing to compare against is not a failure — it is a gate that has not run, and
  ;; saying so plainly beats a FILE-DOES-NOT-EXIST backtrace on every machine that has
  ;; never had the fixtures.
  (with-data-or-skip ("kaldi fbank fixtures" (merge-pathnames "cases.txt" (fixtures)))
   (let ((fb (make-fbank)) (failures '()) (cases 0)
        (worst 0d0) (worst-case nil) (worst-where nil) (worst-raw 0d0)
        (total 0) (slack 0) (strict 0d0) (strict-n 0))
    (format t "~&fixtures: ~a~%" (namestring (fixtures)))
    (format t "bar:      ~,1e + ~,1e / (bin's share of its frame's power)~%~%"
            *atol* *cancellation*)
    (dolist (name (case-names))
      (incf cases)
      (let ((v (run-case name fb)))
        (cond
          ((v-complaint v)
           (format t "  ~16a SHAPE — ~a~%" name (v-complaint v))
           (push (format nil "~a: ~a" name (v-complaint v)) failures))
          (t
           (incf total (v-elements v))
           (incf slack (v-slack v))
           (setf strict (max strict (v-strict v)))
           (incf strict-n (v-strict-n v))
           (format t "  ~16a ~,3f of the bar~34t err ~,3e~@[  frame ~d~]~@[ bin ~d~]~62t~
                     ~[~:;  (~:*~d of ~d got slack)~]~%"
                   name (v-tightest v) (v-raw v)
                   (first (v-where v)) (second (v-where v))
                   (v-slack v) (v-elements v))
           (when (> (v-tightest v) worst)
             (setf worst (v-tightest v) worst-case name
                   worst-where (v-where v) worst-raw (v-raw v)))
           (when (plusp (v-over v))
             (push (format nil "~a: ~d elements over their bar, worst ~,2f of it (err ~,3e)"
                           name (v-over v) (v-tightest v) (v-raw v))
                   failures))))))
    (format t "~&~%~d elements over ~d cases, against kaldi_native_fbank~%" total cases)
    (format t "~d of them (~,2f%) were near enough to cancellation to get any slack~%"
            slack (* 100d0 (/ slack (max total 1))))
    (format t "~d got none worth the name (bar within 1% of ~,1e); worst there ~,3e~%"
            strict-n *atol* strict)
    (format t "closest to the bar: ~,3f of it, error ~,3e (~a, frame ~d bin ~d)~%"
            worst worst-raw worst-case (first worst-where) (second worst-where))
    (cond ((null failures)
           (format t "~%GATE GREEN — every frame count exact, every value inside its bar~%"))
          (t
           (format t "~%GATE RED — ~d cases:~%" (length failures))
           (dolist (f (reverse failures)) (format t "  ~a~%" f))))
    (finish-output)
    (sb-ext:exit :code (if failures 1 0)))))

(main)