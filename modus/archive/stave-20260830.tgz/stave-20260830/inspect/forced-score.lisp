;;;; forced-score.lisp — what the model thinks of a transcript it did not choose.
;;;;
;;;;     sbcl --dynamic-space-size 8192 --disable-debugger \
;;;;       --load inspect/forced-score.lisp --end-toplevel-options talk.m4a \
;;;;       "WHAT IT SAID" "WHAT IT SHOULD HAVE SAID"
;;;;
;;;; When a word comes out wrong there are two suspects and they need different
;;;; repairs.  Either the model gave the right answer a lower probability than
;;;; the wrong one — nothing a search can fix, and the fix is biasing or weights
;;;; — or the model would have scored the right answer higher and the search
;;;; never carried it far enough to find out, which is a pruning problem and is
;;;; fixed by widening the beam.  Guessing between the two is how people spend a
;;;; week on the wrong one.
;;;;
;;;; So: score both, the same way, over the same audio.  The number is the exact
;;;; log-probability the model assigns to a token sequence, summed over every
;;;; alignment of that sequence to the frames — the transducer forward
;;;; algorithm, on the same one-label-per-frame lattice src/recognize.lisp and
;;;; src/beam.lisp decode on, so what it measures is what they search.  Scores
;;;; are comparable to each other and to nothing else; a longer transcript
;;;; scores lower for being longer, which is why the interesting comparisons are
;;;; between transcripts that differ in a word or two.
;;;;
;;;; The tokenizer is the honest weak point.  We have the model's 500-piece
;;;; vocabulary but not the merge rules that built it, so words are split by
;;;; longest match, which is *a* valid spelling and not necessarily the one the
;;;; training data used.  A text's true probability is the sum over all its
;;;; spellings; what is printed here is one of them, so every score is a lower
;;;; bound.  That is fine for the comparison it exists to make and would not be
;;;; fine as a published number.

(load (merge-pathnames "audio.lisp" (or *load-truename* *default-pathname-defaults*)))
(in-package #:stave)

(load (merge-pathnames "data.lisp"
                       (make-pathname :name nil :type nil
                                      :defaults (or *load-truename* *compile-file-truename*))))


(defparameter *export*
  (data-path "export/" "STAVE_EXPORT"))

;;; ---------------------------------------------------------------- spelling

(defun piece-table (rec)
  "The vocabulary as a list of (piece . id), longest first, so a plain scan
finds the longest match."
  (let ((out '()))
    (loop for id from 0 below (length (rec-tokens rec))
          for piece = (aref (rec-tokens rec) id)
          when (and (plusp (length piece)) (char/= (char piece 0) #\<))
            do (push (cons piece id) out))
    (sort out #'> :key (lambda (x) (length (car x))))))

(defun tokenize-word (word table)
  "WORD as pieces, longest match first.  The first piece carries the word-start
marker; NIL if some character has no piece at all."
  (let ((s (concatenate 'string "▁" word))
        (out '()))
    (loop with at = 0
          while (< at (length s))
          for hit = (loop for (piece . id) in table
                          when (and (<= (+ at (length piece)) (length s))
                                    (string= piece s :start2 at
                                                     :end2 (+ at (length piece))))
                            return (cons piece id))
          do (if hit
                 (progn (push (cdr hit) out) (incf at (length (car hit))))
                 (return-from tokenize-word nil)))
    (nreverse out)))

(defun piece-id (piece rec)
  (or (position piece (rec-tokens rec) :test #'string=)
      (error "~s is not a piece in this vocabulary" piece)))

(defun tokenize (text rec)
  "TEXT as token ids.  An argument that already contains ▁ is taken as an
explicit spelling and used as given — the tokenizer picks one segmentation out
of the several a text has, and sometimes the question is about the others."
  (if (find #\▁ text)
      (mapcar (lambda (p) (piece-id p rec)) (word-list text))
      (let ((table (piece-table rec)))
        (loop for word in (word-list text)
              for pieces = (tokenize-word word table)
              unless pieces do (error "no spelling for ~s in this vocabulary" word)
              append pieces))))

(defun spell (ids rec)
  (format nil "~{~a~^ ~}" (mapcar (lambda (id) (aref (rec-tokens rec) id)) ids)))

;;; ------------------------------------------------------------- the forward

(defun forward-score (rec feats ys)
  "log P(YS | audio), summed over alignments.

ALPHA[u] is the probability of having emitted the first u labels by the frame
under consideration.  Each frame every live cell either stays put on blank or
advances one label, which is the same lattice the searches walk — a forward pass
over a different topology would answer a question about a recognizer we do not
have."
  (let* ((u (length ys))
         (ys-v (coerce ys 'vector))
         (window (rec-window rec))
         (advance (rec-advance rec))
         (chunks (chunk-count (tensor-dim feats 0) window advance))
         (padded (pad-features feats (+ (* (1- chunks) advance) window)))
         (state (start-decoding rec))
         (prefix (coerce (ds-hyp state) 'list))   ; the context blanks the decoder wants
         (alpha (make-array (1+ u) :element-type 'double-float
                                   :initial-element sb-ext:double-float-negative-infinity))
         (next (make-array (1+ u) :element-type 'double-float))
         (douts (make-array (1+ u)))
         (reached 0))
    (setf (aref alpha 0) 0d0)
    ;; The decoder is stateless over the last CONTEXT tokens, so every prefix's
    ;; answer is computed once for the whole file rather than once per frame.
    (dotimes (i (1+ u))
      (setf (aref douts i)
            (decoder-run rec (append prefix (coerce (subseq ys-v 0 i) 'list)))))
    (dotimes (c chunks)
      (let ((enc (encode-chunk rec state (window-tensor padded (* c advance) window))))
        (dotimes (i (tensor-dim enc 1))
          (let ((frame (frame-tensor enc i)))
            (fill next sb-ext:double-float-negative-infinity)
            (loop for k from 0 to (min reached u)
                  unless (= (aref alpha k) sb-ext:double-float-negative-infinity)
                    do (let ((lp (log-softmax
                                  (model-output-tensor
                                   (rec-joiner rec)
                                   (run-model (rec-joiner rec)
                                              (list (cons "encoder_out" frame)
                                                    (cons "decoder_out" (aref douts k))))))))
                         ;; stay: this frame said nothing
                         (setf (aref next k)
                               (log-add (aref next k)
                                        (+ (aref alpha k) (aref lp (rec-blank rec)))))
                         ;; advance: this frame said the next label
                         (when (< k u)
                           (setf (aref next (1+ k))
                                 (log-add (aref next (1+ k))
                                          (+ (aref alpha k) (aref lp (aref ys-v k))))))))
            (setf reached (min u (1+ reached)))
            (replace alpha next)))))
    (aref alpha u)))

;;; ------------------------------------------------------------------- main

(defun main (args)
  (unless (rest args)
    (format t "~&usage: ... forced-score.lisp AUDIO \"TRANSCRIPT\" [\"TRANSCRIPT\"...]~%")
    (sb-ext:quit :unix-status 2))
  (let* ((path (pathname (first args)))
         (texts (rest args))
         (rec (load-recognizer *export*)))
    (multiple-value-bind (samples seconds) (load-audio path (fbank-rate (rec-fbank rec)))
      (let ((feats (compute-features samples :fbank (rec-fbank rec)))
            (best nil) (best-score nil))
        (format t "~&~,1f s of audio, ~d feature frames~2%" seconds (tensor-dim feats 0))
        (dolist (text texts)
          (let* ((ys (tokenize (string-upcase text) rec))
                 (score (forward-score rec feats ys)))
            (format t "~&~,2f   ~a~%     spelled ~a~%~%" score text (spell ys rec))
            (when (or (null best-score) (> score best-score))
              (setf best-score score best text))))
        (format t "~&the model prefers: ~a~%" best)
        (finish-output)))))

(let ((args (rest sb-ext:*posix-argv*)))
  (main args))
(sb-ext:quit)
