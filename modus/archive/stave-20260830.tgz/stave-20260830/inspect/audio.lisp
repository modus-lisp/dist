;;;; audio.lisp — audio that is not already a 16 kHz wav, for the scripts here.
;;;;
;;;; Not part of the system.  stave depends on mill and nothing else, and
;;;; recognizing a file has no business requiring a codec library; but the tools
;;;; in this directory do want to point at whatever the operator actually has,
;;;; and reed decodes containers and codecs in Lisp, so nothing here reaches for
;;;; ffmpeg.  LOAD this, don't ASDF it — two inspect scripts share it and that is
;;;; the whole of its constituency.

(asdf:load-system :reed)
(asdf:load-system :stave)
(in-package #:stave)

(defun pcm->floats (pcm)
  "reed speaks 16-bit integers, the filterbank speaks single-floats in [-1,1].
Kaldi's own scaling is the same 32768, so this is the conversion and not a
choice."
  (let* ((s (reed:pcm-samples pcm))
         (out (make-array (length s) :element-type 'single-float)))
    (dotimes (i (length s) out)
      (setf (aref out i) (/ (float (aref s i) 1f0) 32768f0)))))

(defun load-audio (path rate &key quiet)
  "Samples at RATE, mono, from whatever PATH is.  Returns the samples and how
many seconds of audio they are.

RATE arrives as the filterbank's own float, because that is what a sample rate
is to a window length; reed counts samples, so it wants the integer."
  (let* ((rate (round rate))
         (type (string-downcase (or (pathname-type path) "")))
         (samples
           (if (string= type "wav")
               (multiple-value-bind (s got) (read-wav path)
                 (unless (= got rate)
                   (error "~a is ~d Hz and this does not resample wavs" path got))
                 s)
               (let ((pcm (cond ((member type '("m4a" "mp4" "aac" "adts") :test #'string=)
                                 (reed:decode-aac-file path))
                                ((string= type "mp3") (reed:decode-mp3-file path))
                                ((member type '("opus" "ogg") :test #'string=)
                                 (reed:decode-opus-file path))
                                (t (error "~a: no decoder for a .~a" path type)))))
                 (unless quiet
                   (format t "~&  ~a: ~d Hz, ~d channel~:p, ~,2f s~%"
                           (file-namestring path) (reed:pcm-sample-rate pcm)
                           (reed:pcm-channels pcm)
                           (/ (float (reed:pcm-frame-count pcm)) (reed:pcm-sample-rate pcm))))
                 (pcm->floats (reed:resample-pcm pcm rate :channels 1))))))
    (values samples (/ (float (length samples)) rate))))
