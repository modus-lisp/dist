;;;; profile.lisp — where a transcript's time actually goes.
;;;;
;;;;     sbcl --dynamic-space-size 8192 --load inspect/profile.lisp
;;;;
;;;; The recognizer runs at a bit over realtime and the obvious question before
;;;; optimizing anything is which part of it is slow.  There are three candidate
;;;; answers and they suggest completely different work: the filterbank (fix the
;;;; FFT), mill's arithmetic (fix a kernel), or the search around the graphs
;;;; (fix the loop).  Guessing between them from the source is how you spend a
;;;; day making a kernel twice as fast and the recognizer 3% faster.
;;;;
;;;; So this measures four things on one real utterance:
;;;;
;;;;   features   samples -> filterbank frames, before any graph runs
;;;;   graphs     everything inside RUN-MODEL, per op and per node (mill's
;;;;              own profiler), split by which of the three models it was
;;;;   search     the remainder — the per-frame Lisp between the graph calls
;;;;   total      wall clock, as the WER harness would have measured it
;;;;
;;;; The utterance is a real one from the corpus rather than a synthetic buffer,
;;;; because the shape of the work depends on how many tokens get emitted: the
;;;; decoder runs once per emitted token and the joiner once per frame, so a
;;;; silent buffer would profile a different program than a sentence does.
;;;;
;;;; Set STAVE_PROFILE_N to profile more than one utterance.  Numbers from a
;;;; contended machine are numbers about the machine, so run it alone.

(asdf:load-system :stave)
(in-package #:stave)

(load (merge-pathnames "data.lisp"
                       (make-pathname :name nil :type nil
                                      :defaults (or *load-truename* *compile-file-truename*))))


(defparameter *manifest*
  (data-path "librispeech-test-clean/manifest.tsv" "STAVE_MANIFEST"))
(defparameter *export*
  (data-path "export/" "STAVE_EXPORT"))
(defparameter *count*
  (let ((e (sb-posix:getenv "STAVE_PROFILE_N"))) (if e (parse-integer e) 3)))

(defun manifest-rows (path n)
  "N utterances spread over the corpus, as (id wav text)."
  (let ((rows '()))
    (with-open-file (s path :external-format :utf-8)
      (loop for line = (read-line s nil) while line
            do (let ((a (position #\Tab line))
                     (b (position #\Tab line :from-end t)))
                 (when (and a b (/= a b))
                   (push (list (subseq line 0 a) (subseq line (1+ a) b)) rows)))))
    (setf rows (coerce (nreverse rows) 'vector))
    (loop for i below (min n (length rows))
          collect (aref rows (floor (* i (length rows)) (max n 1))))))

;;; ---- attributing nodes to the model they came from -------------------------

(defun node-owners (rec)
  "Node -> which of the three graphs it belongs to.  mill profiles nodes, and
nothing in a node says which model it is in; this is the only place that knows."
  (let ((owner (make-hash-table :test #'eq)))
    (dolist (pair (list (cons "encoder" (rec-encoder rec))
                        (cons "decoder" (rec-decoder rec))
                        (cons "joiner" (rec-joiner rec))))
      (loop for n across (model-nodes (cdr pair))
            do (setf (gethash n owner) (car pair))))
    owner))

(defun report-by-model (table owner total)
  (let ((secs (make-hash-table :test #'equal))
        (calls (make-hash-table :test #'equal)))
    (maphash (lambda (node pe)
               (let ((m (gethash node owner "?")))
                 (incf (gethash m secs 0d0) (profile-seconds (pe-ticks pe)))
                 (incf (gethash m calls 0) (pe-calls pe))))
             table)
    (format t "~&  ~10a ~12a ~9a ~10a~%" "graph" "node calls" "seconds" "share")
    (dolist (m '("encoder" "decoder" "joiner" "?"))
      (let ((s (gethash m secs)))
        (when s
          (format t "  ~10a ~12d ~9,3f ~9,1f%~%"
                  m (gethash m calls 0) s (* 100 (/ s total))))))))

;;; ---- one utterance ---------------------------------------------------------

(defun profile-one (rec wav)
  (multiple-value-bind (samples rate) (read-wav wav)
    (let* ((seconds (/ (length samples) (float rate 1d0)))
           ;; the front end, alone
           (f0 (get-internal-real-time))
           (features (compute-features samples :fbank (rec-fbank rec)))
           (f1 (get-internal-real-time))
           (feature-secs (profile-seconds (- f1 f0)))
           ;; and then the whole thing, graphs profiled
           (t0 (get-internal-real-time))
           (text (with-profiling (decode-features rec features)))
           (t1 (get-internal-real-time))
           (total (profile-seconds (- t1 t0)))
           (graphs (reduce #'+ (op-profile *last-profile*) :key #'third
                                                           :initial-value 0d0)))
      (values seconds feature-secs total graphs text *last-profile*))))

;;; ---- main ------------------------------------------------------------------

(defun main ()
  (unless (probe-file *manifest*)
    (format t "~&no manifest at ~a — run tools/get-librispeech.sh first~%"
            (namestring *manifest*))
    (finish-output)
    (sb-ext:exit :code 2))
  (let* ((rows (manifest-rows *manifest* *count*))
         (rec (load-recognizer *export*))
         (owner (node-owners rec))
         (merged (make-hash-table :test #'eq))
         (audio 0d0) (feat 0d0) (wall 0d0) (graph 0d0))
    (format t "~&models:  ~a, ~d workers~%" (namestring *export*) *worker-count*)
    (format t "corpus:  ~d utterances~2%" (length rows))
    (dolist (row rows)
      (destructuring-bind (id wav) row
        (multiple-value-bind (secs f total g text table) (profile-one rec (pathname wav))
          (declare (ignore text))
          (incf audio secs) (incf feat f) (incf wall total) (incf graph g)
          ;; fold this utterance's nodes into the running table
          (maphash (lambda (node pe)
                     (let ((into (or (gethash node merged)
                                     (setf (gethash node merged)
                                           (make-profile-entry :op (pe-op pe)
                                                               :name (pe-name pe))))))
                       (incf (pe-calls into) (pe-calls pe))
                       (incf (pe-ticks into) (pe-ticks pe))))
                   table)
          (format t "~&  ~22a ~,1f s audio   ~,2f s wall (~,2fx)~%" id secs total
                  (/ secs total)))))
    (format t "~%~,1f s of audio in ~,2f s — ~,2fx realtime~2%"
            audio wall (/ audio wall))
    (format t "  ~14a ~9,3f ~9,1f%~%" "features" feat (* 100 (/ feat wall)))
    (format t "  ~14a ~9,3f ~9,1f%~%" "graphs" graph (* 100 (/ graph wall)))
    (format t "  ~14a ~9,3f ~9,1f%   (the loop around the graphs, and the~%"
            "everything else" (- wall graph feat) (* 100 (/ (- wall graph feat) wall)))
    (format t "  ~14a                        argument tensors it builds)~2%" "")
    (report-by-model merged owner graph)
    (terpri)
    (report-profile :table merged :nodes 12)
    (finish-output)))

(main)
(sb-ext:quit)
