;;;; transcript-gate.lisp — the whole thing, judged on what it says.
;;;;
;;;;     sbcl --dynamic-space-size 8192 --load inspect/transcript-gate.lisp
;;;;
;;;; Every other gate here compares numbers.  This one compares words, and it is
;;;; the only one that can fail for a reason none of the others can see: the node
;;;; gates prove that each graph computes what onnxruntime computes, and say
;;;; nothing about whether the graphs are being CALLED right — the window, the
;;;; advance between chunks, which 98 outputs carry to which 98 inputs, when the
;;;; decoder is re-run, what counts as blank.  All of that is this file's
;;;; business, and all of it is invisible until a word comes out wrong.
;;;;
;;;; It is also the answer to the question the fbank gate cannot answer.  Our
;;;; features differ from kaldi's by up to 4.8e-4 in bins near cancellation, and
;;;; whether that matters is not a matter of argument: either the transcript is
;;;; the same or it is not.
;;;;
;;;; The bar is equality.  A transcript is discrete — there is no such thing as
;;;; being close to the right word — so anything short of the same string is a
;;;; failure, and the report shows where the two first part company rather than
;;;; just that they did.
;;;;
;;;; What it is compared against is tools/make-feeds.py's answer for the same
;;;; file: the same model, the same chunking, the same greedy search, run against
;;;; onnxruntime in Python.  Not sherpa-onnx's output, which flushes less at the
;;;; end and stops 1.wav mid-word; and not the reference trans.txt shipped with
;;;; the model, which differs from what these weights actually produce by one
;;;; letter (DISHONOURED where the model says DISHONORED).  The thing to be
;;;; gated against is what this model, driven correctly, says.

(asdf:load-system :stave)
(in-package #:stave)

(load (merge-pathnames "data.lisp"
                       (make-pathname :name nil :type nil
                                      :defaults (or *load-truename* *compile-file-truename*))))


(defparameter *export*
  (data-path "export/" "STAVE_EXPORT"))
(defparameter *wavs*
  (data-path "models/zipformer-en/test_wavs/" "STAVE_WAVS"))
(defparameter *feeds*
  (data-path "" "STAVE_FEEDS"))

(defparameter *cases* '("0" "1"))

(defun expected (name)
  (with-open-file (s (merge-pathnames (format nil "feeds-~a/transcript.txt" name) *feeds*)
                     :external-format :utf-8)
    (string-trim '(#\Space #\Newline) (read-line s))))

(defun words (text)
  (let ((out '()) (start nil))
    (dotimes (i (length text))
      (cond ((char= (char text i) #\Space)
             (when start (push (subseq text start i) out) (setf start nil)))
            ((null start) (setf start i))))
    (when start (push (subseq text start) out))
    (nreverse out)))

(defun first-difference (got want)
  "Where two transcripts part company, in words, with a little either side."
  (let* ((a (words got)) (b (words want))
         (at (or (mismatch a b :test #'string=) (length a))))
    (format nil "~%    at word ~d of ~d~%      ours: ...~{~a ~}~%      want: ...~{~a ~}"
            at (length b)
            (subseq a (max 0 (- at 3)) (min (length a) (+ at 4)))
            (subseq b (max 0 (- at 3)) (min (length b) (+ at 4))))))

(defun main ()
  (let ((rec (load-recognizer *export*))
        (failures '()) (audio 0d0) (wall 0d0))
    (format t "~&models:  ~a~%" (namestring *export*))
    (format t "driving: window ~d frames, advance ~d, context ~d, ~d tokens~%~%"
            (rec-window rec) (rec-advance rec) (rec-context rec) (length (rec-tokens rec)))
    (dolist (name *cases*)
      (let* ((path (merge-pathnames (format nil "~a.wav" name) *wavs*))
             (want (expected name))
             (seconds (multiple-value-bind (samples rate) (read-wav path)
                        (/ (length samples) (float rate 1d0))))
             (start (get-internal-real-time))
             (got (recognize-file rec path))
             (took (/ (- (get-internal-real-time) start)
                      (float internal-time-units-per-second 1d0))))
        (incf audio seconds)
        (incf wall took)
        (cond ((string= got want)
               (format t "  ~a.wav  ~5,1f s of audio in ~5,1f s (~,2fx realtime), ~
                          ~d words, exact~%" name seconds took (/ seconds took)
                          (length (words got))))
              (t
               (format t "  ~a.wav  DIFFERS~a~%" name (first-difference got want))
               (push name failures)))))
    (format t "~%~,1f s of audio in ~,1f s of wall clock: ~,2fx realtime on ~d ~
               worker~:p~%" audio wall (/ audio wall) *worker-count*)
    (cond ((null failures)
           (format t "~%GATE GREEN — every transcript word for word~%"))
          (t
           (format t "~%GATE RED — ~{~a.wav~^, ~}~%" (reverse failures))))
    (finish-output)
    (sb-ext:exit :code (if failures 1 0))))

(main)
