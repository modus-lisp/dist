;;;; transcribe.lisp — transcribe an audio file that is not already a 16 kHz wav.
;;;;
;;;;     sbcl --dynamic-space-size 8192 --disable-debugger \
;;;;       --load inspect/transcribe.lisp --end-toplevel-options song.m4a
;;;;
;;;; stave's own front door is RECOGNIZE-FILE, which reads a RIFF wav at exactly
;;;; the rate the filterbank was built for and refuses anything else — on the
;;;; grounds that a recognizer should not quietly resample and a wrong rate is a
;;;; wrong transcript rather than a worse one.  Real audio is not that.  This
;;;; puts the missing two steps in front of it, and both are Lisp:
;;;;
;;;;   reed   decodes the container and the codec (MP3, AAC-LC in ADTS or MP4,
;;;;          Opus in Ogg, G.711) to interleaved PCM
;;;;   reed   downmixes to mono and resamples to 16 kHz
;;;;   stave  does the rest
;;;;
;;;; So there is no ffmpeg anywhere in the path and no libavcodec under it.  That
;;;; is the point rather than a convenience: this stack is aimed at a machine
;;;; that has no OS to borrow a decoder from, and an .m4a is exactly the kind of
;;;; thing that would otherwise smuggle a C dependency into a pure-Lisp pipeline
;;;; at the last step.
;;;;
;;;; A codec is lossy and a resampler is a filter, so what comes out here is not
;;;; the samples any other decoder would produce, and it is not gated to be.
;;;; What can be checked — and is, by --compare — is that a second decoding of
;;;; the same audio produces the same WORDS, which is the only property the
;;;; recognizer actually needs from its front end.

(load (merge-pathnames "audio.lisp" (or *load-truename* *default-pathname-defaults*)))
(in-package #:stave)

(load (merge-pathnames "data.lisp"
                       (make-pathname :name nil :type nil
                                      :defaults (or *load-truename* *compile-file-truename*))))


(defparameter *export*
  (data-path "export/" "STAVE_EXPORT"))

(defun reference-for (path)
  "What was actually said, if a .txt of the same name sits beside the audio.

Held to the recognizer's own form — upper case, no punctuation — because that is
what this model emits, and a comparison that normalizes both sides is a
comparison you can tune until it flatters you."
  (let ((txt (make-pathname :type "txt" :defaults path)))
    (when (probe-file txt)
      (with-open-file (s txt :external-format :utf-8)
        (let ((out (make-string-output-stream)))
          (loop for line = (read-line s nil) while line
                do (loop for c across line
                         do (write-char (if (alpha-char-p c) (char-upcase c)
                                            (if (char= c #\') c #\Space))
                                        out))
                   (write-char #\Space out))
          (format nil "~{~a~^ ~}" (word-list (get-output-stream-string out))))))))

(defun report-error-rate (reference text label)
  (multiple-value-bind (wer s d i n) (word-error-rate reference text)
    (format t "~&  ~10a WER ~5,1f%  (~d sub ~d del ~d ins over ~d words)~%"
            label (* 100 wer) s d i n)))

(defun main (paths)
  (unless paths
    (format t "~&usage: ... --load inspect/transcribe.lisp --end-toplevel-options FILE...~%")
    (sb-ext:quit :unix-status 2))
  (format t "~&models: ~a~%" *export*)
  (let* ((rec (load-recognizer *export*))
         (beam (let ((e (sb-posix:getenv "STAVE_BEAM"))) (and e (parse-integer e))))
         (lexicon (let ((e (sb-posix:getenv "STAVE_LEXICON")))
                    (when e (format t "~&lexicon: ~a~%" e) (load-lexicon e))))
         (penalty (let ((e (sb-posix:getenv "STAVE_PENALTY")))
                    (if e (let ((*read-eval* nil)) (float (read-from-string e) 1d0)) 1d0))))
    (dolist (p paths)
      (multiple-value-bind (samples seconds) (load-audio (pathname p) (fbank-rate (rec-fbank rec)))
        (let* ((t0 (get-internal-real-time))
               (text (recognize-samples rec samples :beam beam
                                                    :lexicon lexicon :penalty penalty))
               (elapsed (/ (float (- (get-internal-real-time) t0))
                           internal-time-units-per-second))
               (reference (reference-for (pathname p))))
          (format t "~&  ~,1f s of audio in ~,1f s (~,2fx realtime)~@[, beam ~d~]~2%~a~2%"
                  seconds elapsed (/ seconds elapsed) beam text)
          (when reference
            (format t "~&  reference: ~a~%" reference)
            (report-error-rate reference text (if beam (format nil "beam ~d" beam) "greedy"))
            (terpri)))))))

;;; SBCL eats --end-toplevel-options itself and leaves what follows in
;;; *POSIX-ARGV* after argv[0], so there is no marker left to look for.
(let ((args (rest sb-ext:*posix-argv*)))
  (main (or args (let ((e (sb-posix:getenv "STAVE_AUDIO"))) (and e (list e))))))
(sb-ext:quit)
