;;;; data.lisp — where stave's fixtures and models live, and what to do without them.
;;;;
;;;; Loaded by the gates; not part of the stave system.
;;;;
;;;; THE PATHS USED TO BE ABSOLUTE.  Every gate defaulted to /mnt/lisp/stave/..., a
;;;; volume on one machine, so on any other machine — including a CI runner — the
;;;; first thing a gate did was fail to open a file.  Not "no fixtures, nothing to
;;;; compare against", which is a true and useful thing to say, but a FILE-DOES-NOT-EXIST
;;;; backtrace, which reads like broken code.
;;;;
;;;; The location is still a preference and still right for that box: kaldi reference
;;;; output and a Zipformer export are large and belong on the big disk.  What changes
;;;; is that absence is now a fact the gate can report instead of an error it dies on.
;;;;
;;;; A skip is deliberately LOUD.  A gate that quietly passes when it has nothing to
;;;; test is worse than one that fails: it reports green forever and nobody notices the
;;;; data went away.

(require :sb-posix)   ; GETENV.  Not implied: --script and a bare sbcl both lack it,
                      ; and a package prefix is resolved when this file is READ.

(in-package #:stave)

(defparameter *data-roots*
  (list #p"/mnt/lisp/stave/"
        (merge-pathnames ".cache/stave/" (user-homedir-pathname)))
  "Where stave's big files might be, in order of preference.  STAVE_DATA overrides.")

(defun data-root ()
  "The first root that exists, or the last as a place to point people at.

   ASKED WHEN CALLED, not when this file was loaded: a DEFPARAMETER reading the
   environment freezes at load time, and in a saved core that is image-build time —
   the trap that silently disabled GLASS_EARS, GLASS_VOICE and SPOOL_ROOT."
  (let ((env (sb-posix:getenv "STAVE_DATA")))
    (or (and env (plusp (length env))
             (pathname (if (char= (char env (1- (length env))) #\/) env
                           (concatenate 'string env "/"))))
        (find-if #'probe-file *data-roots*)
        (car (last *data-roots*)))))

(defun data-path (relative &optional env-var)
  "RELATIVE under the data root, unless ENV-VAR names somewhere else outright."
  (let ((env (and env-var (sb-posix:getenv env-var))))
    (if (and env (plusp (length env)))
        (pathname (if (char= (char env (1- (length env))) #\/) env
                      (concatenate 'string env "/")))
        (merge-pathnames relative (data-root)))))

(defmacro with-data-or-skip ((what path) &body body)
  "Run BODY, or say plainly that WHAT is missing and exit 0.

   Exit 0 because a gate with no data has not FAILED — it has not run.  The
   distinction matters on a machine that has never had the fixtures, which is every
   machine except the one that made them."
  (let ((p (gensym)))
    `(let ((,p ,path))
       (if (probe-file ,p)
           (progn ,@body)
           (progn
             (format t "~&~%  SKIPPED — no ~a at ~a~%" ,what ,p)
             (format t "  This gate compares against reference data that is not in the~%")
             (format t "  repository.  Point STAVE_DATA at a directory holding it, or~%")
             (format t "  set the gate's own variable, and it will run.~%~%")
             (finish-output)
             (sb-ext:exit :code 0))))))
