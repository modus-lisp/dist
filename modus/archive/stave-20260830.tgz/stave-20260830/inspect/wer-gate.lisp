;;;; wer-gate.lisp — the recognizer against captioned speech, in one number.
;;;;
;;;;     bash tools/get-librispeech.sh          # once, ~350 MB
;;;;     sbcl --dynamic-space-size 8192 --load inspect/wer-gate.lisp
;;;;
;;;; The transcript gate holds two files to the exact words a Python/ort loop
;;;; produces from the same weights, which proves the graphs are being driven
;;;; right and proves nothing about whether the result is any good.  This gate
;;;; asks the other question: over hours of speech nobody chose for us, how
;;;; often is a word wrong?
;;;;
;;;; Word error rate is (substitutions + deletions + insertions) / reference
;;;; words — the word-level Levenshtein distance over the number of words that
;;;; should have been said.  It can exceed 1.  LibriSpeech references are
;;;; already uppercase and unpunctuated, which is the form this model emits, so
;;;; nothing has to be normalized away and no normalizer can quietly flatter us.
;;;;
;;;; Two things are measured, not one.  Greedy is what the transcript gate
;;;; holds and what ships by default; beam is src/beam.lisp.  A search that
;;;; keeps more opinions ought to be at least as good as one that keeps one,
;;;; and that "ought" is the only claim here strong enough to fail the gate on
;;;; its own.  The absolute bar below is a ratchet on our own measurement, not
;;;; somebody else's published number — we have no provenance file for these
;;;; weights, and a bar copied from a model card that might not be this model's
;;;; would be a bar that means nothing.
;;;;
;;;; The subset is strided, not the first N lines.  test-clean is ordered by
;;;; speaker and chapter, so the first two hundred utterances are two or three
;;;; readers in a row — a number measured on those is a number about them.

(asdf:load-system :stave)
(in-package #:stave)

(load (merge-pathnames "data.lisp"
                       (make-pathname :name nil :type nil
                                      :defaults (or *load-truename* *compile-file-truename*))))


(defparameter *manifest*
  (data-path "librispeech-test-clean/manifest.tsv" "STAVE_MANIFEST"))
(defparameter *export*
  (data-path "export/" "STAVE_EXPORT"))

(defparameter *count*
  (let ((e (sb-posix:getenv "STAVE_WER_N"))) (if e (parse-integer e) 200))
  "How many utterances to take.  0 means all 2620 (about four hours of compute
per configuration at current speed).")

(defparameter *bar* 0.030d0
  "The greedy word error rate this may not exceed.  The first measurement on 200
strided utterances was 2.35%; the bar is 3%, which is room for the subset
changing size and not much else.  Tighten it when the recognizer gets better,
never loosen it to make a run pass.")

;;; ------------------------------------------------------------------ corpus

(defun split-tab (line)
  (let ((out '()) (start 0))
    (dotimes (i (length line))
      (when (char= (char line i) #\Tab)
        (push (subseq line start i) out)
        (setf start (1+ i))))
    (push (subseq line start) out)
    (nreverse out)))

(defun read-manifest (path)
  "Every (id wav text) the corpus script wrote."
  (with-open-file (s path :external-format :utf-8)
    (loop for line = (read-line s nil)
          while line
          for fields = (split-tab line)
          when (= (length fields) 3) collect fields)))

(defun stride-subset (rows n)
  "N rows spread evenly over ROWS, so the sample spans readers rather than
starting with three of them."
  (let ((total (length rows)))
    (if (or (zerop n) (>= n total))
        rows
        (loop with v = (coerce rows 'vector)
              for i below n
              collect (aref v (floor (* i total) n))))))

;;; ------------------------------------------------------------- the measure

;;; The counting itself is src/wer.lisp — the front door wants it too, and a
;;; measure that lives in two places is a measure with two definitions.

;;; -------------------------------------------------------------- the sweep

(defstruct (tally (:conc-name tally-))
  (label "" :type string)
  (subs 0) (dels 0) (inss 0) (words 0)
  (audio 0d0 :type double-float) (wall 0d0 :type double-float)
  (texts '()))

(defun tally-errors (tl) (+ (tally-subs tl) (tally-dels tl) (tally-inss tl)))
(defun tally-wer (tl)
  (if (zerop (tally-words tl)) 0d0 (/ (tally-errors tl) (float (tally-words tl) 1d0))))

(defun run-config (rec rows label beam &key lexicon (penalty 0d0))
  "Every utterance once, under one search."
  (let ((tl (make-tally :label label)))
    (dolist (row rows tl)
      (destructuring-bind (id wav text) row
        (declare (ignore id))
        (let* ((path (pathname wav))
               (seconds (multiple-value-bind (samples rate) (read-wav path)
                          (/ (length samples) (float rate 1d0))))
               (start (get-internal-real-time))
               (got (recognize-file rec path :beam beam
                                             :lexicon lexicon :penalty penalty))
               (took (/ (- (get-internal-real-time) start)
                        (float internal-time-units-per-second 1d0)))
               (ref (word-list text)))
          (multiple-value-bind (s d i) (align-words ref (word-list got))
            (incf (tally-subs tl) s) (incf (tally-dels tl) d) (incf (tally-inss tl) i)
            (incf (tally-words tl) (length ref))
            (incf (tally-audio tl) seconds) (incf (tally-wall tl) took)
            (push got (tally-texts tl))))))
    (setf (tally-texts tl) (nreverse (tally-texts tl)))
    tl))

(defun report (tl)
  (format t "~&  ~10a  WER ~6,2f%   ~d sub ~d del ~d ins over ~d words   ~
             ~,2fx realtime~%"
          (tally-label tl) (* 100 (tally-wer tl))
          (tally-subs tl) (tally-dels tl) (tally-inss tl) (tally-words tl)
          (/ (tally-audio tl) (tally-wall tl)))
  (finish-output))

(defun show-changes (rows greedy beam n)
  "Up to N utterances where the beam said something else — the evidence for
whatever the two numbers claim."
  (let ((shown 0))
    (loop for row in rows
          for g in (tally-texts greedy)
          for b in (tally-texts beam)
          while (< shown n)
          unless (string= g b)
            do (incf shown)
               (format t "~&    ~a~%      ref:    ~a~%      greedy: ~a~%      beam:   ~a~%"
                       (first row) (third row) g b))
    (when (zerop shown)
      (format t "~&    the two searches agreed on every utterance in this subset~%"))))

;;; ------------------------------------------------------------------- main

(defun main ()
  (unless (probe-file *manifest*)
    (format t "~&no manifest at ~a — run tools/get-librispeech.sh first~%"
            (namestring *manifest*))
    (finish-output)
    (sb-ext:exit :code 2))
  (let* ((all (read-manifest *manifest*))
         (rows (stride-subset all *count*))
         (rec (load-recognizer *export*)))
    (format t "~&corpus:  ~d of ~d utterances from ~a~%"
            (length rows) (length all) (namestring *manifest*))
    (format t "models:  ~a, ~d workers~2%" (namestring *export*) *worker-count*)
    (let* ((greedy (run-config rec rows "greedy" nil))
           (beam (progn (report greedy) (run-config rec rows "beam 4" 4))))
      (report beam)
      ;; The lexicon prior, at whatever prices were asked for.  It is swept
      ;; rather than set because the right price is an empirical question with
      ;; a corpus-shaped answer: test-clean is full of correct names no word
      ;; list has (GAMEWELL, ARONNAX, CONSEIL), and charging too much for those
      ;; costs more than STEECHOBS ever did.
      (let ((prices (let ((e (sb-posix:getenv "STAVE_WER_PENALTIES")))
                      (when e (with-input-from-string (s e)
                                (loop for v = (read s nil) while v collect (float v 1d0))))))
            (lex (let ((e (sb-posix:getenv "STAVE_LEXICON"))) (and e (load-lexicon e)))))
        (when (and prices lex)
          (dolist (p prices)
            (report (run-config rec rows (format nil "lex ~,1f" p) 4
                                :lexicon lex :penalty p)))))
      (format t "~%  the beam changed:~%")
      (show-changes rows greedy beam 8)
      (let ((failures '()))
        (when (> (tally-wer greedy) *bar*)
          (push (format nil "greedy WER ~,2f% is over the ~,2f% bar"
                        (* 100 (tally-wer greedy)) (* 100 *bar*))
                failures))
        (when (> (tally-wer beam) (tally-wer greedy))
          (push (format nil "the beam is worse than greedy (~,2f% vs ~,2f%) — ~
                             a wider search that loses is a bug in the search"
                        (* 100 (tally-wer beam)) (* 100 (tally-wer greedy)))
                failures))
        (cond ((null failures)
               (format t "~%GATE GREEN — greedy ~,2f%, beam ~,2f%, ~
                          ~:[no better~;~,2f points better~]~%"
                       (* 100 (tally-wer greedy)) (* 100 (tally-wer beam))
                       (< (tally-wer beam) (tally-wer greedy))
                       (* 100 (- (tally-wer greedy) (tally-wer beam)))))
              (t
               (format t "~%GATE RED~{~%  ~a~}~%" (reverse failures))))
        (finish-output)
        (sb-ext:exit :code (if failures 1 0))))))

(main)
