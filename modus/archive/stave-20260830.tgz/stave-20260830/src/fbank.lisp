;;;; fbank.lisp — 80-bin log-mel features, the way kaldi computes them.
;;;;
;;;; This is the front end the Zipformer was trained behind, so "the way kaldi
;;;; computes them" is the specification and not a stylistic preference.  Every
;;;; choice below is one kaldi made, and several of them are choices a from-first
;;;; principles implementation would make differently and be wrong:
;;;;
;;;;   * The window is Povey's — a Hann window raised to 0.85.  Not Hann, not
;;;;     Hamming.
;;;;   * DC removal happens per frame, before preemphasis, and it uses that
;;;;     frame's own mean.
;;;;   * Preemphasis treats sample 0 as its own predecessor rather than as
;;;;     following a zero, which is a one-line difference visible only in the
;;;;     first coefficient of every frame.
;;;;   * With SNIP-EDGES off, frame f starts at sample 160f - 120 — before the
;;;;     file, for f = 0 — and samples off either end are found by reflecting.
;;;;     The frame count is (n + 80) / 160, rounded down, so a file shorter than
;;;;     a frame still produces frames.
;;;;   * The mel triangles are laid over 256 FFT bins for a 512-point transform:
;;;;     the Nyquist bin is not one of them.
;;;;   * high_freq is given as -400, meaning 400 Hz below Nyquist.
;;;;
;;;; Held against kaldi_native_fbank by inspect/fbank-gate.lisp, on speech and on
;;;; signals no recording contains.

(in-package #:stave)

(defconstant +frame-length+ 400)        ; 25 ms at 16 kHz
(defconstant +frame-shift+ 160)         ; 10 ms
(defconstant +padded-length+ 512)       ; the next power of two
(defconstant +num-bins+ 80)
;; 2^-23, C's FLT_EPSILON — and NOT Lisp's SINGLE-FLOAT-EPSILON, which is half
;; that (it answers a different question: the smallest e with 1+e /= 1, rather
;; than the spacing at 1).  The two differ by a factor of two, and the whole
;; visible effect is the value a silent frame takes: -15.942 against -16.636.
(defconstant +epsilon+ (scale-float 1.0 -23))

(defstruct (fbank (:constructor %make-fbank))
  "The tables and scratch a stream reuses.  Nothing here depends on the audio,
so one of these serves a whole file — or a whole session."
  (rate 16000.0 :type single-float)
  (window (make-array 0 :element-type 'single-float) :type f32v)
  (plan nil :type (or null fft-plan))
  ;; the mel filters, as a first FFT bin and a run of weights for each: a
  ;; triangle touches perhaps a dozen of the 256 bins, and holding the zeros
  ;; would make the filterbank a 80x256 matrix multiply instead of a sum
  (bin-first (make-array 0 :element-type 'fixnum) :type (simple-array fixnum (*)))
  (bin-weights (make-array 0) :type simple-vector)
  (frame (make-array 0 :element-type 'single-float) :type f32v)
  (power (make-array 0 :element-type 'single-float) :type f32v))

(declaim (inline mel-scale))
(defun mel-scale (freq)
  "1127 ln(1 + f/700), in single-float because kaldi's is.

Precision matters here in a way it does not elsewhere: the mel value of an FFT
bin is compared against a triangle's edges, and that comparison is a discrete
decision about whether a whole bin's energy is in the filter or out of it.
Computing it more accurately than the reference does not split the difference —
it moves a bin."
  (declare (type single-float freq) (optimize (speed 3)))
  (* 1127.0 (log (+ 1.0 (/ freq 700.0)))))

(defun povey-window (n)
  "(0.5 - 0.5 cos(2*pi*i/(n-1)))^0.85 — a Hann window with the peak flattened.
Computed in double and stored single, which is what kaldi does."
  (let ((w (make-array n :element-type 'single-float))
        (a (/ (* 2 pi) (- n 1))))
    (dotimes (i n w)
      (setf (aref w i) (float (expt (- 0.5d0 (* 0.5d0 (cos (* a i)))) 0.85d0) 1.0)))))

(defun mel-filters (rate padded num-bins low-freq high-freq)
  "Values: the first FFT bin of each triangle, and its weights.

Laid over PADDED/2 bins, which for a 512-point transform is 256 — Nyquist is
not among them.  The triangles are equally spaced on the mel scale and overlap
by half, so there is one more spacing than there are bins at each end, hence the
division by num-bins+1."
  (let* ((num-fft (ash padded -1))
         (nyquist (* 0.5 rate))
         (high (if (> high-freq 0.0) high-freq (+ nyquist high-freq)))
         (fft-bin-width (/ rate padded))
         (mel-low (mel-scale low-freq))
         (mel-high (mel-scale high))
         (delta (/ (- mel-high mel-low) (+ num-bins 1)))
         (firsts (make-array num-bins :element-type 'fixnum))
         (weights (make-array num-bins))
         (scratch (make-array num-fft :element-type 'single-float)))
    (when (or (< low-freq 0.0) (<= high low-freq) (> high nyquist))
      (error "mel range ~a..~a Hz makes no sense at ~a Hz" low-freq high rate))
    (dotimes (bin num-bins (values firsts weights))
      (let ((left (+ mel-low (* bin delta)))
            (center (+ mel-low (* (+ bin 1) delta)))
            (right (+ mel-low (* (+ bin 2) delta)))
            (lo -1) (hi -1))
        (dotimes (i num-fft)
          (let ((mel (mel-scale (* fft-bin-width i))))
            (cond ((and (> mel left) (< mel right))
                   (setf (aref scratch i)
                         (if (<= mel center)
                             (/ (- mel left) (- center left))
                             (/ (- right mel) (- right center))))
                   (when (minusp lo) (setf lo i))
                   (setf hi i))
                  (t (setf (aref scratch i) 0.0)))))
        (when (minusp lo)
          (error "mel bin ~d covers no FFT bin: ~d bins is too many for ~a Hz"
                 bin num-bins rate))
        (setf (aref firsts bin) lo
              (aref weights bin) (subseq scratch lo (+ hi 1)))))))

(defun make-fbank (&key (rate 16000.0) (num-bins +num-bins+)
                        (low-freq 20.0) (high-freq -400.0))
  (let ((rate (float rate 1.0)))
    (multiple-value-bind (firsts weights)
        (mel-filters rate +padded-length+ num-bins (float low-freq 1.0)
                     (float high-freq 1.0))
      (%make-fbank
       :rate rate
       :window (povey-window +frame-length+)
       :plan (make-fft-plan +padded-length+)
       :bin-first firsts :bin-weights weights
       :frame (make-array +padded-length+ :element-type 'single-float)
       :power (make-array (ash +padded-length+ -1) :element-type 'single-float)))))

(defun fbank-num-frames (num-samples)
  "How many frames kaldi produces from NUM-SAMPLES once the stream has ended.

With snip_edges off a frame is centred on its shift rather than starting at it,
so the count rounds to the nearest shift instead of truncating: 79 samples give
nothing and 80 give a frame, out of a 400-sample window that is mostly
reflection.  A shorter file is not an error."
  (declare (type fixnum num-samples))
  (max 0 (floor (+ num-samples (ash +frame-shift+ -1)) +frame-shift+)))

(defun fbank-frames-ready (num-samples)
  "How many frames NUM-SAMPLES yields WITHOUT reflecting off the end — the frames
a stream can compute now and never has to revisit.

Frame f reads samples 160f-120 up to 160f+280, so it is settled once that many
have arrived; the reflection at the START is off sample 0, which a stream has
had since the beginning.  The difference between this and FBANK-NUM-FRAMES is
the tail: two or three frames that are partly the end of the signal reflected
back, and which therefore cannot be computed until the signal has ended."
  (declare (type fixnum num-samples))
  (max 0 (floor (- num-samples (ash (- +frame-length+ +frame-shift+) -1)) +frame-shift+)))

(defun extract-frame (samples f out window &optional (end (length samples)))
  "Fill OUT with frame F: WINDOW-LENGTH samples, DC-removed, preemphasized and
windowed, then zeros to the padded length.

END is where the signal stops, which is not always where the buffer does.  A
stream holds its audio in a buffer it grows ahead of what has arrived, and the
reflection off the end is a statement about the SIGNAL — reflecting off the
buffer's capacity instead would fold in whatever has not been recorded yet.
Left alone it is the buffer's length, which is the whole-file case."
  (declare (type f32v samples out window) (type fixnum f end)
           (optimize (speed 3) (safety 0)))
  (let* ((n end)
         (start (- (* f +frame-shift+) (ash (- +frame-length+ +frame-shift+) -1)))
         (sum 0.0))
    (declare (type fixnum n start) (type single-float sum))
    (assert (plusp n))
    ;; off either end, reflect: sample -1 is sample 0, and the sample after the
    ;; last is the last.  Repeatedly, because a file can be shorter than a frame
    ;; and then a single reflection still lands outside.
    (dotimes (s +frame-length+)
      (let ((i (+ s start)))
        (declare (type fixnum i))
        (loop while (or (minusp i) (>= i n))
              do (setf i (if (minusp i) (- (- i) 1) (- (* 2 n) 1 i))))
        (setf (aref out s) (aref samples i))
        (incf sum (aref samples i))))
    ;; DC removal, on this frame's own mean
    (let ((mean (/ sum (float +frame-length+ 1.0))))
      (dotimes (s +frame-length+) (decf (aref out s) mean)))
    ;; preemphasis, backwards so each sample still sees the original before it —
    ;; and sample 0 is its own predecessor, which is kaldi's choice and not an
    ;; oversight: it leaves the first coefficient scaled by 1-a rather than
    ;; carrying a step from silence
    (loop for s of-type fixnum from (- +frame-length+ 1) above 0
          do (decf (aref out s) (* 0.97 (aref out (- s 1)))))
    (decf (aref out 0) (* 0.97 (aref out 0)))
    (dotimes (s +frame-length+) (setf (aref out s) (* (aref out s) (aref window s))))
    (loop for s of-type fixnum from +frame-length+ below +padded-length+
          do (setf (aref out s) 0.0))
    out))

(defun apply-mel (fb power out offset)
  "Sum each triangle over the power spectrum, floor, and take the log."
  (declare (type f32v power out) (type fixnum offset)
           (optimize (speed 3) (safety 0)))
  (let ((firsts (fbank-bin-first fb))
        (weights (fbank-bin-weights fb)))
    (declare (type (simple-array fixnum (*)) firsts) (type simple-vector weights))
    (dotimes (b (length firsts) out)
      (let ((base (aref firsts b))
            (w (the f32v (svref weights b)))
            (acc 0.0))
        (declare (type single-float acc) (type fixnum base))
        (dotimes (i (length w))
          (incf acc (* (aref w i) (aref power (+ base i)))))
        ;; the floor is what keeps silence finite: an all-zero frame has zero
        ;; energy in every bin, and log of that is not a number a network can use
        (setf (aref out (+ offset b))
              (log (if (< acc +epsilon+) +epsilon+ acc)))))))

(defun compute-features (samples &key fbank)
  "Log-mel features for SAMPLES, as a mill tensor of shape (frames, 80).

A tensor rather than a list of frames because that is what the encoder is fed,
and because the chunk driver slices it by rows."
  (let* ((fb (or fbank (make-fbank)))
         (frames (fbank-num-frames (length samples)))
         (bins (length (fbank-bin-first fb)))
         (out (mill:make-tensor :f32 (vector frames bins))))
    (when (plusp frames)
      (let ((data (mill:tensor-data out))
            (frame (fbank-frame fb))
            (power (fbank-power fb)))
        (dotimes (f frames)
          (extract-frame samples f frame (fbank-window fb))
          (power-spectrum (fbank-plan fb) frame power)
          (apply-mel fb power data (* f bins)))))
    out))

(defun file-features (path &key fbank (rate 16000))
  "Features for a wav file, with the sample rate checked rather than assumed.
Nothing here resamples: a recognizer quietly fed 8 kHz audio as though it were
16 kHz produces confident nonsense, which is worse than an error."
  (multiple-value-bind (samples sr) (read-wav path)
    (unless (= sr rate)
      (error 'wav-error
             :text (format nil "~a is ~d Hz and this wants ~d; nothing here resamples"
                           path sr rate)))
    (compute-features samples :fbank fbank)))
