;;;; packages.lisp

(defpackage #:stave
  (:use #:common-lisp #:mill)
  (:documentation "Streaming speech recognition: audio in, text out.

The arithmetic is mill's.  What lives here is the two ends of it — the
filterbank front end that turns samples into the features a Zipformer was
trained on, and the transducer search that turns the encoder's output into
tokens.")
  (:export
   ;; getting the model
   #:fetch-model #:ensure-recognizer #:available-models
   #:*model-dir* #:*default-model* #:*model-catalogue*
   ;; audio in
   #:read-wav #:wav-error
   ;; the front end
   #:fbank #:make-fbank #:compute-features #:file-features
   #:fbank-num-frames #:fbank-frames-ready
   ;; the transform under it, which is worth reaching on its own
   #:make-fft-plan #:power-spectrum
   ;; text out
   #:recognizer #:load-recognizer #:recognizer-error
   #:recognize-file #:recognize-samples
   ;; the loop taken apart, for anything that wants partial results
   #:decode-state #:start-decoding #:encode-chunk #:search-chunk
   #:decode-features #:tokens-text #:sentence-case #:ds-hyp
   ;; ...and the loop driven by a clock, for audio that has not all arrived
   #:listener #:make-listener #:listener-feed #:listener-finish #:listener-reset
   #:listener-text #:listener-done #:listener-transcript
   #:listener-seconds #:listener-level
   ;; the beam, for when one opinion per frame is not enough
   #:hypothesis #:hyp-ys #:hyp-log-prob #:decode-features-beam #:best-hypothesis
   ;; a prior the weights do not have: a list of words that exist
   #:lexicon #:load-lexicon #:word-known-p #:word-prefix-p #:make-word-prior
   ;; and how wrong it was, if you have something to compare against
   #:word-list #:align-words #:word-error-rate))
