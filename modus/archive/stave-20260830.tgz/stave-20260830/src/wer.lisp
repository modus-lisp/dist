;;;; wer.lisp — how wrong a transcript is, counted the standard way.
;;;;
;;;; A transcript is discrete, so there is no distance between what was said and
;;;; what was heard except the number of edits between them.  Word error rate is
;;;; the word-level Levenshtein distance over the number of words that should
;;;; have been said: (substitutions + deletions + insertions) / N.  It can exceed
;;;; 1, because a recognizer that will not stop talking can insert more words
;;;; than exist.
;;;;
;;;; This lives in the library rather than in inspect/ because two different
;;;; things want it — the corpus gate and the front door, which will tell you how
;;;; it did if you happen to have a reference — and because the only way to make
;;;; a WER number flattering is to normalize before counting.  Nothing here
;;;; normalizes.  Case and punctuation are the caller's business, and the caller
;;;; should be able to see what it decided.

(in-package #:stave)

(defun word-list (text)
  "TEXT split on whitespace.  Not a tokenizer: a transcript is already words."
  (let ((out '()) (start nil))
    (dotimes (i (length text))
      (if (member (char text i) '(#\Space #\Tab #\Newline #\Return))
          (when start (push (subseq text start i) out) (setf start nil))
          (unless start (setf start i))))
    (when start (push (subseq text start) out))
    (nreverse out)))

(defun align-words (ref hyp)
  "REF against HYP, as (values substitutions deletions insertions).

The three are reported apart because they fail differently: deletions are a
recognizer that stopped listening, insertions are one that would not stop
talking, and substitutions are the only kind that is about hearing.  Ties are
broken toward substitution, then deletion, which is the conventional order and
matters only for how a given error is labelled, never for the total."
  (let* ((r (coerce ref 'vector))
         (h (coerce hyp 'vector))
         (n (length r))
         (m (length h))
         (d (make-array (list (1+ n) (1+ m)) :element-type 'fixnum))
         ;; 0 match, 1 substitution, 2 deletion (a ref word with no hyp word),
         ;; 3 insertion
         (op (make-array (list (1+ n) (1+ m)) :element-type 'fixnum)))
    (dotimes (i (1+ n)) (setf (aref d i 0) i (aref op i 0) 2))
    (dotimes (j (1+ m)) (setf (aref d 0 j) j (aref op 0 j) 3))
    (setf (aref op 0 0) 0)
    (loop for i from 1 to n do
      (loop for j from 1 to m do
        (let* ((same (string= (aref r (1- i)) (aref h (1- j))))
               (sub (+ (aref d (1- i) (1- j)) (if same 0 1)))
               (del (1+ (aref d (1- i) j)))
               (ins (1+ (aref d i (1- j))))
               (best (min sub del ins)))
          (setf (aref d i j) best
                (aref op i j) (cond ((= best sub) (if same 0 1))
                                    ((= best del) 2)
                                    (t 3))))))
    (let ((s 0) (dl 0) (in 0) (i n) (j m))
      (loop while (or (plusp i) (plusp j))
            do (case (aref op i j)
                 (0 (decf i) (decf j))
                 (1 (incf s) (decf i) (decf j))
                 (2 (incf dl) (decf i))
                 (t (incf in) (decf j))))
      (values s dl in))))

(defun word-error-rate (reference hypothesis)
  "(values wer substitutions deletions insertions reference-words) for two
strings.  A reference of no words has no error rate; it returns 0."
  (let ((ref (word-list reference)))
    (multiple-value-bind (s d i) (align-words ref (word-list hypothesis))
      (values (if (null ref) 0d0 (/ (+ s d i) (float (length ref) 1d0)))
              s d i (length ref)))))
