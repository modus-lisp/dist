;;;; fft.lisp — the power spectrum of a real frame.
;;;;
;;;; The filterbank asks one question of the Fourier transform — how much energy
;;;; is at each frequency — and never asks for the phase back.  So this computes
;;;; |X(k)|^2 directly and there is no inverse anywhere.
;;;;
;;;; A real transform of length N is a complex one of length N/2 plus a fixup:
;;;; pack the even samples as the real part and the odd ones as the imaginary
;;;; part, transform that, and separate the two spectra out again by symmetry.
;;;; Half the butterflies and half the memory, for one extra pass.  At 100 frames
;;;; a second that is not the difference between working and not, but this has to
;;;; run on a Pi with everything else, and the fixup is fifteen lines.
;;;;
;;;; The plan is built once per size and holds its twiddles, so a stream pays for
;;;; sin and cos once rather than once per frame.  Everything is single-float:
;;;; the features are compared against an implementation that is also
;;;; single-float, and computing more precisely than the reference only moves the
;;;; disagreement somewhere else.

(in-package #:stave)

(deftype f32v () '(simple-array single-float (*)))

(defstruct (fft-plan (:constructor %make-fft-plan))
  "Everything a size needs that does not change frame to frame."
  (n 0 :type fixnum)                    ; the real transform's length
  (half 0 :type fixnum)                 ; n/2, the complex transform's length
  (rev (make-array 0 :element-type 'fixnum) :type (simple-array fixnum (*)))
  (cos-half (make-array 0 :element-type 'single-float) :type f32v)
  (sin-half (make-array 0 :element-type 'single-float) :type f32v)
  (cos-full (make-array 0 :element-type 'single-float) :type f32v)
  (sin-full (make-array 0 :element-type 'single-float) :type f32v)
  (re (make-array 0 :element-type 'single-float) :type f32v)
  (im (make-array 0 :element-type 'single-float) :type f32v))

(defun make-fft-plan (n)
  "N must be a power of two and at least 4."
  (unless (and (>= n 4) (zerop (logand n (1- n))))
    (error "an FFT of length ~d: this wants a power of two, 4 or more" n))
  (let* ((half (ash n -1))
         (rev (make-array half :element-type 'fixnum))
         (cos-half (make-array half :element-type 'single-float))
         (sin-half (make-array half :element-type 'single-float))
         (cos-full (make-array (1+ (ash half -1)) :element-type 'single-float))
         (sin-full (make-array (1+ (ash half -1)) :element-type 'single-float))
         (bits (round (log half 2))))
    ;; bit-reversal permutation, so the transform can run in place
    (dotimes (i half)
      (let ((r 0) (v i))
        (dotimes (b bits) (setf r (logior (ash r 1) (logand v 1)) v (ash v -1)))
        (setf (aref rev i) r)))
    ;; e^{-2*pi*i*k/half} for the butterflies, and e^{-2*pi*i*k/n} for the fixup
    (dotimes (k half)
      (let ((a (/ (* -2 pi k) half)))
        (setf (aref cos-half k) (float (cos a) 1.0)
              (aref sin-half k) (float (sin a) 1.0))))
    (dotimes (k (1+ (ash half -1)))
      (let ((a (/ (* -2 pi k) n)))
        (setf (aref cos-full k) (float (cos a) 1.0)
              (aref sin-full k) (float (sin a) 1.0))))
    (%make-fft-plan :n n :half half :rev rev
                    :cos-half cos-half :sin-half sin-half
                    :cos-full cos-full :sin-full sin-full
                    :re (make-array half :element-type 'single-float)
                    :im (make-array half :element-type 'single-float))))

(defun power-spectrum (plan frame out)
  "Write |X(k)|^2 for k = 0 .. N/2-1 into OUT, from the N real samples in FRAME.

The Nyquist bin is not produced.  Nothing downstream uses it: the mel filters
are laid out over N/2 bins and stop one short of Nyquist, which is also where
kaldi stops."
  (declare (type fft-plan plan) (type f32v frame out)
           (optimize (speed 3) (safety 0)))
  (let* ((n (fft-plan-n plan))
         (half (fft-plan-half plan))
         (rev (fft-plan-rev plan))
         (cs (fft-plan-cos-half plan)) (sn (fft-plan-sin-half plan))
         (cf (fft-plan-cos-full plan)) (sf (fft-plan-sin-full plan))
         (re (fft-plan-re plan)) (im (fft-plan-im plan)))
    (declare (type fixnum n half) (type (simple-array fixnum (*)) rev)
             (type f32v cs sn cf sf re im))
    (assert (>= (length frame) n))
    (assert (>= (length out) half))
    ;; even samples become the real part and odd ones the imaginary part, and
    ;; the bit-reversal is folded into the same pass
    (dotimes (i half)
      (let ((r (aref rev i)))
        (setf (aref re r) (aref frame (* 2 i))
              (aref im r) (aref frame (+ (* 2 i) 1)))))
    ;; iterative radix-2, decimation in time
    (let ((len 2))
      (declare (type fixnum len))
      (loop while (<= len half)
            do (let ((step (the fixnum (floor half len)))
                     (halflen (the fixnum (ash len -1))))
                 (loop for base of-type fixnum from 0 below half by len
                       do (dotimes (j halflen)
                            (let* ((k (* j step))
                                   (wr (aref cs k)) (wi (aref sn k))
                                   (a (+ base j)) (b (+ base j halflen))
                                   (xr (aref re b)) (xi (aref im b))
                                   (tr (- (* wr xr) (* wi xi)))
                                   (ti (+ (* wr xi) (* wi xr))))
                              (declare (type fixnum a b))
                              (setf (aref re b) (- (aref re a) tr)
                                    (aref im b) (- (aref im a) ti)
                                    (aref re a) (+ (aref re a) tr)
                                    (aref im a) (+ (aref im a) ti)))))
                 (setf len (ash len 1)))))
    ;; Separate the two interleaved spectra and recombine.  Z(k) holds the even
    ;; samples' transform in its conjugate-symmetric part and the odd samples'
    ;; in its antisymmetric part; X(k) = E(k) + e^{-2*pi*i*k/N} * O(k).
    (let ((quarter (ash half -1)))
      (declare (type fixnum quarter))
      ;; k = 0 is its own mirror: E(0) and O(0) are both real
      (let ((e (+ (aref re 0) (aref im 0))))
        (setf (aref out 0) (* e e)))
      (loop for k of-type fixnum from 1 to quarter
            do (let* ((m (- half k))
                      (ar (aref re k)) (ai (aref im k))
                      (br (aref re m)) (bi (aref im m))
                      (er (* 0.5 (+ ar br))) (ei (* 0.5 (- ai bi)))
                      (or* (* 0.5 (+ ai bi))) (oi (* 0.5 (- br ar)))
                      (wr (aref cf k)) (wi (aref sf k))
                      (tr (- (* wr or*) (* wi oi)))
                      (ti (+ (* wr oi) (* wi or*)))
                      (xr (+ er tr)) (xi (+ ei ti)))
                 (declare (type fixnum m))
                 (setf (aref out k) (+ (* xr xr) (* xi xi)))
                 ;; X(N/2 - k) falls out of the same four numbers, with no second
                 ;; twiddle to look up.  Both halves of the split are symmetric
                 ;; about k — E conjugates, O conjugates — and the twiddle itself
                 ;; satisfies W^(N/2-k) = -conj(W^k), so the recombination is the
                 ;; same product with two signs flipped.  That is why the twiddle
                 ;; table only runs to a quarter of N.
                 (when (< k quarter)
                   (let ((xr2 (- er tr)) (xi2 (- ti ei)))
                     (setf (aref out m) (+ (* xr2 xr2) (* xi2 xi2))))))))
    out))
