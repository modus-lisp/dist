;;;; fetch.lisp — get the model, in Lisp.
;;;;
;;;; stave ships no weights: the encoder alone is 262 MB in one file, and GitHub rejects anything
;;;; over 100 MB.  Compression does not rescue it — gzip -9 returns 92% of the original, because
;;;; trained float32 weights are close to incompressible noise — and the two ways to make it fit,
;;;; float16 and int8, both break the bit-exactness the node gates assert against onnxruntime.
;;;;
;;;; So it is fetched on first use, over weft's pure-CL TLS, and converted once by mill's own ONNX
;;;; reader.  No curl, no Python, no protobuf library: the machine doing this may be modus, where
;;;; there is nothing underneath the Lisp to shell out to.
;;;;
;;;; Unlike chord's default voice, this model CAN be redistributed — Apache-2.0, trained on
;;;; LibriSpeech (CC BY 4.0) — so a converted build could reasonably be published as a release
;;;; asset.  It is the size that keeps it out of the tree, not the licence.

(in-package #:stave)

(defparameter *model-catalogue*
  '(("zipformer-en-2023-06-26"
     "https://huggingface.co/csukuangfj/sherpa-onnx-streaming-zipformer-en-2023-06-26/resolve/main/"
     ("encoder-epoch-99-avg-1-chunk-16-left-128.onnx"
      "decoder-epoch-99-avg-1-chunk-16-left-128.onnx"
      "joiner-epoch-99-avg-1-chunk-16-left-128.onnx"
      "tokens.txt")
     "Apache-2.0; trained on LibriSpeech (CC BY 4.0) — redistributable with attribution"))
  "Model -> base URL, files, and what its licence permits.  The licence is stated because it is the
thing that decides what you may do with the result, and it is not in the download.")

(defparameter *model-dir*
  (or (uiop:getenv "STAVE_MODEL_DIR")
      (namestring (merge-pathnames ".stave/models/" (user-homedir-pathname))))
  "Where FETCH-MODEL puts models, and where ENSURE-RECOGNIZER looks.")

(defparameter *default-model* "zipformer-en-2023-06-26")

(defun available-models (&key (stream *standard-output*))
  (dolist (m *model-catalogue*)
    (format stream "~&  ~a~%    ~a~%" (first m) (fourth m)))
  (values))

(defun %fetch-to-file (url path)
  (let ((r (weft.fetch:fetch url)))
    (unless (= 200 (weft.fetch:response-status r))
      (error "stave: fetching ~a returned HTTP ~a" url (weft.fetch:response-status r)))
    (let ((body (weft.fetch:decompress-body (weft.fetch:response-headers r)
                                            (weft.fetch:response-body r))))
      (with-open-file (o path :direction :output :element-type '(unsigned-byte 8)
                              :if-exists :supersede :if-does-not-exist :create)
        (write-sequence body o))
      (length body))))

(defun fetch-model (&optional (name *default-model*) &key (dir *model-dir*) force keep-onnx)
  "Download NAME into DIR/NAME, convert the graphs, and return that directory.

The .onnx files are converted to mill's .graph + .bin once and then deleted: protobuf is how the
model is published, not how it should be read on every load.  On this encoder that is 6.9s of
parsing traded for a step that happens once."
  (let* ((entry (assoc name *model-catalogue* :test #'string=))
         (target (merge-pathnames (concatenate 'string name "/") dir)))
    (unless entry (error "stave: unknown model ~s.  (stave:available-models) lists them." name))
    (when (and (probe-file (merge-pathnames "tokens.txt" target))
               (directory (merge-pathnames "encoder-*.graph" target))
               (not force))
      (return-from fetch-model (namestring target)))
    (ensure-directories-exist target)
    (format *error-output* "~&stave: fetching ~a~%       licence: ~a~%" name (fourth entry))
    (finish-output *error-output*)
    (dolist (file (third entry))
      (let ((path (merge-pathnames file target)))
        (cond
          ((and (probe-file path) (not force))
           (format *error-output* "~&       ~a (already here)~%" file))
          (t (let ((n (%fetch-to-file (concatenate 'string (second entry) file) path)))
               (format *error-output* "~&       ~a  ~:d bytes~%" file n))))
        (finish-output *error-output*)
        ;; convert as each graph lands, so peak disk is one .onnx rather than three
        (when (string= "onnx" (pathname-type path))
          (format *error-output* "~&       converting ~a~%" (file-namestring path))
          (finish-output *error-output*)
          (mill:onnx->graph path target)
          (unless keep-onnx (ignore-errors (delete-file path))))))
    (format *error-output* "~&stave: ~a ready -> ~a~%" name (namestring target))
    (finish-output *error-output*)
    (namestring target)))

(defun ensure-recognizer (&optional (name *default-model*))
  "The recognizer, fetching and converting the model first if it is not already here."
  (let ((dir (merge-pathnames (concatenate 'string name "/") *model-dir*)))
    (load-recognizer (if (directory (merge-pathnames "encoder-*.graph" dir))
                         dir
                         (fetch-model name)))))
