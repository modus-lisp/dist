;;;; recognize.lisp — the loop: chunks in, tokens out.
;;;;
;;;; A transducer is three graphs that only mean something together.  The
;;;; encoder turns a window of features into a few frames of a 512-dimensional
;;;; summary and hands back the 98 tensors of state it will need next time; the
;;;; decoder turns the last two emitted tokens into a 512-dimensional summary of
;;;; where the sentence is; the joiner is asked, once per encoder frame, what
;;;; those two summaries say together, and answers with 500 logits.  The largest
;;;; is either blank — the search stays where it is and moves to the next frame
;;;; — or a token, which is appended and changes what the decoder says next.
;;;;
;;;; That is the whole search.  It is greedy: no beam, no lattice, no rescoring.
;;;; A beam would be a better recognizer, and it is not what the reference this
;;;; is gated against does, so it is not what this does yet.
;;;;
;;;; How the calls follow one another is not in the graphs — a graph describes
;;;; one call.  It is in the model's metadata, which mill now carries through the
;;;; export: decode_chunk_len is how many feature frames a chunk advances, the
;;;; window is the encoder's own declared input shape, and context_size is how
;;;; many past tokens the decoder is shown.  Nothing here is a constant read off
;;;; a model card.

(in-package #:stave)

(defstruct (recognizer (:conc-name rec-))
  "Three graphs, a vocabulary, and the numbers that say how to drive them."
  encoder decoder joiner
  (tokens #() :type simple-vector)      ; index -> the piece of text it stands for
  (window 0 :type fixnum)               ; feature frames per encoder call
  (advance 0 :type fixnum)              ; ...of which this many are new
  (context 0 :type fixnum)              ; tokens of history the decoder is shown
  (blank 0 :type fixnum)
  (fbank nil))

(define-condition recognizer-error (error)
  ((text :initarg :text :reader recognizer-error-text))
  (:report (lambda (c s) (write-string (recognizer-error-text c) s))))

(defun rec-error (fmt &rest args)
  (error 'recognizer-error :text (apply #'format nil fmt args)))

;;; ---- loading ---------------------------------------------------------------

(defun one-graph (dir kind)
  (let ((found (directory (merge-pathnames (format nil "~a-*.graph" kind) dir))))
    (cond ((null found) (rec-error "no ~a-*.graph in ~a" kind (namestring dir)))
          ((rest found) (rec-error "~d graphs match ~a-*.graph in ~a; which one?"
                                   (length found) kind (namestring dir)))
          (t (first found)))))

(defun read-tokens (path)
  "tokens.txt is one line per symbol: the text, a space, the index.  The text may
itself be a space — the model has a token for one — so the split is at the LAST
space on the line and not the first."
  (let ((pairs '()) (top -1))
    (with-open-file (s path :external-format :utf-8)
      (loop for line = (read-line s nil) while line
            unless (string= line "")
              do (let ((at (position #\Space line :from-end t)))
                   (unless at (rec-error "~a: no index on line ~s" (namestring path) line))
                   (let ((i (parse-integer line :start (1+ at))))
                     (setf top (max top i))
                     (push (cons i (subseq line 0 at)) pairs)))))
    (when (minusp top) (rec-error "~a is empty" (namestring path)))
    (let ((v (make-array (1+ top) :initial-element nil)))
      (loop for (i . text) in pairs do (setf (aref v i) text))
      v)))

(defun meta-integer (model key)
  (let ((s (model-meta model key)))
    (unless s
      (rec-error "the model does not record ~a, and it cannot be guessed from the ~
                  graph — the graph describes one call and this is about how the ~
                  calls follow one another" key))
    (parse-integer s)))

(defun load-recognizer (dir &key tokens)
  "Load the three graphs in DIR, and the vocabulary beside them."
  (let* ((dir (pathname dir))
         (tokens (or tokens (merge-pathnames "tokens.txt" dir)))
         (encoder (load-model (one-graph dir "encoder")))
         (decoder (load-model (one-graph dir "decoder")))
         (joiner (load-model (one-graph dir "joiner")))
         (x (find "x" (model-inputs encoder) :key #'first :test #'string=)))
    (unless x
      (rec-error "the encoder has no input named x, so this is not the model ~
                  this knows how to drive"))
    (unless (probe-file tokens)
      (rec-error "no vocabulary at ~a" (namestring tokens)))
    (let ((r (make-recognizer
              :encoder encoder :decoder decoder :joiner joiner
              :tokens (read-tokens tokens)
              :window (aref (third x) 1)
              :advance (meta-integer encoder "decode_chunk_len")
              :context (meta-integer decoder "context_size")
              :fbank (make-fbank))))
      (let ((vocab (meta-integer decoder "vocab_size")))
        (unless (>= (length (rec-tokens r)) vocab)
          (rec-error "the vocabulary has ~d entries and the model expects ~d"
                     (length (rec-tokens r)) vocab)))
      r)))

;;; ---- the stream ------------------------------------------------------------

(defstruct (decode-state (:conc-name ds-))
  "What survives from one chunk to the next: the encoder's 98 caches, the tokens
emitted so far, and the decoder's answer for the last CONTEXT of them.

The decoder's output is kept rather than recomputed because it only changes when
a token is emitted, which is far less often than once per frame — and it is the
joiner's second input on every single frame."
  (states '() :type list)               ; input name -> tensor, ready to feed
  (hyp '() :type list)                  ; emitted tokens, newest last
  (decoder-out nil))

(defun zero-states (model &optional (batch 1))
  "Every encoder input but x, at its declared shape, holding zeros.

A stream begins with no history, and no history is zeros in all 98 of them —
including processed_lens, which is a count and starts at none.  The shapes are
read off the model rather than tabulated here: the model is where they are
written down, and a table would be a second copy to get wrong.  A symbolic
dimension is the batch axis, which is 1."
  (loop for (name dtype shape) in (model-inputs model)
        unless (string= name "x")
          collect (cons name
                        (make-tensor dtype (map 'vector
                                                (lambda (d) (if (stringp d) batch d))
                                                shape)))))

(defun decoder-run (rec hyp)
  "What the decoder says about the last CONTEXT tokens of HYP."
  (let* ((n (rec-context rec))
         (y (make-tensor :i64 (vector 1 n)))
         (tail (last hyp n)))
    (with-typed-data (d y :dtypes (:i64))
      (loop for tok in tail for i from 0 do (setf (aref d i) tok)))
    (model-output-tensor (rec-decoder rec) (run-model (rec-decoder rec) (list (cons "y" y))))))

(defun start-decoding (rec)
  (let ((hyp (make-list (rec-context rec) :initial-element (rec-blank rec))))
    (make-decode-state :states (zero-states (rec-encoder rec))
                       :hyp hyp
                       :decoder-out (decoder-run rec hyp))))

(defun encode-chunk (rec state x)
  "Run the encoder on one window and carry its state forward.  Returns the
encoder's output for this chunk, shape (1, frames, 512).

The output names are the input names with new_ in front, which is how a graph
that cannot mutate anything says the same thing as a loop that can."
  (let* ((encoder (rec-encoder rec))
         (vals (run-model encoder (list* (cons "x" x) (ds-states state))))
         (declared (model-outputs encoder)))
    (setf (ds-states state)
          (loop for (name) in (rest declared)
                do (unless (and (> (length name) 4) (string= "new_" name :end2 4))
                     (rec-error "the encoder's output ~a is not a new_ state, so ~
                                 this does not know where to carry it" name))
                collect (cons (subseq name 4) (gethash name vals))))
    (model-output-tensor encoder vals)))

(defun frame-tensor (enc-out t-index)
  "One frame of the encoder's output, shaped the way the joiner wants it."
  (let* ((dim (tensor-dim enc-out 2))
         (frame (make-tensor :f32 (vector 1 dim))))
    (with-typed-data (src enc-out :dtypes (:f32))
      (with-typed-data (dst frame :dtypes (:f32))
        (replace dst src :start2 (* t-index dim) :end2 (* (1+ t-index) dim))))
    frame))

(defun best-token (logit)
  (let ((best 0) (top most-negative-single-float))
    (with-typed-data (d logit :dtypes (:f32))
      (dotimes (i (length d))
        (when (> (aref d i) top) (setf top (aref d i) best i))))
    best))

(defun search-chunk (rec state enc-out)
  "Greedy transducer search over one chunk's encoder frames.

One question per frame, and the history only moves when the answer is not blank
— which is what makes this a transducer search rather than a classifier: the
number of tokens is not the number of frames, and nothing here decides in
advance how many words a second of audio holds."
  (dotimes (i (tensor-dim enc-out 1))
    (let* ((frame (frame-tensor enc-out i))
           (logit (model-output-tensor
                   (rec-joiner rec)
                   (run-model (rec-joiner rec)
                              (list (cons "encoder_out" frame)
                                    (cons "decoder_out" (ds-decoder-out state))))))
           (best (best-token logit)))
      (unless (= best (rec-blank rec))
        (setf (ds-hyp state) (append (ds-hyp state) (list best))
              (ds-decoder-out state) (decoder-run rec (ds-hyp state)))))))

;;; ---- whole files -----------------------------------------------------------

(defun chunk-count (frames window advance)
  "How many encoder calls a file of FRAMES feature frames takes.

The +2 is not slack.  One extra chunk is the remainder: a file is not a whole
number of chunks, and dropping the last partial one drops the last second of
speech, so it is zero-padded out — which is what a streaming recognizer does
when its input ends.  The second is because the downsampling stack looks ahead:
the last real frames only reach the encoder's OUTPUT once something has followed
them through it.  Without it 1.wav ends IN HEAVE."
  (max 1 (+ 2 (ceiling (- frames window) advance))))

(defun pad-features (feats total)
  (let* ((bins (tensor-dim feats 1))
         (out (make-tensor :f32 (vector total bins))))
    (with-typed-data (src feats :dtypes (:f32))
      (with-typed-data (dst out :dtypes (:f32))
        (replace dst src)))
    out))

(defun window-tensor (feats at window)
  (let* ((bins (tensor-dim feats 1))
         (x (make-tensor :f32 (vector 1 window bins))))
    (with-typed-data (src feats :dtypes (:f32))
      (with-typed-data (dst x :dtypes (:f32))
        (replace dst src :start2 (* at bins) :end2 (* (+ at window) bins))))
    x))

(defun decode-features (rec feats &key on-chunk)
  "Run the whole of FEATS through the recognizer and return the tokens emitted.
ON-CHUNK, if given, is called with (index state) after each chunk — which is how
something that wants partial results as they arrive gets them."
  (let* ((window (rec-window rec))
         (advance (rec-advance rec))
         (chunks (chunk-count (tensor-dim feats 0) window advance))
         (padded (pad-features feats (+ (* (1- chunks) advance) window)))
         (state (start-decoding rec)))
    (dotimes (c chunks)
      (search-chunk rec state (encode-chunk rec state (window-tensor padded (* c advance) window)))
      (when on-chunk (funcall on-chunk c state)))
    (nthcdr (rec-context rec) (ds-hyp state))))

(defun tokens-text (rec tokens)
  "The emitted pieces, joined.  U+2581 LOWER ONE EIGHTH BLOCK is how a
sentencepiece vocabulary writes the space that begins a word."
  (let ((out (make-string-output-stream)))
    (dolist (tok tokens)
      (let ((text (aref (rec-tokens rec) tok)))
        (unless text (rec-error "token ~d is not in the vocabulary" tok))
        (loop for ch across text
              do (write-char (if (char= ch #\LOWER_ONE_EIGHTH_BLOCK) #\Space ch) out))))
    (string-trim " " (get-output-stream-string out))))

(defun sentence-case (text)
  "TEXT as a reader wants it, not as the recognizer emits it.  A Zipformer trained on a
sentencepiece vocabulary hands back bare UPPERCASE with no punctuation — the shape of its training
data — so `AFTER EARLY NIGHTFALL THE YELLOW LAMPS WOULD LIGHT UP' comes out shouting.  This
lowercases it and capitalizes the first letter: `After early nightfall the yellow lamps would light
up'.  Pure — no model, no state — so it is checkable without audio.

It does NOT restore proper-noun capitals or punctuation: the recognizer did not tell us which words
were names or where the sentences ended, and inventing either would be inventing a fact.  A caller
that wants that has to add a step that knows something this function does not."
  (let ((s (string-trim '(#\Space #\Tab #\Newline #\Return) (or text ""))))
    (if (zerop (length s))
        ""
        (let ((low (string-downcase s)))
          (setf (char low 0) (char-upcase (char low 0)))
          low))))

(defun recognize-samples (rec samples &key on-chunk beam lexicon (penalty 1d0))
  "Transcribe SAMPLES.  BEAM, if given, is the width of a modified beam search
(see beam.lisp); without it the search is greedy, which is what the transcript
gate holds this to.  LEXICON adds a word-list prior at PENALTY nats a word,
which needs a beam to act on — a greedy search has nothing to prefer instead."
  (let ((feats (compute-features samples :fbank (rec-fbank rec))))
    (tokens-text rec (if (and beam (> beam 1))
                         (decode-features-beam
                          rec feats beam :on-chunk on-chunk
                          :prior (and lexicon (plusp penalty)
                                      (make-word-prior rec lexicon penalty)))
                         (decode-features rec feats :on-chunk on-chunk)))))

(defun recognize-file (rec path &key on-chunk beam lexicon (penalty 1d0))
  "Transcribe a 16 kHz wav file."
  (multiple-value-bind (samples rate) (read-wav path)
    (let ((want (fbank-rate (rec-fbank rec))))
      (unless (= rate want)
        (rec-error "~a is ~d Hz; the front end is built for ~d, and nothing here ~
                    resamples" (file-namestring path) rate (round want))))
    (recognize-samples rec samples :on-chunk on-chunk :beam beam
                                   :lexicon lexicon :penalty penalty)))
