;;;; beam.lisp — the same three graphs, asked to keep more than one opinion.
;;;;
;;;; The greedy search in recognize.lisp takes the largest logit at every frame
;;;; and never revisits it.  That is fine when the model is sure and it is a coin
;;;; flip when the model is not, and the coin lands once and forever: a token
;;;; emitted at frame 400 is the decoder's input from frame 400 onward, so one
;;;; bad flip does not cost one token, it costs the rest of the word.
;;;;
;;;; A 14-second clip of the sugar-water speech showed both halves of that.  The
;;;; name STEVE came out STEE because at the deciding frame E led VE by 0.9 of a
;;;; logit — and having said STEE, the decoder went on to make STEECHOBS out of
;;;; what should have been JOBS, though ▁JO had been within 1.3 the whole time.
;;;; Elsewhere ▁YOU beat ▁JUST by 0.3 and turned "just stared at me" into "you
;;;; stared at me".  Neither is a bad model; both are a search that cannot
;;;; entertain a second opinion for even one frame.
;;;;
;;;; So: modified beam search, as in icefall, which is what this model was
;;;; trained and published against.  Every surviving hypothesis is extended by
;;;; exactly one label per frame — blank included — which bounds the work per
;;;; frame at BEAM joiner calls instead of leaving it to a while-loop, and is the
;;;; whole of what "modified" means.  Hypotheses that arrive at the same token
;;;; sequence by different routes are merged, their probabilities added, because
;;;; they are the same hypothesis and counting them twice would let a beam fill
;;;; up with one word spelled one way.
;;;;
;;;; The greedy path is untouched and stays the default.  What the transcript
;;;; gate compares against is a Python reference loop that is greedy, and a
;;;; search that scores better is still a search that would make that gate fail
;;;; for a reason that is not a bug.  Beam is asked for by name, and judged by
;;;; word error rate instead — inspect/wer-gate.lisp.

(in-package #:stave)

(defstruct (hypothesis (:conc-name hyp-))
  "A token sequence, what the model thinks of it, and the decoder's answer for
its tail.  The decoder is stateless over the last CONTEXT tokens, so DECODER-OUT
is a function of those alone — which is why it can be cached across hypotheses
and across frames rather than recomputed per joiner call.

WORD and OFF are the lexicon prior's business and are ignored without one: the
letters of the word currently being spelled, and whether this hypothesis has
already been charged for that word not being one."
  (ys '() :type list)
  (log-prob 0d0 :type double-float)
  (decoder-out nil)
  (word "" :type string)
  (off nil))

(defun log-add (a b)
  "log(e^A + e^B), without leaving the range of a double-float."
  (declare (type double-float a b))
  (let ((hi (max a b)) (lo (min a b)))
    (if (= hi sb-ext:double-float-negative-infinity)
        hi
        (+ hi (log (+ 1d0 (exp (- lo hi))))))))

(defun log-softmax (logit)
  "The joiner's logits as log-probabilities: what the beam adds up.

Logits are only comparable within one frame; log-probabilities are comparable
across frames, which is the whole reason a beam can compare a hypothesis that
emitted here against one that did not."
  (with-typed-data (d logit :dtypes (:f32))
    (let* ((n (length d))
           (out (make-array n :element-type 'double-float))
           (top most-negative-double-float))
      (dotimes (i n) (setf top (max top (float (aref d i) 1d0))))
      (let ((sum 0d0))
        (dotimes (i n)
          (let ((v (exp (- (float (aref d i) 1d0) top))))
            (setf (aref out i) v)
            (incf sum v)))
        (let ((lse (+ top (log sum))))
          (dotimes (i n out)
            (setf (aref out i) (- (+ (log (aref out i)) top) lse))))))))

(defun decoder-out-for (rec ys cache)
  "The decoder's answer for the tail of YS, computed once per distinct tail."
  (let ((key (last ys (rec-context rec))))
    (or (gethash key cache)
        (setf (gethash key cache) (decoder-run rec ys)))))

;;; ---- the lexicon prior ------------------------------------------------------
;;;
;;; Shallow fusion with the smallest language model there is: a list of words.
;;; A hypothesis pays PENALTY nats, once, the moment the word it is spelling
;;; stops being spellable — and the moment matters more than the size.  Charged
;;; at the end of a word it arrives after the alternatives have been pruned;
;;; charged at the first impossible piece it arrives while they are still in the
;;; beam, which is the difference between a prior and a post-mortem.
;;;
;;; It is a bias and not a filter, deliberately.  A recognizer that can only say
;;; words somebody wrote down cannot say a name, and the corpus this is measured
;;; on is full of them — GAMEWELL, ARONNAX, CONSEIL are all correct and all
;;; absent from CMUdict.  A model that is sure enough still wins; PENALTY is the
;;; price of being sure, and inspect/wer-gate.lisp is where it gets set.

(defstruct (prior (:conc-name prior-))
  "A lexicon, a price, and the vocabulary rendered as plain letters."
  (lexicon nil)
  (penalty 0d0 :type double-float)
  (starts #() :type simple-vector)     ; does token N begin a word?
  (letters #() :type simple-vector)    ; token N without the word-start marker
  (cache (make-hash-table :test #'equal)))

(defun make-word-prior (rec lexicon penalty)
  (let* ((tokens (rec-tokens rec))
         (n (length tokens))
         (starts (make-array n))
         (letters (make-array n)))
    (dotimes (i n)
      (let ((piece (aref tokens i)))
        (cond ((and (plusp (length piece)) (char= (char piece 0) #\▁))
               (setf (aref starts i) t (aref letters i) (subseq piece 1)))
              ;; <blk>, <unk> and friends spell nothing and are charged nothing
              ((and (plusp (length piece)) (char= (char piece 0) #\<))
               (setf (aref starts i) nil (aref letters i) ""))
              (t (setf (aref starts i) nil (aref letters i) piece)))))
    (make-prior :lexicon lexicon :penalty (float penalty 1d0)
                :starts starts :letters letters)))

(defun prior-advance (prior word off token)
  "The word state after TOKEN, and what it costs to get there."
  (let ((lex (prior-lexicon prior))
        (p (prior-penalty prior)))
    (if (aref (prior-starts prior) token)
        ;; a new word begins, so the old one is finished and is either a word or
        ;; is not
        (let* ((closing (if (or off (zerop (length word)) (word-known-p lex word))
                            0d0 p))
               (new (aref (prior-letters prior) token))
               (bad (not (word-prefix-p lex new))))
          (values new bad (+ closing (if bad p 0d0))))
        (let ((new (concatenate 'string word (aref (prior-letters prior) token))))
          (cond (off (values new t 0d0))
                ((word-prefix-p lex new) (values new nil 0d0))
                (t (values new t p)))))))

(defun prior-penalties (prior word off)
  "What each token in the vocabulary would cost this word state, cached — the
state repeats across frames and hypotheses far more often than it changes."
  (let ((key (concatenate 'string (if off "!" ".") word)))
    (or (gethash key (prior-cache prior))
        (setf (gethash key (prior-cache prior))
              (let* ((n (length (prior-starts prior)))
                     (out (make-array n :element-type 'double-float)))
                (dotimes (i n out)
                  (setf (aref out i)
                        (nth-value 2 (prior-advance prior word off i)))))))))

(defun close-word (prior hyp)
  "The last word of an utterance ends without anything starting after it."
  (let ((word (hyp-word hyp)))
    (unless (or (hyp-off hyp) (zerop (length word))
                (word-known-p (prior-lexicon prior) word))
      (decf (hyp-log-prob hyp) (prior-penalty prior))
      (setf (hyp-off hyp) t)))
  hyp)

;;; The candidate heap is a plain vector kept in descending order.  With a beam
;;; of four and a vocabulary of five hundred, insertion into a four-element
;;; vector beats sorting two thousand conses per frame, and allocates nothing.

(defstruct (candidate (:conc-name cand-))
  (score most-negative-double-float :type double-float)
  (from nil)
  (token 0 :type fixnum))

(defun offer (heap filled score from token)
  "Keep this extension among the best seen so far; returns the new fill count.
The struct that falls off the end is the one reused, so a frame's two thousand
candidates allocate nothing."
  (declare (type double-float score))
  (let ((cap (length heap)))
    (if (and (= filled cap) (<= score (cand-score (aref heap (1- cap)))))
        filled
        (let* ((at (or (position-if (lambda (x) (< (cand-score x) score)) heap :end filled)
                       filled))
               (last (if (< filled cap) filled (1- cap)))
               (slot (aref heap last)))
          (loop for i downfrom last above at
                do (setf (aref heap i) (aref heap (1- i))))
          (setf (aref heap at) slot
                (cand-score slot) score (cand-from slot) from (cand-token slot) token)
          (min cap (1+ filled))))))

(defun beam-step (rec frame hyps beam cache prior)
  "One encoder frame against every live hypothesis; the BEAM best survive."
  (let ((heap (make-array beam))
        (filled 0))
    (dotimes (i beam) (setf (aref heap i) (make-candidate)))
    (dolist (h hyps)
      (let ((lp (log-softmax
                 (model-output-tensor
                  (rec-joiner rec)
                  (run-model (rec-joiner rec)
                             (list (cons "encoder_out" frame)
                                   (cons "decoder_out" (hyp-decoder-out h)))))))
            (pen (and prior (prior-penalties prior (hyp-word h) (hyp-off h)))))
        (dotimes (tok (length lp))
          (setf filled (offer heap filled
                              (- (+ (hyp-log-prob h) (aref lp tok))
                                 (if pen (aref pen tok) 0d0))
                              h tok)))))
    ;; Merge: two candidates that spell the same thing ARE the same hypothesis,
    ;; and adding their probabilities is the difference between a beam of four
    ;; opinions and a beam of one opinion held four ways.
    (let ((by-ys (make-hash-table :test #'equal))
          (order '()))
      (dotimes (i filled)
        (let* ((c (aref heap i))
               (h (cand-from c))
               (blank (= (cand-token c) (rec-blank rec)))
               (ys (if blank (hyp-ys h) (append (hyp-ys h) (list (cand-token c)))))
               (found (gethash ys by-ys)))
          (if found
              (setf (hyp-log-prob found) (log-add (hyp-log-prob found) (cand-score c)))
              (let ((new (make-hypothesis
                          :ys ys :log-prob (cand-score c)
                          :decoder-out (if blank
                                           (hyp-decoder-out h)
                                           (decoder-out-for rec ys cache))
                          :word (hyp-word h) :off (hyp-off h))))
                (when (and prior (not blank))
                  (multiple-value-bind (word off)
                      (prior-advance prior (hyp-word h) (hyp-off h) (cand-token c))
                    (setf (hyp-word new) word (hyp-off new) off)))
                (setf (gethash ys by-ys) new)
                (push new order)))))
      (nreverse order))))

(defun best-hypothesis (hyps)
  "The most probable, unnormalized — which is what icefall returns.  Dividing by
length would be a different search with a different bias, and this one is meant
to be the published one."
  (let ((best (first hyps)))
    (dolist (h (rest hyps) best)
      (when (> (hyp-log-prob h) (hyp-log-prob best)) (setf best h)))))

(defun decode-features-beam (rec feats beam &key on-chunk prior)
  "FEATS through the recognizer with a beam of BEAM; returns the tokens emitted.
ON-CHUNK is called with (index hypotheses) — a list, newest opinion included,
rather than the single state the greedy loop can offer.  PRIOR, if given, is a
lexicon prior (MAKE-WORD-PRIOR) and makes the score a fused one rather than the
model's own."
  (let* ((window (rec-window rec))
         (advance (rec-advance rec))
         (chunks (chunk-count (tensor-dim feats 0) window advance))
         (padded (pad-features feats (+ (* (1- chunks) advance) window)))
         (state (start-decoding rec))
         (cache (make-hash-table :test #'equal))
         (hyps (list (make-hypothesis :ys (ds-hyp state)
                                      :log-prob 0d0
                                      :decoder-out (ds-decoder-out state)))))
    (dotimes (c chunks)
      (let ((enc (encode-chunk rec state (window-tensor padded (* c advance) window))))
        (dotimes (i (tensor-dim enc 1))
          (setf hyps (beam-step rec (frame-tensor enc i) hyps beam cache prior))))
      (when on-chunk (funcall on-chunk c hyps)))
    (when prior (dolist (h hyps) (close-word prior h)))
    (nthcdr (rec-context rec) (hyp-ys (best-hypothesis hyps)))))
