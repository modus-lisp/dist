;;;; wav.lisp — read a RIFF/WAVE file into samples.
;;;;
;;;; A recognizer needs samples, and the shortest honest path from a file to
;;;; samples is to read the file.  RIFF is a chunk format: a header, then chunks
;;;; that name themselves and give their own length, so anything unrecognized is
;;;; skipped by its length rather than by guesswork.  Only `fmt ` and `data` are
;;;; interesting, and real files put `LIST`, `fact` and worse between them.

(in-package #:stave)

(define-condition wav-error (error)
  ((text :initarg :text :reader wav-error-text))
  (:report (lambda (c s) (format s "~a" (wav-error-text c)))))

(defun %u16 (buf i) (logior (aref buf i) (ash (aref buf (+ i 1)) 8)))

(defun %u32 (buf i)
  (logior (aref buf i) (ash (aref buf (+ i 1)) 8)
          (ash (aref buf (+ i 2)) 16) (ash (aref buf (+ i 3)) 24)))

(defun %s16 (buf i)
  (let ((v (%u16 buf i)))
    (if (>= v 32768) (- v 65536) v)))

(defun %f32 (buf i)
  (sb-kernel:make-single-float
   (let ((v (%u32 buf i))) (if (>= v #x80000000) (- v #x100000000) v))))

(defun %tag (buf i)
  (map 'string #'code-char (subseq buf i (+ i 4))))

(defun read-file-bytes (path)
  (with-open-file (s path :element-type '(unsigned-byte 8))
    (let ((buf (make-array (file-length s) :element-type '(unsigned-byte 8))))
      (read-sequence buf s)
      buf)))

(defun read-wav (path)
  "Values: samples as single-floats in [-1, 1], and the sample rate.

Scaled by 1/32768 for integer files — the convention every other reader uses,
and the one this model was trained under; a recognizer fed samples scaled by
32768 instead would see every log-mel value shifted by a constant 20.8, which
is a plausible-looking spectrogram and a useless one.

Only the first channel is kept.  Mixing channels is a decision about the
recording, not about the format, and nothing here is entitled to make it."
  (let* ((buf (read-file-bytes path))
         (n (length buf))
         (channels 0) (rate 0) (bits 0) (format 0)
         (samples nil))
    (when (or (< n 12) (not (string= (%tag buf 0) "RIFF"))
              (not (string= (%tag buf 8) "WAVE")))
      (error 'wav-error :text (format nil "~a is not a RIFF/WAVE file" path)))
    (loop with i = 12
          while (<= (+ i 8) n)
          do (let* ((tag (%tag buf i))
                    (size (%u32 buf (+ i 4)))
                    (body (+ i 8)))
               ;; a chunk's length excludes the pad byte that keeps the next one
               ;; even, and a truncated final chunk is common enough to survive
               (setf size (min size (- n body)))
               (cond
                 ((string= tag "fmt ")
                  (when (< size 16)
                    (error 'wav-error :text (format nil "~a: fmt chunk is ~d bytes"
                                                    path size)))
                  (setf format (%u16 buf body)
                        channels (%u16 buf (+ body 2))
                        rate (%u32 buf (+ body 4))
                        bits (%u16 buf (+ body 14)))
                  ;; WAVE_FORMAT_EXTENSIBLE hides the real format in a GUID whose
                  ;; first two bytes are the format tag it stands in for
                  (when (and (= format #xFFFE) (>= size 26))
                    (setf format (%u16 buf (+ body 24)))))
                 ((string= tag "data")
                  (when (zerop channels)
                    (error 'wav-error :text (format nil "~a: data before fmt" path)))
                  (let* ((bytes (/ bits 8))
                         (stride (* bytes channels))
                         (count (floor size stride))
                         (out (make-array count :element-type 'single-float)))
                    (cond
                      ((and (= format 1) (= bits 16))
                       (dotimes (k count)
                         (setf (aref out k)
                               (/ (float (%s16 buf (+ body (* k stride))) 1.0) 32768.0))))
                      ((and (= format 3) (= bits 32))
                       (dotimes (k count)
                         (setf (aref out k) (%f32 buf (+ body (* k stride))))))
                      (t (error 'wav-error
                                :text (format nil "~a: format ~d at ~d bits is not read here"
                                              path format bits))))
                    (setf samples out))))
               (incf i (+ 8 size (mod size 2)))))
    (unless samples
      (error 'wav-error :text (format nil "~a has no data chunk" path)))
    (values samples rate)))
