;;;; lexicon.lisp — a list of words that exist, and fast questions about it.
;;;;
;;;; The model's implicit language model is whatever its training corpus was.
;;;; This one's was LibriSpeech: public-domain novels read aloud, in which STEVE
;;;; occurs zero times, JOBS occurs zero times, and STEECHOBS is therefore no
;;;; less plausible than either.  A list of English words is a prior the model
;;;; does not have and cannot get from its weights, and it is not a list of
;;;; answers — nothing here knows what was said, only what is spellable.
;;;;
;;;; Two questions get asked, and the second is the one that earns its keep:
;;;;
;;;;   is this a word?      asked when a word ends
;;;;   could this BE a word? asked at every piece, which is what lets a search
;;;;                         notice at STEECH — while the alternative is still
;;;;                         alive in the beam — rather than at STEECHOBS, four
;;;;                         frames after the last hypothesis that could have
;;;;                         said otherwise was pruned
;;;;
;;;; Both are binary search over one sorted vector.  A prefix trie would answer
;;;; the same questions in less time and more memory; a sorted vector of 134,000
;;;; strings is two megabytes and seventeen comparisons, and this is not the hot
;;;; loop — the encoder is.

(in-package #:stave)

(defstruct (lexicon (:constructor %make-lexicon (words)))
  "Words, sorted, upper case.  Sorted is the whole data structure: the words
sharing a prefix are exactly the ones adjacent to where that prefix would go."
  (words #() :type simple-vector))

(defun load-lexicon (path)
  "One word per line.  Blank lines and anything starting with ; are skipped, so
a word list can carry its own provenance at the top."
  (with-open-file (s path :external-format :utf-8)
    (let ((words '()))
      (loop for line = (read-line s nil)
            while line
            for w = (string-trim '(#\Space #\Tab #\Return) line)
            unless (or (zerop (length w)) (char= (char w 0) #\;))
              do (push (string-upcase w) words))
      (%make-lexicon (sort (coerce words 'simple-vector) #'string<)))))

(defun %lower-bound (lex s)
  "The index of the first word not less than S."
  (let ((words (lexicon-words lex))
        (lo 0))
    (let ((hi (length words)))
      (loop while (< lo hi)
            do (let ((mid (floor (+ lo hi) 2)))
                 (if (string< (svref words mid) s)
                     (setf lo (1+ mid))
                     (setf hi mid)))))
    lo))

(defun word-known-p (lex word)
  (let ((at (%lower-bound lex word))
        (words (lexicon-words lex)))
    (and (< at (length words)) (string= (svref words at) word))))

(defun word-prefix-p (lex prefix)
  "Is PREFIX the beginning of any word at all?  The empty prefix is, trivially:
a word that has not started yet has not gone wrong."
  (if (zerop (length prefix))
      t
      (let ((at (%lower-bound lex prefix))
            (words (lexicon-words lex)))
        (and (< at (length words))
             (let ((w (svref words at)))
               (and (<= (length prefix) (length w))
                    (string= prefix w :end2 (length prefix))))))))
