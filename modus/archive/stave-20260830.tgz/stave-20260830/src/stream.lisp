;;;; stream.lisp — the recognizer driven by a clock instead of by a file.
;;;;
;;;; recognize.lisp already decodes a chunk at a time; what it does not have is
;;;; anywhere to put audio that has not arrived yet.  RECOGNIZE-SAMPLES is handed
;;;; every sample of the utterance at once, computes every feature frame, and
;;;; then walks the chunks — which is the right shape for a file and the wrong
;;;; one for a microphone, where the last sample of the sentence does not exist
;;;; when the first word has to be on the screen.
;;;;
;;;; So: a LISTENER, fed whatever has arrived, transcribing as far as it can and
;;;; keeping the remainder.  Two things make that exact rather than approximate.
;;;;
;;;; THE FRONT END STOPS SHORT OF THE END.  With snip_edges off, frame f reads
;;;; samples 160f-120 through 160f+280, and samples off either end are found by
;;;; reflecting.  The reflection at the start is off sample 0, which a stream has
;;;; had since it began; the reflection at the END is off audio that has not
;;;; happened.  A stream that computed its last two frames anyway would be
;;;; folding in a mirror of the moment before, and would then have to compute
;;;; them AGAIN, differently, once the next packet landed.  FBANK-FRAMES-READY is
;;;; the line: frames below it are final the first time, and are bit-for-bit what
;;;; the whole-file front end produces for the same recording.
;;;;
;;;; THE CHUNKING IS THE SAME ARITHMETIC, RUN LATE.  Chunk c is feature frames
;;;; [c*advance, c*advance+window), and it runs the moment that many frames are
;;;; settled — no earlier, which would need audio, and no later, which would be
;;;; latency for nothing.  LISTENER-FINISH then does what CHUNK-COUNT's +2 does
;;;; for a file: the tail frames, computed once the signal really has ended, and
;;;; the zero-padded chunks that push the last real frames out through a
;;;; downsampling stack that looks ahead.  inspect/stream-gate.lisp holds the
;;;; whole of it to equality with DECODE-FEATURES on the same audio, fed in
;;;; packet-sized pieces at every awkward size.
;;;;
;;;; THE UTTERANCE IS BOUNDED AND THE SESSION IS NOT.  A listener keeps the
;;;; samples of the CURRENT utterance, because the front end indexes them from
;;;; its beginning; a session that never reset would grow a buffer forever.
;;;; LISTENER-RESET ends one utterance and starts the next, which is also where
;;;; the transducer's history is dropped — a recognizer carrying an hour of
;;;; context into a new sentence is not a better one.

(in-package #:stave)

(defstruct (listener (:conc-name ln-) (:constructor make-listener (rec &key (rate 16000))))
  "A recognizer, a clock's worth of audio at a time, and the transcript so far.

Feed it samples in [-1, 1] at the recognizer's own rate; nothing here resamples,
for the same reason FILE-FEATURES does not — a recognizer quietly fed the wrong
rate produces confident nonsense."
  rec
  (rate 16000 :type fixnum)
  ;; the current utterance's audio, from its first sample.  Grown by doubling and
  ;; kept SIMPLE — the front end wants a simple-array, and FED is how much of it
  ;; is real, which is why EXTRACT-FRAME takes an end rather than reading LENGTH.
  (audio (make-array 0 :element-type 'single-float) :type f32v)
  (fed 0 :type fixnum)
  ;; the features computed out of it: rows of BINS, again grown by doubling
  (feats (make-array 0 :element-type 'single-float) :type f32v)
  (frames 0 :type fixnum)
  (bins 0 :type fixnum)
  (at 0 :type fixnum)                   ; first feature frame of the next chunk
  (chunks 0 :type fixnum)
  state
  (text "" :type string)                ; the current utterance, as words
  (done '() :type list)                 ; utterances already ended, newest first
  (ended nil))                          ; LISTENER-FINISH has run on this one

;;; ---- growing buffers -------------------------------------------------------

(defun %grow-f32 (vec need)
  "VEC, or a bigger one holding what VEC held.  Doubling, so feeding a stream in
packets does not copy the utterance once per packet."
  (declare (type f32v vec) (type fixnum need))
  (if (<= need (length vec))
      vec
      (let ((new (make-array (max need 4096 (* 2 (length vec)))
                             :element-type 'single-float)))
        (replace new vec)
        new)))

;;; ---- feeding ---------------------------------------------------------------

(defun %append-samples (ln samples)
  (let* ((n (length samples))
         (need (+ (ln-fed ln) n)))
    (setf (ln-audio ln) (%grow-f32 (ln-audio ln) need))
    (let ((buf (ln-audio ln)))
      (etypecase samples
        (f32v (replace buf samples :start1 (ln-fed ln)))
        (sequence (let ((i (ln-fed ln)))
                    (map nil (lambda (s) (setf (aref buf i) (float s 1.0)) (incf i))
                         samples)))))
    (setf (ln-fed ln) need)))

(defun %compute-frames (ln upto)
  "Compute feature frames [FRAMES, UPTO) out of the audio held so far.

Each one is computed once and never revisited, which is only true because UPTO
never runs past what FBANK-FRAMES-READY allows until the signal has ended."
  (let* ((fb (rec-fbank (ln-rec ln)))
         (bins (length (fbank-bin-first fb)))
         (frame (fbank-frame fb))
         (power (fbank-power fb))
         (window (fbank-window fb))
         (audio (ln-audio ln))
         (end (ln-fed ln)))
    (when (zerop (ln-bins ln)) (setf (ln-bins ln) bins))
    (setf (ln-feats ln) (%grow-f32 (ln-feats ln) (* upto bins)))
    (let ((feats (ln-feats ln)))
      (loop while (< (ln-frames ln) upto)
            do (extract-frame audio (ln-frames ln) frame window end)
               (power-spectrum (fbank-plan fb) frame power)
               (apply-mel fb power feats (* (ln-frames ln) bins))
               (incf (ln-frames ln))))))

(defun %window-tensor (ln at window)
  (let* ((bins (ln-bins ln))
         (x (make-tensor :f32 (vector 1 window bins))))
    (with-typed-data (dst x :dtypes (:f32))
      (replace dst (ln-feats ln) :start2 (* at bins) :end2 (* (+ at window) bins)))
    x))

(defun %run-ready-chunks (ln)
  "Every chunk whose window is entirely inside the frames computed so far."
  (let* ((rec (ln-rec ln))
         (window (rec-window rec))
         (advance (rec-advance rec))
         (before (ln-chunks ln)))
    (loop while (<= (+ (ln-at ln) window) (ln-frames ln))
          do (search-chunk rec (ln-state ln)
                           (encode-chunk rec (ln-state ln)
                                         (%window-tensor ln (ln-at ln) window)))
             (incf (ln-at ln) advance)
             (incf (ln-chunks ln)))
    (when (> (ln-chunks ln) before)
      (setf (ln-text ln)
            (tokens-text rec (nthcdr (rec-context rec) (ds-hyp (ln-state ln))))))
    (> (ln-chunks ln) before)))

(defun listener-feed (ln samples)
  "Hand SAMPLES to LN and decode as far as they reach.

Returns (VALUES TEXT CHANGED-P): the current utterance's transcript, and whether
this call moved it.  Never blocks on anything but its own arithmetic — the work
is bounded by how much audio arrived, so a caller on a 20 ms clock stays on it."
  (when (ln-ended ln) (listener-reset ln))
  (unless (ln-state ln) (setf (ln-state ln) (start-decoding (ln-rec ln))))
  (%append-samples ln samples)
  (%compute-frames ln (fbank-frames-ready (ln-fed ln)))
  (let ((moved (%run-ready-chunks ln)))
    (values (ln-text ln) moved)))

(defun listener-finish (ln)
  "End the utterance: the tail frames, then the padded chunks that flush the
encoder's lookahead.  Returns the utterance's final transcript.

This is where a stream and a file finally say the same thing.  Until it is
called the last second of speech is still inside the encoder's downsampling
stack, which is not a bug to be fixed but the reason a streaming recognizer can
answer at all — it is always a little behind, and this is the moment it is
allowed to stop being."
  (cond
    ((ln-ended ln) (ln-text ln))
    ((null (ln-state ln)) (setf (ln-ended ln) t) (ln-text ln))
    (t
     (let* ((rec (ln-rec ln))
            (window (rec-window rec))
            (advance (rec-advance rec))
            (total (fbank-num-frames (ln-fed ln)))
            (chunks (chunk-count total window advance))
            (padded (+ (* (1- chunks) advance) window)))
       ;; the tail: frames the end of the signal reflects into, computable only now
       (%compute-frames ln total)
       ;; and then zeros, which is what a stream has after its last sample
       (setf (ln-feats ln) (%grow-f32 (ln-feats ln) (* padded (ln-bins ln))))
       (fill (ln-feats ln) 0.0 :start (* total (ln-bins ln)) :end (* padded (ln-bins ln)))
       (setf (ln-frames ln) padded)
       (%run-ready-chunks ln)
       (setf (ln-ended ln) t)
       (ln-text ln)))))

(defun listener-reset (ln)
  "End this utterance and begin the next one.

The audio goes, because the front end indexes it from the beginning and a
session that kept it all would grow a buffer for as long as it ran; the
transducer's history goes with it, because a sentence should not be decoded in
the context of the one before it.  The TRANSCRIPT does not go — LISTENER-DONE
keeps it."
  (unless (ln-ended ln) (listener-finish ln))
  (when (plusp (length (ln-text ln)))
    (push (ln-text ln) (ln-done ln)))
  (setf (ln-fed ln) 0
        (ln-frames ln) 0
        (ln-at ln) 0
        (ln-chunks ln) 0
        (ln-state ln) nil
        (ln-text ln) ""
        (ln-ended ln) nil)
  ln)

;;; ---- what it has heard -----------------------------------------------------

(defun listener-text (ln)
  "The current utterance's transcript."
  (ln-text ln))

(defun listener-done (ln)
  "The utterances already ended, oldest first."
  (reverse (ln-done ln)))

(defun listener-transcript (ln)
  "Everything heard this session, as one string."
  (let ((parts (append (listener-done ln)
                       (and (plusp (length (ln-text ln))) (list (ln-text ln))))))
    (format nil "~{~a~^ ~}" parts)))

(defun listener-seconds (ln)
  "How much audio the current utterance holds."
  (/ (ln-fed ln) (float (ln-rate ln) 1d0)))

(defun listener-level (ln &optional (samples 1600))
  "Root-mean-square of the last SAMPLES of audio, in the same [0, 1] the samples
are in — what a level meter shows, and what a caller deciding an utterance has
ended by silence is deciding on."
  (let* ((buf (ln-audio ln))
         (end (ln-fed ln))
         (start (max 0 (- end samples))))
    (if (<= end start)
        0d0
        (let ((acc 0d0))
          (loop for i from start below end
                do (incf acc (* (aref buf i) (aref buf i))))
          (sqrt (/ acc (- end start)))))))
