# Trust model: honesty requirements, capital efficiency, trust heuristics

*Working analysis, 2026-09-30.* This grounds the spec's security claims (DEP-05 §Security Model,
§Cosignature Threshold, §Lifecycle; DEP-06; DEP-19) in what the devnet has measured and what the red
team found (docs/REDTEAM.md). Q is the number of cosigners and n the operator's ledgers.

## 1. What each guarantee needs

| guarantee | what it needs | measured / found |
|---|---|---|
| **Validity:** no committed update breaks the rules | an honest **majority** of cosigners at the update's tier, each validating in full (state, conformance, witnesses) | Finding 11: cl cosigners skipped depositor authorization, so a cl-majority quorum signed a witness-less spend; one reference member refused. **Honesty is not enough: honest members must also be correct.** |
| **Detection** of a bad committed update | **one** honest, online replica of the ledger (member or watcher) | forged lock on A: flagged within 1 s, forked within 2 s (19:55:29 → :31) |
| **Punishment:** confiscation at Tier 0 | a **majority** of recovery voters sign the confiscation | A: fraud at height 9518, confiscation confirmed at 9521, custody at 9522 (all three online) |
| **Punishment** when the majority colluded | not available at Tier 0; minority confiscation opens at `quorum_expiry + 720`, solo at `+ 4032` | not run. A colluding majority can already spend the vault through Tier 0 (DEP-05: "a quorum majority custodies the operator's entire vault"). |
| **No equivocation** | *spec claim:* an honest majority prevents it (DEP-05 §Cosignature Threshold). *Actually:* nothing prevents it; it is **detected** by one honest online replica and **punished** by a majority | Both implementations re-sign a sequence that has not committed (retries are needed for liveness), so an operator can collect majorities on two branches from honest members alone. DEP-05's argument assumes "signed = applied". |
| **Liveness:** updates keep flowing | a majority online and willing to cosign | soak: ~60 updates per ledger per minute with Q = 3 and mixed implementations |
| **Custody moves** when the operator vanishes | majority at expiry; minority at +720; one member at +4032; operator alone at +8064 | respectful expiry path ran end to end (soak 1, claim #4) |
| **Censorship resistance** | an honest member embeds the request, plus a proof the network acts on | **not enforced** in either implementation (REDTEAM claims #3, #5) |

**Conclusions:**
- Safety of funds needs an honest, *correct* majority. Detection needs only one honest online replica.
  Punishment needs a majority again, or waiting out expiry.
- The gap between "detected" and "punished" is exactly where a colluding majority operates. It can't
  hide the fraud, but it can outrun the punishment.
- "Correct" is doing real work: every red-team finding so far (11–14) was an honest node verifying
  too little. The honesty requirement is really **honest + independently implemented**.

## 2. Capital efficiency

The operator's vault is `U = reserves + collateral`, with obligations ≤ reserves. So the capacity per
sat locked is `R = reserves / U`, and the rest is idle bond.

**With an honest majority**, on-ledger fraud gains nothing: the ledger rolls back to the last valid
update, deposits continue on the winner's fork, and the collateral goes to the lottery (punitive).
What an operator *can* extract is **value settled off the ledger against a state that is later rolled
back**, within the window between the fraud and the freeze:
- a courier leg on another ledger paid against a lock that rolls back (DEP-13);
- a swap counterparty paid out on-chain or over Lightning against a rolled-back transfer;
- (not measured) an equivocation branch shown to one party while the other branch is shown to another.

Measured window with an online honest member: **same block** (1–2 s). So the collateral needed against
an honest-majority quorum is small: what counterparties will settle off-ledger within seconds, plus
enough to make the lottery worth running (the winner's reward).

**With a colluding majority**, DEP-05's arithmetic applies: gain ≈ `U × R / n` per ledger taken, cost ≈
`U × C / n` per ledger where an honest majority can confiscate (contagion, DEP-19 §5–6). The simulated
"max safe sybil %" (DEP-05) tops out at 49% for C ≥ 60%. **Collateral mainly buys protection against
collusion, not against a lone operator.**

**Finality for counterparties.** A fraud at sequence N that is detected at N + k rolls back k updates,
honest ones included. With an online honest member k ≈ 0 (A froze on the next update). If every honest
replica is offline, k grows until one returns. So an update is final once an honest replica has seen it
and a detection cycle has passed. A counterparty that settles off-ledger (courier, swap) should wait
for that, not merely for the cosignatures.

### 2a. Does contagion deter collusion? (simulation)

`analysis/contagion_sim.py` (output in `analysis/contagion_sim.out`): N = 100 operators, one vault each,
reserves R fully used, collateral C = 1 − R, quorums of Q drawn at random. A coalition of a fraction p
spends every vault whose quorum it holds a majority of (Tier 0). It takes the whole vault from honest
operators and the deposits from its own. With contagion (DEP-19 §5–6), each coalition key that signs
loses its collateral once, if its own quorum has an honest majority. The attacker picks targets and
signers greedily for maximum net. The table gives the largest p at which the attack is unprofitable
in 95% of 200 trials:

| contagion | Q | R = 0.2 | 0.3 | 0.4 | 0.5 | 0.6 | 0.7 | 0.8 |
|---|---|---|---|---|---|---|---|---|
| off | 3 | 0.01 | 0.01 | 0.01 | 0.02 | 0.01 | 0.02 | 0.01 |
| off | 5 | 0.05 | 0.04 | 0.04 | 0.05 | 0.04 | 0.04 | 0.04 |
| off | 7 | 0.07 | 0.08 | 0.07 | 0.08 | 0.07 | 0.08 | 0.07 |
| on | 3 | 0.08 | 0.09 | 0.07 | 0.08 | 0.01 | 0.02 | 0.01 |
| on | 5 | 0.22 | 0.21 | 0.20 | 0.19 | 0.13 | 0.04 | 0.05 |
| on | 7 | 0.28 | 0.30 | 0.29 | 0.30 | 0.24 | 0.17 | 0.08 |

**Readings:**
- **Without contagion the network is safe only while no quorum anywhere is captured:** 1–8% of
  operators. Signing a theft is free.
- **Contagion is the security model.** With it, Q = 7 tolerates ~30% colluding operators, Q = 5
  ~20% and Q = 3 ~8%, at R ≤ 0.5. It deters collusion; it does not prevent it.
- **Capital-efficiency ceiling, per theft:** a theft of one vault needs `floor(Q/2) + 1` signers,
  each losing C, so it pays whenever `C < 1 / (floor(Q/2) + 1)`. That's R above 0.5 at Q = 3, above
  0.67 at Q = 5, above 0.75 at Q = 7. Above the ceiling, contagion stops mattering.
- **Below the ceiling the limit is key reuse:** a key that signs many thefts is slashed once (DEP-19
  §10.1 says so), and coalition keys whose own quorum the coalition holds are unslashable. That's why
  safety plateaus below the ceiling instead of reaching it.
- **So honest operation at Q = 7 locks ~2 sats per sat of deposits (R = 0.5) for ~30% collusion
  tolerance.** Going to R = 0.4 buys nothing; going past R = 0.6 loses it fast. DEP-05's table (49% at
  C ≥ 60%) assumed wallets deposit only on honest operators, and did not let a majority spend an
  honest vault. This model does both, so it is the harsher bound.

**Two spec problems this exposes:**
- **DEP-19 §10.1 overstates bite.** "Three signers of a theft of V then hold at least 1.5 V between
  them on ledgers that can slash them": holding is not losing. Confiscation costs a signer only its
  collateral; the reserves are owed to its depositors and continue on the winner's fork. Real bite is
  `need × C × (member vault)`, a factor C of what §10.1 implies.
- **DEP-19 §5 makes honest retries slashable.** It drops `Equivocation` because two canonical updates
  at one sequence "imply a member who co-signed both, which is a `NonConforming` fault of that member".
  But re-signing a sequence that has not committed is required for liveness (REDTEAM attack #2), so
  honest members would be slashed. The fault is the operator's; a cosigner who signed two rounds cannot
  be told apart from a colluder.

**Not modelled yet:** strategic quorum joining (the coalition choosing which ledgers to serve on, the
DEP-19 §10 residual), unequal vaults (the "pyramid"), several ledgers per operator, detection or
punishment failing (members offline, contagion not implemented: today, only the reference's
cosigner-side `fault_ledger_id` evidence exists), and deposits concentrating on honest ledgers.

### 2b. Q = 7 on the devnet (2026-09-30)

The devnet runs §2a's sweet spot: 12 nodes (6 cl, 6 reference), 12 ledgers, Q = 7, R = 0.5, each
quorum split 4–3 by implementation with the operator's implementation in the minority
(`soak_plan`). All twelve formed first time with 144 deposits.

- **The cost of Q = 7 is cosign fan-out, not consensus.** The first run showed reference-operated
  ledgers at a fifth of the others' rate. The cause: every cl cosign forked `bitcoin-cli` from a
  multi-gigabyte heap, ~175 ms each, two or three times per request, which capped a cl node at 2–3
  cosigns a second against ~6 asked by its seven quorums. Reference-operated quorums are
  cl-majority, so they waited on the slowest cl answer. Caching the chain height and block hashes
  (cl 08b86af) cut cl answers from a 6–20 s median to **21 ms** (p90 40–80 ms). Reference members
  answer in ~10 ms.
- **Throughput after the fix:** 227–290 updates per ledger per 5 minutes, evenly across operators
  and implementations (the bots' request rate is now the limit), with zero refusals and no
  non-conforming flags.
- **Operational load per node:** each serves 7 quorums. At ~50 updates a minute per ledger that is
  ~6 cosign requests a second per node, which is comfortable once a cosign costs milliseconds.

### 2c. Contagion on the devnet (2026-09-30)

Implemented cosigner contagion (DEP-19 §5): cl d4614e7 (produce and act) and deposits-rust efe4143
(produce; it already acted). `redteam/attack-collude-q7.sh`:
- **Three of seven collude** on A (cld2–cld4 cosign blind, cld1 forges a lock): 3 of the 4 cosignatures
  needed; every reference member refused (`InvalidWitness`); nothing committed.
- **Four of seven collude** on test ledger M (cld1 operates; cld2–cld5 cosign blind): the forged lock
  commits. Then:
  - M is disputed by its honest members within seconds; C, E, G and I (the colluders' own ledgers,
    each Q = 7 with an honest majority) within ~36 s, by members acting on cl-built proofs. The
    reference acted on them unchanged.
  - **All five vaults were confiscated punitively on chain** (M, C, E, G, I: 0.499996 BTC each,
    15–16 confirmations). M's lottery went to cld6; C, E, G and I to honest reference members.
  - The coalition's tally: nothing gained (the lock rolled back with M); collateral lost on five vaults
    (1.25 BTC at R = 0.5).
- **Operator contagion (added: cl 62b69bb, deposits-rust 56efa41).** The first run left cld1, the forging
  operator, with its other ledger A untouched. The same NonConformingCosignature evidence now accepts the
  fault's operator as the accused, and is presented against every other ledger it operates. **Re-run on a
  fresh ledger M2:** M2 was disputed within 9 s, and **A, cld1's other ledger, by all four of its honest
  members (ref2–ref5) within 26 s.** The ledgers confiscated from the colluders in the first run now have
  new custodians and were not disputed again; the reference found its existing forks. Loose end: a
  confiscated cl operator keeps operating its old ledger, and its members refuse every cosign ("in dispute
  state"). That's noise, not harm; it should stand down.
- **So running more ledgers, and serving on more quorums, is more exposure, and exposure is the signal.**
  An operator's every vault is at stake for fraud on any of its ledgers, slashable by each ledger's own
  quorum. A member's own vault is at stake for every quorum it serves, but slashed once (DEP-19 §10.1), so
  its bite per ledger guarded is its collateral divided by the number it guards. §3's heuristics should
  score both: operator collateral summed across its ledgers, and member coverage (own collateral against
  the collateral it guards).
- **Tested (2026-10-02): the theft §2a models.** A colluding majority spending an honest operator's
  vault at Tier 0 is on-chain, not a ledger update. Both implementations now prove it
  (`UnauthorizedVaultSpend`, DEP-06 list item 7, wire type 10) against every witness signer, on every
  ledger the signer operates; `redteam/attack-vault-spend.sh` shows the contagion live (REDTEAM.md).
  Limit: a confiscation is excused only if the verifier knows of it, so a verifier that missed a
  dispute can wrongly accuse its signers.

### 2d. Operator contagion quantified: more ledgers, more deterrent (simulation)

`analysis/coverage_sim.py` extends §2a to L ledgers per operator. An on-chain theft (DEP-06
`UnauthorizedVaultSpend`) names every signer, so each exposed key loses collateral on **every** ledger
it operates with an honest majority — one accusation, every vault it runs at risk (the §2c live run).
The attacker takes the best of all-in, myopic greedy and repeated cheapest-incremental greedy (a key
exposed once is free for further thefts). Largest safe coalition fraction p (unprofitable in ≥95% of
150 trials, N=60, random quorums):

| mode | Q=7, R=0.5 | Q=7, R=0.7 | Q=5, R=0.5 | Q=3, R=0.5 |
|---|---|---|---|---|
| no contagion | 0.09 | 0.09 | 0.06 | 0.02 |
| contagion, L=1 | 0.25 | 0.14 | 0.14 | 0.05 |
| contagion, L=3 | 0.30 | 0.20 | 0.24 | 0.10 |
| contagion, L=5 | 0.30 | 0.24 | 0.25 | 0.14 |

**Readings:**
- **Contagion triples tolerance** at Q=7 (0.09 → 0.25-0.30): the on-chain proof is what makes a
  majority theft cost more than it takes.
- **More ledgers help, then saturate.** 1→3 ledgers lifts Q=7, R=0.5 from 0.25 to 0.30; 3→5 adds
  nothing there, and more at leaner vaults (R=0.7: 0.14 → 0.24). Against a coordinated attacker the
  binding cost is the cascade, not per-key exposure, so scale alone stops at ~0.30.
- **An earlier version of this table read 0.55 at L=5.** Its attacker was myopic (it never paid a
  key's up-front exposure), which overstated safety, most at large L. These are the corrected numbers.
- **Random quorums are the floor, not the design.** §2e holds 0.45 at Q=7 against the same attacker
  by changing *who sits* on quorums (anchors, lot seats, deposits following compliance); that, not
  scale, is the lever that lifts tolerance above a third. Full output: analysis/coverage_sim.out.

### 2e. Seating guidance, followed by wallets' deposits (simulation)

`analysis/seating_sim.py`. Honest operators seat Q = 7 as **trust anchors** (roots: whoever signs the
wallet software, and the few they vouch for: 10% of operators, honest by assumption) + **commit-reveal
lot** from a shared pool + **vanity** (free choice). Wallets deposit only on compliant ledgers (anchors
present, lot seats match the draw), in proportion to score^2. Contagion includes **dereliction**
(DEP-19 §6): when an exposed key's own quorum is coalition-captured and doesn't confiscate, that
quorum's members are derelict and exposed in turn, recursively, until honest majorities act. The
attacker is the best of a myopic greedy, a **coordinated all-in** (every capturable vault, the
cascade paid once), and a **theft-set optimizer** (start all-in, drop any theft whose loot is worth
less than the cascade it alone drags in, to a fixpoint). Still a lower bound on the optimal attack, so
these are upper bounds on safety. Largest safe coalition fraction p:

| seating | L=1, R=.5 | L=1, R=.7 | L=3, R=.5 | L=3, R=.7 |
|---|---|---|---|---|
| random | 0.24 | 0.15 | 0.30 | 0.24 |
| 2 anchors / 3 lot / 2 vanity | 0.27 | 0.09 | 0.33 | 0.21 |
| 2/3/2, pool stuffed 2× | 0.12 | 0.06 | 0.15 | 0.12 |
| **2 anchors / 4 lot / 1 vanity** | **0.36** | **0.21** | **0.45** | **0.33** |
| 2/4/1, pool stuffed 2× | 0.15 | 0.09 | 0.18 | 0.12 |
| 2/4/1, coalition wins half the vanity seats | 0.36 | 0.15 | 0.42 | 0.30 |

**Two rules the guidance needs (both checkable by a wallet):**
- **Eligibility = punishability.** Only keys whose own ledgers comply may fill lot or vanity seats on
  others' ledgers. Without it, a coalition stacks its own ledgers (visibly non-compliant) and still
  takes seats on honest ones.
- **Non-compliant ledgers get no deposits.** Even a sliver gives a self-stacked coalition something
  to steal from its own ledgers.

**Readings:**
- **2/4/1 is a real improvement against a competent attacker**: 0.24 → 0.36 at one ledger per
  operator, 0.30 → 0.45 at three (R = 0.5). That is the margin to defend.
- **One vanity seat, not two.** Free seats are where a coalition places itself, on honest ledgers and
  its own; 2/3/2 is little better than random and degrades when vanity is gamed.
- **Pool stuffing is the critical risk.** 2× stuffing takes 2/4/1 from 0.36 to 0.15, below random.
  The design is only as strong as the lot pool's admission: the pool must be **shared, not
  operator-curated** (a coalition that defines its own pool draws only itself), and entry must be
  **costly** (stake, coverage, track record), so stuffing costs what being p does.
- **Dereliction closes the self-capture escape** rather than moving the headline. A captured quorum
  doesn't make its operator safe: it makes the quorum's own members liable, until an honest majority
  is reached. Against a coordinated attack, most of the coalition is exposed anyway, so the cascade
  adds little cost; what it removes is a careful attacker signing only with keys whose own quorums
  are captured. **Now implemented** (cl c7976a5, deposits-rust ec7457b): the escape is closed, verified cross-implementation.
- **Choosing thefts doesn't help the attacker.** The theft-set optimizer never beat all-in: in a dense
  coalition the signers are shared, so dropping a theft doesn't shrink the cascade. So 2/4/1's 0.45
  (L=3, R=0.5) holds against the smartest attacker built so far, with every dishonest operator in one
  coalition.
- **§2d now uses the stronger attacker but not dereliction cascades; §2a predates both.** Read them as
  upper bounds on their own settings.

### 2f. Entry cost: stake-blocks, with bonding to bootstrap (design and simulation)

§2e left pool stuffing as the critical risk: a coalition that can add lot-pool entries cheaply halves
the safe fraction. The answer is an entry cost on pool eligibility, and the design question is how to
let new operators in quickly (bootstrapping) without making that cheaper than waiting.

**Design (proposed):**
- **Eligibility is measured in stake-blocks:** locked capital × blocks held, threshold S* = V × T. A
  plain operator accrues V per block and is eligible after T.
- **A bond compresses time, not cost.** An entrant that locks an extra bond B accrues V + B per block
  and is eligible after T × V / (V + B) (B = V: T/2; B = 3V: T/4). The opportunity cost burned is the
  same either way, so bonding buys speed, not a discount. The bond is slashable while held and
  returned at eligibility. Day-one operators bond to bootstrap the network.
- **A floor on the wait** (e.g. T/8 whatever the bond) keeps what only time provides: a rate limit on
  rebuilding after a burn (one good shot per floor), and a visible age signal.
- **Stake-blocks keep accruing as seniority** that wallets weight deposits by and operators can
  prefer for vanity seats. **Confiscation resets a key's stake-blocks**, so a theft forfeits the key's
  whole history, not just its collateral. An honest operator that has run 2T holds twice what a fresh
  entrant does; time spent honest is an asset, not a sunk cost.
- **Forfeited bonds go to the robbed ledger's depositors** (towards the "victims aren't made whole"
  concern in docs/MISSING.md).

**Simulation** (`analysis/entry_sim.py`): λ, the threshold's opportunity cost per key as a fraction of a
vault, charged at formation to every coalition key. Same dereliction model and smart attacker as §2e.

| seating | λ | L=1, R=.5 | L=1, R=.7 | L=3, R=.5 | L=3, R=.7 |
|---|---|---|---|---|---|
| random | 0 | 0.24 | 0.15 | 0.27 | 0.21 |
| random | 0.10 | 0.27 | 0.18 | 0.30 | 0.24 |
| 2/4/1 | 0 | 0.39 | 0.21 | 0.42 | 0.33 |
| 2/4/1 | 0.025 | 0.39 | 0.24 | 0.45 | 0.30 |
| 2/4/1 | 0.10 | 0.45 | 0.30 | 0.42 | 0.33 |

**Readings:**
- **The size of λ barely matters** below ~10% of a vault (differences within one 0.03 grid step). At the
  boundary the attacker's profit doesn't arrive at thin margins but in whole vaults, so a small
  per-key charge doesn't move where it flips.
- **What entry cost is for is turning stuffing into participation.** With eligibility requiring
  stake-blocks on a real, punishable vault, an extra pool entry is an extra coalition key: the 2×
  stuffing row of §2e (0.15–0.18) stops being a separate threat, and the defence reads off the main
  rows (0.39–0.45).
- **So a modest threshold suffices**, which is good for bootstrapping. The floor on the wait matters
  for repeated attacks (one per floor), which this single-shot model doesn't measure.

### 2g. Multiple rounds: the floor caps damage, it does not move the boundary (simulation)

`analysis/multiround_sim.py` runs the §2f network for H rounds. A key exposed in a theft is
confiscated (stake-blocks reset): ineligible for FLOOR rounds, re-entry costs λ again, and while it
cools it neither helps capture nor can be slashed. Two coalition strategies: **all-in** (strike once)
and **rotate** (strike each round with whatever keys are eligible, a slow bleed).

**The safe boundary is unchanged by rounds or by the floor** (2/4/1, L=3, R=0.5):

| re-entry floor | 1 | 5 | 20 | 40 | single-shot |
|---|---|---|---|---|---|
| multi-round safe p | 0.45 | 0.45 | 0.45 | 0.45 | 0.45 |

Why it must be so: round 1 of any strategy faces the same network as the single-shot attack, and every
later round faces an equal-or-worse one (some coalition keys cooling). So if no single strike profits,
no sequence does. **Keeping p below the boundary is the whole game**; the floor is not part of it.

**What the floor does is cap damage above the boundary** — and a short floor barely does. At p = 0.48
(just past 0.45), cumulative net over H = 40 rounds, rotate vs all-in:

| floor | 1 | 2 | 5 | 10 | 20 | 40 |
|---|---|---|---|---|---|---|
| rotate / all-in | 6.6× | 9.4× | 7.6× | 8.8× | 2.5× | 0.6× |

A floor shorter than the horizon lets a coalition rotate burnt keys back in and bleed most rounds
(6–9× a single strike). Only a floor approaching the horizon caps it to one strike. Since the floor
can't be set to "forever", its role is to **space out** a past-boundary coalition's strikes and
rate-limit recovery after a burn, not to make an unsafe network safe.

**Takeaway:** the multi-round picture adds no new safety margin and needs none — the defence is entirely
in keeping p under the single-shot boundary (seating + contagion + entry cost). The floor is a
damage-and-tempo control, so it can be modest (bootstrapping-friendly), chosen for recovery tempo
rather than for a safety threshold it does not set.

### 2h. Collateral ratio: efficiency against resilience (simulation)

`analysis/ratio_sim.py` sweeps R, the deposits' share of a vault (capital efficiency R/(1-R) deposits
per unit of collateral), under the §2e attacker and cascade (N=60, Q=7, 80 trials, 0.03 steps).
Largest unprofitable coalition fraction p:

| R | eff | random L=1 | guidance L=1 | random L=3 | guidance L=3 | guidance L=5 |
|---|---|---|---|---|---|---|
| 0.3 | 0.43 | 0.30 | 0.48 | 0.33 | 0.54 | 0.54 |
| 0.5 | 1.0 | 0.24 | 0.36 | 0.27 | 0.42 | 0.45 |
| 0.6 | 1.5 | 0.18 | 0.30 | 0.27 | 0.39 | 0.39 |
| 0.7 | 2.3 | 0.15 | 0.18 | 0.21 | 0.33 | 0.36 |
| 0.8 | 4.0 | 0.09 | 0.09 | 0.15 | 0.24 | 0.27 |
| 0.9 | 9.0 | 0.09 | 0.09 | 0.12 | 0.12 | 0.18 |

**Readings:** the knee is R≈0.6-0.7, and only with guidance and several ledgers per operator (R=0.6
holds ~0.39; R=0.7 a third). Below R=0.5 more collateral buys little; above 0.8 tolerance is under a
quarter in every world. A profitable attack (profiled at p=0.36, random, L=3) is one coordinated
strike: every capturable vault at once, two thirds of them honest operators' vaults (which yield
deposits *and* collateral), every coalition key burned, ~20% of its ledgers shielded by
coalition-majority quorums. A variant where a captured quorum cannot take an honest vault's
collateral (`ratio_sim_safecoll.out`) gains only 0.03-0.09, about one step of R.

### 2i. Attestation as a trust root that degrades to economics (design and simulation)

A node's key can be generated inside an enclave running a reproducible image that cosigns only
conforming updates and refuses any vault spend that is not a recorded rotation or dispute-backed
confiscation, and the DEP-04 ad can carry the attestation quote binding the key to the image. An
attested key on an intact platform cannot sign a theft, whoever owns it.

`analysis/attest2_sim.py` models classes as vendor x platform (CPU family / microcode / board
firmware: most breaks hit one platform, a vendor-root compromise hits all of a vendor's), 3 vendors
x 4 platforms, 80% of operators attested, the §2e attacker and cascade (N=60, Q=7, L=3). 0.99 is the
top of the grid: no coalition of any size profits.

| seating | broken | R=0.5 | R=0.7 | R=0.8 | R=0.9 |
|---|---|---|---|---|---|
| nobody attested | - | 0.27 | 0.24 | 0.18 | 0.12 |
| 80% attested, random seats | 1 platform | 0.90 | 0.63 | 0.57 | 0.30 |
| 80% attested, random seats | 1 vendor | 0.48 | 0.42 | 0.33 | 0.18 |
| **7 attested, ≤1/platform, ≤3/vendor** | **≤3 platforms, or 1 vendor** | **0.99** | **0.99** | **0.99** | **0.99** |
| same | 1 vendor + 1 platform | 0.75 | 0.54 | 0.45 | 0.30 |
| 7 attested, ≤2/platform, ≤3/vendor | 2 platforms | 0.99 | 0.99 | 0.99 | 0.69 |
| 5 attested, ≤1/platform, ≤2/vendor | 1 vendor | 0.99 | 0.78 | 0.60 | 0.33 |

**The guarantee is counting, not simulation.** With every seat attested, ≤1 per platform and ≤3 per
vendor, any three platform breaks, or one whole vendor, leave a coalition at most 3 of 7 seats; it
cannot reach the 4 a theft needs, at any coalition size. A vendor break plus one more platform can
(3 + 1), which is where the economic line takes over. Tightening the vendor cap to ≤2 needs ≥4
vendors per quorum. The simulation confirms the cascade and the
attacker find no way around it.

**What is different from earlier TEE designs** (Teechain, HSM federations): they put the enclave alone
in the safety path, so one break was total loss. Here a break moves the system down to a line it
already holds: beyond the designed failure, the §2e economics still apply (0.45 at R=0.8 after a
vendor and a platform break; today's design needs R≈0.4 for that). **Sizing rule:** choose R for the
tolerance wanted after the worst planned break; attestation is margin above it, and that margin is
what buys capital efficiency.

**Conditions the model does not capture:**
- **The image is a class spanning every platform.** A policy bug breaks every enclave running it. Two
  independent implementations become a requirement: cap seats per implementation too (≤3 cl, ≤3 Rust).
- **Revocation tempo is a safety parameter.** While a broken class keeps its seats the system runs on
  the economic line; how fast a class is demoted (TCB advisories) and quorums re-seated sets that window.
- **Supply:** each quorum needs 7 distinct platforms over ≥3 vendors (TDX, SEV-SNP, CCA; Nitro as a
  cloud option). Whether operators have enough attestable combinations is open.
- **The enclave's view of the world:** it must check header proof-of-work and keep rollback-proof
  state, or the host feeds it a fake chain or replays sealed state into an equivocation.
- **Liveness is unchanged:** censorship, co-sign refusal and going offline rest on collateral and
  dereliction as before.

### 2j. A zero-day, repriced: containment, and why the first strike is the seating rule's (simulation)

Contagion maps onto a vendor zero-day: the first exploited theft is on chain, its
`UnauthorizedVaultSpend` names the signers, and through their ads their attestation classes. No
proof is *about* the TEE (an enclave claim is not chain-verifiable); nodes and wallets simply stop
counting those classes as attested and re-seat the quorums relying on them. Any use of a zero-day
discloses it network-wide, so exploitation is one-shot and all-in.

`analysis/zeroday_sim.py`, worst case: a remote exploit (every key on a broken class signs for the
attacker, whoever operates it) plus a coalition share p of the unattested operators. Share of vaults
capturable (N=60, L=3, 80% attested, 200 trials):

| seating | broken | p=0 | p=0.2 | p=0.4 |
|---|---|---|---|---|
| 80% attested, random seats | 1 vendor | 8.6% | 13.6% | 19.4% |
| 80% attested, random seats | 1 vendor + 1 platform | 17.6% | 24.6% | 30.7% |
| 7 att, ≤1/platform, ≤3/vendor | ≤2 platforms or 1 vendor | 0 | 0 | 0 |
| 7 att, ≤1/platform, ≤3/vendor | 1 vendor + 1 platform | 20.8% | 20.9% | 22.4% |
| 7 att, ≤1/platform, ≤3/vendor | 2 vendors | 100% | 100% | 100% |

**On Bitcoin today repricing does not shrink the first strike:** every capturable vault goes in one
block, before any proof exists. Repricing protects everything after (no second strike, deposits move,
quorums re-seat). The first strike is set by seating alone: zero inside the counting bound, large
beyond it. Four vendors at ≤2 seats each would put "1 vendor + 1 platform" and "2 vendors" back inside.

**With a spend cap, containment bounds the loss:** loss = capturable × min(1, f·(2 + r)) for a vault
spendable at fraction f per window, one window to detect and r to re-seat. f = 2%, r = 1 turns the
21% vendor+platform strike into 1.3% of deposits. A cap needs a covenant (BIP-345, CTV) today. A
possible covenant-free shape, to design: a fast path at 6-7 of 7 (used by rotation), a majority path
behind a relative timelock, and a rescue transaction pre-signed by the intact full quorum
(Revault-style) that any watcher broadcasts during the delay. The open part is the rescue's
destination, since the next quorum is not known at signing time; the recovery tiers may be it.

## 3. Trust heuristics for a wallet choosing a ledger

Observable from public data (relay + chain), roughly in order of what the findings say matters:

1. **Implementation diversity in the quorum:** no single implementation holds a majority of
   cosigners. Findings 11–14 were each one implementation verifying too little. A mixed quorum turned
   Finding 11 from theft into a refused update. *Observable:* members' software is not on the wire today;
   it could be advertised in member terms (self-reported), or inferred from behaviour.
2. **Honest-majority plausibility:** members are independent operators, each with their own ledger,
   `min_member_collateral` at stake (DEP-05), and a history of being online (cosign latency and refusal
   rate are visible on the relay).
3. **At least one reliably online replica** (member or independent watcher): this is what makes
   detection immediate. Wallets can run their own watcher for ledgers they hold.
4. **Collateral ratio and the operator's total collateral across ledgers** (contagion), against the
   wallet's exposure and the off-ledger settlement it plans (§2).
5. **Lifecycle position:** distance to `quorum_expiry`, and a history of rotating on time. Past expiry
   the quorum's authority degrades by tier.
6. **Terms:** `service_response_blocks`, fee schedule and limits, timeout heights. These bound how long
   funds can be held and what they cost.

## 4. Open questions, with how to answer each

- **Colluding-majority fraud against an honest minority, end to end:** what the minority can do before
  `quorum_expiry + 720`, and whether contagion (DEP-19 §5–6) is implemented anywhere. *Devnet run plus
  code reading.*
- **Detection with members offline:** the rollback depth k as a function of honest-replica uptime.
  *Devnet: stop the honest members, commit a fault, restart them, measure k.*
- **Off-ledger extraction:** a courier leg across two ledgers whose source lock rolls back. Who loses,
  and how much should a courier wait? *node-test plus devnet.*
- **Attestation (§2i):** per-implementation classes; exposure as a function of class revocation and
  re-seating time; platform supply among real operators; what an attestable cl-deposits image needs.
  *Simulation, then a design note for DEP-04 ads and DEP-19 §10 seating.*
- **Extend the simulation (§2a):** strategic quorum joining, unequal vaults, several ledgers per
  operator, and implementation diversity as a second axis.
- **DEP-05 §Cosignature Threshold** needs rewording: it claims an honest majority prevents equivocation;
  retries mean it is detected and punished instead. A spec decision (see REDTEAM, attack #2).
