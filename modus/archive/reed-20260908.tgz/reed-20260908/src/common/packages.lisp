;;;; src/common/packages.lisp — reed package definition.
;;;;
;;;; reed is a pure-Common-Lisp audio-codec library: a multi-codec umbrella (the
;;;; audio analog of pigment for images) hosting an MPEG-1/2/2.5 Layer III (MP3)
;;;; decoder and the ITU-T G.711 companders today, with AAC-LC and Opus modules
;;;; planned.  No FFI: every codec, container to PCM, is Lisp.  The package stays
;;;; flat (#:reed) across all codecs — modularity is in the file layout, not in
;;;; sub-packages.
(defpackage #:reed
  (:use #:cl)
  (:export
   ;; ==== shared PCM representation (every codec's common currency) ====
   #:pcm #:pcm-p #:make-pcm
   #:pcm-samples #:pcm-channels #:pcm-sample-rate #:pcm-format #:pcm-frame-count
   ;; ---- WAV helper ----
   #:write-wav #:write-wav-file #:pcm->wav-octets

   ;; ==== DSP: what sits between a decoder and a device ====
   ;; sample plumbing
   #:pcm16-vector #:make-pcm16 #:clamp16
   ;; downmix / gain / the mixer
   #:downmix #:apply-gain #:mix
   ;; rate conversion (stateful, so a stream converted in pieces has no seams)
   #:resampler #:resampler-p #:make-resampler #:resample #:resample-pcm
   #:resampler-in-rate #:resampler-out-rate

   ;; ==== playing a file: fixed-size frames on demand ====
   #:player #:player-p #:make-mp3-player #:make-mp3-source #:make-buffer-source
   #:player-next-frame #:player-finished-p #:player-frames
   #:player-source-rate #:player-source-channels #:player-gain #:drain-source

   ;; ==== AC-3 (ATSC A/52) ====
   #:decode-ac3 #:decode-ac3-file #:make-ac3-decoder #:decode-ac3-packet #:ac3-frame-length
   #:ac3-error #:ac3-error-message
   #:ac3-stats #:make-ac3-stats #:*ac3-stats*
   #:ast-frames #:ast-blocks #:ast-coupled #:ast-rematrixed #:ast-short-blocks
   #:ast-dithered #:ast-delta-alloc #:ast-lfe-frames #:ast-phase-flags
   #:ast-exp-d15 #:ast-exp-d25 #:ast-exp-d45 #:ast-exp-reuse #:ast-acmods

   ;; ==== FLAC (lossless) ====
   #:decode-flac #:decode-flac-file #:decode-flac-raw
   #:make-flac-decoder #:make-flac-decoder-for-header #:decode-flac-packet
   #:parse-flac-metadata #:flac-info #:fi-sample-rate #:fi-channels #:fi-bits
   #:fi-total-samples #:fi-md5 #:fi-min-block #:fi-max-block
   #:flac-error #:flac-error-message
   #:flac-stats #:make-flac-stats #:*flac-stats*
   #:fst-frames #:fst-constant #:fst-verbatim #:fst-fixed #:fst-lpc #:fst-wasted
   #:fst-escaped #:fst-rice2 #:fst-independent #:fst-left-side #:fst-side-right
   #:fst-mid-side #:fst-max-lpc-order #:fst-max-partition-order

   ;; ==== Vorbis I ====
   #:decode-vorbis-ogg #:decode-vorbis-file
   #:decode-vorbis-packet #:vorbis-headers-from-xiph #:make-vorbis-decoder-for-headers
   #:vorbis-packet-block-size #:vorbis-setup-from-headers
   #:parse-identification #:parse-setup #:make-vorbis-decoder #:decode-audio-packet
   #:vorbis-info #:vi-channels #:vi-rate #:vi-blocksize-0 #:vi-blocksize-1
   #:vd-long-blocks #:vd-short-blocks #:vd-hybrid-windows #:vd-coupled-blocks
   #:vd-unused-channels #:vs-codebooks #:vs-modes #:vs-info
   #:vorbis-error #:vorbis-error-message

   ;; ==== MP3 (MPEG-1/2/2.5 Layer III) ====
   ;; one-shot decode -> pcm struct
   #:decode-mp3 #:decode-mp3-file
   ;; streaming / frame API
   #:make-decoder #:decoder #:decoder-p
   #:decode-next-frame #:decoder-sample-rate #:decoder-channels
   ;; conditions
   #:mp3-error #:mp3-error-message

   ;; ==== AAC-LC (MPEG-4 Audio Object Type 2) ====
   ;; MPEG audio Layer II, which DVDs and broadcast carry
   #:decode-mp2 #:make-mp2-decoder #:mp2-next-frame #:decode-mp2-packet
   #:decode-aac #:decode-aac-file
   ;; streaming AAC, for a container that hands over one access unit at a time
   #:make-aac-decoder #:decode-aac-packet
   #:aac-error #:aac-error-message

   ;; ==== Opus (RFC 6716) — full decoder: CELT + SILK + hybrid + Ogg ====
   #:make-opus-decoder #:opus-decoder-state #:opus-decoder-state-p
   #:decode-opus-packet #:decode-opus-celt #:decode-opus #:decode-opus-file
   #:decode-opus-ogg #:opus-head #:opus-head-pre-skip #:opus-head-channels
   #:opus-head-output-gain #:opus-head-mapping-family #:*opus-rfc8251*
   #:parse-opus-packet #:parse-toc #:opus-toc #:opus-toc-p
   #:opus-toc-config #:opus-toc-mode #:opus-toc-bandwidth
   #:opus-toc-frame-size #:opus-toc-channels #:opus-toc-stereo #:opus-toc-code
   #:opus-frame #:opus-frame-data #:opus-frame-start #:opus-frame-size
   #:opus-error #:opus-error-message
   ;; range coder (exposed for Stage 2/testing)
   #:ec-dec-init #:ec-decode #:ec-dec-update #:ec-dec-bit-logp
   #:ec-dec-icdf #:ec-dec-bits #:ec-dec-uint #:ec-tell #:ec-tell-frac

   ;; ==== G.711 (ITU-T PCMU / PCMA companding) ====
   ;; buffer transforms: (signed-byte 16) PCM <-> (unsigned-byte 8) codewords
   #:pcmu-encode #:pcmu-decode #:pcma-encode #:pcma-decode
   #:mulaw-encode #:mulaw-decode #:alaw-encode #:alaw-decode
   ;; per-sample companders
   #:pcmu-encode-1 #:pcmu-decode-1 #:pcma-encode-1 #:pcma-decode-1))
