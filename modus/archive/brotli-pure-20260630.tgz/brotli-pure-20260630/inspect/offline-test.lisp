;;;; inspect/offline-test.lisp — brotli-pure offline gate.
;;;;
;;;; Two halves, no external tools needed at run time:
;;;;   1. DECODE vs the reference: inspect/vectors/<name>.qNwM.br are real brotli
;;;;      streams produced by the reference encoder (python brotli, qualities 5
;;;;      & 11, windows 10 & 22); each must decode byte-for-byte to <name>.raw.
;;;;      These exercise compressed meta-blocks — prefix codes, context maps,
;;;;      the distance ring buffer, and the static dictionary + transforms.
;;;;   2. SELF round-trip: our entropy-coding encoder's output (LZ77 + Huffman)
;;;;      must decode back to the original; it is independently confirmed
;;;;      reference-decodable by node + python brotli (see inspect/differential.sh).
(defpackage #:brotli-pure.test (:use #:cl) (:local-nicknames (#:br #:brotli-pure)) (:export #:run))
(in-package #:brotli-pure.test)
(defvar *p* 0) (defvar *f* 0)
(defun ok (name g) (if g (progn (incf *p*) (format t "  ok   ~a~%" name)) (progn (incf *f*) (format t "  FAIL ~a~%" name))))
(defun so (s) (map '(simple-array (unsigned-byte 8) (*)) #'char-code s))

(defun slurp (path)
  (with-open-file (s path :element-type '(unsigned-byte 8) :if-does-not-exist nil)
    (when s
      (let ((b (make-array (file-length s) :element-type '(unsigned-byte 8))))
        (read-sequence b s) b))))

(defun vectors-dir () (asdf:system-relative-pathname "brotli-pure" "inspect/vectors/"))

(defun test-decode ()
  "Decode every committed reference .br stream; compare to its .raw original.
The .raw name is the prefix before the first dot of the .br name."
  (format t "~%decode vs reference brotli (compressed meta-blocks):~%")
  (dolist (br (sort (directory (merge-pathnames "*.br" (vectors-dir))) #'string< :key #'namestring))
    (let* ((nm (pathname-name br))
           (base (subseq nm 0 (position #\. nm)))
           (raw (slurp (merge-pathnames (format nil "~a.raw" base) (vectors-dir)))))
      (when raw
        (ok (format nil "~a (~d B)" nm (length raw))
            (ignore-errors (equalp (br:decompress (slurp br)) raw)))))))

(defun test-roundtrip ()
  (format t "~%self round-trip (our compress -> our decompress):~%")
  (flet ((rt (label data) (ok (format nil "~a (~d B)" label (length data))
                              (ignore-errors (equalp (br:decompress (br:compress data)) data)))))
    (rt "empty" (so ""))
    (rt "tiny" (so "hi"))
    (rt "text" (so (with-output-to-string (s) (dotimes (i 80) (write-string "the quick brown fox. " s)))))
    (let ((v (make-array 200000 :element-type '(unsigned-byte 8))))
      (dotimes (i 200000) (setf (aref v i) (mod (* i 7) 256)))
      (rt "200k" v))
    (let ((v (make-array 50 :element-type '(unsigned-byte 8))))   ; all byte values incl 0
      (dotimes (i 50) (setf (aref v i) (mod (* i 5) 256)))
      (rt "binary" v))))

(defun run ()
  (setf *p* 0 *f* 0)
  (format t "~&=== brotli-pure offline gate ===~%")
  (test-decode)
  (test-roundtrip)
  (format t "~%=== ~d passed, ~d failed ===~%" *p* *f*)
  (when (plusp *f*) (error "brotli-pure: ~d failures" *f*))
  t)
