#!/usr/bin/env sh
# Cross-check brotli-pure against the reference brotli in BOTH directions:
#   (a) DECODE: reference-compressed streams (python brotli, qualities 0-11,
#       several window sizes, mixed data) must decode byte-for-byte under us.
#   (b) ENCODE: our stored-meta-block output must decode under node + python.
set -e
here=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd); tmp=$(mktemp -d)
export CL_SOURCE_REGISTRY="(:source-registry (:tree \"$here\") :inherit-configuration)"

# ---- (a) reference encodes -> we decode --------------------------------------
python3 - "$tmp" <<'PY'
import brotli, random, sys
random.seed(7); d = sys.argv[1]
def gen(kind, n):
    if kind=="zeros": return bytes(n)
    if kind=="random": return bytes(random.randrange(256) for _ in range(n))
    if kind=="text":
        w="the quick brown fox lorem ipsum dolor sit amet consectetur".split()
        return (" ".join(random.choice(w) for _ in range(n))).encode()[:n]
    return bytes((i*7)%256 for i in range(n))
i=0
for kind in ("zeros","random","text","ramp"):
    for n in (0,1,50,1000,40000):
        data=gen(kind,n)
        for q in (0,5,9,11):
            for lg in (10,18,24):
                c=brotli.compress(data, quality=q, lgwin=lg)
                open(f"{d}/r{i}.br","wb").write(c)
                open(f"{d}/r{i}.raw","wb").write(data); i+=1
print("ref vectors:", i)
PY
sbcl --non-interactive \
  --eval '(handler-bind ((warning (function muffle-warning))) (asdf:load-system "brotli-pure"))' \
  --eval "(in-package :brotli-pure)" \
  --eval "(let ((ok 0) (f 0))
            (dolist (br (directory (format nil \"$tmp/r*.br\")))
              (let* ((nm (pathname-name br))
                     (raw (with-open-file (s (format nil \"$tmp/~a.raw\" nm) :element-type '(unsigned-byte 8))
                            (let ((b (make-array (file-length s) :element-type '(unsigned-byte 8)))) (read-sequence b s) b)))
                     (got (with-open-file (s br :element-type '(unsigned-byte 8))
                            (let ((b (make-array (file-length s) :element-type '(unsigned-byte 8)))) (read-sequence b s) b))))
                (if (ignore-errors (equalp (decompress got) raw)) (incf ok) (incf f))))
            (format t \"decode (we read reference): ~d ok ~d fail~%\" ok f)
            (when (plusp f) (uiop:quit 1)))"

# ---- (b) we encode -> reference decodes --------------------------------------
sbcl --non-interactive \
  --eval '(handler-bind ((warning (function muffle-warning))) (asdf:load-system "brotli-pure"))' \
  --eval "(in-package :brotli-pure)" \
  --eval "(dotimes (i 6) (let* ((len (* i i 5000)) (v (make-array len :element-type '(unsigned-byte 8)))) (dotimes (j len) (setf (aref v j) (mod (* j 7) 256))) (with-open-file (s (format nil \"$tmp/c~d.br\" i) :direction :output :element-type '(unsigned-byte 8)) (write-sequence (compress v) s)) (with-open-file (s (format nil \"$tmp/c~d.raw\" i) :direction :output :element-type '(unsigned-byte 8)) (write-sequence v s))))"
node -e "const z=require('zlib'),fs=require('fs');let ok=0,f=0;for(let i=0;i<6;i++){const o=z.brotliDecompressSync(fs.readFileSync('$tmp/c'+i+'.br'));const r=fs.readFileSync('$tmp/c'+i+'.raw');if(Buffer.compare(o,r)===0)ok++;else f++;}console.log('encode (node reads us):',ok,'ok',f,'fail')"
python3 -c "
import brotli,glob
ok=0
for zf in glob.glob('$tmp/c*.br'):
    r=open(zf[:-3]+'.raw','rb').read()
    ok+= (brotli.decompress(open(zf,'rb').read())==r)
print('encode (python reads us):',ok,'ok')"
rm -rf "$tmp"
