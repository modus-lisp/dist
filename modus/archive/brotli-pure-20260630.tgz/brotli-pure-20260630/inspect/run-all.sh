#!/usr/bin/env sh
set -e
here=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
export CL_SOURCE_REGISTRY="(:source-registry (:tree \"$here\") :inherit-configuration)"
exec sbcl --non-interactive \
  --eval '(require :asdf)' \
  --eval '(handler-bind ((warning (function muffle-warning))) (asdf:load-system "brotli-pure/test"))' \
  --eval '(uiop:quit (if (ignore-errors (brotli-pure.test:run)) 0 1))'
