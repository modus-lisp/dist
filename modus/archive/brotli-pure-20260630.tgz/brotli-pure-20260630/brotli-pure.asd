(defsystem "brotli-pure"
  :description "A from-scratch Brotli codec in pure Common Lisp (no FFI).
                Full decompressor: stream/meta-block framing, uncompressed +
                compressed meta-blocks (canonical prefix codes, block types,
                context maps, distance ring buffer, static dictionary + word
                transforms).  Entropy-coding compressor (LZ77 + length-limited
                Huffman) emits standard reference-decodable streams.  The 122 KB
                static dictionary is vendored.  Tested vs the brotli reference."
  :version "0.0.1" :author "ynniv" :license "MIT"
  :depends-on ()
  :serial t
  :components ((:module "src" :serial t
                :components ((:file "packages")
                             (:file "bitio")     ; LSB-first bit reader + writer (brotli/deflate style)
                             (:file "tables")    ; context LUTs + 121 word transforms (RFC 7932 §8)
                             (:file "huffman")   ; canonical prefix (Huffman) codes: simple + complex
                             (:file "dict")      ; static dictionary load + transform application
                             (:file "decompress"); compressed meta-block decoder (commands/contexts/distances)
                             (:file "brotli")    ; stream framing + uncompressed meta-blocks (+ dispatch)
                             (:file "encode"))))   ; compressed encoder (LZ77 + Huffman)
  :in-order-to ((test-op (test-op "brotli-pure/test"))))

(defsystem "brotli-pure/test"
  :depends-on ("brotli-pure")
  :components ((:module "inspect" :components ((:file "offline-test"))))
  :perform (test-op (o c) (uiop:symbol-call :brotli-pure.test :run)))
