(defpackage #:brotli-pure.bitio
  (:use #:cl)
  (:export #:octets #:to-octets
           #:brd #:make-brd #:rbit #:rbits #:r-align #:r-bytes #:r-eof-p
           #:bwr #:make-bwr #:wbits #:w-align #:w-bytes #:bwr-out))
(defpackage #:brotli-pure
  (:use #:cl)
  (:local-nicknames (#:b #:brotli-pure.bitio))
  (:export #:decompress #:compress #:brotli-error))
