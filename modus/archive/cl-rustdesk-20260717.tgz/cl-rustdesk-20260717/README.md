# cl-rustdesk

Reach a machine **by its RustDesk ID, through NAT**, from pure Common Lisp — a
[RustDesk](https://github.com/rustdesk/rustdesk) **relay transport** built as a
[`cl-transport`](https://github.com/modus-lisp/cl-transport) backend. It reuses a
**self-hosted** RustDesk rendezvous (`hbbs`) + relay (`hbbr`) for signaling and byte
transport; it does *not* implement the remote-desktop app layer — just the connection.

Hand-rolled protobuf + RustDesk's `BytesCodec` framing + `AddrMangle`, no FFI, no codegen.
The **relay path** (connect-by-ID, always via `hbbr`, works through any NAT). Direct P2P
(UDP hole-punching) and NaCl `secure` mode are future work — see below.

Verified end-to-end against a real, unmodified **rustdesk-server 1.1.15**
(`test/live-relay.sh`): register → punch → RelayResponse coordination → relay pairing →
byte round-trip.

## Use — the uniform cl-transport API

`cl-rustdesk` registers `:rustdesk` with cl-transport in both directions:

```lisp
(ql:quickload "cl-rustdesk")
(setf cl-rustdesk::*rendezvous-server* "your-hbbs-host"   ; used by DIAL
      cl-rustdesk:*default-relay-key*  "your-key")        ; matches hbbs/hbbr -k

;; be reachable as an ID (like a listener): each inbound connection -> handler
(cl-transport:expose
  (lambda (stream peer) (declare (ignore peer))
    (loop for b = (read-byte stream nil :eof) until (eq b :eof)
          do (write-byte b stream) (force-output stream)))     ; echo
  :backend :rustdesk :id "123456789" :server "your-hbbs-host" :key "your-key")

;; connect to a peer by ID (like a dial) -> (values stream closer)
(cl-transport:dial "123456789" 0 :transport :rustdesk)
```

## How the relay path works
```
A (dial)  --PunchHoleRequest{id, force_relay}-->  hbbs
                                                   hbbs --FetchLocalAddr/PunchHole--> B (host, UDP-registered)
B mints a uuid, --RelayResponse{uuid} (TCP)--> hbbs --forwards--> A
A and B each --RequestRelay{uuid}--> hbbr   ; hbbr pairs by uuid, raw byte pipe
```
The host (B) UDP-registers with hbbs (`RegisterPk` + `RegisterPeer` keepalive); the dialer
(A) drives a TCP punch. hbbs coordinates a relay `uuid`; both sides open a relay TCP
connection and hbbr splices them.

## Layout
```
src/wire.lisp        protobuf + BytesCodec framing + AddrMangle
src/rendezvous.lisp  hbbs register + the A(dial)/B(host) relay coordination
src/backend.lisp     DIAL + EXPOSE + register :rustdesk with cl-transport
test/offline-test    unit gate (addrmangle, protobuf, framing, messages, registration)
test/live-relay.sh   live connect-by-ID echo against a real rustdesk-server
```

## Not yet (deliberately)
- **Direct P2P (UDP hole-punching)** — the relay-MVP always relays (reliable through any
  NAT); hole-punching is the hard, network-sensitive part.
- **NaCl `secure` mode** — the relay carries plaintext today (`secure=false`). RustDesk's
  Curve25519-box + XSalsa20-Poly1305 session crypto would layer on top (ironclad has the
  primitives + a small HSalsa20 shim).

MIT.
