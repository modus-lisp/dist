# cl-rustdesk

Reach a machine **by its RustDesk ID, through NAT**, from pure Common Lisp — a
[RustDesk](https://github.com/rustdesk/rustdesk) **relay transport** built as a
[`cl-transport`](https://github.com/modus-lisp/cl-transport) backend. It reuses a
**self-hosted** RustDesk rendezvous (`hbbs`) + relay (`hbbr`) for signaling and byte
transport; it does *not* implement the remote-desktop app layer — just the connection.

Hand-rolled protobuf + RustDesk's `BytesCodec` framing + `AddrMangle`, no FFI, no codegen.
Two transport paths:
- the **relay path** (connect-by-ID, always via `hbbr`, works through any NAT), and
- **direct P2P** via **TCP hole-punching** (`:mode :punch` / `:auto`) — bypasses the relay
  when both NATs are punchable, with automatic relay fallback.

Both support optional **end-to-end encryption** (`:secure t`) — X25519 + XSalsa20-Poly1305
secretbox, the same NaCl primitives RustDesk uses, verified byte-for-byte against libsodium.

Verified end-to-end against a real, unmodified **rustdesk-server 1.1.15**
(`test/live-relay.sh`): register → punch → RelayResponse coordination → relay pairing →
byte round-trip.

## Use — the uniform cl-transport API

`cl-rustdesk` registers `:rustdesk` with cl-transport in both directions:

```lisp
(ql:quickload "cl-rustdesk")
(setf cl-rustdesk::*rendezvous-server* "your-hbbs-host"   ; used by DIAL
      cl-rustdesk:*default-relay-key*  "your-key")        ; matches hbbs/hbbr -k

;; be reachable as an ID (like a listener): each inbound connection -> handler
(cl-transport:expose
  (lambda (stream peer) (declare (ignore peer))
    (loop for b = (read-byte stream nil :eof) until (eq b :eof)
          do (write-byte b stream) (force-output stream)))     ; echo
  :backend :rustdesk :id "123456789" :server "your-hbbs-host" :key "your-key")

;; connect to a peer by ID (like a dial) -> (values stream closer)
(cl-transport:dial "123456789" 0 :transport :rustdesk)
```

### Encryption

Pass `:secure t` to both sides (or set `cl-rustdesk::*secure*` for the `ct:dial` path). After
the relay pairs the peers they run an ephemeral **X25519** exchange over the pipe and
**XSalsa20-Poly1305 secretbox** every frame — so the relay carries ciphertext, not plaintext:

```lisp
(cl-transport:expose #'handler :backend :rustdesk :id "…" :secure t …)
(cl-rustdesk:dial "…" :secure t)
```

## How the relay path works
```
A (dial)  --PunchHoleRequest{id, force_relay}-->  hbbs
                                                   hbbs --FetchLocalAddr/PunchHole--> B (host, UDP-registered)
B mints a uuid, --RelayResponse{uuid} (TCP)--> hbbs --forwards--> A
A and B each --RequestRelay{uuid}--> hbbr   ; hbbr pairs by uuid, raw byte pipe
```
The host (B) UDP-registers with hbbs (`RegisterPk` + `RegisterPeer` keepalive); the dialer
(A) drives a TCP punch. hbbs coordinates a relay `uuid`; both sides open a relay TCP
connection and hbbr splices them.

## Direct P2P (TCP hole-punching)

Opt in per call with `:mode`:

```lisp
(cl-transport:expose #'handler :backend :rustdesk :id "…" :mode :auto)  ; direct, relay fallback
(cl-rustdesk:dial "…" :mode :punch)   ; direct only   |   :mode :auto (fallback)  |  :mode :relay (default)
```

```
A (dial) --PunchHoleRequest{id} (no force_relay)--> hbbs --PunchHole{A_pub}--> B
B opens a fresh reused-port TCP conn to hbbs, --PunchHoleSent--> hbbs --PunchHoleResponse{B_pub}--> A
A and B each reuse the SAME local port they showed hbbs, and simultaneously connect() to the
other's public addr: the two SYNs cross both NATs (TCP simultaneous open) -> one direct pipe.
If the direct connect fails, A re-requests relay (nat_type=SYMMETRIC) and B relays instead.
```

Mechanics that make it work (see `src/punch.lisp`): `SO_REUSEADDR + SO_REUSEPORT` on every
socket so the hbbs-facing conn and the punch conn share the local port hbbs mapped; a
non-blocking connect that lingers in `SYN_SENT` so the peer's crossing SYN is answered with a
`SYN-ACK` (not a `RST` that would tear the NAT mapping down); a tight (gap-free) retry loop plus
a shared wall-clock start barrier so both peers' `SYN_SENT` windows overlap. Proven through a
rootless two-NAT (netns + veth + MASQUERADE) rig: direct echo round-trips while `hbbr` never
logs `got paired`; relay fallback still pairs. `:mode` defaults to `:relay` (nothing regresses).

## Layout
```
src/wire.lisp        protobuf + BytesCodec framing + AddrMangle
src/punch.lisp       SO_REUSEPORT sockets + TCP simultaneous-open hole punch
src/rendezvous.lisp  hbbs register + A(dial)/B(host) relay + direct-punch coordination
src/backend.lisp     DIAL + EXPOSE + register :rustdesk with cl-transport
test/offline-test    unit gate (addrmangle, protobuf, framing, messages, registration)
test/live-relay.sh   live connect-by-ID echo against a real rustdesk-server
```

## Encryption details / caveats
`:secure t` protects **confidentiality + integrity against a passive (honest-but-curious)
relay** — the hbbr operator can no longer read or tamper with the stream. It is **not yet
authenticated against an *active* MITM relay**: the ephemeral X25519 pubkeys are exchanged
over the (untrusted) relay, so a malicious relay could interpose. Closing that gap means
pinning the peer's hbbs-registered identity key (RustDesk's Ed25519-signed box-sealed-key
exchange). Also note: unlike RustDesk's own stream (which reuses one nonce space in both
directions), this uses distinct per-direction nonces, so there is no cross-direction reuse.

## Not yet (deliberately)
- **UDP / symmetric-NAT hole-punching** — the TCP punch handles cone-ish NATs (the common
  case); a symmetric NAT on either side isn't punchable and falls back to relay.
- **Authenticated secure mode** — MITM resistance via the peer's pinned hbbs identity key
  (see above).

MIT.
