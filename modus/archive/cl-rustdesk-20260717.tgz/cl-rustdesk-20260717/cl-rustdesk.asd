;;;; cl-rustdesk.asd
;;;;
;;;; A RustDesk RELAY transport in pure Common Lisp: reach a peer by RustDesk ID through a
;;;; self-hosted rendezvous (hbbs) + relay (hbbr), as a cl-transport backend.  Hand-rolled
;;;; protobuf + BytesCodec framing + AddrMangle; the connect-by-ID relay path (no
;;;; hole-punching, secure=false).  Verified against rustdesk-server 1.1.15.

(defsystem "cl-rustdesk"
  :description "RustDesk relay transport (pure CL): connect by ID through hbbs+hbbr; a
                :rustdesk backend for cl-transport."
  :version "0.1.0"
  :author "ynniv"
  :license "MIT"
  :depends-on ("cl-transport" "usocket" "bordeaux-threads")
  :serial t
  :components
  ((:module "src"
    :serial t
    :components
    ((:file "wire")         ; protobuf + BytesCodec framing + AddrMangle
     (:file "rendezvous")   ; hbbs register + relay coordination (dial / host)
     (:file "backend"))))   ; DIAL + EXPOSE + register :rustdesk with cl-transport
  :in-order-to ((test-op (test-op "cl-rustdesk/test"))))

(defsystem "cl-rustdesk/test"
  :depends-on ("cl-rustdesk")
  :components ((:module "test" :components ((:file "offline-test"))))
  :perform (test-op (o c) (uiop:symbol-call :cl-rustdesk.test :run)))
