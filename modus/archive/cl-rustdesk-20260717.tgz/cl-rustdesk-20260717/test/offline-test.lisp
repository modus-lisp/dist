;;;; test/offline-test.lisp — offline gate for cl-rustdesk (no network / no servers).
;;;;
;;;; Unit coverage: AddrMangle round-trip, protobuf encode/parse, BytesCodec framing,
;;;; message construction, and the :rustdesk cl-transport registration.  The full
;;;; connect-by-ID relay is exercised live against a real rustdesk-server by
;;;; test/live-relay.sh.

(defpackage :cl-rustdesk.test
  (:use :cl)
  (:local-nicknames (:rd :cl-rustdesk) (:ct :cl-transport))
  (:export #:run))
(in-package :cl-rustdesk.test)

(defparameter *ok* t)
(defun ok (n) (format t "  ok   ~a~%" n))
(defun bad (fmt &rest args) (setf *ok* nil) (format t "  *** FAIL ~a~%" (apply #'format nil fmt args)))
(defun checkt (n c) (if c (ok n) (bad n)))
(defun check (n got want) (if (equalp got want) (ok n) (bad "~a: ~s /= ~s" n got want)))

(defun test-addrmangle ()
  (dolist (case '((#(192 168 5 22) 41348) (#(10 0 0 1) 65535) (#(127 0 0 1) 1)))
    (destructuring-bind (octets port) case
      (let ((enc (cl-rustdesk::mangle-encode octets port)))
        (multiple-value-bind (ip p) (cl-rustdesk::mangle-decode enc)
          (check (format nil "addrmangle ~{~d~^.~}:~d" (coerce octets 'list) port)
                 (list ip p)
                 (list (format nil "~{~d~^.~}" (coerce octets 'list)) port)))))))

(defun test-protobuf ()
  (let ((out (cl-rustdesk::new-buf)))
    (cl-rustdesk::put-string out 1 "peer-id")
    (cl-rustdesk::put-int out 8 1)
    (cl-rustdesk::put-bytes out 3 #(9 8 7))
    (let ((p (cl-rustdesk::parse (cl-rustdesk::freeze out))))
      (check "protobuf string" (cl-rustdesk::bytes->string (cl-rustdesk::pfield p 1)) "peer-id")
      (check "protobuf varint" (cl-rustdesk::pfield p 8) 1)
      (check "protobuf bytes" (coerce (cl-rustdesk::pfield p 3) 'list) '(9 8 7)))))

(defun test-framing ()
  ;; frame a payload and read it back via an in-memory octet stream
  (let* ((payload (coerce (loop for i below 200 collect (mod i 256)) '(vector (unsigned-byte 8))))
         (buf (make-array 0 :element-type '(unsigned-byte 8) :adjustable t :fill-pointer 0)))
    (flet ((mk-out () (make-instance 'octet-stream :buf buf))
           (mk-in () (make-instance 'octet-stream :buf buf)))
      (cl-rustdesk::write-frame (mk-out) payload)
      (check "framing 200B round-trip" (cl-rustdesk::read-frame (mk-in)) payload))))

(defclass octet-stream (sb-gray:fundamental-binary-input-stream sb-gray:fundamental-binary-output-stream)
  ((buf :initarg :buf) (rp :initform 0)))
(defmethod stream-element-type ((s octet-stream)) '(unsigned-byte 8))
(defmethod sb-gray:stream-write-byte ((s octet-stream) b) (vector-push-extend b (slot-value s 'buf)) b)
(defmethod sb-gray:stream-read-byte ((s octet-stream))
  (with-slots (buf rp) s (if (< rp (fill-pointer buf)) (prog1 (aref buf rp) (incf rp)) :eof)))
(defmethod sb-gray:stream-force-output ((s octet-stream)) nil)

(defun test-messages ()
  ;; a PunchHoleRequest should carry id (1) and force_relay (8)
  (let* ((bytes (cl-rustdesk::msg-punch-hole-request "123456789" "KEY"))
         (outer (cl-rustdesk::parse bytes))
         (inner (cl-rustdesk::parse (cl-rustdesk::pfield outer cl-rustdesk::+punch-hole-request+))))
    (check "punch-hole-request id" (cl-rustdesk::bytes->string (cl-rustdesk::pfield inner 1)) "123456789")
    (check "punch-hole-request force_relay" (cl-rustdesk::pfield inner 8) 1)))

(defun test-punch-messages ()
  ;; direct PunchHoleRequest: no force_relay (8) and no nat_type (2) -> B punches
  (let ((inner (cl-rustdesk::parse
                (cl-rustdesk::pfield (cl-rustdesk::parse
                                      (cl-rustdesk::msg-punch-hole-request "id" "K" nil))
                                     cl-rustdesk::+punch-hole-request+))))
    (checkt "direct punch-request omits force_relay" (null (cl-rustdesk::pfield inner 8)))
    (checkt "direct punch-request omits nat_type"    (null (cl-rustdesk::pfield inner 2))))
  ;; relay PunchHoleRequest: nat_type = SYMMETRIC (2) — how hbbs is told to relay
  (let ((inner (cl-rustdesk::parse
                (cl-rustdesk::pfield (cl-rustdesk::parse
                                      (cl-rustdesk::msg-punch-hole-request "id" "K" t))
                                     cl-rustdesk::+punch-hole-request+))))
    (check "relay punch-request nat_type=SYMMETRIC" (cl-rustdesk::pfield inner 2)
           cl-rustdesk::+nat-symmetric+))
  ;; PunchHoleSent echoes A's socket_addr (1) and carries id (2)
  (let* ((a-addr (coerce #(1 2 3 4 5) '(vector (unsigned-byte 8))))
         (inner (cl-rustdesk::parse
                 (cl-rustdesk::pfield (cl-rustdesk::parse
                                       (cl-rustdesk::msg-punch-hole-sent a-addr "peerid"))
                                      cl-rustdesk::+punch-hole-sent+))))
    (check "punch-hole-sent echoes socket_addr" (coerce (cl-rustdesk::pfield inner 1) 'list)
           '(1 2 3 4 5))
    (check "punch-hole-sent id" (cl-rustdesk::bytes->string (cl-rustdesk::pfield inner 2)) "peerid")))

(defun test-reuseport ()
  ;; SO_REUSEADDR+SO_REUSEPORT lets two sockets share one local port (needed for the punch)
  (let (s1 s2 ok)
    (unwind-protect
         (progn
           (setf s1 (cl-rustdesk::make-reuse-tcp))
           (sb-bsd-sockets:socket-bind s1 (sb-bsd-sockets:make-inet-address "127.0.0.1") 0)
           (multiple-value-bind (ip port) (cl-rustdesk::sock-local s1)
             (check "sock-local reports loopback" ip "127.0.0.1")
             (setf s2 (cl-rustdesk::make-reuse-tcp))
             (sb-bsd-sockets:socket-bind s2 (sb-bsd-sockets:make-inet-address "127.0.0.1") port)
             (setf ok t)))
      (ignore-errors (sb-bsd-sockets:socket-close s1))
      (ignore-errors (sb-bsd-sockets:socket-close s2)))
    (checkt "two SO_REUSEPORT sockets share a local port" ok))
  ;; connect-reuse: a bounded connect to a closed port fails cleanly (no hang, returns NIL)
  (checkt "connect-reuse to closed port returns NIL"
          (null (cl-rustdesk::connect-reuse "127.0.0.1" 1 :timeout 1))))

(defun test-registration ()
  (checkt ":rustdesk outbound (dial) registered" (ct:transport-available-p :rustdesk))
  (checkt ":rustdesk inbound (expose) registered" (ct:listener-available-p :rustdesk)))

(defun hx (v) (string-downcase (format nil "~{~2,'0x~}" (coerce v 'list))))
(defun iota (n) (coerce (loop for i below n collect (mod i 256)) '(vector (unsigned-byte 8))))
(defun k32 (b) (make-array 32 :element-type '(unsigned-byte 8) :initial-element b))
(defun a (s) (map '(vector (unsigned-byte 8)) #'char-code s))

(defun test-crypto ()
  ;; NaCl primitives byte-for-byte vs libsodium/pynacl
  (check "secretbox vs libsodium vector"
         (hx (cl-rustdesk::secretbox-seal (iota 32) (iota 24) (a "the quick brown fox 0123456789")))
         "cb09a0399e86f8d87929ca0209a06a232a975d6fb6bfcb73d01ced4c07f824b734ca3effbc140ddc239751a36dfe")
  (check "x25519 pubkey vs vector"
         (hx (cl-rustdesk::x25519-pub (k32 9)))
         "57db4b359f23ae5e146e4e2512056704722506348c150c14753d0c933d04d421")
  ;; seal/open round-trip + tamper rejection
  (let* ((key (k32 5)) (nonce (cl-rustdesk::secretbox-nonce 7 1)) (pt (a "secret message"))
         (boxed (cl-rustdesk::secretbox-seal key nonce pt)))
    (check "secretbox open round-trip" (cl-rustdesk::secretbox-open key nonce boxed) pt)
    (setf (aref boxed 20) (logxor (aref boxed 20) 1))
    (checkt "secretbox rejects tampering"
            (handler-case (progn (cl-rustdesk::secretbox-open key nonce boxed) nil) (error () t))))
  ;; ECDH: both sides derive the same session key
  (multiple-value-bind (ask apk) (cl-rustdesk::x25519-keypair)
    (multiple-value-bind (bsk bpk) (cl-rustdesk::x25519-keypair)
      (checkt "ecdh session key agreement"
              (equalp (cl-rustdesk::derive-key (cl-rustdesk::x25519-shared ask bpk))
                      (cl-rustdesk::derive-key (cl-rustdesk::x25519-shared bsk apk)))))))

(defun run ()
  (setf *ok* t)
  (format t "~&== cl-rustdesk offline gate ==~%")
  (test-addrmangle) (test-protobuf) (test-framing) (test-messages) (test-punch-messages)
  (test-reuseport) (test-registration) (test-crypto)
  (format t "~a~%" (if *ok* "ALL OK" "FAILURES ABOVE"))
  *ok*)
