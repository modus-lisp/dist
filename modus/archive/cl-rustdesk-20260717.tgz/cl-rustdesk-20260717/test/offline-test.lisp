;;;; test/offline-test.lisp — offline gate for cl-rustdesk (no network / no servers).
;;;;
;;;; Unit coverage: AddrMangle round-trip, protobuf encode/parse, BytesCodec framing,
;;;; message construction, and the :rustdesk cl-transport registration.  The full
;;;; connect-by-ID relay is exercised live against a real rustdesk-server by
;;;; test/live-relay.sh.

(defpackage :cl-rustdesk.test
  (:use :cl)
  (:local-nicknames (:rd :cl-rustdesk) (:ct :cl-transport))
  (:export #:run))
(in-package :cl-rustdesk.test)

(defparameter *ok* t)
(defun ok (n) (format t "  ok   ~a~%" n))
(defun bad (fmt &rest args) (setf *ok* nil) (format t "  *** FAIL ~a~%" (apply #'format nil fmt args)))
(defun checkt (n c) (if c (ok n) (bad n)))
(defun check (n got want) (if (equalp got want) (ok n) (bad "~a: ~s /= ~s" n got want)))

(defun test-addrmangle ()
  (dolist (case '((#(192 168 5 22) 41348) (#(10 0 0 1) 65535) (#(127 0 0 1) 1)))
    (destructuring-bind (octets port) case
      (let ((enc (cl-rustdesk::mangle-encode octets port)))
        (multiple-value-bind (ip p) (cl-rustdesk::mangle-decode enc)
          (check (format nil "addrmangle ~{~d~^.~}:~d" (coerce octets 'list) port)
                 (list ip p)
                 (list (format nil "~{~d~^.~}" (coerce octets 'list)) port)))))))

(defun test-protobuf ()
  (let ((out (cl-rustdesk::new-buf)))
    (cl-rustdesk::put-string out 1 "peer-id")
    (cl-rustdesk::put-int out 8 1)
    (cl-rustdesk::put-bytes out 3 #(9 8 7))
    (let ((p (cl-rustdesk::parse (cl-rustdesk::freeze out))))
      (check "protobuf string" (cl-rustdesk::bytes->string (cl-rustdesk::pfield p 1)) "peer-id")
      (check "protobuf varint" (cl-rustdesk::pfield p 8) 1)
      (check "protobuf bytes" (coerce (cl-rustdesk::pfield p 3) 'list) '(9 8 7)))))

(defun test-framing ()
  ;; frame a payload and read it back via an in-memory octet stream
  (let* ((payload (coerce (loop for i below 200 collect (mod i 256)) '(vector (unsigned-byte 8))))
         (buf (make-array 0 :element-type '(unsigned-byte 8) :adjustable t :fill-pointer 0)))
    (flet ((mk-out () (make-instance 'octet-stream :buf buf))
           (mk-in () (make-instance 'octet-stream :buf buf)))
      (cl-rustdesk::write-frame (mk-out) payload)
      (check "framing 200B round-trip" (cl-rustdesk::read-frame (mk-in)) payload))))

(defclass octet-stream (sb-gray:fundamental-binary-input-stream sb-gray:fundamental-binary-output-stream)
  ((buf :initarg :buf) (rp :initform 0)))
(defmethod stream-element-type ((s octet-stream)) '(unsigned-byte 8))
(defmethod sb-gray:stream-write-byte ((s octet-stream) b) (vector-push-extend b (slot-value s 'buf)) b)
(defmethod sb-gray:stream-read-byte ((s octet-stream))
  (with-slots (buf rp) s (if (< rp (fill-pointer buf)) (prog1 (aref buf rp) (incf rp)) :eof)))
(defmethod sb-gray:stream-force-output ((s octet-stream)) nil)

(defun test-messages ()
  ;; a PunchHoleRequest should carry id (1) and force_relay (8)
  (let* ((bytes (cl-rustdesk::msg-punch-hole-request "123456789" "KEY"))
         (outer (cl-rustdesk::parse bytes))
         (inner (cl-rustdesk::parse (cl-rustdesk::pfield outer cl-rustdesk::+punch-hole-request+))))
    (check "punch-hole-request id" (cl-rustdesk::bytes->string (cl-rustdesk::pfield inner 1)) "123456789")
    (check "punch-hole-request force_relay" (cl-rustdesk::pfield inner 8) 1)))

(defun test-registration ()
  (checkt ":rustdesk outbound (dial) registered" (ct:transport-available-p :rustdesk))
  (checkt ":rustdesk inbound (expose) registered" (ct:listener-available-p :rustdesk)))

(defun run ()
  (setf *ok* t)
  (format t "~&== cl-rustdesk offline gate ==~%")
  (test-addrmangle) (test-protobuf) (test-framing) (test-messages) (test-registration)
  (format t "~a~%" (if *ok* "ALL OK" "FAILURES ABOVE"))
  *ok*)
