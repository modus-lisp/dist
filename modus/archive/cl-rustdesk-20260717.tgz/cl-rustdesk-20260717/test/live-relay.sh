#!/usr/bin/env bash
# test/live-relay.sh — LIVE connect-by-ID test against a real rustdesk-server (hbbs+hbbr).
#
# Downloads rustdesk-server (if not cached), starts hbbs+hbbr with a token, then runs
# test/live-relay.lisp which EXPOSEs an echo handler by ID and DIALs it back through the
# relay, verifying a byte round-trip.  Needs: network (first run), sbcl+Quicklisp, cl-rustdesk
# on the ASDF path, and a non-loopback IP (RustDesk routes loopback conns to an admin path).
set -u
here=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
work="${TMPDIR:-/tmp}/cl-rustdesk-live"
mkdir -p "$work"
ver=1.1.15
zip="$work/rustdesk-server-linux-amd64.zip"
if [ ! -x "$work/amd64/hbbs" ]; then
  echo "== fetching rustdesk-server $ver =="
  curl -fsSL -o "$zip" \
    "https://github.com/rustdesk/rustdesk-server/releases/download/${ver}/rustdesk-server-linux-amd64.zip" || {
      echo "download failed (no network?) — skipping live test"; exit 0; }
  ( cd "$work" && unzip -o -q "$zip" )
fi
chmod +x "$work/amd64/hbbs" "$work/amd64/hbbr"
ip=$(hostname -I 2>/dev/null | tr ' ' '\n' | grep -vE '^127\.|^$' | head -1)
key=cltest
[ -z "$ip" ] && { echo "no non-loopback IP — skipping"; exit 0; }
pkill -x hbbs 2>/dev/null; pkill -x hbbr 2>/dev/null; sleep 1
"$work/amd64/hbbr" -k "$key" > "$work/hbbr.log" 2>&1 &
"$work/amd64/hbbs" -r "$ip" -k "$key" > "$work/hbbs.log" 2>&1 &
sleep 3
echo "== connect-by-ID relay through hbbs+hbbr @ $ip =="
: "${CL_SOURCE_REGISTRY:=(:source-registry (:tree \"$here/../..\") :inherit-configuration)}"
export CL_SOURCE_REGISTRY
RUSTDESK_SERVER="$ip" RUSTDESK_KEY="$key" \
  sbcl --dynamic-space-size 2048 --non-interactive --load "$here/live-relay.lisp" 2>&1 | grep -aE '@@'
rc=${PIPESTATUS[0]}
pkill -x hbbs 2>/dev/null; pkill -x hbbr 2>/dev/null
echo "== hbbr saw =="; grep -aoE 'got paired|Both are raw' "$work/hbbr.log" | tail -2
exit "$rc"
