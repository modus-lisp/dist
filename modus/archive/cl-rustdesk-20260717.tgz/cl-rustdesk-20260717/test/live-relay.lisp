;;;; test/live-relay.lisp — LIVE connect-by-ID relay test (needs a running hbbs+hbbr).
;;;; Driven by test/live-relay.sh, which sets RUSTDESK_SERVER / RUSTDESK_KEY.
(require :asdf)
(handler-bind ((warning #'muffle-warning)) (ql:quickload "cl-rustdesk" :silent t))

(defun echo (stream peer)
  (declare (ignore peer))
  (handler-case (loop for b = (read-byte stream nil :eof) until (eq b :eof)
                      do (write-byte b stream) (force-output stream))
    (error () nil)))

(let ((server (or (sb-ext:posix-getenv "RUSTDESK_SERVER") "127.0.0.1"))
      (key (or (sb-ext:posix-getenv "RUSTDESK_KEY") "")))
  (setf cl-rustdesk::*rendezvous-server* server cl-rustdesk:*default-relay-key* key)
  ;; be reachable by ID through the relay
  (cl-transport:expose #'echo :backend :rustdesk :id "123456789" :server server :key key :supervise nil)
  (sleep 4)                                         ; register + keepalive
  (handler-case
      (multiple-value-bind (s close) (cl-transport:dial "123456789" 0 :transport :rustdesk)
        (let ((msg (sb-ext:string-to-octets "PING-VIA-RUSTDESK-RELAY")))
          (write-sequence msg s) (force-output s)
          (let ((buf (make-array (length msg) :element-type '(unsigned-byte 8))))
            (sb-ext:with-timeout 10 (read-sequence buf s))
            (format t "~&@@ RUSTDESK-RELAY-ECHO ok=~a got=~s~%"
                    (equalp buf msg) (sb-ext:octets-to-string buf))))
        (funcall close))
    (error (e) (format t "~&@@ ERR: ~a~%" e))))
(sb-ext:exit :code 0)
