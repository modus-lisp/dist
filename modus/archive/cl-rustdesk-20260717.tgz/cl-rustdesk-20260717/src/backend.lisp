;;;; src/backend.lisp — cl-rustdesk as a cl-transport backend (:rustdesk, both directions).
;;;;
;;;; Loading this registers :rustdesk with cl-transport, addressing peers by RustDesk ID:
;;;;   (cl-transport:dial "<peer-id>" 0 :transport :rustdesk)   -> connect to a peer
;;;;   (cl-transport:expose handler :backend :rustdesk :id "…") -> be reachable by ID
;;;; through a self-hosted hbbs+hbbr relay.  Server/key come from the specials below (or
;;;; per-call keywords on EXPOSE).

(in-package #:cl-rustdesk)

(defvar *rendezvous-server* "127.0.0.1" "hbbs host used by DIAL (and EXPOSE's default).")
(defvar *secure* nil "Default for :secure — XSalsa20-Poly1305 encrypt the pipe (also used by ct:dial).")

(defun dial (peer-id &key (server *rendezvous-server*) (key *default-relay-key*) (timeout 20) (secure *secure*))
  "Connect to PEER-ID (a RustDesk ID string) through the relay.  (values stream closer).
   With :SECURE, the pipe is encrypted (ephemeral-X25519 + secretbox)."
  (dial-id peer-id :server server :key key :timeout timeout :secure secure))

(defun expose (on-connection &rest opts
               &key id (server *rendezvous-server*) (key *default-relay-key*) (secure *secure*)
                    (supervise t) (backoff 3) &allow-other-keys)
  "Be reachable as ID through the relay: register with hbbs and hand each inbound relay
   stream to ON-CONNECTION (called (stream peer)).  Returns a zero-arg closer thunk."
  (declare (ignore opts))
  (unless id (rderr "expose needs :id"))
  (let ((stop nil) thread)
    (setf thread
          (bt:make-thread
           (lambda ()
             (loop
               (handler-case (run-host :id id :server server :key key :secure secure
                                       :on-connection on-connection)
                 (error (e) (say "~&[rustdesk] host down: ~a~%" e)))
               (when (or stop (not supervise)) (return))
               (sleep backoff)))
           :name "cl-rustdesk-expose"))
    (lambda () (setf stop t) (ignore-errors (bt:destroy-thread thread)))))

;; cl-transport registration — id in place of host, port ignored.
(ct:register-transport :rustdesk
                       (lambda (id port timeout) (declare (ignore port)) (dial id :timeout timeout)))
(ct:register-listener :rustdesk
                      (lambda (on-connection opts) (apply #'expose on-connection opts)))
