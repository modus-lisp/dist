;;;; src/backend.lisp — cl-rustdesk as a cl-transport backend (:rustdesk, both directions).
;;;;
;;;; Loading this registers :rustdesk with cl-transport, addressing peers by RustDesk ID:
;;;;   (cl-transport:dial "<peer-id>" 0 :transport :rustdesk)   -> connect to a peer
;;;;   (cl-transport:expose handler :backend :rustdesk :id "…") -> be reachable by ID
;;;; through a self-hosted hbbs+hbbr relay.  Server/key come from the specials below (or
;;;; per-call keywords on EXPOSE).

(in-package #:cl-rustdesk)

(defvar *rendezvous-server* "127.0.0.1" "hbbs host used by DIAL (and EXPOSE's default).")
(defvar *secure* nil "Default for :secure — XSalsa20-Poly1305 encrypt the pipe (also used by ct:dial).")

(defvar *mode* :relay
  "Default connection mode: :relay (via hbbr), :punch (direct TCP hole-punch only), or
   :auto (try direct, fall back to relay).  Kept :relay so nothing regresses; opt in.")

(defun dial (peer-id &key (server *rendezvous-server*) (key *default-relay-key*) (timeout 20)
                          (secure *secure*) (mode *mode*) (punch-timeout 12) peer-key)
  "Connect to PEER-ID (a RustDesk ID string).  (values stream closer).  MODE :relay|:punch|:auto.
   With :SECURE, the pipe is encrypted (ephemeral-X25519 + secretbox); pass :PEER-KEY (the
   host's Ed25519 identity as 32 bytes or hex) to authenticate the host / defeat an active MITM."
  (dial-id peer-id :server server :key key :timeout timeout :secure secure
                   :mode mode :punch-timeout punch-timeout :peer-key peer-key))

(defun host-identity (&optional identity)
  "Resolve the host's Ed25519 identity secret: IDENTITY (32 bytes or hex) if given, else a
   persistent one at ~/.cl-rustdesk/identity."
  (cond ((stringp identity) (hex->bytes identity))
        (identity identity)
        (t (load-or-create-identity))))

(defun expose (on-connection &rest opts
               &key id (server *rendezvous-server*) (key *default-relay-key*) (secure *secure*)
                    identity (mode *mode*) (punch-timeout 12) (supervise t) (backoff 3) &allow-other-keys)
  "Be reachable as ID: register with hbbs and hand each inbound stream to ON-CONNECTION
   (called (stream peer)).  MODE :relay|:punch|:auto.  Returns a zero-arg closer thunk.
   With :SECURE, the host signs its handshake with an Ed25519 identity (:IDENTITY, else a
   persistent one) — its pubkey is printed for the dialer to pin via :PEER-KEY."
  (declare (ignore opts))
  (unless id (rderr "expose needs :id"))
  (let ((identity-sk (when secure (host-identity identity))) (stop nil) thread)
    (when identity-sk
      (say "~&[rustdesk] host identity (pin on the dialer as :peer-key): ~a~%"
           (bytes->hex (ed25519-pub identity-sk))))
    (setf thread
          (bt:make-thread
           (lambda ()
             (loop
               (handler-case (run-host :id id :server server :key key :secure secure
                                       :mode mode :punch-timeout punch-timeout
                                       :identity-sk identity-sk :on-connection on-connection)
                 (error (e) (say "~&[rustdesk] host down: ~a~%" e)))
               (when (or stop (not supervise)) (return))
               (sleep backoff)))
           :name "cl-rustdesk-expose"))
    (lambda () (setf stop t) (ignore-errors (bt:destroy-thread thread)))))

;; cl-transport registration — id in place of host, port ignored.
(ct:register-transport :rustdesk
                       (lambda (id port timeout) (declare (ignore port)) (dial id :timeout timeout)))
(ct:register-listener :rustdesk
                      (lambda (on-connection opts) (apply #'expose on-connection opts)))
