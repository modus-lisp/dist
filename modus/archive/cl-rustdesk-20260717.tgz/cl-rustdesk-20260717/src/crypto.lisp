;;;; src/crypto.lisp — NaCl primitives for the secure relay channel.
;;;;
;;;; X25519 key agreement + XSalsa20-Poly1305 secretbox, via ironclad.  Verified byte-for-
;;;; byte against libsodium/pynacl (see test/offline-test).  These are the same primitives
;;;; RustDesk uses (Curve25519 + XSalsa20-Poly1305); the *handshake* here is our own simple
;;;; ephemeral ECDH (confidential against a passive relay) rather than RustDesk's signed
;;;; box-sealed-key exchange — see the note in secure-stream.lisp.

(in-package #:cl-rustdesk)

(defun random-bytes (n)
  (let ((b (make-array n :element-type '(unsigned-byte 8))))
    (handler-case (with-open-file (f "/dev/urandom" :element-type '(unsigned-byte 8)) (read-sequence b f))
      (error () (ironclad:random-data n (ironclad:make-prng :fortuna))))
    b))

;;; ---- X25519 ----
(defun x25519-pub (sk) (ironclad:curve25519-key-y (ironclad:make-private-key :curve25519 :x sk)))
(defun x25519-shared (sk peer-pub)
  (ironclad:diffie-hellman (ironclad:make-private-key :curve25519 :x sk)
                           (ironclad:make-public-key :curve25519 :y peer-pub)))
(defun x25519-keypair () (let ((sk (random-bytes 32))) (values sk (x25519-pub sk))))

(defun derive-key (shared)
  "Session secretbox key from the raw X25519 shared secret (KDF: SHA-256 with a label)."
  (let ((d (ironclad:make-digest :sha256)))
    (ironclad:update-digest d (ascii "cl-rustdesk-secure-v1"))
    (ironclad:update-digest d shared)
    (ironclad:produce-digest d)))

;;; ---- XSalsa20-Poly1305 secretbox (NaCl) ----
(defun secretbox-seal (key nonce msg)
  "-> 16-byte Poly1305 tag || ciphertext (crypto_secretbox_easy layout)."
  (let* ((c (ironclad:make-cipher :xsalsa20 :key key :mode :stream :initialization-vector nonce))
         (blk0 (make-array 32 :element-type '(unsigned-byte 8) :initial-element 0))
         (ct (copy-seq (coerce msg '(simple-array (unsigned-byte 8) (*))))))
    (ironclad:encrypt-in-place c blk0)             ; first 32 keystream bytes = Poly1305 key
    (ironclad:encrypt-in-place c ct)               ; message encrypted from stream offset 32
    (let ((mac (ironclad:make-mac :poly1305 blk0)))
      (ironclad:update-mac mac ct)
      (concatenate '(simple-array (unsigned-byte 8) (*)) (ironclad:produce-mac mac) ct))))

(defun secretbox-open (key nonce boxed)
  "Verify + decrypt; signals RUSTDESK-ERROR on a bad tag."
  (when (< (length boxed) 16) (rderr "secretbox: short frame"))
  (let* ((tag (subseq boxed 0 16))
         (ct (subseq boxed 16))
         (c (ironclad:make-cipher :xsalsa20 :key key :mode :stream :initialization-vector nonce))
         (blk0 (make-array 32 :element-type '(unsigned-byte 8) :initial-element 0)))
    (ironclad:encrypt-in-place c blk0)
    (let ((mac (ironclad:make-mac :poly1305 blk0)))
      (ironclad:update-mac mac ct)
      (unless (equalp (ironclad:produce-mac mac) tag) (rderr "secretbox: authentication failed")))
    (let ((pt (copy-seq ct))) (ironclad:decrypt-in-place c pt) pt)))

(defun secretbox-nonce (seqnum dir)
  "24-byte nonce: seqnum as u64 LE in bytes 0..7, direction in byte 8 (no cross-dir reuse)."
  (let ((n (make-array 24 :element-type '(unsigned-byte 8) :initial-element 0)))
    (dotimes (i 8) (setf (aref n i) (logand (ash seqnum (* -8 i)) #xff)))
    (setf (aref n 8) dir)
    n))
