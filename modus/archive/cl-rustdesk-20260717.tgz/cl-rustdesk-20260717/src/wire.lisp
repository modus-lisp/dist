;;;; src/wire.lisp — RustDesk wire primitives: protobuf, BytesCodec framing, AddrMangle.
;;;;
;;;; Just enough protobuf (proto3) to build/parse the handful of RendezvousMessage variants
;;;; the relay path needs — hand-rolled (verified against rustdesk-server 1.1.15), no codegen.
;;;; BytesCodec is RustDesk's TCP framing; AddrMangle is its socket-address obfuscation.

(defpackage #:cl-rustdesk
  (:use #:cl)
  (:local-nicknames (#:ct #:cl-transport) (#:bt #:bordeaux-threads))
  (:export #:dial #:expose #:run-host #:*default-relay-key*
           #:rustdesk-error))

(in-package #:cl-rustdesk)

(define-condition rustdesk-error (error)
  ((msg :initarg :msg :reader rustdesk-error-msg))
  (:report (lambda (c s) (format s "rustdesk: ~a" (rustdesk-error-msg c)))))
(defun rderr (fmt &rest args) (error 'rustdesk-error :msg (apply #'format nil fmt args)))

(deftype u8vec () '(simple-array (unsigned-byte 8) (*)))
(defun u8 (n) (logand n #xff))
(defun new-buf () (make-array 0 :element-type '(unsigned-byte 8) :adjustable t :fill-pointer 0))
(defun freeze (out) (coerce out '(simple-array (unsigned-byte 8) (*))))
(defun ascii (s) (map '(vector (unsigned-byte 8)) #'char-code s))
(defun bytes->string (v) (map 'string #'code-char v))

;;; ---- protobuf wire ----------------------------------------------------------------

(defun put-varint (out n)
  (loop (if (< n #x80) (progn (vector-push-extend n out) (return))
            (progn (vector-push-extend (logior (u8 n) #x80) out) (setf n (ash n -7))))))
(defun tag (field wire) (logior (ash field 3) wire))
(defun put-len (out field bytes)                 ; wire 2 (length-delimited)
  (put-varint out (tag field 2)) (put-varint out (length bytes))
  (loop for b across bytes do (vector-push-extend b out)))
(defun put-string (out field s) (put-len out field (ascii s)))
(defun put-bytes  (out field b) (put-len out field b))
(defun put-int    (out field n) (unless (zerop n) (put-varint out (tag field 0)) (put-varint out n)))

(defun get-varint (bytes pos)
  (let ((n 0) (shift 0))
    (loop (let ((b (aref bytes pos))) (incf pos)
            (setf n (logior n (ash (logand b #x7f) shift)))
            (when (< b #x80) (return)) (incf shift 7)))
    (values n pos)))

(defun parse (bytes &optional (start 0) (end (length bytes)))
  "-> alist of (field-number . value): value is an int (varint) or a subvector (len-delim)."
  (let ((pos start) (out '()))
    (loop while (< pos end) do
      (multiple-value-bind (tg p) (get-varint bytes pos)
        (setf pos p)
        (let ((field (ash tg -3)) (wire (logand tg 7)))
          (ecase wire
            (0 (multiple-value-bind (v p2) (get-varint bytes pos) (push (cons field v) out) (setf pos p2)))
            (2 (multiple-value-bind (len p2) (get-varint bytes pos)
                 (push (cons field (subseq bytes p2 (+ p2 len))) out) (setf pos (+ p2 len))))
            (5 (push (cons field (subseq bytes pos (+ pos 4))) out) (incf pos 4))
            (1 (push (cons field (subseq bytes pos (+ pos 8))) out) (incf pos 8))))))
    (nreverse out)))
(defun pfield (parsed n) (cdr (assoc n parsed)))

;;; ---- BytesCodec framing (TCP) -----------------------------------------------------

(defun write-frame (stream payload)
  (let* ((len (length payload))
         (hl (cond ((<= len #x3F) 1) ((<= len #x3FFF) 2) ((<= len #x3FFFFF) 3) (t 4)))
         (v (logior (ash len 2) (1- hl))))
    (dotimes (i hl) (write-byte (u8 (ash v (* -8 i))) stream))
    (write-sequence payload stream) (force-output stream)))

(defun read-frame (stream)
  (let* ((b0 (read-byte stream)) (hl (1+ (logand b0 3))) (v b0))
    (loop for i from 1 below hl do (setf v (logior v (ash (read-byte stream) (* 8 i)))))
    (let* ((n (ash v -2)) (buf (make-array n :element-type '(unsigned-byte 8))) (got 0))
      (loop while (< got n) do
        (let ((r (read-sequence buf stream :start got))) (when (= r got) (error 'end-of-file :stream stream))
          (setf got r)))
      buf)))

;;; ---- AddrMangle (matches hbb_common) ----------------------------------------------

(defun mangle-encode (ip-octets port)
  "IPv4 SocketAddr -> RustDesk's obfuscated bytes.  IP-OCTETS is a 4-elt vector, PORT u16."
  (let* ((tm 0)                                  ; time factor; 0 is accepted (decode subtracts it)
         (ip (logior (aref ip-octets 0) (ash (aref ip-octets 1) 8)
                     (ash (aref ip-octets 2) 16) (ash (aref ip-octets 3) 24)))
         (v (logior (ash (+ ip tm) 49) (ash tm 17) (+ port (logand tm #xFFFF))))
         (raw (make-array 16 :element-type '(unsigned-byte 8))))
    (dotimes (i 16) (setf (aref raw i) (u8 (ash v (* -8 i)))))
    ;; strip trailing zero bytes
    (let ((n 16)) (loop while (and (> n 0) (zerop (aref raw (1- n)))) do (decf n))
      (freeze (subseq raw 0 n)))))

(defun mangle-decode (bytes)
  "RustDesk obfuscated bytes -> (values ip-string port)."
  (let ((padded (make-array 16 :element-type '(unsigned-byte 8) :initial-element 0)))
    (replace padded bytes :end2 (min 16 (length bytes)))
    (let* ((number (loop with v = 0 for i from 15 downto 0 do (setf v (logior (ash v 8) (aref padded i))) finally (return v)))
           (tm (logand (ash number -17) #xFFFFFFFF))
           (ipv (logand (- (ash number -49) tm) #xFFFFFFFF))
           (port (logand (- (logand number #xFFFFFF) (logand tm #xFFFF)) #xFFFF)))
      (values (format nil "~d.~d.~d.~d" (logand ipv #xff) (logand (ash ipv -8) #xff)
                      (logand (ash ipv -16) #xff) (logand (ash ipv -24) #xff))
              port))))
