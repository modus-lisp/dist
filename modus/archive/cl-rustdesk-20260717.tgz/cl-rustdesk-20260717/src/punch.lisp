;;;; src/punch.lisp — TCP hole-punching sockets (SO_REUSEADDR + SO_REUSEPORT) for direct P2P.
;;;;
;;;; Direct connect bypasses hbbr: each peer reuses the SAME local port it used to talk to
;;;; hbbs (so the NAT mapping hbbs observed is the one the peer dials), then both sides
;;;; connect() to each other's public address at once — TCP simultaneous open punches
;;;; through both cone NATs and yields a single connection at each end.  Mirrors RustDesk's
;;;; connect_tcp_local (hbb_common tcp.rs new_socket(local, reuse=true) -> bind -> connect).

(in-package #:cl-rustdesk)

;;; Linux socket-option numbers (SOL_SOCKET / SO_REUSEPORT / SO_ERROR).
(defconstant +sol-socket+ 1)
(defconstant +so-reuseport+ 15)
(defconstant +so-error+ 4)

(defun set-reuseport (bsd-socket)
  "SO_REUSEADDR + SO_REUSEPORT: allow several sockets to share one local port so the hbbs
   conn, the punch conn(s) and (if used) a listener can all bind the reused port."
  (setf (sb-bsd-sockets:sockopt-reuse-address bsd-socket) t)
  (let ((fd (sb-bsd-sockets:socket-file-descriptor bsd-socket)))
    (sb-alien:with-alien ((one sb-alien:int 1))
      (sb-alien:alien-funcall
       (sb-alien:extern-alien "setsockopt"
         (function sb-alien:int sb-alien:int sb-alien:int sb-alien:int
                   (sb-alien:* sb-alien:int) sb-alien:int))
       fd +sol-socket+ +so-reuseport+ (sb-alien:addr one) 4)))
  bsd-socket)

(defun so-error (fd)
  "Read SO_ERROR (0 = connected OK) after a non-blocking connect completes."
  (sb-alien:with-alien ((val sb-alien:int 0) (len sb-alien:int 4))
    (sb-alien:alien-funcall
     (sb-alien:extern-alien "getsockopt"
       (function sb-alien:int sb-alien:int sb-alien:int sb-alien:int
                 (sb-alien:* sb-alien:int) (sb-alien:* sb-alien:int)))
     fd +sol-socket+ +so-error+ (sb-alien:addr val) (sb-alien:addr len))
    val))

(defun make-reuse-tcp ()
  (set-reuseport (make-instance 'sb-bsd-sockets:inet-socket :type :stream :protocol :tcp)))

(defun bsd-stream (bsd-socket)
  (sb-bsd-sockets:socket-make-stream bsd-socket :input t :output t
                                     :element-type '(unsigned-byte 8)))

(defun sock-local (bsd-socket)
  "-> (values ip-string port) for a bound/connected inet socket."
  (multiple-value-bind (addr port) (sb-bsd-sockets:socket-name bsd-socket)
    (values (format nil "~{~d~^.~}" (coerce addr 'list)) port)))

(defun connect-reuse (remote-ip remote-port &key local-port (local-ip "0.0.0.0") (timeout 6))
  "Open a fresh SO_REUSEPORT TCP socket, optionally bound to LOCAL-IP:LOCAL-PORT, and connect
   (non-blocking, bounded by TIMEOUT seconds) to REMOTE-IP:REMOTE-PORT.  Returns the connected
   BSD socket, or NIL on failure/timeout."
  (let ((s (make-reuse-tcp)))
    (handler-case
        (progn
          (when local-port
            (sb-bsd-sockets:socket-bind s (sb-bsd-sockets:make-inet-address local-ip) local-port))
          (setf (sb-bsd-sockets:non-blocking-mode s) t)
          ;; connect() on a non-blocking socket returns EINPROGRESS (a socket-error here).
          (ignore-errors
           (sb-bsd-sockets:socket-connect s (sb-bsd-sockets:make-inet-address remote-ip) remote-port))
          (let ((fd (sb-bsd-sockets:socket-file-descriptor s)))
            (if (and (sb-sys:wait-until-fd-usable fd :output timeout)
                     (zerop (so-error fd)))
                (progn (setf (sb-bsd-sockets:non-blocking-mode s) nil) s)
                (progn (ignore-errors (sb-bsd-sockets:socket-close s)) nil))))
      (error () (ignore-errors (sb-bsd-sockets:socket-close s)) nil))))

(defun punch-barrier (&optional (period 2))
  "Align both peers to a shared wall-clock tick so their first simultaneous-open attempts
   overlap.  Waits for the next whole second that is a multiple of PERIOD (both peers, having
   near-synced clocks, converge on the same boundary).  Bounded so a skewed clock can't hang."
  (let ((start (get-universal-time)))
    (loop for u = (get-universal-time)
          until (or (and (> u start) (zerop (mod u period)))
                    (> (- u start) (1+ period)))       ; safety cap
          do (sleep 0.02))))

(defun punch-connect (peer-ip peer-port local-ip local-port
                      &key (deadline 12) (per-try 2.0) (barrier t))
  "TCP simultaneous-open hole punch — BOTH peers run this at once.  From the reused
   LOCAL-IP:LOCAL-PORT, hammer connect() at the peer's public PEER-IP:PEER-PORT with no gap,
   each attempt lingering in SYN_SENT up to PER-TRY seconds so the peer's crossing SYN is met
   with our SYN-ACK (not a RST that would tear down the NAT mapping).  A shared BARRIER lines
   the two peers up.  Returns the connected BSD socket, or NIL after DEADLINE seconds.

   No inter-attempt sleep is intentional: it keeps a socket in SYN_SENT as much of the time as
   possible, which is what lets the two SYNs cross.  A retry gap here makes the punch fail."
  (when barrier (punch-barrier))
  (let ((end (+ (get-internal-real-time) (* deadline internal-time-units-per-second))))
    (loop
      (let ((s (connect-reuse peer-ip peer-port :local-port local-port :local-ip local-ip
                                                :timeout per-try)))
        (when s (return s))
        (when (>= (get-internal-real-time) end) (return nil))))))
