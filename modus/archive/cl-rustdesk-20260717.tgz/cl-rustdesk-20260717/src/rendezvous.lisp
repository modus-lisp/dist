;;;; src/rendezvous.lisp — the connect coordination against hbbs (+ hbbr for relay).
;;;;
;;;; Two paths, chosen per call by :mode (:relay default, :punch direct-only, :auto direct+fallback).
;;;;
;;;; Relay path (connect-by-ID via hbbr):
;;;;   HOST (B):  UDP-register with hbbs (RegisterPk + RegisterPeer keepalive); on an
;;;;              incoming PunchHole / FetchLocalAddr, mint a uuid, send RelayResponse back
;;;;              (hbbs forwards it to A), and open the relay TCP conn (RequestRelay{uuid}).
;;;;   DIAL (A):  TCP PunchHoleRequest{id=B, force_relay} to hbbs; read the forwarded
;;;;              RelayResponse{uuid, relay_server}; open the relay TCP conn (RequestRelay{uuid}).
;;;;   hbbr pairs the two relay conns by uuid and pipes raw bytes.
;;;;
;;;; Direct path (TCP hole-punch, no hbbr — see src/punch.lisp):
;;;;   DIAL (A):  PunchHoleRequest WITHOUT force_relay from a reused local port; on the
;;;;              PunchHoleResponse{B_pub} it simultaneous-open connects to B (reused port).
;;;;   HOST (B):  on the PunchHole it opens a reused-port hbbs conn, sends PunchHoleSent
;;;;              (hbbs -> A learns B_pub), and simultaneous-open connects to A (reused port).
;;;;   The two SYNs cross both NATs into one direct pipe; on failure A re-requests relay.
;;;;
;;;; secure mode (X25519 + XSalsa20-Poly1305) composes over either path.

(in-package #:cl-rustdesk)

(defparameter *default-relay-key* ""
  "licence_key sent to hbbs (punch) and hbbr (relay); must match the servers' -k.")
(defparameter +rz-port+ 21116)
(defparameter +relay-port+ 21117)
(defvar *trace* (and (sb-ext:posix-getenv "RUSTDESK_TRACE") t))
(defun trace* (fmt &rest args)
  (when *trace* (apply #'format *error-output* (concatenate 'string "~&" fmt "~%") args)
    (finish-output *error-output*)))

;;; ---- RendezvousMessage field numbers (oneof) ----
(defconstant +register-peer+ 6)   (defconstant +register-peer-response+ 7)
(defconstant +punch-hole-request+ 8) (defconstant +punch-hole+ 9)
(defconstant +punch-hole-sent+ 10)
(defconstant +punch-hole-response+ 11)
(defconstant +fetch-local-addr+ 12)
(defconstant +register-pk+ 15)    (defconstant +register-pk-response+ 16)
(defconstant +request-relay+ 18)  (defconstant +relay-response+ 19)

(defun rmsg (field inner) (let ((o (new-buf))) (put-len o field inner) (freeze o)))
(defun rz-variant (parsed)
  "Return (values field-number inner-parsed) for the single set oneof field, or NIL."
  (dolist (fn (list +register-peer-response+ +punch-hole+ +punch-hole-sent+ +punch-hole-response+
                    +fetch-local-addr+ +register-pk-response+ +relay-response+
                    +request-relay+ +register-peer+ +register-pk+ +punch-hole-request+))
    (let ((v (pfield parsed fn))) (when v (return-from rz-variant (values fn (parse v))))))
  (values nil nil))

(defun random-hex (n)
  (with-open-file (f "/dev/urandom" :element-type '(unsigned-byte 8))
    (let ((b (make-array n :element-type '(unsigned-byte 8)))) (read-sequence b f)
      (string-downcase (format nil "~{~2,'0x~}" (coerce b 'list))))))

(defun msg-register-pk (id uuid pk)
  (let ((r (new-buf))) (put-string r 1 id) (put-bytes r 2 uuid) (put-bytes r 3 pk)
    (rmsg +register-pk+ (freeze r))))
(defun msg-register-peer (id serial)
  (let ((r (new-buf))) (put-string r 1 id) (put-int r 2 serial) (rmsg +register-peer+ (freeze r))))
(defconstant +nat-symmetric+ 2)                  ; NatType::SYMMETRIC
(defun msg-punch-hole-request (id key &optional (force-relay t))
  (let ((r (new-buf)))
    (put-string r 1 id)                          ; id
    ;; hbbs does NOT copy force_relay into the forwarded PunchHole; it DOES copy nat_type.
    ;; RustDesk signals 'go relay' to B by claiming nat_type = SYMMETRIC, so we do the same.
    (when force-relay (put-int r 2 +nat-symmetric+))
    (put-int r 4 0)                              ; conn_type = DEFAULT_CONN
    (put-string r 3 key)                         ; licence_key
    (when force-relay (put-int r 8 1))           ; force_relay (kept for parity; hbbs ignores it)
    (rmsg +punch-hole-request+ (freeze r))))
(defun msg-punch-hole-sent (a-socket-addr id)
  "B -> hbbs (over a fresh TCP conn): 'I'm ready'.  hbbs replies to A with a PunchHoleResponse
   carrying B's public addr (the source of this conn).  socket_addr echoes A's addr so hbbs
   routes it back to A; nat_type is left UNKNOWN so A does not force relay."
  (let ((r (new-buf)))
    (put-bytes r 1 a-socket-addr)                ; socket_addr (A's addr, echoed)
    (put-string r 2 id)                          ; id
    (rmsg +punch-hole-sent+ (freeze r))))
(defun msg-relay-response (a-socket-addr uuid relay-server)
  (let ((r (new-buf)))
    (put-bytes r 1 a-socket-addr)                ; socket_addr (A's addr, echoed) -> hbbs routes to A
    (put-string r 2 uuid) (put-string r 3 relay-server)
    (rmsg +relay-response+ (freeze r))))
(defun msg-request-relay (uuid key)
  (let ((r (new-buf)))
    (put-string r 2 uuid) (put-int r 5 0)        ; uuid ; secure = false
    (put-string r 6 key)                         ; licence_key
    (rmsg +request-relay+ (freeze r))))

;;; ---- relay TCP connection (both sides) ----
(defun open-relay (relay-server uuid key)
  "Connect to hbbr and send RequestRelay{uuid} as the first frame; returns (values stream sock).
   After this frame hbbr switches to a raw byte pipe once the peer with the same uuid arrives."
  (let* ((sock (usocket:socket-connect relay-server +relay-port+ :element-type '(unsigned-byte 8) :timeout 10))
         (s (usocket:socket-stream sock)))
    (write-frame s (msg-request-relay uuid key))
    (values s sock)))

;;; ---- DIAL (controller A) ----
(defun dial-id (peer-id &key (server "127.0.0.1") (key *default-relay-key*) (timeout 20) secure
                             (mode :relay) (punch-timeout 12) peer-key)
  "Connect to PEER-ID.  Returns (values stream closer).  MODE:
     :relay  always through hbbr (default; unchanged behaviour).
     :punch  direct TCP hole-punch only (error if the direct connect fails).
     :auto   try the direct hole-punch first, fall back to the relay on failure.
   With :SECURE the pipe is XSalsa20-Poly1305 encrypted after an ephemeral-X25519 handshake;
   :PEER-KEY (the host's Ed25519 identity, 32 bytes or hex) authenticates the host + defeats
   an active MITM relay."
  (ecase mode
    (:relay (dial-relay peer-id :server server :key key :timeout timeout :secure secure :peer-key peer-key))
    ((:punch :auto)
     (multiple-value-bind (stream closer)
         (dial-punch peer-id :server server :key key :timeout timeout :secure secure
                             :punch-timeout punch-timeout :peer-key peer-key)
       (cond (stream (values stream closer))        ; keep BOTH values (closer!)
             ((eq mode :auto)
              (trace* "[rustdesk dial] direct failed; falling back to relay")
              (dial-relay peer-id :server server :key key :timeout timeout :secure secure :peer-key peer-key))
             (t (rderr "direct hole-punch to ~a failed" peer-id)))))))

(defun dial-relay (peer-id &key (server "127.0.0.1") (key *default-relay-key*) (timeout 20) secure peer-key)
  "The relay path: PunchHoleRequest{force_relay} -> RelayResponse -> hbbr pipe."
  (let* ((sock (usocket:socket-connect server +rz-port+ :element-type '(unsigned-byte 8) :timeout 10))
         (s (usocket:socket-stream sock)))
    (write-frame s (msg-punch-hole-request peer-id key t))
    (trace* "[rustdesk dial] sent punch-hole-request (force_relay) id=~a" peer-id)
    (loop
      (let ((frame (sb-ext:with-timeout timeout (read-frame s))))
        (multiple-value-bind (fn inner) (rz-variant (parse frame))
          (trace* "[rustdesk dial] recv variant=~a" fn)
          (cond
            ((eql fn +relay-response+)
             (let ((uuid (bytes->string (pfield inner 2)))
                   (relay (let ((rs (pfield inner 3))) (if (and rs (plusp (length rs))) (bytes->string rs) server))))
               (ignore-errors (usocket:socket-close sock))   ; done with hbbs
               (multiple-value-bind (rs rsock) (open-relay relay uuid key)
                 (return (values (if secure (secure-client rs t :peer-key peer-key) rs)
                                 (lambda () (ignore-errors (usocket:socket-close rsock))))))))
            ((eql fn +punch-hole-response+)
             (ignore-errors (usocket:socket-close sock))
             (rderr "peer ~a unreachable (failure ~a)" peer-id (pfield inner 3)))
            (t nil)))))))                          ; ignore other messages, keep waiting

(defun dial-punch (peer-id &key (server "127.0.0.1") (key *default-relay-key*) (timeout 20) secure
                                (punch-timeout 12) peer-key)
  "Direct TCP hole-punch (controller A).  Sends PunchHoleRequest WITHOUT force_relay from a
   reused local port; on the PunchHoleResponse (carrying B's public addr) races reused-port
   connects to B for a direct pipe.  Returns (values stream closer), or NIL on failure.
   If B answered with a RelayResponse instead (B chose relay) it completes the relay path."
  (let ((hbbs (connect-reuse server +rz-port+ :timeout 8)))
    (unless hbbs (return-from dial-punch nil))
    (let (done result)
      (unwind-protect
           (multiple-value-bind (my-ip my-port) (sock-local hbbs)
             (let ((s (bsd-stream hbbs)))
               (write-frame s (msg-punch-hole-request peer-id key nil))
               (trace* "[rustdesk dial] sent punch-hole-request (direct) id=~a local=~a:~a"
                       peer-id my-ip my-port)
               (loop
                 (let ((frame (sb-ext:with-timeout timeout (read-frame s))))
                   (multiple-value-bind (fn inner) (rz-variant (parse frame))
                     (trace* "[rustdesk dial] recv variant=~a" fn)
                     (cond
                       ((eql fn +punch-hole-response+)
                        (let ((sa (pfield inner 1)))
                          (if (or (null sa) (zerop (length sa)))
                              (progn (trace* "[rustdesk dial] punch-hole failure ~a" (pfield inner 3))
                                     (return))
                              (multiple-value-bind (bip bport) (mangle-decode sa)
                                (trace* "[rustdesk dial] B public addr = ~a:~a; punching from ~a:~a"
                                        bip bport my-ip my-port)
                                (let ((ds (punch-connect bip bport my-ip my-port :deadline punch-timeout)))
                                  (when ds
                                    (setf done t
                                          result (list (bsd-stream ds) ds)))
                                  (return))))))
                       ((eql fn +relay-response+)
                        (let ((uuid (bytes->string (pfield inner 2)))
                              (relay (let ((rs (pfield inner 3)))
                                       (if (and rs (plusp (length rs))) (bytes->string rs) server))))
                          (trace* "[rustdesk dial] peer chose relay uuid=~a" uuid)
                          (multiple-value-bind (rs rsock) (open-relay relay uuid key)
                            (setf done t result (list rs rsock :relay)))
                          (return)))
                       (t nil)))))))
        (ignore-errors (sb-bsd-sockets:socket-close hbbs)))
      (when done
        (destructuring-bind (stream sock &optional relayp) result
          (declare (ignore relayp))
          (values (if secure (secure-client stream t :peer-key peer-key) stream)
                  (lambda () (ignore-errors
                              (if (typep sock 'sb-bsd-sockets:socket)
                                  (sb-bsd-sockets:socket-close sock)
                                  (usocket:socket-close sock))))))))))

;;; ---- HOST (controlled B) ----
(defun run-host (&key id (server "127.0.0.1") (key *default-relay-key*) on-connection secure
                      (mode :relay) (punch-timeout 12) identity-sk
                      (pk (if identity-sk (ed25519-pub identity-sk)
                              (make-array 32 :element-type '(unsigned-byte 8) :initial-element 3))))
  "Register ID with hbbs and serve inbound relay connections, handing each raw stream to
   ON-CONNECTION (called (stream peer)).  Blocks; returns/​signals when the socket drops.
   With :SECURE + :IDENTITY-SK the host signs its ephemeral key so a dialer pinning the
   matching Ed25519 pubkey (PK, also registered with hbbs) can authenticate it."
  (let* ((usock (usocket:socket-connect server +rz-port+ :protocol :datagram
                                        :element-type '(unsigned-byte 8)))
         (uuid16 (let ((b (make-array 16 :element-type '(unsigned-byte 8)))) ; register uuid (device)
                   (with-open-file (f "/dev/urandom" :element-type '(unsigned-byte 8)) (read-sequence b f)) b))
         (last-reg 0) (rbuf (make-array 1500 :element-type '(unsigned-byte 8))))
    (labels ((send (bytes) (usocket:socket-send usock bytes (length bytes)))
             (now () (get-universal-time))
             (register () (send (msg-register-pk id uuid16 pk)) (send (msg-register-peer id 0))
                          (setf last-reg (now)))
             (start-relay (a-addr relay-server)
               (let ((uuid (random-hex 16)))
                 (trace* "[rustdesk host] start-relay uuid=~a relay=~a" uuid relay-server)
                 ;; RelayResponse goes over a fresh TCP conn to hbbs (handle_tcp forwards it to A)
                 (ignore-errors
                   (let* ((tsock (usocket:socket-connect server +rz-port+ :element-type '(unsigned-byte 8) :timeout 10))
                          (ts (usocket:socket-stream tsock)))
                     (write-frame ts (msg-relay-response a-addr uuid (or relay-server "")))
                     (finish-output ts) (sleep 0.3)
                     (ignore-errors (usocket:socket-close tsock))))
                 (bt:make-thread
                  (lambda ()
                    (handler-case
                        (multiple-value-bind (rs rsock) (open-relay (if (and relay-server (plusp (length relay-server)))
                                                                        relay-server server)
                                                                    uuid key)
                          (unwind-protect
                               (funcall on-connection (if secure (secure-client rs nil :identity-sk identity-sk) rs) (list :id id))
                            (ignore-errors (usocket:socket-close rsock))))
                      (error (e) (say "~&[rustdesk] relay conn: ~a~%" e))))
                  :name "cl-rustdesk-conn")))
             (start-punch (a-addr)
               ;; Direct TCP hole-punch (controlled B).  Open a fresh reused-port TCP conn to
               ;; hbbs (its source becomes B's public addr); tell A we're ready via PunchHoleSent
               ;; (hbbs forwards B's public addr to A in a PunchHoleResponse); then run the SAME
               ;; simultaneous-open punch A runs -> the two SYNs cross both NATs into one pipe.
               (bt:make-thread
                (lambda ()
                  (handler-case
                      (let ((hbbs (connect-reuse server +rz-port+ :timeout 8)))
                        (when hbbs
                          (multiple-value-bind (my-ip my-port) (sock-local hbbs)
                            (multiple-value-bind (aip aport) (mangle-decode a-addr)
                              (trace* "[rustdesk host] punch: A=~a:~a local=~a:~a" aip aport my-ip my-port)
                              (write-frame (bsd-stream hbbs) (msg-punch-hole-sent a-addr id))
                              (ignore-errors (sb-bsd-sockets:socket-close hbbs))
                              (let ((ds (punch-connect aip aport my-ip my-port :deadline punch-timeout)))
                                (if ds
                                    (unwind-protect
                                         (progn
                                           (trace* "[rustdesk host] direct pipe established with ~a:~a" aip aport)
                                           (funcall on-connection
                                                    (if secure (secure-client (bsd-stream ds) nil :identity-sk identity-sk) (bsd-stream ds))
                                                    (list :id id :direct t)))
                                      (ignore-errors (sb-bsd-sockets:socket-close ds)))
                                    (trace* "[rustdesk host] direct punch failed (A may fall back to relay)")))))))
                    (error (e) (say "~&[rustdesk] punch conn: ~a~%" e))))
                :name "cl-rustdesk-punch")))
      (register)
      (trace* "[rustdesk host] registered id=~a" id)
      (loop
        ;; keepalive
        (when (> (- (now) last-reg) 15) (send (msg-register-peer id 0)) (setf last-reg (now)))
        ;; bounded receive via wait-for-input — dispatch punch / fetch-local-addr / responses
        (when (usocket:wait-for-input usock :timeout 3 :ready-only t)
          (handler-case
              (multiple-value-bind (b size) (usocket:socket-receive usock rbuf 1500)
                (declare (ignore b))
                (when (and size (plusp size))
                  (multiple-value-bind (fn inner) (rz-variant (parse (subseq rbuf 0 size)))
                    (trace* "[rustdesk host] recv variant=~a" fn)
                    (cond
                      ((eql fn +register-pk-response+))                       ; ok
                      ((eql fn +register-peer-response+)
                       (when (and (pfield inner 2) (not (zerop (pfield inner 2)))) ; request_pk
                         (send (msg-register-pk id uuid16 pk))))
                      ((or (eql fn +punch-hole+) (eql fn +fetch-local-addr+))
                       (let* ((relay-server (let ((rs (pfield inner 2))) (and rs (bytes->string rs))))
                              ;; A asks for relay by claiming nat_type = SYMMETRIC (PunchHole field 3).
                              (want-relay (and (eql fn +punch-hole+)
                                               (eql (pfield inner 3) +nat-symmetric+))))
                         (if (and (member mode '(:punch :auto))
                                  (eql fn +punch-hole+) (not want-relay))
                             (start-punch (pfield inner 1))          ; direct hole-punch
                             (start-relay (pfield inner 1) relay-server))))
                      (t nil)))))
            (error (e) (trace* "[rustdesk host] recv err: ~a" e))))))))

(defun say (fmt &rest args) (apply #'format *error-output* fmt args) (finish-output *error-output*))
