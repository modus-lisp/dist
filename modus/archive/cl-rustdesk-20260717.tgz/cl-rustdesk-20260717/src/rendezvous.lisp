;;;; src/rendezvous.lisp — the relay coordination against hbbs + hbbr.
;;;;
;;;; Relay path (no hole-punching), connect-by-ID:
;;;;   HOST (B):  UDP-register with hbbs (RegisterPk + RegisterPeer keepalive); on an
;;;;              incoming PunchHole / FetchLocalAddr, mint a uuid, send RelayResponse back
;;;;              (hbbs forwards it to A), and open the relay TCP conn (RequestRelay{uuid}).
;;;;   DIAL (A):  TCP PunchHoleRequest{id=B, force_relay} to hbbs; read the forwarded
;;;;              RelayResponse{uuid, relay_server}; open the relay TCP conn (RequestRelay{uuid}).
;;;;   hbbr pairs the two relay conns by uuid and pipes raw bytes.  secure=false (MVP).

(in-package #:cl-rustdesk)

(defparameter *default-relay-key* ""
  "licence_key sent to hbbs (punch) and hbbr (relay); must match the servers' -k.")
(defparameter +rz-port+ 21116)
(defparameter +relay-port+ 21117)
(defvar *trace* (and (sb-ext:posix-getenv "RUSTDESK_TRACE") t))
(defun trace* (fmt &rest args)
  (when *trace* (apply #'format *error-output* (concatenate 'string "~&" fmt "~%") args)
    (finish-output *error-output*)))

;;; ---- RendezvousMessage field numbers (oneof) ----
(defconstant +register-peer+ 6)   (defconstant +register-peer-response+ 7)
(defconstant +punch-hole-request+ 8) (defconstant +punch-hole+ 9)
(defconstant +punch-hole-response+ 11)
(defconstant +fetch-local-addr+ 12)
(defconstant +register-pk+ 15)    (defconstant +register-pk-response+ 16)
(defconstant +request-relay+ 18)  (defconstant +relay-response+ 19)

(defun rmsg (field inner) (let ((o (new-buf))) (put-len o field inner) (freeze o)))
(defun rz-variant (parsed)
  "Return (values field-number inner-parsed) for the single set oneof field, or NIL."
  (dolist (fn (list +register-peer-response+ +punch-hole+ +punch-hole-response+
                    +fetch-local-addr+ +register-pk-response+ +relay-response+
                    +request-relay+ +register-peer+ +register-pk+ +punch-hole-request+))
    (let ((v (pfield parsed fn))) (when v (return-from rz-variant (values fn (parse v))))))
  (values nil nil))

(defun random-hex (n)
  (with-open-file (f "/dev/urandom" :element-type '(unsigned-byte 8))
    (let ((b (make-array n :element-type '(unsigned-byte 8)))) (read-sequence b f)
      (string-downcase (format nil "~{~2,'0x~}" (coerce b 'list))))))

(defun msg-register-pk (id uuid pk)
  (let ((r (new-buf))) (put-string r 1 id) (put-bytes r 2 uuid) (put-bytes r 3 pk)
    (rmsg +register-pk+ (freeze r))))
(defun msg-register-peer (id serial)
  (let ((r (new-buf))) (put-string r 1 id) (put-int r 2 serial) (rmsg +register-peer+ (freeze r))))
(defun msg-punch-hole-request (id key)
  (let ((r (new-buf)))
    (put-string r 1 id)                          ; id
    (put-int r 4 0)                              ; conn_type = DEFAULT_CONN
    (put-string r 3 key)                         ; licence_key
    (put-int r 8 1)                              ; force_relay = true
    (rmsg +punch-hole-request+ (freeze r))))
(defun msg-relay-response (a-socket-addr uuid relay-server)
  (let ((r (new-buf)))
    (put-bytes r 1 a-socket-addr)                ; socket_addr (A's addr, echoed) -> hbbs routes to A
    (put-string r 2 uuid) (put-string r 3 relay-server)
    (rmsg +relay-response+ (freeze r))))
(defun msg-request-relay (uuid key)
  (let ((r (new-buf)))
    (put-string r 2 uuid) (put-int r 5 0)        ; uuid ; secure = false
    (put-string r 6 key)                         ; licence_key
    (rmsg +request-relay+ (freeze r))))

;;; ---- relay TCP connection (both sides) ----
(defun open-relay (relay-server uuid key)
  "Connect to hbbr and send RequestRelay{uuid} as the first frame; returns (values stream sock).
   After this frame hbbr switches to a raw byte pipe once the peer with the same uuid arrives."
  (let* ((sock (usocket:socket-connect relay-server +relay-port+ :element-type '(unsigned-byte 8) :timeout 10))
         (s (usocket:socket-stream sock)))
    (write-frame s (msg-request-relay uuid key))
    (values s sock)))

;;; ---- DIAL (controller A) ----
(defun dial-id (peer-id &key (server "127.0.0.1") (key *default-relay-key*) (timeout 20))
  "Connect to PEER-ID through the relay.  Returns (values stream closer)."
  (let* ((sock (usocket:socket-connect server +rz-port+ :element-type '(unsigned-byte 8) :timeout 10))
         (s (usocket:socket-stream sock)))
    (write-frame s (msg-punch-hole-request peer-id key))
    (trace* "[rustdesk dial] sent punch-hole-request id=~a" peer-id)
    (loop
      (let ((frame (sb-ext:with-timeout timeout (read-frame s))))
        (multiple-value-bind (fn inner) (rz-variant (parse frame))
          (trace* "[rustdesk dial] recv variant=~a" fn)
          (cond
            ((eql fn +relay-response+)
             (let ((uuid (bytes->string (pfield inner 2)))
                   (relay (let ((rs (pfield inner 3))) (if (and rs (plusp (length rs))) (bytes->string rs) server))))
               (ignore-errors (usocket:socket-close sock))   ; done with hbbs
               (multiple-value-bind (rs rsock) (open-relay relay uuid key)
                 (return (values rs (lambda () (ignore-errors (usocket:socket-close rsock))))))))
            ((eql fn +punch-hole-response+)
             (ignore-errors (usocket:socket-close sock))
             (rderr "peer ~a unreachable (failure ~a)" peer-id (pfield inner 3)))
            (t nil)))))))                          ; ignore other messages, keep waiting

;;; ---- HOST (controlled B) ----
(defun run-host (&key id (server "127.0.0.1") (key *default-relay-key*) on-connection
                      (pk (make-array 32 :element-type '(unsigned-byte 8) :initial-element 3)))
  "Register ID with hbbs and serve inbound relay connections, handing each raw stream to
   ON-CONNECTION (called (stream peer)).  Blocks; returns/​signals when the socket drops."
  (let* ((usock (usocket:socket-connect server +rz-port+ :protocol :datagram
                                        :element-type '(unsigned-byte 8)))
         (uuid16 (let ((b (make-array 16 :element-type '(unsigned-byte 8)))) ; register uuid (device)
                   (with-open-file (f "/dev/urandom" :element-type '(unsigned-byte 8)) (read-sequence b f)) b))
         (last-reg 0) (rbuf (make-array 1500 :element-type '(unsigned-byte 8))))
    (labels ((send (bytes) (usocket:socket-send usock bytes (length bytes)))
             (now () (get-universal-time))
             (register () (send (msg-register-pk id uuid16 pk)) (send (msg-register-peer id 0))
                          (setf last-reg (now)))
             (start-relay (a-addr relay-server)
               (let ((uuid (random-hex 16)))
                 (trace* "[rustdesk host] start-relay uuid=~a relay=~a" uuid relay-server)
                 ;; RelayResponse goes over a fresh TCP conn to hbbs (handle_tcp forwards it to A)
                 (ignore-errors
                   (let* ((tsock (usocket:socket-connect server +rz-port+ :element-type '(unsigned-byte 8) :timeout 10))
                          (ts (usocket:socket-stream tsock)))
                     (write-frame ts (msg-relay-response a-addr uuid (or relay-server "")))
                     (finish-output ts) (sleep 0.3)
                     (ignore-errors (usocket:socket-close tsock))))
                 (bt:make-thread
                  (lambda ()
                    (handler-case
                        (multiple-value-bind (rs rsock) (open-relay (if (and relay-server (plusp (length relay-server)))
                                                                        relay-server server)
                                                                    uuid key)
                          (unwind-protect (funcall on-connection rs (list :id id))
                            (ignore-errors (usocket:socket-close rsock))))
                      (error (e) (say "~&[rustdesk] relay conn: ~a~%" e))))
                  :name "cl-rustdesk-conn"))))
      (register)
      (trace* "[rustdesk host] registered id=~a" id)
      (loop
        ;; keepalive
        (when (> (- (now) last-reg) 15) (send (msg-register-peer id 0)) (setf last-reg (now)))
        ;; bounded receive via wait-for-input — dispatch punch / fetch-local-addr / responses
        (when (usocket:wait-for-input usock :timeout 3 :ready-only t)
          (handler-case
              (multiple-value-bind (b size) (usocket:socket-receive usock rbuf 1500)
                (declare (ignore b))
                (when (and size (plusp size))
                  (multiple-value-bind (fn inner) (rz-variant (parse (subseq rbuf 0 size)))
                    (trace* "[rustdesk host] recv variant=~a" fn)
                    (cond
                      ((eql fn +register-pk-response+))                       ; ok
                      ((eql fn +register-peer-response+)
                       (when (and (pfield inner 2) (not (zerop (pfield inner 2)))) ; request_pk
                         (send (msg-register-pk id uuid16 pk))))
                      ((or (eql fn +punch-hole+) (eql fn +fetch-local-addr+))
                       (start-relay (pfield inner 1) (let ((rs (pfield inner 2))) (and rs (bytes->string rs)))))
                      (t nil)))))
            (error (e) (trace* "[rustdesk host] recv err: ~a" e))))))))

(defun say (fmt &rest args) (apply #'format *error-output* fmt args) (finish-output *error-output*))
