;;;; src/secure-stream.lisp — an encrypted framing over the raw relay pipe.
;;;;
;;;; Once the peers are connected (relay or direct punch), each side does an ephemeral X25519
;;;; exchange over the pipe and derives a shared secretbox key; every subsequent frame is
;;;; XSalsa20-Poly1305 secretbox'd with a per-direction seqnum nonce.  Both keys are ephemeral
;;;; (forward secrecy), and directions use distinct nonce space (no cross-direction reuse,
;;;; unlike RustDesk's own stream).
;;;;
;;;; AUTHENTICATION (defeats an ACTIVE MITM relay): the HOST signs its ephemeral pubkey with a
;;;; persistent Ed25519 IDENTITY key; a DIALER that PINS the host's identity pubkey (PEER-KEY)
;;;; verifies the signature and aborts on mismatch.  Without identity/peer-key the handshake is
;;;; unauthenticated — confidential against a passive relay only.

(in-package #:cl-rustdesk)

(defclass secure-stream (sb-gray:fundamental-binary-input-stream
                         sb-gray:fundamental-binary-output-stream)
  ((under :initarg :under :reader ss-under)
   (key :initarg :key :reader ss-key)
   (send-dir :initarg :send-dir) (recv-dir :initarg :recv-dir)
   (send-seq :initform 0) (recv-seq :initform 0)
   (wbuf :initform (make-array 0 :element-type '(unsigned-byte 8) :adjustable t :fill-pointer 0))
   (rbuf :initform (make-array 0 :element-type '(unsigned-byte 8))) (rpos :initform 0)))

(defmethod stream-element-type ((s secure-stream)) '(unsigned-byte 8))

(defun %secure-stream (under sk peer-eph initiator)
  (make-instance 'secure-stream :under under :key (derive-key (x25519-shared sk peer-eph))
                 :send-dir (if initiator 0 1) :recv-dir (if initiator 1 0)))

(defun secure-client (under initiator &key identity-sk peer-key)
  "Run the handshake over UNDER (relay or direct pipe) and return a SECURE-STREAM.  Both
   sides use FRESH ephemeral X25519 keys (forward secrecy), and derive the session key from
   the X25519 of the two ephemerals.

   Authentication (defeats an ACTIVE MITM relay): the HOST (INITIATOR nil) signs its
   ephemeral pubkey with its Ed25519 IDENTITY-SK; the DIALER (INITIATOR t) that pins the
   host's identity via PEER-KEY verifies that signature and aborts on mismatch.  Without
   IDENTITY-SK/PEER-KEY the handshake is unauthenticated (confidential vs a passive relay)."
  (when (stringp peer-key) (setf peer-key (hex->bytes peer-key)))
  (multiple-value-bind (eph-sk eph-pk) (x25519-keypair)
    (cond
      ((not initiator)                          ; HOST / responder: send [eph | sig?], then read
       (write-frame under (if identity-sk
                              (concatenate '(simple-array (unsigned-byte 8) (*))
                                           eph-pk (ed25519-sign identity-sk eph-pk))
                              eph-pk))
       (%secure-stream under eph-sk (read-frame under) initiator))
      (t                                         ; DIALER / initiator: read [eph | sig?], verify, send eph
       (let* ((msg (read-frame under))
              (peer-eph (subseq msg 0 32))
              (sig (when (>= (length msg) 96) (subseq msg 32 96))))
         (when peer-key
           (unless (and sig (ed25519-verify peer-key peer-eph sig))
             (rderr "secure: peer identity verification FAILED — wrong pinned key or active MITM")))
         (write-frame under eph-pk)
         (%secure-stream under eph-sk peer-eph initiator))))))

;;; ---- output: buffer, then seal+frame on force-output ----
(defmethod sb-gray:stream-write-byte ((s secure-stream) b)
  (vector-push-extend b (slot-value s 'wbuf)) b)
(defmethod sb-gray:stream-write-sequence ((s secure-stream) seq &optional (start 0) end)
  (loop for i from start below (or end (length seq)) do (vector-push-extend (elt seq i) (slot-value s 'wbuf)))
  seq)
(defun %flush (s)
  (with-slots (under key send-dir send-seq wbuf) s
    (when (plusp (length wbuf))
      (incf send-seq)
      (write-frame under (secretbox-seal key (secretbox-nonce send-seq send-dir)
                                         (coerce wbuf '(simple-array (unsigned-byte 8) (*)))))
      (setf (fill-pointer wbuf) 0))))
(defmethod sb-gray:stream-force-output ((s secure-stream)) (%flush s) (force-output (ss-under s)))
(defmethod sb-gray:stream-finish-output ((s secure-stream)) (%flush s) (finish-output (ss-under s)))

;;; ---- input: read one frame, open, serve bytes ----
(defun %fill (s)
  (with-slots (under key recv-dir recv-seq rbuf rpos) s
    (when (>= rpos (length rbuf))
      (incf recv-seq)
      (setf rbuf (secretbox-open key (secretbox-nonce recv-seq recv-dir) (read-frame under)) rpos 0))))
(defmethod sb-gray:stream-read-byte ((s secure-stream))
  (handler-case (progn (%fill s)
                       (with-slots (rbuf rpos) s (prog1 (aref rbuf rpos) (incf rpos))))
    (end-of-file () :eof)))
(defmethod sb-gray:stream-read-sequence ((s secure-stream) seq &optional (start 0) end)
  (let ((end (or end (length seq))) (i start))
    (handler-case
        (loop while (< i end) do (%fill s)
              (with-slots (rbuf rpos) s
                (loop while (and (< i end) (< rpos (length rbuf)))
                      do (setf (elt seq i) (aref rbuf rpos)) (incf i) (incf rpos))))
      (end-of-file () nil))
    i))

(defmethod close ((s secure-stream) &key abort)
  (unless abort (ignore-errors (%flush s)))
  (ignore-errors (close (ss-under s) :abort abort)))
