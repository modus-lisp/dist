;;;; src/secure-stream.lisp — an encrypted framing over the raw relay pipe.
;;;;
;;;; After the relay pairs the two peers, each side does an ephemeral X25519 exchange over
;;;; the raw pipe and derives a shared secretbox key; every subsequent frame is
;;;; XSalsa20-Poly1305 secretbox'd with a per-direction seqnum nonce.  This gives
;;;; confidentiality + integrity against a PASSIVE relay (an honest-but-curious hbbr can no
;;;; longer read the traffic).  It is *not* yet authenticated against an ACTIVE MITM relay
;;;; — that needs pinning the peer's hbbs-registered identity key (RustDesk's signed
;;;; box-sealed-key exchange); see README "Not yet".  Directions use distinct nonce space,
;;;; so unlike RustDesk's own stream there is no cross-direction nonce reuse.

(in-package #:cl-rustdesk)

(defclass secure-stream (sb-gray:fundamental-binary-input-stream
                         sb-gray:fundamental-binary-output-stream)
  ((under :initarg :under :reader ss-under)
   (key :initarg :key :reader ss-key)
   (send-dir :initarg :send-dir) (recv-dir :initarg :recv-dir)
   (send-seq :initform 0) (recv-seq :initform 0)
   (wbuf :initform (make-array 0 :element-type '(unsigned-byte 8) :adjustable t :fill-pointer 0))
   (rbuf :initform (make-array 0 :element-type '(unsigned-byte 8))) (rpos :initform 0)))

(defmethod stream-element-type ((s secure-stream)) '(unsigned-byte 8))

(defun secure-client (under initiator)
  "Run the ephemeral-X25519 handshake over UNDER (the raw relay stream) and return a
   SECURE-STREAM.  Both peers send their pubkey then read the peer's, so no deadlock."
  (multiple-value-bind (sk pk) (x25519-keypair)
    (write-frame under pk)
    (let* ((peer-pk (read-frame under))
           (key (derive-key (x25519-shared sk peer-pk))))
      (make-instance 'secure-stream :under under :key key
                     :send-dir (if initiator 0 1) :recv-dir (if initiator 1 0)))))

;;; ---- output: buffer, then seal+frame on force-output ----
(defmethod sb-gray:stream-write-byte ((s secure-stream) b)
  (vector-push-extend b (slot-value s 'wbuf)) b)
(defmethod sb-gray:stream-write-sequence ((s secure-stream) seq &optional (start 0) end)
  (loop for i from start below (or end (length seq)) do (vector-push-extend (elt seq i) (slot-value s 'wbuf)))
  seq)
(defun %flush (s)
  (with-slots (under key send-dir send-seq wbuf) s
    (when (plusp (length wbuf))
      (incf send-seq)
      (write-frame under (secretbox-seal key (secretbox-nonce send-seq send-dir)
                                         (coerce wbuf '(simple-array (unsigned-byte 8) (*)))))
      (setf (fill-pointer wbuf) 0))))
(defmethod sb-gray:stream-force-output ((s secure-stream)) (%flush s) (force-output (ss-under s)))
(defmethod sb-gray:stream-finish-output ((s secure-stream)) (%flush s) (finish-output (ss-under s)))

;;; ---- input: read one frame, open, serve bytes ----
(defun %fill (s)
  (with-slots (under key recv-dir recv-seq rbuf rpos) s
    (when (>= rpos (length rbuf))
      (incf recv-seq)
      (setf rbuf (secretbox-open key (secretbox-nonce recv-seq recv-dir) (read-frame under)) rpos 0))))
(defmethod sb-gray:stream-read-byte ((s secure-stream))
  (handler-case (progn (%fill s)
                       (with-slots (rbuf rpos) s (prog1 (aref rbuf rpos) (incf rpos))))
    (end-of-file () :eof)))
(defmethod sb-gray:stream-read-sequence ((s secure-stream) seq &optional (start 0) end)
  (let ((end (or end (length seq))) (i start))
    (handler-case
        (loop while (< i end) do (%fill s)
              (with-slots (rbuf rpos) s
                (loop while (and (< i end) (< rpos (length rbuf)))
                      do (setf (elt seq i) (aref rbuf rpos)) (incf i) (incf rpos))))
      (end-of-file () nil))
    i))

(defmethod close ((s secure-stream) &key abort)
  (unless abort (ignore-errors (%flush s)))
  (ignore-errors (close (ss-under s) :abort abort)))
