;;;; inspect/open-channel.lisp
;;;;
;;;; The Phase 4 milestone — open a real channel against a real node.
;;;;
;;;; Everything in BOLT #3 was verified against published vectors, which proves
;;;; we agree with the SPEC.  This proves we agree with an IMPLEMENTATION, and it
;;;; is a much harder thing to fake: Core Lightning verifies our signature over
;;;; the commitment transaction IT will hold.  If any of the key derivation, the
;;;; output construction, the fee, the obscured commitment number or the BIP143
;;;; digest is wrong, that signature does not verify and the channel is refused.
;;;;
;;;; The funding transaction is built but NOT broadcast until `funding_signed`
;;;; arrives.  That ordering is the opener's only protection: the funding output
;;;; is a 2-of-2, so broadcasting before holding a signature that returns the
;;;; money means an uncooperative counterparty can strand it forever.
;;;;
;;;;   CL_PAYMENTS_PEER=<node_id>@127.0.0.1:9835 sbcl --load inspect/open-channel.lisp --quit

(require :asdf)
(asdf:initialize-source-registry
 (let ((here (make-pathname :name nil :type nil :defaults *load-truename*)))
   `(:source-registry (:tree ,(merge-pathnames "../" here))
                      (:tree ,(merge-pathnames "../../" here))
                      :inherit-configuration)))
(handler-bind ((warning #'muffle-warning)) (asdf:load-system "cl-payments"))

(defpackage #:open-channel
  (:use #:cl)
  (:local-nicknames (#:c #:cl-payments.crypto) (#:w #:cl-payments.wire)
                    (#:p #:cl-payments.peer) (#:k #:cl-payments.keys)
                    (#:m #:cl-payments.commitment) (#:ch #:cl-payments.channel)
                    (#:btx #:cl-consensus.tx) (#:bw #:cl-consensus.wire)
                    (#:secp #:secp256k1-fast) (#:bt #:bordeaux-threads)
                    (#:benc #:cl-consensus.encoding)
                    (#:n #:cl-payments.node) (#:gs #:cl-payments.gossip)
                    (#:bb #:cl-consensus.block))
  (:export #:run))

(in-package #:open-channel)

(defparameter *bitcoin-cli*
  "/mnt/lisp/signet/bin/bitcoin-cli -signet -datadir=/mnt/lisp/signet/bitcoin -rpcwallet=miner")

(defun bcli (&rest args)
  (string-trim '(#\Newline #\Space)
               (with-output-to-string (s)
                 (uiop:run-program (format nil "~a ~{~a ~}" *bitcoin-cli* args)
                                   :output s :error-output nil))))

(defun json-string (json field)
  "Pull a string FIELD out of bitcoin-cli's JSON.  Deliberately tiny — pulling in
   a JSON parser for two fields would add a dependency to the whole system for
   the sake of one test script."
  (let* ((key (format nil "\"~a\": \"" field))
         (at (search key json)))
    (unless at (error "no ~a in ~a" field json))
    (let ((start (+ at (length key))))
      (subseq json start (position #\" json :start start)))))

(defun json-number (json field)
  "Pull a numeric FIELD out of bitcoin-cli's JSON.  Same reasoning as
   JSON-STRING: two fields is not worth a parser dependency."
  (let* ((key (format nil "\"~a\": " field))
         (at (search key json)))
    (unless at (error "no ~a in ~a" field json))
    (parse-integer json :start (+ at (length key)) :junk-allowed t)))

(defvar *step* 0)
(defun step! (fmt &rest args)
  (format t "~&~%~d. ~?~%" (incf *step*) fmt args)
  (force-output))
(defun note (fmt &rest args) (format t "   ~?~%" fmt args) (force-output))

;;; ----------------------------------------------------------------------------

;;; Channel keys are DERIVED from the node key and an index, not generated
;;; randomly.  Random keys would make this script the only thing in the world
;;; that knows half of a 2-of-2 holding real funds: the moment it exits, the
;;; channel is unannounceable by the daemon and — worse — unspendable.  The
;;; struct is kept so the flow below reads unchanged.
(defstruct our-keys funding revocation payment delayed htlc seed index)

(defun derived-keys (node-privkey index)
  (let ((ck (n:derive-channel-keys node-privkey index)))
    (make-our-keys :funding (n:ck-funding ck) :revocation (n:ck-revocation ck)
                   :payment (n:ck-payment ck) :delayed (n:ck-delayed ck)
                   :htlc (n:ck-htlc ck) :seed (n:ck-seed ck) :index index)))

(defun next-key-index (dir)
  "One past the highest index any recorded channel uses.  Reusing an index would
   reuse a funding key across two channels, and a revocation secret leaked on one
   would then apply to the other."
  (let ((path (merge-pathnames "channels.sexp" (uiop:ensure-directory-pathname dir))))
    (if (probe-file path)
        (with-open-file (s path)
          (loop for form = (read s nil) while form
                maximize (1+ (or (getf form :key-index) 0))))
        0)))

(defun scid-of (txid-hex vout)
  "Where the funding output landed, as a short channel id.  A channel is NAMED by
   its funding outpoint's position in the chain, so this has to come from the
   chain rather than from anything either peer said.

   The block is fetched as raw hex and parsed with cl-consensus rather than
   scraped out of bitcoin-cli's JSON.  A first attempt did scrape it, and found
   the funding transaction at index 0 — the coinbase's slot, which no real
   transaction can occupy.  An scid that is wrong by one is not a near miss: it
   names a different output, so the announcement fails to check against the chain
   and every peer drops it silently."
  (let* ((blockhash (json-string (bcli "getrawtransaction" txid-hex "true") "blockhash"))
         (hex (bcli "getblock" blockhash "0"))
         (blk (bb:parse-block (bw:hex->bytes hex)))
         (txids (map 'list (lambda (tx) (bw:hash->hex (btx:tx-txid tx))) (bb:block-txs blk)))
         (idx (position txid-hex txids :test #'string=))
         (height (json-number (bcli "getblockheader" blockhash) "height")))
    (unless idx (error "funding tx ~a is not in block ~a" txid-hex blockhash))
    (gs:make-scid height idx vout)))

(defun run (&optional (uri (or (uiop:getenv "CL_PAYMENTS_PEER")
                               (error "set CL_PAYMENTS_PEER=<node_id>@host:port"))))
  (w:select-network :signet)
  (let* ((at (position #\@ uri)) (colon (position #\: uri :from-end t))
         (node-id (c:hex->bytes (subseq uri 0 at)))
         (host (subseq uri (1+ at) colon))
         (port (parse-integer (subseq uri (1+ colon))))
         (funding-sat 200000)
         (temp-id (c:octets (ironclad:random-data 32)))
         (inbox (make-hash-table))
         (lock (bt:make-lock)) (cv (bt:make-condition-variable)))
    ;; A PERSISTENT node key, from CL_PAYMENTS_NODE's directory.  Generating one
    ;; per run leaves an un-reclaimable channel behind every time: the channel is
    ;; a 2-of-2 with a specific counterparty, so a node that forgets its key can
    ;; never reconnect to a channel it opened.
    (let* ((our-node-key
            (let ((dir (uiop:getenv "CL_PAYMENTS_NODE")))
              (if dir
                  (secp:bytes-to-int
                   (c:hex->bytes
                    (string-trim '(#\Newline #\Space)
                                 (uiop:read-file-string
                                  (merge-pathnames "node.key"
                                                   (uiop:ensure-directory-pathname dir))))))
                  (c:generate-key))))
           (key-index (let ((dir (uiop:getenv "CL_PAYMENTS_NODE")))
                        (if dir (next-key-index dir) 0)))
           (keys (derived-keys our-node-key key-index)))
      (note "channel key index ~d (derived from the node key)" key-index)
      (let ((peer (p:connect host port node-id our-node-key
                             :chain-hashes (list (w:chain-hash))
                             :log nil :read-loop nil)))
        (unwind-protect
             (progn
               ;; Collect every message; the flow below waits on specific types.
               (dolist (ty (list ch:+msg-accept-channel+ ch:+msg-funding-signed+
                                 ch:+msg-channel-ready+ p:+msg-error+ p:+msg-warning+))
                 (let ((type ty))
                   (p:on peer type
                         (lambda (pr payload) (declare (ignore pr))
                           (bt:with-lock-held (lock)
                             (setf (gethash type inbox) payload)
                             (bt:condition-notify cv))))))
               (p:start-read-loop peer)
               (flet ((await (type seconds what)
                        (bt:with-lock-held (lock)
                          (loop with deadline = (+ (get-universal-time) seconds)
                                until (gethash type inbox)
                                do (when (gethash p:+msg-error+ inbox)
                                     (error "peer sent an error: ~a"
                                            (p::decode-error (gethash p:+msg-error+ inbox))))
                                   (when (> (get-universal-time) deadline)
                                     (error "timed out waiting for ~a" what))
                                   (bt:condition-wait cv lock :timeout 1)))
                        (gethash type inbox)))

                 (step! "connected to ~a" (subseq (c:bytes->hex node-id) 0 16))
                 (note "our node id ~a"
                       (c:bytes->hex (c:compressed-pubkey (c:pubkey-of our-node-key))))

                 ;; ---- open_channel -------------------------------------------
                 (step! "open_channel: ~d sat, nothing pushed" funding-sat)
                 (p:send-message
                  peer
                  (ch:encode-open-channel
                   (ch:make-open-channel
                    :chain-hash (w:chain-hash)
                    :temporary-channel-id temp-id
                    :funding-satoshis funding-sat
                    ;; Push a quarter of the channel to them.  A channel funded
                    ;; entirely by us is outbound-only: the peer holds nothing, so
                    ;; nobody can route a payment TOWARD us over it and the
                    ;; channel is half useless the moment it is announced.  Real
                    ;; nodes solve this by buying inbound liquidity; on a devnet,
                    ;; pushing at open is the honest equivalent.
                    :push-msat (* 1000 (floor funding-sat 4))
                    :dust-limit-satoshis 546
                    :max-htlc-value-in-flight-msat (* funding-sat 1000)
                    :channel-reserve-satoshis (floor funding-sat 100)
                    :htlc-minimum-msat 1
                    :feerate-per-kw 2500
                    :to-self-delay 144 :max-accepted-htlcs 30
                    :funding-pubkey (pub (our-keys-funding keys))
                    :revocation-basepoint (pub (our-keys-revocation keys))
                    :payment-basepoint (pub (our-keys-payment keys))
                    :delayed-payment-basepoint (pub (our-keys-delayed keys))
                    :htlc-basepoint (pub (our-keys-htlc keys))
                    :first-per-commitment-point
                    (k:per-commitment-point (our-keys-seed keys) k:+max-commitment-index+)
                    ;; channel_flags bit 0 is `announce_channel`.  With it CLEAR
                    ;; the channel is PRIVATE: the peer never sends
                    ;; announcement_signatures, no channel_announcement is ever
                    ;; produced, and the channel stays invisible to the routing
                    ;; graph — usable by its two ends and by nobody else.  A node
                    ;; that wants to ROUTE must ask to be announced.
                    :channel-flags 1))
                  nil)

                 ;; ---- accept_channel -----------------------------------------
                 (let ((acc (ch:parse-accept-channel
                             (await ch:+msg-accept-channel+ 30 "accept_channel"))))
                   (step! "accept_channel received")
                   (note "minimum_depth ~d, to_self_delay ~d, dust ~d"
                         (ch:ac-minimum-depth acc) (ch:ac-to-self-delay acc)
                         (ch:ac-dust-limit-satoshis acc))

                   ;; ---- build (but do not broadcast) the funding transaction --
                   (step! "building the funding transaction")
                   (let* ((funding-script (m:funding-script (pub (our-keys-funding keys))
                                                            (ch:ac-funding-pubkey acc)))
                          ;; Compute the P2WSH address ourselves rather than
                          ;; asking bitcoind: `deriveaddresses` wants a descriptor
                          ;; CHECKSUM, and we already have bech32 in cl-consensus.
                          (address (let ((cl-consensus.encoding::*bech32-hrp* "tb"))
                                     ;; signet shares testnet's human-readable
                                     ;; part; cl-consensus defaults to mainnet.
                                     (benc:encode-p2wsh (c:sha256 funding-script))))
                          (raw (bcli "createrawtransaction" "[]"
                                     (format nil "\"[{\\\"~a\\\":~,8f}]\""
                                             address (/ funding-sat 100000000.0d0))))
                          (funded (bcli "fundrawtransaction" raw))
                          (fhex (json-string funded "hex"))
                          (signed (bcli "signrawtransactionwithwallet" fhex))
                          (shex (json-string signed "hex"))
                          (ftx (btx:parse-tx (bw:make-reader (bw:hex->bytes shex))))
                          (fidx (position (m:p2wsh funding-script) (btx:tx-outputs ftx)
                                          :key #'btx:txout-script :test #'equalp)))
                     (note "funding txid ~a output ~a"
                           (bw:hash->hex (btx:tx-txid ftx)) fidx)
                     (unless fidx (error "our 2-of-2 output is not in the funding tx"))

                     ;; ---- sign THEIR first commitment --------------------------
                     ;; Their commitment: to_local is THEIR balance behind THEIR
                     ;; delayed key and OUR revocation key; to_remote is ours.  We
                     ;; pushed nothing, so their side is empty and only our output
                     ;; exists — the fee comes out of ours, since we opened.
                     (step! "signing their first commitment")
                     (let* ((their-pcp (ch:ac-first-per-commitment-point acc))
                            (obscuring (m:obscuring-factor (pub (our-keys-payment keys))
                                                           (ch:ac-payment-basepoint acc)))
                            (their-commitment
                              (m:build-commitment
                               :funding-txid (btx:tx-txid ftx)
                               :funding-output-index fidx
                               :funding-amount-sat funding-sat
                               :commitment-number 0 :obscuring obscuring
                               :to-local-msat 0
                               :to-remote-msat (* funding-sat 1000)
                               :local-feerate-per-kw 2500
                               :dust-limit-sat (ch:ac-dust-limit-satoshis acc)
                               ;; Revocation key in THEIR commitment is built from
                               ;; OUR revocation basepoint — it exists so WE can
                               ;; punish THEM.
                               :revocation-pubkey
                               (k:derive-revocation-pubkey (pub (our-keys-revocation keys))
                                                           their-pcp)
                               :to-self-delay 144
                               :delayed-pubkey
                               (k:derive-pubkey (ch:ac-delayed-payment-basepoint acc) their-pcp)
                               ;; option_static_remotekey: to_remote is our payment
                               ;; basepoint verbatim, with no per-commitment
                               ;; blinding at all.
                               :remote-pubkey (pub (our-keys-payment keys))
                               :opener :remote)))
                       (let ((sig (m:sign-commitment their-commitment
                                                     (our-keys-funding keys)
                                                     (pub (our-keys-funding keys))
                                                     (ch:ac-funding-pubkey acc)
                                                     funding-sat)))
                         (note "signature ~a…" (subseq (c:bytes->hex sig) 0 24))

                         ;; ---- funding_created ---------------------------------
                         (step! "funding_created (the funding tx is NOT broadcast yet)")
                         (p:send-message
                          peer
                          (ch:encode-funding-created
                           (ch:make-funding-created
                            :temporary-channel-id temp-id
                            :funding-txid (btx:tx-txid ftx)
                            :funding-output-index fidx
                            :signature sig))
                          nil)

                         ;; ---- funding_signed ----------------------------------
                         (let ((fs (ch:parse-funding-signed
                                    (await ch:+msg-funding-signed+ 30 "funding_signed"))))
                           (step! "funding_signed received — THEY ACCEPTED OUR SIGNATURE")
                           (note "channel_id ~a" (c:bytes->hex (ch:fs-channel-id fs)))
                           (note "expected   ~a"
                                 (c:bytes->hex (ch:channel-id (btx:tx-txid ftx) fidx)))
                           (note "match: ~a"
                                 (equalp (c:octets (ch:fs-channel-id fs))
                                         (c:octets (ch:channel-id (btx:tx-txid ftx) fidx))))

                           ;; ---- now it is safe to broadcast ------------------
                           (step! "broadcasting the funding transaction")
                           (note "~a" (bcli "sendrawtransaction" shex))
                           (uiop:run-program "/mnt/lisp/signet/mine.sh 6"
                                             :output nil :error-output nil
                                             :ignore-error-status t)
                           (note "mined 6 blocks")

                           ;; ---- channel_ready --------------------------------
                           (step! "channel_ready")
                           (p:send-message
                            peer
                            (ch:encode-channel-ready
                             (ch:make-channel-ready
                              :channel-id (ch:channel-id (btx:tx-txid ftx) fidx)
                              :second-per-commitment-point
                              (k:per-commitment-point (our-keys-seed keys)
                                                      (1- k:+max-commitment-index+))))
                            nil)
                           (let ((cr (await ch:+msg-channel-ready+ 60 "their channel_ready")))
                             (declare (ignore cr))
                             (step! "their channel_ready received"))
                           ;; ---- record it, so the daemon can announce it -----
                           ;;
                           ;; This script's job ends here, but the channel's does
                           ;; not.  announcement_signatures arrive minutes later,
                           ;; to whatever process is connected then — so what is
                           ;; written now is exactly what the daemon will need and
                           ;; cannot re-derive: the key index, where the funding
                           ;; landed, and the peer's half of the 2-of-2.
                           (let ((dir (uiop:getenv "CL_PAYMENTS_NODE")))
                             (when dir
                               (step! "recording the channel for the daemon")
                               (let* ((node (n:make-node :dir dir :port 0 :log nil))
                                      (txid-hex (bw:hash->hex (btx:tx-txid ftx)))
                                      (scid (handler-case (scid-of txid-hex fidx)
                                              (error (e)
                                                (note "could not resolve scid: ~a" e)
                                                nil))))
                                 (n:load-channels node)
                                 (setf (gethash (c:bytes->hex
                                                 (ch:channel-id (btx:tx-txid ftx) fidx))
                                                (n:node-channels node))
                                       (n:make-stored-channel
                                        :channel-id (ch:channel-id (btx:tx-txid ftx) fidx)
                                        :peer-id node-id
                                        :funding-txid (btx:tx-txid ftx)
                                        :funding-index fidx
                                        :capacity-sat funding-sat
                                        :local-msat (* 1000 (- funding-sat
                                                               (floor funding-sat 4)))
                                        :remote-msat (* 1000 (floor funding-sat 4))
                                        :key-index key-index
                                        :scid scid
                                        :remote-funding-pubkey (ch:ac-funding-pubkey acc)))
                                 (n:save-channels node)
                                 (note "wrote ~a (scid ~a)"
                                       (merge-pathnames "channels.sexp"
                                                        (uiop:ensure-directory-pathname dir))
                                       (if scid (gs:scid-string scid) "unknown")))))
                           (format t "~&~%✓ a real Lightning node opened a channel with us.~%")
                           t)))))))
          (ignore-errors (p:disconnect peer)))))))

(run)
