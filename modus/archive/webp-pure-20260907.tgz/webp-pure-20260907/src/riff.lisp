;;;; riff.lisp — the RIFF/WebP container: chunk walking, and the dimensions of
;;;; either kind of image without decoding it.  The VP8 frame header this asks
;;;; for, and everything under it, is reel's.
(in-package #:webp-pure)

(deftype u8 () '(unsigned-byte 8))
(deftype octets () '(simple-array (unsigned-byte 8) (*)))

;;; ---- RIFF / WebP container ---------------------------------------------

(declaim (inline u16le u24le u32le))
(defun u16le (b i) (logior (aref b i) (ash (aref b (+ i 1)) 8)))
(defun u24le (b i) (logior (aref b i) (ash (aref b (+ i 1)) 8) (ash (aref b (+ i 2)) 16)))
(defun u32le (b i) (logior (u24le b i) (ash (aref b (+ i 3)) 24)))

(defun fourcc-at (b i)
  (map 'string #'code-char (subseq b i (+ i 4))))

(defun webp-p (bytes)
  "True when BYTES begin with a RIFF/WEBP container."
  (and (>= (length bytes) 12)
       (string= (fourcc-at bytes 0) "RIFF")
       (string= (fourcc-at bytes 8) "WEBP")))

(defun find-chunk (bytes fourcc)
  "Return (values offset size) of the first chunk named FOURCC in the WebP
   container BYTES (offset points at the chunk payload), or NIL."
  (let ((n (length bytes)) (p 12))            ; after RIFF(4) size(4) WEBP(4)
    (loop while (<= (+ p 8) n) do
      (let ((tag (fourcc-at bytes p)) (size (u32le bytes (+ p 4))))
        (when (string= tag fourcc)
          (return-from find-chunk (values (+ p 8) size)))
        (incf p (+ 8 size (logand size 1)))))  ; chunks are padded to even size
    nil))

;;; ---- public entry ------------------------------------------------------

(defun dimensions (bytes)
  "Return (values width height) of the WebP in BYTES, lossy or lossless."
  (unless (webp-p bytes) (%err "not a RIFF/WebP container"))
  (multiple-value-bind (off size) (find-chunk bytes "VP8 ")
    (if off
        (let ((fr (parse-frame-header bytes off size)))
          (values (fr-width fr) (fr-height fr)))
        (multiple-value-bind (loff lsize) (find-chunk bytes "VP8L")
          (declare (ignore lsize))
          (unless loff (%err "no VP8 or VP8L chunk (animation/VP8X not supported)"))
          (vp8l-dimensions bytes loff)))))

;;; DECODE, the full pixel pipeline, is defined in decode.lisp.
