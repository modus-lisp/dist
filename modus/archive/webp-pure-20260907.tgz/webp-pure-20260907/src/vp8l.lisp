;;;; vp8l.lisp — WebP lossless (VP8L).
;;;;
;;;; The other half of WebP, and nothing like the first half: where VP8 is a
;;;; lossy video key frame (boolean arithmetic coder, DCT, prediction on 4x4/16x16
;;;; blocks), VP8L is an LZ77 + canonical-prefix-code image codec with four
;;;; reversible whole-image transforms bolted in front of it.  They share only the
;;;; RIFF container.
;;;;
;;;; The generic entropy machinery — the LSB-first bit reader, canonical prefix
;;;; codes, LZ77 back-references, the hash-addressed recent-value cache — lives in
;;;; CRAM, which already had most of it for DEFLATE.  What stays here is the part
;;;; that is actually about pictures: the 5-byte header, how a pixel position
;;;; selects one of several prefix-code groups, the distance plane-code map, and
;;;; the four inverse transforms.
;;;;
;;;; Reference: the WebP Lossless Bitstream Specification (Google, 2025-08-07),
;;;; cross-checked against libwebp's src/dec/vp8l_dec.c for the places where the
;;;; prose is looser than the code.

(in-package #:webp-pure)

(deftype argb-buffer () '(simple-array (unsigned-byte 32) (*)))

;;; A decode notes which optional features the bitstream actually used.  This is
;;; not decoration: "the decoder returned the right pixels" means very little
;;; without knowing whether the file exercised the colour cache or a transform at
;;; all, and an encoder picks those on its own.  Bound to a fresh list by the test
;;; harness; NIL means nobody is collecting.
(defvar *vp8l-features* :off
  "Bind to NIL to collect: DECODE then pushes keywords naming the VP8L features
   the file used.  The default :OFF collects nothing.")

(defun note-feature (fmt &rest args)
  (when (listp *vp8l-features*)
    (pushnew (intern (string-upcase (apply #'format nil fmt args)) :keyword)
             *vp8l-features*)))

(declaim (inline sub-sample-size))
(defun sub-sample-size (size bits)
  "DIV_ROUND_UP(SIZE, 1 << BITS) — the size of a subresolution image."
  (declare (type fixnum size bits))
  (ash (+ size (1- (ash 1 bits))) (- bits)))

;;; ---- ARGB pixel arithmetic ---------------------------------------------
;;; Pixels are packed a<<24 | r<<16 | g<<8 | b, matching the spec's ARGB order.

(declaim (inline argb pix-a pix-r pix-g pix-b add-pixels average2))
(defun argb (a r g b)
  (declare (type (unsigned-byte 8) a r g b))
  (logior (ash a 24) (ash r 16) (ash g 8) b))
(defun pix-a (p) (ldb (byte 8 24) p))
(defun pix-r (p) (ldb (byte 8 16) p))
(defun pix-g (p) (ldb (byte 8 8) p))
(defun pix-b (p) (ldb (byte 8 0) p))

(defun add-pixels (a b)
  "Add two ARGB pixels channel-wise modulo 256, all four channels at once."
  (declare (type (unsigned-byte 32) a b))
  (let ((lo (logand (+ (logand a #x00ff00ff) (logand b #x00ff00ff)) #x00ff00ff))
        (hi (logand (+ (logand (ash a -8) #x00ff00ff) (logand (ash b -8) #x00ff00ff))
                    #x00ff00ff)))
    (logior lo (ash hi 8))))

(defun average2 (a b)
  "Channel-wise floor mean of two ARGB pixels."
  (declare (type (unsigned-byte 32) a b))
  (+ (ash (logand (logxor a b) #xfefefefe) -1) (logand a b)))

;;; CLAMP255 comes from decode.lisp — the lossy and lossless halves want exactly
;;; the same 8-bit saturation.

;;; ---- predictors (spec §4.1) --------------------------------------------
;;; L = left, T = top, TR = top-right, TL = top-left.

(defun pred-select (l tp tl)
  "Predictor 11: whichever of L and T is nearer, in Manhattan distance over all
   four channels, to the estimate L + T - TL."
  (flet ((dist (shift)
           (let ((cl (ldb (byte 8 shift) l)) (ct (ldb (byte 8 shift) tp))
                 (ctl (ldb (byte 8 shift) tl)))
             ;; |p - L| = |T - TL| and |p - T| = |L - TL| for p = L + T - TL.
             (values (abs (- ct ctl)) (abs (- cl ctl))))))
    (let ((pl 0) (pt 0))
      (dolist (shift '(24 16 8 0))
        (multiple-value-bind (a b) (dist shift) (incf pl a) (incf pt b)))
      (if (< pl pt) l tp))))

(defun pred-clamp-add-subtract-full (l tp tl)
  "Predictor 12: Clamp(L + T - TL) per channel."
  (argb (clamp255 (- (+ (pix-a l) (pix-a tp)) (pix-a tl)))
        (clamp255 (- (+ (pix-r l) (pix-r tp)) (pix-r tl)))
        (clamp255 (- (+ (pix-g l) (pix-g tp)) (pix-g tl)))
        (clamp255 (- (+ (pix-b l) (pix-b tp)) (pix-b tl)))))

(defun pred-clamp-add-subtract-half (l tp tl)
  "Predictor 13: with ave = Average2(L, T), Clamp(ave + (ave - TL) / 2) per
   channel.  The division truncates toward zero, as in C — FLOOR here would be
   off by one on every negative difference."
  (let ((ave (average2 l tp)))
    (flet ((chan (shift)
             (let ((a (ldb (byte 8 shift) ave)) (b (ldb (byte 8 shift) tl)))
               (clamp255 (+ a (truncate (- a b) 2))))))
      (argb (chan 24) (chan 16) (chan 8) (chan 0)))))

(defun predict (mode l tp tr tl)
  "The predicted pixel for MODE given the four already-decoded neighbours."
  (declare (type fixnum mode))
  (case mode
    (0 #xff000000)                      ; solid black
    (1 l)
    (2 tp)
    (3 tr)
    (4 tl)
    (5 (average2 (average2 l tr) tp))
    (6 (average2 l tl))
    (7 (average2 l tp))
    (8 (average2 tl tp))
    (9 (average2 tp tr))
    (10 (average2 (average2 l tl) (average2 tp tr)))
    (11 (pred-select l tp tl))
    (12 (pred-clamp-add-subtract-full l tp tl))
    (13 (pred-clamp-add-subtract-half l tp tl))
    (t (%err "VP8L predictor mode ~d out of range" mode))))

;;; ---- distance plane codes (spec §5.2.2) --------------------------------
;;; A distance symbol below 120 does not name a linear distance but a small 2-D
;;; (x, y) offset, so that a reference to "the pixel above" costs the same few
;;; bits whatever the image width is.  Entries are packed yoffset<<4 | (8-xoffset).

(defparameter +code-to-plane+
  #(#x18 #x07 #x17 #x19 #x28 #x06 #x27 #x29 #x16 #x1a #x26 #x2a
    #x38 #x05 #x37 #x39 #x15 #x1b #x36 #x3a #x25 #x2b #x48 #x04
    #x47 #x49 #x14 #x1c #x35 #x3b #x46 #x4a #x24 #x2c #x58 #x45
    #x4b #x34 #x3c #x03 #x57 #x59 #x13 #x1d #x56 #x5a #x23 #x2d
    #x44 #x4c #x55 #x5b #x33 #x3d #x68 #x02 #x67 #x69 #x12 #x1e
    #x66 #x6a #x22 #x2e #x54 #x5c #x43 #x4d #x65 #x6b #x32 #x3e
    #x78 #x01 #x77 #x79 #x53 #x5d #x11 #x1f #x64 #x6c #x42 #x4e
    #x76 #x7a #x21 #x2f #x75 #x7b #x31 #x3f #x63 #x6d #x52 #x5e
    #x00 #x74 #x7c #x41 #x4f #x10 #x20 #x62 #x6e #x30 #x73 #x7d
    #x51 #x5f #x40 #x72 #x7e #x61 #x6f #x50 #x71 #x7f #x60 #x70)
  "The 120 short distance codes, as yoffset<<4 | (8 - xoffset).")

(defun plane-code-to-distance (xsize plane-code)
  "Turn a decoded distance code into a distance in pixels."
  (declare (type fixnum xsize plane-code))
  (if (> plane-code 120)
      (- plane-code 120)
      (let* ((c (aref +code-to-plane+ (1- plane-code)))
             (dist (+ (* (ash c -4) xsize) (- 8 (logand c #xf)))))
        (max dist 1))))

;;; ---- prefix code groups (spec §6.2.1) ----------------------------------

(defconstant +literal-codes+ 256)
(defconstant +length-codes+ 24)
(defconstant +distance-codes+ 40)

(defparameter +code-length-order+
  #(17 18 0 1 2 3 4 5 16 6 7 8 9 10 11 12 13 14 15))
(defparameter +repeat-extra-bits+ #(2 3 7))
(defparameter +repeat-offsets+ #(3 3 11))

(defun read-code-lengths (br alphabet-size)
  "Read ALPHABET-SIZE code lengths, themselves prefix-coded (the \"normal code
   length code\").  Returns the length vector, or NIL on a malformed stream."
  (let ((clcl (make-array 19 :element-type 'fixnum :initial-element 0))
        (num-codes (+ 4 (cram:read-bits br 4))))
    (dotimes (i num-codes)
      (setf (aref clcl (aref +code-length-order+ i)) (cram:read-bits br 3)))
    (let ((clcode (cram:make-prefix-code clcl)))
      (unless clcode (return-from read-code-lengths nil))
      (let ((max-symbol (if (= 1 (cram:read-bits br 1))
                            (+ 2 (cram:read-bits br (+ 2 (* 2 (cram:read-bits br 3)))))
                            alphabet-size))
            (lengths (make-array alphabet-size :element-type 'fixnum :initial-element 0))
            (prev 8) (sym 0))
        (when (> max-symbol alphabet-size) (return-from read-code-lengths nil))
        (loop while (< sym alphabet-size) do
          (when (zerop max-symbol) (return))
          (decf max-symbol)
          (when (cram:bit-reader-past-end-p br) (return-from read-code-lengths nil))
          (let ((len (cram:read-prefix-symbol br clcode)))
            (cond
              ((< len 16)                       ; a literal code length
               (setf (aref lengths sym) len)
               (incf sym)
               (unless (zerop len) (setf prev len)))
              (t                                ; 16 repeats PREV, 17/18 repeat zero
               (let* ((slot (- len 16))
                      (repeat (+ (cram:read-bits br (aref +repeat-extra-bits+ slot))
                                 (aref +repeat-offsets+ slot)))
                      (value (if (= len 16) prev 0)))
                 (when (> (+ sym repeat) alphabet-size) (return-from read-code-lengths nil))
                 (dotimes (i repeat) (setf (aref lengths sym) value) (incf sym)))))))
        lengths))))

(defun read-one-prefix-code (br alphabet-size)
  "Read one prefix code of ALPHABET-SIZE symbols.  Signals on a malformed code."
  (let ((lengths
          (if (= 1 (cram:read-bits br 1))
              ;; Simple code: one or two symbols, both of length 1.  A one-symbol
              ;; code then reads back as zero bits, which is the whole point.
              (let* ((n (+ 1 (cram:read-bits br 1)))
                     (wide (cram:read-bits br 1))
                     (v (make-array alphabet-size :element-type 'fixnum :initial-element 0))
                     (s0 (cram:read-bits br (if (zerop wide) 1 8))))
                (when (>= s0 alphabet-size) (%err "VP8L simple prefix symbol out of range"))
                (setf (aref v s0) 1)
                (when (= n 2)
                  (let ((s1 (cram:read-bits br 8)))
                    (when (>= s1 alphabet-size) (%err "VP8L simple prefix symbol out of range"))
                    (setf (aref v s1) 1)))
                v)
              (read-code-lengths br alphabet-size))))
    (unless lengths (%err "malformed VP8L prefix code lengths"))
    (or (cram:make-prefix-code lengths)
        (%err "VP8L prefix code is not a complete binary tree"))))

(defun group-alphabet-size (k cache-bits)
  "Alphabet size of the K'th code in a prefix code group.  Code 0 carries the
   green channel, the back-reference lengths and the colour-cache codes all in
   one alphabet; 1-3 are red/blue/alpha; 4 is the back-reference distance."
  (ecase k
    (0 (+ +literal-codes+ +length-codes+ (if (plusp cache-bits) (ash 1 cache-bits) 0)))
    ((1 2 3) +literal-codes+)
    (4 +distance-codes+)))

(defun read-prefix-code-groups (br xsize ysize cache-bits allow-meta)
  "Read the meta-prefix image (if any) and then every prefix code group.
   Returns (values groups entropy-image entropy-xsize prefix-bits)."
  (let ((entropy-image nil) (entropy-xsize 0) (prefix-bits 0) (ngroups 1))
    (when (and allow-meta (= 1 (cram:read-bits br 1)))
      (setf prefix-bits (+ 2 (cram:read-bits br 3)))
      (let ((hx (sub-sample-size xsize prefix-bits))
            (hy (sub-sample-size ysize prefix-bits)))
        (setf entropy-image (decode-image-stream br hx hy nil)
              entropy-xsize hx)
        ;; The meta prefix code of a block is its red and green bytes together.
        (let ((mx 0))
          (declare (type fixnum mx))
          (dotimes (i (length entropy-image))
            (setf mx (max mx (logand (ash (aref entropy-image i) -8) #xffff))))
          (setf ngroups (1+ mx))
          (note-feature "meta-prefix-~d-groups" ngroups))))
    (let ((groups (make-array ngroups)))
      (dotimes (g ngroups)
        (let ((grp (make-array 5)))
          (dotimes (k 5)
            (setf (aref grp k) (read-one-prefix-code br (group-alphabet-size k cache-bits))))
          (setf (aref groups g) grp)))
      (values groups entropy-image entropy-xsize prefix-bits))))

;;; ---- entropy-coded image data (spec §6.2.3) ----------------------------

(defun decode-image-data (br xsize ysize groups entropy-image entropy-xsize
                          prefix-bits cache-bits)
  "Decode XSIZE x YSIZE pixels: prefix-coded literals, LZ77 back-references and
   colour-cache hits, in whatever mixture the encoder chose."
  (declare (type fixnum xsize ysize prefix-bits cache-bits))
  (let* ((npix (* xsize ysize))
         (data (make-array npix :element-type '(unsigned-byte 32) :initial-element 0))
         (cache (when (plusp cache-bits) (cram:make-recent-cache cache-bits)))
         (cache-base (+ +literal-codes+ +length-codes+))
         (grp (aref groups 0))
         (pos 0) (x 0) (y 0))
    (declare (type argb-buffer data) (type fixnum npix pos x y cache-base))
    (loop while (< pos npix) do
      (when (cram:bit-reader-past-end-p br)
        (%err "VP8L bitstream ran out ~d pixels short" (- npix pos)))
      ;; Which of the prefix code groups applies here depends on where we are.
      (when entropy-image
        (let ((meta (aref entropy-image (+ (* (ash y (- prefix-bits)) entropy-xsize)
                                           (ash x (- prefix-bits))))))
          (setf grp (aref groups (logand (ash meta -8) #xffff)))))
      (let ((s (cram:read-prefix-symbol br (aref grp 0))))
        (declare (type fixnum s))
        (cond
          ;; literal: S is the green channel, the other three follow
          ((< s +literal-codes+)
           (let* ((r (cram:read-prefix-symbol br (aref grp 1)))
                  (b (cram:read-prefix-symbol br (aref grp 2)))
                  (a (cram:read-prefix-symbol br (aref grp 3)))
                  (px (argb a r s b)))
             (setf (aref data pos) px)
             (when cache (cram:recent-cache-put cache px))
             (incf pos) (incf x)
             (when (= x xsize) (setf x 0) (incf y))))
          ;; back-reference: copy a run of already-decoded pixels
          ((< s cache-base)
           (let* ((len (cram:read-prefix-coded-int br (- s +literal-codes+)))
                  (dsym (cram:read-prefix-symbol br (aref grp 4)))
                  (dist (plane-code-to-distance
                         xsize (cram:read-prefix-coded-int br dsym))))
             (declare (type fixnum len dist))
             (when (or (> dist pos) (> (+ pos len) npix))
               (%err "VP8L back-reference out of range (pos ~d dist ~d len ~d)" pos dist len))
             (note-feature "lz77")
             (cram:lz77-copy data pos dist len)
             (when cache
               (dotimes (i len) (cram:recent-cache-put cache (aref data (+ pos i)))))
             (incf pos len) (incf x len)
             (loop while (>= x xsize) do (decf x xsize) (incf y))))
          ;; colour cache hit
          (t
           (unless cache (%err "VP8L colour-cache code with no colour cache"))
           (note-feature "cache-hit")
           (let ((px (cram:recent-cache-ref cache (- s cache-base))))
             (setf (aref data pos) px)
             (cram:recent-cache-put cache px)
             (incf pos) (incf x)
             (when (= x xsize) (setf x 0) (incf y)))))))
    data))

;;; ---- transforms (spec §4) ----------------------------------------------
;;; Read in stream order and inverted in the opposite order.  Each record keeps
;;; the image size it was applied at, which is what the colour-indexing inverse
;;; needs to expand back to: reading that transform is what shrank the width.

(defclass vp8l-transform ()
  ((kind :initarg :kind :reader tx-kind
         :documentation "One of :PREDICTOR :CROSS-COLOR :SUBTRACT-GREEN :COLOR-INDEX.")
   (xsize :initarg :xsize :reader tx-xsize)
   (ysize :initarg :ysize :reader tx-ysize)
   (bits :initarg :bits :initform 0 :reader tx-bits
         :documentation "log2 of the block size, or of the pixel bundling for :COLOR-INDEX.")
   (data :initarg :data :initform nil :reader tx-data
         :documentation "The subresolution image / colour table, as ARGB.")))

(defun read-transform (br xsize ysize seen)
  "Read one transform.  Returns (values transform new-xsize new-seen-mask)."
  (let ((type (cram:read-bits br 2)))
    (when (logbitp type seen) (%err "duplicate VP8L transform type ~d" type))
    (let ((seen (logior seen (ash 1 type))))
      (ecase type
        ((0 1)                                  ; predictor / cross-colour
         (let* ((bits (+ 2 (cram:read-bits br 3)))
                (data (decode-image-stream br (sub-sample-size xsize bits)
                                           (sub-sample-size ysize bits) nil)))
           (values (make-instance 'vp8l-transform
                                  :kind (if (zerop type) :predictor :cross-color)
                                  :xsize xsize :ysize ysize :bits bits :data data)
                   xsize seen)))
        (2                                      ; subtract green: no payload
         (values (make-instance 'vp8l-transform :kind :subtract-green
                                                :xsize xsize :ysize ysize)
                 xsize seen))
        (3                                      ; colour indexing (palette)
         (let* ((ncolors (+ 1 (cram:read-bits br 8)))
                (bits (cond ((> ncolors 16) 0) ((> ncolors 4) 1) ((> ncolors 2) 2) (t 3)))
                (table (decode-image-stream br ncolors 1 nil)))
           (values (make-instance 'vp8l-transform :kind :color-index
                                                  :xsize xsize :ysize ysize :bits bits
                                                  :data (expand-color-map table ncolors bits))
                   (sub-sample-size xsize bits) seen)))))))

(defun expand-color-map (table ncolors bits)
  "Undo the colour table's delta coding and pad it out to a power of two.

   The table is stored as differences so that a palette of similar colours costs
   almost nothing; each entry is the channel-wise sum of itself and the previous
   entry.  Padding entries are transparent black, which is what the spec says an
   out-of-range index decodes to."
  (let* ((final (ash 1 (ash 8 (- bits))))
         (out (make-array final :element-type '(unsigned-byte 32) :initial-element 0)))
    (setf (aref out 0) (aref table 0))
    (loop for i from 1 below ncolors
          do (setf (aref out i) (add-pixels (aref table i) (aref out (1- i)))))
    out))

;;; ---- inverse transforms -------------------------------------------------

(defun inverse-subtract-green (data)
  "Add the green channel back into red and blue."
  (declare (type argb-buffer data))
  (dotimes (i (length data) data)
    (let* ((p (aref data i)) (g (pix-g p)))
      (setf (aref data i)
            (argb (pix-a p) (logand (+ (pix-r p) g) 255) g (logand (+ (pix-b p) g) 255))))))

(defun inverse-predictor (data width height bits pred-image)
  "Add each pixel's prediction back to its stored residual, in scan order.

   The border rules are the spec's: the very first pixel predicts from opaque
   black, the rest of the top row from the left, the leftmost column from above.
   The top-right neighbour of the last pixel in a row is the first pixel of the
   same row — which falls out for free from indexing a flat raster."
  (declare (type argb-buffer data) (type fixnum width height bits))
  (let ((tile-w (sub-sample-size width bits)))
    (declare (type fixnum tile-w))
    (setf (aref data 0) (add-pixels (aref data 0) #xff000000))
    (loop for x of-type fixnum from 1 below width
          do (setf (aref data x) (add-pixels (aref data x) (aref data (1- x)))))
    (loop for y of-type fixnum from 1 below height do
      (let ((row (* y width)))
        (declare (type fixnum row))
        (setf (aref data row) (add-pixels (aref data row) (aref data (- row width))))
        (loop for x of-type fixnum from 1 below width do
          (let* ((i (+ row x))
                 (mode (pix-g (aref pred-image (+ (* (ash y (- bits)) tile-w)
                                                  (ash x (- bits))))))
                 (pred (predict mode
                                (aref data (1- i))              ; L
                                (aref data (- i width))         ; T
                                (aref data (- i width -1))      ; TR
                                (aref data (- i width 1)))))    ; TL
            (setf (aref data i) (add-pixels (aref data i) pred)))))))
  data)

(declaim (inline s8 color-transform-delta))
(defun s8 (v) (declare (type (unsigned-byte 8) v)) (if (> v 127) (- v 256) v))
(defun color-transform-delta (multiplier channel)
  "(int8 multiplier * int8 channel) >> 5 — a 3.5 fixed-point scaling.  Only the
   low 8 bits of the result are ever used, so the shift's sign handling is moot."
  (ash (* (s8 multiplier) (s8 channel)) -5))

(defun inverse-cross-color (data width height bits cc-image)
  "Re-correlate red and blue with green, per block.

   A block's ColorTransformElement is packed into a subresolution pixel as
   green_to_red in blue, green_to_blue in green, red_to_blue in red."
  (declare (type argb-buffer data) (type fixnum width height bits))
  (let ((tile-w (sub-sample-size width bits)))
    (declare (type fixnum tile-w))
    (dotimes (y height data)
      (declare (type fixnum y))
      (let ((row (* y width))
            (trow (* (ash y (- bits)) tile-w)))
        (declare (type fixnum row trow))
        (dotimes (x width)
          (declare (type fixnum x))
          (let* ((cte (aref cc-image (+ trow (ash x (- bits)))))
                 (green-to-red (pix-b cte))
                 (green-to-blue (pix-g cte))
                 (red-to-blue (pix-r cte))
                 (i (+ row x))
                 (p (aref data i))
                 (g (pix-g p))
                 (r (logand (+ (pix-r p) (color-transform-delta green-to-red g)) 255))
                 (b (logand (+ (pix-b p)
                               (color-transform-delta green-to-blue g)
                               (color-transform-delta red-to-blue r))
                            255)))
            (setf (aref data i) (argb (pix-a p) r g b))))))))

(defun inverse-color-index (data packed-width height width bits table)
  "Replace indices with palette entries, unbundling several indices per pixel
   when the palette is small enough that the encoder packed them into one green
   channel (LSB first)."
  (declare (type argb-buffer data table) (type fixnum packed-width height width bits))
  (let* ((out (make-array (* width height) :element-type '(unsigned-byte 32)
                                           :initial-element 0))
         (bits-per-index (ash 8 (- bits)))
         (per-pixel (ash 1 bits))
         (count-mask (1- per-pixel))
         (index-mask (1- (ash 1 bits-per-index))))
    (declare (type argb-buffer out) (type fixnum bits-per-index per-pixel count-mask index-mask))
    (dotimes (y height out)
      (declare (type fixnum y))
      (let ((src (* y packed-width)) (dst (* y width)) (packed 0))
        (declare (type fixnum src dst packed))
        (dotimes (x width)
          (declare (type fixnum x))
          (when (zerop (logand x count-mask))
            (setf packed (pix-g (aref data src)))
            (incf src))
          (setf (aref out (+ dst x)) (aref table (logand packed index-mask)))
          (setf packed (ash packed (- bits-per-index))))))))

;;; ---- image streams ------------------------------------------------------

(defun decode-image-stream (br xsize ysize level0)
  "Decode one image stream.  At level 0 (the picture itself) this may be preceded
   by transforms and may use meta prefix codes; the subresolution images that
   transforms and meta prefix codes are themselves made of are level > 0 and may
   not recurse further.

   Returns the ARGB pixels; at level 0 also (values pixels width height transforms),
   where WIDTH is the possibly-subsampled width the pixels are actually stored at."
  (let ((transforms '()) (tx xsize) (ty ysize) (seen 0))
    (when level0
      (loop while (= 1 (cram:read-bits br 1)) do
        (multiple-value-bind (tr new-x new-seen) (read-transform br tx ty seen)
          (push tr transforms) (setf tx new-x seen new-seen))))
    (let ((cache-bits 0))
      (when (= 1 (cram:read-bits br 1))
        (setf cache-bits (cram:read-bits br 4))
        (unless (<= 1 cache-bits 11) (%err "VP8L colour cache size ~d out of range" cache-bits))
        (when level0 (note-feature "cache-~d-bits" cache-bits)))
      (multiple-value-bind (groups entropy-image entropy-xsize prefix-bits)
          (read-prefix-code-groups br tx ty cache-bits level0)
        (let ((data (decode-image-data br tx ty groups entropy-image entropy-xsize
                                       prefix-bits cache-bits)))
          ;; TRANSFORMS comes back in inverse-application order: pushing while
          ;; reading already reversed it.
          (values data tx ty transforms))))))

(defun apply-inverse-transforms (data width height transforms)
  "Undo TRANSFORMS, last-read first.  Returns (values pixels width)."
  (dolist (tr transforms (values data width))
    (ecase (tx-kind tr)
      (:subtract-green
       (note-feature "subtract-green")
       (setf data (inverse-subtract-green data)))
      (:predictor
       (note-feature "predictor-~dpx-blocks" (ash 1 (tx-bits tr)))
       (setf data (inverse-predictor data width height (tx-bits tr) (tx-data tr))))
      (:cross-color
       (note-feature "cross-colour-~dpx-blocks" (ash 1 (tx-bits tr)))
       (setf data (inverse-cross-color data width height (tx-bits tr) (tx-data tr))))
      (:color-index
       (note-feature "palette-~d-per-pixel" (ash 1 (tx-bits tr)))
       (setf data (inverse-color-index data width height (tx-xsize tr) (tx-bits tr) (tx-data tr))
             width (tx-xsize tr))))))

;;; ---- header and public entry --------------------------------------------

(defconstant +vp8l-signature+ #x2f)

(defun parse-vp8l-header (br)
  "Read the 5-byte VP8L header.  Returns (values width height alpha-hint version)."
  (let ((sig (cram:read-bits br 8)))
    (unless (= sig +vp8l-signature+) (%err "bad VP8L signature #x~2,'0x" sig)))
  (let* ((w (+ 1 (cram:read-bits br 14)))
         (h (+ 1 (cram:read-bits br 14)))
         (alpha (cram:read-bits br 1))
         (version (cram:read-bits br 3)))
    (unless (zerop version) (%err "VP8L version ~d is not supported" version))
    (values w h (= alpha 1) version)))

(defun vp8l-bit-reader (bytes off size)
  "A bit reader over the VP8L payload.  The end is clamped to the buffer: a
   truncated file has a chunk header promising more bytes than are there, and
   the reader must report that as running out of bitstream rather than as an
   array index error."
  (cram:make-bit-reader bytes :start off :end (min (+ off size) (length bytes))))

(defun vp8l-dimensions (bytes off)
  (multiple-value-bind (w h)
      (parse-vp8l-header (vp8l-bit-reader bytes off (- (length bytes) off)))
    (values w h)))

(defun decode-vp8l (bytes off size)
  "Decode the VP8L chunk at BYTES[OFF..OFF+SIZE).  Returns (values width height
   rgb alpha), rgb 3 bytes/px row-major and alpha 1 byte/px, or NIL for alpha
   when every pixel is opaque."
  (let ((br (vp8l-bit-reader bytes off size)))
    (multiple-value-bind (width height) (parse-vp8l-header br)
      (multiple-value-bind (data stored-width stored-height transforms)
          (decode-image-stream br width height t)
        (declare (ignore stored-height))
        ;; The last symbol of a well-formed stream may be read with lookahead
        ;; past the final byte; consuming real bits past it means the file was
        ;; short, and the pixels decoded from that invented padding are fiction.
        (when (cram:bit-reader-past-end-p br)
          (%err "VP8L chunk is truncated"))
        (multiple-value-bind (pixels final-width)
            (apply-inverse-transforms data stored-width height transforms)
          (unless (= final-width width)
            (%err "VP8L transform chain produced width ~d, header says ~d"
                  final-width width))
          (argb->rgb+alpha pixels width height))))))

(defun argb->rgb+alpha (pixels width height)
  "Split packed ARGB into the (values width height rgb alpha) the decoder
   promises.  ALPHA is NIL when the image is fully opaque, so a caller that does
   not care about transparency can ignore it."
  (declare (type argb-buffer pixels))
  (let* ((n (* width height))
         (rgb (make-array (* 3 n) :element-type '(unsigned-byte 8)))
         (alpha (make-array n :element-type '(unsigned-byte 8)))
         (opaque t))
    (dotimes (i n)
      (let ((p (aref pixels i)) (o (* i 3)))
        (setf (aref rgb o) (pix-r p)
              (aref rgb (+ o 1)) (pix-g p)
              (aref rgb (+ o 2)) (pix-b p)
              (aref alpha i) (pix-a p))
        (when (/= (pix-a p) 255) (setf opaque nil))))
    (values width height rgb (unless opaque alpha))))
