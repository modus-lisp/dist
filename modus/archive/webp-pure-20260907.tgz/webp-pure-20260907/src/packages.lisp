;;;; packages.lisp
(defpackage #:webp-pure
  (:use #:cl)
  ;; The VP8 decoder moved to reel, which is where a video codec belongs: a lossy WebP is one VP8
  ;; key frame, so that code was never about the image format.  What is left here is the format —
  ;; the RIFF container, the VP8L lossless path, and the colour conversion an image wants at the
  ;; end — and these are the handles it needs on the codec to do it.
  (:import-from #:reel.decode
   #:parse-frame-header #:fr-width #:fr-height #:decode-key-frame
   #:plane #:pget #:d-width #:d-height #:d-yplane #:d-uplane #:d-vplane)
  (:export #:decode #:webp-p #:dimensions #:webp-error))
(in-package #:webp-pure)

(define-condition webp-error (error)
  ((message :initarg :message :reader webp-error-message))
  (:report (lambda (c s) (format s "webp-pure: ~a" (webp-error-message c)))))

(defun %err (fmt &rest args)
  (error 'webp-error :message (apply #'format nil fmt args)))
