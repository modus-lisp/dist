;;;; rgb.lisp — YUV 4:2:0 to RGB, and the top-level WebP entry point.
;;;;
;;;; The colour conversion is libwebp's, down to the fancy (9-3-3-1) chroma upsampler, because
;;;; matching libwebp pixel-for-pixel is what webp-pure's vectors assert.  It reads the planes
;;;; reel's decoder reconstructed; the decoding itself is no longer here.

(in-package #:webp-pure)
;;; ---- YUV 4:2:0 -> RGB (libwebp fixed point) ---------------------------

(declaim (inline clamp8 mult-hi))
(defun clamp8 (v) (declare (type fixnum v)) (max 0 (min 255 (ash v -6))))
(defun mult-hi (v c) (declare (type fixnum v c)) (ash (* v c) -8))

(defun fancy-upsample (cpl w h)
  "2x fancy (bilinear, 9-3-3-1) upsampling of chroma plane CPL to WxH, matching
   libwebp's WebPUpsamplers used by the reference decoder."
  (let* ((ch (ceiling h 2))
         (out (make-array (* w h) :element-type 'fixnum))
         (lpp (ash (1- w) -1)))
    (labels ((s (row col) (pget cpl col row))
             (fill-row (y ct cc topp)
               (let ((base (* y w)))
                 (setf (aref out base)
                       (if topp (ash (+ (* 3 (s ct 0)) (s cc 0) 2) -2)
                                (ash (+ (* 3 (s cc 0)) (s ct 0) 2) -2)))
                 (loop for x from 1 to lpp do
                   (let* ((tl (s ct (1- x))) (tt (s ct x)) (l (s cc (1- x))) (uv (s cc x))
                          (avg (+ tl tt l uv 8))
                          (d12 (ash (+ avg (* 2 (+ tt l))) -3))
                          (d03 (ash (+ avg (* 2 (+ tl uv))) -3))
                          (c1 (1- (* 2 x))) (c2 (* 2 x)))
                     (when (< c1 w)
                       (setf (aref out (+ base c1))
                             (if topp (ash (+ d12 tl) -1) (ash (+ d03 l) -1))))
                     (when (< c2 w)
                       (setf (aref out (+ base c2))
                             (if topp (ash (+ d03 tt) -1) (ash (+ d12 uv) -1))))))
                 (when (evenp w)
                   (let ((tl (s ct lpp)) (l (s cc lpp)))
                     (setf (aref out (+ base (1- w)))
                           (if topp (ash (+ (* 3 tl) l 2) -2) (ash (+ (* 3 l) tl 2) -2))))))))
      (dotimes (y h)
        (cond ((= y 0) (fill-row 0 0 0 t))
              ((and (= y (1- h)) (evenp h)) (fill-row y (1- ch) (1- ch) t))
              (t (let ((k (ceiling y 2))) (fill-row y (1- k) k (oddp y)))))))
    out))

(defun yuv->rgb (d)
  "Convert the reconstructed YUV 4:2:0 planes to packed RGB using libwebp's
   fixed-point coefficients (per-term MultHi, then a >>6 clamp) with fancy
   chroma upsampling."
  (let* ((w (d-width d)) (h (d-height d)) (yp (d-yplane d))
         (uu (fancy-upsample (d-uplane d) w h))
         (vv-arr (fancy-upsample (d-vplane d) w h))
         (rgb (make-array (* w h 3) :element-type '(unsigned-byte 8))))
    (dotimes (y h)
      (dotimes (x w)
        (let* ((i (+ (* y w) x))
               (y1 (mult-hi (pget yp x y) 19077))
               (uv (aref uu i)) (vv (aref vv-arr i))
               (r (clamp8 (+ y1 (mult-hi vv 26149) -14234)))
               (g (clamp8 (+ y1 (- (mult-hi uv 6419)) (- (mult-hi vv 13320)) 8708)))
               (b (clamp8 (+ y1 (mult-hi uv 33050) -17685)))
               (o (* i 3)))
          (setf (aref rgb o) r (aref rgb (+ o 1)) g (aref rgb (+ o 2)) b))))
    rgb))

(defun decode (bytes)
  "Decode a WebP in BYTES to (values width height rgb-octets alpha-octets).

   RGB is 3 bytes/px row-major.  ALPHA is 1 byte/px, or NIL when the image is
   fully opaque — which is always the case for lossy VP8, whose alpha lives in a
   separate ALPH chunk this decoder does not read.  Signals WEBP-ERROR on
   anything unsupported."
  (unless (webp-p bytes) (%err "not a RIFF/WebP container"))
  (multiple-value-bind (off size) (find-chunk bytes "VP8 ")
    (if off
        (let* ((fr (parse-frame-header bytes off size))
               (d (decode-key-frame bytes off size fr)))
          (values (d-width d) (d-height d) (yuv->rgb d) nil))
        (multiple-value-bind (loff lsize) (find-chunk bytes "VP8L")
          (unless loff (%err "no VP8 or VP8L chunk (animation/VP8X not supported)"))
          (decode-vp8l bytes loff lsize)))))
