;;;; webp-pure.asd — a pure Common Lisp WebP image decoder.
(asdf:defsystem :webp-pure
  :description "Pure-CL WebP decoder: the RIFF container, VP8L lossless, and the colour
conversion.  The lossy path is one VP8 key frame, so it is reel's decoder rather than a
second copy of it living here.  The generic entropy coding VP8L needs (canonical prefix
codes, LZ77, the recent-value cache) comes from cram; no FFI, nothing else."
  :license "MIT"
  :depends-on (:cram :reel)
  :components ((:module "src"
                :serial t
                :components ((:file "packages")
                             (:file "riff")      ; the container
                             (:file "rgb")       ; YUV->RGB, and the top-level entry
                             (:file "vp8l")))))
