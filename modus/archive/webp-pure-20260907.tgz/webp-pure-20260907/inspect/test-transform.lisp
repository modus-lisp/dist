;;;; test-transform.lisp — checks VP8-IDCT and VP8-IWHT against reference vectors.
;;;;   run:  sbcl --non-interactive --load inspect/test-transform.lisp
(require :asdf)
(push (truename "./") asdf:*central-registry*)
(handler-case (asdf:load-system :webp-pure)
  (error (e) (format t "~&LOAD-ERR ~a~%" e) (sb-ext:exit :code 1)))

(defun parse-ints (str) (mapcar #'parse-integer (remove "" (uiop:split-string str :separator " ") :test #'string=)))

(let ((idct (find-symbol "VP8-IDCT" :webp-pure))
      (iwht (find-symbol "VP8-IWHT" :webp-pure))
      (pass 0) (fail 0) (shown 0))
  (unless (and idct (fboundp idct) iwht (fboundp iwht))
    (format t "~&NOT-DEFINED: need WEBP-PURE::VP8-IDCT and VP8-IWHT (both (array->array of 16))~%")
    (sb-ext:exit :code 1))
  (with-open-file (s "vectors/transforms.txt")
    (loop for line = (read-line s nil) while line do
      (let* ((bar (position #\| line))
             (kind (subseq line 0 (position #\Space line)))
             (in (parse-ints (subseq line (length kind) bar)))
             (expect (parse-ints (subseq line (1+ bar))))
             (arr (make-array 16 :element-type 'fixnum :initial-contents in))
             (got (funcall (if (string= kind "idct") idct iwht) arr)))
        (if (equal (coerce got 'list) expect)
            (incf pass)
            (progn (incf fail)
                   (when (< shown 3) (incf shown)
                     (format t "~&FAIL ~a~%  in     ~a~%  expect ~a~%  got    ~a~%"
                             kind in expect (coerce got 'list))))))))
  (format t "~&transforms: ~a passed, ~a failed~%" pass fail)
  (sb-ext:exit :code (if (zerop fail) 0 1)))
