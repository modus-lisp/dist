;;;; test-decode.lisp — decode each vector and score against the reference RGB.
;;;;   run:  sbcl --non-interactive --load inspect/test-decode.lisp
(require :asdf)
(push (truename "./") asdf:*central-registry*)
(handler-case (asdf:load-system :webp-pure)
  (error (e) (format t "~&LOAD-ERR ~a~%" e) (sb-ext:exit :code 1)))

(defun slurp (path)
  (with-open-file (s path :element-type '(unsigned-byte 8))
    (let ((b (make-array (file-length s) :element-type '(unsigned-byte 8))))
      (read-sequence b s) b)))

(let ((decode (find-symbol "DECODE" :webp-pure)) (any-fail nil))
  (dolist (name '("solid_red" "solid_gray" "gradient" "real1"))
    (let* ((webp (slurp (format nil "vectors/~a.webp" name)))
           (oracle (slurp (format nil "vectors/~a.rgb" name)))
           (meta (with-open-file (s (format nil "vectors/~a.meta" name)) (read-line s))))
      (handler-case
          (multiple-value-bind (w h rgb) (funcall decode webp)
            (cond
              ((null rgb) (format t "~&~11a NO PIXELS (~ax~a)~%" name w h) (setf any-fail t))
              ((/= (length rgb) (length oracle))
               (format t "~&~11a SIZE ~a bytes != oracle ~a (~ax~a, meta ~a)~%"
                       name (length rgb) (length oracle) w h meta) (setf any-fail t))
              (t (let ((n (length rgb)) (exact 0) (sum 0) (maxd 0))
                   (dotimes (i n)
                     (let ((d (abs (- (aref rgb i) (aref oracle i)))))
                       (when (zerop d) (incf exact)) (incf sum d) (setf maxd (max maxd d))))
                   (let ((pct (* 100d0 (/ exact n))))
                     (when (< pct 99.9d0) (setf any-fail t))
                     (format t "~&~11a ~ax~a  exact=~5,1f%  mean-diff=~4,2f  max-diff=~a~%"
                             name w h pct (/ (float sum) n) maxd))))))
        (error (e) (format t "~&~11a ERROR ~a~%" name e) (setf any-fail t)))))
  (format t "~&~a~%" (if any-fail "SOME VECTORS NOT EXACT" "ALL VECTORS EXACT"))
  (sb-ext:exit :code (if any-fail 1 0)))
