;;;; test-vp8l.lisp — decode every lossless vector and compare against ground truth.
;;;;   run:  sbcl --non-interactive --load inspect/test-vp8l.lisp
;;;;
;;;; The oracle for each NAME.webp is NAME.rgba: the raw RGBA the picture was
;;;; encoded FROM (libwebp via Pillow), so a match means the round trip through
;;;; a third-party encoder and this decoder is bit-exact.  VP8L is lossless, so
;;;; anything short of 100% exact is a bug, not a tolerance to widen.
;;;;
;;;; resvg-image.webp is the exception worth calling out: it is not ours, it
;;;; shipped in the resvg test corpus, and its oracle is the .png that shipped
;;;; alongside it.  That one proves the decoder handles a file no part of this
;;;; process produced.

(require :asdf)
(load (merge-pathnames "quicklisp/setup.lisp" (user-homedir-pathname)))
(push (truename "./") asdf:*central-registry*)
(handler-case (asdf:load-system :webp-pure)
  (error (e) (format t "~&LOAD-ERR ~a~%" e) (sb-ext:exit :code 1)))

(defun slurp (path)
  (with-open-file (s path :element-type '(unsigned-byte 8))
    (let ((b (make-array (file-length s) :element-type '(unsigned-byte 8))))
      (read-sequence b s) b)))

(defun vector-names (dir)
  (sort (mapcar (lambda (p) (pathname-name p))
                (directory (merge-pathnames "*.webp" dir)))
        #'string<))

(let* ((dir #p"vectors/lossless/")
       (names (vector-names dir))
       (features (make-hash-table :test 'equal))
       (any-fail nil))
  (when (null names) (format t "~&no vectors in ~a~%" dir) (sb-ext:exit :code 1))
  (dolist (name names)
    (let ((webp (slurp (merge-pathnames (format nil "~a.webp" name) dir)))
          (oracle (slurp (merge-pathnames (format nil "~a.rgba" name) dir))))
      (handler-case
          (let ((webp-pure::*vp8l-features* nil))
            (multiple-value-bind (w h rgb alpha) (webp-pure:decode webp)
              (setf (gethash name features) webp-pure::*vp8l-features*)
              (let ((n (* w h)))
                (cond
                  ((/= (length oracle) (* 4 n))
                   (format t "~&~14a DIMENSIONS ~ax~a but oracle is ~a bytes~%"
                           name w h (length oracle))
                   (setf any-fail t))
                  (t
                   ;; compare all four channels; a missing ALPHA means opaque
                   (let ((bad 0) (maxd 0) (bad-alpha 0))
                     (dotimes (i n)
                       (dotimes (c 3)
                         (let ((d (abs (- (aref rgb (+ (* i 3) c))
                                          (aref oracle (+ (* i 4) c))))))
                           (unless (zerop d) (incf bad) (setf maxd (max maxd d)))))
                       (let ((a (if alpha (aref alpha i) 255)))
                         (unless (= a (aref oracle (+ (* i 4) 3))) (incf bad-alpha))))
                     (if (and (zerop bad) (zerop bad-alpha))
                         (format t "~&~14a ~3dx~3d  EXACT (~d px)~%" name w h n)
                         (progn
                           (setf any-fail t)
                           (format t "~&~14a ~3dx~3d  ~d/~d rgb samples wrong (max ~d), ~
                                      ~d/~d alpha wrong~%"
                                   name w h bad (* 3 n) maxd bad-alpha n)))))))))
        (error (e) (format t "~&~14a ERROR ~a~%" name e) (setf any-fail t)))))
  (format t "~%feature coverage (what each file actually exercises):~%")
  (dolist (name names)
    (format t "  ~14a ~{~a~^ ~}~%" name (sort (mapcar #'symbol-name
                                                      (gethash name features))
                                              #'string<)))
  (let ((all (reduce #'union (loop for v being the hash-values of features collect v))))
    (format t "~%union of features seen: ~{~a~^ ~}~%" (sort (mapcar #'symbol-name all) #'string<)))
  (format t "~&~a~%" (if any-fail "SOME LOSSLESS VECTORS WRONG" "ALL LOSSLESS VECTORS EXACT"))
  (sb-ext:exit :code (if any-fail 1 0)))
