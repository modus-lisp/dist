;;;; src/hash.lisp — SHA-256, SHA-1, base64, SipHash-2-4, CRC32.
;;;;
;;;; SHA-256, SHA-1 and CRC32 are natrium's and cram's; this file keeps beacon's names.
;;;; SHA-256 is on the ingest hot path twice per event (the event id, then the
;;;; BIP340 challenge).  It also exposes a MIDSTATE: the BIP340 challenge
;;;; hash begins with the same 64-byte block (SHA256(tag) || SHA256(tag)) for
;;;; every event, so that block is compressed once at load time.
;;;;
;;;; SHA-1 and base64 exist only for the WebSocket handshake.  SipHash-2-4 is the
;;;; keyed hash behind every in-memory index: keyed with a per-store secret so a
;;;; client cannot grind tag values or pubkeys that collide in our tables.

(in-package #:beacon)

(deftype u64 () '(unsigned-byte 64))

;;; ---- SHA-256, SHA-1 (natrium) ----------------------------------------------
;;; natrium is the org's canonical SHA-2 and SHA-1, and since natrium 68b132e faster
;;; than the versions that were here (SBCL: SHA-256 75 -> 90 MB/s, SHA-1 67 -> 181).
;;; The challenge midstate below is natrium's heap context: public data, so it does not
;;; need the fixed memory natrium keeps secrets in.

(defun make-sha256-ctx () (natrium:make-sha256-state))

(defun sha256-copy-state (from to)
  "Make TO continue from FROM's state (midstate reuse)."
  (natrium:sha256-copy-state from to))

(defun sha256-update (ctx data &optional (start 0) (end (length data)))
  (natrium:sha256-update ctx data :start start :end end))

(defun sha256-final (ctx &optional (out (make-octets 32)) (out-start 0))
  (natrium:sha256-final-into ctx out :start out-start))

(defun sha256 (data &optional (start 0) (end (length data)))
  "SHA-256 of DATA[START,END) -- a fresh 32-byte vector."
  (let ((ctx (make-sha256-ctx)))
    (sha256-update ctx data start end)
    (sha256-final ctx)))

(defun sha1 (data)
  "SHA-1 of DATA -- the WebSocket handshake's only use."
  (natrium:sha1 data))

;;; ---- base64 ----------------------------------------------------------------

(defparameter +b64+ "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/")

(defun base64-encode (data)
  (declare (type octets data))
  (with-output-to-string (s)
    (loop for i from 0 below (length data) by 3
          for n = (- (length data) i)
          for b0 = (aref data i)
          for b1 = (if (> n 1) (aref data (+ i 1)) 0)
          for b2 = (if (> n 2) (aref data (+ i 2)) 0)
          for v = (logior (ash b0 16) (ash b1 8) b2)
          do (write-char (char +b64+ (ldb (byte 6 18) v)) s)
             (write-char (char +b64+ (ldb (byte 6 12) v)) s)
             (write-char (if (> n 1) (char +b64+ (ldb (byte 6 6) v)) #\=) s)
             (write-char (if (> n 2) (char +b64+ (ldb (byte 6 0) v)) #\=) s))))

;;; ---- SipHash-2-4 -----------------------------------------------------------

(defmacro u64+ (a b) `(ldb (byte 64 0) (+ ,a ,b)))
(defmacro rotl64 (x n) `(logior (ldb (byte 64 0) (ash ,x ,n)) (ash ,x ,(- n 64))))

(defmacro %sipround (v0 v1 v2 v3)
  `(progn
     (setf ,v0 (u64+ ,v0 ,v1) ,v1 (rotl64 ,v1 13) ,v1 (logxor ,v1 ,v0) ,v0 (rotl64 ,v0 32))
     (setf ,v2 (u64+ ,v2 ,v3) ,v3 (rotl64 ,v3 16) ,v3 (logxor ,v3 ,v2))
     (setf ,v0 (u64+ ,v0 ,v3) ,v3 (rotl64 ,v3 21) ,v3 (logxor ,v3 ,v0))
     (setf ,v2 (u64+ ,v2 ,v1) ,v1 (rotl64 ,v1 17) ,v1 (logxor ,v1 ,v2) ,v2 (rotl64 ,v2 32))))

(declaim (type u64 *sip-k0* *sip-k1*))
(defvar *sip-k0* #x0706050403020100)
(defvar *sip-k1* #x0f0e0d0c0b0a0908)

(defmacro define-siphash (name doc result-form)
  `(defun ,name (data &optional (start 0) (end (length data)) (prefix-byte nil)
                      (k0 *sip-k0*) (k1 *sip-k1*))
     ,doc
     (declare (optimize (speed 3) (safety 0))
              (type octets data) (type ufix start end) (type u64 k0 k1))
     (let* ((v0 (logxor k0 #x736f6d6570736575))
            (v1 (logxor k1 #x646f72616e646f6d))
            (v2 (logxor k0 #x6c7967656e657261))
            (v3 (logxor k1 #x7465646279746573))
            (len (+ (- end start) (if prefix-byte 1 0)))
            (pos 0))
       (declare (type u64 v0 v1 v2 v3) (type ufix len pos))
       (flet ((byte-at (i)
                (declare (type ufix i))
                (if prefix-byte
                    (if (zerop i) (the (unsigned-byte 8) prefix-byte) (aref data (+ start i -1)))
                    (aref data (+ start i)))))
         (declare (inline byte-at))
         (loop while (<= (+ pos 8) len) do
           (let ((m 0))
             (declare (type u64 m))
             (dotimes (i 8) (setf m (logior m (ash (byte-at (+ pos i)) (* 8 i)))))
             (setf v3 (logxor v3 m))
             (%sipround v0 v1 v2 v3) (%sipround v0 v1 v2 v3)
             (setf v0 (logxor v0 m))
             (incf pos 8)))
         (let ((m (ash (ldb (byte 8 0) len) 56)))
           (declare (type u64 m))
           (loop for i from 0 below (- len pos)
                 do (setf m (logior m (ash (byte-at (+ pos i)) (* 8 i)))))
           (setf v3 (logxor v3 m))
           (%sipround v0 v1 v2 v3) (%sipround v0 v1 v2 v3)
           (setf v0 (logxor v0 m))))
       (setf v2 (logxor v2 #xff))
       (%sipround v0 v1 v2 v3) (%sipround v0 v1 v2 v3)
       (%sipround v0 v1 v2 v3) (%sipround v0 v1 v2 v3)
       ,result-form)))

(define-siphash siphash64
  "SipHash-2-4 of [PREFIX-BYTE] || DATA[START,END) under key (K0 K1) — the full
64-bit value, as in the reference.  Returns a bignum on SBCL when the top bits
are set, so the relay itself uses KEYED-HASH."
  (logxor v0 v1 v2 v3))

(define-siphash keyed-hash
  "SipHash-2-4 truncated to 62 bits: always a FIXNUM, so the hot paths that pass
hashes around (index keys, posting lists, the subscription index) never box a
bignum.  PREFIX-BYTE lets a tag hash fold in the tag letter without copying."
  (ldb (byte 62 0) (logxor v0 v1 v2 v3)))

(deftype hash62 () '(unsigned-byte 62))

(defun set-hash-key (key16)
  "Install the store's 16-byte secret as the SipHash key."
  (flet ((le64 (o) (loop for i below 8 sum (ash (aref key16 (+ o i)) (* 8 i)))))
    (setf *sip-k0* (le64 0) *sip-k1* (le64 8))))

;;; ---- CRC32 (IEEE) ----------------------------------------------------------
;;; Every record is checksummed on write and again on every replay.  cram's is this
;;; file's slicing-by-8 (it moved there), 1311 MB/s on SBCL.

(defun crc32 (data &optional (start 0) (end (length data)))
  (cram:crc32 data start end))
