;;;; src/relay-modus.lisp — the relay on modus: one owner thread, an event loop.
;;;;
;;;; Modus threads share no heap.  A thread's objects live in its own region, and a
;;;; store that would let another thread reach one is refused; what crosses between
;;;; threads is a COPY -- a message on a channel (MODUS:MAKE-CHANNEL), or a number.
;;;; The SBCL pipeline (relay.lisp) is the opposite shape: I/O threads, a verify
;;;; pool, a writer and fanout threads all touching the store, the indexes, the
;;;; subscriptions and every connection's output queue.  So here:
;;;;
;;;;   ONE OWNER THREAD holds every mutable relay structure -- the store and its
;;;;   indexes, the subscription index, the connections and their output queues,
;;;;   the timers -- and runs the relay as a classic event loop: accept, poll,
;;;;   read, parse, admit, commit, query, fan out, write.  UDP ingest is one more
;;;;   descriptor in the same poll; timers are the poll's timeout.
;;;;
;;;;   VERIFY THREADS do the one CPU-heavy pure job, BIP-340 signature checks.  The
;;;;   owner sends (token pubkey id sig) -- octet vectors -- on a channel; a verify
;;;;   thread answers (token ok-p) on another and writes a byte to the owner's
;;;;   wakeup pipe.  Each verify thread keeps its own decoded-pubkey cache.
;;;;
;;;;   THE STARTING THREAD keeps the RELAY returned by START-RELAY: a handle holding
;;;;   what other threads may read -- the config, the statistics (the owner only
;;;;   ever adds numbers to them), the listening and UDP sockets, the SERVER's
;;;;   counters.  The owner works on a COPY of that struct (COPY-RELAY) whose store,
;;;;   queues and fanout are its own.
;;;;
;;;; Being single-threaded, the owner needs none of the pipeline's hand-offs: a REQ
;;;; is answered in the turn it arrives (stored events, EOSE, then registered for
;;;; live delivery, with no event committed in between), so GAP-FREE delivery holds
;;;; by construction rather than through FANNED snapshots.

(in-package #:beacon)

;;; ---- verify threads ---------------------------------------------------------------------

(defclass verifier ()
  ((in :initarg :in :reader verifier-in)            ; channel: (token pubkey id sig) or :stop
   (out :initarg :out :reader verifier-out)         ; channel: (token ok-p)
   (waker :initarg :waker :reader verifier-waker)   ; the owner's wakeup pipe
   (threads :initform '() :accessor verifier-threads)))

(defun make-point-cache ()
  (let ((v (make-array +point-shards+)))
    (dotimes (i +point-shards+ v) (setf (svref v i) (make-point-shard)))))

(defun verify-thread (verifier)
  "A verify thread's body: answer signature checks until told :STOP."
  (with-thread-io
    ;; this thread's own cache: the global one belongs to the thread that loaded beacon
    (let ((*point-cache* (make-point-cache)))
      (loop
        (let ((m (modus:channel-receive (verifier-in verifier))))
          (when (eq m :stop) (return))
          (destructuring-bind (token pubkey id sig) m
            (let ((ok (handler-case (verify-signature pubkey id sig) (error () nil))))
              (modus:channel-send (verifier-out verifier) (list token (and ok t))))
            (wake (verifier-waker verifier)))))))
  0)

;;; ---- the owner's state ---------------------------------------------------------------

(defclass owner ()
  ((relay :initarg :relay :reader owner-relay)        ; the owner's copy of the RELAY
   (io :initarg :io :accessor owner-io)
   (verifier :initarg :verifier :reader owner-verifier)
   (workers :initarg :workers :reader owner-workers)  ; how many verify threads
   (inflight :initform (make-hash-table :test 'eql) :reader owner-inflight) ; token -> (c e t0)
   (next-token :initform 0 :accessor owner-next-token)
   (commit :initform '() :accessor owner-commit)      ; verified (c e t0), newest first
   (timers :initform '() :accessor owner-timers)      ; (due-us . thunk), soonest first
   (last-fsync :initform 0 :accessor owner-last-fsync)
   (frame-buf :initform (make-obuf 4096) :reader owner-frame-buf)))

(defvar *owner* nil "The OWNER, bound on the owner thread only.")

(defun owner-after (seconds thunk)
  "Run THUNK on the owner thread SECONDS from now."
  (let ((o *owner*) (due (+ (now-us) (round (* seconds 1000000)))))
    (setf (owner-timers o) (merge 'list (owner-timers o) (list (cons due thunk)) #'< :key #'car))))

(defun owner-verify (relay c e t0 raw-id)
  "Start the signature check of E (for connection C, NIL for none).  NIL if the
relay is too busy to take it."
  (declare (ignore raw-id))
  (let ((o *owner*))
    (cond
      ((zerop (owner-workers o))
       ;; no verify threads: check it here
       (if (verify-event-signature e)
           (push (list c e t0) (owner-commit o))
           (progn (sb-ext:atomic-incf (stats-invalid (relay-stats relay)))
                  (send-ok c (event-id-hex e) nil "invalid: bad signature")))
       t)
      ((>= (hash-table-count (owner-inflight o)) (config-verify-queue (relay-config relay))) nil)
      (t
       (let ((token (incf (owner-next-token o))))
         (when (modus:channel-send (verifier-in (owner-verifier o))
                                   (list token (event-pubkey e) (event-id e) (event-sig e))
                                   :timeout 0)
           (setf (gethash token (owner-inflight o)) (list c e t0))
           t))))))

(defun owner-collect (o &key (timeout 0))
  "Take every verdict the verify threads have sent; with TIMEOUT, wait that long
for the first."
  (let ((out (verifier-out (owner-verifier o))) (relay (owner-relay o)))
    (loop
      (multiple-value-bind (m got) (modus:channel-receive out :timeout timeout)
        (unless got (return))
        (setf timeout 0)
        (destructuring-bind (token ok) m
          (let ((job (gethash token (owner-inflight o))))
            (remhash token (owner-inflight o))
            (when job
              (destructuring-bind (c e t0) job
                (declare (ignore t0))
                (if ok
                    (push job (owner-commit o))
                    (progn (sb-ext:atomic-incf (stats-invalid (relay-stats relay)))
                           (send-ok c (event-id-hex e) nil "invalid: bad signature")))))))))))

(defun owner-fanout (relay e)
  "Deliver E to every live subscription it matches."
  (let* ((fo (svref (relay-fanouts relay) 0)) (json (event-json e))
         (fb (owner-frame-buf *owner*)) (st (relay-stats relay)))
    (dolist (sub (matching-subs fo e))
      (let ((frame (write-event-frame fb (sub-id-json sub) json 0 (length json))))
        (conn-send-region (sub-conn sub) (obuf-data frame) 0 (obuf-fill frame))
        (sb-ext:atomic-incf (stats-delivered st))))))

(defun owner-commit-batch (o)
  "Insert the verified events as one group commit, answer them, fan them out."
  (let ((jobs (nreverse (owner-commit o))) (relay (owner-relay o)))
    (setf (owner-commit o) '())
    (when jobs
      (let* ((store (relay-store relay)) (st (relay-stats relay))
             (results (handler-case (store-insert-batch store (mapcar #'second jobs))
                        (error (err)
                          (log-msg 0 "writer: insert failed: ~a" err)
                          (mapcar (lambda (j) (declare (ignore j)) '(:rejected . "error: could not store the event")) jobs)))))
        (loop for (c e t0) in jobs
              for (status . detail) in results
              do (ecase status
                   (:stored (sb-ext:atomic-incf (stats-stored st))
                    (owner-fanout relay e)
                    (send-ok c (event-id-hex e) t ""))
                   (:ephemeral (retain-ephemeral relay e)
                    (owner-fanout relay e)
                    (send-ok c (event-id-hex e) t ""))
                   (:duplicate (sb-ext:atomic-incf (stats-duplicates st))
                    (send-ok c (event-id-hex e) t "duplicate: already have this event"))
                   (:rejected (sb-ext:atomic-incf (stats-rejected st))
                    (send-ok c (event-id-hex e) nil detail)))
                 (record-latency (stats-ingest-hist st) t0))
        (setf (server-events (relay-server relay)) (store-event-count store))))))

(defun owner-query (relay job)
  "Answer a REQ or COUNT in full, now.  A REQ is registered for live delivery
right after its EOSE, and nothing is committed in between."
  (destructuring-bind (kind sub) job
    (let ((c (sub-conn sub)) (store (relay-store relay)) (st (relay-stats relay)))
      (handler-case
          (ecase kind
            (:count
             (sb-ext:atomic-incf (stats-counts st))
             (let ((n (store-count store (sub-filters sub))))
               (conn-send c (msg-frame (lambda (b)
                                         (obuf-ascii b "[\"COUNT\",") (obuf-octets b (sub-id-json sub))
                                         (obuf-ascii b ",{\"count\":") (obuf-uint b n) (obuf-ascii b "}]"))))))
            (:req
             (sb-ext:atomic-incf (stats-reqs st))
             (unless (or (sub-closed sub) (conn-closed c))
               (let ((reader (store-reader store)) (fb (owner-frame-buf *owner*)))
                 (dolist (s (store-query store (sub-filters sub)))
                   (multiple-value-bind (buf start end) (read-event-json store s reader)
                     (let ((frame (write-event-frame fb (sub-id-json sub) buf start end)))
                       (conn-send-region c (obuf-data frame) 0 (obuf-fill frame)))))
                 (dolist (e (retained-matches relay (sub-filters sub)))
                   (let* ((json (event-json e))
                          (frame (write-event-frame fb (sub-id-json sub) json 0 (length json))))
                     (conn-send-region c (obuf-data frame) 0 (obuf-fill frame))))
                 (conn-send c (eose-frame sub))
                 (record-latency (stats-query-hist st) (sub-t0 sub))
                 (register-sub (sub-fanout relay sub) sub)
                 (setf (sub-state sub) :live)))))
        (error (err)
          (log-msg 0 "query failed: ~a" err)
          (send-closed c (sub-id sub) "error: query failed"))))))

(defun owner-work (o)
  "Everything a turn's input set in motion: verdicts, commits, queries, timers."
  (let* ((relay (owner-relay o)) (q (relay-query-q relay)))
    (when (plusp (owner-workers o)) (owner-collect o))
    (owner-commit-batch o)
    (loop while (plusp (bqueue-count q))
          do (let ((job (bqueue-pop q :timeout 0)))
               (when job (owner-query relay job))))
    (let ((now (now-us)))
      (loop while (and (owner-timers o) (<= (car (first (owner-timers o))) now))
            do (let ((thunk (cdr (pop (owner-timers o)))))
                 (handler-case (funcall thunk) (error (e) (log-msg 0 "timer: ~a" e))))))
    ;; a timer may have admitted events (a delayed one, checked inline)
    (owner-commit-batch o)
    (let ((store (relay-store relay)))
      (when (eq (store-sync store) :interval)
        (let ((now (now-us)))
          (when (>= (- now (owner-last-fsync o)) (* 1000 (config-fsync-interval-ms (relay-config relay))))
            (setf (owner-last-fsync o) now)
            (handler-case (store-fsync store) (error (e) (log-msg 0 "fsync failed: ~a" e)))))))
    (ioloop-settle (owner-io o))))

(defun owner-timeout-ms (o)
  (let ((ms 500))
    (when (owner-timers o)
      (setf ms (min ms (max 0 (ceiling (- (car (first (owner-timers o))) (now-us)) 1000)))))
    (when (and (eq (store-sync (relay-store (owner-relay o))) :interval))
      (setf ms (min ms (config-fsync-interval-ms (relay-config (owner-relay o))))))
    ms))

(defun udp-drain (relay buf)
  "Every datagram waiting on the UDP socket, up to a bound per turn."
  (let ((fd (socket-fd (relay-udp relay))))
    (loop repeat 256 do
      (let ((n (fd-read fd buf 0 (length buf))))
        (unless (and (integerp n) (plusp n)) (return))
        (sb-ext:atomic-incf (stats-udp (relay-stats relay)))
        (udp-datagram relay buf n)))))

(defun relay-owner (handle)
  "The owner thread: open the store and serve until the handle's server stops.
Returns NIL, or the text of what stopped it from starting."
  (let ((server (relay-server handle)) (config (relay-config handle)))
    (with-thread-io
      ;; specials the store and the verifier set: this thread's own bindings
      (let ((*sip-k0* *sip-k0*) (*sip-k1* *sip-k1*)
            (*point-cache* (make-point-cache))
            (*owner* nil))
        (let ((store (handler-case (open-store (config-dir config) :sync (config-sync config))
                       (error (e)
                         (setf (server-state server) -1)
                         (return-from relay-owner (format nil "~a" e))))))
          (let* ((relay (copy-relay handle))
                 (verifier (relay-verify-q handle))
                 (o (make-instance 'owner :relay relay :verifier verifier
                                          :workers (config-verify-threads config))))
            (setf (relay-store relay) store
                  (relay-writer-q relay) nil
                  (relay-query-q relay) (make-bqueue :limit (config-query-queue config))
                  (relay-fanouts relay) (vector (%make-fanout :fanned (index-count (store-index store))))
                  (relay-retained relay) '()
                  (relay-threads relay) '()
                  (relay-udp-limit relay) (make-cstate :event-tokens (float (config-event-burst config) 1d0)
                                                       :refilled (now-us)))
            (setf (owner-io o)
                  (make-ioloop server
                               :on-open (lambda (c) (relay-on-open relay c))
                               :on-message (lambda (c buf s e) (relay-on-message relay c buf s e))
                               :on-close (lambda (c) (relay-on-close relay c))
                               :on-http (lambda (c m tg h) (relay-on-http relay c m tg h))))
            (when (relay-udp relay)
              (let ((buf (make-octets 65536)))
                (ioloop-add-fd (owner-io o) (socket-fd (relay-udp relay)) (lambda () (udp-drain relay buf)))))
            (setf (server-events server) (store-event-count store)
                  (server-state server) 1)
            (setf *owner* o)
            (unwind-protect
                 (loop while (server-running server) do
                   (handler-case
                       (progn (ioloop-turn (owner-io o) (owner-timeout-ms o))
                              (owner-work o))
                     (error (e) (log-msg 0 "relay loop: ~a" e))))
              ;; stopping: close the connections, let accepted events finish, close the store
              (ignore-errors (ioloop-close-all (owner-io o) "server stopping"))
              (let ((deadline (+ (now-us) 10000000)))
                (loop while (and (plusp (hash-table-count (owner-inflight o))) (< (now-us) deadline))
                      do (ignore-errors (owner-collect o :timeout 0.05))))
              (ignore-errors (owner-commit-batch o))
              (setf (server-events server) (store-event-count store))
              (ignore-errors (store-fsync store))
              (close-store store)
              (setf (server-state server) 2)))))))
  nil)

;;; ---- the protocol's modus arms (relay.lisp marks their SBCL twins #-modus) ----------------

(defun retire-sub (relay sub)
  "Close SUB: the owner holds the subscription index, so take it out now."
  (setf (sub-closed sub) t)
  (unregister-sub (sub-fanout relay sub) sub))

(defun admit-event (relay c e raw-id t0)
  "As on SBCL (relay.lisp): what happens to a parsed event, on the WebSocket and
UDP paths alike.  Timers are the owner's; verification goes to the verify threads."
  (let ((st (relay-stats relay)))
    (let* ((idx (store-index (relay-store relay))) (s (index-find-id idx (event-id e))))
      (when (and s (not (serial-deleted-p (index-columns idx) s)))
        (sb-ext:atomic-incf (stats-duplicates st))
        (return-from admit-event (send-ok c raw-id t "duplicate: already have this event"))))
    (let* ((policy (config-event-policy (relay-config relay)))
           (verdict (and policy (handler-case (funcall policy e)
                                  (error (err) (log-msg 0 "event policy: ~a" err) nil)))))
      (cond ((null verdict))
            ((or (eq verdict :drop) (and (consp verdict) (eq (car verdict) :drop)))
             (sb-ext:atomic-incf (stats-rejected st))
             (return-from admit-event
               (send-ok c raw-id nil (format nil "blocked: ~a" (if (consp verdict) (second verdict) "policy")))))
            ((and (realp verdict) (plusp verdict))
             (owner-after verdict (lambda () (owner-verify relay nil e (now-us) raw-id)))
             (return-from admit-event (send-ok c raw-id t "")))
            ((and (consp verdict) (eq (car verdict) :dup) (realp (second verdict)))
             (owner-after (max 0 (second verdict)) (lambda () (owner-fanout relay e))))))
    (unless (owner-verify relay c e t0 raw-id)
      (sb-ext:atomic-incf (stats-busy st))
      (send-ok c raw-id nil "rate-limited: relay is busy, try again"))))

(defun relay-stats-json (relay)
  (let* ((st (relay-stats relay)) (server (relay-server relay)) (o *owner*))
    (string-utf8
     (format nil "{\"events\":~d,\"received\":~d,\"stored\":~d,\"duplicates\":~d,\"rejected\":~d,\"invalid\":~d,\"busy\":~d,\"reqs\":~d,\"counts\":~d,\"delivered\":~d,\"udp_datagrams\":~d,\"connections\":~d,\"verify_queue\":~d,\"query_queue\":~d,\"ingest_p50_us\":~d,\"ingest_p99_us\":~d,\"query_p50_us\":~d,\"query_p99_us\":~d,\"point_cache_hits\":~d,\"point_cache_misses\":~d,\"io_busy_p99_us\":~d,\"io_busy_max_us\":~d}"
             (server-events server) (stats-received st) (stats-stored st) (stats-duplicates st)
             (stats-rejected st) (stats-invalid st) (stats-busy st) (stats-reqs st) (stats-counts st)
             (stats-delivered st) (stats-udp st) (server-connections server)
             (if o (hash-table-count (owner-inflight o)) 0)
             (if (relay-query-q relay) (bqueue-count (relay-query-q relay)) 0)
             (hist-percentile (stats-ingest-hist st) 0.5) (hist-percentile (stats-ingest-hist st) 0.99)
             (hist-percentile (stats-query-hist st) 0.5) (hist-percentile (stats-query-hist st) 0.99)
             *point-cache-hits* *point-cache-misses*
             (hist-percentile (server-busy-hist server) 0.99) (server-busy-max server)))))

;;; ---- starting and stopping (on the thread that keeps the handle) -----------------------------

(defun start-relay (&optional (config (make-config)))
  "Open the store and start serving.  Returns the relay: a handle the calling
thread keeps, while the owner thread serves."
  (secp:secp-init)                      ; its tables are made here, read by every thread
  (let* ((server (make-server :host (config-host config) :port (config-port config)
                              :max-message (config-max-message config)
                              :max-connections (config-max-connections config)))
         (key (and (config-udp-port config) (config-udp-secret config)
                   (udp-secret-key (config-udp-secret config))))
         (udp (and (config-udp-port config) (make-udp-socket (config-host config) (config-udp-port config))))
         (verifier (make-instance 'verifier :in (modus:make-channel :name "beacon verify")
                                            :out (modus:make-channel :name "beacon verdicts")
                                            :waker (server-waker server)))
         (relay (%make-relay :config config :server server :verify-q verifier
                             :udp udp :udp-key key))
         (owner (sb-thread:make-thread #'relay-owner :arguments (list relay) :name "beacon-owner")))
    (loop while (zerop (server-state server)) do (sleep 0.005))
    (when (minusp (server-state server))
      (let ((why (sb-thread:join-thread owner :default "the owner thread failed")))
        (close-server server)
        (when udp (close-socket udp))
        (error "beacon: could not start: ~a" why)))
    (setf (verifier-threads verifier)
          (loop for i below (config-verify-threads config)
                collect (sb-thread:make-thread #'verify-thread :arguments (list verifier)
                                                               :name (format nil "beacon-verify-~d" i))))
    (setf (relay-threads relay) (cons owner (verifier-threads verifier)))
    (when udp
      (log-msg 1 "beacon udp on ~a:~d~@[ (NIP-44 encrypted, relay pubkey ~a)~]"
               (config-host config) (listener-port udp)
               (and key (hex-encode (schnorr:pubkey-xonly key)))))
    (log-msg 1 "beacon listening on ~a:~d (~d events; one owner thread, ~d verify)"
             (config-host config) (relay-port relay) (server-events server) (config-verify-threads config))
    relay))

(defun stop-relay (relay)
  (let ((server (relay-server relay)) (verifier (relay-verify-q relay)))
    (setf (server-running server) nil (relay-running relay) nil)
    (wake (server-waker server))
    (ignore-errors (sb-thread:join-thread (first (relay-threads relay)) :timeout 30))
    (dolist (th (verifier-threads verifier))
      (declare (ignore th))
      (modus:channel-send (verifier-in verifier) :stop :timeout 1))
    (dolist (th (verifier-threads verifier)) (ignore-errors (sb-thread:join-thread th :timeout 10)))
    (close-server server)
    (when (relay-udp relay) (close-socket (relay-udp relay)))
    relay))

(defun relay-event-count (relay)
  "Live events in the relay's store, as the owner last counted them."
  (server-events (relay-server relay)))
