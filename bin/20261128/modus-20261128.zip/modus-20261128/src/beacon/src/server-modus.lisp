;;;; src/server-modus.lisp — connections on modus: one owner thread, many sockets.
;;;;
;;;; The SBCL server (server.lisp) spreads connections over I/O threads and lets any
;;;; thread write to any connection under its OUT-LOCK.  Modus threads share no
;;;; heap: a thread's objects live in its own region, and storing one where another
;;;; thread can reach it is refused.  So on modus every connection belongs to ONE
;;;; thread, the relay's owner, and this file is that thread's event loop over
;;;; non-blocking sockets and poll(2) -- the classic single-threaded server.
;;;;
;;;; THE SPLIT.  A SERVER is the part made on the thread that starts the relay: the
;;;; listening socket, a wakeup pipe, and counters.  Other threads read it and the
;;;; owner writes only numbers into it, which is all modus lets cross.  An IOLOOP is
;;;; the owner's: its connections, their buffers and output queues, the poll set,
;;;; and the callbacks.  Nothing in an IOLOOP is ever seen by another thread.
;;;;
;;;; The connection API is the SBCL server's (CONN-SEND, CONN-SEND-REGION,
;;;; CONN-CLOSE-AFTER-FLUSH, CONN-KILL-NOW, CONN-USER, CONN-ID, CONN-CLOSED), so the
;;;; protocol code in relay.lisp runs on either.  Sending is simpler here: only the
;;;; owner sends, so there is no lock, no dirty list, and no stale-fd race.

(in-package #:beacon)

;;; ---- the server: made by the starting thread, read by everyone ----------------------

(defclass server ()
  ((listener :initarg :listener :reader server-listener)
   (waker :initarg :waker :reader server-waker)
   (running :initform t :accessor server-running)
   (max-message :initarg :max-message :reader server-max-message)
   (max-out-bytes :initarg :max-out-bytes :reader server-max-out-bytes)
   (max-connections :initarg :max-connections :reader server-max-connections)
   (idle-timeout :initarg :idle-timeout :reader server-idle-timeout)
   ;; written by the owner (numbers only)
   (state :initform 0 :accessor server-state)              ; 0 starting, 1 serving, 2 stopped, -1 failed
   (events :initform 0 :accessor server-events)            ; live events in the store
   (connections :initform 0 :accessor server-connections)
   (next-id :initform 0 :accessor server-next-id)
   (busy-max :initform 0 :accessor server-busy-max)        ; longest loop turn (us)
   (busy-hist :initform (make-array 32 :element-type 'fixnum :initial-element 0)
              :reader server-busy-hist)))

(defun make-server (&key (host "127.0.0.1") (port 7777) (max-message (* 1024 1024))
                         (max-connections 20000) (idle-timeout 600) (max-out-bytes (* 32 1024 1024)))
  "The listener and wakeup pipe of a server whose connections an IOLOOP will own.
Call on the thread that starts the relay; the IOLOOP is made on the owner."
  (ignore-sigpipe)
  (make-instance 'server :listener (make-listener host port) :waker (make-waker)
                         :max-message max-message :max-out-bytes max-out-bytes
                         :max-connections max-connections :idle-timeout idle-timeout))

(defun server-port (server) (listener-port (server-listener server)))

(defun close-server (server)
  "After the owner has stopped: release the listener and the pipe."
  (close-socket (server-listener server))
  (close-waker (server-waker server)))

;;; ---- the owner's side ----------------------------------------------------------------

(defclass ioloop ()
  ((server :initarg :server :reader ioloop-server)
   (on-open :initarg :on-open :initform nil :reader ioloop-on-open)
   (on-message :initarg :on-message :reader ioloop-on-message)
   (on-close :initarg :on-close :initform nil :reader ioloop-on-close)
   (on-http :initarg :on-http :initform nil :reader ioloop-on-http)
   (conns :initform (make-array 64 :adjustable t :fill-pointer 0) :reader ioloop-conns)
   (slots :initform (make-array 64 :adjustable t :fill-pointer 0) :reader ioloop-slots)
   (pollset :initform (make-pollset) :reader ioloop-pollset)
   ;; other descriptors the owner serves from the same poll: (fd . handler)
   (extras :initform '() :accessor ioloop-extras)
   (accepting :initform t :accessor ioloop-accepting)
   (doomed :initform '() :accessor ioloop-doomed)          ; connections to close this turn
   (last-housekeeping :initform 0 :accessor ioloop-last-housekeeping)))

(defclass conn ()
  ((id :initarg :id :reader conn-id)
   (socket :initarg :socket :reader conn-socket)
   (fd :initarg :fd :reader conn-fd)
   (io :initarg :io :reader conn-io)
   (peer :initarg :peer :reader conn-peer)
   (state :initform :http :accessor conn-state)            ; :http :ws
   (inbuf :initform (make-octets 16384) :accessor conn-inbuf)
   (in-fill :initform 0 :accessor conn-in-fill)
   (frag :initform nil :accessor conn-frag)                ; obuf while a fragmented message arrives
   (out-head :initform nil :accessor conn-out-head)        ; queued octet vectors
   (out-tail :initform nil :accessor conn-out-tail)
   (out-pos :initform 0 :accessor conn-out-pos)            ; bytes of the head already written
   (out-bytes :initform 0 :accessor conn-out-bytes)
   (closing :initform nil :accessor conn-closing)          ; close once output drains
   (kill :initform nil :accessor conn-kill)                ; close at the end of this turn
   (closed :initform nil :accessor conn-closed)
   (last-active :initarg :last-active :accessor conn-last-active)
   (pinged :initform nil :accessor conn-pinged)
   (user :initform nil :accessor conn-user)))              ; the relay's per-connection state

(defun make-ioloop (server &key on-open on-message on-close on-http)
  (make-instance 'ioloop :server server :on-open on-open :on-message on-message
                         :on-close on-close :on-http on-http))

(defun ioloop-add-fd (io fd handler)
  "Serve FD from the same poll: HANDLER (no arguments) runs when it is readable."
  (push (cons fd handler) (ioloop-extras io)))

;;; ---- sending (the owner only) ----------------------------------------------------------

(defun %doom (c)
  (unless (conn-kill c)
    (setf (conn-kill c) t)
    (push c (ioloop-doomed (conn-io c)))))

(defun %write-queue (c)
  "Write as much queued output as the socket takes.  NIL if the connection failed."
  (loop while (conn-out-head c) do
    (let* ((chunk (car (conn-out-head c)))
           (n (fd-write (conn-fd c) chunk (conn-out-pos c) (length chunk))))
      (cond ((eq n :again) (return t))
            ((eq n :error) (return nil))
            (t (incf (conn-out-pos c) n)
               (decf (conn-out-bytes c) n)
               (when (= (conn-out-pos c) (length chunk))
                 (pop (conn-out-head c))
                 (setf (conn-out-pos c) 0)
                 (unless (conn-out-head c) (setf (conn-out-tail c) nil))))))
        finally (return t)))

(defun conn-send-region (c buf start end)
  "Send BUF[START,END) to C: straight to the socket when nothing is queued ahead
of it, and whatever the kernel does not take is COPIED onto C's queue, so BUF may
be a scratch buffer.  NIL if C is closed."
  (declare (type octets buf) (type ufix start end))
  (when (or (conn-closed c) (conn-kill c)) (return-from conn-send-region nil))
  (when (null (conn-out-head c))
    (loop while (< start end) do
      (let ((n (fd-write (conn-fd c) buf start end)))
        (cond ((eq n :error) (%doom c) (return-from conn-send-region t))
              ((eq n :again) (return))
              (t (incf start n))))))
  (when (< start end)
    (let ((cell (list (subseq buf start end))))
      (if (conn-out-tail c)
          (setf (cdr (conn-out-tail c)) cell (conn-out-tail c) cell)
          (setf (conn-out-head c) cell (conn-out-tail c) cell (conn-out-pos c) 0))
      (incf (conn-out-bytes c) (- end start)))
    (when (> (conn-out-bytes c) (server-max-out-bytes (ioloop-server (conn-io c))))
      (%doom c)))
  t)

(defun conn-send (c octets) (conn-send-region c octets 0 (length octets)))

(defun conn-send-throttled (c buf &key (start 0) (end (length buf)) high-water timeout)
  "On one thread there is no waiting for a client to drain: this is CONN-SEND-REGION,
bounded by the server's MAX-OUT-BYTES."
  (declare (ignore high-water timeout))
  (conn-send-region c buf start end))

(defun conn-close-after-flush (c) (setf (conn-closing c) t))

(defun conn-kill-now (c) (%doom c))

;;; ---- the loop ---------------------------------------------------------------------------

(defun %close-conn (io c reason)
  (unless (conn-closed c)
    (setf (conn-closed c) t
          (conn-out-head c) nil (conn-out-tail c) nil (conn-out-bytes c) 0)
    (close-socket (conn-socket c))
    (decf (server-connections (ioloop-server io)))
    (log-msg 2 "conn ~d closed: ~a" (conn-id c) reason)
    (let ((h (ioloop-on-close io)))
      (when h (ignore-errors (funcall h c))))))

(defun %flush (io c)
  (cond ((not (%write-queue c)) (%close-conn io c "write error"))
        ((and (conn-closing c) (null (conn-out-head c))) (%close-conn io c "closed"))))

(defun %compact-input (c consumed)
  (when (plusp consumed)
    (replace (conn-inbuf c) (conn-inbuf c) :start2 consumed :end2 (conn-in-fill c))
    (setf (conn-in-fill c) (- (conn-in-fill c) consumed))))

(defun %handle-http (io c)
  (let* ((buf (conn-inbuf c))
         (hend (find-header-end buf 0 (conn-in-fill c))))
    (cond
      ((null hend)
       (when (> (conn-in-fill c) *max-http-header-bytes*) (%close-conn io c "oversized HTTP header"))
       nil)
      (t
       (multiple-value-bind (method target headers) (parse-http-request buf 0 hend)
         (cond
           ((and (string-equal method "GET")
                 (header-has-token-p headers "upgrade" "websocket")
                 (header headers "sec-websocket-key"))
            (conn-send c (websocket-upgrade-response (header headers "sec-websocket-key")))
            (setf (conn-state c) :ws)
            (%compact-input c hend)
            (when (ioloop-on-open io) (funcall (ioloop-on-open io) c))
            t)
           (t
            (let ((resp (and (ioloop-on-http io) (funcall (ioloop-on-http io) c method target headers))))
              (conn-send c (or resp (http-response 404 "Not Found" :body "not found")))
              (conn-close-after-flush c)
              (setf (conn-in-fill c) 0)
              nil))))))))

(defun %dispatch-message (io c buf start end)
  (handler-case (funcall (ioloop-on-message io) c buf start end)
    (error (e) (log-msg 0 "conn ~d: handler error: ~a" (conn-id c) e))))

(defun %handle-frames (io c)
  (let ((buf (conn-inbuf c)) (pos 0) (max (server-max-message (ioloop-server io))))
    (handler-case
        (loop
          (when (or (conn-closed c) (conn-closing c) (conn-kill c)) (return))
          (multiple-value-bind (fin opcode ps pe fe) (ws-parse-frame buf pos (conn-in-fill c) max)
            (when (null opcode) (return))        ; incomplete frame
            (setf pos fe)
            (case opcode
              ((#.+op-text+ #.+op-binary+)
               (when (conn-frag c) (protocol-fail "new message inside a fragmented one"))
               (if fin
                   (%dispatch-message io c buf ps pe)
                   (setf (conn-frag c) (obuf-octets (make-obuf (max 1024 (- pe ps))) buf ps pe))))
              (#.+op-continuation+
               (unless (conn-frag c) (protocol-fail "continuation without a message"))
               (obuf-octets (conn-frag c) buf ps pe)
               (when (> (obuf-fill (conn-frag c)) max) (protocol-fail "message too large"))
               (when fin
                 (let ((m (conn-frag c)))
                   (setf (conn-frag c) nil)
                   (%dispatch-message io c (obuf-data m) 0 (obuf-fill m)))))
              (#.+op-ping+ (conn-send c (ws-frame +op-pong+ buf ps pe)))
              (#.+op-pong+ (setf (conn-pinged c) nil))
              (#.+op-close+
               (conn-send c (ws-frame +op-close+ buf ps (min pe (+ ps 2))))
               (conn-close-after-flush c)
               (return))
              (t (protocol-fail "unknown opcode ~d" opcode)))))
      (protocol-error (e)
        (conn-send c (ws-close-frame 1002 (protocol-error-message e)))
        (conn-close-after-flush c)))
    (unless (conn-closed c) (%compact-input c pos))))

(defun %handle-readable (io c)
  (let ((max-buf (+ (server-max-message (ioloop-server io)) 16)))
    (loop repeat 32 do
      (when (>= (conn-in-fill c) (length (conn-inbuf c)))
        (if (>= (length (conn-inbuf c)) max-buf)
            (progn (%close-conn io c "input overflow") (return))
            (setf (conn-inbuf c) (grow-vector (conn-inbuf c) (min max-buf (* 2 (length (conn-inbuf c))))))))
      (let ((n (fd-read (conn-fd c) (conn-inbuf c) (conn-in-fill c) (length (conn-inbuf c)))))
        (cond ((eq n :again) (return))
              ((or (eq n :error) (eql n 0)) (%close-conn io c "peer closed") (return))
              (t (incf (conn-in-fill c) n)
                 (setf (conn-last-active c) (get-universal-time) (conn-pinged c) nil)
                 (when (eq (conn-state c) :http)
                   (unless (%handle-http io c) (return)))
                 (when (eq (conn-state c) :ws) (%handle-frames io c))
                 (when (or (conn-closed c) (conn-kill c)) (return))))))
    (when (and (not (conn-closed c)) (> (length (conn-inbuf c)) 65536) (< (conn-in-fill c) 16384))
      (setf (conn-inbuf c) (subseq (conn-inbuf c) 0 (max 16384 (conn-in-fill c)))))))

(defun %accept-all (io)
  (let ((server (ioloop-server io)))
    (loop for s = (accept-connection (server-listener server))
          while s
          do (if (>= (server-connections server) (server-max-connections server))
                 (close-socket s)
                 (let ((c (make-instance 'conn :id (incf (server-next-id server))
                                               :socket s :fd (socket-fd s) :io io :peer (socket-peer s)
                                               :last-active (get-universal-time))))
                   (incf (server-connections server))
                   (vector-push-extend c (ioloop-conns io)))))))

(defun %housekeeping (io)
  (let ((now (get-universal-time)) (timeout (server-idle-timeout (ioloop-server io))))
    (loop for c across (ioloop-conns io)
          unless (conn-closed c)
            do (let ((idle (- now (conn-last-active c))))
                 (cond ((and (conn-pinged c) (> idle (+ timeout 30))) (%close-conn io c "idle"))
                       ((and (> idle timeout) (not (conn-pinged c)) (eq (conn-state c) :ws))
                        (setf (conn-pinged c) t)
                        (conn-send c (ws-frame +op-ping+ (make-octets 0))))
                       ((and (eq (conn-state c) :http) (> idle 30)) (%close-conn io c "http timeout")))))
    (%drop-closed io)))

(defun %drop-closed (io)
  (let ((v (ioloop-conns io)) (j 0))
    (loop for c across v unless (conn-closed c) do (setf (aref v j) c) (incf j))
    (setf (fill-pointer v) j)))

(defun %close-doomed (io)
  (loop while (ioloop-doomed io)
        do (let ((c (pop (ioloop-doomed io))))
             (%close-conn io c "dropped (slow consumer or error)"))))

(defun ioloop-turn (io timeout-ms)
  "One turn: wait up to TIMEOUT-MS for any descriptor, then serve every one that
is ready -- the wakeup pipe, the listener, the extra descriptors, the connections."
  (let* ((ps (ioloop-pollset io)) (slots (ioloop-slots io)) (server (ioloop-server io))
         (waker (server-waker server)) (extras (ioloop-extras io)))
    (pollset-clear ps)
    (setf (fill-pointer slots) 0)
    (pollset-add ps (waker-rfd waker) +pollin+)
    (pollset-add ps (if (ioloop-accepting io) (socket-fd (server-listener server)) -1) +pollin+)
    (dolist (x extras) (pollset-add ps (car x) +pollin+))
    (loop for c across (ioloop-conns io)
          unless (conn-closed c)
            do (pollset-add ps (conn-fd c) (if (conn-out-head c) (logior +pollin+ +pollout+) +pollin+))
               (vector-push-extend c slots))
    (pollset-wait ps timeout-ms)
    (let ((t-busy (now-us)))
      (unless (zerop (pollset-revents ps 0)) (drain-waker waker))
      (unless (zerop (pollset-revents ps 1)) (%accept-all io))
      (loop for x in extras for i from 2
            unless (zerop (pollset-revents ps i))
              do (handler-case (funcall (cdr x))
                   (error (e) (log-msg 0 "fd ~d: ~a" (car x) e))))
      (loop for c across slots for i from (+ 2 (length extras))
            for re = (pollset-revents ps i)
            unless (or (zerop re) (conn-closed c) (conn-kill c))
              do (handler-case
                     (progn
                       (when (logtest re +pollout+) (%flush io c))
                       (when (and (not (conn-closed c)) (logtest re (logior +pollin+ +pollhup+ +pollerr+)))
                         (%handle-readable io c))
                       (when (and (not (conn-closed c)) (logtest re +pollnval+))
                         (%close-conn io c "invalid fd")))
                   (error (e) (log-msg 0 "conn ~d: ~a" (conn-id c) e) (%close-conn io c "internal error"))))
      (ioloop-settle io)
      (let ((now (get-universal-time)))
        (when (/= now (ioloop-last-housekeeping io))
          (setf (ioloop-last-housekeeping io) now)
          (%housekeeping io)))
      (let ((us (max 1 (- (now-us) t-busy))))
        (setf (server-busy-max server) (max (server-busy-max server) us))
        (incf (aref (server-busy-hist server) (min 31 (1- (integer-length us)))))))))

(defun ioloop-settle (io)
  "Close what was killed, and finish closes whose output has drained.  The owner
calls this after any work that sends (a turn calls it itself)."
  (%close-doomed io)
  (loop for c across (ioloop-conns io)
        when (and (conn-closing c) (not (conn-closed c)) (null (conn-out-head c)))
          do (%close-conn io c "closed")))

(defun ioloop-close-all (io reason)
  (loop for c across (ioloop-conns io) do (%close-conn io c reason))
  (setf (fill-pointer (ioloop-conns io)) 0))
