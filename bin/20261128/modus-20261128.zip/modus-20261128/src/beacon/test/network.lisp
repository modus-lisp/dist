;;;; test/network.lisp — the relay over real sockets, driven by cl-nostr.
;;;;
;;;; cl-nostr is an independent client (its own event serialization, its own
;;;; WebSocket client over seal), so these tests check beacon against something
;;;; that did not grow up with it.  Raw WebSocket traffic, for the messages
;;;; cl-nostr has no API for (COUNT, malformed input), goes through
;;;; seal.websocket directly.
;;;;
;;;; ON MODUS the client side runs on the test's own thread too.  Modus threads share
;;;; no heap, so cl-nostr there has no reader thread: waiting (WAIT-STEP) is what
;;;; reads the relays and runs the callbacks, which is why WAIT-UNTIL calls it (on
;;;; SBCL it is a SLEEP).  The two places that start a thread of their own have a
;;;; #+modus arm that does the same thing without handing objects across threads.

(in-package #:beacon.test)

(defvar *relay* nil)

(defun relay-url () (format nil "ws://127.0.0.1:~d/" (relay-port *relay*)))

(defun wait-until (fn &key (timeout 10))
  (let ((deadline (+ (get-internal-real-time) (* timeout internal-time-units-per-second))))
    (loop (when (funcall fn) (return t))
          (when (> (get-internal-real-time) deadline) (return nil))
          (cl-nostr.util:wait-step 0.01))))

(defun nkey () (cl-nostr.keys:generate-keypair))

(defun note (kp content &key (kind 1) tags)
  (cl-nostr.event:build-event kp kind content :tags tags))

(defun publish-sync (r event)
  "Publish and wait for the OK.  -> (values accepted message)."
  (let ((done nil) (acc nil) (msg nil))
    (cl-nostr.relay:publish r event :on-ok (lambda (a m) (setf acc a msg m done t)))
    (wait-until (lambda () done))
    (values acc msg done)))

(defun fetch (r filters &key (timeout 10))
  "Stored events for FILTERS (cl-nostr filter structs) until EOSE."
  (let ((events '()) (eose nil))
    (let ((sub (cl-nostr.relay:subscribe r filters
                                         :on-event (lambda (e rl) (declare (ignore rl)) (push e events))
                                         :on-eose (lambda (rl) (declare (ignore rl)) (setf eose t)))))
      (wait-until (lambda () eose) :timeout timeout)
      (cl-nostr.relay:unsubscribe r sub))
    (values (nreverse events) eose)))

(defun raw-ws ()
  (seal.websocket:connect (relay-url)))

(defun raw-exchange (ws text &key (timeout 5))
  "Send TEXT, return the first reply as a parsed vector."
  (seal.websocket:send-text ws text)
  #+modus   ; read by readiness on this thread: a reader thread could not hand its string back
  (let ((reply nil))
    (wait-until (lambda () (setf reply (ignore-errors (seal.websocket:receive-text ws :wait nil))))
                :timeout timeout)
    (and reply (json-simple:parse reply)))
  #-modus
  (let ((reply nil))
    (let ((th (sb-thread:make-thread (lambda () (setf reply (ignore-errors (seal.websocket:receive-text ws)))))))
      (wait-until (lambda () reply) :timeout timeout)
      (unless reply (ignore-errors (sb-thread:terminate-thread th))))
    (and reply (json-simple:parse reply))))

#+modus
(defun publish-stream (url texts)
  "Send each of TEXTS on a WebSocket of this thread's own, then wait for every OK."
  (let ((ws (seal.websocket:connect url)) (oks 0))
    (unwind-protect
         (progn
           (dolist (text texts) (seal.websocket:send-text ws text))
           (let ((deadline (+ (get-internal-real-time) (* 20 internal-time-units-per-second))))
             (loop while (and (< oks (length texts)) (< (get-internal-real-time) deadline))
                   do (let ((m (seal.websocket:receive-text ws :wait nil)))
                        (if m (incf oks) (sleep 0.005))))))
      (ignore-errors (seal.websocket:close-socket ws)))
    oks))

(defun http-get (path &key accept)
  (let ((s (make-instance 'sb-bsd-sockets:inet-socket :type :stream :protocol :tcp)))
    (sb-bsd-sockets:socket-connect s #(127 0 0 1) (relay-port *relay*))
    (let ((stream (sb-bsd-sockets:socket-make-stream s :input t :output t :element-type 'character
                                                       :external-format :latin-1)))
      (format stream "GET ~a HTTP/1.1~c~cHost: x~c~c~@[Accept: ~a~c~c~]~c~c" path #\Return #\Newline #\Return #\Newline
              accept #\Return #\Newline #\Return #\Newline)
      (force-output stream)
      (prog1 (with-output-to-string (out)
               (loop for line = (read-line stream nil) while line do (write-line line out)))
        (close stream)))))

(defun run-network-tests ()
  (let ((dir (fresh-dir "network")))
    (setf *relay* (start-relay (make-config :port 0 :dir (namestring dir) :io-threads 2
                                            :verify-threads 2 :query-threads 2 :sync nil
                                            :events-per-second 100000 :event-burst 100000)))
    (unwind-protect
         (let* ((alice (nkey)) (bob (nkey))
                (r (cl-nostr.relay:connect-relay (relay-url))))
           (unwind-protect
                (progn
                  ;; publish + read back
                  (let ((e (note alice "hello beacon")))
                    (multiple-value-bind (ok msg done) (publish-sync r e)
                      (check "publish acknowledged" done)
                      (check (format nil "publish accepted (~a)" msg) ok))
                    (multiple-value-bind (ok msg) (publish-sync r e)
                      (check "duplicate accepted" ok)
                      (check "duplicate says so" (and msg (search "duplicate" msg))))
                    (let ((got (fetch r (cl-nostr.filter:make-filter
                                         :authors (list (cl-nostr.keys:public-hex alice))))))
                      (check "fetch by author" (= 1 (length got)))
                      (check "fetched event verifies (cl-nostr's own check)"
                             (and got (cl-nostr.event:verify-event (first got))))
                      (check "fetched event is byte-identical in meaning"
                             (and got (string= (cl-nostr.event:event-id (first got)) (cl-nostr.event:event-id e))))))
                  ;; bad signature
                  (let* ((e (note alice "forged")))
                    (setf (cl-nostr.event:event-sig e)
                          (concatenate 'string (subseq (cl-nostr.event:event-sig e) 0 126)
                                       (if (string= (subseq (cl-nostr.event:event-sig e) 126) "00") "11" "00")))
                    (multiple-value-bind (ok msg) (publish-sync r e)
                      (check "bad signature rejected" (not ok))
                      (check "bad signature reason" (and msg (search "invalid" msg)))))
                  ;; unicode + escapes round trip
                  (let ((e (note bob (format nil "naïve ☃ \"quoted\" back\\slash tab	 ~a" (code-char #x1F600))
                                 :tags '(("t" "unicode") ("p" "deadbeef")))))
                    (publish-sync r e)
                    (let ((got (fetch r (cl-nostr.filter:make-filter :tags '(("t" . ("unicode")))))))
                      (check "unicode event round-trips"
                             (and got (string= (cl-nostr.event:event-content (first got)) (cl-nostr.event:event-content e))
                                  (cl-nostr.event:verify-event (first got))))))
                  ;; live delivery to a second connection
                  (let ((r2 (cl-nostr.relay:connect-relay (relay-url))) (live '()) (eose nil))
                    (unwind-protect
                         (progn
                           (cl-nostr.relay:subscribe r2 (cl-nostr.filter:make-filter :kinds '(1) :authors (list (cl-nostr.keys:public-hex bob)))
                                                     :on-event (lambda (e rl) (declare (ignore rl)) (push e live))
                                                     :on-eose (lambda (rl) (declare (ignore rl)) (setf eose t)))
                           (wait-until (lambda () eose))
                           (let ((before (length live)))
                             (publish-sync r (note bob "live one"))
                             (check "live event delivered" (wait-until (lambda () (> (length live) before)) :timeout 5))))
                      (cl-nostr.relay:close-relay r2)))
                  ;; GAP-FREE: subscribe in the middle of a publish stream
                  (let* ((carol (nkey)) (n 300)
                         (events (loop for i below n collect (note carol (format nil "stream ~d" i))))
                         (r2 (cl-nostr.relay:connect-relay (relay-url)))
                         (seen (make-hash-table :test 'equal)) (dups 0))
                    (unwind-protect
                         (let ((pub #-modus
                                    (sb-thread:make-thread
                                     (lambda () (dolist (e events) (cl-nostr.relay:publish r e))))
                                    ;; modus: R belongs to this thread, so the publisher opens a
                                    ;; connection of its own and is handed the events as text
                                    #+modus
                                    (sb-thread:make-thread
                                     #'publish-stream
                                     :arguments (list (relay-url)
                                                      (mapcar (lambda (e)
                                                                (concatenate 'string "[\"EVENT\","
                                                                             (cl-nostr.event:event->json e) "]"))
                                                              events)))))
                           (sleep 0.05)
                           (cl-nostr.relay:subscribe r2 (cl-nostr.filter:make-filter :authors (list (cl-nostr.keys:public-hex carol)) :limit 5000)
                                                     :on-event (lambda (e rl) (declare (ignore rl))
                                                                 (if (gethash (cl-nostr.event:event-id e) seen)
                                                                     (incf dups)
                                                                     (setf (gethash (cl-nostr.event:event-id e) seen) t))))
                           (sb-thread:join-thread pub)
                           (check (format nil "gap-free: all ~d events seen (got ~d)" n (hash-table-count seen))
                                  (wait-until (lambda () (= n (hash-table-count seen))) :timeout 20))
                           (check (format nil "gap-free: no duplicates (~d)" dups) (zerop dups)))
                      (cl-nostr.relay:close-relay r2)))
                  ;; raw protocol: COUNT, CLOSED, NOTICE
                  (let ((ws (raw-ws)))
                    (unwind-protect
                         (progn
                           (let ((reply (raw-exchange ws (format nil "[\"COUNT\",\"c1\",{\"authors\":[\"~a\"]}]" (cl-nostr.keys:public-hex alice)))))
                             (check "COUNT reply" (and reply (string= (aref reply 0) "COUNT")
                                                       (= 1 (gethash "count" (aref reply 2))))))
                           (let ((reply (raw-exchange ws "[\"REQ\",\"s1\",{\"ids\":[\"nothex\"]}]")))
                             (check "bad filter -> CLOSED" (and reply (string= (aref reply 0) "CLOSED") (string= (aref reply 1) "s1"))))
                           (let ((reply (raw-exchange ws "not json")))
                             (check "garbage -> NOTICE" (and reply (string= (aref reply 0) "NOTICE"))))
                           (let ((reply (raw-exchange ws "[\"EVENT\",{\"id\":\"x\"}]")))
                             (check "malformed event -> OK false" (and reply (string= (aref reply 0) "OK") (null (aref reply 2))))))
                      (ignore-errors (seal.websocket:close-socket ws))))
                  ;; NIP-11
                  (let ((resp (http-get "/" :accept "application/nostr+json")))
                    (check "NIP-11 document" (and (search "200 OK" resp) (search "\"supported_nips\"" resp)
                                                  (search "Access-Control-Allow-Origin" resp))))
                  (let ((resp (http-get "/stats")))
                    (check "stats endpoint" (search "\"stored\"" resp))))
             (cl-nostr.relay:close-relay r)))
      (stop-relay *relay*))
    ;; the events are durable: reopen the store and count them
    (let ((store (open-store dir)))
      (check "events survive a restart" (>= (store-event-count store) 300))
      (close-store store))))

(defun run-policy-tests ()
  "EVENT-POLICY (drop, delay) and RETAIN-EPHEMERAL, on a relay of their own."
  (let* ((dir (fresh-dir "policy"))
         (relay (start-relay (make-config :port 0 :dir (namestring dir) :io-threads 1 :verify-threads 1
                                          :query-threads 1 :sync nil
                                          :event-policy (lambda (e) (case (event-kind e) (7 '(:drop "test")) (8 1) (9 '(:dup 1))))
                                          :retain-ephemeral (lambda (e) (= (event-kind e) 20002))
                                          :ephemeral-ttl 60))))
    (unwind-protect
         (let* ((*relay* relay) (alice (nkey)) (me (cl-nostr.keys:public-hex alice))
                (r (cl-nostr.relay:connect-relay (relay-url))))
           (flet ((by-kind (k &key since)
                    (fetch r (if since
                                 (cl-nostr.filter:make-filter :kinds (list k) :authors (list me) :since since)
                                 (cl-nostr.filter:make-filter :kinds (list k) :authors (list me))))))
             (unwind-protect
                  (progn
                    (multiple-value-bind (ok msg) (publish-sync r (note alice "dropped" :kind 7))
                      (check "policy drop -> OK false" (not ok))
                      (check "policy drop reason" (and msg (search "blocked: test" msg))))
                    (check "dropped event not stored" (null (by-kind 7)))
                    (multiple-value-bind (ok) (publish-sync r (note alice "late" :kind 8))
                      (check "policy delay -> OK true at once" ok))
                    (check "delayed event not there yet" (null (by-kind 8)))
                    (check "delayed event stored after the delay"
                           (wait-until (lambda () (by-kind 8)) :timeout 5))
                    (let ((live '()) (eose nil) (sub (cl-nostr.relay:connect-relay (relay-url))))
                      (unwind-protect
                           (progn
                             (cl-nostr.relay:subscribe sub (cl-nostr.filter:make-filter :kinds '(9) :authors (list me))
                                                       :on-event (lambda (e rl) (declare (ignore rl)) (push e live))
                                                       :on-eose (lambda (rl) (declare (ignore rl)) (setf eose t)))
                             (wait-until (lambda () eose))
                             (multiple-value-bind (ok) (publish-sync r (note alice "twice" :kind 9))
                               (check "policy dup -> OK true" ok))
                             (check "policy dup: a live subscriber gets the event twice"
                                    (wait-until (lambda () (= 2 (length live))) :timeout 5))
                             (check "policy dup: stored once" (= 1 (length (by-kind 9)))))
                        (cl-nostr.relay:close-relay sub)))
                    (let ((since (- (unix-now) 30)))
                      (publish-sync r (note alice "kept" :kind 20002))
                      (publish-sync r (note alice "not kept" :kind 20001))
                      (check "retained ephemeral returned to a since filter"
                             (= 1 (length (by-kind 20002 :since since))))
                      (check "retained ephemeral not returned without since" (null (by-kind 20002)))
                      (check "ephemeral the predicate refuses is not retained" (null (by-kind 20001 :since since)))))
               (cl-nostr.relay:close-relay r))))
      (stop-relay relay))))

;;; ---- UDP ingest ------------------------------------------------------------------------
;;; One signed event per datagram, from a plain socket that is not a client of the
;;; relay.  The checks look at both ends: what the relay stored and fanned out to a
;;; WebSocket subscriber, and what came back to the sender (nothing, on any path).

(defparameter *udp-relay-secret* (make-string 64 :initial-element #\1)
  "The relay's secret key for the encrypted-datagram tests (a valid scalar).")

(defun udp-send-octets (sock port octets)
  (sb-bsd-sockets:socket-send sock octets (length octets) :address (list #(127 0 0 1) port)))

(defun udp-send (sock port text)
  (udp-send-octets sock port (sb-ext:string-to-octets text :external-format :utf-8)))

(defun udp-got-reply-p (sock &optional (ms 300))
  "True if a datagram arrived at SOCK within MS milliseconds."
  (let ((ps (beacon::make-pollset)))
    (beacon::pollset-add ps (beacon::socket-fd sock) beacon::+pollin+)
    (plusp (beacon::pollset-wait ps ms))))

(defun run-udp-tests ()
  "UDP ingest: a datagram is stored (or refused) with no reply on any path."
  (let* ((dir (fresh-dir "udp"))
         (relay (start-relay (make-config :port 0 :udp-port 0 :udp-secret *udp-relay-secret*
                                          :dir (namestring dir) :io-threads 1
                                          :verify-threads 2 :query-threads 1 :sync nil
                                          :events-per-second 100000 :event-burst 100000)))
         (*relay* relay)
         (sender (make-instance 'sb-bsd-sockets:inet-socket :type :datagram :protocol :udp))
         (sub nil))
    (unwind-protect
         (let* ((port (beacon::listener-port (beacon::relay-udp relay)))
                (stats (beacon::relay-stats relay))
                (key (make-test-key))
                (author (beacon::hex-encode (cdr key)))
                (live '()))
           (flet ((send (text) (udp-send sender port text))
                  (stored () (beacon::relay-event-count relay))
                  (counter (fn) (funcall fn stats)))
             (let ((good (sign-event-json key 1 "udp hello")))
               (send good)
               (check "udp: valid event stored" (wait-until (lambda () (= 1 (stored)))))
               (send good)
               (check "udp: resent event counted as a duplicate"
                      (wait-until (lambda () (>= (counter #'beacon::stats-duplicates) 1))))
               (check "udp: no reply to an accepted event" (not (udp-got-reply-p sender))))
             (send (sign-event-json key 1 "forged" :fake-sig t))
             (check "udp: bad signature counted invalid"
                    (wait-until (lambda () (>= (counter #'beacon::stats-invalid) 1))))
             (send "not json at all")
             (send (sign-event-json key 1 (make-string 1600 :initial-element #\x)))
             (check "udp: garbage and oversize counted invalid"
                    (wait-until (lambda () (>= (counter #'beacon::stats-invalid) 3))))
             (send (sign-event-json key 1 "barrier"))
             (check "udp: later valid event stored" (wait-until (lambda () (= 2 (stored)))))
             (check "udp: refused datagrams are not stored" (= 2 (stored)))
             ;; live: a WebSocket subscriber sees a datagram event like any other
             (setf sub (cl-nostr.relay:connect-relay (relay-url)))
             (let ((eose nil))
               (cl-nostr.relay:subscribe sub (cl-nostr.filter:make-filter :kinds '(1) :authors (list author))
                                         :on-event (lambda (e rl) (declare (ignore rl)) (push e live))
                                         :on-eose (lambda (rl) (declare (ignore rl)) (setf eose t)))
               (wait-until (lambda () eose)))
             (send (sign-event-json key 1 "udp live"))
             (check "udp: live subscriber receives the datagram event"
                    (wait-until (lambda ()
                                  (find "udp live" live :key #'cl-nostr.event:event-content :test #'string=))))
             ;; cl-nostr's own UDP sender: its event stored, then read back over a
             ;; WebSocket and verified by cl-nostr -- the two implementations agree
             (let* ((kp (nkey))
                    (e (note kp (format nil "cl-nostr over UDP: naïve ☃ ~a" (code-char #x1F600))
                             :tags '(("t" "udp"))))
                    (id (cl-nostr.udp:publish-datagram "127.0.0.1" port e)))
               (check "udp: cl-nostr's datagram stored" (wait-until (lambda () (= 4 (stored)))))
               (let ((r3 (cl-nostr.relay:connect-relay (relay-url))))
                 (unwind-protect
                      (let ((got (fetch r3 (cl-nostr.filter:make-filter :ids (list id)))))
                        (check "udp: cl-nostr reads its datagram back, content and signature intact"
                               (and got
                                    (string= id (cl-nostr.event:event-id (first got)))
                                    (string= (cl-nostr.event:event-content e)
                                             (cl-nostr.event:event-content (first got)))
                                    (cl-nostr.event:verify-event (first got)))))
                   (cl-nostr.relay:close-relay r3))))
             ;; NIP-44 encrypted datagrams, addressed to the relay's key (cl-nostr seals them)
             (let* ((relay-pub (cl-nostr.keys:public-hex (cl-nostr.keys:keypair-from-secret *udp-relay-secret*)))
                    (author (nkey))
                    (sealed (note author "sealed for the relay"))
                    (tampered (cl-nostr.udp:encrypted-datagram (note author "tampered") relay-pub))
                    (ephemeral (loop for kp = (nkey)
                                     when (string= "7b" (subseq (cl-nostr.keys:public-hex kp) 0 2))
                                       return kp))
                    (colliding (cl-nostr.udp:encrypt-datagram ephemeral (note author "ephemeral begins with a brace")
                                                              relay-pub)))
               (check "udp: the colliding datagram really begins with '{'" (= #x7b (aref colliding 0)))
               (cl-nostr.udp:publish-datagram-encrypted "127.0.0.1" port sealed relay-pub)
               (check "udp: encrypted datagram opened and stored" (wait-until (lambda () (= 5 (stored)))))
               (cl-nostr.udp:publish-datagram-encrypted "127.0.0.1" port (note author "for someone else")
                                                        (cl-nostr.keys:public-hex (nkey)))
               (check "udp: encrypted to another key refused"
                      (wait-until (lambda () (>= (counter #'beacon::stats-invalid) 4))))
               (let ((altered (copy-seq tampered)))
                 (setf (aref altered (1- (length altered))) (logxor 1 (aref altered (1- (length altered)))))
                 (udp-send-octets sender port altered))
               (check "udp: altered encrypted datagram refused"
                      (wait-until (lambda () (>= (counter #'beacon::stats-invalid) 5))))
               (udp-send-octets sender port colliding)
               (check "udp: a datagram whose ephemeral key begins with '{' is opened"
                      (wait-until (lambda () (= 6 (stored)))))
               (check "udp: refused encrypted datagrams stored nothing" (= 6 (stored))))
             (check "udp: every datagram was read" (= 12 (counter #'beacon::stats-udp)))
             (check "udp: nothing ever came back to the sender" (not (udp-got-reply-p sender 300)))))
      (when sub (ignore-errors (cl-nostr.relay:close-relay sub)))
      (ignore-errors (sb-bsd-sockets:socket-close sender))
      (stop-relay relay))))
