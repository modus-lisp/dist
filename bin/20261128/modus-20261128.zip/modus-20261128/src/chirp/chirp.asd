;;;; chirp.asd -- a bitchat client in Common Lisp: the BLE mesh chat's wire protocol, over whatever moves the bytes.

(defsystem "chirp"
  :description "bitchat's mesh protocol: packets, signed announces and public messages, fragments, relaying."
  :license "MIT"
  :depends-on ("natrium" "cram")
  :serial t
  :components ((:module "src"
                :components ((:file "package")
                             (:file "packet")
                             (:file "identity")
                             (:file "mesh")))))

;; the chat on the phone: native screens over kiln-native (vessel's ios-native.lisp, loaded by the world first)
(defsystem "chirp/app"
  :depends-on ("chirp")
  :components ((:module "src" :components ((:file "app")))))

;; the chat in a glass window, for a desktop (modus on Windows: its radio is net/win32-ble.lisp)
(defsystem "chirp/glass"
  :depends-on ("chirp" "glass" "glass/text")
  :components ((:module "src" :components ((:file "glass")))))
