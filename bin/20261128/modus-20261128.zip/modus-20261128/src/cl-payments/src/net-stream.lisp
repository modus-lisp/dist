;;;; src/net-stream.lisp -- cl-payments' TCP: a Gray stream over cl-consensus's net layer.
;;;;
;;;; ONE THREADING MODEL, ON SBCL AND ON MODUS.  modus threads share no state (a worker may
;;;; not store its objects where another thread can reach them), and a Lightning peer's
;;;; handlers touch the node's channels, so the node has ONE owner thread and one net thread:
;;;; cl-consensus's net layer (cl-consensus.netloop), which owns every socket and moves
;;;; bytes over CL-TRANSPORT.CHAN channels.  SBCL runs exactly that too, so there is one
;;;; design to test.
;;;;
;;;; This file puts a Gray binary stream over one of the net layer's connections, so
;;;; everything above -- the BOLT #8 handshake, the transport, the control socket -- runs
;;;; unchanged on it.  A read pumps the net layer until its bytes are there (other
;;;; connections' input is delivered meanwhile, so a node can dial itself); a write is
;;;; handed to the net thread and returns.
;;;;
;;;; EXPOSE and DIAL stand in for cl-transport's TR:EXPOSE and TR:DIAL for plain TCP; other
;;;; transports (:tor) still go through cl-transport.  SERVE-LINES is a line-per-request
;;;; server (the control socket) that answers as lines arrive instead of parking a thread.

(defpackage #:cl-payments.net-stream
  (:use #:cl)
  (:nicknames #:clp-net)
  (:local-nicknames (#:nl #:cl-consensus.netloop) (#:tgs #:trivial-gray-streams))
  (:export #:conn-stream #:conn-stream-p #:stream-conn #:expose #:dial #:serve-lines))
(in-package #:cl-payments.net-stream)

(defclass conn-stream (tgs:fundamental-binary-input-stream tgs:fundamental-binary-output-stream)
  ((conn :initarg :conn :reader stream-conn)))

(defun conn-stream-p (x) (typep x 'conn-stream))

(defmethod stream-element-type ((s conn-stream)) '(unsigned-byte 8))

(defun %wait-for (c n)
  "Pump until N bytes are buffered on C or it has closed.  The bytes available."
  (loop while (and (< (nl:conn-available c) n) (not (nl:netconn-eof c)))
        do (nl:pump 0.05))
  (nl:conn-available c))

(defmethod tgs:stream-read-byte ((s conn-stream))
  (let ((c (stream-conn s)))
    (if (plusp (%wait-for c 1))
        (aref (nl:conn-read c 1) 0)
        :eof)))

(defmethod tgs:stream-read-sequence ((s conn-stream) seq start end &key)
  "Fill SEQ[START,END), short only at end of stream: CL:READ-SEQUENCE's contract."
  (let* ((c (stream-conn s))
         (end (or end (length seq)))
         (have (min (- end start) (%wait-for c (- end start)))))
    (when (plusp have)
      (replace seq (nl:conn-read c have) :start1 start))
    (+ start have)))

(defmethod tgs:stream-listen ((s conn-stream))
  (plusp (nl:conn-available (stream-conn s))))

(defmethod tgs:stream-write-byte ((s conn-stream) b)
  (nl:conn-write (stream-conn s) (make-array 1 :element-type '(unsigned-byte 8) :initial-element b))
  b)

(defmethod tgs:stream-write-sequence ((s conn-stream) seq start end &key)
  (nl:conn-write (stream-conn s) (subseq seq start (or end (length seq))))
  seq)

(defmethod tgs:stream-force-output ((s conn-stream)) nil)
(defmethod tgs:stream-finish-output ((s conn-stream)) nil)

(defmethod close ((s conn-stream) &key abort)
  (declare (ignore abort))
  (nl:net-close (stream-conn s))
  t)

(defun expose (handler &key (host "127.0.0.1") (port 0))
  "TR:EXPOSE on the net layer: listen on HOST:PORT (0: an ephemeral port) and call HANDLER
   with (stream nil) for each connection, on the thread that pumps, as it arrives.  The
   handler must not block for the connection's life (that thread is the whole node): it
   starts an input-driven reader (P:ACCEPT-ASYNC, P:START-READ-LOOP) and returns, and the
   stream is its to close.  Returns (values closer port-bound)."
  (multiple-value-bind (bound id)
      (nl:net-listen host port (lambda (conn) (funcall handler (make-instance 'conn-stream :conn conn) nil)))
    (values (lambda () (nl:net-unlisten id)) bound)))

(defun dial (host port &key (timeout 10))
  "TR:DIAL on the net layer: (values stream closer)."
  (let* ((conn (nl:net-connect host port :timeout timeout))
         (s (make-instance 'conn-stream :conn conn)))
    (values s (lambda () (close s)))))

(defun %line-end (c)
  "The index of the first newline in C's buffered input, or NIL."
  (loop for i from 0 below (nl:conn-available c)
        when (= (nl:conn-peek c i) 10) return i))

(defun serve-lines (fn &key (host "127.0.0.1") (port 0))
  "A line-per-request server: for each complete line (UTF-8, newline-terminated) a
   connection sends, write (FUNCALL FN line) and a newline back, as the lines arrive, on the
   thread that pumps.  A connection is closed when its peer closes.  Returns (values closer
   port-bound)."
  (multiple-value-bind (bound id)
      (nl:net-listen
       host port
       (lambda (conn)
         (setf (nl:netconn-on-data conn)
               (lambda (c)
                 (loop for end = (%line-end c) while end
                       do (let* ((line (sb-ext:octets-to-string (nl:conn-read c (1+ end))
                                                                :external-format :utf-8 :end end))
                                 (reply (handler-case (funcall fn line)
                                          (error (e) (format nil "(:status :error :message ~s)"
                                                             (princ-to-string e))))))
                            (nl:conn-write c (sb-ext:string-to-octets (format nil "~a~%" reply)
                                                                      :external-format :utf-8))))
                 (when (nl:netconn-eof c)
                   ;; a last line without its newline is still a request
                   (let ((n (nl:conn-available c)))
                     (when (plusp n)
                       (let ((line (sb-ext:octets-to-string (nl:conn-read c n) :external-format :utf-8)))
                         (ignore-errors
                          (nl:conn-write c (sb-ext:string-to-octets (format nil "~a~%" (funcall fn line))
                                                                    :external-format :utf-8))))))
                   (nl:net-close c))))
         (nl:conn-kick conn)))
    (values (lambda () (nl:net-unlisten id)) bound)))
