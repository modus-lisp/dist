;;;; shared/bitcoind/peer.lisp
;;;;
;;;; Phase 1 — a single P2P peer connection: TCP, the version/verack handshake,
;;;; ping/pong keepalive, and a message read loop that dispatches to handlers.
;;;;
;;;; Higher layers register handlers on message commands ("headers", "block", "inv",
;;;; ...) and send requests via SEND.
;;;;
;;;; A DIRECT peer (plain TCP, inbound or outbound) is a connection of the net layer
;;;; (netloop.lisp), on SBCL and on modus alike: it has no thread of its own.  Its input
;;;; is delivered, and its handlers run, on the thread that pumps the net layer -- every
;;;; wait for a peer is a PAUSE-FOR, WAIT-UNTIL or AWAIT-SEMAPHORE, which pump.  Both
;;;; handshakes run as their messages arrive -- outbound START-OUTBOUND-HANDSHAKE (which
;;;; CONNECT-PEER waits for, pumping), inbound ACCEPT-NETCONN -- so a node that dials itself
;;;; on one thread cannot deadlock, and a discovery batch handshakes every dial at once.
;;;;
;;;; An OUTBOUND peer over :TOR or :SOCKS5 -- a .onion one included -- is a net-layer
;;;; connection too: the net thread connects to the SOCKS5 proxy and speaks the SOCKS5
;;;; handshake itself (netloop.lisp), and from then on the peer is like any other.  Which
;;;; proxy: PEER-PROXY.  Only an INBOUND peer over an onion service's rendezvous stream
;;;; (ACCEPT-PEER-STREAM) still has a reader thread: its stream belongs to the thread that
;;;; made it.


(defpackage #:cl-consensus.peer
  (:use #:cl)
  (:nicknames #:btc-peer)
  (:local-nicknames (#:w #:cl-consensus.wire) (#:bt #:bordeaux-threads) (#:tr #:cl-transport)
                    (#:sock #:cl-transport.sockets)
                    (#:onion #:cl-consensus.onion) (#:nl #:cl-consensus.netloop))
  (:export
   #:peer #:peer-addr #:peer-version #:peer-subver #:peer-height
   #:peer-services #:peer-alive-p #:peer-connected-at #:peer-prefers-headers #:peer-wants-addrv2
   #:pause-for #:wait-until #:await-semaphore #:accept-netconn
   #:connect-peer #:start-outbound-handshake #:handshake-status #:peer-handshake-error
   #:start-read-loop #:run-read-loop #:accept-peer #:disconnect #:send #:on #:peer-log #:peer-host #:peer-port
   #:send-getaddr #:parse-addr-payload #:parse-addrv2-payload #:enable-discovery
   #:build-addrv2-message #:onion-addrv2-entry #:announce-address
   #:tor-available-p #:%onion-host-p #:peer-proxy #:*tor-proxy* #:*tor-proxy-hook* #:*tor-isolate*
   #:*default-user-agent* #:*protocol-version* #:*peer-transport* #:*advertised-services* #:peer-closer))

(in-package #:cl-consensus.peer)

(defparameter *protocol-version* 70016)
(defparameter *default-user-agent* "/cl-consensus:0.1/")
(defparameter +max-message-length+ (* 32 1024 1024)
  "Reject P2P messages larger than this before allocating the payload (DoS guard).")

(defparameter *peer-transport* :direct
  "Transport for OUTBOUND peer connections (CONNECT-PEER, discovery's dials): :direct |
   :socks5 | :tor.  :direct is plain TCP; :socks5 goes through the SOCKS5 proxy
   CL-TRANSPORT:*SOCKS-PROXY*; :tor through a SOCKS5 proxy into Tor (*TOR-PROXY*, see
   PEER-PROXY), which hides our IP.  A .onion peer always goes through Tor, a loopback or
   LAN peer always direct.  Inbound (ACCEPT-PEER) is always direct.")

(defvar *tor-proxy* nil
  "Where :TOR dials go: NIL, or (HOST . PORT) of a SOCKS5 proxy into Tor -- a tor daemon's
   SocksPort, or cl-tor's in-process proxy (CL-CONSENSUS.ONION-SERVICE:START-TOR-PROXY sets
   it).  NIL: *TOR-PROXY-HOOK* is asked for one, else CL-TRANSPORT:*SOCKS-PROXY* is used
   (127.0.0.1:9050 by default, Tor's own SocksPort).")

(defvar *tor-proxy-hook* nil
  "NIL, or a function of no arguments returning (HOST . PORT) of a SOCKS5 proxy into Tor,
   asked when *TOR-PROXY* is NIL (on the owner, at the first :TOR dial).  Loading
   cl-consensus/tor sets it to start cl-tor's in-process proxy.")

(defvar *tor-isolate* t
  "When true, every :TOR dial offers the proxy fresh random SOCKS5 credentials, so Tor puts
   each peer on a circuit of its own (IsolateSOCKSAuth, Tor's default; Bitcoin Core's
   -proxyrandomize).  A proxy that does not ask for credentials ignores them.")

(defparameter *advertised-services* (logior w:+services-network+ w:+services-witness+)
  "The service bits we advertise to inbound peers.  A pruned node sets this to
   NODE_NETWORK_LIMITED|NODE_WITNESS (it serves only the last ~288 blocks).")

(defstruct peer
  host port socket stream
  closer                                 ; thunk that tears the connection down (transport-agnostic)
  (lock (bt:make-lock "peer-send"))
  thread
  (handlers (make-hash-table :test 'equal))   ; command string -> function (peer payload-bytes)
  (alive t)
  ;; peer-reported handshake info
  version services subver height
  (connected-at 0)
  (prefers-headers nil)   ; peer sent BIP130 "sendheaders" -> announce blocks via headers
  (wants-addrv2 nil)      ; peer sent BIP155 "sendaddrv2" -> ok to send it addrv2
  (verbose nil)
  ;; the outbound handshake of a net-layer peer (START-OUTBOUND-HANDSHAKE)
  (hs :done) (hs-error nil) (hs-deadline nil))

(defun peer-addr (p) (format nil "~a:~d" (peer-host p) (peer-port p)))
(defun peer-alive-p (p) (peer-alive p))

(defun peer-log (p fmt &rest args)
  (when (peer-verbose p)
    (format t "~&[peer ~a] ~a~%" (peer-addr p) (apply #'format nil fmt args))
    (force-output)))

;;; ----------------------------------------------------------------------------
;;; Low-level socket I/O
;;; ----------------------------------------------------------------------------

(defun read-fully (stream n)
  "Read exactly N bytes or signal end-of-file."
  (when (nl:netconn-p stream) (return-from read-fully (nl:conn-read stream n)))
  (let ((buf (make-array n :element-type '(unsigned-byte 8)))
        (got 0))
    (loop while (< got n) do
      (let ((r (read-sequence buf stream :start got :end n)))
        (when (= r got) (error 'end-of-file :stream stream))
        (setf got r)))
    buf))

(defun read-message (p)
  "Read one framed message off the peer socket.  Returns (values command-string
   payload-bytes), or NIL on clean EOF.  Verifies the magic and checksum."
  (let ((stream (peer-stream p)))
    (let* ((hdr (handler-case (read-fully stream 24)
                  (end-of-file () (return-from read-message nil))))
           (r (w:make-reader hdr))
           (magic (w:r-u32 r)))
      (unless (= magic (w:net-magic w:*network*))
        (error "bad magic ~x from ~a" magic (peer-addr p)))
      (let* ((cmd-bytes (w:r-bytes r 12))
             (command (string-right-trim '(#\Nul)
                                         (map 'string #'code-char cmd-bytes)))
             (len (w:r-u32 r))
             (checksum (w:r-bytes r 4)))
        ;; Cap the payload length before allocating: an attacker-controlled u32 (up to
        ;; 4 GB) would otherwise make-array a giant buffer (DoS).  Largest legit message
        ;; is a block (~4 MB); 32 MB leaves generous headroom.
        (when (> len +max-message-length+)
          (error "oversized ~a message: ~d bytes from ~a" command len (peer-addr p)))
        (let ((payload (if (plusp len) (read-fully stream len)
                           (make-array 0 :element-type '(unsigned-byte 8)))))
          (unless (equalp checksum (w:checksum payload))
            (error "bad checksum on ~a message from ~a" command (peer-addr p)))
          (values command payload))))))

(defun send (p command payload)
  "Frame and send a message.  PAYLOAD is a byte vector (often a writer's bytes)."
  (let ((bytes (w:encode-message command payload)))
    (if (nl:netconn-p (peer-stream p))
        (nl:conn-write (peer-stream p) bytes)   ; one command to the net thread: no lock needed
        (bt:with-lock-held ((peer-lock p))
          (write-sequence bytes (peer-stream p))
          (force-output (peer-stream p))))
    (peer-log p "-> ~a (~d bytes)" command (length payload))
    p))

;;; ----------------------------------------------------------------------------
;;; version message
;;; ----------------------------------------------------------------------------

(defun build-version-payload (&key (services (logior w:+services-witness+))
                                   (start-height 0)
                                   (user-agent *default-user-agent*)
                                   (peer-ip #(0 0 0 0)) (peer-port 0))
  (let ((wr (w:make-writer)))
    (w:w-i32 wr *protocol-version*)
    (w:w-u64 wr services)
    (w:w-i64 wr (- (get-universal-time) 2208988800)) ; CL epoch 1900 -> unix epoch
    ;; addr_recv (the peer), no time field in version
    (w:w-netaddr wr services peer-ip peer-port)
    ;; addr_from (us) — zeros are fine
    (w:w-netaddr wr services #(0 0 0 0) 0)
    (w:w-u64 wr (logand (get-internal-real-time) #xffffffffffffffff)) ; nonce
    (w:w-varstr wr user-agent)
    (w:w-i32 wr start-height)
    (w:w-bool wr nil)              ; relay=false: don't flood us with mempool txs yet
    (w:writer-bytes wr)))

(defun parse-version-payload (payload)
  "Pull the fields we care about out of a peer's version message."
  (let ((r (w:make-reader payload)))
    (let ((version (w:r-i32 r))
          (services (w:r-u64 r)))
      (w:r-i64 r)                  ; timestamp
      ;; addr_recv: services(8) ip(16) port(2)
      (w:r-bytes r 26)
      ;; addr_from
      (w:r-bytes r 26)
      (w:r-u64 r)                  ; nonce
      (let ((subver (w:r-varstr r))
            (height (w:r-i32 r)))
        (values version services subver height)))))

;;; ----------------------------------------------------------------------------
;;; handler registry + read loop
;;; ----------------------------------------------------------------------------

(defun on (p command fn)
  "Register FN (peer payload-bytes) as the handler for COMMAND."
  (setf (gethash command (peer-handlers p)) fn)
  p)

(defun dispatch (p command payload)
  (let ((fn (gethash command (peer-handlers p))))
    (when fn
      (handler-case (funcall fn p payload)
        (serious-condition (c)
          (format t "~&[peer ~a] handler ~a error: ~a~%" (peer-addr p) command c)
          (force-output))))))

(defun handle-builtin (p command payload)
  "Protocol housekeeping common to every node: pings and sendheaders/feefilter
   noise.  Returns T if fully handled here."
  (cond
    ((string= command "ping")
     (send p "pong" payload) t)          ; echo the nonce
    ((string= command "sendheaders")
     (setf (peer-prefers-headers p) t) t) ; BIP130: announce new blocks via headers
    ((string= command "sendaddrv2")
     (setf (peer-wants-addrv2 p) t) t)    ; BIP155 (belt-and-suspenders if it arrives late)
    ((member command '("alert" "feefilter" "sendcmpct" "wtxidrelay")
             :test #'string=)
     t)                                   ; ignore for now
    ;; NOTE: "addr"/"addrv2"/"getheaders"/"getdata" are intentionally NOT swallowed
    ;; here — they dispatch to a registered handler (peer discovery; serving headers/
    ;; blocks).  With no handler installed DISPATCH simply no-ops, so this stays safe
    ;; by default (a pure leech ignores them; the serving daemon installs handlers).
    (t nil)))

(defun pause-for (seconds)
  "Wait SECONDS.  Use this, not SLEEP, while waiting for a peer: it is what delivers the
   peer's messages (and runs their handlers) meanwhile.  See netloop.lisp."
  (nl:pause-for seconds))

(defun wait-until (predicate &key (timeout 5) (step 0.05))
  "Call PREDICATE until it is true or TIMEOUT seconds pass (pausing STEP between tries,
   see PAUSE-FOR); its last value."
  (nl:wait-until predicate :timeout timeout :step step))

(defun await-semaphore (semaphore &key timeout)
  "BT:WAIT-ON-SEMAPHORE for a semaphore a PEER HANDLER signals.  The handler runs while
   some thread pumps the net layer -- possibly only this one -- so a plain wait could
   block the very reply it is waiting for: this polls the semaphore and pumps in between.
   T if it was signalled."
  ;; A millisecond, not 0: SBCL (2.2.9) rejects a zero timeout, and modus has no
  ;; SB-THREAD:TRY-SEMAPHORE.
  (and (nl:wait-until (lambda () (bt:wait-on-semaphore semaphore :timeout 0.001))
                      :timeout (or timeout most-positive-fixnum) :step 0.01)
       t))

;;; A net-layer peer has no read loop: its connection's ON-DATA runs, on the pumping
;;; thread, whenever input arrives, and dispatches every complete message buffered by then.
(defun %frame-ready-p (c)
  (and (>= (nl:conn-available c) 24)
       (>= (nl:conn-available c) (+ 24 (nl:conn-peek-u32 c 16)))))

(defun %drain (p)
  "Dispatch every complete message buffered on P's connection, as READ-LOOP would."
  (let ((c (peer-stream p)))
    (handler-case
        (loop while (and (peer-alive p) (%frame-ready-p c)) do
          (multiple-value-bind (command payload) (read-message p)
            (peer-log p "<- ~a (~d bytes)" command (length payload))
            (unless (handle-builtin p command payload)
              (dispatch p command payload))))
      (serious-condition (e)
        (when (peer-alive p)
          (format t "~&[peer ~a] read loop ended: ~a~%" (peer-addr p) e) (force-output))
        (setf (peer-alive p) nil)
        (nl:net-close c)))
    (when (and (nl:netconn-eof c) (not (%frame-ready-p c)))
      (setf (peer-alive p) nil)
      (nl:net-close c))))

(defun read-loop (p)
  (handler-case
      (loop while (peer-alive p) do
        ;; An idle read past the socket timeout must NOT kill the loop: during
        ;; IBD the consumer can pause requesting (backpressure) for a while, so a
        ;; P2P read loop blocks indefinitely for the next message and just retries
        ;; on a timeout.  (The stream's input timeout is also cleared at connect.)
        (block one
          (handler-case
              (multiple-value-bind (command payload) (read-message p)
                (unless command (return))    ; clean EOF
                (peer-log p "<- ~a (~d bytes)" command (length payload))
                (unless (handle-builtin p command payload)
                  (dispatch p command payload)))
            (#+sbcl sb-sys:io-timeout #-sbcl error () (return-from one))
            #+sbcl (sb-sys:deadline-timeout () (return-from one)))))
    (serious-condition (c)
      (when (peer-alive p)
        (format t "~&[peer ~a] read loop ended: ~a~%" (peer-addr p) c)
        (force-output))))
  (setf (peer-alive p) nil))

;;; ----------------------------------------------------------------------------
;;; connect + handshake
;;; ----------------------------------------------------------------------------

(defun start-read-loop (p)
  "Start delivering P's messages to its handlers; return P.  A net-layer peer: from now
   on, as they arrive (while some thread pumps).  A stream peer: clear the connect-time
   input timeout and spawn its read thread -- call this from a LONG-LIVED thread then: in
   SBCL a read loop spawned inside an ephemeral worker thread dies when that worker exits,
   so a parallel dialer must dial with :DEFER-LOOP and hand the peers here from its
   (long-lived) collector."
  (when (nl:netconn-p (peer-stream p))
    (setf (nl:netconn-on-data (peer-stream p)) (lambda (c) (declare (ignore c)) (%drain p)))
    (nl:conn-kick (peer-stream p))        ; anything that arrived with the handshake
    (return-from start-read-loop p))
  ;; the dialled stream may carry an INPUT timeout (from the connect :timeout); clear it
  ;; so the steady-state read loop blocks indefinitely for the next message instead of
  ;; dying on an idle gap (e.g. while IBD is backpressured).
  #+sbcl (ignore-errors (setf (sb-impl::fd-stream-timeout (peer-stream p)) nil))
  (setf (peer-thread p)
        (bt:make-thread (lambda () (read-loop p))
                        :name (format nil "btc-peer ~a" (peer-addr p))))
  p)

(defun run-read-loop (p)
  "Clear the input timeout and run P's read loop IN THE CURRENT THREAD (blocks until
   the peer closes).  Parallel dialers use this so the dialing thread BECOMES the
   peer's long-lived owner: a socket opened in a thread that then exits is torn down
   with it, so the connecting thread must live as long as the connection.  A net-layer
   peer: deliver its messages and pump until it is gone."
  (when (nl:netconn-p (peer-stream p))
    (start-read-loop p)
    (loop while (peer-alive p) do (pause-for 0.25))
    (return-from run-read-loop nil))
  #+sbcl (ignore-errors (setf (sb-impl::fd-stream-timeout (peer-stream p)) nil))
  (setf (peer-thread p) (bt:current-thread))
  (read-loop p))

(defun %prefix-p (prefix s)
  (and (stringp s) (>= (length s) (length prefix))
       (string= prefix s :end2 (length prefix))))

(defun %suffix-p (suffix s)
  (and (stringp s) (>= (length s) (length suffix))
       (string= suffix s :start2 (- (length s) (length suffix)))))

(defun %private-host-p (host)
  "True for loopback / RFC1918 / .lan / .local hosts — not reachable via a Tor exit,
   so they always dial :DIRECT even when *PEER-TRANSPORT* is :TOR/:SOCKS5."
  (and (stringp host)
       (or (string= host "localhost")
           (%suffix-p ".lan" host) (%suffix-p ".local" host)
           (%prefix-p "10." host) (%prefix-p "127." host) (%prefix-p "192.168." host)
           (loop for b from 16 to 31 thereis (%prefix-p (format nil "172.~d." b) host)))))

(defun %onion-host-p (host)
  "True for a v3 .onion address — only reachable end-to-end via the onion-service
   client, so these ALWAYS dial :TOR regardless of *PEER-TRANSPORT*."
  (onion:onion-valid-p host))

(defun tor-available-p ()
  "T if this node has been told it can reach Tor: *TOR-PROXY* or *TOR-PROXY-HOOK* is set,
   or cl-tor-transport is loaded (cl-transport has a :tor backend).  Callers gate .onion
   dialing on this so the core node stays usable without Tor."
  (and (or *tor-proxy* *tor-proxy-hook* (tr:transport-available-p :tor)) t))

(defun %tor-proxy ()
  (or *tor-proxy*
      (and *tor-proxy-hook* (setf *tor-proxy* (funcall *tor-proxy-hook*)))
      tr:*socks-proxy*))

(defun peer-proxy (host &optional (transport *peer-transport*))
  "How an outbound dial of HOST goes: NIL for plain TCP, else the SOCKS5 proxy, a list
   (PROXY-HOST PROXY-PORT USER PASSWORD) for NETLOOP:NET-CONNECT-START.  A .onion HOST goes
   through Tor whatever TRANSPORT is; a loopback or LAN HOST goes direct (a Tor exit cannot
   reach it)."
  (cond ((%onion-host-p host) (setf transport :tor))
        ((%private-host-p host) (setf transport :direct)))
  (ecase transport
    (:direct nil)
    (:socks5 (let ((pr tr:*socks-proxy*)) (list (car pr) (cdr pr) nil nil)))
    (:tor (let ((pr (%tor-proxy)))
            (if *tor-isolate*
                (list (car pr) (cdr pr) (format nil "cl-consensus-~a" (%random-hex)) (%random-hex))
                (list (car pr) (cdr pr) nil nil))))))

(defun %random-hex ()
  ;; 64 bits, 16 at a time: modus's RANDOM of a bignum limit answers below 2^30
  (format nil "~{~4,'0x~}" (loop repeat 4 collect (random 65536))))

(defun connect-peer (host &key (port (w:net-port w:*network*))
                               (start-height 0) (verbose nil)
                               (timeout 15) (defer-loop nil)
                               (transport *peer-transport*))
  "Open a connection to HOST:PORT over TRANSPORT (default *PEER-TRANSPORT*; see PEER-PROXY)
   and complete the version/verack handshake, pumping meanwhile.  Returns a live PEER whose
   messages reach its handlers, or signals on failure.  With :DEFER-LOOP the handshake
   completes but dispatch does not start until START-READ-LOOP."
  ;; a net-layer connection -- straight to HOST, or through a SOCKS5 proxy (PEER-PROXY):
  ;; the handshake runs as input arrives (START-OUTBOUND-HANDSHAKE), and this waits for it,
  ;; pumping
  (let* ((c (nl:net-connect host port :timeout timeout :proxy (peer-proxy host transport)))
         (p (start-outbound-handshake c :start-height start-height :verbose verbose
                                        :timeout timeout)))
    (nl:pump-until (lambda () (not (eq (handshake-status p) :pending))) :timeout (+ timeout 1))
    (unless (eq (handshake-status p) :done)
      (%handshake-failed p "handshake timed out")
      (error "~a" (or (peer-hs-error p) "handshake failed")))
    (if defer-loop p (start-read-loop p))))

(defun peer-handshake-error (p) (peer-hs-error p))

(defun %handshake-failed (p why)
  (when (eq (peer-hs p) :pending)
    (setf (peer-hs p) :failed (peer-hs-error p) why (peer-alive p) nil)
    (ignore-errors (funcall (peer-closer p)))))

(defun start-outbound-handshake (conn &key (start-height 0) (verbose nil) (timeout 15))
  "Begin the OUTBOUND version/verack handshake on CONN, an open net-layer connection, and
   return its PEER at once.  The handshake runs as messages arrive (whoever pumps runs it),
   so many can be in flight together; HANDSHAKE-STATUS says how it stands -- :PENDING,
   :DONE, or :FAILED (PEER-HANDSHAKE-ERROR says why) -- and fails it once TIMEOUT seconds
   have passed.  A :DONE peer has no read loop yet: START-READ-LOOP."
  (let* ((p (make-peer :host (nl:netconn-host conn) :port (nl:netconn-port conn)
                       :stream conn :closer (lambda () (nl:net-close conn))
                       :verbose verbose :connected-at (get-universal-time)
                       :hs :pending
                       :hs-deadline (+ (get-internal-real-time)
                                       (round (* timeout internal-time-units-per-second)))))
         (got-version nil) (got-verack nil))
    (setf (nl:netconn-on-data conn)
          (lambda (c)
            (handler-case
                (progn
                  (loop while (and (eq (peer-hs p) :pending) (not (and got-version got-verack))
                                   (%frame-ready-p c))
                        do (multiple-value-bind (command payload) (read-message p)
                             (peer-log p "<- ~a (~d bytes)" command (length payload))
                             (cond
                               ((string= command "version")
                                (multiple-value-bind (v s sv h) (parse-version-payload payload)
                                  (setf (peer-version p) v (peer-services p) s
                                        (peer-subver p) sv (peer-height p) h))
                                (setf got-version t)
                                ;; BIP155: we understand addrv2 (must precede verack); then ack
                                (send p "sendaddrv2" #())
                                (send p "verack" #()))
                               ((string= command "verack") (setf got-verack t))
                               ((string= command "sendaddrv2") (setf (peer-wants-addrv2 p) t))
                               (t nil))))      ; wtxidrelay and the like
                  (cond ((and got-version got-verack (eq (peer-hs p) :pending))
                         ;; what follows waits in the buffer for START-READ-LOOP
                         (setf (nl:netconn-on-data c) nil
                               (peer-hs p) :done))
                        ((and (nl:netconn-eof c) (not (%frame-ready-p c)))
                         (%handshake-failed p (format nil "peer ~a closed during handshake"
                                                      (peer-addr p))))))
              (serious-condition (e) (%handshake-failed p (princ-to-string e))))))
    (send p "version" (build-version-payload :start-height start-height))
    (nl:conn-kick conn)
    p))

(defun handshake-status (p)
  ":PENDING, :DONE or :FAILED: how P's outbound handshake stands (past its deadline,
   a pending one fails now)."
  (when (and (eq (peer-hs p) :pending) (peer-hs-deadline p)
             (> (get-internal-real-time) (peer-hs-deadline p)))
    (%handshake-failed p (format nil "handshake with ~a timed out" (peer-addr p))))
  (peer-hs p))

(defun %inbound-addr (socket)
  "Best-effort dotted IP of an accepted SOCKET's remote end (for logging)."
  (or (ignore-errors (sock:tcp-peer socket)) "inbound"))

(defun accept-peer (socket &key (services *advertised-services*)
                                (start-height 0) (verbose nil))
  "Wrap an ACCEPTED inbound TCP SOCKET (a cl-transport.sockets TCP-SOCKET, from
   TCP-ACCEPT) as a live peer: complete the version/verack
   handshake in INBOUND order (read THEIR version first, then send ours advertising
   SERVICES + verack), clear the read timeout, and spawn the read loop.  Returns the
   live peer, or signals on a bad/!aborted handshake (caller closes the socket)."
  (let* ((stream (sock:tcp-socket-stream socket))
         (p (make-peer :host (%inbound-addr socket)
                       :port (or (ignore-errors (nth-value 1 (sock:tcp-peer socket))) 0)
                       :socket socket :stream stream :verbose verbose
                       :connected-at (get-universal-time))))
    (%inbound-handshake p services start-height)
    #+sbcl (ignore-errors (setf (sb-impl::fd-stream-timeout (peer-stream p)) nil))
    (%start-inbound-loop p)))

(defun %inbound-handshake (p services start-height)
  "Complete the INBOUND version/verack handshake on peer P: read THEIRS first, then
   send OURS advertising SERVICES + verack.  Shared by socket and stream inbound."
  (let ((got-version nil) (got-verack nil))
    (loop until (and got-version got-verack) do
      (multiple-value-bind (command payload) (read-message p)
        (unless command (error "inbound peer ~a closed during handshake" (peer-addr p)))
        (peer-log p "<- ~a (~d bytes)" command (length payload))
        (cond
          ((string= command "version")
           (multiple-value-bind (v s sv h) (parse-version-payload payload)
             (setf (peer-version p) v (peer-services p) s
                   (peer-subver p) sv (peer-height p) h))
           (setf got-version t)
           (send p "version" (build-version-payload :services services :start-height start-height))
           (send p "sendaddrv2" #())     ; BIP155: we speak addrv2 (so inbound peers gossip Tor v3)
           (send p "verack" #()))
          ((string= command "verack") (setf got-verack t))
          ((string= command "sendaddrv2") (setf (peer-wants-addrv2 p) t))
          (t nil)))))                  ; ignore wtxidrelay/etc. during handshake
  p)

(defun accept-netconn (conn on-ready &key (services *advertised-services*)
                                          (start-height 0) (verbose nil) host)
  "ACCEPT-PEER for an inbound net-layer connection CONN (see NETLOOP:NET-LISTEN), driven
   by input rather than by a blocking read: the thread that pumps may itself be the peer
   on the far end (a loopback dial in progress), so it must not wait here.  The INBOUND
   handshake runs as messages arrive; once both version and verack are in, ON-READY is
   called with the live peer and the connection switches to ordinary dispatch.  Returns
   the peer (not yet live).  HOST names the peer (default: the connection's remote address)."
  (let* ((p (make-peer :host (or host (nl:netconn-host conn)) :port (nl:netconn-port conn)
                       :stream conn :closer (lambda () (nl:net-close conn))
                       :verbose verbose :connected-at (get-universal-time)))
         (got-version nil) (got-verack nil))
    (setf (nl:netconn-on-data conn)
          (lambda (c)
            (handler-case
                (progn
                  (loop while (and (not (and got-version got-verack)) (%frame-ready-p c)) do
                    (multiple-value-bind (command payload) (read-message p)
                      (peer-log p "<- ~a (~d bytes)" command (length payload))
                      (cond
                        ((string= command "version")
                         (multiple-value-bind (v s sv h) (parse-version-payload payload)
                           (setf (peer-version p) v (peer-services p) s
                                 (peer-subver p) sv (peer-height p) h))
                         (setf got-version t)
                         (send p "version" (build-version-payload :services services
                                                                  :start-height start-height))
                         (send p "sendaddrv2" #())
                         (send p "verack" #()))
                        ((string= command "verack") (setf got-verack t))
                        ((string= command "sendaddrv2") (setf (peer-wants-addrv2 p) t))
                        (t nil))))
                  (cond ((and got-version got-verack)
                         (setf (nl:netconn-on-data c) (lambda (c) (declare (ignore c)) (%drain p)))
                         (funcall on-ready p)
                         (%drain p))
                        ((nl:netconn-eof c)
                         (setf (peer-alive p) nil)
                         (nl:net-close c))))
              (serious-condition (e)
                (format t "~&[peer ~a] inbound handshake failed: ~a~%" (peer-addr p) e)
                (force-output)
                (setf (peer-alive p) nil)
                (nl:net-close c)))))
    p))

(defun %start-inbound-loop (p)
  (setf (peer-thread p)
        (bt:make-thread (lambda () (read-loop p))
                        :name (format nil "btc-inbound ~a" (peer-addr p))))
  p)

(defun disconnect (p)
  (setf (peer-alive p) nil)
  ;; tear down via the transport closer (outbound: direct/socks5/tor), else the raw
  ;; socket (inbound peers from ACCEPT-PEER have no closer).
  ;; An inbound peer's socket is SHUT DOWN first, which wakes the read-loop parked in a
  ;; blocking read (closing a descriptor does not, and on SBCL closing a stream another
  ;; thread is reading races), then closed once that thread is out of it.
  (if (peer-closer p)
      (ignore-errors (funcall (peer-closer p)))
      (when (peer-socket p) (sock:tcp-shutdown (peer-socket p))))
  ;; Join with a bounded timeout and move on rather than hang forever (an outbound
  ;; transport's closer may not wake the read).  A leftover thread dies when its read
  ;; finally errors / at exit.
  (when (and (peer-thread p) (bt:thread-alive-p (peer-thread p))
             (not (eq (peer-thread p) (bt:current-thread))))
    (ignore-errors (sb-thread:join-thread (peer-thread p) :timeout 3 :default nil)))
  (when (and (null (peer-closer p)) (peer-socket p))
    (sock:tcp-close (peer-socket p) :abort t))
  p)

;;; ----------------------------------------------------------------------------
;;; Peer discovery: ask a peer for its known addresses (getaddr -> addr/addrv2).
;;; ----------------------------------------------------------------------------

(defun send-getaddr (p) (send p "getaddr" #()))

(defun parse-addr-payload (payload)
  "addr message: varint count + entries[time u32, services u64, ip16, port u16BE].
   Returns a list of (host . port) for the IPv4 entries (others skipped)."
  (let ((r (w:make-reader payload)) (out '()))
    (let ((n (w:r-varint r)))
      (dotimes (i n)
        (let ((a (w:r-netaddr r :with-time t))) (when a (push a out)))))
    out))

(defun parse-addrv2-payload (payload)
  "addrv2 (BIP155): varint count + entries[time u32, services varint, netID u8,
   addrlen varint, addr, port u16BE].  Returns (host . port) for IPv4 (netID 1)."
  (let ((r (w:make-reader payload)) (out '()))
    (let ((n (w:r-varint r)))
      (dotimes (i n)
        (w:r-u32 r)                      ; time
        (w:r-varint r)                   ; services
        (let* ((netid (w:r-u8 r)) (len (w:r-varint r))
               (addr (w:r-bytes r len)) (port (w:r-port-be r)))
          (when (and (= netid 1) (= len 4))   ; IPV4
            (push (cons (format nil "~d.~d.~d.~d"
                                (aref addr 0) (aref addr 1) (aref addr 2) (aref addr 3))
                        port)
                  out)))))
    out))

(defun enable-discovery (p sink &optional onion-sink)
  "Register addr/addrv2 handlers on P that feed parsed (host . port) pairs to
   SINK (a function of one (host . port)), and send getaddr.  SINK is typically
   ADDRMAN-ADD bound to the process address pool.  With ONION-SINK, Tor v3
   (.onion-address . port) entries from addrv2 gossip are fed to it as well."
  (on p "addr"   (lambda (pr payload) (declare (ignore pr))
                   (dolist (hp (parse-addr-payload payload)) (funcall sink hp))))
  (on p "addrv2" (lambda (pr payload) (declare (ignore pr))
                   (dolist (hp (parse-addrv2-payload payload)) (funcall sink hp))
                   (when onion-sink
                     (dolist (op (onion:parse-addrv2-onions payload)) (funcall onion-sink op)))))
  (send-getaddr p)
  p)

;;; ----------------------------------------------------------------------------
;;; Self-advertisement: announce our OWN address (BIP155 addrv2) so peers relay it.
;;; ----------------------------------------------------------------------------

(defconstant +netid-tor-v3+ 4 "BIP155 network id for Tor v3 (.onion).")

(defun build-addrv2-message (entries)
  "Encode an addrv2 (BIP155) message from ENTRIES, each (services netid addr port):
   varint(count) then per entry u32(time) varint(services) u8(netid) varint(len) addr u16BE(port)."
  (let ((wr (w:make-writer)) (now (- (get-universal-time) 2208988800)))   ; CL epoch -> unix
    (w:w-varint wr (length entries))
    (dolist (e entries (w:writer-bytes wr))
      (destructuring-bind (services netid addr port) e
        (w:w-u32 wr now) (w:w-varint wr services) (w:w-u8 wr netid)
        (w:w-varint wr (length addr)) (w:w-bytes wr addr) (w:w-port-be wr port)))))

(defun onion-addrv2-entry (onion port &optional
                                       (services *advertised-services*))
  "An addrv2 entry advertising ONION:PORT (Tor v3: netID 4, 32-byte Ed25519 pubkey)."
  (list services +netid-tor-v3+ (onion:onion->pubkey onion) port))

(defun announce-address (p entries)
  "Send an addrv2 message advertising ENTRIES to peer P (best-effort)."
  (ignore-errors (send p "addrv2" (build-addrv2-message entries))))
