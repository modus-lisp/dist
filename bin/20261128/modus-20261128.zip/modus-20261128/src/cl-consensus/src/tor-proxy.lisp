;;;; src/tor-proxy.lisp -- cl-tor's SOCKS5 proxy, in this process, as the node's way into Tor.
;;;;
;;;; Part of the optional cl-consensus/tor system.  An outbound :TOR peer (and every .onion
;;;; peer) is dialled by the net thread through a SOCKS5 proxy into Tor (PEER:PEER-PROXY,
;;;; netloop.lisp): a tor daemon's SocksPort when PEER:*TOR-PROXY* names one, else this --
;;;; cl-tor's own proxy (CL-TOR.SOCKS:RUN-PROXY), started on 127.0.0.1 at an ephemeral port
;;;; the first time a :TOR dial asks (PEER:*TOR-PROXY-HOOK*), or by START-TOR-PROXY.
;;;;
;;;; The shape is the one cl-tor documents for modus, on both Lisps: the proxy's accept loop
;;;; (and each of its connections) runs on a thread of its own, started on a NAMED function
;;;; with channels as :ARGUMENTS; the DIRECTORY -- consensus, guards -- belongs to the owner,
;;;; which answers the connections' path requests from an owner task.  (A thread that is not
;;;; main on modus has a 16 MB heap, which the consensus does not fit.)  Fetching the
;;;; consensus is the one slow step and it happens on the owner: at the first circuit, or at
;;;; START-TOR-PROXY with :PRELOAD T, which is the place to pay it (at startup).

(defpackage #:cl-consensus.tor-proxy
  (:use #:cl)
  (:local-nicknames (#:tsocks #:cl-tor.socks) (#:dsvc #:cl-tor.dirsvc) (#:bob #:bobbin)
                    (#:p #:cl-consensus.peer) (#:nl #:cl-consensus.netloop))
  (:export #:start-tor-proxy #:stop-tor-proxy #:tor-proxy-port))

(in-package #:cl-consensus.tor-proxy)

(defvar *proxy* nil "(thread stop-channel port directory) of the running proxy, or NIL.")

(defun tor-proxy-port () (third *proxy*))

(defun %proxy-main (requests replies free port-chan stop-chan max-connections)
  "The proxy thread: cl-tor's accept loop on 127.0.0.1 at an ephemeral port, its directory
   served by the owner (REQUESTS / REPLIES, FREE slots); the port goes back on PORT-CHAN; it
   stops at the first message on STOP-CHAN."
  (handler-case
      (tsocks:run-proxy :host "127.0.0.1" :port 0 :max-connections max-connections
                        :directory (dsvc:%make-directory requests replies free)
                        :on-listening (lambda (port) (bob:channel-send port-chan port :timeout 5))
                        :stop-p (lambda () (nth-value 1 (bob:channel-try-receive stop-chan))))
    (serious-condition (e)
      (bob:channel-send port-chan (princ-to-string e) :timeout 5)))
  nil)

(defun start-tor-proxy (&key (max-connections 8) preload)
  "Start cl-tor's SOCKS5 proxy in this process (once) and make it where :TOR dials go
   (PEER:*TOR-PROXY*); returns (\"127.0.0.1\" . port).  Call it on the owner.  PRELOAD
   fetches the consensus now (on this thread, the owner, which then waits) rather than at
   the first circuit."
  (unless *proxy*
    (nl:start-net)                        ; this thread is the owner: it serves the directory
    (let* ((dir (dsvc:make-directory :slots max-connections))
           (port-chan (bob:make-channel :capacity 4096))
           (stop-chan (bob:make-channel :capacity 4096))
           (th (sb-thread:make-thread
                '%proxy-main :name "cl-tor socks"
                :arguments (list (dsvc:directory-requests dir)
                                 (coerce (dsvc:directory-replies dir) 'list)
                                 (dsvc:directory-free dir)
                                 port-chan stop-chan max-connections))))
      (multiple-value-bind (port ok) (bob:channel-receive port-chan :timeout 30)
        (unless (and ok (integerp port))
          (ignore-errors (bob:channel-send stop-chan :stop :timeout 1))
          (error "cl-tor's SOCKS5 proxy did not start: ~a" (if ok port "no answer")))
        (when preload (dsvc:load-directory))
        (nl:add-owner-task 'tor-directory (lambda () (dsvc:serve-directory-requests dir))
                           :interval 0.05)
        (setf *proxy* (list th stop-chan port dir)))))
  (setf p:*tor-proxy* (cons "127.0.0.1" (third *proxy*))))

(defun stop-tor-proxy ()
  "Stop the proxy START-TOR-PROXY started (its listener closes; connections in flight end
   when their peers do).  :TOR dials go to PEER:*TOR-PROXY-HOOK*'s next proxy after this."
  (let ((pr *proxy*))
    (when pr
      (setf *proxy* nil)
      (nl:remove-owner-task 'tor-directory)
      (bob:channel-send (second pr) :stop :timeout 1)
      (ignore-errors (sb-thread:join-thread (first pr) :timeout 10 :default nil))
      (when (and (consp p:*tor-proxy*) (eql (cdr p:*tor-proxy*) (third pr)))
        (setf p:*tor-proxy* nil))))
  nil)

;; A :TOR dial with no PEER:*TOR-PROXY* starts this proxy.
(setf p:*tor-proxy-hook* (lambda () (start-tor-proxy)))
