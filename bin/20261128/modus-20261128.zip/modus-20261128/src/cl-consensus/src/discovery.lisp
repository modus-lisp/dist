;;;; src/discovery.lisp
;;;;
;;;; Peer discovery: bootstrap the address pool from DNS seeds and/or a known
;;;; peer's getaddr reply, then dial N live connections for parallel IBD download.
;;;;
;;;; PARALLEL DIALING WITHOUT THREADS.  Most gossiped addresses are dead, so dials go out in
;;;; batches: a DIAL-BATCH starts a non-blocking connect to every candidate at once (the net
;;;; thread holds them all in flight, each with its own deadline -- netloop.lisp), starts the
;;;; version handshake on each that connects (input-driven, so all of them at once too), and
;;;; DIAL-BATCH-STEP looks at how they stand, never waiting.  A DIAL-POOL runs batches from
;;;; the address pool until it has N peers.  Everything runs on the thread that pumps the
;;;; net layer -- the owner on modus, where a thread may not store what it makes where
;;;; another can reach it -- either inside a wait (CONNECT-PARALLEL, CONNECT-N-PARALLEL) or a
;;;; step at a time (the node's peer manager, an owner task).
;;;;
;;;; Every transport dials this way.  Over :TOR or :SOCKS5 (and for a .onion candidate) the
;;;; net thread connects to the SOCKS5 proxy and does the SOCKS5 handshake itself (P:PEER-PROXY
;;;; says which proxy), so a Tor dial is in flight beside the others like a clearnet one.

(eval-when (:compile-toplevel :load-toplevel :execute)
  (require :sb-bsd-sockets))             ; libc resolver (usocket's hung here)

(defpackage #:cl-consensus.discovery
  (:use #:cl)
  (:nicknames #:btc-discovery)
  (:local-nicknames (#:p #:cl-consensus.peer) (#:am #:cl-consensus.addrman) (#:w #:cl-consensus.wire)
                    (#:nl #:cl-consensus.netloop)
                    (#:bt #:bordeaux-threads))
  (:export #:*dns-seeds* #:seed-from-dns #:try-connect #:connect-n
           #:make-peer-source #:discover-peers
           #:connect-parallel #:connect-n-parallel #:discover-peers-parallel
           #:dial-batch #:start-dial-batch #:dial-batch-step #:dial-batch-live #:dial-batch-abort
           #:dial-pool #:make-dial-pool #:dial-pool-step #:dial-pool-live #:dial-pool-abort #:dial-pool-stop
           #:dial-pool-attempts
           #:start-dns-seeding #:finish-dns-seeding))

(in-package #:cl-consensus.discovery)

(defparameter *dns-seeds*
  '("seed.bitcoin.sipa.be" "dnsseed.bluematt.me" "seed.bitcoinstats.com"
    "seed.bitcoin.jonasschnelli.ch" "seed.btc.petertodd.net" "seed.bitcoin.wiz.biz"
    "dnsseed.emzy.de" "seed.bitcoin.sprovoost.nl")
  "Mainnet DNS seeds — each resolves to many full-node A records.")

(defun %resolve-a (host)
  "Resolve HOST to a list of IPv4 dotted-quad strings via the libc resolver,
   bounded by a per-host timeout so one dead seed can't stall startup."
  (handler-case
      (sb-ext:with-timeout 8
        (loop for a in (sb-bsd-sockets:host-ent-addresses (sb-bsd-sockets:get-host-by-name host))
              when (and (vectorp a) (= (length a) 4))
                collect (format nil "~d.~d.~d.~d" (aref a 0) (aref a 1) (aref a 2) (aref a 3))))
    (serious-condition () nil)))         ; NXDOMAIN / timeout / no A records

(defun %resolve-hosts (hosts)
  "The IPv4 addresses (dotted-quad strings) HOSTS resolve to.  Plain data in, plain data
   out: a thread runs it (START-DNS-SEEDING)."
  (loop for h in hosts append (%resolve-a h)))

(defun start-dns-seeding (&optional (hosts *dns-seeds*))
  "Resolve HOSTS on a thread of its own, so the owner need not block on the resolver: a
   handle for FINISH-DNS-SEEDING, or NIL when there is nothing to resolve.  The thread runs
   a named function on a list of strings and returns a list of strings."
  (when hosts
    (sb-thread:make-thread '%resolve-hosts :name "btc-dns-seed" :arguments (list (copy-list hosts)))))

(defun finish-dns-seeding (handle &optional (am am:*addrman*) (port (w:net-port w:*network*)))
  "NIL while HANDLE's resolver still runs; then the count of addresses it added to AM."
  (cond ((null handle) 0)
        ((sb-thread:thread-alive-p handle) nil)
        (t (let ((ips (ignore-errors (sb-thread:join-thread handle :default nil))) (added 0))
             (dolist (ip ips added)
               (when (am:addrman-add am ip port) (incf added)))))))

(defun seed-from-dns (&optional (am am:*addrman*) (port (w:net-port w:*network*)))
  "Resolve each DNS seed to its A records and add (ip . PORT) to AM.  Returns the
   count of newly-added addresses."
  (let ((added 0))
    (dolist (host *dns-seeds* added)
      (dolist (ip (%resolve-a host))
        (when (am:addrman-add am ip port) (incf added))))))

(defun try-connect (host port &key (start-height 0) (timeout 8) (require-network t) (min-height 0)
                                   (defer-loop nil))
  "Dial one address; return a live peer, or NIL on failure / wrong services / too
   far behind.  IBD of historical blocks needs NODE_NETWORK (full, unpruned)
   peers — pruned nodes can't serve old blocks — and the peer must itself be
   synced past the heights we want (MIN-HEIGHT), else it can't serve them.  With
   :DEFER-LOOP the returned peer's read loop is not started (the caller must call
   P:START-READ-LOOP from a long-lived thread) — required when dialing in workers."
  (handler-case
      (let ((peer (p:connect-peer host :port port :start-height start-height :timeout timeout
                                  :defer-loop defer-loop)))
        (cond
          ((and require-network (not (logtest (p:peer-services peer) w:+services-network+)))
           (p:disconnect peer) nil)       ; pruned / non-archive: can't serve history
          ((< (or (p:peer-height peer) 0) min-height)
           (p:disconnect peer) nil)       ; peer itself not synced past our target
          (t (format t "~&[discovery] +peer ~a:~d h~a ~a~%"
                     host port (p:peer-height peer) (p:peer-subver peer)) (force-output)
             peer)))
    (serious-condition () nil)))           ; unreachable / handshake failed

(defun connect-n (n &key (am am:*addrman*) (start-height 0) (timeout 8)
                         (max-attempts (* 12 n)) (require-network t) (min-height 0))
  "Dial up to N untried NODE_NETWORK addresses from AM; return the live peers.
   Bounded by MAX-ATTEMPTS so a run of pruned/dead addresses can't loop forever."
  (let ((peers '()) (attempts 0))
    (loop while (and (< (length peers) n) (< attempts max-attempts)) do
      (let ((cands (am:addrman-take am (max 1 (- n (length peers))))))
        (when (null cands) (return))
        (dolist (hp cands)
          (when (>= (length peers) n) (return))
          (incf attempts)
          (let ((peer (try-connect (car hp) (cdr hp) :start-height start-height
                                   :timeout timeout :require-network require-network
                                   :min-height min-height)))
            (when peer (push peer peers))))))
    (nreverse peers)))

(defun make-peer-source (&key (am am:*addrman*) (start-height 0) (timeout 8)
                              (require-network t) (min-height 0))
  "Return a thunk that yields ONE fresh live NODE_NETWORK peer from AM (or NIL when
   exhausted).  Passed to RUN-IBD-ASYNC so a fetcher whose peer dies can pull a
   replacement instead of aborting the whole run."
  (lambda ()
    (loop for tries from 0 below 24
          for hp = (first (am:addrman-take am 1))
          while hp
          for peer = (try-connect (car hp) (cdr hp) :start-height start-height
                                  :timeout timeout :require-network require-network
                                  :min-height min-height)
          when peer do (return peer)
          finally (return nil))))

;;; --- a batch of dials in flight -------------------------------------------------------

(defstruct dial
  host port conn peer
  (state :connecting)                    ; :connecting :handshaking -> :live | :failed
  deadline)                              ; the owner's own bound, past the net thread's

(defstruct (dial-batch (:constructor %make-dial-batch))
  dials start-height timeout require-network min-height)

(defun start-dial-batch (candidates &key (start-height 0) (timeout 6)
                                         (require-network t) (min-height 0))
  "Start dialling every (host . port) in CANDIDATES at once, each over the transport
   P:PEER-PROXY picks for it (*PEER-TRANSPORT*; .onion through Tor); return the batch.
   Nothing waits: DIAL-BATCH-STEP advances it.  TIMEOUT bounds each connect (through a proxy:
   the connect and the SOCKS5 handshake together) and, again, its version handshake."
  (let ((now (get-internal-real-time)))
    (%make-dial-batch
     :start-height start-height :timeout timeout
     :require-network require-network :min-height min-height
     :dials (mapcar (lambda (hp)
                      (let ((d (make-dial :host (car hp) :port (cdr hp)
                                          :deadline (+ now (round (* (+ (* 2 timeout) 5)
                                                                     internal-time-units-per-second))))))
                        (handler-case
                            (setf (dial-conn d) (nl:net-connect-start (car hp) (cdr hp) :timeout timeout
                                                                           :proxy (p:peer-proxy (car hp))))
                          (serious-condition () (setf (dial-state d) :failed)))
                        d))
                    candidates))))

(defun %dial-fail (d)
  (setf (dial-state d) :failed)
  (cond ((dial-peer d) (ignore-errors (p:disconnect (dial-peer d))))
        ((dial-conn d) (ignore-errors (nl:net-close (dial-conn d))))))

(defun %dial-step (d b)
  "Advance one dial as far as it goes without waiting."
  (when (and (member (dial-state d) '(:connecting :handshaking))
             (> (get-internal-real-time) (dial-deadline d)))
    (%dial-fail d))
  (when (eq (dial-state d) :connecting)
    (case (nl:netconn-state (dial-conn d))
      (:open
       (handler-case
           (setf (dial-peer d) (p:start-outbound-handshake (dial-conn d)
                                                           :start-height (dial-batch-start-height b)
                                                           :timeout (dial-batch-timeout b))
                 (dial-state d) :handshaking)
         (serious-condition () (%dial-fail d))))
      (:failed (setf (dial-state d) :failed))))
  (when (eq (dial-state d) :handshaking)
    (let ((peer (dial-peer d)))
      (case (p:handshake-status peer)
        (:done
         (cond
           ((and (dial-batch-require-network b)
                 (not (logtest (or (p:peer-services peer) 0) w:+services-network+)))
            (%dial-fail d))               ; pruned / non-archive: can't serve history
           ((< (or (p:peer-height peer) 0) (dial-batch-min-height b))
            (%dial-fail d))               ; peer itself not synced past our target
           (t (format t "~&[discovery] +peer ~a:~d h~a ~a~%"
                      (dial-host d) (dial-port d) (p:peer-height peer) (p:peer-subver peer))
              (force-output)
              (p:start-read-loop peer)
              (setf (dial-state d) :live))))
        (:failed (setf (dial-state d) :failed))))))

(defun dial-batch-step (b)
  "Advance every dial of B without waiting; T once each has resolved (live or failed)."
  (let ((done t))
    (dolist (d (dial-batch-dials b) done)
      (%dial-step d b)
      (unless (member (dial-state d) '(:live :failed)) (setf done nil)))))

(defun dial-batch-live (b)
  "The live peers B has made so far, in candidate order."
  (loop for d in (dial-batch-dials b) when (eq (dial-state d) :live) collect (dial-peer d)))

(defun dial-batch-abort (b)
  "Give up every dial of B still in flight."
  (dolist (d (dial-batch-dials b))
    (when (member (dial-state d) '(:connecting :handshaking)) (%dial-fail d))))

(defun connect-parallel (candidates &key (start-height 0) (timeout 6)
                                         (require-network t) (min-height 0))
  "Dial every (host . port) in CANDIDATES concurrently and return the live peers (their
   read loops running).  Most gossiped addresses are dead, so serial dialing pays one
   TIMEOUT per dud; dialling them all at once collapses the batch into one timeout window.
   Waits, pumping the net layer (see DIAL-BATCH)."
  (let ((b (start-dial-batch candidates :start-height start-height :timeout timeout
                                         :require-network require-network :min-height min-height)))
    (unless (nl:pump-until (lambda () (dial-batch-step b)) :timeout (+ (* 2 timeout) 10))
      (dial-batch-abort b))
    (dial-batch-live b)))

;;; --- a pool: batches until N peers ------------------------------------------------------

(defstruct (dial-pool (:constructor %make-dial-pool))
  n am batch max-rounds (round 0) (live '()) current (attempts 0) (done nil)
  start-height timeout require-network min-height)

(defun make-dial-pool (n &key (am am:*addrman*) (start-height 0) (timeout 6)
                              (batch (* 4 n)) (max-rounds 4)
                              (require-network t) (min-height 0))
  "A pool that collects up to N live NODE_NETWORK peers, dialling AM's candidates BATCH at
   a time, until N are up, AM runs dry, or MAX-ROUNDS batches have run.  Nothing happens
   until DIAL-POOL-STEP."
  (%make-dial-pool :n n :am am :batch batch :max-rounds max-rounds
                   :start-height start-height :timeout timeout
                   :require-network require-network :min-height min-height))

(defun %pool-finish (pool)
  (let ((live (dial-pool-live pool)) (n (dial-pool-n pool)))
    (when (> (length live) n)
      (mapc (lambda (p) (ignore-errors (p:disconnect p))) (subseq live n))   ; drop surplus (tail)
      (setf (dial-pool-live pool) (subseq live 0 n))))
  (setf (dial-pool-done pool) t))

(defun dial-pool-step (pool)
  "Advance POOL without waiting; T once it is finished, and DIAL-POOL-LIVE is its peers."
  (loop
    (when (dial-pool-done pool) (return t))
    (let ((cur (dial-pool-current pool)))
      (when cur
        (unless (dial-batch-step cur) (return nil))
        (setf (dial-pool-live pool) (append (dial-pool-live pool) (dial-batch-live cur))
              (dial-pool-current pool) nil)))
    (when (or (>= (length (dial-pool-live pool)) (dial-pool-n pool))
              (>= (dial-pool-round pool) (dial-pool-max-rounds pool)))
      (%pool-finish pool) (return t))
    (let ((cands (am:addrman-take (dial-pool-am pool) (dial-pool-batch pool))))
      (when (null cands) (%pool-finish pool) (return t))
      (incf (dial-pool-round pool))
      (incf (dial-pool-attempts pool) (length cands))
      (setf (dial-pool-current pool)
            (start-dial-batch cands
                              :start-height (dial-pool-start-height pool)
                              :timeout (dial-pool-timeout pool)
                              :require-network (dial-pool-require-network pool)
                              :min-height (dial-pool-min-height pool))))))

(defun dial-pool-stop (pool)
  "Finish POOL now: dials in flight are given up, the peers made so far are kept."
  (let ((cur (dial-pool-current pool)))
    (when cur
      (dial-batch-abort cur)
      (setf (dial-pool-live pool) (append (dial-pool-live pool) (dial-batch-live cur))
            (dial-pool-current pool) nil)))
  (%pool-finish pool))

(defun dial-pool-abort (pool)
  "Give up POOL's dials in flight and close the peers it has made."
  (when (dial-pool-current pool) (dial-batch-abort (dial-pool-current pool)))
  (mapc (lambda (p) (ignore-errors (p:disconnect p))) (dial-pool-live pool))
  (setf (dial-pool-live pool) '() (dial-pool-current pool) nil (dial-pool-done pool) t))

(defun connect-n-parallel (n &key (am am:*addrman*) (start-height 0) (timeout 6)
                                  (batch (* 4 n)) (max-rounds 4)
                                  (require-network t) (min-height 0))
  "Collect up to N live NODE_NETWORK peers, dialing addrman candidates in parallel
   batches until N are up, the pool is exhausted, or MAX-ROUNDS batches have run.
   Surplus connections beyond N are closed.  Waits, pumping (see DIAL-POOL)."
  (let ((pool (make-dial-pool n :am am :start-height start-height :timeout timeout
                                :batch batch :max-rounds max-rounds
                                :require-network require-network :min-height min-height)))
    (unless (nl:pump-until (lambda () (dial-pool-step pool))
                           :timeout (* max-rounds (+ (* 2 timeout) 10)))
      (dial-pool-stop pool))
    (dial-pool-live pool)))

(defun discover-peers-parallel (n &key (am am:*addrman*) (start-height 0) bootstrap (min-height 0))
  "Like DISCOVER-PEERS but fans the dials out.  Seeds AM from a BOOTSTRAP peer's
   getaddr (if given) AND the DNS seeds (curated, higher hit-rate than gossip),
   then parallel-dials up to N live peers."
  (when bootstrap
    (p:enable-discovery bootstrap (lambda (hp) (am:addrman-add am (car hp) (cdr hp))))
    (p:pause-for 3))                      ; let the addr/addrv2 reply arrive
  (seed-from-dns am)
  (connect-n-parallel n :am am :start-height start-height :min-height min-height))

(defun discover-peers (n &key (am am:*addrman*) (start-height 0) bootstrap)
  "Return up to N live NODE_NETWORK peer connections.  Seeds AM from DNS when
   empty, and — if a BOOTSTRAP peer is given — asks it for addresses (getaddr)
   first, so a local node can supply the network without DNS."
  (when bootstrap
    (p:enable-discovery bootstrap (lambda (hp) (am:addrman-add am (car hp) (cdr hp))))
    (p:pause-for 3))                      ; let the addr/addrv2 reply arrive
  (when (zerop (am:addrman-size am)) (seed-from-dns am))
  (connect-n n :am am :start-height start-height))
