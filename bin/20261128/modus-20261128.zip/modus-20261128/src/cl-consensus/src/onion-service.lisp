;;;; src/onion-service.lisp — run a v3 onion SERVICE for this node (inbound over Tor).
;;;;
;;;; Part of the optional cl-consensus/tor system (needs cl-tor).  Publishes an onion
;;;; service for the node; each inbound rendezvous stream becomes an ORDINARY INBOUND
;;;; CONNECTION of the net layer, as with a tor daemon's HiddenServicePort: cl-tor splices
;;;; the stream to a listener of the node's own on 127.0.0.1 (an ephemeral port), the net
;;;; thread accepts it, and the owner runs the inbound handshake and serves the peer as it
;;;; pumps (ACCEPT-NETCONN) -- a NETCONN like any other, with no reader thread.  The node's
;;;; identity (hence its .onion address) is persisted so it survives restarts.
;;;;
;;;; THE THREADS SHARE NOTHING (netloop.lisp, cl-tor's dirsvc.lisp).  The service -- its
;;;; identity, intro points, descriptor -- belongs to the OWNER, this node's thread: an owner
;;;; task steps it (CL-TOR.HSHOST:SERVICE-STEP), which also answers the directory questions
;;;; of the service's threads from the owner's directory state (the consensus is the owner's,
;;;; shared with the in-process SOCKS proxy, src/tor-proxy.lisp).  cl-tor runs each intro
;;;; point, rendezvous and descriptor upload on a thread of its own, started on a named
;;;; function; nothing here starts a thread.

(defpackage #:cl-consensus.onion-service
  (:use #:cl)
  (:local-nicknames (#:svc #:cl-tor.hsservice) (#:host #:cl-tor.hshost)
                    (#:hsdir #:cl-tor.hsdir)
                    (#:p #:cl-consensus.peer) (#:s #:cl-consensus.serve)
                    (#:nl #:cl-consensus.netloop) (#:own #:bobbin.owner))
  (:export #:start-onion-service #:stop-onion-service #:onion-service-published-p
           #:onion-service-listen-port #:*onion-address* #:*onion-service*))

(in-package #:cl-consensus.onion-service)

(defvar *onion-address* nil "This node's published .onion address, once the service is up.")
(defvar *onion-service* nil
  "The running service: a plist (:service S :listener ID :port P :announce TIMER), or NIL.")

(defun %load-or-create-identity (path)
  "Load the 32-byte service seed from PATH, or generate + persist a new one there."
  (if (and path (probe-file path))
      (svc:identity-from-seed
       (with-open-file (in path :element-type '(unsigned-byte 8))
         (let ((seed (make-array 32 :element-type '(unsigned-byte 8))))
           (read-sequence seed in) seed)))
      (let ((id (svc:generate-identity)))
        (when path
          (with-open-file (out path :direction :output :element-type '(unsigned-byte 8)
                                    :if-exists :supersede :if-does-not-exist :create)
            (write-sequence (svc:hs-identity-seed id) out)))
        id)))

(defun %announce (onion port)
  "Gossip our own .onion as a BIP155 addrv2 to every live peer, so they add it to their
   address db and RELAY it — this is how the network learns to reach us.  An owner timer."
  (handler-case
      (let ((peers (remove-if-not #'p:peer-wants-addrv2 (cl-consensus.node:live-peers)))
            (entries (list (p:onion-addrv2-entry onion port))))
        (dolist (pr peers) (p:announce-address pr entries))
        (when peers
          (format t "~&[onion] advertised ~a:~d to ~d peers~%" onion port (length peers))
          (force-output)))
    (serious-condition () nil)))

(defun %on-inbound (start-height max-peers)
  "The net layer's accept function for the service's local listener: every connection on it
   is an inbound Tor peer (cl-tor's rendezvous splice)."
  (lambda (conn)
    (p:accept-netconn
     conn
     (lambda (pr)
       (cond ((s:register-inbound-peer pr :max-peers max-peers)
              (format t "~&[onion] inbound peer up: ~a (height ~a)~%"
                      (p:peer-subver pr) (p:peer-height pr))
              (force-output))
             (t (p:disconnect pr))))                      ; at cap
     :host "onion-inbound" :start-height start-height)))

(defun start-onion-service (&key key-path (start-height 0) (num-intros 3) (port 8333)
                                 (max-peers 64) (republish 5400) (announce-interval 900))
  "Publish an onion service for this node and serve inbound Tor peers into the node's
   inbound set.  Call it on the owner (the node's thread, which has started the net layer).
   KEY-PATH persists the identity (stable .onion across restarts).  The descriptor is
   re-published every REPUBLISH seconds (and whenever the intro points change), and our
   .onion (addrv2) is advertised to peers every ANNOUNCE-INTERVAL seconds so the network
   learns to dial us.  Returns the .onion; it is reachable once ONION-SERVICE-PUBLISHED-P."
  (when *onion-service* (stop-onion-service))
  (nl:start-net)
  (let* ((id (%load-or-create-identity key-path))
         (onion (hsdir:pubkey->onion (svc:hs-identity-pubkey id))))
    (multiple-value-bind (bound listener)
        (nl:net-listen "127.0.0.1" 0 (%on-inbound start-height max-peers))
      (let ((service (host:start-service id :target (list "127.0.0.1" bound)
                                            :num-intros num-intros
                                            :republish-interval republish)))
        (nl:add-owner-task 'onion-service (lambda () (host:service-step service)) :interval 0.05)
        (setf *onion-address* onion
              *onion-service*
              (list :service service :listener listener :port bound
                    :announce (own:every-seconds announce-interval
                                                 (lambda () (%announce onion port))
                                                 :name 'onion-advertise
                                                 :first (min 60 announce-interval))))
        (format t "~&[onion] service address: ~a (inbound via 127.0.0.1:~d)~%" onion bound)
        (force-output)
        onion))))

(defun onion-service-published-p ()
  "True once the running service's descriptor has been accepted by an HSDir."
  (and *onion-service* (host:service-published (getf *onion-service* :service))))

(defun onion-service-listen-port ()
  "The local port inbound Tor peers arrive on, or NIL."
  (and *onion-service* (getf *onion-service* :port)))

(defun stop-onion-service ()
  "Stop the service START-ONION-SERVICE started: its intro points and rendezvous end, its
   local listener closes.  Inbound peers already up stay up until their streams end."
  (let ((o *onion-service*))
    (when o
      (setf *onion-service* nil)
      (host:stop-service (getf o :service))
      (own:cancel-timer (getf o :announce))
      (nl:net-unlisten (getf o :listener))
      ;; keep stepping a little so the threads' last reports are read, then drop the task
      (let ((svc (getf o :service)))
        (nl:wait-until (lambda () (zerop (host:service-intro-count svc))) :timeout 10))
      (nl:remove-owner-task 'onion-service)))
  nil)

;; Register with the core node: SERVE-NODE calls this when :onion-service is on.
(setf cl-consensus.node:*onion-service-hook* #'start-onion-service)
