;;;; src/netloop.lisp -- the P2P sockets: one net thread, two channels, on every Lisp.
;;;;
;;;; THE MODEL.  modus threads share no state: a worker may not store one of its own
;;;; objects where another thread can reach it.  A thread per peer that shares the chain,
;;;; the mempool, the peer lists and every handler's closure variables therefore cannot
;;;; work there.  So the work is split the way modus's own isolated SSH server splits it
;;;; (net/isolated-cl.lisp), and the way bobbin channel users split theirs
;;;; (webrtc-data's transport, cl-tor's SOCKS server):
;;;;
;;;;   - ONE NET THREAD owns every socket (listeners and connections).  It never sees a
;;;;     peer, a handler or the chain; it moves BYTES.  It is started on a NAMED function
;;;;     with its two channels as :ARGUMENTS, and keeps everything it makes in locals.
;;;;   - The OWNER (the thread that started the net layer, normally the main thread) owns
;;;;     everything else.  Peers, handlers and the chain live there, and every handler runs
;;;;     there, when it PUMPS.
;;;;   - Two bobbin channels connect them: commands in (:listen :connect :send :close
;;;;     :unlisten), events out (:accept :data :eof, and replies).  A channel copies its
;;;;     message into the receiver's heap, so nothing is shared.  On modus a channel is a
;;;;     MODUS:CHANNEL; on SBCL it is a locked queue of copies: the same design, the same code.
;;;;
;;;; THE PUMP IS BOBBIN'S OWNER LOOP (BOBBIN.OWNER).  The event channel is a SOURCE of that
;;;; loop (ADD-OWNER-SOURCE, in START-NET): every pump drains it, an idle owner waits in it
;;;; (so an event wakes it directly, as before), and a message to the owner's own inbox -- an
;;;; OWNER-CALL -- wakes it there (%NET-WAKE).  PUMP, PAUSE-FOR,
;;;; WAIT-UNTIL, PUMP-UNTIL and OWNER-CALL are bobbin's, re-exported here: so a program that also
;;;; uses bobbin's lanes and timers (cl-deposits) is served by the same pump -- a lane waiting in
;;;; PAUSE-FOR delivers network input, and a handshake waiting in CONN-READ runs lanes and timers.
;;;;
;;;; The owner learns about network input only when it pumps.  Every place cl-consensus waits
;;;; for the network therefore waits through PAUSE-FOR (or WAIT-UNTIL, built on it): it pumps
;;;; for that long, running handlers as messages arrive.  A blocking read on a connection
;;;; (CONN-READ: the outbound handshake) pumps too.
;;;;
;;;; WHO MAY PUMP.  On modus only the owner: pumping touches the owner's tables.  On SBCL
;;;; any thread that waits on a peer (an IBD fetcher, a discovery dialler, the archive's
;;;; threads) pumps too: one of them takes the events off the channel at a time, and every
;;;; pumping thread runs connections' ON-DATA -- one connection on one thread at a time --
;;;; so handler work (checksums, block parsing) still spreads over the waiting threads as
;;;; it did with a thread per peer.  Measured on SBCL, 64 x 1 MB blocks over loopback
;;;; from a thread-per-peer server, one fetcher thread per peer, for 1 / 4 / 8 peers: a
;;;; thread per peer 23 / 78 / 151 MB/s; this layer 14 / 32 / 42, and 20 / 59 / 107 with
;;;; cl-transport receiving through read(2) (SB-BSD-SOCKETS:SOCKET-RECEIVE copies element by
;;;; element, and this layer's net thread does every receive).  Serving is the owner's alone:
;;;; 8 peers fetching from this layer get ~37 MB/s in all, against ~150 from a thread per
;;;; inbound peer.
;;;;
;;;; FOREIGN THREADS reach the owner by OWNER-CALL (bobbin's): a named function and plain
;;;; arguments go to the owner's inbox, it runs them while pumping, and the value comes back on
;;;; a reply channel.  The JSON-RPC server and the control socket of SERVE-NODE use it, so their
;;;; connection threads (cl-transport/http-server's) never touch the node's state.  A call runs
;;;; on the OWNER only (other pumping threads deliver network events, never calls).
;;;;
;;;; CONNECTS DO NOT BLOCK THE NET THREAD.  A :CONNECT starts a non-blocking connect and the
;;;; socket waits, with its own deadline, among the others the net thread polls: many dials
;;;; are in flight at once, and the answer (:CONNECTED or :ERROR) comes back as an event.
;;;; NET-CONNECT-START returns at once with a NETCONN in state :CONNECTING; NET-CONNECT waits
;;;; (pumping) for it.  Both Lisps: modus's sb-bsd-sockets has (SETF NON-BLOCKING-MODE),
;;;; signals OPERATION-IN-PROGRESS for EINPROGRESS and has WAIT-UNTIL-FD-USABLE :OUTPUT.
;;;; (A host NAME is still resolved on the net thread, blocking; peers are dialled by address.)
;;;;
;;;; THROUGH A SOCKS5 PROXY (Tor's SocksPort, cl-tor's in-process proxy, any SOCKS5 proxy) a
;;;; dial is the same thing: a non-blocking connect to the proxy, then the SOCKS5 handshake
;;;; spoken by the net thread as the proxy's replies arrive (see %SOCKS-STEP), under the
;;;; dial's one deadline; :CONNECTED once the proxy has connected the target.  So a Tor peer
;;;; -- a .onion one included -- is an ordinary connection: no stream, no reader thread, and
;;;; as many dials in flight as for clearnet.
;;;;
;;;; OWNER TASKS.  Work that must run on the owner but on no schedule of its own -- the peer
;;;; manager's top-up -- is an OWNER TASK (ADD-OWNER-TASK): a bobbin timer, which the owner
;;;; runs from PUMP every so often.  A task must not wait: it is called from inside whatever
;;;; wait the owner is in (a handshake, a header sync), so it starts work and looks at its progress,
;;;; and the pumping that follows does the rest.

(defpackage #:cl-consensus.netloop
  (:use #:cl)
  (:local-nicknames (#:sock #:cl-transport.sockets) (#:bob #:bobbin) (#:own #:bobbin.owner))
  ;; bobbin's owner loop, re-exported (one pump for every library in the process)
  (:import-from #:bobbin.owner #:pause-for #:wait-until #:pump-until #:pump
                #:owner-call #:owner-call-error)
  (:export #:start-net #:stop-net #:net-running-p
           #:pause-for #:wait-until #:pump-until #:pump
           #:netconn #:netconn-p #:netconn-id #:netconn-host #:netconn-port #:netconn-eof
           #:netconn-on-data #:conn-kick
           #:netconn-state #:netconn-error
           #:net-listen #:net-unlisten #:net-connect #:net-connect-start #:net-close
           #:add-owner-task #:remove-owner-task #:owner-thread-p
           #:conn-write #:conn-read #:conn-available #:conn-peek-u32 #:conn-peek
           #:*conn-deadline* #:conn-timeout
           #:owner-call #:owner-call-error))
(in-package #:cl-consensus.netloop)

(defconstant +chunk+ (* 256 1024)
  "The most bytes one :SEND command carries: a larger write is split, so a channel bounds a
   message, not a block.")

(defconstant +chan-bytes+ (* 8 1024 1024)
  "Capacity of each of the two channels.  A full event channel makes the net thread wait
   (backpressure): input the owner is not pumping stays in the kernel.")

;;; ===========================================================================
;;; The net thread.  Everything below until "THE OWNER SIDE" runs there and keeps its
;;; state in locals: nothing it makes is stored anywhere the owner can reach.
;;; ===========================================================================

(defun %emit (out event)
  (bob:channel-send out event)
  (own:owner-wake 'cl-consensus.netloop))   ; an owner idle in some other wait wakes now

(defconstant +max-queued+ (* 64 1024 1024)
  "A connection with more output queued than this is not reading: it is dropped (:EOF).")

(defun %send-some (sock v off)
  "Send what SOCK takes now of V from OFF, without waiting: the bytes sent (0 when it takes
   none).  The socket is non-blocking only for this: on modus SOCKET-SEND has no :DONTWAIT,
   and SB-SYS:WAIT-UNTIL-FD-USABLE :OUTPUT answers T on a socket whose buffer is full.  A
   send that would block returns NIL on SBCL and signals SOCKET-ERROR on modus; a broken
   connection shows itself on the read side (end of stream), so both count as 0 here."
  (let ((end (min (length v) (+ off 65536))))
    (setf (sb-bsd-sockets:non-blocking-mode sock) t)
    (unwind-protect
         (let ((n (handler-case (sb-bsd-sockets:socket-send
                                 sock (if (and (zerop off) (= end (length v))) v (subseq v off end))
                                 (- end off))
                    (error () nil))))
           (if (and (integerp n) (plusp n)) n 0))
      (ignore-errors (setf (sb-bsd-sockets:non-blocking-mode sock) nil)))))

;;; --- SOCKS5 (RFC 1928, with RFC 1929 username/password), spoken by the net thread ---
;;;
;;; A :CONNECT may name a PROXY: the net thread then connects to the proxy instead, and
;;; before the connection is reported :CONNECTED it speaks SOCKS5 to it -- greeting, the
;;; optional username/password, CONNECT to the target -- as input arrives, like any other
;;; connection's input, under the dial's one deadline.  The target goes as a domain name
;;; (ATYP 3) unless it is a dotted quad, so the proxy resolves it (no local DNS lookup for a
;;; peer reached through Tor; a .onion name only means anything to the proxy).  Many such
;;; handshakes are in flight at once; none waits.

(defun %octets (&rest parts)
  "One octet vector of PARTS: integers (one byte each) and octet vectors."
  (let* ((n (loop for x in parts sum (if (integerp x) 1 (length x))))
         (v (make-array n :element-type '(unsigned-byte 8))) (i 0))
    (dolist (x parts v)
      (if (integerp x)
          (progn (setf (aref v i) x) (incf i))
          (progn (replace v x :start1 i) (incf i (length x)))))))

(defun %ascii (string)
  (let ((v (make-array (length string) :element-type '(unsigned-byte 8))))
    (dotimes (i (length string) v)
      (let ((c (char-code (char string i))))
        (when (> c 127) (error "SOCKS5: not an ASCII name: ~a" string))
        (setf (aref v i) c)))))

(defun %socks-greeting (user)
  ;; version 5; no authentication, and username/password when we have credentials
  (if user (%octets 5 2 0 2) (%octets 5 1 0)))

(defun %socks-auth (user pass)
  (let ((u (%ascii user)) (p (%ascii (or pass ""))))
    (when (or (> (length u) 255) (> (length p) 255)) (error "SOCKS5: credentials too long"))
    (%octets 1 (length u) u (length p) p)))

(defun %socks-connect-request (host port)
  (let ((quad (sock:dotted-quad host)))
    (if quad
        (%octets 5 1 0 1 (coerce quad '(simple-array (unsigned-byte 8) (*)))
                 (ldb (byte 8 8) port) (ldb (byte 8 0) port))
        (let ((name (%ascii host)))
          (when (> (length name) 255) (error "SOCKS5: host name too long: ~a" host))
          (%octets 5 1 0 3 (length name) name (ldb (byte 8 8) port) (ldb (byte 8 0) port))))))

(defun %socks-reply-text (code)
  (case code
    (1 "general SOCKS server failure") (2 "connection not allowed by ruleset")
    (3 "network unreachable") (4 "host unreachable") (5 "connection refused")
    (6 "TTL expired") (7 "command not supported") (8 "address type not supported")
    ;; Tor's extended replies (onion services)
    (#xF0 "onion service descriptor can not be found") (#xF1 "onion service descriptor is invalid")
    (#xF2 "onion service introduction failed") (#xF3 "onion service rendezvous failed")
    (#xF4 "onion service missing client authorization") (#xF5 "onion service wrong client authorization")
    (#xF6 "onion service invalid address") (#xF7 "onion service introduction timed out")
    (t (format nil "reply ~d" code))))

(defun %socks-step (st)
  "Advance SOCKS state ST (a vector: phase inbuf host port user pass deadline) over the bytes
   in its INBUF.  Values: what to send now (an octet vector or NIL), and the outcome --
   NIL (more input needed), :DONE (the connection is through; INBUF holds what followed the
   reply), or a string (why it failed)."
  (let ((buf (svref st 1)))
    (flet ((need (n) (< (length buf) n))
           (consume (n) (setf (svref st 1) (subseq buf n))))
      (ecase (svref st 0)
        (:greet
         (cond ((need 2) (values nil nil))
               ((/= (aref buf 0) 5) (values nil "not a SOCKS5 proxy"))
               ((and (= (aref buf 1) 2) (svref st 4))
                (consume 2) (setf (svref st 0) :auth)
                (values (%socks-auth (svref st 4) (svref st 5)) nil))
               ((= (aref buf 1) 0)
                (consume 2) (setf (svref st 0) :reply)
                (values (%socks-connect-request (svref st 2) (svref st 3)) nil))
               (t (values nil "SOCKS5 proxy accepts none of our authentication methods"))))
        (:auth
         (cond ((need 2) (values nil nil))
               ((/= (aref buf 1) 0) (values nil "SOCKS5 proxy rejected the username/password"))
               (t (consume 2) (setf (svref st 0) :reply)
                  (values (%socks-connect-request (svref st 2) (svref st 3)) nil))))
        (:reply
         (cond ((need 2) (values nil nil))
               ((/= (aref buf 0) 5) (values nil "SOCKS5: bad reply"))
               ((/= (aref buf 1) 0)
                (values nil (format nil "SOCKS5: ~a" (%socks-reply-text (aref buf 1)))))
               ((need 5) (values nil nil))
               (t (let ((total (case (aref buf 3)
                                 (1 10) (4 22) (3 (+ 7 (aref buf 4)))
                                 (t nil))))
                    (cond ((null total) (values nil "SOCKS5: bad address type in reply"))
                          ((need total) (values nil nil))
                          (t (consume total) (setf (svref st 0) :done) (values nil :done)))))))))))

(defun %net-thread-main (in out)
  "The net thread's whole life: run commands from IN, report on OUT, until :QUIT."
  (let ((conns (make-hash-table))           ; id -> tcp-socket
        (rdone (make-hash-table))           ; ids whose peer has finished SENDING (EOF read):
                                            ; no longer polled, still writable until :close
        (listeners (make-hash-table))       ; id -> listening socket
        (ids (make-hash-table :test 'eq))   ; socket -> id, for WAIT-READABLE's answer
        (outq (make-hash-table))            ; id -> (offset-into-first vector ...): unsent output
        (queued (make-hash-table))          ; id -> bytes in OUTQ
        (closing (make-hash-table))         ; id -> socket the owner closed, output still queued
        (connecting (make-hash-table))      ; id -> (sb-bsd-socket . deadline): connect in flight
        (socks (make-hash-table))           ; id -> SOCKS state (%SOCKS-STEP): connected to its
                                            ; proxy, handshake not finished; in CONNS, not reported
        (next 1000000))                     ; ids for accepted connections
    ;; A WRITE NEVER WAITS.  This one thread is also the reader of every socket, the far end
    ;; of a loopback dial included: a blocking send to a peer that is not reading -- or one
    ;; whose reading is this thread -- would stop the whole net layer.  Output is queued per
    ;; connection and sent as the socket takes it.
    (labels ((connected (id sock)
               ;; a connect has completed: SOCK becomes connection ID
               (setf (sb-bsd-sockets:non-blocking-mode sock) nil)
               (ignore-errors (setf (sb-bsd-sockets:sockopt-tcp-nodelay sock) t))
               (let ((s (sock:tcp-socket-from sock)) (st (gethash id socks)))
                 (setf (gethash id conns) s (gethash s ids) id)
                 (if st
                     (enqueue id (%socks-greeting (svref st 4)))   ; reported when through
                     (%emit out (list :connected id)))))
             (socks-fail (id why)
               (remhash id socks)
               (drop-output id)
               (let ((s (forget id)))
                 (when s (sock:tcp-close s :abort t)))
               (%emit out (list :error id why)))
             (socks-input (id octets eof)
               ;; bytes from a proxy whose handshake is still running
               (let ((st (gethash id socks)))
                 (setf (svref st 1) (concatenate '(simple-array (unsigned-byte 8) (*))
                                                 (svref st 1) octets))
                 (loop
                   (multiple-value-bind (send outcome)
                       (handler-case (%socks-step st)
                         (serious-condition (e) (values nil (princ-to-string e))))
                     (when send (enqueue id send))
                     (cond ((stringp outcome) (return (socks-fail id outcome)))
                           ((eq outcome :done)
                            (remhash id socks)
                            (%emit out (list :connected id))
                            (when (plusp (length (svref st 1)))
                              (%emit out (list :data id (svref st 1))))
                            (when eof
                              (setf (gethash id rdone) t)
                              (%emit out (list :eof id)))
                            (return))
                           ((null send)       ; needs more input
                            (when eof (socks-fail id "SOCKS5 proxy closed the connection"))
                            (return)))))))
             (check-socks ()
               (let ((now (get-internal-real-time)) (late '()))
                 (maphash (lambda (id st) (when (> now (svref st 6)) (push id late))) socks)
                 (dolist (id late) (socks-fail id "SOCKS5 handshake timed out"))))
             (enqueue (id v)
               ;; queue V for connection ID and send what its socket takes now
               (let ((s (gethash id conns)))
                 (when (and s (plusp (length v)))
                   (let ((q (or (gethash id outq) (list 0))))
                     (setf (gethash id outq) (nconc q (list v)))
                     (incf (gethash id queued 0) (length v))
                     (cond ((> (gethash id queued 0) +max-queued+)
                            (drop-output id) (forget id)
                            (sock:tcp-close s :abort t)
                            (%emit out (list :eof id)))
                           (t (flush id (sock:tcp-socket-sock s))))))))
             (connect-failed (id sock why)
               (remhash id socks)
               (ignore-errors (sb-bsd-sockets:socket-close sock))
               (%emit out (list :error id why)))
             (check-connecting ()
               ;; resolve the connects in flight that have an answer, or are out of time.
               ;; A socket becomes writable when its connect completes OR fails; only a
               ;; connected one has a peer name.  T if any resolved.
               (let ((now (get-internal-real-time)) (resolved '()))
                 (maphash (lambda (id entry)
                            (let ((sk (car entry)))
                              (cond ((ignore-errors
                                      (sb-sys:wait-until-fd-usable
                                       (sb-bsd-sockets:socket-file-descriptor sk) :output 0))
                                     (push id resolved)
                                     (if (ignore-errors (sb-bsd-sockets:socket-peername sk) t)
                                         (handler-case (connected id sk)
                                           (serious-condition (e)
                                             (connect-failed id sk (princ-to-string e))))
                                         (connect-failed id sk "connection refused")))
                                    ((> now (cdr entry))
                                     (push id resolved)
                                     (connect-failed id sk "connect timed out")))))
                          connecting)
                 (dolist (id resolved) (remhash id connecting))
                 (and resolved t)))
             (forget (id)
               (let ((s (or (gethash id conns) (gethash id listeners))))
                 (when s (remhash s ids))
                 (remhash id conns) (remhash id listeners) (remhash id rdone)
                 s))
             (drop-output (id) (remhash id outq) (remhash id queued))
             (flush (id sock)
               ;; send what SOCK takes of ID's queue; T when the queue is empty
               (let ((q (gethash id outq)))
                 (loop while (cdr q)
                       do (let* ((v (second q)) (off (first q)) (n (%send-some sock v off)))
                            (when (zerop n) (return))
                            (decf (gethash id queued 0) n)
                            (if (>= (+ off n) (length v))
                                (setf q (cons 0 (cddr q)))
                                (setf (first q) (+ off n)))))
                 (if (cdr q) (progn (setf (gethash id outq) q) nil) (progn (drop-output id) t))))
             (flush-all ()
               ;; T if anything is still queued
               (let ((pending nil))
                 (maphash (lambda (id q)
                            (declare (ignore q))
                            (let ((s (or (gethash id conns) (gethash id closing))))
                              (cond ((null s) (drop-output id))
                                    ((flush id (sock:tcp-socket-sock s))
                                     (when (gethash id closing)
                                       (remhash id closing)
                                       (sock:tcp-close s)))
                                    (t (setf pending t)))))
                          ;; MAPHASH over a copy: FLUSH removes entries
                          (let ((h (make-hash-table)))
                            (maphash (lambda (k v) (setf (gethash k h) v)) outq) h))
                 pending))
             (command (cmd)
               ;; NIL for :QUIT, else T
               (let ((op (first cmd)) (id (second cmd)))
                 (case op
                   (:listen
                    (handler-case
                        (let ((l (sock:tcp-listen :host (third cmd) :port (fourth cmd) :backlog 64)))
                          (setf (gethash id listeners) l (gethash l ids) id)
                          (%emit out (list :listening id (sock:tcp-listener-port l))))
                      (serious-condition (e)
                        (%emit out (list :error id (princ-to-string e))))))
                   (:connect
                    ;; start a non-blocking connect; CHECK-CONNECTING finishes it.  With a
                    ;; PROXY (host port user pass) the connect is to the proxy, and the SOCKS5
                    ;; handshake follows (SOCKS-INPUT) before :CONNECTED.
                    (let ((sk nil) (proxy (sixth cmd)))
                      (handler-case
                          (let* ((deadline (+ (get-internal-real-time)
                                              (round (* (or (fifth cmd) 15)
                                                        internal-time-units-per-second))))
                                 (addr (sock:resolve-host (if proxy (first proxy) (third cmd)))))
                            (when proxy
                              (setf (gethash id socks)
                                    (vector :greet (make-array 0 :element-type '(unsigned-byte 8))
                                            (third cmd) (fourth cmd) (third proxy) (fourth proxy)
                                            deadline)))
                            (setf sk (make-instance 'sb-bsd-sockets:inet-socket
                                                    :type :stream :protocol :tcp))
                            (setf (sb-bsd-sockets:non-blocking-mode sk) t)
                            (if (handler-case (progn (sb-bsd-sockets:socket-connect
                                                      sk addr (if proxy (second proxy) (fourth cmd)))
                                                     t)
                                  (sb-bsd-sockets:operation-in-progress () nil))
                                (connected id sk)
                                (setf (gethash id connecting) (cons sk deadline))))
                        (serious-condition (e)
                          (remhash id socks)
                          (if sk
                              (connect-failed id sk (princ-to-string e))
                              (%emit out (list :error id (princ-to-string e))))))))
                   (:send (enqueue id (third cmd)))
                   (:close
                    (remhash id socks)
                    (let ((pend (gethash id connecting)))   ; a dial given up on
                      (when pend
                        (remhash id connecting)
                        (ignore-errors (sb-bsd-sockets:socket-close (car pend)))))
                    (let ((s (forget id)))
                      (cond ((null s))
                            ((not (sock:tcp-socket-p s)) (sock:tcp-listener-close s))
                            ((gethash id outq) (setf (gethash id closing) s))   ; after its output
                            (t (sock:tcp-close s)))))
                   (:quit
                    (maphash (lambda (id s) (declare (ignore id)) (sock:tcp-close s :abort t)) conns)
                    (maphash (lambda (id s) (declare (ignore id)) (sock:tcp-close s :abort t)) closing)
                    (maphash (lambda (id l) (declare (ignore id)) (sock:tcp-listener-close l)) listeners)
                    (maphash (lambda (id e) (declare (ignore id))
                               (ignore-errors (sb-bsd-sockets:socket-close (car e))))
                             connecting)
                    (return-from command nil)))
                 t))
             (poll ()
               ;; Accept and read whatever is ready now.  T if anything was.
               (let ((watch '()))
                 (maphash (lambda (id s) (unless (gethash id rdone) (push s watch))) conns)
                 (maphash (lambda (id l) (declare (ignore id)) (push l watch)) listeners)
                 (let ((ready (and watch (sock:wait-readable watch 0))))
                   (dolist (s ready)
                     (let ((id (gethash s ids)))
                       (cond
                         ((null id))
                         ((gethash id listeners)
                          (let ((c (ignore-errors (sock:tcp-accept s :timeout-ms 0))))
                            (when c
                              (let ((cid (incf next)))
                                (setf (gethash cid conns) c (gethash c ids) cid)
                                (multiple-value-bind (host port) (sock:tcp-peer c)
                                  (%emit out (list :accept id cid (or host "inbound") (or port 0))))))))
                         ((gethash id socks)
                          (multiple-value-bind (octets eof) (sock:tcp-read-available s)
                            (socks-input id octets eof)))
                         (t
                          (multiple-value-bind (octets eof) (sock:tcp-read-available s)
                            (when (plusp (length octets))
                              (%emit out (list :data id octets)))
                            ;; The peer has finished sending.  It may still be reading -- a
                            ;; client that half-closes after its request waits for the reply
                            ;; -- so the socket stays open for writes until the owner closes it.
                            (when eof
                              (setf (gethash id rdone) t)
                              (%emit out (list :eof id))))))))
                   (and ready t)))))
      (%emit out (list :ready 0))
      (loop
        (loop (multiple-value-bind (cmd ok) (bob:channel-try-receive in)
                (unless ok (return))
                (unless (command cmd) (return-from %net-thread-main nil))))
        (let ((busy (poll)))
          (when (and (plusp (hash-table-count connecting)) (check-connecting))
            (setf busy t))
          (when (plusp (hash-table-count socks)) (check-socks))
          (when (plusp (hash-table-count outq)) (flush-all))
          (unless busy
            ;; idle: wait for a command, but not long, so the sockets are looked at (and the
            ;; queued output tried) again
            ;; (shorter while connects are in flight: a loopback or LAN connect completes in
            ;; microseconds, and its dialler is waiting for the answer)
            (multiple-value-bind (cmd ok)
                (bob:channel-receive in :timeout (if (or (plusp (hash-table-count connecting))
                                                         (plusp (hash-table-count socks)))
                                                     0.0002 0.002))
              (when (and ok (not (command cmd)))
                (return-from %net-thread-main nil)))))))))

;;; ===========================================================================
;;; THE OWNER SIDE
;;;
;;; Two locks, both uncontended on modus (only the owner pumps there):
;;;   *RX-LOCK*  -- held by the ONE thread taking events off *FROM-NET* (it may wait there);
;;;   *LOCK*     -- guards the tables, each connection's inbox and flags, and the pending
;;;                 list; held only for a few instructions, never across user code or a wait.
;;; A connection's buffer (BUF/START/END) belongs to whoever is reading it: its ON-DATA
;;; runner (one at a time, the BUSY flag), or before it has an ON-DATA, the thread in
;;; CONN-READ.  Arriving bytes wait in its INBOX until that reader merges them.
;;; ===========================================================================

(defvar *to-net* nil "CHAN: commands to the net thread.")
(defvar *from-net* nil "CHAN: events from the net thread.")
(defvar *net-thread* nil)
(defvar *owner-tasks* '() "(name . bobbin timer) of every owner task.")
(defvar *next-id* 0)
(defvar *conns* (make-hash-table))       ; id -> netconn
(defvar *listeners* (make-hash-table))   ; id -> function of one netconn
(defvar *replies* (make-hash-table))     ; request id -> reply event
(defvar *pending* '() "Connections with input their ON-DATA has not been run for.")
(defvar *lock* (sb-thread:make-mutex :name "cl-consensus netloop"))
(defvar *rx-lock* (sb-thread:make-mutex :name "cl-consensus netloop receive"))

(defmacro %locked (&body body)
  `(sb-thread:with-recursive-lock (*lock*) ,@body))

(defstruct netconn
  id host port
  (state :open)                          ; :connecting (NET-CONNECT-START) -> :open | :failed
  (error nil)                            ; why it is :failed
  (buf (make-array 4096 :element-type '(unsigned-byte 8)))
  (start 0) (end 0)
  (inbox '())                            ; arrived octet vectors, newest first (under *LOCK*)
  (eof nil)
  (on-data nil)                          ; function of the conn, run after input arrives
  (busy nil)                             ; ON-DATA is running (no re-entry)
  (again nil)                            ; input came while it ran: run it once more
  (pending nil))                         ; on *PENDING*

(defun net-running-p () (and *net-thread* t))

(defun start-net ()
  "Start the net thread (once).  Call it -- or anything that uses the net layer -- first on
   the thread that will own the peers: on modus the channels must be made by a thread every
   other thread may name."
  (%locked
    (unless *net-thread*
      (unless *to-net*                    ; made once: on modus a channel is never reclaimed
        (setf *to-net* (bob:make-channel :capacity +chan-bytes+ :name "p2p commands")
              *from-net* (bob:make-channel :capacity +chan-bytes+ :name "p2p events")))
      (bob:channel-drain *to-net*)
      (own:start-owner)                   ; this thread owns the peers (and bobbin's owner loop)
      ;; the event channel becomes a source of bobbin's pump: every pump drains it, an idle
      ;; owner waits in it, and on SBCL other waiting threads drain it too
      (own:add-owner-source 'cl-consensus.netloop '%net-drain :any-thread t :wake '%net-wake)
      (setf *net-thread* (sb-thread:make-thread #'%net-thread-main :name "cl-consensus net"
                                                                  :arguments (list *to-net* *from-net*)))
      (multiple-value-bind (ev ok) (bob:channel-receive *from-net* :timeout 30)
        (unless (and ok (eq (first ev) :ready))
          (error "cl-consensus: the net thread did not start")))))
  t)

(defun stop-net ()
  "Close every socket and end the net thread.  The channels are kept (they are never
   reclaimed on modus), so a later START-NET reuses them."
  (let ((th (%locked (prog1 *net-thread* (setf *net-thread* nil)))))
    (when th
      (bob:channel-send *to-net* (list :quit 0))
      (ignore-errors (sb-thread:join-thread th :timeout 10 :default nil))
      (bob:channel-drain *from-net*)
      (%locked
        (maphash (lambda (id c) (declare (ignore id))
                   (setf (netconn-eof c) t)
                   (when (eq (netconn-state c) :connecting)
                     (setf (netconn-state c) :failed (netconn-error c) "the net layer stopped")))
                 *conns*)
        (clrhash *conns*) (clrhash *listeners*) (clrhash *replies*) (setf *pending* '()))))
  t)

(defun %send-command (cmd)
  "CMD to the net thread.  If its channel is full, deliver events meanwhile: the net thread
   may itself be waiting for room on the event channel."
  (unless *net-thread* (start-net))
  (loop until (bob:channel-send *to-net* cmd :timeout 0.05)
        do (pump 0)))

(defun %request (cmd &key (timeout 30))
  "Send CMD (its second element is a fresh request id) and pump until the reply."
  (unless *net-thread* (start-net))
  (let ((id (second cmd))
        (deadline (+ (get-internal-real-time) (* timeout internal-time-units-per-second))))
    (bob:channel-send *to-net* cmd)
    (loop
      (multiple-value-bind (r found) (%locked (gethash id *replies*))
        (when found (%locked (remhash id *replies*)) (return r)))
      (when (> (get-internal-real-time) deadline)
        (error "the net thread did not answer ~a" (first cmd)))
      (pump 0.05))))

(defun %merge (c)
  "Move C's inbox into its buffer.  Only C's reader calls this."
  (let ((chunks (and (netconn-inbox c) (%locked (prog1 (nreverse (netconn-inbox c))
                                                  (setf (netconn-inbox c) '()))))))
    (dolist (bytes chunks)
      (let* ((n (length bytes)) (buf (netconn-buf c)))
        (when (> (+ (netconn-end c) n) (length buf))
          ;; compact, and grow if still short
          (let* ((live (- (netconn-end c) (netconn-start c)))
                 (nb (if (> (+ live n) (length buf))
                         (make-array (max (* 2 (length buf)) (+ live n)) :element-type '(unsigned-byte 8))
                         buf)))
            (replace nb buf :start2 (netconn-start c) :end2 (netconn-end c))
            (setf (netconn-buf c) nb (netconn-start c) 0 (netconn-end c) live buf nb)))
        (replace buf bytes :start1 (netconn-end c))
        (incf (netconn-end c) n)))))

(defun %mark-pending (c)
  ;; with *LOCK* held
  (unless (netconn-pending c)
    (setf (netconn-pending c) t)
    (push c *pending*)))

(defun %pop-pending ()
  (%locked (let ((c (pop *pending*))) (when c (setf (netconn-pending c) nil)) c)))

(defun %run-on-data (c)
  "Run C's ON-DATA, unless it is already running (on any thread): then that run goes once
   more when it finishes, so no input is left unseen."
  (when (%locked (cond ((null (netconn-on-data c)) nil)
                       ((netconn-busy c) (setf (netconn-again c) t) nil)
                       (t (setf (netconn-busy c) t (netconn-again c) nil) t)))
    (let ((done nil))
      (unwind-protect
           (loop
             (let ((fn (netconn-on-data c)))
               (when fn (funcall fn c)))
             (when (%locked (if (netconn-again c)
                                (progn (setf (netconn-again c) nil) nil)
                                (progn (setf (netconn-busy c) nil) t)))
               (setf done t)
               (return)))
        (unless done (%locked (setf (netconn-busy c) nil)))))))

(defun conn-kick (c)
  "Run C's ON-DATA now, on this thread, for input that may already be buffered (as after
   setting it)."
  (%run-on-data c))

(defun %deliver (ev)
  "File one event (with *RX-LOCK* held)."
  (case (first ev)
    (:wake)                               ; %NET-WAKE: only to end a wait
    (:connected
     (%locked (let ((c (gethash (second ev) *conns*)))
                (when (and c (eq (netconn-state c) :connecting))
                  (setf (netconn-state c) :open)))))
    (:error
     (%locked (let ((c (gethash (second ev) *conns*)))
                (if (and c (eq (netconn-state c) :connecting))
                    (setf (netconn-state c) :failed (netconn-error c) (third ev)
                          (netconn-eof c) t)
                    (setf (gethash (second ev) *replies*) ev)))
              (remhash (second ev) *conns*)))
    (:data (%locked (let ((c (gethash (second ev) *conns*)))
                      (when c (push (third ev) (netconn-inbox c)) (%mark-pending c)))))
    (:eof (%locked (let ((c (gethash (second ev) *conns*)))
                     (when c (setf (netconn-eof c) t) (remhash (second ev) *conns*) (%mark-pending c)))))
    (:accept
     (let ((nc (make-netconn :id (third ev) :host (fourth ev) :port (fifth ev)))
           (fn (%locked (gethash (second ev) *listeners*))))
       (%locked (setf (gethash (third ev) *conns*) nc))
       (if fn
           (handler-case (funcall fn nc)
             (serious-condition (e)
               (format t "~&[net] accept handler error: ~a~%" e) (force-output)))
           (net-close nc))))
    (t (%locked (setf (gethash (second ev) *replies*) ev)))))

(defun %net-drain (timeout)
  "bobbin's owner loop drains the net layer through this (a SOURCE, added below): wait up to
   TIMEOUT seconds for the first event, then take every event already waiting, and run the
   ON-DATA of every connection with new input -- so handlers -- and listeners' accept
   functions.  T if anything happened.  On SBCL several threads may pump at once (the source
   is :ANY-THREAD): one takes the events, and all of them run waiting connections' ON-DATA, so
   the work spreads over the waiting threads.  On the owner TIMEOUT is 0 (bobbin's pump waits)."
  (if (null *from-net*)
      (progn (when (plusp timeout) (sleep timeout)) nil)
      (let ((any nil) (received nil))
        (flet ((receive ()
                 (setf received t)
                 (multiple-value-bind (ev ok) (bob:channel-receive *from-net* :timeout timeout)
                   (loop while ok do
                     (unless (eq (first ev) :wake) (setf any t))
                     (%deliver ev)
                     (multiple-value-setq (ev ok) (bob:channel-try-receive *from-net*))))))
          (cond ((sb-thread:holding-mutex-p *rx-lock*) (receive))      ; pumping inside a handler
                ((sb-thread:grab-mutex *rx-lock* :waitp nil)
                 (unwind-protect (receive) (sb-thread:release-mutex *rx-lock*)))))
        (loop (let ((c (%pop-pending)))
                (unless c (return))
                (setf any t)
                (%run-on-data c)))
        (when (and (not received) (not any) (plusp timeout))
          (sleep (min timeout 0.002)))     ; another thread is taking the events
        any)))

(defun %net-wake ()
  "Make a %NET-DRAIN waiting on the event channel return (bobbin calls it, from any thread, when
   a message reaches the owner's inbox while the owner waits here)."
  (let ((ch *from-net*)) (when ch (bob:channel-send ch (list :wake) :timeout 0))))

(defun net-listen (host port on-accept)
  "Listen on HOST:PORT (0 = any free port); call ON-ACCEPT with each new NETCONN, on the
   thread that pumps.  Returns (values port-bound listener-id)."
  (let* ((id (%locked (incf *next-id*)))
         (r (%request (list :listen id host port))))
    (when (eq (first r) :error) (error "listen on ~a:~d failed: ~a" host port (third r)))
    (%locked (setf (gethash id *listeners*) on-accept))
    (values (third r) id)))

(defun net-unlisten (listener-id)
  "Stop listening (the id NET-LISTEN returned as its second value)."
  (%locked (remhash listener-id *listeners*))
  (when *net-thread* (bob:channel-send *to-net* (list :close listener-id))))

(defun net-connect-start (host port &key (timeout 15) proxy)
  "Start connecting to HOST:PORT and return at once: a NETCONN in state :CONNECTING, which
   becomes :OPEN or :FAILED (NETCONN-ERROR says why; after TIMEOUT seconds at the latest)
   as the owner pumps.  Writes before it is open are queued by nobody: wait for :OPEN.
   NET-CLOSE gives the dial up.

   PROXY, a list (PROXY-HOST PROXY-PORT &optional USER PASSWORD), reaches HOST:PORT through
   that SOCKS5 proxy instead: the net thread connects to the proxy and does the SOCKS5
   handshake (HOST sent as a name, resolved by the proxy), all within TIMEOUT, and the
   connection is :OPEN once the proxy has connected it -- an ordinary connection from then
   on.  USER/PASSWORD are offered as RFC 1929 credentials (Tor isolates streams by them)."
  (let* ((id (%locked (incf *next-id*)))
         (c (make-netconn :id id :host host :port port :state :connecting)))
    (%locked (setf (gethash id *conns*) c))   ; before the reply: data may follow it
    (%send-command (list :connect id host port timeout
                         (and proxy (list (first proxy) (second proxy)
                                          (third proxy) (fourth proxy)))))
    c))

(defun net-connect (host port &key (timeout 15) proxy)
  "A connected NETCONN to HOST:PORT (pumping until it is), or an error.  PROXY: see
   NET-CONNECT-START."
  (let ((c (net-connect-start host port :timeout timeout :proxy proxy)))
    ;; the net thread answers by TIMEOUT; the slack covers a slow channel
    (pump-until (lambda () (not (eq (netconn-state c) :connecting))) :timeout (+ timeout 5))
    (case (netconn-state c)
      (:open c)
      (:failed (error "connect to ~a:~d failed: ~a" host port (netconn-error c)))
      (t (net-close c) (error "connect to ~a:~d failed: the net thread did not answer" host port)))))

;;; ---------------------------------------------------------------------------
;;; Owner tasks
;;; ---------------------------------------------------------------------------

(defun owner-thread-p ()
  "True on the owner thread (the one that started the net layer, or bobbin's owner)."
  (own:owner-p))

(defun add-owner-task (name fn &key (interval 0.05))
  "Call FN (no arguments) on the owner thread every INTERVAL seconds, from PUMP -- so while
   the owner waits for anything.  FN must not wait (see OWNER TASKS above); it is not called
   again while it runs, and an error in it is reported, not raised.  NAME (an EQUAL key)
   replaces a task of that name.  Call it on the owner.  (A bobbin timer, first run at once.)"
  (remove-owner-task name)
  (setf *owner-tasks*
        (append *owner-tasks*
                (list (cons name (own:every-seconds interval fn :name name :first 0)))))
  name)

(defun remove-owner-task (name)
  (let ((e (assoc name *owner-tasks* :test #'equal)))
    (when e
      (own:cancel-timer (cdr e))
      (setf *owner-tasks* (remove e *owner-tasks*))))
  nil)

(defun conn-write (c bytes)
  "Send BYTES on C.  Allowed after EOF has been read: a half-closed peer may still be
   waiting for an answer.  (On a fully closed socket the send fails in the net thread,
   which reports :EOF.)"
  (let* ((v (coerce bytes '(simple-array (unsigned-byte 8) (*)))) (n (length v)))
    (if (<= n +chunk+)
        (%send-command (list :send (netconn-id c) v))
        (loop for off from 0 below n by +chunk+
              do (%send-command (list :send (netconn-id c) (subseq v off (min n (+ off +chunk+)))))))))

(defun net-close (c)
  (setf (netconn-eof c) t)
  (%locked (remhash (netconn-id c) *conns*))
  (when *net-thread* (bob:channel-send *to-net* (list :close (netconn-id c)))))

(defun conn-available (c) (%merge c) (- (netconn-end c) (netconn-start c)))

(defun conn-peek (c offset)
  "The byte at OFFSET into C's buffered input (see CONN-AVAILABLE first)."
  (aref (netconn-buf c) (+ (netconn-start c) offset)))

(defun conn-peek-u32 (c offset)
  "The little-endian u32 at OFFSET into C's buffered input (see CONN-AVAILABLE first)."
  (let ((b (netconn-buf c)) (i (+ (netconn-start c) offset)))
    (logior (aref b i) (ash (aref b (+ i 1)) 8) (ash (aref b (+ i 2)) 16) (ash (aref b (+ i 3)) 24))))

(defvar *conn-deadline* nil
  "When set, an absolute GET-INTERNAL-REAL-TIME past which CONN-READ signals CONN-TIMEOUT
   (the bound on a whole handshake).")

(define-condition conn-timeout (error) ()
  (:report "timed out reading a net-layer connection"))

(defun conn-read (c n)
  "Exactly N bytes from C, pumping until they have arrived; END-OF-FILE if the connection
   closes first, CONN-TIMEOUT past *CONN-DEADLINE*."
  (loop while (< (conn-available c) n) do
    (when (netconn-eof c) (when (< (conn-available c) n) (error 'end-of-file :stream nil)))
    (when (and *conn-deadline* (> (get-internal-real-time) *conn-deadline*))
      (error 'conn-timeout))
    (pump 0.05))
  (let ((out (subseq (netconn-buf c) (netconn-start c) (+ (netconn-start c) n))))
    (incf (netconn-start c) n)
    (when (= (netconn-start c) (netconn-end c)) (setf (netconn-start c) 0 (netconn-end c) 0))
    out))

;;; OWNER-CALL (run a function on the owner, from any thread) is bobbin's: BOBBIN.OWNER:OWNER-CALL,
;;; re-exported with its condition OWNER-CALL-ERROR.  It needs an owner (START-NET makes this
;;; thread bobbin's owner), not a running net thread.
