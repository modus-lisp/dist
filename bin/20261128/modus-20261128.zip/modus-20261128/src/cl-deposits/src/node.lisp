;;;; src/node.lisp — a Deposits node: operator of its own ledgers, cosigning
;;;; member of others', and the counterparty wallets talk to.
;;;;
;;;; One NODE holds one protocol key.  For each ledger it knows it keeps a
;;;; RECORD: the folded state, the full update history (what the fixture
;;;; format is: a list of signed updates), and whether it is ours.  Everything
;;;; arrives and leaves through a BUS (in-process for the gate, Nostr relays
;;;; for the devnet), as DEP-04 events built in wire.lisp.
;;;;
;;;; Message flows implemented here, all matching the reference node's request
;;;; and response fields:
;;;;   operator  -> members : cosign_update {sequence_number, cosign_data_hex,
;;;;                          content_hash_hex} ; reply {cosign_signature_hex,
;;;;                          cosigner_pubkey, sequence_number, member_ledger_hash_hex}
;;;;   operator  -> member  : consent_request {operator_pubkey, operator_ledger_id,
;;;;                          ledger_history[], chosen_ruleset, terms...} ; reply
;;;;                          {status CONSENT_GRANTED, consent_signature,
;;;;                          membership_expires, member_response, member_signature}
;;;;   wallet    -> operator: deposit_open, balance_query, transfer_lock,
;;;;                          transfer_complete, onchain_credit (devnet helper)

(defpackage #:cl-deposits.node
  (:use #:cl #:cl-deposits.util)
  (:local-nicknames (#:cf #:cl-deposits.conformance) (#:up #:cl-deposits.update) (#:op #:cl-deposits.operation)
                    (#:lg #:cl-deposits.ledger) (#:d17 #:cl-deposits.dep17)
                    (#:rs #:cl-deposits.reserves) (#:w #:cl-deposits.wire)
                    (#:bus #:cl-deposits.bus) (#:ev #:cl-nostr.event) (#:flt #:cl-nostr.filter)
                    (#:k #:cl-nostr.keys) (#:tlv #:cl-deposits.tlv) (#:ln #:cl-deposits.lightning)
                    (#:fr #:cl-deposits.fraud) (#:lot #:cl-deposits.lottery) (#:rot #:cl-deposits.rotation)
                    (#:d16 #:cl-deposits.dep16)
                    (#:btx #:cl-consensus.tx) (#:bw #:cl-consensus.wire)
                    (#:schnorr #:secp256k1-fast.schnorr) (#:own #:cl-deposits.owner))
  (:export #:node #:make-node #:node-pubkey #:node-pubkey-hex #:node-ledgers #:node-log
           #:record #:record-ledger #:record-history #:record-owned-p #:record-id-hex #:record-reserves
           #:find-record #:own-ledger
           #:open-ledger #:append-operation #:add-member #:trim-staged #:prepare-quorum #:begin-quorum #:credit-onchain
           #:node-chain-fn #:node-pledge-fn #:lottery-armers #:split-armers #:eligibility-floor-sats #:node-min-confs #:node-data-dir #:record-pinned #:height #:tip
           #:node-error #:request #:wallet #:make-wallet #:wallet-pubkey #:wallet-request
           #:wallet-open-deposit #:wallet-balance #:wallet-transfer #:wallet-complete-transfer #:wallet-exit #:wallet-exit-cancel #:wallet-migrate #:wallet-make-offer #:wallet-complete-offer #:address->spk
           #:wallet-make-invoice #:wallet-pay-invoice #:credit-paid-invoices #:settle-pending-payments #:start-invoice-poller #:node-ln #:node-invoices
           #:enter-dispute #:arm-dispute #:fork-key #:find-fork #:forks-of #:armers-of #:disputed-reserves
           #:rotate-vault #:pending-rotation #:build-confiscation #:confiscate #:publish-reveal #:reveals-of #:claim-or-yield #:node-broadcast-fn
           #:node-broadcasts #:broadcast-fraud #:record-fork-p #:record-preimage #:record-lottery #:record-confiscation
           #:node-height-of-block #:fork-live-p #:live-fork #:fork-summaries #:equivocate #:node-spender-fn #:drive-vault-watch #:node-reported-vault-spend
           #:check-expired-quorums #:collateral-floor-sats #:follow-ledger #:wallet-escalate #:node-ignore-actions #:wallet-request-hash #:wallet-lock-to
           #:node-hooks #:add-hook #:wallet-pending-lock #:completion-satisfied-p #:node-busy
           #:save-record #:load-record #:load-data-dir #:stop-node #:lottery-seed #:*cosign-timeout* #:*cosign-response-seconds* #:*drive-dispute-async* #:inbox-depths #:catch-up #:catch-up-all #:fail-expired-transfers #:start-transfer-timeout-poller #:node-adversary
           #:dispute-expired-quorums #:start-expiry-watch #:*expiry-grace-blocks*
           #:required-replacement-sats #:pledge-collateral #:release-pledges #:our-utxos #:node-pledges
           #:drive-disputes #:dispute-arm-closes #:outpoint-key #:save-pledges
           #:vault-spend #:build-vault-theft))
(in-package #:cl-deposits.node)

(define-condition node-error (error)
  ((detail :initarg :detail :reader detail))
  (:report (lambda (c s) (format s "node: ~a" (detail c)))))
(defun fail (fmt &rest args) (error 'node-error :detail (apply #'format nil fmt args)))

(defparameter *cosign-timeout* 10 "Seconds to wait for a cosignature quorum.")
(defparameter *cosign-response-seconds* 30
  "DEP-05 cosign_response_seconds (advisory): how long a member has to answer a cosign request,
   and so the least an operator waits before calling a round short.")
(defparameter *cosign-round-keep* (* 30 60)
  "Seconds a round that fell short is kept for late answers and retries (DEP-05 §Cosign Rounds).")

(defstruct record
  id-hex ledger (history '()) owned-p reserves
  pinned                                       ; (reserves . expiry) prepared for the next QuorumBegin
  fork-p fork-of fork-operator                 ; a dispute fork: of which ledger, signed by whom
  last-event-id                                ; Nostr id of the last update we published
  (persisted 0)                                ; how many history entries the file on disk holds (append-only save)
  (append-lock nil)                            ; unused: one append at a time is OWN:WITH-OWNER-LOCK (APPEND-OPERATION)
  ;; One writer at a time on a replica: the replica lane, a cosign or consent request and a
  ;; rotation check each caught up the same record from their own threads, applied the same
  ;; update twice, and the doubled balance read as a cl operator's BalanceCommitmentMismatch
  ;; (signet soak, 2026-10-30).  Recursive: catch-up applies through ACCEPT-UPDATE.
  (apply-lock nil)                             ; unused: one writer is OWN:WITH-OWNER-LOCK (WITH-REPLICA-WRITER)
  preimage lottery confiscation                ; our lottery secret; the built lottery; the confiscation tx
  rotation                                     ; broadcast rotation awaiting its QuorumBegin (plist; persisted)
  (offers (make-hash-table :test #'equalp))    ; DEP-10 funding offers we made: offer id -> plist
  ;; Kept current by RECORD-PUSH, so steady-state questions cost what changed, not the chain's
  ;; length (a soaked ledger is ~200k updates).  A fork's history is its own updates consed onto
  ;; its base's history at the fork point (shared, never copied); its indexes hold its own
  ;; updates and read the rest through FORK-BASE up to FORK-SEQ.
  (count 0)                                    ; (length history), without walking it
  (index (make-hash-table :test #'eq))         ; operation type -> this record's own updates of it, newest first
  (by-hash (make-hash-table :test #'equalp))   ; chain hash -> this record's own update's sequence
  (by-seq (make-hash-table))                   ; sequence -> this record's own update
  fork-base fork-seq                           ; a fork or view: the record it inherits from, through which sequence
  (checkpoints '())                            ; ((seq . ledger snapshot) ...) newest first, for LEDGER-AT; each made by replay
  (file-base 0)                                ; history entries not in this record's file (a fork's inherited prefix)
  (ckpt-mismatches 0)                          ; checkpoints whose replay disagreed with the live state (a bug of ours)
  (ckpt-events '())                            ; messages for the node's log, drained by SAVE-RECORD
  (ckpt-persisted -1))                         ; the sequence of the checkpoint last written to disk                               ; history entries not in this record's file (a fork's inherited prefix)

(defmacro with-replica-writer ((rec) &body body)
  "One writer at a time on a replica (see the record's apply-lock note): re-entrant for the task
   writing it (catch-up applies through ACCEPT-UPDATE); another task's write, suspended in a wait,
   makes this one run again later (OWN:OWNER-BUSY)."
  `(own:with-owner-lock ((list :apply ,rec)) ,@body))

(defstruct (node (:constructor %make-node))
  priv pubkey pubkey-hex keypair bus network
  (ledgers (make-hash-table :test #'equal :synchronized t))    ; ledger id hex -> record (both lanes add records)
  (pending (make-hash-table :test #'equal :synchronized t))    ; request event id -> waiter
  ;; DEP-05 §Cosign Rounds: cosign_data -> cosign-round, kept past the deadline, and the
  ;; request ids whose (late) answers feed each one.
  (cosign-rounds (make-hash-table :test #'equalp :synchronized t))
  (late-cosign-requests (make-hash-table :test #'equal :synchronized t))
  ;; DEP-06 Phase 4 re-arm signatures, kept like late cosignatures: request event id -> the
  ;; sighash it asked about, and sighash hex -> ((voter-xonly . signature) ...) collected so far.
  ;; A voter's answer can take longer than the 30 s wait (its worker is behind slow dispute work),
  ;; and every proposer dropped every late answer: d5880288 and a2d44d7a sat at "only 1 of 3 re-arm
  ;; signatures" while all three voters signed on every pass (signet soak, 2026-11-11).
  (rearm-late-requests (make-hash-table :test #'equal :synchronized t))
  (rearm-sigs (make-hash-table :test #'equal :synchronized t))
  ;; DEP-03 "When the set is final": ledger id -> the block its confiscation confirmed in.
  (confiscation-heights (make-hash-table :test #'equal :synchronized t))
  ;; ledger id -> the height we last asked the chain for C and it had no answer (CONFISCATION-HEIGHT)
  (confiscation-height-probes (make-hash-table :test #'equal :synchronized t))
  (lock (bt:make-lock "node"))
  (height-fn (lambda () 0))
  (log '())
  data-dir
  (inbox '()) (inbox-lock (bt:make-lock "inbox")) (inbox-cv (bt:make-condition-variable)) (worker nil) (busy nil)
  ;; The replica lane: other operators' updates and their cosign requests, in
  ;; arrival order.  Neither ever waits on anyone, but an operator request does
  ;; (up to 3 rounds of *cosign-timeout*), and every node here is both an
  ;; operator and a cosigner.  On one queue the four cl nodes convoy: each sits
  ;; in wait-for while the others' cosign requests age behind it, and under load
  ;; no operator ever completes a round (the soak's 50% failure rate).  Cosigns
  ;; alone on the lane are not enough: a cosigner whose replica is behind
  ;; refuses ("expected seq N"), so the updates it chains onto must arrive on the
  ;; same lane ahead of it.  Owned ledgers are never replicas, so the two lanes
  ;; mutate disjoint records.
  (fast-inbox '()) (fast-lock (bt:make-lock "cosign-inbox")) (fast-cv (bt:make-condition-variable)) (fast-worker nil)
  (subscription nil)                           ; our bus handler, so STOP-NODE can remove it
  (seen (make-hash-table :test #'equal :synchronized t)) (seen-order '())   ; event ids already handled (relays redeliver)
  (not-ours (make-hash-table :test #'equal :synchronized t))   ; ledger id -> retry-after, for refollow-if-member
  (loading nil)                                ; T until LOAD-DATA-DIR has run: the worker lanes wait
  (ln nil)                                     ; a cl-deposits.lightning backend, or NIL
  (broadcast-fn nil)                           ; (lambda (tx-bytes)) -> txid or NIL; NIL = collect only
  (broadcasts '())                             ; what we would have broadcast (newest first)
  (height-of-block nil)                        ; (lambda (hash32)) -> height or NIL (fraud-proof anchors)
  (block-hash-fn nil)                          ; (lambda (height)) -> hash32 or NIL (TransferFail anchors)
  (reveals (make-hash-table :test #'equal :synchronized t))    ; ledger id hex -> alist (member-pubkey33 . preimage)
  ;; DEP-06 Phase 4 (re-arm, provisional): ledger id hex -> the re-arm rounds whose lottery
  ;; output we have seen on chain, newest first: plists (:round r :tx tx :height h).
  (rearms (make-hash-table :test #'equal :synchronized t))
  (relays '())                                 ; relay URLs, for advertisements
  (ignore-actions '())                         ; testing: wallet actions the operator silently drops
  (adversary '())                              ; red team (docs/REDTEAM.md): plist of misbehaviours this node performs on purpose
  (hooks '())                                  ; (lambda (rec update op)) called after every accepted/committed update
  (invoices (make-hash-table :test #'equalp :synchronized t))  ; payment hash -> plist (:rec :deposit-id :amount :bolt11)
  ;; Payment ids a pay_invoice handler is polling right now; SETTLE-PENDING-PAYMENTS
  ;; leaves those to the handler so a lock is never settled twice.
  (ln-polling (make-hash-table :test #'equalp :synchronized t))
  (chain-fn nil)                               ; (lambda (txid vout)) -> plist :value-sats :confirmations, or NIL
  (pledge-fn nil)                              ; (lambda (txid vout scan-from)) -> plist :created :value-sats :spend (DEP-03 cut), or NIL
  (utxos-fn nil)                               ; (lambda (address)) -> list of plists :txid :vout :sats :confirmations
  (pledges (make-hash-table :test #'equal :synchronized t))   ; "txidhex:vout" -> ledger id hex we pledged it to
  (superseded '())                             ; what our superseded forks still hold (NOTE-SUPERSEDED)
  ;; "ledger_disputant" -> that member's updates not on the fork we hold of it (INGEST-MEMBER-UPDATE)
  (side-forks (make-hash-table :test #'equal :synchronized t))
  (dispute-notes (make-hash-table :test #'equal :synchronized t))   ; ledger id -> the last dispute-driver state we logged
  (parent nil)                                 ; a DISPUTE-VIEW's node: whose records judge an arm's grounds
  (grounds-verdicts (make-hash-table :test #'equalp :synchronized t)) ; DisputeEnter chain hash -> (verdict . why)
  (refused (make-hash-table :test #'equal :synchronized t))   ; ledger id -> seq whose update the rules rejected
  (spender-fn nil)                             ; (lambda (from to outpoints)) -> spend plists (:txid :vout :tx :prevouts :block-hash :height)
  (tx-confs-fn nil)                            ; (lambda (txid)) -> confirmations (0 in the mempool), or NIL when unknown
  (tx-fn nil)                                  ; (lambda (txid)) -> (values parsed-tx confirmations), or NIL when unknown
  (feerate-fn nil)                             ; (lambda (height)) -> block feerate (DEP-03 Reference feerate)
  (vault-scanned nil)                          ; the last block height scanned for vault spends
  (reported-vault-spend (make-hash-table :test (quote equal) :synchronized t))
  (migrations-watched (make-hash-table :test (quote equal) :synchronized t)) ; "ledger:seq" -> (:height h :hash b) | :done
  (obligation-proofs (make-hash-table :test (quote equal) :synchronized t))  ; ledger id hex -> verified offer-evidence proof JSON texts
  ;; ledger id hex -> proofs we could not judge yet: our replica was behind the sequence they
  ;; rest on (JUDGE-LATER-P).  Each a plist (:hash :proof :content :needs :at).
  (parked-proofs (make-hash-table :test (quote equal) :synchronized t))
  ;; (ledger id hex . quorum_expiry) -> (next-republish . interval): the QuorumExpired proofs we
  ;; published (CHECK-EXPIRED-QUORUMS), each once, then on backoff or when the relays lost it.
  (expiry-proofs (make-hash-table :test (quote equal) :synchronized t))
  (proof-catch-ups (make-hash-table :test (quote equal) :synchronized t)) ; ledger id hex -> catch-up thread (KICK-PROOF-CATCH-UP)
  ;; ledger id hex -> txids of confiscations we saw confirmed.  Kept apart from the forks: a fork
  ;; forgets its confiscation once the lottery output is spent (the winner's claim), and the vault
  ;; watch must still excuse it.  Persisted in confiscations.txt.
  (known-confiscations (make-hash-table :test (quote equal) :synchronized t))
  ;; ledger id hex -> ((tx . lottery) ...): every confiscation proposal we signed.  Two
  ;; proposers can race (cl and reference); whichever lands is one we verified.
  (signed-confiscations (make-hash-table :test (quote equal) :synchronized t))
  (signed-rotations (make-hash-table :test (quote equal) :synchronized t))   ; ledger id hex -> rotation txids we signed
  (inflight-rotations (make-hash-table :test (quote equalp) :synchronized t)) ; rung-0 txid -> (:rungs signed bytes :qb-height h), rebroadcast and bumped until one confirms
  (spend-answers (make-hash-table :test (quote equal) :synchronized t))   ; ledger id hex -> updates answering spend challenges (Kind 9112)
  ;; DEP-06 §Arm manifests: ledger id hex -> ((round txid-hex arms) ...), arms ((pubkey33 seq) ...)
  (arm-manifests (make-hash-table :test (quote equal) :synchronized t))
  ;; ledger id hex -> proposed confiscation txs we received, signed or not: a proposal we
  ;; refused (a different view of the cut, a fee we would not pick) may be the one that lands.
  (seen-confiscations (make-hash-table :test (quote equal) :synchronized t))
  ;; (accused spent-ledger spend-tx governing-seq) -> (universal-time ok why): one theft yields a proof
  ;; per signer, key parity and operated ledger, and verifying fetches the spent ledger's history
  (vault-spend-verdicts (make-hash-table :test (quote equal) :synchronized t))
  (derelict-watch (make-hash-table :test (quote equal) :synchronized t))
  (reported-derelict (make-hash-table :test (quote equal) :synchronized t))
  (min-confs 1)
  (member-ledger-hex nil))                     ; our own ledger used for QuorumJoin / member_ledger_hash

(defvar *log-file-lock* (bt:make-lock "node.log"))
(defun log! (node fmt &rest args)
  ;; One line per entry: the control socket is line-oriented.  With a data dir it is also
  ;; appended to node.log there, timestamped, so it outlives a restart.
  (let ((line (substitute #\Space #\Newline (apply #'format nil fmt args))))
    (push line (node-log node))
    (when (node-data-dir node)
      (ignore-errors
       (bt:with-lock-held (*log-file-lock*)
         (with-open-file (s (merge-pathnames "node.log" (node-data-dir node))
                            :direction :output :if-exists :append :if-does-not-exist :create)
           (multiple-value-bind (sec min hr d mo y) (decode-universal-time (get-universal-time) 0)
             (format s "~d-~2,'0d-~2,'0dT~2,'0d:~2,'0d:~2,'0dZ ~a~%" y mo d hr min sec line))))))))

(defun add-hook (node fn) (push fn (node-hooks node)))
(defun extra-actions (node)
  "Actions registered by roles layered on the node (couriers), addressed to us by p tag."
  (or (get (intern (node-pubkey-hex node) :keyword) 'actions)
      (setf (get (intern (node-pubkey-hex node) :keyword) 'actions) (make-hash-table :test #'equal :synchronized t))))
(defun run-hooks (node rec update)
  (let ((o (op:decode-operation (up:update-message update))))
    (dolist (h (node-hooks node)) (handler-case (funcall h rec update o) (error (e) (log! node "hook: ~a" e))))))

(defun make-node (&key priv bus (network "signet") height-fn data-dir chain-fn pledge-fn spender-fn utxos-fn (min-confs 1) ln relays broadcast-fn height-of-block block-hash-fn feerate-fn tx-confs-fn tx-fn)
  (let* ((priv (w:even-y-privkey priv))     ; a pooled copy this node owns
         (pub (up:compressed-pubkey priv))
         (node (gossamer:own (%make-node :priv priv :pubkey pub :pubkey-hex (bytes->hex pub)
                           :keypair (w:nostr-keypair priv) :bus bus :network network
                           :height-fn (or height-fn (lambda () 0)) :data-dir data-dir
                           :chain-fn chain-fn :pledge-fn pledge-fn :spender-fn spender-fn :utxos-fn utxos-fn :min-confs min-confs :ln ln :relays relays
                           :feerate-fn feerate-fn :tx-confs-fn tx-confs-fn :tx-fn tx-fn
                           :broadcast-fn broadcast-fn :height-of-block height-of-block :block-hash-fn block-hash-fn
                           ;; We subscribe below, before the caller loads the data dir.  A
                           ;; cosign request handled then found no record, took the ledger
                           ;; for a replica we had lost, and rebuilt it from the relay: 80k
                           ;; updates, racing the load, through every fork's updates too.
                           :loading (and data-dir t)) priv)))
    ;; On a real relay, events arrive from the relay.  Responses are consumed inline (they only
    ;; wake a waiter); requests and updates go to the node's two lanes (cl-deposits.owner), because
    ;; handling a request may itself wait for responses.  A lane runs on the owner thread, one
    ;; event at a time, and while one waits the other runs (the waits pump).
    (when (bus:bus-async-p bus)
      (let ((ready (lambda () (not (node-loading node)))))   ; see above: the lanes wait for the load
        (setf (node-worker node)
              (own:make-lane :name "cld-worker" :ready ready :run (lambda (item) (declare (ignore item)) (worker-step node)))
              (node-fast-worker node)
              (own:make-lane :name "cld-cosigner" :ready ready :run (lambda (item) (declare (ignore item)) (fast-worker-step node)))))
      (when (typep bus 'bus:chaos-bus)
        (bus:bus-add-idle-hook bus (lambda () (and (null (node-inbox node)) (null (node-fast-inbox node))
                                                   (own:lane-idle-p (node-worker node)) (own:lane-idle-p (node-fast-worker node)))))))
    (setf (node-subscription node)
          ;; SINCE a minute ago: the relay would otherwise replay its whole store
          ;; (tens of thousands of events) into this subscription at every start;
          ;; anything we missed while down, catch-up fetches per ledger on demand.
          (bus:bus-subscribe bus (flt:make-filter :kinds (list w:+kind-update+ w:+kind-request+ w:+kind-response+
                                                              w:+kind-fraud-proof+ w:+kind-lottery-reveal+ w:+kind-rotation-tx+
                                                              w:+kind-spend-challenge+ w:+kind-challenge-answer+)
                                                  :since (if (bus:bus-async-p bus) (- (get-universal-time) 2208988800 60) nil))
                             (lambda (event)
                               (cond ((or (null (node-worker node)) (= (ev:event-kind event) w:+kind-response+))
                                      (handle-event node event))
                                     ((replica-lane-event-p event) (enqueue-fast node event))
                                     (t (enqueue node event))))))
    node))

(defun stop-node (node)
  "Leave the bus and stop the worker: what a process exit does, for tests that
   then rebuild the node from its data dir."
  (bus:bus-unsubscribe (node-bus node) (node-subscription node))
  (when (node-worker node) (own:lane-close (node-worker node)) (setf (node-worker node) nil))
  (when (node-fast-worker node) (own:lane-close (node-fast-worker node)) (setf (node-fast-worker node) nil))
  (setf (node-inbox node) '() (node-fast-inbox node) '())
  (stop-node-work node)
  node)

(defun enqueue (node event)
  (setf (node-inbox node) (append (node-inbox node) (list event)))
  (when (node-worker node) (own:lane-push (node-worker node) :next)))

(defun requeue-on-busy (node event place)
  "A handler refused an owner lock another (suspended) task holds: forget we saw EVENT and put it
   back first in PLACE (:inbox or :fast), so the lane runs it again (OWN:OWNER-BUSY reaches the
   lane runner, which waits a little)."
  (unless (functionp event)
    (bt:with-lock-held ((node-lock node)) (remhash (ev:event-id event) (node-seen node))))
  (if (eq place :inbox) (push event (node-inbox node)) (push event (node-fast-inbox node))))

(defun worker-step (node)
  "The main lane's next event (one lane item per queued event)."
  (let ((event (pop (node-inbox node))))
    (when event
      (setf (node-busy node) t)
      ;; A function is work queued for this lane (KICK-PROOF-CATCH-UP's re-judge).
      (unwind-protect
           (handler-bind ((own:owner-busy (lambda (c) (declare (ignore c)) (requeue-on-busy node event :inbox))))
             (if (functionp event) (ignore-errors (funcall event)) (handle-event node event)))
        (setf (node-busy node) nil)))))

(defun cosign-request-event-p (event)
  (and (= (ev:event-kind event) w:+kind-request+) (equal (w:event-action event) "cosign_update")))

(defun replica-lane-event-p (event)
  "Events the replica lane (the cosigner thread) handles: updates, which it applies to the
   replicas, and the member requests that read a replica and must see it between updates,
   never during one.  rotation_sign rebuilds the ladder from the replica: on the main worker it
   raced the replica lane applying the QuorumBegin it names, read the new vault as the one being
   spent and refused an honest rotation (signet soak, 2026-10-22)."
  (or (= (ev:event-kind event) w:+kind-update+)
      (and (= (ev:event-kind event) w:+kind-request+)
           (member (w:event-action event) '("cosign_update" "rotation_sign") :test #'equal))))

(defun fast-event-ledger (event)
  "The ledger an event on the replica lane concerns, by its 16-hex prefix: an update's d
   tag, a request's l tag."
  (let ((id (if (= (ev:event-kind event) w:+kind-update+) (w:event-d-tag event) (w:event-ledger-id event))))
    (and id (>= (length id) 16) (subseq id 0 16))))

(defun enqueue-fast (node event)
  ;; DEP-05 §Cosign Rounds: a member SHOULD answer cosign requests ahead of other relay
  ;; traffic.  A cosign request goes ahead of everything queued except earlier cosign
  ;; requests and its own ledger's events (the updates it chains onto, see the lane note
  ;; on NODE).  Behind a burst of other ledgers' updates it missed the operator's window.
  (progn
    (setf (node-fast-inbox node)
          (if (cosign-request-event-p event)
              (let* ((inbox (node-fast-inbox node)) (ledger (fast-event-ledger event))
                     (after (position-if (lambda (e) (or (cosign-request-event-p e) (equal (fast-event-ledger e) ledger)))
                                         inbox :from-end t)))
                (if after
                    (append (subseq inbox 0 (1+ after)) (list event) (nthcdr (1+ after) inbox))
                    (cons event inbox)))
              (append (node-fast-inbox node) (list event))))
    (when (node-fast-worker node) (own:lane-push (node-fast-worker node) :next))))

(defun fast-worker-step (node)
  ;; Replicas are applied and read here only; the main lane mutates owned records.
  (let ((event (pop (node-fast-inbox node))))
    (when event
      (handler-bind ((own:owner-busy (lambda (c) (declare (ignore c)) (requeue-on-busy node event :fast))))
        (handle-event node event)))))

(defun inbox-depths (node)
  "(:inbox N :cosign-inbox N) — how far behind the two lanes are."
  (list :inbox (length (node-inbox node)) :cosign-inbox (length (node-fast-inbox node))))

;; A height fn answers NIL while the chain height is UNKNOWN (bitcoind has not answered a
;; getblockcount since the node started).  HEIGHT keeps answering 0 then, as it always did, for
;; the many comparisons that merely wait on the chain; anything that STAMPS a height into what we
;; sign or publish uses KNOWN-HEIGHT, which refuses instead (signet soak, 2026-11-20: a pool node
;; woken while bitcoind rejected RPCs ran add-member at "height 0" and staged membership_until
;; 4320 at height ~11050, so the quorum was born expired).
(defun height-known-p (node) (and (funcall (node-height-fn node)) t))
(defun height (node) (or (funcall (node-height-fn node)) 0))
(defun known-height (node)
  (or (funcall (node-height-fn node))
      (fail "chain height unknown: bitcoind has not answered getblockcount since we started; retry")))
(defun find-record (node id-hex) (gethash id-hex (node-ledgers node)))
(defun own-ledger (node) (and (node-member-ledger-hex node) (find-record node (node-member-ledger-hex node))))
(defun tip (rec) (car (record-history rec)))

;;; ---------------------------------------------------------------------------
;;; Record indexes.  Every update a record gains goes through RECORD-PUSH, which keeps the
;;; counts, the per-type index, the by-sequence table and the ledger checkpoints.  A full walk
;;; of a history is for startup and recovery only, and LEDGER-AT logs one when it has to.

(defparameter *checkpoint-every* 1024 "Snapshot the ledger state every this many updates.")
(defparameter *checkpoint-recent* 8192 "Keep every snapshot this close to the tip ...")
(defparameter *checkpoint-sparse* 32768 "... and, further back, one per this many updates.")

;;; A checkpoint is made by replay, never copied from the live state.  The live state is kept
;;; up to date update by update, through code that has had bugs a replay does not share: on
;;; 2026-10-30 a replica caught up from three threads, applied a transfer twice, and published a
;;; false proof from the doubled balance.  So every *CHECKPOINT-EVERY* updates the segment since
;;; the previous checkpoint is replayed from that checkpoint and compared with the live state.  A
;;; difference is our own fault: the live state is replaced by the replay, the event is logged and
;;; counted, and no one is accused.  Verifying a proof before publishing it starts from these
;;; checkpoints (VERIFIED-LEDGER-AT), never from the live state.  Cost: one replay of
;;; *CHECKPOINT-EVERY* updates and two encodings per checkpoint.

(defvar *replaying* nil
  "True while a record is being rebuilt from its file in order (LOAD-RECORD): the live state is
   itself a replay then, so a checkpoint is taken from it without replaying the segment again.")

(defun replay-to-checkpoint (rec seq)
  "REC's ledger after SEQ, replayed from its newest checkpoint below SEQ (from genesis when it has
   none).  NIL when an update in between is missing."
  (let* ((cp (find-if (lambda (c) (< (car c) seq)) (record-checkpoints rec)))
         (l (if cp (lg:copy-ledger (cdr cp)) (lg:make-ledger))))
    (loop for s from (if cp (1+ (car cp)) 0) to seq
          for u = (record-update-at rec s)
          do (if u (lg:apply-update l u) (return-from replay-to-checkpoint nil)))
    l))

(defun take-checkpoint (rec seq)
  "Replay REC to SEQ from its previous checkpoint, compare with the live state, keep the replay."
  (let ((live (record-ledger rec)))
    (if (or *replaying* (record-fork-p rec) (record-fork-base rec))
        ;; A load is a replay already.  A fork's state starts from its fork point with the quorum
        ;; cleared, which a replay of its history does not reproduce: its checkpoints stay copies.
        (push (cons seq (lg:copy-ledger live)) (record-checkpoints rec))
        (let ((r (handler-case (replay-to-checkpoint rec seq)
                   (error (e) (push (format nil "checkpoint ~a at ~a: the replay failed (~a); none taken"
                                            (subseq (record-id-hex rec) 0 8) seq e)
                                    (record-ckpt-events rec))
                     nil))))
          (when r
            (unless (string= (lg:encode-state r) (lg:encode-state live))
              (incf (record-ckpt-mismatches rec))
              (push (format nil "CHECKPOINT MISMATCH on ~a at seq ~a: the live state differs from a replay; replacing it with the replay (our fault, no one accused)"
                            (subseq (record-id-hex rec) 0 8) seq)
                    (record-ckpt-events rec))
              (setf (record-ledger rec) (lg:copy-ledger r)))
            (push (cons seq r) (record-checkpoints rec)))))
    (prune-checkpoints rec seq)))

(defun verified-ledger-at (rec seq)
  "A fresh copy of REC's ledger after SEQ, replayed from its newest checkpoint at or below SEQ:
   never the live state.  For judging a proof before we publish it."
  (cond ((and (record-fork-base rec) (<= seq (record-fork-seq rec))) (verified-ledger-at (record-fork-base rec) seq))
        (t (let* ((cp (find-if (lambda (c) (<= (car c) seq)) (record-checkpoints rec)))
                  (l (if cp (lg:copy-ledger (cdr cp)) (lg:make-ledger))))
             (unless cp
               (push (format nil "verify: ~a replayed from genesis to ~a (no checkpoint)" (subseq (record-id-hex rec) 0 8) seq)
                     (record-ckpt-events rec)))
             (loop for s from (if cp (1+ (car cp)) 0) to seq
                   do (lg:apply-update l (or (record-update-at rec s) (fail "ledger ~a has no update ~a" (subseq (record-id-hex rec) 0 8) s))))
             l))))

(defun prefix-ledger-fn (rec)
  "For FR:VERIFY-PROOF: the ledger after PREFIX (oldest first), from REC's checkpoints when
   PREFIX ends in the very update REC holds at that sequence; otherwise (another branch, or no
   record) a replay of PREFIX from genesis."
  (lambda (prefix)
    (let* ((last-u (car (last prefix)))
           (ours (and last-u rec (not (record-fork-p rec)) (record-update-at rec (up:update-seq last-u)))))
      (cond ((null prefix) (lg:make-ledger))
            ((and ours (equalp (up:chain-hash ours) (up:chain-hash last-u)))
             (verified-ledger-at rec (up:update-seq last-u)))
            (t (lg:replay prefix))))))

(defun prune-checkpoints (rec tip-seq)
  (setf (record-checkpoints rec)
        (remove-if-not (lambda (c) (or (<= (- tip-seq (car c)) *checkpoint-recent*)
                                       (zerop (mod (car c) *checkpoint-sparse*))))
                       (record-checkpoints rec))))

(defvar *verify-indexes* nil
  "Gates: after every Nth push, check the record's indexes against a from-scratch scan of its
   history (and LEDGER-AT against a replay).  Mismatches are collected in *INDEX-MISMATCHES*.")
(defvar *verify-every* 7)
(defvar *index-verifications* 0)
(defvar *index-mismatches* '())

(defun verify-record-indexes (rec)
  (incf *index-verifications*)
  (flet ((bad (fmt &rest args) (push (apply #'format nil fmt args) *index-mismatches*)))
    (let* ((hist (record-history rec))
           (types (let ((h (make-hash-table))) (dolist (u hist) (setf (gethash (op:update-type u) h) t))
                    (loop for k being the hash-keys of h collect k))))
      (unless (= (record-count rec) (length hist))
        (bad "~a: count ~a, history ~a" (subseq (record-id-hex rec) 0 8) (record-count rec) (length hist)))
      (dolist (ty (union types '(:quorum-begin :dispute-enter :dispute-armed :dispute-acquire :obligation-record)))
        (let ((want (remove-if-not (lambda (u) (eq (op:update-type u) ty)) hist))
              (got (record-updates-of rec ty)))
          (unless (and (= (length want) (length got)) (every #'eq want got))
            (bad "~a: index of ~a holds ~a, the history ~a" (subseq (record-id-hex rec) 0 8) ty (length got) (length want)))))
      (dolist (u hist)
        (unless (eq (record-update-at rec (up:update-seq u)) (find (up:update-seq u) hist :key #'up:update-seq))
          (bad "~a: update-at ~a" (subseq (record-id-hex rec) 0 8) (up:update-seq u))))
      ;; chain hash -> sequence, for a record whose ledger follows its history (not a scratch fork)
      (when (and hist (= (lg:ledger-sequence (record-ledger rec)) (up:update-seq (first hist))))
        (dolist (u (if (record-fork-base rec)
                       (loop for u in hist while (> (up:update-seq u) (record-fork-seq rec)) collect u)
                       hist))
          (unless (eql (record-seq-of-hash rec (up:chain-hash u)) (up:update-seq u))
            (bad "~a: seq-of-hash ~a" (subseq (record-id-hex rec) 0 8) (up:update-seq u)))))
      ;; LEDGER-AT against a replay of the prefix, for a base record (a fork's own state starts from
      ;; its fork point with the quorum cleared, which a replay from genesis does not do)
      (when (and hist (not (record-fork-base rec)) (not (record-fork-p rec)) (zerop (up:update-seq (car (last hist)))))
        (let* ((seq (up:update-seq (nth (random (length hist)) hist)))
               (a (ignore-errors (ledger-at rec seq)))
               (b (ignore-errors (lg:replay (reverse (remove-if (lambda (u) (> (up:update-seq u) seq)) hist))))))
          (when (and b (not (and a (= (lg:ledger-sequence a) (lg:ledger-sequence b))
                                 (equalp (lg:ledger-chain-tip a) (lg:ledger-chain-tip b))
                                 (equalp (lg:ledger-quorum-members a) (lg:ledger-quorum-members b))
                                 (= (lg:ledger-reserves-amount a) (lg:ledger-reserves-amount b))
                                 (= (hash-table-count (lg:ledger-deposits a)) (hash-table-count (lg:ledger-deposits b)))
                                 (loop for k being the hash-keys of (lg:ledger-deposits b) using (hash-value d)
                                       always (let ((e (gethash k (lg:ledger-deposits a))))
                                                (and e (= (lg:deposit-balance e) (lg:deposit-balance d))
                                                     (= (lg:deposit-locked-balance e) (lg:deposit-locked-balance d))))))))
            (bad "~a: ledger-at ~a differs from a replay" (subseq (record-id-hex rec) 0 8) seq)))))))

(defun record-push (rec u)
  "Append U (already applied to REC's ledger) to REC's history and indexes."
  (ensure-indexed rec)
  (push u (record-history rec))
  (incf (record-count rec))
  (push u (gethash (op:update-type u) (record-index rec)))
  (setf (gethash (up:update-seq u) (record-by-seq rec)) u)
  (let ((seq (up:update-seq u)) (l (record-ledger rec)))
    ;; the chain hash is the ledger's tip once U is applied (a scratch fork with no state: none)
    (when (= seq (lg:ledger-sequence l)) (setf (gethash (lg:ledger-chain-tip l) (record-by-hash rec)) seq))
    (when (and (zerop (mod seq *checkpoint-every*)) (= seq (lg:ledger-sequence (record-ledger rec))))
      (take-checkpoint rec seq)))
  (when (and *verify-indexes* (zerop (mod (record-count rec) *verify-every*))) (verify-record-indexes rec))
  u)

(defun index-record (rec)
  "Rebuild REC's indexes from its history (a record built from a list, not pushed).  O(length)."
  (let ((own (if (record-fork-base rec)
                 (loop for u in (record-history rec) while (> (up:update-seq u) (record-fork-seq rec)) collect u)
                 (record-history rec))))
    (clrhash (record-index rec)) (clrhash (record-by-seq rec)) (clrhash (record-by-hash rec))
    (dolist (u (reverse own))
      (push u (gethash (op:update-type u) (record-index rec)))
      (setf (gethash (up:update-seq u) (record-by-seq rec)) u)
      (setf (gethash (up:chain-hash u) (record-by-hash rec)) (up:update-seq u)))
    (setf (record-count rec) (length (record-history rec))))
  rec)

(defun ensure-indexed (rec)
  "A record built from a list rather than pushed (tests, scratch views) is indexed on first use."
  (when (and (zerop (record-count rec)) (record-history rec)) (index-record rec))
  rec)

(defun record-update-at (rec seq)
  "REC's update at sequence SEQ, or NIL."
  (ensure-indexed rec)
  (or (gethash seq (record-by-seq rec))
      (and (record-fork-base rec) (<= seq (record-fork-seq rec))
           (record-update-at (record-fork-base rec) seq))))

(defun record-seq-of-hash (rec hash)
  "The sequence of REC's update whose chain hash is HASH, or NIL."
  (or (gethash hash (record-by-hash rec))
      (and (record-fork-base rec)
           (let ((s (record-seq-of-hash (record-fork-base rec) hash))) (and s (<= s (record-fork-seq rec)) s)))))

(defun record-updates-of (rec type)
  "REC's updates of operation TYPE, newest first: its own, then (a fork or view) its base's
   through the fork point.  Shared structure: do not modify."
  (ensure-indexed rec)
  (let ((own (gethash type (record-index rec))) (base (record-fork-base rec)))
    (if base
        (let ((inherited (member-if (lambda (u) (<= (up:update-seq u) (record-fork-seq rec)))
                                    (record-updates-of base type))))
          (if own (append own inherited) inherited))
        own)))

(defun record-latest (rec type &key (below most-positive-fixnum) test)
  "REC's newest update of TYPE with sequence below BELOW (and satisfying TEST), or NIL."
  (find-if (lambda (u) (and (< (up:update-seq u) below) (or (null test) (funcall test u))))
           (record-updates-of rec type)))

(defvar *rescan-log* nil "(lambda (fmt &rest args)) told about every full rescan LEDGER-AT makes.")

(defun ledger-at (rec seq)
  "A fresh copy of REC's ledger as it stood after sequence SEQ: from the nearest checkpoint at or
   below SEQ, replaying only what follows it.  Callers may modify the result."
  (let ((tip (lg:ledger-sequence (record-ledger rec))))
    (cond ((= seq tip) (lg:copy-ledger (record-ledger rec)))
          ((> seq tip) (fail "ledger ~a is at ~a, not ~a" (subseq (record-id-hex rec) 0 8) tip seq))
          ((and (record-fork-base rec) (<= seq (record-fork-seq rec))) (ledger-at (record-fork-base rec) seq))
          (t (let* ((cp (find-if (lambda (c) (<= (car c) seq)) (record-checkpoints rec)))
                    (l (if cp (lg:copy-ledger (cdr cp)) (lg:make-ledger)))
                    (from (if cp (1+ (car cp)) 0)))
               (when (and *rescan-log* (> (- seq from) *checkpoint-sparse*))
                 (funcall *rescan-log* "rescan: ~a replayed from ~a to ~a (no checkpoint)" (subseq (record-id-hex rec) 0 8) from seq))
               (loop for s from from to seq
                     do (lg:apply-update l (or (record-update-at rec s) (fail "ledger ~a has no update ~a" (subseq (record-id-hex rec) 0 8) s))))
               l)))))

(defun fork-own-segment (fork)
  "FORK's own updates (after its fork point), newest first; all of a scratch fork's."
  (if (record-fork-base fork)
      (loop for u in (record-history fork) while (> (up:update-seq u) (record-fork-seq fork)) collect u)
      (record-history fork)))

(defun fork-own-updates (fork type)
  "FORK's own updates of TYPE (after its fork point; a view or scratch fork with no base: all of
   them), newest first."
  (if (record-fork-base fork) (gethash type (record-index (ensure-indexed fork))) (record-updates-of fork type)))

(defun spent-vault-updates (rec &optional seq)
  "What FR:SPENT-VAULT reads of REC: its LedgerOpen and QuorumBegins (all of them when SEQ is
   NIL, else the one at SEQ), not the whole chain."
  (remove nil (cons (record-update-at rec 0)
                    (if seq (list (record-update-at rec seq)) (record-updates-of rec :quorum-begin)))))

(defun make-view (rec seq &key fork-p fork-operator owned-p ledger)
  "A record that inherits REC's history through SEQ (shared, not copied), with LEDGER (default:
   REC's ledger as it stood after SEQ) and empty own indexes."
  (let* ((skipped 0)
         (history (loop for tail on (record-history rec)
                        while (> (up:update-seq (car tail)) seq) do (incf skipped)
                        finally (return tail)))
         (v (make-record :id-hex (record-id-hex rec) :owned-p owned-p
                         :ledger (or ledger (ledger-at rec seq))
                         :history history
                         :fork-p fork-p :fork-of (and fork-p (record-id-hex rec)) :fork-operator fork-operator
                         :fork-base rec :fork-seq seq)))
    (setf (record-count v) (- (record-count rec) skipped)
          (record-file-base v) (record-count v)
          (record-checkpoints v) (list (cons seq (lg:copy-ledger (record-ledger v)))))
    v))
(defun x-hex (pubkey33) (bytes->hex (up:x-only pubkey33)))

;;; ---------------------------------------------------------------------------
;;; Waiting for responses

(defstruct waiter (lock (bt:make-lock)) (cv (bt:make-condition-variable)) (responses '()) (done nil) want (successes-only nil) (ids '()) (counts nil)
  (settled nil))                               ; (lambda (responses)): nothing more is coming

(defun waiter-count (wt)
  (cond ((waiter-counts wt) (count-if (waiter-counts wt) (waiter-responses wt)))
        ((waiter-successes-only wt) (count-if (lambda (r) (w:jget r "success")) (waiter-responses wt)))
        (t (length (waiter-responses wt)))))

(defun wait-for (node request-id want &key (timeout *cosign-timeout*))
  "Block until WANT responses (or DONE) for REQUEST-ID, or TIMEOUT.  Returns the responses."
  ;; Responses arrive on the owner while it pumps (OWN:WAIT-UNTIL), so this wait lets the
  ;; node's other lanes, the drives and the timers run.
  (let ((wt (gethash request-id (node-pending node))))
    (own:wait-until (lambda () (or (waiter-done wt) (>= (waiter-count wt) want)
                                   (and (waiter-settled wt) (funcall (waiter-settled wt) (waiter-responses wt)))))
                    :timeout timeout :step 0.2)
    (remhash request-id (node-pending node))
    (reverse (waiter-responses wt))))

(defun send-request (node ledger-id-hex action params &key (want 1) (timeout *cosign-timeout*) extra-tags successes-only counts
                                                           settled on-publish)
  "Publish a Kind 20101 request and collect WANT Kind 20102 responses (successful
   ones when SUCCESSES-ONLY; those satisfying COUNTS when given), or stop early once
   SETTLED says no more are coming.  ON-PUBLISH gets the request's event id first."
  (let ((event (w:request-event (node-keypair node) ledger-id-hex action params :extra-tags extra-tags)))
    (setf (gethash (ev:event-id event) (node-pending node))
          (make-waiter :want want :successes-only successes-only :counts counts :settled settled))
    (when on-publish (funcall on-publish (ev:event-id event)))
    (bus:bus-publish (node-bus node) event)
    (wait-for node (ev:event-id event) want :timeout timeout)))

(defun respond (node request success &key result error)
  (bus:bus-publish (node-bus node)
                   (w:response-event (node-keypair node) (ev:event-id request) (w:event-ledger-id request) success
                                     :result result :error error)))

;;; ---------------------------------------------------------------------------
;;; Building and publishing our own updates

(defun new-update (node rec op &key (height (known-height node)))
  "DEP-02 §Block height and hash: dated at our tip but never below the chain's last height (a
   reorganisation that lowered our tip leaves us at that height), and naming a block."
  (let* ((t0 (tip rec))
         (height (max height (if t0 (up:update-block-height t0) 0))))
    (up:make-signed-update :operator-id (node-pubkey node) :ledger-id (hex->bytes (record-id-hex rec))
                           :seq (if t0 (1+ (up:update-seq t0)) 0)
                           :prev-hash (if t0 (up:chain-hash t0) (make-array 32 :element-type '(unsigned-byte 8)))
                           :message (op:encode-operation op) :block-height height
                           :block-hash (block-hash-at node height t0))))

(defun block-hash-at (node height &optional predecessor)
  "The block hash to sign at HEIGHT: PREDECESSOR's when it is at the same height (one block, one
   hash, even after a reorganisation), else our chain's, else (no chain view) a stand-in.  Never
   zero; never judged against anyone's chain (DEP-02)."
  (or (and predecessor (= height (up:update-block-height predecessor))
           (let ((h (up:update-block-hash predecessor))) (and h (not (zero-bytes-p h)) h)))
      (and (node-block-hash-fn node) (ignore-errors (funcall (node-block-hash-fn node) height)))
      (sha256 (ascii->bytes (format nil "deposits: no chain view at height ~a" height)))))

;;; WRITE-AHEAD.  Every update we sign is durable on our disk before any relay sees it, so a node
;;; killed at any point comes back knowing every update of ours that may be out there, and never
;;; signs a second one at that sequence.  Publishing before saving (the order until 2026-11-20)
;;; left a window, kill between the publish and the save, in which the update was on the relays and
;;; not on our disk; the rerun then signed another at the same sequence under a later header.  The
;;; PENDING file closes the other side: an update saved and not yet published is republished, as
;;; the saved bytes, by the next boot (PUBLISH-PENDING).  COMMIT-UPDATE is the only place an update
;;; of ours is signed (EQUIVOCATE, testing only, aside), so the rule lives here.

(defparameter *fsync-operator-updates*
  (let ((v (uiop:getenv "CLD_FSYNC_OPERATOR_UPDATES"))) (and v (member v '("1" "true" "on") :test #'string-equal) t))
  "fsync the write-ahead of an ordinary operator update (CLD_FSYNC_OPERATOR_UPDATES=1 turns it
   on).  OFF by default, measured (inspect/fsync-bench.lisp, 2026-11-20, 300 updates appended to
   a 4000-update ledger, interleaved runs): 0.36 ms per write-ahead without fsync, 984 ms with it
   on the nodes' zfs pool, far past a 20% bar.  A power loss there can lose a published operator
   update; a kill cannot.  Dispute and rotation updates are always fsync'd: a power-loss re-sign
   there is an equivocation, and they are rare.")

(defvar *durable* nil "Bound T around a write that must survive power loss: fsync it.")
(defvar *deferred-saves*)   ; special here, before WRITE-AHEAD binds it (its value: below, at SAVE-RECORD's batch)

(defun fsync-stream (out)
  (finish-output out)
  (sb-posix:fsync (sb-sys:fd-stream-fd out)))

(defun fsync-dir (dir)
  (let ((fd (sb-posix:open (namestring dir) sb-posix:o-rdonly)))
    (unwind-protect (sb-posix:fsync fd) (sb-posix:close fd))))

(defun durable-update-p (rec update)
  "A dispute or rotation update (anything on a fork: DisputeEnter, Armed, Yield, Acquire, residue
   credits; a QuorumBegin; a ledger's continuation after its rotation), or any update when
   *FSYNC-OPERATOR-UPDATES*."
  (or *fsync-operator-updates*
      (record-fork-p rec)
      (member (getf (ignore-errors (op:update-op update)) :type)
              '(:quorum-begin :dispute-enter :dispute-armed :dispute-yield :dispute-acquire))))

(defvar *before-publish-hook* nil
  "Testing: called with NODE REC UPDATE after the write-ahead save and before the publish; a
   non-local exit from it is a node killed in that window.")

(defun pending-path (node rec)
  (merge-pathnames (format nil "pending_~a.b64" (pathname-name (record-file-name rec))) (node-data-dir node)))

(defun write-ahead (node rec update)
  "Make UPDATE (already applied and recorded on REC) durable before it is published: the pending
   file naming it, then the record itself, written now even inside a deferred-save block.
   Returns the pending path, or NIL with no data dir."
  (when (node-data-dir node)
    (ensure-directories-exist (node-data-dir node))
    (let ((pending (pending-path node rec)))
      (with-open-file (out pending :direction :output :if-exists :supersede :external-format :latin-1)
        (write-string (base64-encode (up:encode-update update)) out)
        (when *durable* (fsync-stream out)))
      (when *durable* (fsync-dir (node-data-dir node)))
      (let ((*deferred-saves* nil)) (save-record node rec))
      pending)))

(defun publish-pending (node)
  "Boot: publish, as the saved bytes, every update of ours that was saved and never published (a
   node killed between WRITE-AHEAD and the publish).  A pending update the record does not hold
   was never saved, so never published: it is dropped, and nothing of ours left this node."
  (when (node-data-dir node)
    (dolist (f (directory (merge-pathnames "pending_*.b64" (node-data-dir node))))
      (handler-case
          (let* ((u (up:decode-update (base64-decode (string-trim '(#\Newline #\Return #\Space) (uiop:read-file-string f :external-format :latin-1)))))
                 (id (bytes->hex (up:update-ledger-id u)))
                 (held (some (lambda (rec) (and rec (equalp (ignore-errors (up:encode-update (record-update-at rec (up:update-seq u))))
                                                            (up:encode-update u))))
                             (list (find-record node id) (find-fork node id (node-pubkey node))))))
            (cond (held (bus:bus-publish (node-bus node) (w:update-event (node-keypair node) u))
                        (log! node "published saved update ~a seq ~a (killed before its publish)" (subseq id 0 8) (up:update-seq u)))
                  (t (log! node "dropped pending ~a seq ~a: never saved, so never published" (subseq id 0 8) (up:update-seq u))))
            (delete-file f))
        (error (e) (log! node "pending ~a: ~a" (file-namestring f) e))))))

(defun commit-update (node rec update)
  "Operator-sign, apply, record, persist, publish (WRITE-AHEAD: saved before any relay sees it).
   The update's cosignatures must already be in place."
  (up:sign-operator update (node-priv node))
  (handler-case (lg:apply-update (record-ledger rec) update)       ; signals ledger-error if invalid
    (lg:ledger-error (e)
      ;; ADVERSARY :sign-invalid — an operator that publishes, with its colluders'
      ;; cosignatures, an update its own validator rejects: the chain advances,
      ;; the operation's effect does not (red team #1: what an honest minority
      ;; must catch is exactly this update on the relay).
      (unless (getf (node-adversary node) :sign-invalid) (error e))
      (log! node "ADVERSARY: committing seq ~a on ~a that our validator rejects: ~a"
            (up:update-seq update) (subseq (record-id-hex rec) 0 8) e)
      (setf (lg:ledger-sequence (record-ledger rec)) (up:update-seq update)
            (lg:ledger-chain-tip (record-ledger rec)) (up:chain-hash update))))
  (record-push rec update)
  (let ((pending (let ((*durable* (durable-update-p rec update))) (write-ahead node rec update))))
    (when *before-publish-hook* (funcall *before-publish-hook* node rec update))
    (setf (record-last-event-id rec) (ev:event-id (bus:bus-publish (node-bus node) (w:update-event (node-keypair node) update))))
    (when pending (ignore-errors (delete-file pending))))
  (run-hooks node rec update)
  update)

;;; A DisputeYield of ours is signed at most once per sequence.  The relays may already hold one
;;; our disk does not (killed between the publish and the save, or a node that broadcast without
;;; recording: the Rust loser path until b758991, regtest 1120-next4's ref6), and signing another
;;; there, at a later height, is an equivocation by us.

(defun our-updates-at (node rec seq)
  "Our own updates of REC's ledger at SEQ as the relays hold them: signed by us and verifying,
   distinct by bytes.  A failed query signals."
  (let ((out '()))
    (dolist (u (ledger-updates-from-relays node (record-id-hex rec) :from seq :to seq) out)
      (when (and (= (up:update-seq u) seq) (equalp (up:update-operator-id u) (node-pubkey node))
                 (ignore-errors (up:verify-operator-signature u)))
        (pushnew u out :test #'equalp :key #'up:encode-update)))))

(defun adopt-update (node rec update)
  "Record UPDATE, already signed and published by us, on REC: apply, record, persist.  No
   signing, no publishing: these are the bytes the relays hold."
  (lg:apply-update (record-ledger rec) update)
  (record-push rec update)
  (save-record node rec)
  (run-hooks node rec update)
  update)

(defun fork-yield-evidence-p (fork)
  "FORK's yields are judged under yield-evidence-v9 (its ruleset, the fork point's)."
  (lg:ruleset-rule-p (lg:ledger-active-ruleset (record-ledger fork)) :yield-evidence))

;; Case C5 of the yield-builder audit, ruled 2026-11-24 (option B): an un-armed expiry fork
;; standing down for our punitive dispute of the same ledger yields naming that dispute's
;; DisputeEnter, reason 4 superseded_by (TLV 373: its content hash; DEP-06 "What a yield must say").
(defun stand-down-for-punitive (node expiry superseding)
  "Yield our un-armed expiry fork EXPIRY because our DisputeEnter SUPERSEDING (a signed update, not
   yet committed) of the same ledger supersedes it.  Earlier rulesets: no reason, as before."
  (yield-once node expiry :reason (and (fork-yield-evidence-p expiry)
                                       (list :superseded-by (up:content-hash superseding)))
                          :also (list superseding)))

(defun yield-self-check (node fork reason &key also (height (known-height node)))
  "DEP-06 \"What a yield must say\": our own judge's verdict on the yield REASON (a plist,
   YIELD-ONCE's) we would sign on FORK at HEIGHT: REENTRY-YIELD-VERDICT over the ledger's replica, FORK and ALSO (updates signed and not yet
   committed, as STAND-DOWN-FOR-PUNITIVE's DisputeEnter), on our chain view.  A builder signs only
   on :VALID: :INVALID is never signed or broadcast, :PENDING waits."
  (let* ((base (find-record node (record-fork-of fork)))
         (enter (fork-op fork :dispute-enter))
         (tip (tip fork)))
    (if (not (and enter tip))
        :valid
        (let ((draft (up:make-signed-update
                      :operator-id (node-pubkey node) :ledger-id (up:update-ledger-id tip)
                      :seq (1+ (up:update-seq tip)) :prev-hash (up:chain-hash tip) :block-height height
                      :message (op:encode-operation
                                (append (list :type :dispute-yield)
                                        (loop for k in '(:lost-to :reestablished :excluded-by :superseded-by)
                                              when (getf reason k) append (list k (getf reason k))))))))
          (reentry-yield-verdict (append (and base (reverse (record-history base))) (reverse (record-history fork)) also)
                                 enter draft :chain (node-chain-view node))))))

(defun yield-once (node fork &key reason also)
  "Yield our FORK: adopt the DisputeYield of ours the relays already hold at its next sequence,
   or sign one only when nothing of ours is there.  NIL (and a note) when holding: the query
   failed, or something of ours other than that yield is already at that sequence.  REASON is
   the yield's evidence, a plist of one of :LOST-TO :REESTABLISHED :EXCLUDED-BY (DEP-06 \"What a
   yield must say\"): carried whenever known, and required under yield-evidence-v9, where a yield
   without one is never signed (the fold would refuse it).  Nor one our own judge does not find
   valid (YIELD-SELF-CHECK, ALSO its extra updates): invalid is never signed, pending waits."
  (when (and (fork-yield-evidence-p fork) (/= 1 (count-if (lambda (k) (getf reason k)) '(:lost-to :reestablished :excluded-by :superseded-by))))
    (log! node "yield of ~a held: yield-evidence-v9 needs exactly one reason, have ~s" (subseq (record-id-hex fork) 0 8) reason)
    (return-from yield-once nil))
  (let* ((tip (tip fork)) (seq (if tip (1+ (up:update-seq tip)) 0))
         (ours (handler-case (our-updates-at node fork seq)
                 (error (e) (log! node "yield of ~a held: the relay query failed: ~a" (subseq (record-id-hex fork) 0 8) e)
                   (return-from yield-once nil)))))
    (cond ((and (null ours) (not (eq :valid (yield-self-check node fork reason :also also))))
           (log! node "yield of ~a held: our own judge reads ~s as ~(~a~) (DEP-06 \"What a yield must say\")"
                 (subseq (record-id-hex fork) 0 8) reason (yield-self-check node fork reason :also also))
           nil)
          ((null ours) (commit-update node fork (new-update node fork (append (list :type :dispute-yield)
                                                                               (loop for k in '(:lost-to :reestablished :excluded-by :superseded-by)
                                                                                     when (getf reason k) append (list k (getf reason k)))))))
          ((and (null (rest ours))
                (eq (getf (ignore-errors (op:update-op (first ours))) :type) :dispute-yield)
                (chains-on-p fork (first ours)))
           (log! node "yield of ~a: adopting ours already published at seq ~a" (subseq (record-id-hex fork) 0 8) seq)
           (adopt-update node fork (first ours)))
          (t (log! node "yield of ~a held: ~a update~:p of ours other than its yield at seq ~a"
                   (subseq (record-id-hex fork) 0 8) (length ours) seq)
             nil))))

(defvar *cosign-post-expiry-establishment*
  (let ((v (uiop:getenv "CLD_REFUSE_POST_EXPIRY_ROTATION"))) (not (and v (plusp (length v)) (not (string= v "0")))))
  "Member policy, not protocol (DEP-05 §Cosignature Threshold, ruled 2026-11-14: \"we can allow it,
   but we can't require members to sign\").  T (the default): we cosign, and consent to, a rotation
   of a quorum past its expiry exactly as we would before it, which rescues an operator that missed
   its deadline.  NIL (CLD_REFUSE_POST_EXPIRY_ROTATION=1, or the control port's (:policy ...)): we
   refuse.  Expiry released us; refusing is never a fault.")

(defparameter *cosign-tip-wait-seconds* 10
  "How long a cosigner waits for its tip to reach a proposed height above it (within the tolerance).")

(defparameter *cosign-height-tolerance* 6
  "A cosigner refuses an update whose (signed) block_height is further than this
   from its own chain tip: the height decides the lifecycle tier.")

(defvar *extra-cosign-params* nil
  "Extra (key value ...) for the cosign request of the update being appended (DEP-20 §8.3's manifest).")

;;; DEP-05 §Cosign Rounds.  A cosignature binds cosign_data, not the moment it arrived: one that
;;; reaches us after we stopped waiting still counts for that update.  A round is kept per
;;; cosign_data; late answers land in it (HANDLE-RESPONSE) and a retry of the same update
;;; starts from them.

(defstruct cosign-round (started (get-universal-time)) update signers (cosigs '()) (request-ids '()) (lock (bt:make-lock "round")))

(defun response-cosignature (response)
  "The cosignature a successful cosign_update response carries, or NIL."
  (let ((res (w:jget response "result")))
    (when (and (w:jget response "success") (hash-table-p res) (w:jget res "cosigner_pubkey"))
      (ignore-errors
       (up:make-cosignature :pubkey (hex->bytes (w:jget res "cosigner_pubkey"))
                            :signature (hex->bytes (w:jget res "cosign_signature_hex"))
                            :member-ledger-hash (hex->bytes (w:jget res "member_ledger_hash_hex")))))))

(defun round-add (round c)
  "Keep C if it is a signer's valid cosignature over the round's cosign_data, one per signer."
  (when (and c (member (up:cosig-pubkey c) (cosign-round-signers round) :key #'lg:member-pubkey :test #'equalp)
             (ignore-errors (up:verify-cosignature (cosign-round-update round) c)))
    (bt:with-lock-held ((cosign-round-lock round))
      (unless (member (up:cosig-pubkey c) (cosign-round-cosigs round) :key #'up:cosig-pubkey :test #'equalp)
        (push c (cosign-round-cosigs round))
        t))))

(defun keep-late-cosignature (node data response)
  (let ((round (gethash data (node-cosign-rounds node))))
    (when (and round (round-add round (response-cosignature response)))
      (log! node "late cosignature for seq ~a kept (~a held)" (up:update-seq (cosign-round-update round))
            (length (cosign-round-cosigs round))))))

(defun begin-cosign-round (node update signers)
  "The round for UPDATE's cosign_data: the one kept from an earlier attempt, or a fresh one."
  (let ((rounds (node-cosign-rounds node)) (now (get-universal-time)))
    (sb-ext:with-locked-hash-table (rounds)
      (loop for data being the hash-keys of rounds using (hash-value r)
            when (> (- now (cosign-round-started r)) *cosign-round-keep*)
              do (remhash data rounds)
                 (dolist (id (cosign-round-request-ids r)) (remhash id (node-late-cosign-requests node))))
      (let* ((data (up::cosign-data update))
             (round (or (gethash data rounds)
                        (setf (gethash data rounds) (make-cosign-round :update (up::copy-signed-update update) :signers signers)))))
        (setf (cosign-round-signers round) signers)   ; the requirement may have moved (another tier)
        round))))

(defun end-cosign-round (node update)
  (let ((round (gethash (up::cosign-data update) (node-cosign-rounds node))))
    (when round
      (dolist (id (cosign-round-request-ids round)) (remhash id (node-late-cosign-requests node)))
      (remhash (up::cosign-data update) (node-cosign-rounds node)))))

(defun republish-missed (node rec response)
  "A member that refuses with 'expected seq N' while we hold N has missed our updates N..: the
   relay refused or lost them (a publish is fire-and-forget, so a refused one is never retried).
   Republish them, at most 64, so the member can chain onto them; nothing else would ever send
   them again, and every later update would be refused the same way.  (Signet soak, 2026-11-04:
   a lossy relay rule refused one of ledger I's updates; I stood at that seq for two hours, its
   operator's inbox grew past 75,000 requests, and two other ledgers could not rotate for want of
   its consent.)"
  (let* ((err (and (hash-table-p response) (w:jget response "error")))
         (at (and (stringp err) (search "expected seq " err)))
         (n (and at (parse-integer err :start (+ at 13) :junk-allowed t)))
         (tip (lg:ledger-sequence (record-ledger rec))))
    (when (and n (<= n tip))
      (let ((sent 0))
        (loop for seq from n to (min tip (+ n 63))
              for u = (record-update-at rec seq)
              while u
              do (bus:bus-publish (node-bus node) (w:update-event (node-keypair node) u)) (incf sent))
        (log! node "republished ~a update(s) of ~a from seq ~a: a member expected seq ~a"
              sent (subseq (record-id-hex rec) 0 8) n n)))))

(defparameter *restamp-margin* 2
  "Blocks of headroom kept under a cosigner's freshness window (*COSIGN-HEIGHT-TOLERANCE*, DEP-02's
   6): a draft whose block_height has fallen more than (window - margin) behind our tip is
   re-stamped at the tip before it is asked for again, so it reaches a cosigner still inside.")

(defparameter *max-restamps* 3 "How many times one append re-stamps its draft before it gives up.")

(defvar *before-cosign-request-hook* nil
  "Testing: called with NODE REC UPDATE ATTEMPT before each cosign_update request is sent (a
   block that arrives while the draft waits for the box).")

(defun stale-refusal-p (response)
  "A cosigner's refusal of a block_height too far below its tip (cl: \"more than N below our tip\";
   the reference: \"is more than N blocks from our height\")."
  (let ((err (and (hash-table-p response) (not (w:jget response "success")) (w:jget response "error"))))
    (and (stringp err) (search "block_height" err)
         (or (search "below our tip" err) (search "blocks from our height" err)))))

(defun draft-stale-p (node update &optional refused-stale)
  "UPDATE (a draft we have not signed) should be re-dated before it is asked for again: its
   block_height is more than (window - margin) below our tip, or a cosigner refused it as too
   old and our tip has moved past it at all."
  (let ((lag (- (height node) (up:update-block-height update))))
    (or (> lag (- *cosign-height-tolerance* *restamp-margin*))
        (and refused-stale (plusp lag)))))

(defun check-restampable (rec draft)
  "Write-ahead, checked rather than assumed (DEP-02 §Operator, implementer note): DRAFT may be
   replaced only while it is unsigned and nothing of ours is recorded at its sequence -- every
   update we sign is recorded and written ahead before a relay sees it (COMMIT-UPDATE), so an
   empty slot means nothing of ours at that (ledger, sequence) exists anywhere."
  (when (or (up:update-operator-sig draft) (record-update-at rec (up:update-seq draft)))
    (fail "seq ~a of ~a is already signed by us; not re-stamping it" (up:update-seq draft) (subseq (record-id-hex rec) 0 8)))
  t)

(defun solicit-cosignatures (node rec update signers required &key stale-p)
  "Ask the quorum; return when REQUIRED valid cosignatures are in the update.  With STALE-P (a
   function of one argument, whether a cosigner refused the draft's height as too old), return
   :STALE instead of asking again once it says the draft must be re-dated (APPEND-OPERATION
   re-stamps it: the draft is not ours to keep, we have not signed it)."
  (let* ((data (up::cosign-data update))
         (round (begin-cosign-round node update signers))
         (params (apply #'w:json-object "sequence_number" (up:update-seq update)
                                "cosign_data_hex" (bytes->hex data)
                                "content_hash_hex" (bytes->hex (up:content-hash update))
                                "message_type" 32769
                                "fork_operator" (and (record-fork-p rec) (bytes->hex (record-fork-operator rec)))
                                ;; DEP-03 Rotation ordering: cosigners rebuild every rung, unsigned.
                                "rotation_rungs_tx" (let ((r (record-rotation rec)))
                                                      (and r (getf r :rungs) (not (getf r :qb-seq))
                                                           (eq (op:update-type update) :quorum-begin)
                                                           (coerce (getf r :rungs) 'vector)))
                                *extra-cosign-params*))
         (signer-xs (mapcar (lambda (m) (x-hex (lg:member-pubkey m))) signers))
         (attempt 0))
    (labels ((take-round ()
               ;; Everything the round holds (earlier attempts, late answers) into the update.
               (dolist (c (bt:with-lock-held ((cosign-round-lock round)) (copy-list (cosign-round-cosigs round))))
                 (unless (member (up:cosig-pubkey c) (up:update-cosignatures update) :key #'up:cosig-pubkey :test #'equalp)
                   (push c (up:update-cosignatures update)))))
             (enough () (>= (length (up:update-cosignatures update)) required))
             (answered (r)
               ;; Who answered, as x-only hex: the cosigner's key on a cosignature, the
               ;; responder's on a refusal.
               (let ((c (response-cosignature r)))
                 (if c (x-hex (up:cosig-pubkey c)) (gethash "responder" r)))))
      (take-round)
      ;; A member may still be applying the update this one chains onto (relays
      ;; reorder); ask again after a pause before giving up.
      (loop with refused-stale = nil
            until (or (enough) (>= attempt 3))
            do (when *before-cosign-request-hook* (funcall *before-cosign-request-hook* node rec update attempt))
               ;; Every retry used to resend the identical draft: one dated at a height already
               ;; behind the cosigners' window is refused the same way each time (regtest
               ;; 1121-101522: ref6 refused seq 5 of fbe37fad three times, "block_height 35890 is
               ;; more than 6 blocks from our height 35897", and the post-expiry rotation never formed).
               (when (and stale-p (funcall stale-p refused-stale))
                 (return-from solicit-cosignatures :stale))
               (dolist (r (send-request node (record-id-hex rec) "cosign_update" params
                                        :want (- required (length (up:update-cosignatures update)))
                                        :counts (lambda (r) (let ((c (response-cosignature r)))
                                                              (and c (member (up:cosig-pubkey c) signers :key #'lg:member-pubkey :test #'equalp))))
                                        ;; Every signer has answered (signed or refused): nothing more is coming.
                                        :settled (lambda (rs) (let ((who (mapcar #'answered rs)))
                                                                (every (lambda (x) (member x who :test #'equal)) signer-xs)))
                                        :on-publish (lambda (id)
                                                      (bt:with-lock-held ((cosign-round-lock round))
                                                        (push id (cosign-round-request-ids round)))
                                                      (setf (gethash id (node-late-cosign-requests node)) data))
                                        :timeout (if (zerop attempt) *cosign-response-seconds* 3)))
                 (round-add round (response-cosignature r))
                 ;; A refusal says why: log it, or a stale-height refusal is invisible to the operator.
                 (when (and (hash-table-p r) (not (response-cosignature r)) (w:jget r "error"))
                   (log! node "cosign of ~a seq ~a (block_height ~a) refused by ~a: ~a"
                         (subseq (record-id-hex rec) 0 8) (up:update-seq update) (up:update-block-height update)
                         (let ((who (gethash "responder" r))) (if (stringp who) (subseq who 0 (min 8 (length who))) "?"))
                         (w:jget r "error")))
                 (when (stale-refusal-p r) (setf refused-stale t))
                 (republish-missed node rec r))
               (take-round)
               (incf attempt)
               (unless (enough) (own:pause-for 0.3))))
    (when (< (length (up:update-cosignatures update)) required)
      (fail "only ~a of ~a cosignatures for seq ~a" (length (up:update-cosignatures update)) required (up:update-seq update)))
    (end-cosign-round node update)
    update))

(defun append-operation (node rec op &key (height nil height-p) op-fn tier-floor)
  "The operator's one entry point: chain OP onto REC's ledger with whatever
   cosignatures DEP-05 requires at HEIGHT.  With OP-FN, OP is (funcall OP-FN tip-chain-hash),
   built under the append lock on the tip it extends (a rotation's anchor, DEP-03).  TIER-FLOOR
   (keys . need): also NEED valid cosignatures by KEYS, or nothing is recorded (a rotating
   QuorumBegin answers its rungs only at the spent tier's floor, FR:ANSWER-COSIGN-NEED).
   HEIGHT defaults to our tip read under the append lock; a defaulted draft whose height falls out
   of the cosigners' window before its cosignatures are in is re-stamped (DRAFT-STALE-P)."
  (unless (record-owned-p rec) (fail "not our ledger"))
  ;; Serialised per ledger, cosign round included: the control socket (a
  ;; rotation's QuorumAddMember) and the worker (a wallet's transfer) both
  ;; append here, and an update built from a tip that moved during its own
  ;; cosign round commits as "SEQUENCE (expected N+1, got N)".  Under steady
  ;; traffic a rotation never won that race and only succeeded post-expiry,
  ;; when value-moving operations were being refused and nothing competed.
  ;; An owner lock (one thread runs every append): another task's append to this ledger is
  ;; suspended in its cosign wait, below us on the stack; we cannot wait for it, so the work
  ;; that wanted this append is run again later (OWN:OWNER-BUSY).
  (own:with-owner-lock ((list :append rec))
   ;; RE-STAMPING.  An update that needs cosignatures is a DRAFT until COMMIT-UPDATE: we sign it
   ;; only after the cosignatures are in (DEP-02 §Operator, "the operator signs after collecting
   ;; the required majority"), and only a signed update is written ahead.  So a draft whose
   ;; block_height has fallen behind the cosigners' window (DEP-02: "a cosigner refuses a
   ;; block_height more than 6 blocks below its own tip") may be rebuilt at our tip and asked for
   ;; again: we have signed nothing at its (ledger, sequence), and DEP-02's write-ahead rule ("MUST
   ;; NOT sign a different update at a (ledger, sequence) it has already signed") is about what
   ;; we sign.  DEP-05 §Cosign Rounds names the case: cosignatures kept for the old cosign_data
   ;; are dead once we sign a different update at that sequence; they are never attached to it.
   ;; The whole draft is rebuilt, not just its height: the height decides the tier and threshold
   ;; (DEP-05), the balance commitments and the validity checks.  HEIGHT is read HERE, under the
   ;; lock: read on entry it was as old as the wait for another append's cosign round.
   (let ((op0 op) (stale-drafts '()) (restamps 0))
    (loop
     (block attempt
     (let ((height (if height-p height (height node))) (op op0))
    (when op-fn (setf op (funcall op-fn (up:chain-hash (tip rec)))))
    ;; DEP-02 §Balance Commitments: declare the post-update balances of what OP touches.
    ;; ADVERSARY :omit-commitments — an operator that declares none (red team: DEP-18's
    ;; MissingBalanceCommitment under balance-commit-v4 and balance-anchor-v6).
    (unless (getf (node-adversary node) :omit-commitments)
     (let ((height (max height (if (tip rec) (up:update-block-height (tip rec)) 0))))
      (setf op (lg:fill-balance-commitments (record-ledger rec) op height (1+ (lg:ledger-sequence (record-ledger rec)))))
      ;; ADVERSARY :falsify-commitments — an operator that declares a balance 1 msat off the real
      ;; one (red team: DEP-02 BalanceCommitmentMismatch, which members must refuse to cosign).
      (when (getf (node-adversary node) :falsify-commitments)
        (let ((target (first (lg::commitment-targets (record-ledger rec) op))))
          (when target
            (destructuring-bind (id bk lk) target
              (declare (ignore id lk))
              (when (op:field op bk)
                (setf op (lg::op-with op bk (1+ (op:field op bk)))))))))))
    ;; Would it apply?  Check on a copy before asking anyone to cosign it.
    ;; ADVERSARY :sign-invalid — an operator that asks its quorum to cosign an
    ;; operation its own validator rejects (red team #1).
    (unless (or (getf (node-adversary node) :sign-invalid) (getf (node-adversary node) :omit-commitments)
                (getf (node-adversary node) :falsify-commitments))
      (let ((why (cf:descriptor-refusal (record-ledger rec) op))) (when why (fail "~a" why)))
      (lg:speculate (record-ledger rec) op (max height (if (tip rec) (up:update-block-height (tip rec)) 0))
                    (1+ (lg:ledger-sequence (record-ledger rec)))))
    (let* ((update (new-update node rec op :height height))
           (may-restamp (and (not height-p) (< restamps *max-restamps*))))
     (flet ((stale-p (refused-stale) (draft-stale-p node update refused-stale))
            (restamp (draft)
              (check-restampable rec draft)
              (log! node "re-stamping seq ~a of ~a: drafted at block_height ~a, our tip is ~a (unsigned draft; DEP-02 window ~a)"
                    (up:update-seq draft) (subseq (record-id-hex rec) 0 8) (up:update-block-height draft) (height node)
                    *cosign-height-tolerance*)
              (push draft stale-drafts) (incf restamps)
              (return-from attempt nil)))
      (multiple-value-bind (required signers tier operator-alone allowed)
          (lg:cosign-requirement (record-ledger rec) op height)
        (declare (ignore operator-alone))
        (unless allowed (fail "~a not cosignable at ~a" (op:operation-type op) tier))
        (when (plusp required)
          ;; Members that forked against this quorum refuse every cosign: once too few
          ;; are left to reach REQUIRED, stand down now instead of timing out each time.
          (let ((disputing (disputing-members node rec)) (custodian (custody-moved-to node rec)))
            (when custodian
              (fail "ledger disputed: custody moved to ~a by DisputeAcquire; this operator stands down"
                    (subseq (bytes->hex custodian) 0 16)))
            (when (> required (count-if-not (lambda (m) (member (lg:member-pubkey m) disputing :test #'equalp)) signers))
              (fail "ledger disputed: ~a of ~a members forked it; ~a cosignatures are out of reach (custody follows the dispute)"
                    (length disputing) (length signers) required)))
          (when (eq (solicit-cosignatures node rec update signers required :stale-p (and may-restamp #'stale-p)) :stale)
            (restamp update)))
        (when (and tier-floor (plusp (cdr tier-floor)))
          (let ((have (fr:tier-cosignatures update (car tier-floor))))
            (when (< have (cdr tier-floor))
              ;; The members not yet in: ask for the rest, then judge again.
              (when (eq (ignore-errors (solicit-cosignatures node rec update signers
                                                             (+ (length (up:update-cosignatures update)) (- (cdr tier-floor) have))
                                                             :stale-p (and may-restamp #'stale-p)))
                        :stale)
                (restamp update))
              (let ((have (fr:tier-cosignatures update (car tier-floor))))
                (when (< have (cdr tier-floor))
                  (fail "~a: ~a of the ~a cosignatures by the spent vault's tier that answer its rungs (DEP-06); not recording a rotation no judge could answer"
                        (op:operation-type op) have (cdr tier-floor))))))))
      (commit-update node rec update)
      ;; DEP-05 §Cosign Rounds: a different update is signed at this sequence; the stale drafts' rounds are dead.
      (dolist (d stale-drafts) (end-cosign-round node d))
      (return update)))))))))

(defun open-ledger (node &key reserves-id (genesis-block (height node)) (reserves 0) (collateral 0)
                         (ruleset lg:+current-ruleset+))
  "Genesis: LedgerOpen at sequence 0.  Returns the record."
  (let* ((id (op:compute-ledger-id (node-pubkey node) reserves-id genesis-block))
         (rec (make-record :id-hex (bytes->hex id) :ledger (lg:make-ledger) :owned-p t)))
    (setf (gethash (record-id-hex rec) (node-ledgers node)) rec)
    (unless (node-member-ledger-hex node) (setf (node-member-ledger-hex node) (record-id-hex rec)))
    (commit-update node rec (new-update node rec (list :type :ledger-open :operator-id (node-pubkey node)
                                                       :reserves-id reserves-id :genesis-block genesis-block
                                                       :reserves-amount reserves :collateral-amount collateral
                                                       :protocol-version ruleset)))
    rec))

;;; ---------------------------------------------------------------------------
;;; Quorum formation (operator side)

(defun member-terms->plist (res)
  (list :min-fee-bps (w:jget res "min_fee_bps") :min-fee-fixed (w:jget res "min_fee_fixed")
        :max-fee-period (w:jget res "max_fee_period") :membership-until (w:jget res "membership_expires")))

(defparameter +consent-timeout+ 180
  "Seconds to wait for a member's consent.  A member catches its replica up to the operator's
   sequence from the relay before it answers; under soak load (relay p99 query 33 s) that outran
   60 s, every rotation of A failed on one member's silence for five hours, and the quorum expired
   (signet soak, 2026-11-07).")
(defparameter +consent-history-limit+ 40
  "How much of the history a consent request carries: the reference's nostr client drops any
   event over 70 KB (~70 updates), and it needs LedgerOpen; the rest is gap-filled from the relay.")

(defun add-member (node rec member-pubkey &key member-ledger-id (membership-blocks 4320) ruleset (min-fee-bps 0) (min-fee-fixed 0) (max-fee-period 2016) dispute-response-blocks dormancy-blocks dormancy-notice-blocks)
  "Ask MEMBER-PUBKEY to join REC's quorum; on consent, stage them with QuorumAddMember.
   The request is addressed (tag l) to MEMBER-LEDGER-ID — the member's own ledger —
   as the reference does; its nodes only answer requests for ledgers they operate."
  (let* ((until (+ (known-height node) membership-blocks))
         (ruleset (or ruleset (let ((l (record-ledger rec)))   ; DEP-18 §operator policy, LG:PROPOSED-RULESET
                                (lg:proposed-ruleset (or (lg:ledger-active-ruleset l)
                                                         (and (null (lg:ledger-quorum-members l)) lg:+current-ruleset+))
                                                     (lg:member-declaration l member-pubkey)))))
         ;; Only a PREFIX of the history rides along.  At 46k updates the whole
         ;; of it is ~60 MB of base64 in one event — no relay carries that.  The
         ;; reference member insists on seeing LedgerOpen (it validates the
         ;; ledger id from it) and gap-fills the rest itself; ours catches up
         ;; from the relay to `ledger_sequence`.
         (params (w:json-object "operator_pubkey" (node-pubkey-hex node) "operator_ledger_id" (record-id-hex rec)
                                "ledger_history" (coerce (let ((h (reverse (last (record-history rec) +consent-history-limit+))))
                                                           (mapcar (lambda (u) (base64-encode (up:encode-update u))) h))
                                                         'vector)
                                "ledger_sequence" (lg:ledger-sequence (record-ledger rec))
                                "chosen_ruleset" ruleset "min_fee_bps" min-fee-bps "min_fee_fixed" min-fee-fixed
                                "max_fee_period" max-fee-period "membership_until" until))
         ;; A member validates (the reference imports and gap-fills) before it
         ;; answers: allow it well beyond a cosign round.
         (responses (send-request node (or member-ledger-id (record-id-hex rec)) "consent_request" params
                                  :timeout +consent-timeout+
                                  :extra-tags (list (list "p" (x-hex member-pubkey)))))
         (consent-ok (lambda (r)
                       ;; The reference signs Nostr events with a per-host delegate key, so
                       ;; the event pubkey says nothing; the consent signature does.
                       (let ((res (w:jget r "result")))
                         (and (w:jget r "success") res (w:jget res "consent_signature")
                              (schnorr:schnorr-verify (up:x-only member-pubkey)
                                                      (sha256 (cat (ascii->bytes "COLLATERAL_CONSENT") (node-pubkey node)
                                                                   (ascii->bytes (record-id-hex rec))))
                                                      (hex->bytes (w:jget res "consent_signature")))))))
         (r (find-if consent-ok responses)))
    (unless r (fail "member ~a did not consent" (subseq (bytes->hex member-pubkey) 0 8)))
    (let* ((res (w:jget r "result"))
           (consent (hex->bytes (w:jget res "consent_signature"))))
      (append-operation node rec
                        (%strip-nil-fields
                                (list :type :quorum-add-member :quorum-member member-pubkey
                                      :dormancy-blocks dormancy-blocks :dormancy-notice-blocks dormancy-notice-blocks
                                      :quorum-member-signature consent
                                      :member-ledger-id (or (w:jget res "member_ledger_id") member-ledger-id "")
                                      :min-fee-bps min-fee-bps :min-fee-fixed min-fee-fixed :max-fee-period max-fee-period
                                      :membership-until (w:jget res "membership_expires")
                                      :dispute-response-blocks dispute-response-blocks
                                      :member-response (let ((b (w:jget res "member_response"))) (and b (base64-decode b)))
                                      :member-signature (let ((h (w:jget res "member_signature"))) (and h (hex->bytes h)))))))))

(defun trim-staged (node rec)
  "DEP-11 §Rotating without a silent member: cut REC's staged (consenting) set to the quorum the
   operator seats (LG:SEAT-CONSENTING over the live consents), unstaging the rest, stale consents
   included, with QuorumRemoveMember.  Returns the number to be seated; fails with fewer than three."
  ;; Only a live consent counts: a member staged in an earlier, failed pass keeps its old
  ;; membership_until, and seating it bounds the new quorum's expiry by it, so the QuorumBegin is
  ;; born expired (signet soak, Nov 10: I and K resumed rotations to quorum_expiry 9441 at height
  ;; 10420, 105 times).  A consent counts when its commitment runs at least 72 blocks past the tip.
  (let* ((l (record-ledger rec)) (h (height node))
         (members (lg:ledger-next-quorum-members l))
         (staged (mapcar #'lg:member-pubkey members))
         (fresh (loop for m in members
                      for until = (lg:member-membership-until m)
                      when (or (null until) (> until (+ h 72))) collect (lg:member-pubkey m)))
         (seat (lg:seat-consenting (mapcar #'lg:member-pubkey (lg:ledger-quorum-members l)) fresh)))
    (unless seat (fail "only ~a members hold a live consent (a quorum needs 3)" (length fresh)))
    (dolist (m staged (length seat))
      (unless (member m seat :test #'equalp)
        (append-operation node rec (list :type :quorum-remove-member :quorum-member m
                                         :operator-signature (make-array 64 :element-type '(unsigned-byte 8) :initial-element 0)))))))

(defun %strip-nil-fields (plist)
  (loop for (k v) on plist by #'cddr when v append (list k v)))

(defun prepare-quorum (node rec &key ruleset (expiry-blocks 4320))
  "Build (and pin) the reserves output the next QuorumBegin will point at, so
   it can be funded on chain first.  Returns the reserves.  RULESET defaults to the reference
   operator policy (DEP-18 §operator policy, LG:PLANNED-RULESET)."
  (let* ((h (known-height node))
         (staged (lg:ledger-next-quorum-members (record-ledger rec)))
         (ruleset (or ruleset (lg:planned-ruleset (lg:ledger-active-ruleset (record-ledger rec)) (mapcar #'lg:member-supported-rulesets staged))))
         ;; DEP-05: quorum_expiry is the shortest member commitment.
         (expiry (lg:planned-quorum-expiry staged h expiry-blocks))
         (reserves (rs:build-reserves :operator (node-pubkey node) :members (mapcar #'lg:member-pubkey staged)
                                      :ledger-hash (up:chain-hash (tip rec)) :quorum-expiry expiry
                                      :ruleset ruleset :network (intern (string-upcase (node-network node)) :keyword))))
    (when (null staged) (fail "no staged members"))
    ;; A member whose commitment has already lapsed would make the quorum born
    ;; expired (every value-moving op refused): say which, rather than pin it.
    (when (<= expiry h)
      (fail "quorum would be born expired: a member's commitment ends at ~a, height ~a" expiry h))
    (setf (record-pinned rec) (cons reserves expiry))
    reserves))

(defun rotation-file (node rec)
  (and (node-data-dir node)
       (merge-pathnames (format nil "rotation_~a.sexp" (subseq (record-id-hex rec) 0 16)) (node-data-dir node))))

(defun save-rotation (node rec plist)
  "Persist a broadcast rotation: the old vault is spent, and a restart before its
   QuorumBegin must still know where the reserves went."
  (setf (record-rotation rec) plist)
  (let ((f (rotation-file node rec)))
    (when f
      (ensure-directories-exist f)
      (with-open-file (out f :direction :output :if-exists :supersede)
        (with-standard-io-syntax (prin1 plist out))))))

(defun pending-rotation (node rec)
  (or (record-rotation rec)
      (let ((f (rotation-file node rec)))
        (when (and f (probe-file f))
          (setf (record-rotation rec) (with-open-file (in f) (with-standard-io-syntax (read in))))))))

(defun clear-rotation (node rec)
  (setf (record-rotation rec) nil)
  (let ((f (rotation-file node rec))) (when (and f (probe-file f)) (delete-file f))))

(defun has-quorum-begin-p (rec)
  "REC holds a vault its next QuorumBegin must rotate: a QuorumBegin with no DisputeAcquire
   after it (an acquisition's first QuorumBegin is funded by the lottery claim instead)."
  (let ((qb (record-latest rec :quorum-begin)) (acq (record-latest rec :dispute-acquire)))
    (and qb (or (null acq) (> (up:update-seq qb) (up:update-seq acq))))))

(defun rotation-tier-index (reserves height)
  "The highest-numbered tier whose CLTV is satisfied at HEIGHT (Tier 0 before expiry)."
  (loop for tier in (rs:reserves-tiers reserves) for i from 0
        when (<= (rs:tier-locktime tier) height) maximize i))

(defun exit-settlement (ledger height cutoff)
  "DEP-20 §3: the due exits at HEIGHT under CUTOFF as (values extras entries exits-cost): EXTRAS the
   rotation's exit outputs ((spk . sats) ...), each less its own cost, ENTRIES the QuorumBegin's
   exit_outputs, EXITS-COST the sum of those costs (the part of the fee the exits pay)."
  (let ((due (lg:due-exits ledger height cutoff)) (f (lg:rotation-feerate ledger)))
    (values (loop for (nil . e) in due
                  collect (cons (getf e :exit-address)
                                (- (floor (getf e :amount) 1000) (lg:exit-cost (getf e :exit-address) f))))
            (loop for (nil . e) in due for i from 1 collect (list (getf e :deposit-id) (getf e :amount) i))
            (loop for (nil . e) in due sum (lg:exit-cost (getf e :exit-address) f)))))

(defun dormancy-settlement (ledger cutoff nexits)
  "DEP-20 §8.2: the spin-outs a rotating QuorumBegin at HEIGHT must pay, as (values extras entries
   cost): EXTRAS ((spk . sats) ...) after NEXITS exit outputs, ENTRIES the dormancy_outputs, COST
   the operator's (collateral's) share of the fee for them."
  (let ((spins (lg:dormancy-spin-outs ledger cutoff)))
    (values (loop for (nil bal spk) in spins collect (cons spk (floor bal 1000)))
            (loop for (id bal) in spins for j from 1 collect (list id bal (+ nexits j)))
            (* (length spins) (lg:dormancy-cost ledger)))))

(defun settlement (ledger height cutoff)
  "Every DEP-20 output a rotation at HEIGHT pays: (values extras exit-entries dormancy-entries
   exits-cost dormancy-cost migration premium), DORMANCY-COST including the migration output's
   own cost (a fee), MIGRATION (:entries :vout) or NIL, PREMIUM the sats the migration output
   carries beyond the deposits (not a fee); collateral pays the dormancy cost and the premium."
  (multiple-value-bind (ex ee ec) (exit-settlement ledger height cutoff)
    (multiple-value-bind (dx de dc) (dormancy-settlement ledger cutoff (length ee))
      (multiple-value-bind (mentries mspk msats) (lg:dormancy-migration ledger cutoff (length de) height)
        (if mentries
            (let ((premium-msat (or (getf (lg:ledger-dormancy-notice ledger) :premium) 0)))
              (values (append ex dx (list (cons mspk msats))) ee de ec
                      (+ dc (* (lg:rotation-feerate ledger) (+ 9 (length mspk))))
                      (list :entries mentries :vout (+ 1 (length ee) (length de)))
                      (floor premium-msat 1000)))
            (values (append ex dx) ee de ec dc nil 0))))))

(defun median-feerate (node height)
  "DEP-03 Reference feerate: m = floor((s3 + s4) / 2) over the block feerates of heights h-6..h-1,
   or NIL without a feerate source."
  (when (node-feerate-fn node)
    (let ((fs (loop for b from (- height 6) below height collect (funcall (node-feerate-fn node) b))))
      (unless (member nil fs)
        (let ((s (sort fs #'<))) (floor (+ (nth 2 s) (nth 3 s)) 2))))))

(defun feerate-bounds (m) (values (max 1 (floor m 2)) (max 2 (* 2 m))))

(defun splice-outpoint-bytes (txid vout) (cat txid (int->be vout 4)))

(defun splice-prevout (node txid vout)
  "DEP-20 §4: a splice-in outpoint, confirmed to the policy depth and unspent: (values sats spk)."
  (let ((info (and (node-chain-fn node) (funcall (node-chain-fn node) txid vout))))
    (unless info (fail "splice-in outpoint ~a:~a is spent or unknown" (bytes->hex txid) vout))
    (unless (>= (or (getf info :confirmations) 0) 1) (fail "splice-in outpoint is unconfirmed"))
    (values (getf info :value-sats)
            (or (getf info :spk) (lot:p2tr-spk (up:x-only (node-pubkey node)) (octets))))))

(defun rotation-collateral (ledger vault-sats fee-sats)
  "DEP-20 §3 Amounts: collateral bears only its share of FEE-SATS, the vault's part of the
   rotation fee (the fee less what the exits paid themselves)."
  (let ((old (+ (lg:ledger-reserves-amount ledger) (lg:ledger-collateral-amount ledger))))
    (if (plusp old) (floor (* (lg:ledger-collateral-amount ledger) (- vault-sats fee-sats) 1000) old) 0)))

(defun rotate-vault (node rec &key ruleset (expiry-blocks 4320) (timeout 90) splice)
  "DEP-03 rotation, first step: plan the spend of the current vault into the reserves of the
   staged quorum with the shared builder (rot:build-ladder).  Nothing is signed yet: BEGIN-QUORUM
   records the QuorumBegin naming every rung, then gathers the members' signatures on the rungs
   (rotation_sign), assembles and broadcasts (DEP-03 Rotation ordering).  Returns (values txid
   new-vault-sats): rung 0 as it would be built on our current tip (BEGIN-QUORUM's answer is the
   one recorded)."
  (declare (ignore timeout))
  (unless (record-owned-p rec) (fail "not our ledger"))
  (unless (has-quorum-begin-p rec) (fail "no vault yet: the first QuorumBegin is funded, not rotated"))
  (let ((pending (pending-rotation node rec)))
    (when (and pending (getf pending :qb-seq)) (fail "a rotation is already recorded and awaits its signatures"))
    ;; Planned but never recorded (its begin-quorum fell short): nothing is signed yet, and its
    ;; exit cutoff ages out of the window a QuorumBegin may name, so plan again on this tip.
    (when pending (clear-rotation node rec)))
  (let* ((staged (mapcar #'lg:member-pubkey (lg:ledger-next-quorum-members (record-ledger rec))))
         (new (if (and (record-pinned rec) (equalp (rs:reserves-members (car (record-pinned rec))) staged))
                  (car (record-pinned rec))       ; prepared already (prepare-quorum)
                  (prepare-quorum node rec :ruleset ruleset :expiry-blocks expiry-blocks)))
         (expiry (cdr (record-pinned rec))))
    (multiple-value-bind (cur txid vout sats) (disputed-reserves node rec)
      ;; The vault a confiscation (or another rotation) already spent cannot be rotated: every
      ;; member refuses its rungs ("vault outpoint is spent") and the attempt repeats for good.
      ;; ADVERSARY :rotate-spent-vault — an operator that asks its quorum to record a rotation of
      ;; a vault already spent (red team: DEP-06 §Race, members refuse a QuorumBegin over a vault
      ;; whose confiscation confirmed; regtest rotation-post-expiry-confiscated).
      (when (and (vault-spent-p node txid vout) (not (getf (node-adversary node) :rotate-spent-vault)))
        (fail "the vault ~a:~a is already spent (confiscated or rotated); not rotating" (bytes->hex txid) vout))
      (let* ((tier-index (rotation-tier-index cur (height node)))
             (tier (nth tier-index (rs:reserves-tiers cur)))
             (cutoff (height node))
             (exits-cost (nth-value 3 (settlement (record-ledger rec) (height node) cutoff)))
             (dorm-cost (nth-value 4 (settlement (record-ledger rec) (height node) cutoff)))
             (extras (settlement (record-ledger rec) (height node) cutoff))
             ;; DEP-20 §4: SPLICE is (txid vout) of a confirmed UTXO paying our key-path P2TR.
             (splice-in (when splice
                          (multiple-value-bind (ssats sspk) (splice-prevout node (first splice) (second splice))
                            (list (first splice) (second splice) ssats sspk))))
             ;; DEP-20 §8.3: a migration output at our own vault script is spent through the same tier.
             (vault-splice (and splice-in (equalp (fourth splice-in) (rs:reserves-spk cur))))
             (plan (list :vault-txid (bytes->hex txid) :vault-vout vout :vault-sats sats
                         :voters (length (rs:reserves-voters cur)) :feerate (lg:rotation-feerate (record-ledger rec))
                         :locktime (rs:tier-locktime tier) :tier-index tier-index
                         :new-vault-spk (bytes->hex (rs:reserves-spk new))
                         :extras (mapcar (lambda (e) (cons (bytes->hex (car e)) (cdr e))) extras)
                         :splice-in (and splice-in (list (bytes->hex (first splice-in)) (second splice-in) (third splice-in)
                                                         (bytes->hex (fourth splice-in))))
                         :splice-vault-p vault-splice
                         ;; DEP-03 §Fee ladder: a migration output's outpoint is named by txid, so one rung
                         :max-rungs (if (nth-value 5 (settlement (record-ledger rec) (height node) cutoff)) 1 rot:+rungs+)
                         :governing-seq (governing-quorum-begin-seq rec (lg:ledger-sequence (record-ledger rec)))))
             (tx (or (first (plan-ladder plan (up:chain-hash (tip rec)) 0))
                     (fail "the rotation leaves the new vault below dust")))
             (new-sats (btx:txout-value (first (btx:tx-outputs tx)))))
        (save-rotation node rec (list :plan plan :sats new-sats :vault-sats sats :cutoff cutoff
                                      :tx (unsigned-tx-hex tx)    ; rung 0 as planned on this tip (inspection only)
                                      :fee (- (+ sats (if splice-in (third splice-in) 0)) (reduce #'+ extras :key #'cdr) new-sats exits-cost dorm-cost)
                                      :dormancy-cost dorm-cost
                                      :premium (nth-value 6 (settlement (record-ledger rec) (height node) cutoff))
                                      :splice (and splice-in (list (bytes->hex (first splice-in)) (second splice-in) (third splice-in)))
                                      :ledger-hash (bytes->hex (rs:reserves-ledger-hash new)) :expiry expiry
                                      :ruleset (rs:reserves-ruleset new)
                                      :members (mapcar #'bytes->hex (rs:reserves-members new))))
        (log! node "rotation of ~a planned: ~a sats into the next vault, spending ~a:~a at tier ~a; recording its QuorumBegin next"
              (subseq (record-id-hex rec) 0 8) new-sats (subseq (bytes->hex txid) 0 16) vout tier-index)
        (values (btx:tx-txid tx) new-sats)))))

(defun plan-ladder (plan anchor collateral-msats)
  "DEP-03 §Fee ladder: the unsigned rungs ROTATE-VAULT's PLAN gives under ANCHOR (the chain hash
   the QuorumBegin extends) and COLLATERAL-MSATS (its collateral_amount)."
  (rot:build-ladder :vault-txid (hex->bytes (getf plan :vault-txid)) :vault-vout (getf plan :vault-vout)
                    :vault-sats (getf plan :vault-sats) :voters (getf plan :voters) :feerate (getf plan :feerate)
                    :locktime (getf plan :locktime) :new-vault-spk (hex->bytes (getf plan :new-vault-spk))
                    :extras (mapcar (lambda (e) (cons (hex->bytes (car e)) (cdr e))) (getf plan :extras))
                    :splice (let ((sp (getf plan :splice-in))) (and sp (list (hex->bytes (first sp)) (second sp) (third sp))))
                    :splice-vault-p (getf plan :splice-vault-p) :anchor anchor :collateral-msats collateral-msats
                    :max-rungs (or (getf plan :max-rungs) rot:+rungs+)))

(defun plan-prevouts (plan cur)
  (let ((sp (getf plan :splice-in)))
    (if sp
        (vector (cons (getf plan :vault-sats) (rs:reserves-spk cur)) (cons (third sp) (hex->bytes (fourth sp))))
        (vector (cons (getf plan :vault-sats) (rs:reserves-spk cur))))))

(defun sign-rotation-rungs (node rec qb-update &key (timeout 90))
  "DEP-03 Rotation ordering, steps 3-4: QB-UPDATE (final, published) names the rungs of the
   pending rotation.  Gather the spent vault's tier signatures on every rung from its members
   (rotation_sign, carrying QB-UPDATE: a member signs only rungs a final QuorumBegin names),
   assemble, verify, broadcast rung 0, publish every rung (Kind 9107) and keep them to
   rebroadcast and bump.  Returns rung 0's txid; signals when too few members sign (the
   rotation stays pending: DRIVE-ROTATION-REBROADCAST retries)."
  (let* ((r (or (pending-rotation node rec) (fail "no pending rotation")))
         (plan (getf r :plan))
         (rungs (mapcar (lambda (h) (btx:parse-tx (bw:make-reader (hex->bytes h)))) (getf r :rungs)))
         (cur (or (fr:spent-vault (spent-vault-updates rec) (getf plan :governing-seq)) (fail "the spent vault's QuorumBegin is gone")))
         (tier-index (getf plan :tier-index))
         (tier (nth tier-index (rs:reserves-tiers cur)))
         (leaf (nth tier-index (rs:reserves-leaves cur)))
         (prevouts (plan-prevouts plan cur))
         (vault-splice (getf plan :splice-vault-p))
         (hashes (mapcar (lambda (tx) (rot:tier-sighash tx 0 prevouts leaf)) rungs))
         (hashes1 (and vault-splice (mapcar (lambda (tx) (rot:tier-sighash tx 1 prevouts leaf)) rungs)))
         (keys (if (and (= (rs:tier-threshold tier) 1) (rs:tier-tie-breaker-p tier))
                   (list (up:x-only (node-pubkey node)))
                   (rs:tier-keys tier)))
         (me (up:x-only (node-pubkey node)))
         ;; (xonly sigs-per-rung splice-sigs-per-rung)
         (sigs (list (list me (mapcar (lambda (h) (schnorr:schnorr-sign (node-priv node) h (random-aux))) hashes)
                           (mapcar (lambda (h) (schnorr:schnorr-sign (node-priv node) h (random-aux))) hashes1))))
         (need (rs:tier-threshold tier)))
    (when (< (count-if (lambda (s) (member (first s) keys :test #'equalp)) sigs) need)
      (let ((responses (send-request node (record-id-hex rec) "rotation_sign"
                                     (w:json-object "quorum_begin" (base64-encode (up:encode-update qb-update))
                                                    "unsigned_rungs" (coerce (getf r :rungs) 'vector)
                                                    "tier_index" tier-index
                                                    "splice_in_outpoint" (let ((sp (getf plan :splice-in)))
                                                                           (and sp (format nil "~a:~a" (first sp) (second sp)))))
                                     :want (max 0 (- need (count-if (lambda (s) (member (first s) keys :test #'equalp)) sigs)))
                                     :timeout timeout :successes-only t)))
        (dolist (resp responses)
          (let ((res (w:jget resp "result")))
            (when (and (w:jget resp "success") res)
              (let* ((res (if (stringp res) (w:parse-json res) res))
                     (pk (up:x-only (hex->bytes (w:jget res "signer"))))
                     (ss (mapcar #'hex->bytes (coerce (or (w:jget res "signatures") #()) 'list)))
                     (ss1 (mapcar #'hex->bytes (coerce (or (w:jget res "splice_signatures") #()) 'list))))
                (when (and (member pk keys :test #'equalp) (not (assoc pk sigs :test #'equalp))
                           (= (length ss) (length hashes)) (every (lambda (h sg) (schnorr:schnorr-verify pk h sg)) hashes ss)
                           (or (not vault-splice)
                               (and (= (length ss1) (length hashes1)) (every (lambda (h sg) (schnorr:schnorr-verify pk h sg)) hashes1 ss1))))
                  (push (list pk ss ss1) sigs))))))))
    (let ((have (remove-if-not (lambda (s) (member (first s) keys :test #'equalp)) sigs)))
      (when (< (length have) need)
        (fail "rotation: only ~a of ~a signatures on its rungs" (length have) need))
      (let ((signed
              (loop for tx in rungs for i from 0
                    collect (let* ((ordered (mapcar (lambda (k) (let ((e (assoc k have :test #'equalp))) (and e (nth i (second e))))) keys))
                                   (s (rot:attach-tier-witness tx 0 cur tier-index ordered)))
                              (cond (vault-splice
                                     (rot:attach-tier-witness s 1 cur tier-index
                                                              (mapcar (lambda (k) (let ((e (assoc k have :test #'equalp))) (and e (nth i (third e))))) keys)))
                                    ((getf plan :splice-in) (attach-key-path-witness s 1 (key-path-signature node s 1 prevouts)))
                                    (t s))))))
        (dolist (s signed)
          (dotimes (i (length (btx:tx-inputs s)))
            (unless (rot:verify-spend s i prevouts) (fail "assembled rotation input ~a does not verify" i))))
        (let ((bytes (mapcar #'btx:serialize-tx signed)))
          (note-rotation-rungs node (btx:tx-txid (first signed)) bytes (up:update-block-height qb-update))
          (when (node-broadcast-fn node)
            (handler-case (funcall (node-broadcast-fn node) (first bytes))
              (error (c) (log! node "rotation ~a broadcast failed: ~a" (subseq (bytes->hex (btx:tx-txid (first signed))) 0 16) c))))
          (loop for b in bytes for i from 0
                do (bus:bus-publish (node-bus node) (w:rotation-tx-event (node-keypair node) (record-id-hex rec)
                                                                         (up:update-seq qb-update) (bytes->hex b) i)))
          (log! node "rotation of ~a broadcast after its QuorumBegin (seq ~a): ~a rungs signed by ~a"
                (subseq (record-id-hex rec) 0 8) (up:update-seq qb-update) (length signed) (length have))
          (clear-rotation node rec)
          (btx:tx-txid (first signed)))))))

(defun begin-quorum (node rec &key funding-txid funding-vout amount-msats collateral-msats splice-collateral-msats
                                   ruleset (expiry-blocks 4320) (spending-txid funding-txid))
  "Promote the staged members: chain a QuorumBegin.  The first one points at the
   outpoint funding the reserves output prepared by PREPARE-QUORUM (or built now);
   every later one names the rungs of the rotation ROTATE-VAULT planned (DEP-03): built on
   the tip the QuorumBegin extends (their anchor), recorded, then signed and broadcast.  A
   vault is never replaced by a fresh one while the old lingers.  Returns (values update
   reserves rotation-txid), the last NIL for a first QuorumBegin or while the rungs await
   signatures."
  (let ((rotation (and (has-quorum-begin-p rec)
                       (or (pending-rotation node rec)
                           (fail "a rotation must spend the old vault: rotate-vault first")))))
    (when (and rotation (getf rotation :qb-seq))
      ;; recorded already; only its signatures are missing
      (let ((qu (record-update-at rec (getf rotation :qb-seq))))
        (return-from begin-quorum
          (values qu (record-reserves rec) (ignore-errors (sign-rotation-rungs node rec qu))))))
    (when rotation
      (let* ((new-msats (* 1000 (getf rotation :sats)))
             (ledger (record-ledger rec))
             (coll (+ (rotation-collateral ledger (getf rotation :vault-sats) (getf rotation :fee))
                      (- (* 1000 (+ (or (getf rotation :dormancy-cost) 0) (or (getf rotation :premium) 0))))
                      ;; DEP-20 §4: a splice's value goes to collateral unless told otherwise.
                      (if (getf rotation :splice)
                          (min (* 1000 (third (getf rotation :splice)))
                               (or splice-collateral-msats (* 1000 (third (getf rotation :splice)))))
                          0))))
        (setf funding-vout 0 amount-msats (- new-msats coll) collateral-msats coll)
        (unless (record-pinned rec)
          (setf (record-pinned rec)
                (cons (rs:build-reserves :operator (node-pubkey node) :members (mapcar #'hex->bytes (getf rotation :members))
                                         :ledger-hash (hex->bytes (getf rotation :ledger-hash)) :quorum-expiry (getf rotation :expiry)
                                         :ruleset (getf rotation :ruleset)
                                         :network (intern (string-upcase (node-network node)) :keyword))
                      (getf rotation :expiry)))))))
  (let* ((rotation (and (has-quorum-begin-p rec) (pending-rotation node rec)))
         (ledger (record-ledger rec))
         (staged (lg:ledger-next-quorum-members ledger))
         (members (mapcar #'lg:member-pubkey staged))
         (pinned (or (record-pinned rec) (progn (prepare-quorum node rec :ruleset ruleset :expiry-blocks expiry-blocks)
                                                 (record-pinned rec))))
         (reserves (car pinned)) (expiry (cdr pinned)))
    (unless (equalp (rs:reserves-members reserves) members)
      (fail "staged members changed since the reserves were prepared; prepare again"))
    (flet ((build-op (anchor)
             ;; DEP-03: a rotation's rungs carry the chain hash the QuorumBegin extends, so they are
             ;; built here, on the tip, under the append lock.
             (let* ((rungs (and rotation
                                (or (plan-ladder (getf rotation :plan) anchor collateral-msats)
                                    (fail "the rotation leaves the new vault below dust"))))
                    (txid (if rungs (btx:tx-txid (first rungs)) funding-txid))
                    (op (list :type :quorum-begin :reserves-id (rs:reserves-address reserves)
                              :spending-txid (if rungs txid spending-txid) :new-outpoint-txid txid :new-outpoint-vout funding-vout
                              :amount amount-msats :quorum-expiry expiry :ledger-hash (rs:reserves-ledger-hash reserves)
                              :quorum-members members :collateral-amount collateral-msats
                              :quorum-member-ledger-ids (mapcar #'lg:member-ledger-id staged)
                              :protocol-version (rs:reserves-ruleset reserves))))
               (when rungs
                 (unless (= (btx:txout-value (first (btx:tx-outputs (first rungs)))) (getf rotation :sats))
                   (fail "the rotation's new vault moved since it was planned; rotate-vault again"))
                 (setf (getf (record-rotation rec) :rungs) (mapcar #'unsigned-tx-hex rungs)))
               (if (and rotation (getf rotation :cutoff))
                   (let ((entries (nth-value 1 (settlement ledger (height node) (getf rotation :cutoff))))
                         (dentries (nth-value 2 (settlement ledger (height node) (getf rotation :cutoff))))
                         (mig (nth-value 5 (settlement ledger (height node) (getf rotation :cutoff))))
                         (sp (getf rotation :splice)))
                     (append op (list :exit-cutoff-height (getf rotation :cutoff))
                             (let ((m (median-feerate node (height node)))) (when m (list :reference-feerate (max 2 m))))
                             (when entries (list :exit-outputs entries))
                             (when dentries (list :dormancy-outputs dentries))
                             (let ((cid (lg:consumed-notice-id ledger (getf rotation :cutoff))))
                               (when cid (list :consumed-notice cid)))
                             (when mig (list :migration-manifest (getf mig :entries)
                                             :migration-receiver (getf (lg:ledger-dormancy-notice ledger) :receiver)
                                             :migration-vout (getf mig :vout)))
                             (when sp (list :splice-in-outpoint (splice-outpoint-bytes (hex->bytes (first sp)) (second sp))
                                            :splice-in-amount (* 1000 (third sp))))
                             (when rungs (list :rotation-rungs (apply #'cat (mapcar #'btx:tx-txid rungs))))))
                   op))))
      (let ((update (append-operation node rec nil :op-fn #'build-op
                                      ;; DEP-06: the QuorumBegin is the answer to a challenge of its rungs;
                                      ;; recorded below the spent tier's floor, nothing answers them.
                                      ;; ADVERSARY :skip-answer-floor — an operator that records the
                                      ;; QuorumBegin at DEP-05's requirement alone, as before 2026-11-19
                                      ;; (red team: the members' rung gate is what must stop it).
                                      :tier-floor (when (and rotation (not (getf (node-adversary node) :skip-answer-floor)))
                                                    (let* ((plan (getf rotation :plan))
                                                           (cur (fr:spent-vault (spent-vault-updates rec) (getf plan :governing-seq))))
                                                      (when cur
                                                        (multiple-value-bind (keys need) (fr:answer-cosign-need cur (getf plan :tier-index))
                                                          (cons keys need))))))))
        (setf (record-reserves rec) reserves (record-pinned rec) nil)
        (if (null rotation)
            (values update reserves nil)
            (progn
              ;; Persisted before anyone signs: a restart resumes at the signatures.
              (save-rotation node rec (append (list :qb-seq (up:update-seq update)) (record-rotation rec)))
              (values update reserves
                      (handler-case (sign-rotation-rungs node rec update)
                        (error (c) (log! node "rotation of ~a recorded at seq ~a; its rungs await signatures: ~a"
                                         (subseq (record-id-hex rec) 0 8) (up:update-seq update) c)
                          nil)))))))))

(defun credit-onchain (node rec deposit-id amount-msats &key txid (vout 0) (funding-address ""))
  (append-operation node rec (list :type :onchain-credit :txid txid :vout vout :deposit-id deposit-id
                                   :amount amount-msats :funding-address funding-address)))

;;; ---------------------------------------------------------------------------
;;; Inbound: dispatch

(defun seen-before-p (node event)
  "T if this event id was handled already; remembers the last 5000 ids."
  (let ((id (ev:event-id event)))
    (bt:with-lock-held ((node-lock node))
      (if (gethash id (node-seen node))
          t
          (progn (setf (gethash id (node-seen node)) t)
                 (push id (node-seen-order node))
                 (when (> (length (node-seen-order node)) 5000)
                   (remhash (car (last (node-seen-order node))) (node-seen node))
                   (setf (node-seen-order node) (butlast (node-seen-order node))))
                 nil)))))

(defun handle-event (node event)
  (when (and (/= (ev:event-kind event) w:+kind-response+) (seen-before-p node event))
    (return-from handle-event nil))
  (handler-case
      (case (ev:event-kind event)
        (#.w:+kind-response+ (handle-response node event))
        (#.w:+kind-request+ (unless (string= (ev:event-pubkey event) (k:public-hex (node-keypair node)))
                              (handle-request node event)))
        (#.w:+kind-update+ (unless (string= (ev:event-pubkey event) (k:public-hex (node-keypair node)))
                             (handle-update node event)))
        (#.w:+kind-fraud-proof+ (handle-fraud node event))
        (#.w:+kind-lottery-reveal+ (handle-reveal node event))
        (#.w:+kind-rotation-tx+ (handle-rotation-tx node event))
        (#.w:+kind-spend-challenge+ (handle-spend-challenge node event))
        (#.w:+kind-challenge-answer+ (handle-challenge-answer node event)))
    (error (e) (log! node "event ~a (kind ~a from ~a): ~a" (subseq (ev:event-id event) 0 8) (ev:event-kind event) (subseq (ev:event-pubkey event) 0 8) e))))

(defun handle-response (node event)
  (let ((wt (gethash (w:event-request-id event) (node-pending node))))
    (unless wt
      ;; An answer to a cosign request after its round's deadline: kept for the retry.
      (let ((data (gethash (w:event-request-id event) (node-late-cosign-requests node))))
        (when data (keep-late-cosignature node data (w:parse-json (ev:event-content event)))))
      (let ((sh (gethash (w:event-request-id event) (node-rearm-late-requests node))))
        (when sh (keep-rearm-signature node sh (w:parse-json (ev:event-content event)) :late t)))
      (return-from handle-response nil))
    (progn
      (bt:with-lock-held ((waiter-lock wt))
        ;; relays redeliver: one response per event id
        (when (member (ev:event-id event) (waiter-ids wt) :test #'string=) (return-from handle-response nil))
        (push (ev:event-id event) (waiter-ids wt))
        (push (w:parse-json (ev:event-content event)) (waiter-responses wt))
        ;; carry the responder's pubkey alongside
        (setf (gethash "responder" (car (waiter-responses wt))) (ev:event-pubkey event))
        (bt:condition-notify (waiter-cv wt))))))

(defun handle-request (node event)
  ;; Addressed requests (a "p" tag) for someone else are not ours: the reference
  ;; CLI talks to its own daemon this way, encrypted, over the same relay.
  (let ((to (ev:first-tag-value event "p")))
    (when (and to (string/= to (k:public-hex (node-keypair node))))
      (return-from handle-request nil)))
  ;; ADVERSARY :mute — a member that answers nothing at all (no cosign, no rotation_sign):
  ;; a watcher that only replicates.
  (when (getf (node-adversary node) :mute) (return-from handle-request nil))
  (let ((action (w:event-action event)) (params (w:parse-json (ev:event-content event))))
    (cond ((and (ev:first-tag-value event "p") (string= (ev:first-tag-value event "p") (k:public-hex (node-keypair node)))
                (gethash action (extra-actions node)))
           (funcall (gethash action (extra-actions node)) event params))
          ((string= action "cosign_update") (handle-cosign node event params))
          ((string= action "confiscation_sign") (handle-confiscation-sign node event params))
          ((string= action "theft_sign") (handle-theft-sign node event params))
          ((string= action "rotation_sign") (handle-rotation-sign node event params))
          ((string= action "cosign_offer") (handle-cosign-offer node event params))
          ((string= action "lottery_subset_attest") (handle-lottery-subset-attest node event params))
          ((string= action "lottery_rearm_sign") (handle-lottery-rearm-sign node event params))
          ((string= action "lottery_reveal") (handle-lottery-reveal-request node event params))
          ((string= action "consent_request") (handle-consent node event params))
          ((string= action "cosign_invoice") (handle-cosign-invoice node event params))
          (t (let ((rec (find-record node (w:event-ledger-id event))))
               (when (and rec (record-owned-p rec))
                 (handle-wallet-request node rec event action params)))))))

;;; ---------------------------------------------------------------------------
;;; Inbound: another operator's published update (we replicate ledgers we cosign)

(defun lagging-p (node id-hex)
  "Fault switch :lag-replica (a ledger id prefix): our replica of that ledger applies nothing, as a
   replica under backpressure that keeps missing updates (red team: a lagging honest watcher)."
  (let ((p (getf (node-adversary node) :lag-replica)))
    (and (stringp p) (plusp (length p)) (<= (length p) (length id-hex)) (string= p id-hex :end2 (length p)))))

(defun handle-update (node event)
  (let* ((update (w:event->update event))
         (id (bytes->hex (up:update-ledger-id update)))
         (rec (and (not (lagging-p node id)) (find-record node id)))
         (signer (up:update-operator-id update)))
    (when rec
      (cond
        ;; The operator's own chain.
        ((and (not (record-owned-p rec)) (equalp signer (lg:ledger-operator-key (record-ledger rec))))
         (let ((ledger (record-ledger rec)))
           (cond
             ;; DEP-02 §Sequence: chained onto our tip but numbered past tip+1 is a skip, a
             ;; NonConformingUpdate provable on sight, not a gap to backfill.
             ((and (not (record-fork-p rec))
                   (> (up:update-seq update) (1+ (lg:ledger-sequence ledger)))
                   (equalp (up:update-prev-hash update) (lg:ledger-chain-tip ledger))
                   (up:verify-operator-signature update))
              (report-non-conforming node rec update
                                     (format nil "sequence skip: ~a follows ~a" (up:update-seq update) (lg:ledger-sequence ledger))))
             (t
              (when (and (not (record-fork-p rec)) (> (up:update-seq update) (1+ (lg:ledger-sequence ledger))))
                (catch-up node rec))
              (accept-update node rec update)))))
        ;; FAULT :blind-relay: we follow the operator's chain but read none of the dispute's
        ;; updates (regtest 1121-next4c: confiscation-answer's blind judge saw every member's fork
        ;; and arm on the live subscription, confiscated itself, and had nothing to challenge).
        ((relay-blind-p node id) nil)
        ;; A quorum member's dispute fork (or its continuation).
        ((not (equalp signer (node-pubkey node)))
         (ingest-member-update node rec id signer update))))))

;;; DEP-03 "The dispute": a disputant's counted DisputeEnter is a function of the SET of its
;;; updates, never of their order (two honest nodes receive them in different orders).

(defun entry-order< (a b)
  "The canonical order of one disputant's DisputeEnters: sequence; at one sequence a punitive entry
   before a quorum_expired one; then content hash ascending."
  (let ((sa (up:update-seq a)) (sb (up:update-seq b)))
    (if (/= sa sb) (< sa sb)
        (let ((ea (expiry-reason-p (op:field (op:update-op a) :reason)))
              (eb (expiry-reason-p (op:field (op:update-op b) :reason))))
          (if (not (eq ea eb)) eb
              (let ((ha (up:content-hash a)) (hb (up:content-hash b)))
                (loop for x across ha for y across hb
                      when (/= x y) return (< x y) finally (return nil))))))))

(defun counted-entry (enters acquired-p)
  "Of one disputant's ENTERS (all at or above Q), the one it takes part through: in ENTRY-ORDER<,
   the first, replaced by each later one at a higher sequence unless ACQUIRED-P of the counted
   entry (its fork carries its author's DisputeAcquire), which nothing supersedes.  DISPUTE-SCOPE
   and the ingest (INGEST-MEMBER-UPDATE) both ask this, as deposits-rust's
   rotation_order::dispute_scope does.  Vector enter_after_yield.txt (every permutation)."
  (let* ((es (sort (remove-duplicates (copy-list enters) :test #'equalp :key #'up:content-hash) #'entry-order<))
         (cur (first es)))
    (dolist (e (rest es) cur)
      (when (funcall acquired-p cur) (return cur))
      (when (> (up:update-seq e) (up:update-seq cur)) (setf cur e)))))

(defun fork-acquired-p (updates enter)
  (some (lambda (u) (eq (%op-type u) :dispute-acquire)) (fork-from updates enter)))

(defvar *side-fork-limit* 512 "At most this many held updates per disputant's other forks.")

(defun side-key (id signer) (fork-key id signer))

(defun pool-counted (rec pool)
  "The counted entry among POOL (one disputant's updates of REC's ledger): its enters at or above
   Q (REC's latest QuorumBegin at or below their highest fork point), COUNTED-ENTRY."
  (let* ((enters (remove-if-not (lambda (u) (eq (%op-type u) :dispute-enter)) pool))
         (top (and enters (reduce #'max enters :key (lambda (u) (op:field (op:update-op u) :last-valid-sequence)))))
         (q (and top (record-latest rec :quorum-begin :below (1+ top))))
         (in (remove-if (lambda (u) (and q (< (op:field (op:update-op u) :last-valid-sequence) (up:update-seq q)))) enters)))
    (and in (counted-entry in (lambda (e) (fork-acquired-p pool e))))))

(defun ingest-member-update (node rec id signer update)
  "A quorum member's dispute fork (or its continuation).  The fork we hold for it is the one its
   counted DisputeEnter opens (POOL-COUNTED over everything it sent us of this ledger, whatever
   the order it arrived in); its other updates are held aside (NODE-SIDE-FORKS) until they are
   counted or pruned, so a late DisputeAcquire on a superseded fork, or an earlier entry arriving
   after a later one, moves us to the same fork every member holds."
  (let* ((o (op:decode-operation (up:update-message update)))
         (f (find-fork node id signer))
         (key (side-key id signer)))
    (when (and f (record-owned-p f))
      (return-from ingest-member-update (%ingest-on-fork node f update)))
    (unless (member signer (lg:ledger-quorum-members (record-ledger rec)) :key #'lg:member-pubkey :test #'equalp)
      (return-from ingest-member-update (and f (%ingest-on-fork node f update))))
    (cond ((and f (on-fork-p f update)) (%ingest-on-fork node f update))
          ((and f (not (eq (op:operation-type o) :dispute-enter)) (> (up:update-seq update) (1+ (up:update-seq (tip f))))
                (not (side-chains-p (gethash key (node-side-forks node)) update)))
           ;; a gap on the fork we hold (a burst out of order): CATCH-UP-FORK, as before; what still
           ;; does not land on it is held aside, never dropped
           (handler-case (%ingest-on-fork node f update)
             (error (e) (log! node "fork of ~a by ~a: seq ~a held aside (~a)" (subseq id 0 8) (subseq (bytes->hex signer) 0 8)
                              (up:update-seq update) e)))
           (unless (on-fork-p f update) (hold-aside node key update)))
          ((null f)
           (if (and (eq (op:operation-type o) :dispute-enter) (chains-to-base-p rec update))
               (let ((fork (make-fork node rec (op:field o :last-valid-sequence) signer)))
                 (accept-update node fork update)
                 (log! node "fork of ~a by ~a at seq ~a" (subseq id 0 8) (subseq (bytes->hex signer) 0 8) (op:field o :last-valid-sequence)))
               (hold-aside node key update)))
          (t (hold-aside node key update)))
    (recount-disputant node rec id signer)))

(defun on-fork-p (fork update)
  "UPDATE continues FORK (its previous_hash is FORK's tip's chain hash), or FORK already holds it."
  (let ((tp (tip fork)))
    (or (and tp (equalp (up:update-prev-hash update) (up:chain-hash tp)))
        (find (up:content-hash update) (record-history fork) :key #'up:content-hash :test #'equalp
              :end (min 64 (length (record-history fork)))))))

(defun side-chains-p (side update)
  (some (lambda (u) (equalp (up:update-prev-hash update) (up:chain-hash u))) side))

(defun %ingest-on-fork (node fork update)
  ;; a burst published out of order (the reference appends its QuorumAddMembers and DisputeArmed
  ;; at once): fill the gap first, or the fork never arms here
  (when (> (up:update-seq update) (1+ (lg:ledger-sequence (record-ledger fork))))
    (catch-up-fork node fork (1- (up:update-seq update))))
  (accept-update node fork update))

(defun hold-aside (node key update)
  (let ((side (gethash key (node-side-forks node))))
    (unless (find (up:content-hash update) side :key #'up:content-hash :test #'equalp)
      (setf (gethash key (node-side-forks node))
            (let ((l (cons update side))) (if (> (length l) *side-fork-limit*) (subseq l 0 *side-fork-limit*) l)))
      (save-side-forks node))))

(defun fork-own-pool (fork signer)
  "FORK's own updates by SIGNER past its fork point: the history is newest first, and past the
   fork point every update is the disputant's."
  (loop for u in (record-history fork) while (equalp (up:update-operator-id u) signer) collect u))

(defun chain-from (pool root)
  "ROOT and every update of POOL chained from it (continuation entries included), by sequence."
  (let ((hashes (make-hash-table :test #'equalp)) (out (list root)))
    (setf (gethash (up:chain-hash root) hashes) t)
    (dolist (u (sort (copy-list pool) #'< :key #'up:update-seq) (nreverse out))
      (when (and (not (eq u root)) (gethash (up:update-prev-hash u) hashes))
        (setf (gethash (up:chain-hash u) hashes) t)
        (push u out)))))

(defun chain-root (pool u)
  "The first update of the chain U is on, walking previous_hash back through POOL."
  (loop for p = (find (up:update-prev-hash u) pool :key #'up:chain-hash :test #'equalp)
        while (and p (not (eq p u))) do (setf u p))
  u)

(defun chains-to-base-p (rec enter)
  "ENTER's previous_hash is the chain hash of REC's update at its last_valid_sequence."
  (let* ((lvs (op:field (op:update-op enter) :last-valid-sequence))
         (at (find lvs (record-history rec) :key #'up:update-seq)))
    (and at (equalp (up:update-prev-hash enter) (up:chain-hash at)))))

(defun drain-aside (node key fork)
  "Move onto FORK, in order, what is held aside under KEY and now continues it."
  (loop for u = (find-if (lambda (u) (on-fork-p fork u)) (gethash key (node-side-forks node)))
        while u
        do (setf (gethash key (node-side-forks node)) (remove u (gethash key (node-side-forks node)) :test #'eq))
           (save-side-forks node)
           (ignore-errors (accept-update node fork u))
           (unless (and (tip fork) (equalp (up:content-hash (tip fork)) (up:content-hash u)))
             (return))))

(defun recount-disputant (node rec id signer)
  "Hold the fork SIGNER's counted DisputeEnter is on (POOL-COUNTED over the fork we hold and
   everything held aside): what continues the fork we hold is moved onto it first; when the counted
   entry is on another chain, and that chain is complete back to REC, swap: the fork we hold goes
   aside and the counted one is rebuilt from its first entry with its whole chain."
  (let ((key (side-key id signer)))
    (let ((f (find-fork node id signer))) (when f (drain-aside node key f)))
    (let* ((f (find-fork node id signer))
           (side (gethash key (node-side-forks node)))
           (mine (and f (fork-own-pool f signer)))
           (pool (append mine side))
           (counted (and side (pool-counted rec pool)))
           (root (and counted (not (member counted mine :test #'eq)) (chain-root pool counted))))
      (when (and root (eq (%op-type root) :dispute-enter) (chains-to-base-p rec root))
        (let ((chain (chain-from pool root)))
          (when f (retire-fork node f :superseded t))
          (let ((fork (make-fork node rec (op:field (op:update-op root) :last-valid-sequence) signer)))
            (dolist (u chain) (ignore-errors (accept-update node fork u)))
            (setf (gethash key (node-side-forks node)) (set-difference pool chain :test #'eq))
            (save-side-forks node)
            (drain-aside node key fork))
          (log! node "fork of ~a by ~a: its counted DisputeEnter is seq ~a (DEP-03, set-wise)" (subseq id 0 8)
                (subseq (bytes->hex signer) 0 8) (up:update-seq counted)))))))

(defun save-side-forks (node)
  (when (node-data-dir node)
    (ensure-directories-exist (node-data-dir node))
    (with-open-file (out (merge-pathnames "side-forks.sexp" (node-data-dir node)) :direction :output :if-exists :supersede)
      (with-standard-io-syntax
        (prin1 (loop for k being the hash-keys of (node-side-forks node) using (hash-value v)
                     when v collect (cons k (mapcar (lambda (u) (bytes->hex (up:encode-update u))) v)))
               out)))))

(defun load-side-forks (node)
  (let ((f (and (node-data-dir node) (probe-file (merge-pathnames "side-forks.sexp" (node-data-dir node))))))
    (when f
      (with-open-file (in f)
        (loop for (k . us) in (with-standard-io-syntax (let ((*read-eval* nil)) (read in nil '())))
              do (setf (gethash k (node-side-forks node)) (mapcar (lambda (h) (up:decode-update (hex->bytes h))) us)))))))

(defun accept-update (node rec update)
  "Validate an operator's update against our replica and apply it, one writer at a time."
  (with-replica-writer (rec)
    (%accept-update node rec update)))

(defun %accept-update (node rec update)
  (let ((ledger (record-ledger rec)) (op (op:decode-operation (up:update-message update))))
    (unless (up:verify-operator-signature update) (fail "bad operator signature at seq ~a" (up:update-seq update)))
    (when (and (record-fork-p rec) (not (equalp (up:update-operator-id update) (record-fork-operator rec))))
      (fail "fork update not signed by the fork's operator"))
    (when (<= (up:update-seq update) (lg:ledger-sequence ledger))
      ;; Same sequence, different content, validly signed by the operator: equivocation.
      (let ((ours (record-update-at rec (up:update-seq update))))
        (when (and ours (not (record-fork-p rec))
                   (equalp (up:update-operator-id ours) (up:update-operator-id update))   ; a fork's is not the operator's
                   (not (equalp (up:content-hash ours) (up:content-hash update)))
                   (member (node-pubkey node) (lg:ledger-quorum-members ledger) :key #'lg:member-pubkey :test #'equalp))
          ;; ...and only if it follows this ledger's chain.  ledger_id is unsigned and
          ;; the operator signs its other ledgers with the same key: one of their
          ;; updates, relabelled with this ledger's id, is not an equivocation.
          (if (fr:update-binds-to-ledger-p update (up:update-ledger-id ours)
                                          ;; our chain-hash index is exactly BOUND-HASHES of the history
                                          (if (record-fork-base rec) (fr:bound-hashes (record-history rec)) (record-by-hash (ensure-indexed rec))))
              (progn (log! node "EQUIVOCATION on ~a at seq ~a" (subseq (record-id-hex rec) 0 8) (up:update-seq update))
                     (broadcast-fraud node (fr:make-equivocation-proof (up:update-operator-id update) (up:update-ledger-id update) ours update)))
              (log! node "ignored an update on ~a at seq ~a that is not on its chain (another ledger's, relabelled?)"
                    (subseq (record-id-hex rec) 0 8) (up:update-seq update)))))
      (return-from %accept-update :echo))
    (multiple-value-bind (required signers tier operator-alone allowed)
        (lg:cosign-requirement ledger op (up:update-block-height update))
      (declare (ignore tier operator-alone))
      (unless allowed (fail "uncosignable operation at seq ~a" (up:update-seq update)))
      (when (plusp required)
        (multiple-value-bind (ok why)
            (up:verify-cosignatures update :quorum (mapcar #'lg:member-pubkey signers) :threshold required)
          (unless ok (fail "seq ~a: ~a" (up:update-seq update) why)))))
    (handler-case (let ((v (or (up:header-violation (first (record-history rec)) update
                                                    (lg:signed-header-applies-p ledger update))
                               (cf:violation ledger op (up:update-block-height update)))))
                    (when v (lg::fail :non-conforming v))
                    (lg:apply-update ledger update))
      (lg:ledger-error (e)
        ;; Signed by the operator, cosigned by the threshold, the next sequence —
        ;; and the rules reject it.  That is provable fraud, not a glitch to retry.
        (report-non-conforming node rec update e)
        (error e)))
    (record-push rec update)
    (save-record node rec)
    (run-hooks node rec update)
    :applied))

;;; Following a ledger we are not a member of (couriers, watchers): bootstrap a
;;; replica from what the relays hold, then keep it current like any replica.

(defun ledger-updates-from-relays (node id-hex &key from to)
  "Updates the relays hold for ID-HEX, deduplicated, in sequence order — all of
   them, or just sequences FROM..TO (the `n` tag every update event carries).
   A gap is usually one or two updates; fetching a 6000-update history to fill
   it took 3 s a time and put the replica lane into a spiral."
  (let ((events (bus:bus-fetch (node-bus node)
                               (flt:make-filter :kinds (list w:+kind-update+)
                                                :tags (append (list (cons "d" (list (subseq id-hex 0 16))))
                                                              (when (and from to)
                                                                (list (cons "n" (loop for i from from to to collect (princ-to-string i))))))))))
    ;; Dedup through a hash table: REMOVE-DUPLICATES on a 6000-update list was
    ;; quadratic in EQUALP on 300-byte vectors and took minutes per ledger.
    (let ((seen (make-hash-table :test #'equalp)) (out '())
          ;; FAULT :blind-relay: of a ledger we are blind to, only its operator's own chain (we
          ;; follow the base ledger), never a member's dispute fork.  This is the one funnel every
          ;; relay read of a ledger's updates goes through; the sites that must read nothing of it
          ;; ask RELAY-BLIND-P before calling.
          (only (and (relay-blind-p node id-hex)
                     (let ((r (find-record node id-hex)))
                       (if (and r (not (record-fork-p r))) (lg:ledger-operator-key (record-ledger r)) :none)))))
      (dolist (e events)
        (let* ((u (w:event->update e)) (k (up:encode-update u)))
          (when (and (string= (bytes->hex (up:update-ledger-id u)) id-hex) (not (gethash k seen))
                     (or (null only) (and (not (eq only :none)) (equalp (up:update-operator-id u) only))))
            (setf (gethash k seen) t) (push u out))))
      (sort out #'< :key #'up:update-seq))))

(defun chains-on-p (rec u)
  "U continues REC's chain: the LedgerOpen that derives its id, or an update
   whose previous_hash is its tip.  The relays hold whatever anyone tags with
   the ledger's id, and ledger_id is signed by no one: the operator's updates of
   its other ledgers, relabelled, sit beside the real ones at the same sequences."
  (if (zerop (up:update-seq u))
      (fr:update-opens-ledger-p u (hex->bytes (record-id-hex rec)))
      (equalp (up:update-prev-hash u) (lg:ledger-chain-tip (record-ledger rec)))))

(defun catch-up (node rec)
  "A replica that missed an update (a restart, a relay that dropped us) can never
   apply another: every later one fails 'expected seq N'.  Fetch the operator's
   chain past our sequence and apply it in order.  Returns how many applied."
  (with-replica-writer (rec) (%catch-up node rec)))

(defun %catch-up (node rec)
  (let ((ledger (record-ledger rec)) (n 0) (from (lg:ledger-sequence (record-ledger rec))) (window 200))
    ;; The operator's next update was already refused by the rules (reported and
    ;; disputed then): nothing past it can chain onto our tip.  Every later update
    ;; showed a gap and sent us back into the same refusal, logged each time.
    (when (or (eql (gethash (record-id-hex rec) (node-refused node)) (1+ (lg:ledger-sequence ledger)))
              (lagging-p node (record-id-hex rec)))
      (return-from %catch-up 0))
    ;; Windows of WINDOW sequences past our tip, until a window adds nothing.
    (loop
      (let* ((lo (1+ (lg:ledger-sequence ledger))) (hi (+ lo window -1)) (applied 0)
             (updates (handler-case (ledger-updates-from-relays node (record-id-hex rec) :from lo :to hi)
                        (error (e) (log! node "catch-up on ~a: fetch failed: ~a" (subseq (record-id-hex rec) 0 8) e) '()))))
        (dolist (u updates)
          (when (and (= (up:update-seq u) (1+ (lg:ledger-sequence ledger)))
                     (equalp (up:update-operator-id u) (lg:ledger-operator-key ledger))
                     ;; Not one that follows something else: a relabelled update here
                     ;; failed the chain check, was taken for a rule the operator broke,
                     ;; and stopped this replica's catch-up for good.
                     (chains-on-p rec u))
            (handler-case (when (eq (accept-update node rec u) :applied) (incf n) (incf applied))
              (lg:ledger-error (e)
                (setf (gethash (record-id-hex rec) (node-refused node)) (up:update-seq u))
                (log! node "catch-up on ~a stopped at seq ~a, which the rules reject: ~a (not retried)"
                      (subseq (record-id-hex rec) 0 8) (up:update-seq u) e)
                ;; A cosigned update the rules reject is a fault whether it arrived live or by
                ;; catch-up: report it as the live path does, so our dispute carries its proof
                ;; (DEP-03 §Grounded arms).  REPORT-NON-CONFORMING checks the cosignatures and
                ;; verifies the proof by replay before publishing anything.
                (ignore-errors (report-non-conforming node rec u e))
                (return))
              (error (e) (log! node "catch-up on ~a stopped at seq ~a: ~a" (subseq (record-id-hex rec) 0 8) (up:update-seq u) e)
                (return)))))
        (when (zerop applied) (return))))
    (when (plusp n) (log! node "caught up ~a from seq ~a to ~a" (subseq (record-id-hex rec) 0 8) from (lg:ledger-sequence ledger)))
    n))

(defun catch-up-fork (node fork &optional upto)
  "Another member's dispute fork past whose tip an update arrived (or, at startup, any it
   published while we were down): apply that operator's updates from the relays, in order,
   to UPTO (default 200 past our tip).  Returns how many applied."
  (with-replica-writer (fork) (%catch-up-fork node fork upto)))

(defun %catch-up-fork (node fork upto)
  (let* ((ledger (record-ledger fork)) (lo (1+ (lg:ledger-sequence ledger))) (n 0))
    (dolist (u (handler-case (ledger-updates-from-relays node (record-id-hex fork) :from lo :to (or upto (+ lo 199)))
                 (error (e) (log! node "fork catch-up on ~a: fetch failed: ~a" (subseq (record-id-hex fork) 0 8) e) '()))
               n)
      (when (and (= (up:update-seq u) (1+ (lg:ledger-sequence ledger)))
                 (equalp (up:update-operator-id u) (record-fork-operator fork))
                 (chains-on-p fork u))
        (handler-case (when (eq (accept-update node fork u) :applied) (incf n))
          (error (e)
            (log! node "fork catch-up on ~a by ~a stopped at seq ~a: ~a" (subseq (record-id-hex fork) 0 8)
                  (subseq (bytes->hex (record-fork-operator fork)) 0 8) (up:update-seq u) e)
            (return n)))))))

(defun catch-up-to (node rec seq)
  "Bring REC to SEQ from the relays: the operator's chain, or a fork's by its operator."
  (if (record-fork-p rec) (catch-up-fork node rec seq) (catch-up node rec)))

(defun catch-up-all (node)
  "At startup: every replica we cosign, before the first cosign request arrives."
  (loop for id being the hash-keys of (node-ledgers node) using (hash-value rec)
        do (cond ((not (record-p rec)) (log! node "catch-up: ~a holds ~s, not a record; dropped" id rec)
                                       (remhash id (node-ledgers node)))
                 ((record-owned-p rec))
                 ((record-fork-p rec) (ignore-errors (catch-up-fork node rec)))
                 (t (ignore-errors (catch-up node rec))))))

(defun quorum-names-us-p (node id-hex)
  "Cheap membership pre-check from the relay: the newest QuorumBegin (update
   events carry the operation discriminant as their `t` tag) names the active
   quorum.  NIL also when the relay has none."
  (let* ((events (bus:bus-fetch (node-bus node)
                                (flt:make-filter :kinds (list w:+kind-update+)
                                                 :tags (list (cons "d" (list (subseq id-hex 0 16)))
                                                             (cons "t" (list (princ-to-string (op:discriminant :quorum-begin)))))
                                                 :limit 1)))
         (u (and events (w:event->update (first events))))
         (o (and u (op:decode-operation (up:update-message u)))))
    (and o (member (node-pubkey node) (op:field o :quorum-members) :test #'equalp) t)))

(defvar *deferred-saves* nil "When a list, SAVE-RECORD queues the record here instead of writing.")
(defvar *verify-on-load* (let ((v (uiop:getenv "CLD_VERIFY_ON_LOAD"))) (and v (plusp (length v)) (not (string= v "0"))))
  "Re-verify every signature when loading our own data dir (default: trust it).")

(defun refollow-if-member (node id-hex)
  "Rebuild ID-HEX from the relay if its quorum names us; else remember it as not
   ours for six hours.  NIL when not ours or not reconstructible.  The rebuild
   used to run FIRST — every signature verified and a file write per update
   for a 90k-update ledger, then discarded because we were not a member, then
   again ten minutes later: the replica lane spent its life on it."
  (let ((until (gethash id-hex (node-not-ours node))))
    (when (and until (< (get-universal-time) until)) (return-from refollow-if-member nil)))
  (unless (handler-case (quorum-names-us-p node id-hex) (error () nil))
    (setf (gethash id-hex (node-not-ours node)) (+ (get-universal-time) 21600))
    (return-from refollow-if-member nil))
  (handler-case
      (let* ((rec (let ((*deferred-saves* (list nil))) (follow-ledger node id-hex)))   ; one write at the end, below
             (l (record-ledger rec)))
        (if (or (member (node-pubkey node) (lg:ledger-quorum-members l) :key #'lg:member-pubkey :test #'equalp)
                (member (node-pubkey node) (lg:ledger-next-quorum-members l) :key #'lg:member-pubkey :test #'equalp))
            (progn (log! node "rebuilt our replica of ~a from the relay (seq ~a)" (subseq id-hex 0 8) (lg:ledger-sequence l))
                   (remhash id-hex (node-not-ours node)) (save-record node rec) rec)
            ;; Not in its quorum any more, but a fork of it we hold is built on this replica:
            ;; dropping the file lost every such fork at the next restart ("fork file before its
            ;; base ledger"), and with them the custodian's chain we were asked to consent to
            ;; (signet soak, 2026-10-28, ledger E after custody moved).
            (if (forks-of node id-hex)
                (progn (save-record node rec) rec)
                (progn (remhash id-hex (node-ledgers node))
                       (let ((f (merge-pathnames (record-file-name rec) (node-data-dir node)))) (when (probe-file f) (delete-file f)))
                       nil))))
    (error (e) (log! node "cannot follow ~a: ~a" (subseq id-hex 0 8) e) nil)))

(defun follow-ledger (node id-hex)
  (or (find-record node id-hex)
      (let* ((updates (ledger-updates-from-relays node id-hex))
             (rec (make-record :id-hex id-hex :ledger (lg:make-ledger))))
        ;; Build the chain, not whatever the relays hold at each sequence: two
        ;; updates at seq 0 (one another ledger's, relabelled) made the first one
        ;; the genesis — the rebuilt replica was the operator's other ledger.
        (dolist (u updates)
          ;; ...and the operator's chain: the relay also holds every dispute
          ;; fork's updates under this id, chaining onto the fork point.  Only the
          ;; next link is taken; whatever else sits at a sequence is not ours to judge.
          (when (and (= (up:update-seq u) (1+ (lg:ledger-sequence (record-ledger rec))))
                     (or (zerop (up:update-seq u))
                         (equalp (up:update-operator-id u) (lg:ledger-operator-key (record-ledger rec))))
                     (chains-on-p rec u)
                     (up:verify-operator-signature u))
            (accept-update node rec u)))
        (setf (gethash id-hex (node-ledgers node)) rec)
        rec)))

;;; ---------------------------------------------------------------------------
;;; Inbound: cosign_update (we are a quorum member of this ledger)

(defun member-ledger-hash (node)
  "The content hash of our own ledger's latest update — what we vouch with."
  (let ((own (own-ledger node)))
    (if (and own (tip own)) (up:content-hash (tip own)) (make-array 32 :element-type '(unsigned-byte 8)))))

(defun handle-cosign (node event params)
  (let* ((rec (let ((fo (w:jget params "fork_operator")))
                (if fo
                    (find-fork node (w:event-ledger-id event) (hex->bytes fo))
                    (or (find-record node (w:event-ledger-id event))
                        ;; A ledger we do not hold — perhaps a replica we LOST (see
                        ;; save-record).  Rebuild it from the relay; keep it only if
                        ;; its quorum names us, and cosign again from here on.
                        (refollow-if-member node (w:event-ledger-id event))))))
         (data (hex->bytes (w:jget params "cosign_data_hex")))
         (seq (w:jget params "sequence_number")))
    (cond
      ((or (null rec) (record-owned-p rec)) nil)      ; not a ledger we replicate
      ;; FAULT :refuse-cosign — a member that cosigns nothing (a member declining past expiry,
      ;; one at a time: the answer-floor gate needs fewer cosigners than DEP-05 alone requires).
      ((getf (node-adversary node) :refuse-cosign) nil)
      ;; Only a member (or a staged member, for the QuorumBegin that promotes it) answers.
      ((not (let ((l (record-ledger rec)))
              (or (member (node-pubkey node) (lg:ledger-quorum-members l) :key #'lg:member-pubkey :test #'equalp)
                  (member (node-pubkey node) (lg:ledger-next-quorum-members l) :key #'lg:member-pubkey :test #'equalp))))
       nil)
      ((not (and (>= (length data) 112) (= (length data) (+ 112 (le->int (subseq data 108 112))))))
       (respond node event nil :error "malformed cosign_data"))
      (t
       ;; DEP-02 v2 cosign_data: seq8 || ledger_id32 || height4 || block_hash32 || prev32 || len4 || message.
       ;; We sign exactly these, so we check what they claim.
       (let* ((ledger (record-ledger rec))
              (ledger-id (subseq data 8 40)) (block-height (le->int (subseq data 40 44)))
              (block-hash (subseq data 44 76)) (prev (subseq data 76 108)) (message (subseq data 112))
              (candidate (up:make-signed-update :operator-id (lg:ledger-operator-key ledger) :ledger-id ledger-id
                                                :seq seq :prev-hash prev :message message
                                                :block-height block-height :block-hash block-hash)))
         (handler-case
             (progn
               (unless (equalp ledger-id (hex->bytes (record-id-hex rec))) (fail "ledger_id mismatch"))
               ;; DEP-18 "advertising is a promise": we never cosign under a ruleset whose rules we
               ;; do not enforce, even if seated.
               (let ((r (lg:ledger-active-ruleset ledger)))
                 (when (and r (not (member r lg:+supported-rulesets+ :test #'string=)))
                   (fail "the ledger's ruleset ~a is not one we enforce" r)))
               (unless (record-fork-p rec) (check-not-deposed node rec))
               ;; DEP-02: our tip is only a bound.  A height a little above it we wait for (the
               ;; operator saw a block before we did); the hash is never judged against our chain.
               (let ((ours (loop repeat *cosign-tip-wait-seconds* while (> block-height (height node)) do (own:pause-for 1)
                                 finally (return (height node)))))
                 (when (plusp ours)
                   (when (> (- block-height ours) *cosign-height-tolerance*)
                     (fail "block_height ~a is more than ~a above our tip ~a" block-height *cosign-height-tolerance* ours))
                   (when (> (- ours block-height) *cosign-height-tolerance*)
                     (fail "block_height ~a is more than ~a below our tip ~a" block-height *cosign-height-tolerance* ours))))
               (when (> seq (1+ (lg:ledger-sequence ledger)))
                 (catch-up-to node rec (1- seq)))
               (unless (= seq (1+ (lg:ledger-sequence ledger)))
                 (fail "expected seq ~a" (1+ (lg:ledger-sequence ledger))))
               (unless (equalp prev (lg:ledger-chain-tip ledger)) (fail "chain mismatch: not our tip"))
               (let ((v (up:header-violation (first (record-history rec)) candidate
                                                 (lg:signed-header-applies-p ledger candidate))))
                 (when v (fail "~a" v)))
               (let ((o (op:decode-operation message)))
                 ;; Speculative apply on a fresh replica: the op must be valid on our state.
                 ;; ADVERSARY :cosign-blind — a member that signs whatever chains (red team #1).
                 (unless (getf (node-adversary node) :cosign-blind)
                   ;; Depositor authorization, nonce window, expiry: at the height we sign.
                   (let ((v (or (cf:violation (record-ledger rec) o block-height)
                                (cf:descriptor-refusal (record-ledger rec) o))))
                     (when v (fail "~a" v)))
                   (lg:speculate (record-ledger rec) o block-height seq))
                 (multiple-value-bind (required signers tier operator-alone allowed)
                     (lg:cosign-requirement ledger o block-height)
                   (declare (ignore required signers tier operator-alone))
                   (unless allowed (fail "not cosignable at this height")))
                 (unless (member-cosigns-post-expiry-p block-height (lg:ledger-quorum-expiry ledger)
                                                       (lg::establishment-p o) *cosign-post-expiry-establishment*)
                   (fail "member policy: we do not cosign a rotation past quorum_expiry"))
                 (when (eq (op:operation-type o) :quorum-begin) (check-quorum-begin-vault node rec o params block-height))
                 (when (eq (op:operation-type o) :dormancy-accept) (check-dormancy-accept node rec o params))
                 (when (and (eq (op:operation-type o) :dormancy-notice) (op:field o :migration-receiver))
                   (check-migration-receiver node o)))
               (let* ((mlh (member-ledger-hash node))
                      (c (up:sign-cosignature candidate (node-priv node) (node-pubkey node) mlh)))
                 (log! node "cosigned ~a seq ~a" (subseq (record-id-hex rec) 0 8) seq)
                 (respond node event t
                          :result (w:json-object "cosign_signature_hex" (bytes->hex (up:cosig-signature c))
                                                 "cosigner_pubkey" (node-pubkey-hex node)
                                                 "sequence_number" seq
                                                 "member_ledger_hash_hex" (bytes->hex mlh)))))
           (error (e) (log! node "refused cosign seq ~a: ~a" seq e)
             (respond node event nil :error (princ-to-string e)))))))))

;;; ---------------------------------------------------------------------------
;;; Inbound: consent_request (an operator wants us in their quorum)

(defun handle-consent (node event params)
  ;; For us if the l tag names a ledger we operate (the reference's addressing),
  ;; or the p tag names our key.
  (let* ((to (ev:first-tag-value event "p"))
         (l (w:event-ledger-id event))
         (ours (and l (find-record node l))))
    (unless (or (and ours (record-owned-p ours))
                (and to (string= to (k:public-hex (node-keypair node)))))
      (return-from handle-consent nil))
    (when (and ours (record-owned-p ours)) (setf (node-member-ledger-hex node) l)))
  (let* ((their-id (w:jget params "operator_ledger_id"))
         (operator (hex->bytes (w:jget params "operator_pubkey")))
         (history (map 'list (lambda (b64) (up:decode-update (base64-decode b64))) (w:jget params "ledger_history"))))
    (unless (own-ledger node) (return-from handle-consent (respond node event nil :error "no ledger of our own")))
    (handler-case
        (let* ((genesis-operator (if history (up:update-operator-id (first history)) operator))
               (known (find-record node their-id))
               ;; Forked when the requester is not the operator of our replica: a custodian
               ;; after DisputeAcquire, whose history (a prefix from genesis, or none for a
               ;; long ledger) need not show its fork at all.
               (forked (if known
                           (not (equalp (lg:ledger-operator-key (record-ledger known)) operator))
                           (not (equalp genesis-operator operator))))
               (div (and forked (position-if (lambda (u) (equalp (up:update-operator-id u) operator)) history)))
               (base (or (find-record node their-id)
                         ;; No replica yet: build it from the history's base prefix,
                         ;; or — no history sent (a long ledger) — from the relay.
                         (if history
                             (let ((b (make-record :id-hex their-id :ledger (lg:make-ledger))))
                               (dolist (u (if forked (subseq history 0 div) history)) (accept-update node b u))
                               (setf (gethash their-id (node-ledgers node)) b)
                               b)
                             (follow-ledger node their-id))))
               (rec (cond ((not forked) base)
                          ;; A dispute winner re-establishing on its fork: find or build the fork.
                          ((find-fork node their-id operator))
                          ;; Our replica already follows the winner's chain.
                          ((equalp (lg:ledger-operator-key (record-ledger base)) operator) base)
                          ;; The history is a prefix that ends before the fork (the operator
                          ;; sends at most a few dozen updates): nothing to build the fork from.
                          ((not div) (fail "not yet: no replica of ~a's fork of ~a; retry once it reaches us"
                                           (subseq (bytes->hex operator) 0 8) (subseq their-id 0 8)))
                          (t (make-fork node base (1- (up:update-seq (nth div history))) operator)))))
          ;; Catch up from the piggybacked history, or from the relay when none came.
          (dolist (u history)
            (when (> (up:update-seq u) (lg:ledger-sequence (record-ledger rec)))
              (accept-update node rec u)))
          ;; A fork lags like any replica (a winner's chain after DisputeAcquire is one): judging
          ;; the operator from a stale copy refused every consent the custodian asked for.
          (let ((want (w:jget params "ledger_sequence")))
            (when (and (integerp want) (> want (lg:ledger-sequence (record-ledger rec))))
              (catch-up-to node rec want))
            (unless (equalp (lg:ledger-operator-key (record-ledger rec)) operator)
              (if (and (integerp want) (< (lg:ledger-sequence (record-ledger rec)) want))
                  (fail "not yet: our replica of ~a is at seq ~a, behind the operator's ~a; retry"
                        (subseq their-id 0 8) (lg:ledger-sequence (record-ledger rec)) want)
                  (fail "history is not this operator's"))))
          (unless (record-fork-p rec) (setf (gethash their-id (node-ledgers node)) rec))
          ;; Member policy: a seat on a quorum past its expiry is offered, never owed.
          (let ((e (lg:ledger-quorum-expiry (record-ledger rec))))
            (unless (member-cosigns-post-expiry-p (known-height node) e t *cosign-post-expiry-establishment*)
              (fail "member policy: we do not join a rotation past quorum_expiry ~a" e)))
          (let* ((until (let ((u (w:jget params "membership_until"))) (if (integerp u) u (+ (known-height node) 4320))))
                 (consent (schnorr:schnorr-sign (node-priv node)
                                                (sha256 (cat (ascii->bytes "COLLATERAL_CONSENT") operator (ascii->bytes their-id)))
                                                (random-aux)))
                 (blob (member-response-blob node operator their-id (w:jget params "chosen_ruleset") until params))
                 (blob-sig (schnorr:schnorr-sign (node-priv node) (tagged-hash "deposits/quorum-member-response/v1" blob) (random-aux))))
            ;; Record the membership on OUR ledger.
            (append-operation node (own-ledger node)
                              (list :type :quorum-join :operator-id operator :ledger-id their-id :membership-expires until))
            (respond node event t
                     :result (w:json-object "status" "CONSENT_GRANTED" "consent_signature" (bytes->hex consent)
                                            "membership_expires" until "member_ledger_id" (node-member-ledger-hex node)
                                            "member_response" (base64-encode blob) "member_signature" (bytes->hex blob-sig)))))
      (error (e) (log! node "refused consent: ~a" e) (respond node event nil :error (princ-to-string e))))))

(defun address-spk (node address)
  (multiple-value-bind (witver program)
      (cl-consensus.encoding:segwit-decode address (rs:hrp-for (intern (string-upcase (node-network node)) :keyword)))
    (cat (octets (if (zerop witver) 0 (+ #x50 witver)) (length program)) program)))

(defun check-relayable (tx)
  "DEP-20 §3: every output of a rotation must relay — a standard type at or above its dust
   floor — or one bad exit makes the whole rotation unbroadcastable."
  (loop for out in (btx:tx-outputs tx) for i from 0
        unless (or (lg:standard-output-p (btx:txout-script out) (btx:txout-value out))
                   ;; DEP-03: the anchor, a zero-value OP_RETURN, last (standard: one 32-byte push)
                   (and (= i (1- (length (btx:tx-outputs tx)))) (rot:anchor-of tx)))
          do (fail "rotation output ~a (~a sats, ~a) would not relay" i (btx:txout-value out)
                   (or (lg:spk-type (btx:txout-script out)) "non-standard script"))))

(defun rung-tier-index (cur locktime height)
  "The tier of CUR whose CLTV is LOCKTIME (a rung's nLockTime), when it is open at HEIGHT."
  (let ((i (position locktime (rs:reserves-tiers cur) :key #'rs:tier-locktime)))
    (unless (and i (<= locktime (max height 0))) (fail "nLockTime ~a names no tier open at ~a" locktime height))
    i))

(defun expected-ladder (node rec o height anchor tier-index)
  "DEP-03: the rungs of the rotation the QuorumBegin O (signed at HEIGHT, extending the update
   whose chain hash is ANCHOR) records, built from REC as it stood before O at TIER-INDEX.  The
   new vault is the reserves O's own fields give (members, ledger hash, expiry, ruleset), which
   must be O's reserves_id.  (values rungs prevouts reserves splice)."
  (multiple-value-bind (cur txid vout sats operator) (disputed-reserves node rec)
    (let* ((sp (op:field o :splice-in-outpoint))
           (splice (when sp
                     (let ((stxid (subseq sp 0 32)) (svout (be->int sp :start 32)))
                       (multiple-value-bind (ssats sspk) (splice-prevout node stxid svout)
                         (unless (eql (op:field o :splice-in-amount) (* 1000 ssats))
                           (fail "splice_in_amount_msats is not the outpoint's value"))
                         (list stxid svout ssats sspk)))))
           (prevouts (if splice
                         (vector (cons sats (rs:reserves-spk cur)) (cons (third splice) (fourth splice)))
                         (vector (cons sats (rs:reserves-spk cur)))))
           (tier (or (nth tier-index (rs:reserves-tiers cur)) (fail "tier ~a out of range" tier-index)))
           (next (rs:build-reserves :operator operator :members (op:field o :quorum-members)
                                    :ledger-hash (op:field o :ledger-hash) :quorum-expiry (op:field o :quorum-expiry)
                                    :ruleset (or (op:field o :protocol-version) "cltv-offset-v2")
                                    :network (intern (string-upcase (node-network node)) :keyword)))
           (ledger (record-ledger rec))
           (cutoff (or (op:field o :exit-cutoff-height) (- height lg:+exit-cutoff-margin+))))
      (unless (equalp (address-spk node (op:field o :reserves-id)) (rs:reserves-spk next))
        (fail "reserves_id is not the reserves the QuorumBegin's quorum gives"))
      (values (rot:build-ladder :vault-txid txid :vault-vout vout :vault-sats sats
                                :feerate (lg:rotation-feerate ledger)
                                :voters (length (rs:reserves-voters cur)) :locktime (rs:tier-locktime tier)
                                :new-vault-spk (rs:reserves-spk next) :extras (settlement ledger height cutoff)
                                :splice (and splice (subseq splice 0 3))
                                :splice-vault-p (and splice (equalp (fourth splice) (rs:reserves-spk cur)))
                                :anchor anchor :collateral-msats (op:field o :collateral-amount)
                                :max-rungs (if (op:field o :migration-manifest) 1 rot:+rungs+))
              prevouts cur splice))))

(defun check-rotation-rungs (node rec o proposed &optional (height (height node)))
  "DEP-03 Rotation ordering, step 2: PROPOSED (unsigned rungs, rung order) is, byte for byte, the
   ladder we build for the QuorumBegin O extending our tip, their txids are O's rotation_rungs
   (rung 0's its new outpoint), every output relays, and rung 0's amounts are O's.  Signals
   otherwise.  Nothing is signed on chain yet, so there is no witness to check."
  (unless proposed (fail "a rotating QuorumBegin must carry rotation_rungs_tx"))
  (unless (and (equalp (btx:tx-txid (first proposed)) (op:field o :new-outpoint-txid)) (eql (op:field o :new-outpoint-vout) 0)
               (equalp (op:field o :spending-txid) (op:field o :new-outpoint-txid)))
    (fail "rung 0 is not the QuorumBegin's new outpoint"))
  (multiple-value-bind (cur) (disputed-reserves node rec)
    (let ((tier-index (rung-tier-index cur (btx:tx-locktime (first proposed)) height)))
      (multiple-value-bind (ours prevouts cur2 splice)
          (expected-ladder node rec o height (lg:ledger-chain-tip (record-ledger rec)) tier-index)
        (declare (ignore prevouts cur2))
        (unless (and ours (= (length ours) (length proposed))
                     (every (lambda (a b) (equalp (btx:serialize-tx a :witness nil) (btx:serialize-tx b :witness nil))) ours proposed))
          (fail "rotation_rungs_tx differ from the DEP-03 ladder we build"))
        (unless (equal (mapcar #'bytes->hex (mapcar #'btx:tx-txid ours)) (mapcar #'bytes->hex (fr:rotation-rungs o)))
          (fail "rotation_rungs is not the ladder's txids"))
        (dolist (tx proposed) (check-relayable tx))
        (let* ((ledger (record-ledger rec)) (tx (first proposed))
               (vault-sats (nth-value 3 (disputed-reserves node rec)))
               (cutoff (or (op:field o :exit-cutoff-height) (- height lg:+exit-cutoff-margin+)))
               (extras (settlement ledger height cutoff))
               (exits-cost (nth-value 3 (settlement ledger height cutoff)))
               (dorm-cost (nth-value 4 (settlement ledger height cutoff)))
               (new (btx:txout-value (first (btx:tx-outputs tx)))))
          (unless (= new (floor (+ (op:field o :amount) (op:field o :collateral-amount)) 1000))
            (fail "QuorumBegin amounts do not sum to the rotation's new vault"))
          (let* ((added (if splice (third splice) 0))
                 (c0 (- (rotation-collateral ledger vault-sats (- (+ vault-sats added) (reduce #'+ extras :key #'cdr) new exits-cost dorm-cost))
                        (* 1000 (+ dorm-cost (nth-value 6 (settlement ledger height cutoff)))))))
            (unless (<= c0 (op:field o :collateral-amount) (+ c0 (* 1000 added)))
              (fail "QuorumBegin collateral is not the DEP-20 §3-4 share"))))))))

(defun check-reference-feerate (node o height)
  "DEP-03: a recorded reference feerate must lie within the bounds the last 6 blocks give."
  (let ((f (op:field o :reference-feerate)) (m (median-feerate node height)))
    (when (and f m)
      (multiple-value-bind (lo hi) (feerate-bounds m)
        (unless (<= lo f hi) (fail "reference feerate ~a outside [~a, ~a] (median ~a)" f lo hi m))))))

(defun check-quorum-begin-vault (node rec o params &optional (height (height node)))
  "A QuorumBegin that rotates a current vault is checked against the unsigned rungs it carries
   (DEP-03 Rotation ordering); one with no current vault (the first, or the first after a
   DisputeAcquire) against the chain."
  ;; DEP-06 §Race: a confiscation that confirmed first decided it.  No rotation of that vault
  ;; can be spent, so we never record one (a post-expiry re-establishment races only until then).
  ;; Read from the chain, not from what our dispute pass has noted: that lags the block by a pass
  ;; (regtest 2026-11-15: a member cosigned the QuorumBegin 9 s before it noted the confiscation).
  ;; Its rungs are signed only after it is final, so any confirmed spend of the vault is another's.
  (when (and (has-quorum-begin-p rec) (not (record-fork-p rec)))
    (when (reserves-confiscated-p node rec)
      (fail "the vault's confiscation confirmed: no rotation of it can be spent"))
    (multiple-value-bind (r txid vout) (ignore-errors (disputed-reserves node rec))
      (when (and r txid (vault-spent-confirmed-p node txid vout))
        (fail "the vault was spent on chain (a confiscation confirmed): no rotation of it can be spent"))))
  (if (and (has-quorum-begin-p rec) (not (record-fork-p rec)))
      (let ((rungs (mapcar (lambda (h) (btx:parse-tx (bw:make-reader (hex->bytes h))))
                           (coerce (or (w:jget params "rotation_rungs_tx") #()) 'list))))
        (check-rotation-rungs node rec o rungs height)
        (check-reference-feerate node o height))
      (progn (check-reserves-outpoint node o) (check-reference-feerate node o height))))

;;; DEP-03 §Fee ladder: every rung of a recorded rotation we hold, (re)broadcast until one confirms.
;;; Rung i goes out once the QuorumBegin is 6·i blocks old with none confirmed: every holder
;;; computes the same schedule, so all of them push the same rung.

(defparameter *rung-bump-blocks* 6 "DEP-03: blocks a rung may stay unconfirmed before the next replaces it.")

(defun note-rotation-rungs (node rung0-txid rung-bytes qb-height)
  "Keep RUNG-BYTES (signed, rung order; NIL where unknown) of the rotation whose rung 0 is RUNG0-TXID."
  (let* ((e (gethash rung0-txid (node-inflight-rotations node)))
         (have (and e (getf e :rungs)))
         (n (max (length rung-bytes) (length have)))
         (merged (loop for i below n collect (or (nth i rung-bytes) (nth i have)))))
    (setf (gethash rung0-txid (node-inflight-rotations node))
          (list :rungs merged :qb-height (or qb-height (and e (getf e :qb-height)) 0)))))

(defun handle-rotation-tx (node event)
  "Kind 9107: keep a rung of a recorded rotation to (re)broadcast and bump, as any watcher may."
  (ignore-errors
   (let* ((c (w:parse-json (ev:event-content event)))
          (rec (find-record node (w:jget c "ledger_id")))
          (bytes (hex->bytes (w:jget c "tx")))
          (txid (btx:tx-txid (btx:parse-tx (bw:make-reader bytes))))
          (qu (and rec (record-update-at rec (w:jget c "sequence"))))
          (o (and qu (op:decode-operation (up:update-message qu))))
          (rungs (and o (eq (op:operation-type o) :quorum-begin) (fr:rotation-rungs o)))
          (i (and rungs (position txid rungs :test #'equalp))))
     (when i
       (note-rotation-rungs node (first rungs) (loop for k from 0 to i collect (and (= k i) bytes)) (up:update-block-height qu))))))

(defun vault-spent-confirmed-p (node txid vout)
  "TXID:VOUT is spent by a CONFIRMED transaction: gone from the confirmed UTXO set (a mempool
   spend leaves it there).  A chain view that takes no mempool switch is asked as it is."
  (and (node-chain-fn node)
       (null (ignore-errors
              (handler-case (funcall (node-chain-fn node) txid vout nil)
                (program-error () (funcall (node-chain-fn node) txid vout)))))))

(defun vault-spent-p (node txid vout)
  "TXID:VOUT (internal-order bytes), a vault the ledger names, is not unspent in our chain view
   (mempool included).  NIL without a chain view: never judged blind."
  (and (node-chain-fn node) (null (ignore-errors (funcall (node-chain-fn node) txid vout)))))

(defun rotation-rung-confirmed-p (node qu)
  "Some rung of the rotation QuorumBegin QU has its new vault (output 0) in our chain view."
  (let ((o (op:decode-operation (up:update-message qu))))
    (and (node-chain-fn node)
         (some (lambda (txid) (ignore-errors (funcall (node-chain-fn node) txid 0))) (fr:rotation-rungs o))
         t)))

(defun drive-rotation-rebroadcast (node)
  "DEP-03: rebroadcast every recorded rotation we hold until a rung confirms, moving to rung i
   once its QuorumBegin is 6·i blocks old.  Also resumes the signing of a rotation of ours that
   was recorded but not yet signed (a restart, or too few members answered)."
  (loop for rec being the hash-values of (node-ledgers node)
        when (and (record-owned-p rec) (not (record-fork-p rec)))
          do (let ((r (pending-rotation node rec)))
               (when (and r (getf r :qb-seq))
                 (let ((qu (record-update-at rec (getf r :qb-seq))))
                   (cond
                     ((null qu) (clear-rotation node rec))
                     ;; Its vault is gone (a confiscation confirmed first): nothing to sign or
                     ;; broadcast, and asking the members again only collects refusals.
                     ((let ((plan (getf r :plan)))
                        (and plan (getf plan :vault-txid)
                             (vault-spent-p node (hex->bytes (getf plan :vault-txid)) (getf plan :vault-vout))
                             (not (rotation-rung-confirmed-p node qu))))
                      (log! node "rotation of ~a: its vault ~a:~a was spent by another transaction; abandoned"
                            (subseq (record-id-hex rec) 0 8) (subseq (getf (getf r :plan) :vault-txid) 0 16)
                            (getf (getf r :plan) :vault-vout))
                      (clear-rotation node rec))
                     (t
                       (handler-case (sign-rotation-rungs node rec qu :timeout 30)
                         (error (c) (log! node "rotation of ~a still awaits its rung signatures: ~a" (subseq (record-id-hex rec) 0 8) c)))))))))
  (when (and (node-broadcast-fn node) (node-chain-fn node))
    (loop for rung0 being the hash-keys of (node-inflight-rotations node) using (hash-value e)
          do (let* ((rungs (getf e :rungs))
                    (confirmed (loop for b in rungs
                                     thereis (and b (let ((info (ignore-errors (funcall (node-chain-fn node) (btx:tx-txid (btx:parse-tx (bw:make-reader b))) 0))))
                                                      (and info (>= (or (getf info :confirmations) 0) 1)))))))
               (if confirmed
                   (remhash rung0 (node-inflight-rotations node))
                   (let* ((want (min (1- (length rungs)) (max 0 (floor (- (height node) (getf e :qb-height)) *rung-bump-blocks*))))
                          (b (loop for i from want downto 0 thereis (nth i rungs))))
                     (when b (ignore-errors (funcall (node-broadcast-fn node) b)))))))))

(defun check-reserves-outpoint (node o)
  "DEP-03: a cosigner verifies the QuorumBegin outpoint against its own chain
   view — exists, unspent, value = (reserves + collateral)/1000 sats, confirmed."
  (when (node-chain-fn node)
    (let* ((info (funcall (node-chain-fn node) (op:field o :new-outpoint-txid) (op:field o :new-outpoint-vout)))   ; internal-order bytes
           (want (floor (+ (op:field o :amount) (op:field o :collateral-amount)) 1000)))
      (unless info (fail "reserves outpoint not found or spent"))
      (unless (= (getf info :value-sats) want) (fail "reserves outpoint value ~a != ~a" (getf info :value-sats) want))
      (unless (>= (getf info :confirmations) (node-min-confs node)) (fail "reserves outpoint has ~a confirmations" (getf info :confirmations))))))

(defun random-aux ()
  "32 bytes from the OS.  CL's RANDOM is deterministic in a fresh image — three
   daemons once started with the same key because of it."
  (with-open-file (in "/dev/urandom" :element-type '(unsigned-byte 8))
    (let ((a (make-array 32 :element-type '(unsigned-byte 8)))) (read-sequence a in) a)))

(defun member-response-blob (node operator their-id ruleset until params)
  "QuorumMemberResponse TLV (deposits-protocol/src/types/quorum_member_response.rs)."
  (tlv:encode
   (remove nil
           (list (cons 1 (int->be 1 2)) (cons 2 (node-pubkey node)) (cons 3 operator)
                 (cons 4 (ascii->bytes their-id)) (cons 5 (ascii->bytes (or ruleset "cltv-offset-v2")))
                 (cons 6 (ascii->bytes (node-member-ledger-hex node)))
                 ;; ADVERSARY :withhold-rulesets — a member that declares fewer rulesets (red team:
                 ;; DEP-18's refusal of a ruleset a seated member did not declare).
                 (cons 7 (apply #'cat (mapcar (lambda (s) (cat (octets (length s)) (ascii->bytes s)))
                                              (set-difference lg:+supported-rulesets+ (getf (node-adversary node) :withhold-rulesets)
                                                              :test #'string=))))
                 (let ((v (w:jget params "min_fee_bps"))) (and v (cons 10 (int->be v 2))))
                 (let ((v (w:jget params "min_fee_fixed"))) (and v (cons 11 (int->be v 8))))
                 (let ((v (w:jget params "max_fee_period"))) (and v (cons 12 (int->be v 4))))
                 (and (integerp until) (cons 13 (int->be until 4)))))))

;;; ---------------------------------------------------------------------------
;;; DEP-10 funding offers (we are the operator, or a member cosigning one)

(defun offer-cosign-digest (ledger-id-hex offer-id deposit-id operator33 address deadline member-ledger-hash)
  (lg:offer-cosign-digest ledger-id-hex offer-id deposit-id operator33 address deadline member-ledger-hash))

(defun offer-address (node offer-id)
  "A key-path P2TR of our key committing OFFER-ID (tweaked by it), so each offer's payments are its own."
  (let ((spk (lot:p2tr-spk (up:x-only (node-pubkey node)) (sha256 offer-id))))
    (values (cl-consensus.encoding:segwit-encode (rs:hrp-for (intern (string-upcase (node-network node)) :keyword)) 1
                                                 (subseq spk 2))
            spk)))

(defun make-offer (node rec descriptor max-sats min-sats blocks-valid)
  "DEP-10: a funding offer for DESCRIPTOR's deposit, cosigned by a member once the quorum is
   active.  Returns the response object."
  (unless (< 0 min-sats max-sats) (fail "need 0 < min_sats < max_sats"))
  (let* ((offer-id (random-aux)) (deadline (+ (known-height node) blocks-valid)))
    (multiple-value-bind (address spk) (offer-address node offer-id)
      (let ((offer (list :offer-id offer-id :descriptor descriptor :deposit-id (op:deposit-id descriptor)
                         :address address :spk spk :deadline deadline :min min-sats :max max-sats :status :pending))
            (cosign nil))
        (when (eq (lg:ledger-quorum-state (record-ledger rec)) :active)
          (let ((r (first (send-request node (record-id-hex rec) "cosign_offer"
                                        (w:json-object "offer_id" (bytes->hex offer-id) "operator_id" (node-pubkey-hex node)
                                                       "deposit_id" (bytes->hex (op:deposit-id descriptor))
                                                       "funding_address" address "deadline_block" deadline)
                                        :want 1 :successes-only t))))
            (let ((res (and r (w:jget r "result"))))
              (when (stringp res) (setf res (w:parse-json res)))
              (unless res (fail "no member cosigned the offer"))
              (let ((pk (hex->bytes (w:jget res "cosigner_pubkey"))) (sig (hex->bytes (w:jget res "signature_hex")))
                    (mlh (hex->bytes (w:jget res "member_ledger_hash_hex"))))
                (unless (schnorr:schnorr-verify (up:x-only pk)
                                                (offer-cosign-digest (record-id-hex rec) offer-id (op:deposit-id descriptor) (node-pubkey node) address deadline mlh) sig)
                  (fail "offer cosignature does not verify"))
                (setf cosign res)))))
        (setf (gethash offer-id (record-offers rec)) offer)
        (apply #'w:json-object "offer_id" (bytes->hex offer-id) "operator_id" (node-pubkey-hex node)
               "deposit_id" (bytes->hex (op:deposit-id descriptor))
               "funding_address" address "deadline_block" deadline "max_sats" max-sats "min_sats" min-sats
               "cosign_required" (and cosign t)
               (when cosign (list "cosigner_pubkey" (w:jget cosign "cosigner_pubkey")
                                  "cosigner_ledger_hash" (w:jget cosign "member_ledger_hash_hex")
                                  "cosign_signature" (w:jget cosign "signature_hex"))))))))

(defun complete-offer (node rec offer-id txid vout)
  "DEP-10 §Completion: credit output VOUT of TXID if it pays the offer's address and confirmed at
   a height <= its deadline; the credit is the output's value (capped at the maximum)."
  (let ((offer (or (gethash offer-id (record-offers rec)) (fail "unknown offer"))))
    (when (eq (getf offer :status) :completed) (return-from complete-offer (getf offer :credited)))
    (let ((info (or (and (node-chain-fn node) (funcall (node-chain-fn node) txid vout)) (fail "no such unspent output"))))
      (unless (equalp (getf info :spk) (getf offer :spk)) (fail "the output does not pay the offer's address"))
      (let ((confs (or (getf info :confirmations) 0)))
        (unless (plusp confs) (fail "the funding output is unconfirmed"))
        (when (> (- (height node) (1- confs)) (getf offer :deadline))
          (fail "funding confirmed after the offer's deadline ~a" (getf offer :deadline))))
      (let ((sats (getf info :value-sats)))
        (when (< sats (getf offer :min)) (fail "funding ~a sats below the minimum ~a" sats (getf offer :min)))
        (let ((msat (* 1000 (min sats (getf offer :max)))) (id (getf offer :deposit-id)))
          (unless (gethash id (lg:ledger-deposits (record-ledger rec)))
            (append-operation node rec (list :type :deposit-open :deposit-id id :descriptor (getf offer :descriptor)
                                             :fees (op:make-fees :frequency-blocks 2016) :receive-requires-sig nil)))
          (credit-onchain node rec id msat :txid txid :vout vout :funding-address (getf offer :address))
          (setf (getf (gethash offer-id (record-offers rec)) :status) :completed
                (getf (gethash offer-id (record-offers rec)) :credited) msat)
          msat)))))

(defun dormancy-offer (node rec)
  "DEP-20 §8.3: what a DormancyOffer (Kind 9110) offers now: (values manifest-entries hash total)."
  (let ((m (lg:dormancy-offer-entries (record-ledger rec) (height node))))
    (values m (sha256 (op:encode-manifest m)) (reduce #'+ m :key (lambda (e) (getf e :amount))))))

(defun accept-address (node rec)
  "DEP-20 §8.3: the address a receiver's accept names — its current vault, so the migration sits
   under the quorum's tiers until spliced.  (values address spk)."
  (let ((reserves (disputed-reserves node rec)))
    (values (rs:reserves-address reserves) (rs:reserves-spk reserves))))

(defun dormancy-accept (node rec manifest offer-event-id total &key (expiry-blocks 288) premium-deposit source-ledger)
  "DEP-20 §8.3 receiver: accept a manifest.  Cosigners check its hash, our capacity and fee floors.
   Returns the signed update (its bytes go into the source's DormancyNotice)."
  (let ((hash (sha256 (op:encode-manifest manifest))))
    (multiple-value-bind (address spk) (accept-address node rec)
      (declare (ignore address))
      (let ((*extra-cosign-params* (list "migration_manifest" (bytes->hex (op:encode-manifest manifest)))))
        (append-operation node rec (%strip-nil-fields
                                    (list :type :dormancy-accept :deposit-id premium-deposit :exit-address spk
                                          :expires-at-height (+ (known-height node) expiry-blocks) :manifest-hash hash
                                          :offer-event-id offer-event-id :accepted-total total
                                          :source-ledger-id source-ledger)))))))

(defun check-dormancy-accept (node rec o params)
  "A receiver's cosigner: the accept names our current vault script, the manifest the request
   carries hashes to the accept's, and our quorum's fee floors are at or below every deposit's
   schedule (DEP-20 §8.3)."
  (unless (equalp (op:field o :exit-address) (ignore-errors (rs:reserves-spk (disputed-reserves node rec))))
    (fail "the accept does not name our current vault script"))
  (let* ((hex (or (w:jget params "migration_manifest") (fail "a DormancyAccept cosign must carry the manifest")))
         (m (op:decode-manifest (hex->bytes hex))))
    (unless (equalp (sha256 (hex->bytes hex)) (op:field o :manifest-hash)) (fail "manifest does not hash to the accept's"))
    (dolist (mem (lg:ledger-quorum-members (record-ledger rec)))
      (dolist (e m)
        (let ((f (getf e :fees)))
          (when (or (and (lg::member-min-fee-bps mem) (< (op:fees-annualized-bps f) (lg::member-min-fee-bps mem)))
                    (and (lg::member-min-fee-fixed mem) (< (op:fees-annualized-msats f) (lg::member-min-fee-fixed mem))))
            (fail "deposit ~a's fees are below a member's floor" (bytes->hex (getf e :deposit-id)))))))))

(defun receiver-history (node ledger-id-hex)
  "A receiver ledger's history, ascending: our replica if we hold one, else the relays'."
  (let ((r (find-record node ledger-id-hex)))
    (if (and r (not (record-fork-p r))) (reverse (record-history r)) (ledger-updates-from-relays node ledger-id-hex))))

(defun receiver-governing-quorum-begin (node accept-update)
  "DEP-20 §8.3: the receiver's latest QuorumBegin before ACCEPT-UPDATE, from its history."
  (let ((qb nil))
    (dolist (u (receiver-history node (bytes->hex (up:update-ledger-id accept-update))))
      (when (and (< (up:update-seq u) (up:update-seq accept-update))
                 (eq (ignore-errors (op:update-type u)) :quorum-begin))
        (setf qb u)))
    (or qb (fail "the receiver's ledger has no QuorumBegin before the accept"))))

(defun check-migration-receiver (node o)
  "DEP-20 §8.3 (L4), a source cosigner: the accept is in the receiver's canonical history, the
   carried QuorumBegin is the receiver's latest (its quorum is current), and that vault is funded
   and unspent on chain."
  (let* ((au (up:decode-update (op:field o :dormancy-accept)))
         (qu (up:decode-update (or (op:field o :receiver-quorum-begin) (fail "no receiver_quorum_begin"))))
         (qb (op:decode-operation (up:update-message qu)))
         (hist (receiver-history node (bytes->hex (up:update-ledger-id au))))
         (ours (find (up:update-seq au) hist :key #'up:update-seq))
         (latest-qb (let ((q nil))
                      (dolist (u hist q)
                        (when (eq (ignore-errors (op:update-type u)) :quorum-begin)
                          (setf q u))))))
    (unless (and ours (equalp (up:chain-hash ours) (up:chain-hash au)))
      (fail "the accept is not in the receiver's history"))
    (unless (and latest-qb (equalp (up:chain-hash latest-qb) (up:chain-hash qu)))
      (fail "the carried QuorumBegin is not the receiver's current one"))
    (when (node-chain-fn node)
      (let ((info (funcall (node-chain-fn node) (op:field qb :new-outpoint-txid) (op:field qb :new-outpoint-vout))))
        (unless (and info (plusp (or (getf info :confirmations) 0))
                     (= (getf info :value-sats) (floor (+ (op:field qb :amount) (op:field qb :collateral-amount)) 1000)))
          (fail "the receiver's vault is not funded and unspent on chain"))))
    t))

(defun migration-source-updates (node accept source-ledger-hex)
  "DEP-20 §8.3 receiver: from SOURCE-LEDGER-HEX's history, the notice carrying ACCEPT (our accept
   record) and the QuorumBegin that consumed it: (values notice-update qb-update) or NIL."
  (let* ((hist (receiver-history node source-ledger-hex))
         (nu (find-if (lambda (u) (let ((o (ignore-errors (op:decode-operation (up:update-message u)))))
                                    (and o (eq (op:operation-type o) :dormancy-notice)
                                         (equalp (op:field o :manifest-hash) (getf accept :hash)))))
                      hist :from-end t))
         (id (and nu (sha256 (up:update-message nu))))
         (qu (and id (find-if (lambda (u) (let ((o (ignore-errors (op:decode-operation (up:update-message u)))))
                                            (and o (eq (op:operation-type o) :quorum-begin)
                                                 (equalp (op:field o :consumed-notice) id))))
                              hist))))
    (when qu (values nu qu))))

(defun dormancy-credit (node rec source-ledger-hex)
  "DEP-20 §8.3 receiver: resolve our accept with positive evidence — the source's notice and the
   QuorumBegin that consumed it (MigrationCredit); the fold credits exactly what migrated."
  (let ((a (or (lg:ledger-dormancy-accept (record-ledger rec)) (fail "no accept to resolve"))))
    (multiple-value-bind (nu qu) (migration-source-updates node a source-ledger-hex)
      (unless qu (fail "the source has not yet consumed the notice"))
      (append-operation node rec (list :type :migration-credit :source-notice-update (up:encode-update nu)
                                       :source-qb-update (up:encode-update qu))))))

(defun handle-cosign-offer (node event params)
  "A member: cosign an operator's funding offer (DEP-10) unless its operator is deposed."
  (let* ((id (w:event-ledger-id event)) (rec (find-record node id)))
    (unless rec (return-from handle-cosign-offer nil))
    (handler-case
        (progn
          (check-not-deposed node rec)
          (unless (member (node-pubkey node) (mapcar #'lg:member-pubkey (lg:ledger-quorum-members (record-ledger rec))) :test #'equalp)
            (fail "not a quorum member"))
          (let* ((offer-id (hex->bytes (w:jget params "offer_id")))
                 (operator (hex->bytes (w:jget params "operator_id")))
                 (address (w:jget params "funding_address")) (deadline (w:jget params "deadline_block"))
                 (deposit-id (hex->bytes (or (w:jget params "deposit_id") (fail "an offer names its deposit_id (DEP-10)"))))
                 (mlh (member-ledger-hash node)))
            (unless (equalp operator (lg:ledger-operator-key (record-ledger rec))) (fail "not this ledger's operator"))
            (unless (and (= (length offer-id) 32) (stringp address) (integerp deadline)) (fail "malformed offer"))
            (respond node event t
                     :result (w:json-object "signature_hex" (bytes->hex (schnorr:schnorr-sign (node-priv node)
                                                                                            (offer-cosign-digest id offer-id deposit-id operator address deadline mlh)
                                                                                            (random-aux)))
                                            "cosigner_pubkey" (node-pubkey-hex node)
                                            "member_ledger_hash_hex" (bytes->hex mlh)))))
      (error (e) (respond node event nil :error (princ-to-string e))))))

;;; ---------------------------------------------------------------------------
;;; Inbound: wallet requests (we are the operator)

(defun handle-wallet-request (node rec event action params)
  (when (member action (node-ignore-actions node) :test #'string=)
    (log! node "ignoring ~a (test switch)" action)
    (return-from handle-wallet-request nil))
  ;; ADVERSARY :ignore-requests — an operator that answers nothing, with no
  ;; error either: the wallet's request times out and nothing on the ledger
  ;; records why (red team: DEP-12 censorship, the escalation path's start).
  (when (getf (node-adversary node) :ignore-requests)
    (log! node "ADVERSARY: dropping wallet request ~a on ~a" action (subseq (record-id-hex rec) 0 8))
    (return-from handle-wallet-request nil))
  (handler-case
      (cond
        ((string= action "delivery_embed")
         ;; DEP-12: a wallet asks us (a quorum member) to anchor its unanswered request.
         (let ((h (hex->bytes (w:jget params "request_hash")))
               (target (hex->bytes (w:jget params "target_ledger_id")))
               (operator (hex->bytes (w:jget params "target_operator"))))
           (unless (= (length h) 32) (fail "request_hash must be 32 bytes"))
           (append-operation node rec (list :type :delivery-embed :request-hash h :target-ledger-id target :target-operator operator))
           (respond node event t :result (w:json-object "ledger_id" (record-id-hex rec)
                                                        "event_id" (record-last-event-id rec)
                                                        "sequence" (lg:ledger-sequence (record-ledger rec))
                                                        "tip_hash" (bytes->hex (lg:ledger-chain-tip (record-ledger rec)))
                                                        "request_hash" (bytes->hex h)))))
        ((string= action "deposit_open")
         (let* ((descriptor (w:jget params "descriptor"))
                (id (op:deposit-id descriptor)))
           (unless (d17:descriptor-key descriptor) (d16:parse-descriptor descriptor))   ; must be a descriptor we can evaluate
           (append-operation node rec (list :type :deposit-open :deposit-id id :descriptor descriptor
                                            :fees (op:make-fees :annualized-msats (or (w:jget params "annualized_msats") 0)
                                                                :annualized-bps (or (w:jget params "annualized_bps") 0)
                                                                :frequency-blocks (or (w:jget params "frequency_blocks") 2016))
                                            :receive-requires-sig nil))
           (respond node event t :result (w:json-object "deposit_id" (bytes->hex id)))))
        ((string= action "balance_query")
         (let ((d (lg:find-deposit (record-ledger rec) (deposit-id-param params))))
           (respond node event t :result (w:json-object "deposit_id" (bytes->hex (lg:deposit-id d))
                                                        "balance_msats" (lg:deposit-balance d)
                                                        "locked_msats" (lg:deposit-locked-balance d)
                                                        "available_msats" (lg:deposit-available-balance d)
                                                        "balance" (lg:deposit-balance d)
                                                        "locked_balance" (lg:deposit-locked-balance d)
                                                        "sequence" (lg:ledger-sequence (record-ledger rec))))))
        ((string= action "transfer_lock")
         (let* ((o (transfer-lock-from-request params))
                (src (lg:find-deposit (record-ledger rec) (op:field o :source-deposit-id))))
           (unless (eq (op:operation-type o) :transfer-lock) (fail "not a TransferLock"))
           (unless (authorized-p node rec o src (op:field o :witness)) (fail "witness does not authorize this operation"))
           (unless (check-nonce node rec o) (append-operation node rec o))
           (respond node event t :result (w:json-object "transfer_id" (bytes->hex (op:field o :transfer-id))))))
        ((member action '("exit_request" "exit_cancel") :test #'string=)
         ;; DEP-20 §3: a depositor-signed ExitRequest / ExitCancel, appended as signed.
         (let* ((o (op:decode-operation (base64-decode (or (w:jget params "operation") (fail "operation required")))))
                (want (if (string= action "exit_request") :exit-request :exit-cancel))
                (d (lg:find-deposit (record-ledger rec) (op:field o :deposit-id))))
           (unless (eq (op:operation-type o) want) (fail "not an ~a" want))
           (unless (authorized-p node rec o d (op:field o :witness)) (fail "witness does not authorize this operation"))
           (let ((u (or (nth-value 1 (check-nonce node rec o)) (append-operation node rec o))))
             (respond node event t :result (w:json-object "exit_request_id" (bytes->hex (if (eq want :exit-request)
                                                                                          (sha256 (op:encode-operation o))
                                                                                          (op:field o :exit-request-id)))
                                                          "sequence" (up:update-seq u))))))
        ((string= action "transfer_complete")
         (let* ((o (if (w:jget params "operation")
                       (op:decode-operation (base64-decode (w:jget params "operation")))
                       (list :type :transfer-complete :transfer-id (hex->bytes (w:jget params "transfer_id"))
                             :script-witness (list (hex->bytes (or (w:jget params "preimage") (w:jget params "scalar") (fail "preimage required")))))))
                (pending (gethash (op:field o :transfer-id) (lg:ledger-pending-transfers (record-ledger rec)))))
           (unless pending (fail "no such transfer"))
           (unless (completion-satisfied-p (getf pending :completion-script) (op:field o :script-witness))
             (fail "completion script not satisfied"))
           (append-operation node rec o)
           (respond node event t :result (w:json-object "transfer_id" (bytes->hex (op:field o :transfer-id))))))
        ((string= action "make_offer")
         (respond node event t :result (make-offer node rec (or (w:jget params "descriptor") (fail "descriptor required"))
                                                   (or (w:jget params "max_sats") (fail "max_sats required"))
                                                   (or (w:jget params "min_sats") 1) (or (w:jget params "blocks_valid") 144))))
        ((string= action "complete_offer")
         (let* ((tx (w:jget params "txid"))
                ;; display or internal hex: try the display order (what wallets print) first
                (raw (hex->bytes tx))
                (oid (hex->bytes (w:jget params "offer_id"))) (vout (or (w:jget params "vout") (fail "vout required")))
                (msat (handler-case (complete-offer node rec oid (reverse raw) vout)
                        (error () (complete-offer node rec oid raw vout)))))
           (respond node event t :result (w:json-object "status" "SUCCESS" "credited_msats" msat))))
        ((string= action "make_invoice") (handle-make-invoice node rec event params))
        ((string= action "pay_invoice") (handle-pay-invoice node rec event params))
        (t (respond node event nil :error (format nil "unknown action ~a" action))))
    (error (e) (respond node event nil :error (princ-to-string e)))))

;;; Authorization: pk(K) deposits take the direct ECDSA path; anything else is
;;; a DEP-16 descriptor evaluated against the deposit's state snapshot.

(defun deposit-snapshot (node ledger d)
  (let ((h (height node)))
    (d16:make-snapshot :balance (lg:deposit-balance d)
                       :blocks-since-activity (max 0 (- h (lg:deposit-last-activity-block d)))
                       :blocks-since-open (max 0 (- h (lg:deposit-opened-at-block d)))
                       :blocks-since-received (max 0 (- h (lg:deposit-last-received-block d)))
                       :height h)
    ))

(defun authorized-p (node rec o d witness)
  "Does deposit D's descriptor authorize operation O with WITNESS (a stack)?
   (The rule itself, with the nonce window and expiry, is CF:VIOLATION: cosigners
   and replicas apply it too.)"
  (declare (ignore rec))
  (let ((o (if (equal witness (op:field o :witness)) o (list* :witness witness (copy-list o)))))
    (cf:authorized-p o d (height node))))

;;; Requests in the reference wallet's shape (field by field, signature = witness)

(defun witness-from-json (v)
  "A DescriptorWitness as the reference serialises it: {\"stack\": [...]}, a bare
   array, or a single hex signature; elements as hex strings or byte arrays."
  (let ((stack (cond ((hash-table-p v) (gethash "stack" v)) (t v))))
    (cond ((stringp stack) (list (hex->bytes stack)))
          ((vectorp stack) (map 'list (lambda (e) (if (stringp e) (hex->bytes e) (coerce (map 'list #'identity e) 'octets))) stack))
          (t '()))))

(defun transfer-lock-from-request (params)
  (if (w:jget params "operation")
      (op:decode-operation (base64-decode (w:jget params "operation")))
      (list :type :transfer-lock
            :transfer-nonce (hex->bytes (w:jget params "transfer_nonce"))
            :source-deposit-id (hex->bytes (w:jget params "source_deposit_id"))
            :destination-deposit-id (hex->bytes (w:jget params "destination_deposit_id"))
            :amount (w:jget params "amount") :fee (or (w:jget params "fee") 0)
            :completion-script (w:jget params "completion_script") :timeout-height (w:jget params "timeout_height")
            :transfer-id (hex->bytes (w:jget params "transfer_id"))
            :nonce (w:jget params "op_nonce") :expiry (w:jget params "op_expiry")
            :witness (or (witness-from-json (w:jget params "witness"))
                         (list (hex->bytes (or (w:jget params "signature") (fail "signature required"))))))))

;;; ---------------------------------------------------------------------------
;;; Lightning: pay_invoice (DEP-10 pay).  InvoiceLock on the deposit, pay through
;;; the node's Lightning backend, then InvoiceFulfill with the preimage or
;;; InvoiceFail.

(defun settle-invoice-lock (node rec payment-id outcome preimage)
  "Append the InvoiceFulfill or InvoiceFail that OUTCOME calls for, if the lock is
   still open.  Only a definitive outcome settles: :succeeded with a preimage that
   hashes to the payment id, or :failed.  Returns the operation appended, or NIL."
  (let ((lock (gethash payment-id (lg:ledger-open-invoice-locks (record-ledger rec)))))
    (when lock
      (cond
        ((and (eq outcome :succeeded) preimage (equalp (sha256 preimage) payment-id))
         (let ((o (list :type :invoice-fulfill :deposit-id (getf lock :deposit-id) :amount (getf lock :amount)
                        :payment-id payment-id :sequence-number (1+ (lg:ledger-sequence (record-ledger rec)))
                        :witness (getf lock :witness) :preimage preimage)))
           (append-operation node rec o) o))
        ((eq outcome :failed)
         (let ((o (list :type :invoice-fail :deposit-id (getf lock :deposit-id) :payment-id payment-id
                        :sequence-number (1+ (lg:ledger-sequence (record-ledger rec))))))
           (append-operation node rec o) o))))))

(defvar *pay-poll-rounds* 60 "Half-second polls a pay_invoice handler waits before answering pending.")

;;; DEP-17 §duplicate delivery.  A relay can deliver one request twice, and a wallet retries a
;;; request whose answer it missed.  The operation it carries is then already on the ledger:
;;; answer as we answered it, never append it again and never answer with a replay error.

(defun nonce-check (node rec o)
  "Classify depositor-signed operation O against REC's ledger at our height:
   (values verdict original-op original-update), VERDICT one of cf:nonce-verdict's.  The
   ledger's seen nonces say whether a live operation shares O's nonce; only then is the history
   read for those operations' sighashes."
  (let* ((h (height node)) (nonce (op:field o :nonce)) (expiry (op:field o :expiry))
         (d (lg:find-deposit (record-ledger rec) (cf:operation-deposit-id o)))
         (live (count-if (lambda (seen) (and (eql (car seen) nonce) (cdr seen) (>= (cdr seen) h)))
                         (lg:deposit-seen-nonces d)))
         (sighash (cf:signed-sighash o)) (accepted '()) (hit nil))
    (when (plusp live)
      (loop for u in (record-history rec)
            for a = (and (member (ignore-errors (op:update-type u))
                                 '(:invoice-lock :onchain-lock :transfer-lock :deposit-key-rotate :exit-request :exit-cancel))
                         (ignore-errors (op:decode-operation (up:update-message u))))
            when (and a (eql (ignore-errors (op:field a :nonce)) nonce)
                      (equalp (cf:operation-deposit-id a) (cf:operation-deposit-id o))
                      (cf:signed-sighash a))
              do (let ((sh (cf:signed-sighash a)))
                   (push (list nonce (op:field a :expiry) sh) accepted)
                   (when (and (null hit) (equalp sh sighash)) (setf hit (cons a u))))
            until (>= (count-if (lambda (x) (>= (second x) h)) accepted) live)))
    (values (cf:nonce-verdict accepted nonce expiry sighash h) (car hit) (cdr hit))))

(defun check-nonce (node rec o)
  "Fail on an expired or replayed O; return the accepted original when O is its duplicate."
  (multiple-value-bind (verdict original update) (nonce-check node rec o)
    (ecase verdict
      (:expired (fail "operation expired"))
      (:replay (fail "nonce replayed"))
      (:duplicate (values original update))
      (:accept nil))))

(defun invoice-fulfill-preimage (rec payment-id)
  (loop for u in (record-updates-of rec :invoice-fulfill)
        for a = (ignore-errors (op:update-op u))
        when (and a (equalp (op:field a :payment-id) payment-id))
          return (op:field a :preimage)))

(defun handle-pay-invoice (node rec event params)
  (unless (node-ln node) (fail "no lightning node"))
  (let* ((deposit-id (deposit-id-param params))
         (bolt11 (w:jget params "invoice"))
         (hash (or (and (w:jget params "payment_hash") (hex->bytes (w:jget params "payment_hash"))) (ln:invoice-payment-hash bolt11)))
         (amount (w:jget params "amount_msats"))
         (fee (or (w:jget params "fee_msats") 0))
         (o (if (w:jget params "operation")
                (op:decode-operation (base64-decode (w:jget params "operation")))
                (list :type :invoice-lock :deposit-id deposit-id :amount amount :payment-id hash
                      :sequence-number (1+ (lg:ledger-sequence (record-ledger rec)))
                      :nonce (w:jget params "nonce") :expiry (w:jget params "expiry") :fee fee
                      :witness (witness-from-json (w:jget params "witness")))))
         (d (lg:find-deposit (record-ledger rec) (op:field o :deposit-id)))
         (asked (ln:invoice-amount-msat bolt11)))
    (unless (equalp (ln:invoice-payment-hash bolt11) (op:field o :payment-id)) (fail "payment_hash does not match the invoice"))
    ;; The lock is what the depositor authorised.  An invoice for any other
    ;; amount is refused here, before anything is locked or sent.
    (when (and asked (/= asked (op:field o :amount)))
      (fail (format nil "the invoice is for ~d msat but the lock is for ~d" asked (op:field o :amount))))
    (unless (authorized-p node rec o d (op:field o :witness)) (fail "witness does not authorize this lock"))
    (when (check-nonce node rec o)
      ;; Already locked: answer as the original does now, and never pay twice.
      (let* ((pid (op:field o :payment-id)) (preimage (invoice-fulfill-preimage rec pid)))
        (return-from handle-pay-invoice
          (cond (preimage
                 (respond node event t :result (w:json-object "payment_id" (bytes->hex pid)
                                                              "deposit_id" (bytes->hex (op:field o :deposit-id))
                                                              "amount_msat" (op:field o :amount) "preimage" (bytes->hex preimage)
                                                              "status" "succeeded")))
                ((gethash pid (lg:ledger-open-invoice-locks (record-ledger rec)))
                 (respond node event nil :error "payment pending; the lock stays until it settles or fails"))
                (t (respond node event nil :error "payment failed; lock released"))))))
    (append-operation node rec o)
    (let ((pid (op:field o :payment-id)) (outcome :pending) (preimage nil))
      (setf (gethash pid (node-ln-polling node)) t)
      (unwind-protect
           (progn
             (handler-case
                 (progn (ln:ln-pay (node-ln node) bolt11 :amount-msat (op:field o :amount) :height (height node))
                        (loop repeat *pay-poll-rounds*
                              do (multiple-value-bind (st pre) (ln:ln-payment-status (node-ln node) pid)
                                   (case st
                                     (:succeeded (setf outcome :succeeded preimage pre) (return))
                                     (:failed (setf outcome :failed) (return))
                                     (t (own:pause-for 0.5))))))
               ;; Declined before any HTLC went out: nothing was sent, so the lock
               ;; can be released.
               (ln:ln-refused (e) (log! node "pay refused: ~a" e) (setf outcome :failed))
               ;; Anything else (a dropped socket, a status we could not read) says
               ;; nothing about whether the payment is in flight: keep the lock.
               (error (e) (log! node "pay ~a: ~a — the lock stays until it resolves" (subseq (bytes->hex pid) 0 8) e)))
             (let ((settled (settle-invoice-lock node rec pid outcome preimage)))
               (cond
                 ((and settled (eq (op:operation-type settled) :invoice-fulfill))
                  (respond node event t :result (w:json-object "payment_id" (bytes->hex pid)
                                                               "deposit_id" (bytes->hex (op:field o :deposit-id))
                                                               "amount_msat" (op:field o :amount) "preimage" (bytes->hex preimage)
                                                               "status" "succeeded")))
                 (settled (respond node event nil :error "payment failed; lock released"))
                 (t (respond node event nil :error "payment pending; the lock stays until it settles or fails")))))
        (remhash pid (node-ln-polling node))))))

(defun settle-pending-payments (node)
  "Every open InvoiceLock on a ledger we operate whose payment is not being polled
   by its handler: ask the Lightning node, and settle the ones it can vouch for.
   The ledger's open locks are the persisted list, so this resumes after a restart.
   Returns the payment ids settled."
  (let ((settled '()))
    (when (node-ln node)
      (loop for rec being the hash-values of (node-ledgers node)
            when (and (record-owned-p rec) (not (record-fork-p rec)))
              do (loop for pid in (loop for k being the hash-keys of (lg:ledger-open-invoice-locks (record-ledger rec)) collect k)
                       unless (gethash pid (node-ln-polling node))
                         do (handler-case
                                (multiple-value-bind (st pre) (ln:ln-payment-status (node-ln node) pid)
                                  (when (settle-invoice-lock node rec pid st pre) (push pid settled)))
                              (error (e) (log! node "settle ~a: ~a" (subseq (bytes->hex pid) 0 8) e))))))
    settled))

;;; ---------------------------------------------------------------------------
;;; Lightning: make_invoice (operator), cosign_invoice (member), crediting

(defun tip-content-hash (rec)
  (if (tip rec) (up:content-hash (tip rec)) (make-array 32 :element-type '(unsigned-byte 8))))

(defun deposit-id-param (params)
  "Wallets name a deposit by id or by descriptor (the reference wallet sends the descriptor)."
  (cond ((w:jget params "deposit_id") (hex->bytes (w:jget params "deposit_id")))
        ((w:jget params "descriptor") (op:deposit-id (w:jget params "descriptor")))
        (t (fail "deposit_id or descriptor required"))))

(defun handle-make-invoice (node rec event params)
  (unless (node-ln node) (fail "no lightning node"))
  (let* ((amount (or (w:jget params "amount_msats") (let ((s (w:jget params "amount_sats"))) (and s (* 1000 s)))
                     (fail "amount_msats required")))
         (deposit-id (deposit-id-param params))
         (ledger (record-ledger rec)))
    (lg:find-deposit ledger deposit-id)
    (unless (<= (+ (lg:total-obligations ledger) amount) (lg:ledger-reserves-amount ledger))
      (fail "invoice would exceed reserves"))
    (multiple-value-bind (bolt11 hash) (ln:ln-make-invoice (node-ln node) amount (w:jget params "description"))
      (setf (gethash hash (node-invoices node)) (list :rec rec :deposit-id deposit-id :amount amount :bolt11 bolt11))
      (let* ((operator-hash (tip-content-hash rec))
             (operator-sig (schnorr:schnorr-sign (node-priv node)
                                                 (ln:invoice-cosign-message (record-id-hex rec) hash deposit-id amount operator-hash)
                                                 (random-aux)))
             (result (w:json-object "invoice" bolt11 "amount_msat" amount "amount_sats" (floor amount 1000)
                                    "deposit_id" (bytes->hex deposit-id) "payment_hash" (bytes->hex hash)
                                    "operator_pubkey" (node-pubkey-hex node)
                                    "operator_ledger_hash" (bytes->hex operator-hash)
                                    "operator_signature" (bytes->hex operator-sig))))
        (when (eq (lg:ledger-quorum-state ledger) :active)
          (let* ((members (lg:ledger-quorum-members ledger))
                 (responses (send-request node (record-id-hex rec) "cosign_invoice"
                                          (w:json-object "payment_hash" (bytes->hex hash) "deposit_id" (bytes->hex deposit-id)
                                                         "amount_msat" amount "invoice" bolt11)))
                 (good (find-if (lambda (r)
                                  (let ((res (w:jget r "result")))
                                    (and (w:jget r "success") res
                                         (let ((pk (hex->bytes (w:jget res "cosigner_pubkey"))))
                                           (and (member pk members :key #'lg:member-pubkey :test #'equalp)
                                                (schnorr:schnorr-verify
                                                 (up:x-only pk)
                                                 (ln:invoice-cosign-message (record-id-hex rec) hash deposit-id amount
                                                                            (hex->bytes (w:jget res "cosigner_ledger_hash")))
                                                 (hex->bytes (w:jget res "cosign_signature"))))))))
                                responses)))
            (unless good (fail "no quorum member cosigned the invoice"))
            (let ((res (w:jget good "result")))
              (setf (gethash "cosign_required" result) t
                    (gethash "cosigner_pubkey" result) (w:jget res "cosigner_pubkey")
                    (gethash "cosigner_ledger_hash" result) (w:jget res "cosigner_ledger_hash")
                    (gethash "cosign_signature" result) (w:jget res "cosign_signature")))))
        (respond node event t :result result)))))

(defun handle-cosign-invoice (node event params)
  (let ((rec (find-record node (w:event-ledger-id event))))
    (when (and rec (not (record-owned-p rec)))
      (handler-case
          (let* ((hash (hex->bytes (w:jget params "payment_hash")))
                 (deposit-id (hex->bytes (w:jget params "deposit_id")))
                 (amount (w:jget params "amount_msat"))
                 (ledger (record-ledger rec)))
            (lg:find-deposit ledger deposit-id)
            (unless (<= (+ (lg:total-obligations ledger) amount) (lg:ledger-reserves-amount ledger))
              (fail "invoice would exceed reserves"))
            (let* ((mlh (member-ledger-hash node))
                   (sig (schnorr:schnorr-sign (node-priv node)
                                              (ln:invoice-cosign-message (record-id-hex rec) hash deposit-id amount mlh)
                                              (random-aux))))
              (respond node event t :result (w:json-object "cosign_signature" (bytes->hex sig)
                                                           "cosigner_pubkey" (node-pubkey-hex node)
                                                           "cosigner_ledger_hash" (bytes->hex mlh)))))
        (error (e) (respond node event nil :error (princ-to-string e)))))))

(defun credit-paid-invoices (node)
  "Ask the Lightning node about every outstanding invoice; credit the paid ones.
   Returns the payment hashes credited."
  (let ((credited '()))
    (when (node-ln node)
      (loop for hash being the hash-keys of (node-invoices node) using (hash-value inv)
            when (multiple-value-bind (st received) (ln:ln-invoice-status (node-ln node) hash)
                   ;; Paid means at least the invoiced amount ARRIVED.  A status
                   ;; without a received amount is not enough to credit on.
                   (and (eq st :paid) received (>= received (getf inv :amount))))
              do (handler-case
                     (let ((rec (getf inv :rec)))
                       (append-operation node rec
                                         (list :type :invoice-credit :payment-hash hash :deposit-id (getf inv :deposit-id)
                                               :amount (getf inv :amount)
                                               :invoice-id (format nil "bolt11:~a" (subseq (getf inv :bolt11) 0 (min 32 (length (getf inv :bolt11)))))
                                               :sequence-number (1+ (lg:ledger-sequence (record-ledger rec)))))
                       (push hash credited)
                       (remhash hash (node-invoices node)))
                   (error (e) (log! node "credit ~a: ~a" (subseq (bytes->hex hash) 0 8) e)))))
    credited))

(defun fail-expired-transfers (node &key (per-ledger 20))
  "DEP-11 §Transfer Timeout: on every ledger we operate, append TransferFail
   for each pending transfer whose timeout_height has passed.  Never done
   before this: after two days of a soak nearly every sat on our ledgers sat
   locked behind a completion that had timed out, and every update we signed
   past those heights was provable non-conformance.  Bounded per pass so a
   backlog does not monopolise the ledger's append lock."
  (let ((h (height node)) (n 0))
    (when (plusp h)
      (loop for rec being the hash-values of (node-ledgers node)
            when (and (record-owned-p rec) (not (record-fork-p rec)))
              do (let ((expired '()))
                   (maphash (lambda (tid p) (let ((th (getf p :timeout-height)))
                                              (when (and (integerp th) (>= h th)) (push tid expired))))
                            (lg:ledger-pending-transfers (record-ledger rec)))
                   (dolist (tid (subseq expired 0 (min per-ledger (length expired))))
                     (handler-case
                         (progn (append-operation node rec (list :type :transfer-fail :transfer-id tid
                                                                 :block-hash (or (and (node-block-hash-fn node) (funcall (node-block-hash-fn node) h))
                                                                                 (make-array 32 :element-type '(unsigned-byte 8)))
                                                                 :reason 1))
                                (incf n))
                       (error (e) (log! node "transfer-fail on ~a: ~a" (subseq (record-id-hex rec) 0 8) e) (return)))))))
    (when (plusp n) (log! node "failed ~a expired transfer~:p at height ~a" n h))
    n))

(defun start-transfer-timeout-poller (node &key (interval 30))
  "FAIL-EXPIRED-TRANSFERS every INTERVAL s, a timer on the owner thread (OWN:CANCEL-TIMER stops it)."
  (own:every-seconds interval (lambda () (ignore-errors (fail-expired-transfers node))) :name "cld-timeouts"))

;;; DEP-19 / DEP-11: a quorum member disputes an operator who let the quorum
;;; lapse.  CHECK-EXPIRED-QUORUMS was only reachable from the control socket,
;;; so no cl member ever noticed an expired quorum by itself: on the soak a
;;; reference-operated ledger sat hours past quorum_expiry, still appending,
;;; with no dispute from either implementation (docs/REDTEAM.md claim #4).
(defparameter *expiry-grace-blocks* 3
  "Blocks past quorum_expiry before a member disputes: room for a QuorumBegin
   still propagating, so a rotation that just made it is not mistaken for a lapse.")

(defun relay-tip-seq (node id-hex operator33)
  "The highest sequence among the newest updates the relays hold for ID-HEX from
   its OPERATOR33 (members' forks share the ledger's tag), or NIL."
  (loop for e in (bus:bus-fetch (node-bus node)
                                (flt:make-filter :kinds (list w:+kind-update+) :limit 20
                                                 :tags (list (cons "d" (list (subseq id-hex 0 16))))))
        for u = (ignore-errors (w:event->update e))
        when (and u (string= (bytes->hex (up:update-ledger-id u)) id-hex) (equalp (up:update-operator-id u) operator33))
          maximize (up:update-seq u)))

(defun dispute-expired-quorums (node &key (grace *expiry-grace-blocks*))
  "Dispute every quorum we sit on that is past expiry — judged only on a replica
   that is current.  One that missed its QuorumBegin shows the old expiry and
   would accuse an operator who rotated: on the soak cld1, just restarted, held
   ledger D at 127572 of 138728, a rotation at 128928 never reached, and
   disputed it.  A replica behind the relay is left alone (the replica lane
   catches it up; catching up here raced that lane).  Returns the ids disputed."
  ;; ADVERSARY :ignore-fraud — a derelict member also lets an expired quorum lie.
  (when (getf (node-adversary node) :ignore-fraud) (return-from dispute-expired-quorums nil))
  (let ((h (height node)))
    (when (plusp h)
      (let* ((stale (loop for rec being the hash-values of (node-ledgers node)
                          when (expired-quorum-p node rec h grace)
                            when (let ((tip (ignore-errors (relay-tip-seq node (record-id-hex rec) (lg:ledger-operator-key (record-ledger rec))))))
                                   (and tip (> tip (lg:ledger-sequence (record-ledger rec)))))
                              collect (record-id-hex rec)))
             (disputed (check-expired-quorums node :grace grace :skip stale
                                                   :anchor-block-hash (and (node-block-hash-fn node) (funcall (node-block-hash-fn node) h)))))
        (dolist (id stale) (note-dispute node id "quorum looks expired but our replica is behind the relay: not judging"))
        (dolist (id disputed) (log! node "quorum expired on ~a at height ~a: disputed" (subseq id 0 8) h))
        disputed))))

;;; The member's side of a dispute, driven to the end (DEP-06): arm with pledged
;;; collateral, propose the confiscation once the arm window closes, reveal once
;;; it is on chain, claim or yield once every reveal is in.  Until now each step
;;; was a control-socket command, so a cl member's dispute stopped at DisputeEnter.

(defparameter *default-dispute-arm-blocks* 6
  "The arm window when no member's QuorumAddMember terms name one.  The
   reference neither sets nor enforces dispute_arm_blocks; this is our policy.")
(defparameter *proposer-grace-blocks* 3
  "Blocks the lowest-keyed armer has to propose before the others do too.")

(defun fork-op (fork type)
  "FORK's most recent update of operation TYPE its own operator signed, and its decoded operation.
   (A dispute of a ledger after a custody change forks the winner's chain, whose DisputeEnter and
   DisputeAcquire are the winner's, not this fork's.)"
  (let ((u (find-if (lambda (u) (equalp (up:update-operator-id u) (record-fork-operator fork)))
                    (if (record-fork-base fork)
                        (gethash type (record-index fork))      ; its own updates: after the fork point
                        (record-updates-of fork type)))))
    (and u (values u (op:update-op u)))))

(defun dispute-arm-closes (node base)
  "The block the arm window closes: the earliest DisputeEnter on any fork of
   BASE's ledger plus the members' dispute_arm_blocks (the longest named)."
  (let ((entered (loop for f in (forks-of node (record-id-hex base))
                       ;; the counted one: a repeat entry above C does not move the window
                       for (u o) = (multiple-value-list (dispute-enter-of node (record-id-hex base) f))
                       when u minimize (or (op:field o :anchor-block-height) (up:update-block-height u))))
        ;; No member names one (the reference never sets dispute_arm_blocks): ours.
        (window (let ((named (loop for m in (lg:ledger-quorum-members (record-ledger base))
                                   for b = (lg::member-dispute-arm-blocks m) when (and b (plusp b)) collect b)))
                  (if named (reduce #'max named) *default-dispute-arm-blocks*))))
    (and entered (+ entered window))))

(defun rebuild-confiscation-on-chain (node id-hex)
  "Rebuild ID-HEX's confiscation from public state as the one whose lottery
   output is in the UTXO set: (tx lottery prevouts reserves tier), or NIL.  Its
   txid depends on the tier (nLockTime) and on whether it was respectful (the
   operator's change output), so both are tried; a rebuild with the defaults
   (non-respectful) never matched a respectful confiscation after a restart."
  ;; DEP-03: arms above the confiscation's block do not count.  That block is learned when the
  ;; confiscation is found, so a restarted node rebuilt with every later arm in the cut and missed
  ;; (751e6951).  The txid of a confiscation we saw confirm is kept (known-confiscations): take
  ;; the block from it first.
  (when (node-chain-fn node)
    (dolist (txid (gethash id-hex (node-known-confiscations node)))
      (note-confiscation-height node id-hex (funcall (node-chain-fn node) txid 0))))
  (when (and (node-chain-fn node)
             ;; No confiscation can exist while the vault is unspent: one gettxout instead of
             ;; rebuilding every shape x tier x armer subset, each with its obligations (a
             ;; chain walk apiece), on every drive-disputes pass of a fresh dispute.
             (multiple-value-bind (r txid vout) (disputed-reserves node (find-record node id-hex))
               (declare (ignore r))
               (not (funcall (node-chain-fn node) txid vout))))
    (flet ((try (armers)
             (loop for respectful in '(t nil)
                   thereis (loop for ti below (length (rs:reserves-tiers (disputed-reserves node (find-record node id-hex))))
                                 for built = (ignore-errors (multiple-value-list (build-confiscation node id-hex :tier-index ti :respectful respectful :armers armers)))
                                 ;; DEP-03 §Confiscation ladder: the rung whose output 0 is on chain
                                 for rung = (and built (find-if (lambda (r) (funcall (node-chain-fn node) (btx:tx-txid r) 0)) (sixth built)))
                                 when rung
                                   return (cons rung (rest built))))))
      ;; The eligibility cut first; then every other set of two or more armers, so
      ;; a confiscation built on a different view of the cut (or by an older node,
      ;; over every armer) is still recognised.
      (or (try nil)
          (let ((all (sort (copy-list (armers-of node id-hex)) #'bytes< :key #'first)))
            (when (<= (length all) 8)
              (loop for mask from (1- (ash 1 (length all))) downto 3
                    for subset = (loop for a in all for i from 0 when (logbitp i mask) collect a)
                    thereis (and (>= (length subset) 2) (try subset)))))))))

(defun lottery-output-spent-p (node id-hex)
  "Literal: a confiscation of ID-HEX we know confirmed (known-confiscations) has its lottery
   output (output 0) spent."
  (and (node-chain-fn node)
       (loop for txid in (gethash id-hex (node-known-confiscations node))
             thereis (null (funcall (node-chain-fn node) txid 0)))))

(defun confiscation-on-chain (node id-hex)
  "The confiscation of ID-HEX whose lottery output is in the UTXO set (we
   proposed or signed it, or it rebuilds from public state), or NIL.  Reserves
   that are merely spent prove nothing: a stranded rotation spends them too."
  (when (node-chain-fn node)
    (let ((known (loop for f in (forks-of node id-hex) thereis (record-confiscation f))))
      (or (and known (funcall (node-chain-fn node) (btx:tx-txid known) 0) known)
          (first (rebuild-confiscation-on-chain node id-hex))))))

;;; DEP-06 Phase 4: the full-set leaf when everyone revealed; otherwise, past the
;;; reveal deadline, the leaf of the revealers R, which the recovery voters attest.
;;; Nobody revealing sends the output to a re-arm round (not yet orchestrated), and
;;; no voter signs a recovery spend to the accused operator.

(defconstant +max-arms+ 4 "Arms that count per armer: the first and up to three re-arms (DEP-03).")

(defvar *rebuild-misses* (make-hash-table :test #'equalp)
  "(node pubkey . ledger id) -> the REBUILD-MISS-STAMP at which rebuilding its spent vault's
   confiscation found nothing.")
(defvar *rebuild-misses-lock* (bt:make-lock "rebuild-misses"))

(defun rebuild-miss-stamp (node id-hex)
  "What a confiscation rebuild of ID-HEX is built from, beyond the chain: its arms (the highest
   arm sequence on any fork) and the arm manifests published for it.  A recorded miss is reused
   only while this is unchanged."
  (list (loop for a in (%all-arms node id-hex) maximize (or (sixth a) 0))
        (length (gethash id-hex (node-arm-manifests node)))))

(defun note-confiscation-height (node id-hex info)
  "INFO is the chain-fn's view of a confiscation's lottery output: once confirmed, remember
   the block it confirmed in (DEP-03: arms above it do not count).  Returns INFO."
  (let ((c (getf info :confirmations)))
    (when (and c (plusp c) (not (gethash id-hex (node-confiscation-heights node))))
      (setf (gethash id-hex (node-confiscation-heights node)) (1+ (- (height node) c)))))
  info)

(defun confiscation-height (node id-hex)
  "The block ID-HEX's confiscation confirmed in (DEP-03 \"When the set is final\"), or NIL.  Noted
   when the confiscation is found; after a restart that table is empty while the confiscation's
   txid is still known (confiscations.txt), so C is derived from the chain before anything is
   judged by it: the lottery output's confirmations while it is unspent, else the txid's own.
   Without this a restarted node's first passes counted a DisputeEnter signed above C (its fork
   point, its grounds, its later rounds) until something rebuilt the confiscation.  The chain is
   asked at most once a block while it has no answer."
  (or (gethash id-hex (node-confiscation-heights node))
      (let ((known (gethash id-hex (node-known-confiscations node))) (h (height node)))
        (when (and known (or (node-chain-fn node) (node-tx-confs-fn node))
                   (not (eql (gethash id-hex (node-confiscation-height-probes node)) h)))
          (setf (gethash id-hex (node-confiscation-height-probes node)) h)
          (dolist (txid known)
            (when (node-chain-fn node)
              (note-confiscation-height node id-hex (ignore-errors (funcall (node-chain-fn node) txid 0))))
            (when (and (node-tx-confs-fn node) (not (gethash id-hex (node-confiscation-heights node))))
              (note-confiscation-height node id-hex (list :confirmations (ignore-errors (funcall (node-tx-confs-fn node) txid))))))
          (gethash id-hex (node-confiscation-heights node))))))

(defun confiscated-lottery (node id-hex)
  "The confiscation of ID-HEX that is on chain: one we signed, or rebuilt from
   public state.  (values tx lottery :pending) while its lottery output is unspent."
  (when (node-chain-fn node)
    (loop for (tx . l) in (gethash id-hex (node-signed-confiscations node))
          when (note-confiscation-height node id-hex (funcall (node-chain-fn node) (btx:tx-txid tx) 0))
            do (return-from confiscated-lottery (values tx l :pending)))
    ;; A proposal we saw but did not sign: its lottery output names its participant set, so
    ;; recover the set from it (DEP-03: final once a confiscation confirms).
    (loop for tx in (gethash id-hex (node-seen-confiscations node))
          when (note-confiscation-height node id-hex (funcall (node-chain-fn node) (btx:tx-txid tx) 0))
            do (let ((l (lottery-paid-by node id-hex (btx:txout-script (first (btx:tx-outputs tx))))))
                 (when l (return-from confiscated-lottery (values tx l :pending)))))
    ;; We hold this ledger's confiscation and its lottery output is gone (claimed): nothing
    ;; pending, and rebuilding every shape x tier x subset would only rediscover that, at a
    ;; chain walk per obligation, on every pass.
    (unless (or (gethash id-hex (node-signed-confiscations node))
                (gethash id-hex (node-seen-confiscations node))
                (equal (rebuild-miss-stamp node id-hex)
                       (bt:with-lock-held (*rebuild-misses-lock*) (gethash (cons (node-pubkey node) id-hex) *rebuild-misses*))))
      (let ((built (rebuild-confiscation-on-chain node id-hex)))
        (if built
            (values (first built) (second built) :pending)
            ;; Spent vault, no pending lottery it rebuilds to (claimed, or not a confiscation):
            ;; nothing can spend that vault again, so the shape x tier x subset search (4-13 s on
            ;; regtest cld364) is not repeated until the arms it is built from change: a new arm
            ;; or arm manifest can make a confiscation rebuildable that was not (REBUILD-MISS-STAMP).
            (when (multiple-value-bind (r txid vout) (disputed-reserves node (find-record node id-hex))
                    (declare (ignore r))
                    (not (funcall (node-chain-fn node) txid vout)))
              (bt:with-lock-held (*rebuild-misses-lock*)
                (setf (gethash (cons (node-pubkey node) id-hex) *rebuild-misses*) (rebuild-miss-stamp node id-hex)))
              nil))))))

(defun lottery-paid-by (node id-hex spk)
  "The lottery over a subset of ID-HEX's armers whose output script is SPK (our cut
   first, then every subset, largest first), or NIL."
  (let* ((network (intern (string-upcase (node-network node)) :keyword)))
    (multiple-value-bind (voters threshold) (lottery-voters node id-hex)
    (flet ((try (armers)
             (let ((ps (loop for (pk c target) in armers collect (lot:make-participant :pubkey (up:x-only pk) :commitment c :target target))))
               (when ps
                 (let ((l (ignore-errors (lot:build-lottery ps voters threshold :network network))))
                   (and l (equalp (lot:lottery-spk l) spk) l))))))
      ;; DEP-06 §Arm manifests: the arm sets the confiscation's signers published first; then our
      ;; cut, then every subset of the latest arms (a judge without a manifest).
      (or (let ((c (confiscation-height node id-hex)) (all (%all-arms node id-hex)))
            (loop for m in (arm-manifests-of node id-hex 1)
                  thereis (let ((named (manifest-arms all m 1 -1 (or c most-positive-fixnum)))) (and named (try named)))))
          (try (ignore-errors (lottery-armers node id-hex)))
          (let ((all (sort (copy-list (armers-of node id-hex)) #'bytes< :key #'first)))
            (when (<= (length all) 8)
              (loop for mask from (1- (ash 1 (length all))) downto 1
                    thereis (try (loop for a in all for i from 0 when (logbitp i mask) collect a))))))))))

(defun reveal-deadline-passed-p (node conf)
  (let ((info (and (node-chain-fn node) (funcall (node-chain-fn node) (btx:tx-txid conf) 0))))
    (and info (>= (getf info :confirmations) lot:+reveal-csv+))))

(defun revealed-indices (node id-hex lottery)
  "(values indices preimages): the participants whose valid reveals we hold, in
   canonical order."
  (let ((reveals (reveals-of node id-hex)) (idx '()) (pre '()))
    (loop for p in (lot:lottery-participants lottery) for i from 0
          for r = (cdr (find-if (lambda (r) (and (equalp (up:x-only (car r)) (lot:participant-pubkey p))
                                                  (equalp (lot:commitment-of (cdr r)) (lot:participant-commitment p))))
                                reveals))
          when (and r (<= 17 (length r) lot:+max-preimage-len+))
            do (push i idx) (push r pre))
    (values (nreverse idx) (nreverse pre))))

(defun handle-lottery-subset-attest (node event params)
  "A recovery voter (DEP-06 Phase 4): sign a revealer-subset claim only past the
   reveal deadline, only for exactly the reveals we hold, only for that subset's
   winner, and only a claim paying the winner's declared target."
  (let ((id (w:event-ledger-id event)))
    (unless (find-record node id) (return-from handle-lottery-subset-attest nil))
    (handler-case
        (multiple-value-bind (conf lottery) (current-lottery node id)   ; a re-arm round's, else round 1's
          (unless (and conf lottery) (fail "no pending lottery on chain"))
          (unless (member (up:x-only (node-pubkey node)) (lot:lottery-recovery-voters lottery) :test #'equalp)
            (fail "not a recovery voter"))
          (unless (reveal-deadline-passed-p node conf) (fail "reveal deadline not reached (~a blocks)" lot:+reveal-csv+))
          (multiple-value-bind (idx pre) (revealed-indices node id lottery)
            (let* ((asked (mapcar (lambda (h) (let ((x (let ((k (hex->bytes h))) (if (= (length k) 33) (up:x-only k) k))))
                                                (or (position x (lot:lottery-participants lottery) :key #'lot:participant-pubkey :test #'equalp)
                                                    (fail "~a is not a participant" (subseq h 0 8)))))
                                  (coerce (w:jget params "subset") 'list)))
                   (asked (sort (copy-list asked) #'<)))
              (unless (equal asked idx) (fail "subset ~a is not the reveals we hold ~a" asked idx))
              (when (= (length idx) (length (lot:lottery-participants lottery))) (fail "everyone revealed: the full-set leaf needs no attestation"))
              (let ((winner (nth (lot:subset-winner idx pre) (lot:lottery-participants lottery))))
                (let* ((proposed (btx:parse-tx (bw:make-reader (hex->bytes (w:jget params "unsigned_tx")))))
                       (in0 (first (btx:tx-inputs proposed)))
                       (target (lot:participant-target winner))
                       (spk (multiple-value-bind (witver program)
                                (cl-consensus.encoding:segwit-decode target (rs:hrp-for (intern (string-upcase (node-network node)) :keyword)))
                              (cat (octets (if (zerop witver) 0 (+ #x50 witver)) (length program)) program))))
                  (unless (and (equalp (btx:txin-prev-hash in0) (btx:tx-txid conf)) (= (btx:txin-prev-index in0) 0))
                    (fail "the claim does not spend the lottery output"))
                  (unless (and (= 1 (length (btx:tx-outputs proposed))) (equalp (btx:txout-script (first (btx:tx-outputs proposed))) spk))
                    (fail "the claim does not pay the winner's target"))
                  (let* ((leaf (nth (lot:subset-leaf-index lottery idx) (lot:lottery-leaves lottery)))
                         (amounts (coerce (w:jget params "prevout_amounts") 'list)) (spks (coerce (w:jget params "prevout_spks") 'list))
                         (prevouts (coerce (loop for a in amounts for k in spks collect (cons a (hex->bytes k))) 'vector)))
                    (unless (and prevouts (equalp (cdr (aref prevouts 0)) (lot:lottery-spk lottery)))
                      (fail "prevout 0 is not the lottery output"))
                    (let ((sighash (rot:tier-sighash proposed 0 prevouts leaf)))
                      (unless (equalp sighash (hex->bytes (w:jget params "sighash"))) (fail "sighash mismatch"))
                      (log! node "attested lottery subset ~a of ~a for ~a" idx (subseq id 0 8)
                            (subseq (bytes->hex (lot:participant-pubkey winner)) 0 8))
                      (respond node event t :result (w:json-object "signer" (node-pubkey-hex node)
                                                                   "signature" (bytes->hex (schnorr:schnorr-sign (node-priv node) sighash (random-aux))))))))))))
      (error (e) (log! node "refused lottery_subset_attest: ~a" e) (respond node event nil :error (princ-to-string e))))))

(defun note-dispute (node id-hex fmt &rest args)
  "Log a dispute's state only when it changes: a stuck dispute is retried every
   pass and would otherwise fill the log."
  (let ((line (apply #'format nil fmt args)))
    (unless (equal line (gethash id-hex (node-dispute-notes node)))
      (setf (gethash id-hex (node-dispute-notes node)) line)
      (log! node "dispute ~a: ~a" (subseq id-hex 0 8) line))))

(defun expiry-reason-p (reason)
  "A DisputeEnter for a lapsed quorum, in either spelling we ever wrote."
  (and (stringp reason) (string= (substitute #\_ #\- reason) "quorum_expired")))

(defparameter *punitive-dispute-reasons*
  '("uncredited_onchain_payment" "uncredited_lightning_payment" "stale_cosignature" "dispute_dereliction"
    "non_conforming_update" "winner_collateral_deviation" "equivocation" "non_conforming_cosignature"
    "unauthorized_vault_spend" "unhonoured_obligation")
  "DisputeEnter reasons that name a freezing ground: the DEP-06 proof types, snake_case.")

(defun dispute-ground-expiry-p (reason has-anchor cites-proof enter-height governing-expiry)
  "DEP-05 \"The ground of a dispute\": whether a DisputeEnter is a quorum_expired dispute.  Its
   reason decides when it names a ground; a generic one (auto_dispute, fraud: records written
   before reasons named grounds) is read from the record: an expiry anchor, or no fraud proof
   cited and entered past the quorum_expiry governing at its fork point.  Vector
   inspect/vectors/dispute_ground.json, shared with deposits-rust."
  (let ((r (and (stringp reason) (substitute #\_ #\- reason))))
    (cond ((equal r "quorum_expired") t)
          ((member r *punitive-dispute-reasons* :test #'equal) nil)
          (t (or (and has-anchor t)
                 (and (not cites-proof) governing-expiry (> enter-height governing-expiry) t))))))

(defun dispute-enter-expiry-p (update op governing-expiry)
  "The DisputeEnter UPDATE (decoded OP) judged by its ground, GOVERNING-EXPIRY the base's."
  (dispute-ground-expiry-p (op:field op :reason) (op:field op :anchor-block-height) (op:field op :fraud-proof-hash)
                           (up:update-block-height update) governing-expiry))

(defparameter +reveal-depth+ 3
  "Confirmations a confiscation needs before a participant reveals (DEP-06 Phase 3), as deposits-rust.")

(defun confiscation-depth (node tx)
  "Confirmations of TX's output 0 (0 while unconfirmed, or with no chain source)."
  (let ((info (and (node-chain-fn node) (ignore-errors (funcall (node-chain-fn node) (btx:tx-txid tx) 0)))))
    (or (and info (getf info :confirmations)) 0)))

(defun fork-lottery (node id-hex)
  "(values confiscation lottery :pending) for ID-HEX while its lottery output is
   unspent, or NIL.  Found once by rebuilding (CONFISCATED-LOTTERY), then kept on
   our forks so a pass costs a UTXO lookup.  A kept transaction that is not on
   chain is not evidence of anything (a signer keeps every proposal it signs, and
   the one that confirmed may be another proposer's), so it is dropped and the
   chain asked again."
  (flet ((forget () (dolist (f (forks-of node id-hex)) (setf (record-confiscation f) nil (record-lottery f) nil))))
    (let ((f (find-if (lambda (f) (and (record-confiscation f) (record-lottery f))) (forks-of node id-hex))))
      (when f
        (let ((tx (record-confiscation f)) (l (record-lottery f)))
          (cond ((not (node-chain-fn node)) (return-from fork-lottery (values tx l :pending)))
                ((let ((info (funcall (node-chain-fn node) (btx:tx-txid tx) 0)))
                   ;; gettxout counts the mempool: a broadcast rung is :pending (the ladder bumps
                   ;; it), but only a confirmed one is noted and saved as THE confiscation.  A
                   ;; competing proposal over another cut can still confirm in its place (signet
                   ;; soak, 2026-11-08: B, C, H and L each logged an "on chain" confiscation that
                   ;; never confirmed).
                   (when info
                     (when (>= (or (getf info :confirmations) 0) 1)
                       (note-confiscation node id-hex (btx:tx-txid tx))
                       (save-confirmed-lottery node id-hex tx l))
                     t))
                 (return-from fork-lottery (values tx l :pending)))
                (t (forget)))))
      (multiple-value-bind (tx l state) (confiscated-lottery node id-hex)
        (when tx
          (when (and state (>= (confiscation-depth node tx) 1))   ; confirmed, not merely broadcast
            (note-confiscation node id-hex (btx:tx-txid tx)) (save-confirmed-lottery node id-hex tx l))
          (dolist (f (forks-of node id-hex)) (setf (record-confiscation f) tx (record-lottery f) l)))
        (values tx l state)))))

(defun expiry-dispute-ended-p (last-valid-seq latest-quorum-begin-seq confiscation-confirmed
                              &key on-spend (rotation-confirmed t))
  "DEP-05 §\"When a quorum_expired dispute ends\": a QuorumBegin after the dispute's fork point
   (re-establishment) ends it, unless its confiscation already confirmed.  ON-SPEND (the
   :expiry-ends-on-spend rule of strict-lottery-v8, judged at the fork point): only once that
   re-establishment's spend of the vault confirmed (REESTABLISHMENT-CONFIRMED-P); recorded but
   unspent, the dispute stands and the race goes on.  Vector: expiry_dispute_ends.json."
  (and (not confiscation-confirmed) (integerp last-valid-seq) (> latest-quorum-begin-seq last-valid-seq)
       (or (not on-spend) rotation-confirmed)))

(defun quorum-begin-spend-confirmed-p (node qu)
  "The vault spend of QuorumBegin update QU is confirmed: some rung of its ladder has a
   confirmation (getrawtransaction, so a rung whose new vault a later rotation spent still counts).
   A QuorumBegin with no rotation rungs funds a fresh vault, checked on chain when cosigned: T.
   Without a way to ask the chain, T (the reading before the rule)."
  (let* ((o (op:decode-operation (up:update-message qu)))
         (rungs (and (op:field o :rotation-rungs) (fr:rotation-rungs o))))
    (or (null rungs) (null (node-tx-confs-fn node))
        (some (lambda (txid) (rung-confirmed-p node txid)) rungs))))

(defvar *confirmed-rungs* (make-hash-table :test #'equalp :synchronized t) "Rung txids seen confirmed (a confirmation is final enough here).")
(defvar *unconfirmed-rungs* (make-hash-table :test #'equalp :synchronized t) "Rung txid -> when last seen unconfirmed: asked again after 60 s.")

(defun rung-confirmed-p (node txid)
  (or (gethash txid *confirmed-rungs*)
      (let ((seen (gethash txid *unconfirmed-rungs*)))
        (unless (and seen (< (- (get-universal-time) seen) 60))
          (let ((c (ignore-errors (funcall (node-tx-confs-fn node) txid))))
            (if (and c (plusp c))
                (progn (remhash txid *unconfirmed-rungs*) (setf (gethash txid *confirmed-rungs*) t))
                (progn (setf (gethash txid *unconfirmed-rungs*) (get-universal-time)) nil)))))))

(defun reestablishing-quorum-begin (node rec last-valid-seq &key (on-spend t))
  "The newest QuorumBegin of REC after LAST-VALID-SEQ (a re-establishment of the quorum after
   the fork point), with its vault spend confirmed when ON-SPEND (strict-lottery-v8): what a
   yield-evidence-v9 stand-down names (its content hash, DEP-06 \"What a yield must say\")."
  (loop for u in (record-updates-of rec :quorum-begin)        ; newest first
        while (> (up:update-seq u) (or last-valid-seq -1))
        when (or (not on-spend) (quorum-begin-spend-confirmed-p node u))
          return u))

(defun reestablishment-confirmed-p (node rec last-valid-seq)
  "Some QuorumBegin of REC after LAST-VALID-SEQ has its vault spend confirmed (strict-lottery-v8,
   :expiry-ends-on-spend)."
  (loop for u in (record-updates-of rec :quorum-begin)        ; newest first
        while (> (up:update-seq u) (or last-valid-seq -1))
          thereis (quorum-begin-spend-confirmed-p node u)))

(defun expiry-dispute-outcome (armed reestablished confiscation-confirmed)
  "DEP-06 §Race, a post-expiry rotation (ruled 2026-11-14): (values yield release-pledge) for our
   quorum_expired dispute.  A re-establishment after its fork point ends it whether or not we
   armed: we yield and our pledge (arm or none) lapses with no lottery, unless the confiscation
   confirmed first, when the chain has decided and the dispute runs on.  ARMED never changes the
   answer; it is in the signature because the reference once yielded only armed disputes.
   Vector: post_expiry_rotation.json."
  (declare (ignore armed))
  (let ((end (and reestablished (not confiscation-confirmed))))
    (values end end)))

(defun member-cosigns-post-expiry-p (height quorum-expiry establishment policy)
  "Whether a member signs an op of class ESTABLISHMENT at HEIGHT: before QUORUM-EXPIRY always (the
   protocol's own checks still apply), past it only an establishment op, and that only by POLICY
   (*COSIGN-POST-EXPIRY-ESTABLISHMENT*).  Vector: post_expiry_rotation.json."
  (cond ((or (null quorum-expiry) (< height quorum-expiry)) t)
        ((not establishment) nil)
        (t (and policy t))))

(defun rung-sign-policy-allows-p (qb-height old-quorum-expiry policy)
  "REVIEW 11: whether a member signs the rungs of a rotation whose QuorumBegin is at QB-HEIGHT,
   judged against the SPENT vault's quorum expiry OLD-QUORUM-EXPIRY (the replica before the
   QuorumBegin), never the new quorum's.  Rungs are establishment: the same opt-out as the
   cosign.  Vector: post_expiry_rotation.json (its rung_sign cases)."
  (member-cosigns-post-expiry-p qb-height old-quorum-expiry t policy))

(defun arm-on-expiry-dispute-p (anchor-height governing-expiry last-valid-seq latest-quorum-begin-seq
                                &key on-spend (rotation-confirmed t))
  "DEP-05: a quorum_expired DisputeEnter is armed on only while its ground stands: its anchor is
   past the expiry of the QuorumBegin governing at its fork point, and no QuorumBegin since has
   re-established the quorum (under ON-SPEND, none whose spend of the vault confirmed)."
  (and (integerp anchor-height) (integerp governing-expiry) (> anchor-height governing-expiry)
       (not (expiry-dispute-ended-p last-valid-seq latest-quorum-begin-seq nil
                                    :on-spend on-spend :rotation-confirmed rotation-confirmed))))

(defvar *drive-threads-lock* (bt:make-lock "drive-threads"))
(defvar *drive-last* (make-hash-table :test #'equalp)
  "(node pubkey . fork id) -> universal time its last drive started (DRIVE-DISPUTE stamps it).")

(defvar *drive-steps* nil
  "Inside a drive: an alist step -> (ms . calls) of its timed steps (DSTEP), NIL outside one.")
(defparameter *drive-log-ms* 1000
  "A dispute drive taking at least this long logs its duration and the steps it spent it in
   (DRIVE-TIMED).  The numbers the throughput work schedules by: a node with ~60 live disputes
   left one undriven 897 s with every slot busy (regtest 1119-111730, cld364).")
(defparameter *watch-log-ms* 120000 "A watch pass at least this long logs its step breakdown.")
(defvar *watch-stats* (make-hash-table :test #'equalp :synchronized t)
  "node pubkey -> plist: :passes, :last-ms / :last-steps (the last whole pass), :max-ms / :max-steps
   (the longest), :totals (step -> (ms . calls)), and :current (step . start-time) while a pass runs.
   regtest 1119-214607: cld364's once-a-minute pass took 7-15 minutes, so its vault watch saw a
   theft 407 s late and a dispute waited a whole pass between drives; nothing said where it went.")

(defvar *drive-stats* (make-hash-table :test #'equalp)
  "(node pubkey . step) -> (total-ms . calls) over the process's life, :drive the whole drive.")
(defvar *drive-stats-lock* (bt:make-lock "drive-stats"))

(defun ms-since (t0)
  (round (* 1000 (- (get-internal-real-time) t0)) internal-time-units-per-second))

(defmacro dstep (name &body body)
  "Time BODY as drive step NAME into *DRIVE-STEPS* (a no-op outside a drive)."
  (let ((t0 (gensym "T0")))
    `(let ((,t0 (get-internal-real-time)))
       (when *drive-current* (setf (cddr *drive-current*) ,name))   ; :drive-stats :inflight shows it
       (unwind-protect (progn ,@body)
         (when *drive-steps*
           (let ((cell (or (assoc ,name (cdr *drive-steps*))
                           (car (push (list* ,name 0 0) (cdr *drive-steps*))))))
             (incf (second cell) (ms-since ,t0))
             (incf (cddr cell))))))))

(defun drive-step-summary (steps)
  "STEPS as \"name ms[xN] ...\", slowest first; steps under 5 ms left out."
  (format nil "~{~a~^ ~}"
          (loop for (name ms . n) in (sort (copy-list steps) #'> :key #'second)
                when (>= ms 5) collect (format nil "~(~a~) ~ams~:[~;x~a~]" name ms (> n 1) n))))

(defvar *drive-current* nil "Inside a drive: this thread's (id start-time . current step), listed in *DRIVE-INFLIGHT-STEPS*.")
(defvar *drive-serial* 0)
(defvar *drive-inflight-steps* (make-hash-table :test #'equalp :synchronized t)
  "(node pubkey . drive serial) -> (task-name fork-id start-universal-time . step): what every running
   drive is doing now.  Keyed by a serial, not the thread: EQUALP hashes a thread by its slots, and
   one that finished hashed elsewhere, so its entry could not be removed.
   regtest 1119-194245: cld364's slots were all busy for 12 minutes and finished no drive, and
   nothing could say where they were.")

(defun drive-inflight (node)
  "Every drive of NODE running now: (fork-id8 seconds step thread-name), longest first."
  (let ((pk (node-pubkey node)) (now (get-universal-time)))
    (sort (loop for k being the hash-keys of *drive-inflight-steps* using (hash-value tv)
                for name = (car tv) for v = (cdr tv)
                when (equalp (car k) pk)
                  collect (list (subseq (first v) 0 8) (- now (second v)) (cddr v) name))
          #'> :key #'second)))

(defparameter *drive-stall-seconds* 120 "A drive in flight this long has its thread's backtrace logged, once.")
(defvar *drive-stall-dumped* (make-hash-table :test #'equalp :synchronized t)
  "*DRIVE-INFLIGHT-STEPS* keys whose backtrace was logged.")

(defun log-stalled-drives (node)
  "Every drive of NODE in flight over *DRIVE-STALL-SECONDS*: log, once per drive, where it is (its
   fork, step, and a backtrace), so a stall names the lock or call it waits on (regtest
   1119-194245: three slots busy 12 minutes, no drive finished).  A drive runs on the owner thread
   and a drive in flight is one suspended in a wait (OWN:WAIT-UNTIL pumps, and this runs inside
   that pump), so the owner's own stack, taken here, holds the stalled drive's frames below ours."
  (let ((pk (node-pubkey node)) (now (get-universal-time)))
    (loop for k being the hash-keys of *drive-inflight-steps* using (hash-value tv)
          for name = (car tv) for v = (cdr tv)
          when (and (equalp (car k) pk) (> (- now (second v)) *drive-stall-seconds*)
                    (not (gethash k *drive-stall-dumped*)))
            do (setf (gethash k *drive-stall-dumped*) t)
               (let ((id (subseq (first v) 0 8)) (secs (- now (second v))) (step (cddr v)))
                 (ignore-errors
                  (log! node "dispute ~a: drive in flight ~a s, in step ~a, on ~a; backtrace: ~{~a~^ | ~}" id secs step name
                        (uiop:split-string (string-trim '(#\Newline)
                                                        (with-output-to-string (s) (let ((*print-length* 10) (*print-level* 4))
                                                                                     (sb-debug:print-backtrace :stream s :count 80))))
                                           :separator '(#\Newline))))))))

(defun drive-timed (node fork thunk)
  "Run THUNK (a drive of FORK) timing it and its DSTEPs; log a slow one with its breakdown and
   the note it left, and add both into *DRIVE-STATS* (the :drive-stats control request)."
  (let* ((*drive-steps* (list :steps)) (t0 (get-internal-real-time)) (id (record-id-hex fork))
         (*drive-current* (list* id (get-universal-time) :start))
         (key (cons (node-pubkey node) (bt:with-lock-held (*drive-stats-lock*) (incf *drive-serial*)))))
    (setf (gethash key *drive-inflight-steps*) (cons (own:task-name) *drive-current*))
    (unwind-protect (funcall thunk)
      (remhash key *drive-inflight-steps*) (remhash key *drive-stall-dumped*)
      (let ((ms (ms-since t0)) (pk (node-pubkey node)))
        (bt:with-lock-held (*drive-stats-lock*)
          (loop for (name sms . n) in (cons (list* :drive ms 1) (cdr *drive-steps*))
                for cell = (or (gethash (cons pk name) *drive-stats*) (setf (gethash (cons pk name) *drive-stats*) (cons 0 0)))
                do (incf (car cell) sms) (incf (cdr cell) n)))
        (when (>= ms *drive-log-ms*)
          (log! node "dispute ~a: drive took ~a ms [~a] -> ~a" (subseq id 0 8) ms
                (drive-step-summary (cdr *drive-steps*)) (gethash id (node-dispute-notes node))))))))

(defun drive-stats (node)
  "This node's drive totals: a list of (step total-ms calls mean-ms), slowest total first."
  (let ((pk (node-pubkey node)))
    (bt:with-lock-held (*drive-stats-lock*)
      (sort (loop for (k . (ms . n)) in (alexandria:hash-table-alist *drive-stats*)
                  when (equalp (car k) pk) collect (list (cdr k) ms n (if (plusp n) (round ms n) 0)))
            #'> :key #'second))))

(defun drive-dispute (node fork)
  "Drive FORK one step (%DRIVE-DISPUTE), timed (DRIVE-TIMED)."
  (drive-timed node fork (lambda () (%drive-dispute node fork))))

(defun lost-to-acquire (node fork our-round)
  "Another participant's binding acquire (OTHERS-BINDING-ACQUIRES: (acquirer round claim-txid))
   of round OUR-ROUND or later whose claim is not ours (its output 0 does not pay our key): what a
   loser's yield names as lost_to (DEP-06 \"What a yield must say\", reason 1), or NIL."
  (let ((mine (lot:key-path-spk (up:x-only (node-pubkey node)))))
    (find-if (lambda (a)
               (and (>= (second a) our-round)
                    (let ((tx (and (node-tx-fn node) (ignore-errors (funcall (node-tx-fn node) (third a))))))
                      (and tx (plusp (length (btx:tx-outputs tx)))
                           (not (equalp (btx:txout-script (elt (btx:tx-outputs tx) 0)) mine))))))
             (others-binding-acquires node fork))))

(defun %drive-dispute (node fork)
  (bt:with-lock-held (*drive-threads-lock*)   ; DRIVE-SCHEDULE: least recently driven first
    (setf (gethash (cons (node-pubkey node) (record-id-hex fork)) *drive-last*) (get-universal-time)))
  (let* ((id (record-id-hex fork)) (base (find-record node id)) (h (height node)))
    (multiple-value-bind (enter enter-op) (fork-op fork :dispute-enter)
      (unless (and base enter)
        (return-from %drive-dispute
          (note-dispute node id "not driven: ~:[no replica of the ledger~;no DisputeEnter of ours on the fork~]" base)))
      (flet ((conclude (reason fmt &rest args)
               (unless (dstep :yield (yield-once node fork :reason reason))
                 (return-from %drive-dispute (note-dispute node id "yield held (YIELD-ONCE)")))
               (release-pledges node id)
               (return-from %drive-dispute (apply #'note-dispute node id fmt args))))
        ;; DEP-03 "When a pledge is live": another participant's binding acquire for our arm's round
        ;; or a later one ended the lottery; yield as its loser, once (YIELD-ONCE adopts a yield of
        ;; ours already published and never signs a second).  Without it a dispute won by someone
        ;; else held our pledge for good (regtest 1121-next4c: 12 of deposits-rust ref6's forks).
        (multiple-value-bind (au ao) (fork-op fork :dispute-armed)
          (declare (ignore au))
          (when (and ao (eq (lg:ledger-dispute-state (record-ledger fork)) :armed))
            (let ((won (lost-to-acquire node fork (or (op:field ao :rearm-round) 1))))
              (when won
                (conclude (list :lost-to (third won)) "lost to ~a's binding acquire (claim ~a, round ~a); yielded"
                          (subseq (bytes->hex (first won)) 0 16) (txid-hex (third won)) (second won))))))
        (when (find-if (lambda (r) (> (getf r :round) 1)) (rearm-rounds node id))
          (return-from %drive-dispute (note-dispute node id "in a re-arm round (DRIVE-REARM)")))
        ;; Our arm is for a LATER round: DRIVE-REARM reveals and claims it against that round's
        ;; output.  The passes below judge ROUND 1's lottery, in which a member that armed only a
        ;; later round is no participant: it revealed its round-2 preimage into round 1, "lost" and
        ;; yielded, Tombstoning its fork for the round it armed in (regtest rearm-rust 2026-11-21:
        ;; deposits-rust ref7 on c8b9b7b1, round-2 arm at seq 26, yield at 27, round 2 then won with
        ;; no acquire possible).  This is noted before round 2's output exists, so REARM-ROUNDS above
        ;; does not see it yet.
        (let ((ao (nth-value 1 (fork-op fork :dispute-armed))))
          (when (and ao (> (or (op:field ao :rearm-round) 1) 1))
            (return-from %drive-dispute
              (note-dispute node id "armed round ~a (DRIVE-REARM)" (op:field ao :rearm-round)))))
        (when (or (fork-op fork :dispute-acquire) (fork-op fork :dispute-yield))
          (when (and (loop for v being the hash-values of (node-pledges node) thereis (equal v id))
                     (not (rearm-rounds node id)))
            (release-pledges node id))
          (return-from %drive-dispute (note-dispute node id "concluded")))
        (multiple-value-bind (conf lottery lstate) (dstep :fork-lottery (fork-lottery node id))
          ;; DEP-05 §"When a quorum_expired dispute ends": a QuorumBegin after the dispute's
          ;; fork point answers its ground, unless its confiscation already confirmed.  Judged
          ;; from the ledger, not the tip: the re-established quorum may itself have expired
          ;; since, and that is a new ground for a new dispute (signet soak, 2026-10-27: members
          ;; kept disputes from before their operators re-established and never opened new
          ;; ones).  A dispute opened on a stale replica, its quorum live now, ends too.
          (let ((expiry (lg:ledger-quorum-expiry (record-ledger base)))
                (confirmed (or (assoc (node-pubkey node) (reveals-of node id) :test #'equalp)
                               (and conf (node-chain-fn node) (dstep :chain-conf (funcall (node-chain-fn node) (btx:tx-txid conf) 0))))))
            ;; strict-lottery-v8 (:expiry-ends-on-spend, judged at the fork point, never by the
            ;; QuorumBegin under judgement): only a re-establishment whose spend of the vault
            ;; confirmed ends it; recorded but unspent, the race goes on (regtest 2026-11-15:
            ;; the reference yielded its armed stake while its own confiscation sat in the
            ;; mempool, and that confiscation then won).
            ;; yield-evidence-v9: the yield names the re-establishing QuorumBegin (DEP-06 "What a
            ;; yield must say", reason 2), so only that answers it: never the tip-based arm below
            ;; (the re-established quorum's expiry ahead of the tip), which names nothing.
            (when (and (dispute-enter-expiry-p enter enter-op expiry) (not confirmed))
              (let* ((lvs (op:field enter-op :last-valid-sequence))
                     (on-spend (lg:ruleset-rule-p (lg:ledger-active-ruleset (record-ledger fork)) :expiry-ends-on-spend))
                     (qb (dstep :reestablished (reestablishing-quorum-begin node base lvs :on-spend on-spend)))
                     (reason (and qb (list :reestablished (up:content-hash qb)))))
                (when (if (fork-yield-evidence-p fork)
                          qb
                          (let ((spent (or (not on-spend) qb)))
                            (or (expiry-dispute-ended-p lvs (latest-quorum-begin-seq base) nil
                                                        :on-spend on-spend :rotation-confirmed spent)
                                (and expiry (<= h (+ expiry *expiry-grace-blocks*)) spent))))
                  (conclude reason "quorum re-established (expiry ~a); yielded" expiry)))))
          (let ((reserves-spent (dstep :reserves-spent
                                (multiple-value-bind (r txid vout) (disputed-reserves node base)
                                  (declare (ignore r))
                                  (and (node-chain-fn node) (null (funcall (node-chain-fn node) txid vout)))))))
            (cond
              ;; Nothing left to confiscate (a stranded rotation spent it): arming
              ;; would only tie up a pledge.
              ((and reserves-spent (null conf) (dstep :lottery-spent (lottery-output-spent-p node id)))
               ;; A confiscation we know confirmed, and its lottery output is spent: claimed (a
               ;; re-arm spend is DRIVE-REARM's, above).  Not being able to rebuild the lottery
               ;; proves nothing (751e6951's fellows concluded on that, and it stranded).
               ;;   Literal means CONFIRMED: gettxout drops an output spent in the mempool, while
               ;; FOLLOW-REARM-SPEND reads blocks.  A voter that had just signed the re-arm spend
               ;; took it for a claim in the pass before it confirmed, yielded, and so never
               ;; revealed round 2 (regtest, 2026-11-10: cld193 on 3151f272).
               (let ((r1 (find 1 (rearm-rounds node id) :key (lambda (r) (getf r :round)))))
                 (cond ((and r1 (dstep :follow-rearm (follow-rearm-spend node id r1)))
                        (note-dispute node id "lottery round 1 spent into round 2's lottery"))
                       ((and r1 (not (lottery-spend-confirmed-p node r1)))
                        (note-dispute node id "lottery output spent in the mempool; judging it once it confirms"))
                       ;; yield-evidence-v9: a spent output names no winner; the yield waits for the
                       ;; winner's binding acquire (lost_to, above), and our pledge stays held until it.
                       ((fork-yield-evidence-p fork)
                        (note-dispute node id "lottery claimed; awaiting the winner's binding acquire to name (yield-evidence-v9)"))
                       (t (conclude nil "lottery claimed by its winner; yielded")))))
              ((and reserves-spent (null conf))
               (note-dispute node id "reserves spent, but not by a confiscation we can rebuild"))
              ;; ADVERSARY :hold-arm — a member that disputes but does not arm (yet): without its
              ;; arm it signs no confiscation (red team: regtest rotation-post-expiry, whose
              ;; rotation-wins arm needs the vault to stay unconfiscated while it re-establishes).
              ((and (null (fork-op fork :dispute-armed)) (getf (node-adversary node) :hold-arm))
               (note-dispute node id "disputed; holding our arm (:hold-arm)"))
              ((null (fork-op fork :dispute-armed))
               (let ((p (dstep :pledge (pledge-collateral node id))))
                 (if p
                     (progn (dstep :arm (arm-dispute node fork :replacement p))
                            (note-dispute node id "armed, pledging ~a:~a (~a sats)" (txid-hex (first p)) (second p) (third p)))
                     (note-dispute node id "waiting for collateral (~a sats)" (required-replacement-sats base)))))
              ;; DEP-03: our pledge stopped passing the eligibility cut (spent, or never
              ;; confirmed), so we would be excluded from the lottery.  Re-arm with a
              ;; fresh one; the latest arm counts and moves E, reopening the window, up
              ;; to +max-arms+ arms in all.
              ((and (null conf) (not (eq lstate :pending)) (not (getf (node-adversary node) :spend-pledge))
                    (< (count (node-pubkey node) (%all-arms node id) :key #'first :test #'equalp) +max-arms+)
                    (let ((ours (find (node-pubkey node) (armers-of node id) :key #'first :test #'equalp)))
                      (and ours (fourth ours)
                           (or (and (dstep :custody-check (pledge-custody-rearm-p node (fourth ours) (not reserves-spent)))
                                    (progn (log! node "our declared pledge ~a on ~a is a lottery claim's output 0 (a ledger's custody); re-arming with a fresh one"
                                                 (outpoint-key (first (fourth ours)) (second (fourth ours))) (subseq id 0 8))
                                           t))
                               (and (node-pledge-fn node)
                                    (dstep :pledge-check (pledge-failure (node-pledge-fn node) (fourth ours) (height node) 0 nil)))))))
               (remhash (outpoint-key (first (fourth (find (node-pubkey node) (armers-of node id) :key #'first :test #'equalp)))
                                      (second (fourth (find (node-pubkey node) (armers-of node id) :key #'first :test #'equalp))))
                        (node-pledges node))
               (let ((p (dstep :pledge (pledge-collateral node id))))
                 (if p
                     (progn (dstep :arm (arm-dispute node fork :replacement p))
                            (note-dispute node id "re-armed: our pledge no longer counted; now pledging ~a:~a" (txid-hex (first p)) (second p)))
                     (note-dispute node id "our pledge no longer counts; waiting for collateral to re-arm"))))
              ((eq lstate :pending)
               ;; DEP-03 §Confiscation ladder: until a rung confirms, push the one the schedule names.
               (let ((i (dstep :bump (bump-confiscation node id))))
                 (when (and i (plusp i)) (note-dispute node id "confiscation unconfirmed; broadcast rung ~a" i)))
               (cond ((< (dstep :conf-depth (confiscation-depth node conf)) +reveal-depth+)
                      ;; DEP-06 Phase 3: reveal once a rung confirms, and deep enough that a reorg
                      ;; cannot swap in a competing confiscation over another cut of the arms.  A
                      ;; preimage published while the rung sat in the mempool let any proposer grind
                      ;; the cut against it (signet soak, 2026-11-08: four confiscations "revealed"
                      ;; that never confirmed).  deposits-rust reveals at 3 confirmations.
                      (note-dispute node id "confiscation ~a broadcast (~a confirmations); revealing at ~a"
                                    (txid-hex (btx:tx-txid conf)) (confiscation-depth node conf) +reveal-depth+))
                     ((not (assoc (node-pubkey node) (reveals-of node id) :test #'equalp))
                      ;; ADVERSARY :withhold-reveal — an armer that never publishes its
                      ;; preimage: the lottery cannot be claimed, custody waits (red team:
                      ;; the last revealer holds the funds hostage; DEP-06 §Phase 4).
                      (if (getf (node-adversary node) :withhold-reveal)
                          (note-dispute node id "ADVERSARY: confiscation ~a on chain; withholding our reveal" (txid-hex (btx:tx-txid conf)))
                          (progn (dstep :reveal (publish-reveal node id))
                                 (note-dispute node id "confiscation ~a on chain; revealed" (txid-hex (btx:tx-txid conf))))))
                     ((and (< (length (revealed-indices node id lottery)) (length (lot:lottery-participants lottery)))
                           (not (reveal-deadline-passed-p node conf)))
                      (note-dispute node id "~a of ~a revealed; the reveal deadline is ~a blocks after the confiscation"
                                    (length (revealed-indices node id lottery)) (length (lot:lottery-participants lottery)) lot:+reveal-csv+))
                     (t (handler-case (let ((outcome (dstep :claim (claim-or-yield node id :confiscation-txid (btx:tx-txid conf)))))
                                        ;; not while awaiting the winner's claim (yield-evidence-v9)
                                        (when (member outcome '(:won :yielded)) (release-pledges node id))
                                        (note-dispute node id "lottery: ~(~a~)" outcome))
                          (error (e) (note-dispute node id "waiting to claim: ~a" e))))))
              ;; Our assembled confiscation fell out of the mempool: push the rung the schedule
              ;; names again rather than gathering signatures anew.
              ((let ((i (dstep :bump (bump-confiscation node id))))
                 (when i (note-dispute node id "confiscation not in the mempool; rebroadcast rung ~a" i) t)))
              (t
               (let* ((closes (dstep :arm-closes (dispute-arm-closes node base)))
                      (armers (sort (mapcar #'first (armers-of node id)) #'bytes<))
                      (q (dispute-lottery-n base (dispute-last-valid-seq node id))) (k (length armers)))
                 (cond ((< k 1) (note-dispute node id "armed; waiting for an armer"))
                       ((< h closes) (note-dispute node id "armed; arm window closes at ~a" closes))
                       ((or (equalp (first armers) (node-pubkey node)) (>= h (+ closes *proposer-grace-blocks*)))
                        (handler-case
                            (let ((tx (dstep :confiscate (confiscate node id :respectful (expiry-reason-p (op:field enter-op :reason))))))
                              (note-dispute node id "proposed confiscation ~a~@[ with ~a of ~a armed~]" (txid-hex (btx:tx-txid tx))
                                            (and (< k q) k) q))
                          (error (e) (note-dispute node id "confiscation not yet: ~a" e))))
                       (t (note-dispute node id "armed; another armer proposes first"))))))))))))

(defun drive-lock (node fork)
  "The owner lock (OWN:WITH-OWNER-LOCK) of one (node, disputed ledger): a fork is never driven
   twice at once, and a long pass over old forks never blocks arming a new one.  A drive that
   finds it held skips the fork: its holder is driving it."
  (list :drive (bytes->hex (node-pubkey node)) (record-id-hex fork)))

(defparameter *max-drive-threads* 3
  "Forks one node drives at once in the watch.  Unbounded, every fork of every node ran
   bitcoin-cli together (load 139, members missing their cosign windows).")
(defvar *drive-threads* (make-hash-table :test #'equalp)
  "node pubkey -> live forks being driven; (:dormant . pubkey) -> dormant ones")

(defun dormant-dispute-p (node fork)
  "A fork the last pass found finished or stuck on a vault already spent: driven after the
   live ones."
  (let ((note (gethash (record-id-hex fork) (node-dispute-notes node))))
    (and note (or (string= note "concluded")
                  (search "reserves spent, but not by a confiscation" note)
                  (search "yielded" note)))))

(defvar *drive-inflight* (make-hash-table :test #'equalp)
  "(node pubkey . fork id) -> T while a watch thread is driving it.")
(defvar *drive-waiting* (make-hash-table :test #'equalp)
  "(node pubkey . fork id) -> (since . warned): a live fork the watch skipped for want of a slot.")
(defparameter *drive-starved-warn-seconds* 600
  "A live fork left undriven this long is logged once (a deadline can pass unseen).")

(defun drive-schedule (forks live-free dormant-free)
  "The forks a watch pass starts: FORKS is a list of (id dormant last inflight), LAST the
   universal time of the fork's last drive or NIL.  A fork already being driven takes no
   slot.  Live forks before dormant ones, each the least recently driven first (never driven
   before all), LIVE-FREE live and DORMANT-FREE dormant slots.  In hash order instead, the
   forks at the head of the table re-took every freed slot while the ones behind them were
   never driven: a pool node with eight live forks (three re-proposing a confiscation, 20 s
   of signature timeout a pass) left its rescue dispute undriven 28 minutes after the
   rotation it had to yield to confirmed (regtest rotation-post-expiry, 2026-11-19)."
  (let ((candidates (stable-sort (remove-if #'fourth forks)
                                 (lambda (a b)
                                   (let ((da (second a)) (db (second b)))
                                     (if (eq (not da) (not db))
                                         (< (or (third a) 0) (or (third b) 0))
                                         (not da)))))))
    (loop for c in candidates
          when (if (second c) (plusp dormant-free) (plusp live-free))
            collect (first c)
            and do (if (second c) (decf dormant-free) (decf live-free)))))

(defvar *drive-queues* (make-hash-table :test #'equalp)
  "node pubkey -> live forks (id . record) waiting for a drive slot, in DRIVE-SCHEDULE
   order; (:dormant . pubkey) -> dormant ones.  Each watch pass replaces both.")
(defvar *drive-fn* 'drive-dispute "What a drive slot runs on a fork (tests time it).")

(defun in-rearm-round-p (node id)
  "Round 2 or later: DRIVE-REARM drives it, and DRIVE-DISPUTE would only say so."
  (find-if (lambda (r) (> (getf r :round) 1)) (rearm-rounds node id)))

(defun drive-slot-step (node pk key lane)
  "One step of a drive slot, which is a lane (OWN:MAKE-LANE): drive the next fork queued under
   KEY, then queue the slot's next step, so the slot takes the next fork the moment its drive
   ends.  With none left the slot gives its count in *DRIVE-THREADS* back and closes.  A drive's
   waits pump, so the other slots' drives run meanwhile (never more than the slots at once)."
  (destructuring-bind (&optional id . rec)
      (bt:with-lock-held (*drive-threads-lock*)
        (loop for e = (pop (gethash key *drive-queues*))
              while e
              unless (gethash (cons pk (car e)) *drive-inflight*)
                do (setf (gethash (cons pk (car e)) *drive-inflight*) t)
                   (remhash (cons pk (car e)) *drive-waiting*)
                   (return e)))
    (if (null id)
        (progn (own:lane-close lane)
               (bt:with-lock-held (*drive-threads-lock*) (decf (gethash key *drive-threads*))))
        (unwind-protect
             ;; a fork DRIVE-DISPUTE-NOW (or another task) is driving is skipped, not waited on
             (own:with-owner-lock ((drive-lock node rec) :busy nil)
               (handler-case (funcall *drive-fn* node rec)
                 (error (e) (note-dispute node id "error: ~a" e))
                 (own:owner-busy (c) (note-dispute node id "not driven: ~a" c))))
          (bt:with-lock-held (*drive-threads-lock*)
            (remhash (cons pk id) *drive-inflight*))
          (own:lane-push lane :next)))))

(defun start-drive-slot (node pk key)
  (let ((lane nil))
    (setf lane (own:make-lane :name "drive-dispute"
                              :run (lambda (item) (declare (ignore item)) (drive-slot-step node pk key lane))))
    (own:lane-push lane :next)
    lane))

(defun drive-load (node)
  "(values owned live waiting): the forks we own, those a watch pass queues for a live slot (not
   dormant, not in a re-arm round), and of those the ones no slot has started since the pass."
  (let ((owned 0) (live 0) (pk (node-pubkey node)))
    (loop for r being the hash-values of (node-ledgers node)
          when (and (record-fork-p r) (record-owned-p r))
            do (incf owned)
               (unless (or (dormant-dispute-p node r) (in-rearm-round-p node (record-id-hex r))) (incf live)))
    (values owned live (bt:with-lock-held (*drive-threads-lock*) (length (gethash pk *drive-queues*))))))

(defun drive-disputes (node &key parallel (rearms t))
  "Drive every dispute fork we own.  PARALLEL (the once-a-minute watch): *MAX-DRIVE-THREADS*
   slots for live forks and one for dormant ones, each slot draining a queue in
   DRIVE-SCHEDULE order (live first, least recently driven first) and taking the next fork
   the moment its drive ends.  A fork whose drive is still running is not queued, and one in
   a re-arm round is DRIVE-REARM's.
     Started once per pass, the slots capped the watch at three drives A MINUTE however short
   the drives were: cld364, holding ~60 live forks (most of them a millisecond to drive),
   drove each one every ~20 minutes, and left a rescue dispute undriven 897 s after the
   rotation it had to yield to confirmed (regtest 1119-111730, rotation-post-expiry,
   rearm-yield and rearm-rust).  Driven in turn instead, a pass over old forks (a fruitless
   confiscation rebuild took minutes each) held a live dispute back 16 minutes, past the
   time its members had to reveal (check-obligations, regtest 2026-10-14)."
  (let ((forks (loop for r being the hash-values of (node-ledgers node)
                     when (and (record-fork-p r) (record-owned-p r)) collect r))
        (pk (node-pubkey node)))
    (when parallel (ignore-errors (log-stalled-drives node)))
    (if (not parallel)
        (dolist (rec forks)
          (own:with-owner-lock ((drive-lock node rec) :busy nil)   ; held: being driven now
            (handler-case (drive-dispute node rec)
              (error (e) (note-dispute node (record-id-hex rec) "error: ~a" e)))))
        ;; Dormant forks share one slot, so live disputes always have the rest: three slow
        ;; dormant drives once held every slot while a live dispute's members never got to
        ;; reveal (check-obligations, regtest 2026-10-14).
        (let* ((by-id (make-hash-table :test #'equal)) (now (get-universal-time)) (dk (cons :dormant pk)) spawn)
          (bt:with-lock-held (*drive-threads-lock*)
            (let* ((rows (loop for r in forks
                               for id = (record-id-hex r) for k = (cons pk id)
                               do (setf (gethash id by-id) r)
                               unless (in-rearm-round-p node id)
                                 collect (list id (dormant-dispute-p node r) (gethash k *drive-last*) (gethash k *drive-inflight*))))
                   (order (drive-schedule rows most-positive-fixnum most-positive-fixnum)))
              (flet ((queue (dormant)
                       (loop for id in order
                             when (eq dormant (and (second (assoc id rows :test #'equal)) t))
                               collect (cons id (gethash id by-id)))))
                (setf (gethash pk *drive-queues*) (queue nil)
                      (gethash dk *drive-queues*) (queue t)))
              ;; A live fork left undriven this long is logged once per wait (a deadline can pass
              ;; unseen).  Measured from its last drive, or from when the watch first saw it.
              (dolist (row rows)
                (let ((k (cons pk (first row))))
                  (unless (or (second row) (fourth row))
                    (let ((w (or (gethash k *drive-waiting*) (setf (gethash k *drive-waiting*) (cons (or (third row) now) nil)))))
                      (when (and (not (cdr w)) (> (- now (car w)) *drive-starved-warn-seconds*))
                        (setf (cdr w) t)
                        ;; Forks are queued once per watch pass, so a long pass leaves the slots
                        ;; idle and a fork waiting a whole pass (regtest 1119-214607): say which.
                        (log! node "dispute ~a: not driven for ~a s (~a of ~a live drive slots running, ~a queued; forks are queued once per watch pass, the last took ~a s)"
                              (subseq (first row) 0 8) (- now (car w))
                              (gethash pk *drive-threads* 0) *max-drive-threads* (length (gethash pk *drive-queues*))
                              (let ((l (getf (gethash pk *watch-stats*) :last-ms))) (if l (round l 1000) "?"))))))))
              (loop for (key cap) in (list (list pk *max-drive-threads*) (list dk 1))
                    for n = (min (- cap (gethash key *drive-threads* 0)) (length (gethash key *drive-queues*)))
                    do (loop repeat (max n 0)
                             do (incf (gethash key *drive-threads* 0)) (push key spawn)))))
          (dolist (key spawn) (start-drive-slot node pk key))))
    (when rearms (drive-rearms node))))

(defvar *drive-dispute-async* nil
  "Drive a newly entered dispute on its own thread (the daemon sets it; tests drive inline).")

(defvar *drive-dispute-on-enter* t
  "Drive a dispute the moment we enter it (tests that stage arming by hand bind it to NIL).")

(defun drive-dispute-now (node fork)
  "Arm a dispute as soon as we enter it, as the reference does, rather than at the next
   once-a-minute pass: the arm window can close first, leaving us out of the lottery.  Only
   when no pass is driving this ledger (never two arms at once, never blocking the relay
   handler)."
  (let ((lock (drive-lock node fork)))
    (flet ((drive ()
             (own:with-owner-lock (lock :busy nil)
               (handler-case (drive-dispute node fork)
                 (error (e) (note-dispute node (record-id-hex fork) "error: ~a" e))))))
      (when *drive-dispute-on-enter*
        (if *drive-dispute-async*
            ;; Off the caller's lane: entering is the worker handling a fraud proof, and a drive
            ;; can walk the chain for minutes (a confiscation rebuild).  On the worker it held
            ;; every request behind it: an operator's deposit_open timed out (regtest 2026-10-14).
            (let ((lane (own:make-lane :name "drive-dispute-now" :close-when-empty t)))
              (own:lane-push lane #'drive))
            (drive))))))

(defun watch-pass (node)
  "One pass of the expiry watch, each step timed (WATCH-STATS); one over *WATCH-LOG-MS* logs its
   breakdown.  The steps run in this order and each one waits for the one before."
  (let ((pk (node-pubkey node)) (t0 (get-internal-real-time)) (steps '()))
    (flet ((wstep (name fn)
             (let ((s0 (get-internal-real-time)))
               (let ((st (gethash pk *watch-stats*)))
                 (setf (gethash pk *watch-stats*) (list* :current (cons name (get-universal-time)) (alexandria:remove-from-plist st :current))))
               (ignore-errors (funcall fn))
               (push (cons name (ms-since s0)) steps))))
      (wstep :parked-proofs (lambda () (rejudge-parked-proofs node)))
      (wstep :dispute-expired (lambda () (dispute-expired-quorums node)))
      (wstep :drive-disputes (lambda () (drive-disputes node :parallel t :rearms nil)))
      (wstep :drive-rearms (lambda () (drive-rearms node)))
      (wstep :dereliction (lambda () (drive-dereliction node)))
      ;; The vault watch is not a step: VAULT-WATCH-PASS runs it on its own thread.
      (wstep :migration-watch (lambda () (drive-migration-watch node)))
      (wstep :obligation-watch (lambda () (drive-obligation-watch node)))
      (wstep :rotation-rebroadcast (lambda () (drive-rotation-rebroadcast node))))
    (let* ((ms (ms-since t0)) (steps (nreverse steps))
           (st (alexandria:remove-from-plist (gethash pk *watch-stats*) :current))
           (totals (copy-alist (getf st :totals))))
      (dolist (e steps)
        (let ((c (assoc (car e) totals)))
          (if c (setf (cdr c) (cons (+ (cadr c) (cdr e)) (1+ (cddr c)))) (push (list* (car e) (cdr e) 1) totals))))
      (setf (getf st :passes) (1+ (or (getf st :passes) 0)) (getf st :last-ms) ms (getf st :last-steps) steps
            (getf st :totals) totals)
      (when (> ms (or (getf st :max-ms) -1)) (setf (getf st :max-ms) ms (getf st :max-steps) steps))
      (setf (gethash pk *watch-stats*) st)
      (when (>= ms *watch-log-ms*)
        (log! node "watch pass took ~a s [~{~a~^ ~}]" (round ms 1000)
              (loop for (name . sms) in (sort (copy-list steps) #'> :key #'cdr)
                    when (>= sms 100) collect (format nil "~(~a~) ~as" name (/ (round sms 100) 10.0))))))))

(defun watch-stats (node)
  "The expiry watch's timing for NODE (WATCH-PASS), with the step running now and for how long."
  (let ((st (gethash (node-pubkey node) *watch-stats*)))
    (append (alexandria:remove-from-plist st :current)
            (let ((c (getf st :current))) (and c (list :current (list (car c) (- (get-universal-time) (cdr c)))))))))

(defvar *vault-watch-stats* (make-hash-table :test #'equalp :synchronized t)
  "node pubkey -> plist :passes :last-ms :max-ms :current-since (universal time, while a pass runs).")

(defun vault-watch-pass (node)
  "One timed DRIVE-VAULT-WATCH, never two at once for a node (its thread and the :vault-watch
   control command).  It has its own thread, not a step of WATCH-PASS: regtest 1120-063204 (40cb3c4)
   had cld364's first pass after a restart spend 20 minutes in DRIVE-REARMS before the vault
   watch's turn, and a theft went unreported for the 300 s it had (the re-arm follow cache is in
   memory, so a restart pays the whole first scan again).  A theft proof must not wait on that."
  (let* ((pk (node-pubkey node))
         (t0 (get-internal-real-time)))
    ;; held by a pass suspended in a wait: the caller runs it again later (OWN:OWNER-BUSY)
    (own:with-owner-lock ((list :vault-watch (bytes->hex pk)))
      (setf (getf (gethash pk *vault-watch-stats*) :current-since) (get-universal-time))
      (unwind-protect (drive-vault-watch node)
        (let ((st (alexandria:remove-from-plist (gethash pk *vault-watch-stats*) :current-since))
              (ms (ms-since t0)))
          (setf (getf st :passes) (1+ (or (getf st :passes) 0)) (getf st :last-ms) ms
                (getf st :max-ms) (max ms (or (getf st :max-ms) 0)))
          (setf (gethash pk *vault-watch-stats*) st))))))

(defun vault-watch-stats (node)
  (let ((st (gethash (node-pubkey node) *vault-watch-stats*)))
    (append (alexandria:remove-from-plist st :current-since)
            (let ((c (getf st :current-since))) (and c (list :current (- (get-universal-time) c)))))))

(defun start-expiry-watch (node &key (interval 60) (vault-interval 30))
  "Start the expiry watch (WATCH-PASS every INTERVAL s) and the vault watch (VAULT-WATCH-PASS every
   VAULT-INTERVAL s), two timers of their own on the owner thread; return (values expiry-timer
   vault-timer) (OWN:CANCEL-TIMER stops one).  Separate timers, so a watch pass waiting in a step
   (a drive asking for signatures, bitcoind) does not hold the vault watch back: the wait pumps,
   and the vault timer runs inside it."
  (let ((vault (own:every-seconds vault-interval (lambda () (ignore-errors (vault-watch-pass node))) :name "cld-vault-watch")))
    (values (own:every-seconds interval (lambda () (watch-pass node)) :name "cld-expiry")
            vault)))

(defun start-invoice-poller (node &key (interval 3))
  (own:every-seconds interval (lambda ()
                                (ignore-errors (credit-paid-invoices node))
                                (ignore-errors (settle-pending-payments node)))
                     :name "cld-invoices"))

;;; ---------------------------------------------------------------------------
;;; Wallet: a key, a bus, and the requests it can make

(defstruct (wallet (:constructor %make-wallet)) priv pubkey keypair bus (pending (make-hash-table :test #'equal)) (nonce 0))

(defun make-wallet (&key priv bus)
  (let* ((priv (w:even-y-privkey priv))     ; a pooled copy this wallet owns
         (wal (gossamer:own (%make-wallet :priv priv :pubkey (up:compressed-pubkey priv) :keypair (w:nostr-keypair priv) :bus bus) priv)))
    (bus:bus-subscribe bus (flt:make-filter :kinds (list w:+kind-response+))
                       (lambda (event)
                         (let ((wt (gethash (w:event-request-id event) (wallet-pending wal))))
                           (when wt (bt:with-lock-held ((waiter-lock wt))
                                      (unless (member (ev:event-id event) (waiter-ids wt) :test #'string=)
                                        (push (ev:event-id event) (waiter-ids wt))
                                        (push (w:parse-json (ev:event-content event)) (waiter-responses wt))
                                        (bt:condition-notify (waiter-cv wt))))))))
    wal))

(defun wallet-request (wal ledger-id-hex action params &key (timeout *cosign-timeout*) extra-tags)
  "Send a request; return (values success result error request-hash)."
  (let* ((event (w:request-event (wallet-keypair wal) ledger-id-hex action params :extra-tags extra-tags))
         (wt (make-waiter :want 1)))
    (setf (gethash (ev:event-id event) (wallet-pending wal)) wt)
    (bus:bus-publish (wallet-bus wal) event)
    (own:wait-until (lambda () (waiter-responses wt)) :timeout timeout :step 0.2)
    (remhash (ev:event-id event) (wallet-pending wal))
    ;; The FIRST response is the answer.  An operator that receives the request twice
    ;; (a relay redelivery) answers twice, and the second answer to a lock is "nonce
    ;; already accepted": the signet soak (2026-10-21) took that one, since responses
    ;; are pushed newest first, and logged a committed lock as a failure.
    (let ((r (car (last (waiter-responses wt)))) (h (sha256 (ascii->bytes (ev:event-content event)))))
      (if r (values (w:jget r "success") (w:jget r "result") (w:jget r "error") h) (values nil nil "timeout" h)))))

(defun wallet-request-hash (wal ledger-id-hex action params)
  "The request hash DEP-12 anchors: SHA256 of the signed request's content."
  (declare (ignore wal ledger-id-hex action))
  (sha256 (ascii->bytes (w:json params))))

(defun wallet-descriptor (wal) (format nil "pk(~a)" (bytes->hex (wallet-pubkey wal))))

(defun wallet-open-deposit (wal ledger-id-hex &key descriptor)
  (multiple-value-bind (ok res err) (wallet-request wal ledger-id-hex "deposit_open" (w:json-object "descriptor" (or descriptor (wallet-descriptor wal))))
    (unless ok (fail "deposit_open: ~a" err))
    (hex->bytes (w:jget res "deposit_id"))))

(defun wallet-balance (wal ledger-id-hex deposit-id)
  (multiple-value-bind (ok res err) (wallet-request wal ledger-id-hex "balance_query" (w:json-object "deposit_id" (bytes->hex deposit-id)))
    (unless ok (fail "balance_query: ~a" err))
    (values (w:jget res "balance_msats") (w:jget res "locked_msats"))))

(defun wallet-transfer (wal ledger-id-hex from to amount-msats &key (fee 0) preimage (timeout-blocks 144) (height 0))
  "Lock AMOUNT from deposit FROM to deposit TO behind sha256(PREIMAGE).  Returns (values transfer-id preimage)."
  (let* ((preimage (or preimage (random-aux)))
         (transfer-nonce (random-aux))
         (transfer-id (sha256 (cat transfer-nonce from to)))
         (o (list :type :transfer-lock :transfer-nonce transfer-nonce :source-deposit-id from :destination-deposit-id to
                  :amount amount-msats :fee fee :completion-script (format nil "sha256(~a)" (bytes->hex (sha256 preimage)))
                  :timeout-height (+ height timeout-blocks) :transfer-id transfer-id
                  :nonce (incf (wallet-nonce wal)) :expiry (+ height 144) :witness '())))
    (setf (getf o :witness) (d17:sign-operation o (wallet-priv wal)))
    (multiple-value-bind (ok res err)
        ;; Both shapes: our operator takes the encoded operation; the reference
        ;; operator wants the fields (and a 64-byte "signature" for the witness).
        (wallet-request wal ledger-id-hex "transfer_lock"
                        (w:json-object "operation" (base64-encode (op:encode-operation o))
                                       "transfer_nonce" (bytes->hex transfer-nonce)
                                       "source_deposit_id" (bytes->hex from) "destination_deposit_id" (bytes->hex to)
                                       "amount" amount-msats "fee" fee
                                       "completion_script" (getf o :completion-script) "timeout_height" (getf o :timeout-height)
                                       "transfer_id" (bytes->hex transfer-id)
                                       "op_nonce" (getf o :nonce) "op_expiry" (getf o :expiry)
                                       "signature" (bytes->hex (first (getf o :witness)))))
      (declare (ignore res))
      (unless ok (fail "transfer_lock: ~a" err))
      (values transfer-id preimage))))

(defun address->spk (address)
  "The scriptPubKey of a segwit ADDRESS (any network: the hrp is read off the address)."
  (let ((hrp (subseq address 0 (position #\1 address :from-end t))))
    (multiple-value-bind (witver program) (cl-consensus.encoding:segwit-decode address hrp)
      (cat (octets (if (zerop witver) 0 (+ #x50 witver)) (length program)) program))))

(defun wallet-exit (wal ledger-id-hex deposit-id amount-msats address &key expires-at (height 0))
  "DEP-20 §3: request an exit of AMOUNT-MSATS from DEPOSIT-ID to ADDRESS at the next rotation.
   Returns the request id (the ExitRequest update's chain_hash, hex)."
  (let ((o (append (list :type :exit-request :deposit-id deposit-id :amount amount-msats
                         :exit-address (address->spk address))
                   (when expires-at (list :expires-at-height expires-at))
                   (list :nonce (incf (wallet-nonce wal)) :expiry (+ height 144) :witness '()))))
    (setf (getf o :witness) (d17:sign-operation o (wallet-priv wal)))
    (multiple-value-bind (ok res err)
        (wallet-request wal ledger-id-hex "exit_request" (w:json-object "operation" (base64-encode (op:encode-operation o))))
      (unless ok (fail "exit_request: ~a" err))
      (w:jget res "exit_request_id"))))

(defun wallet-make-offer (wal ledger-id-hex max-sats &key (min-sats 1) (blocks-valid 144))
  "DEP-10: ask LEDGER-ID-HEX's operator for a cosigned funding offer crediting our pk() deposit.
   Returns the response object (funding_address, deadline_block, offer_id, cosign...)."
  (multiple-value-bind (ok res err)
      ;; An offer waits on the operator's own cosign round with its quorum (DEP-10): give it
      ;; that round plus slack, not one cosign timeout (a reference operator took 14 s).
      (wallet-request wal ledger-id-hex "make_offer"
                      (w:json-object "descriptor" (wallet-descriptor wal) "max_sats" max-sats
                                     "min_sats" min-sats "blocks_valid" blocks-valid)
                      :timeout (* 4 *cosign-timeout*))
    (unless ok (fail "make_offer: ~a" err))
    (if (stringp res) (w:parse-json res) res)))

(defun wallet-complete-offer (wal ledger-id-hex offer-id-hex txid-hex vout)
  "DEP-10 §Completion: name the payment (TXID-HEX display order, VOUT) of an offer on LEDGER-ID-HEX."
  (multiple-value-bind (ok res err)
      (wallet-request wal ledger-id-hex "complete_offer"
                      (w:json-object "offer_id" offer-id-hex "txid" txid-hex "vout" vout "amount_sats" 0))
    (unless ok (fail "complete_offer: ~a" err))
    res))

(defun wallet-migrate (wal from-ledger-hex deposit-id amount-msats to-ledger-hex &key (height 0) (blocks-valid 288))
  "DEP-20 §10: move AMOUNT-MSATS from DEPOSIT-ID on FROM-LEDGER-HEX to our deposit on
   TO-LEDGER-HEX: a cosigned offer there, then an exit here paying its address that is released
   if not settled 6 blocks before the offer's deadline.  Returns (values request-id offer)."
  (let* ((sats (floor amount-msats 1000))
         (offer (wallet-make-offer wal to-ledger-hex sats :min-sats 1 :blocks-valid blocks-valid))   ; the output is sats less its own cost
         (address (or (w:jget offer "funding_address") (fail "offer without funding_address")))
         (deadline (or (w:jget offer "deadline_block") (fail "offer without deadline_block"))))
    (when (<= (- deadline 6) height) (fail "offer deadline ~a leaves no room to settle" deadline))
    (values (wallet-exit wal from-ledger-hex deposit-id amount-msats address :expires-at (- deadline 6) :height height)
            offer)))

(defun wallet-exit-cancel (wal ledger-id-hex deposit-id request-id &key (height 0))
  (let ((o (list :type :exit-cancel :deposit-id deposit-id :exit-request-id request-id
                 :nonce (incf (wallet-nonce wal)) :expiry (+ height 144) :witness '())))
    (setf (getf o :witness) (d17:sign-operation o (wallet-priv wal)))
    (multiple-value-bind (ok res err)
        (wallet-request wal ledger-id-hex "exit_cancel" (w:json-object "operation" (base64-encode (op:encode-operation o))))
      (declare (ignore res))
      (unless ok (fail "exit_cancel: ~a" err))
      t)))

(defun wallet-complete-transfer (wal ledger-id-hex transfer-id preimage)
  (let ((o (list :type :transfer-complete :transfer-id transfer-id :script-witness (list preimage))))
    (multiple-value-bind (ok res err)
        (wallet-request wal ledger-id-hex "transfer_complete"
                        (w:json-object "operation" (base64-encode (op:encode-operation o))
                                       "transfer_id" (bytes->hex transfer-id) "preimage" (bytes->hex preimage)))
      (declare (ignore res))
      (unless ok (fail "transfer_complete: ~a" err))
      t)))

;;; Wallet: pay a Lightning invoice from a deposit

(defun wallet-pay-invoice (wal ledger-id-hex deposit-id bolt11 amount-msat &key (fee 0) (height 0))
  "InvoiceLock signed by us; the operator pays and settles.  Returns (values ok preimage error)."
  (let* ((hash (ln:invoice-payment-hash bolt11))
         (o (list :type :invoice-lock :deposit-id deposit-id :amount amount-msat :payment-id hash :sequence-number 0
                  :nonce (incf (wallet-nonce wal)) :expiry (+ height 144) :fee fee :witness '())))
    (setf (getf o :witness) (d17:sign-operation o (wallet-priv wal)))
    (multiple-value-bind (ok res err)
        (wallet-request wal ledger-id-hex "pay_invoice"
                        (w:json-object "descriptor" (wallet-descriptor wal) "invoice" bolt11 "payment_hash" (bytes->hex hash)
                                       "amount_msats" amount-msat "fee_msats" fee "nonce" (op:field o :nonce) "expiry" (op:field o :expiry)
                                       "witness" (w:json-object "stack" (coerce (mapcar #'bytes->hex (op:field o :witness)) 'vector)))
                        :timeout 40)
      (values ok (and ok (hex->bytes (w:jget res "preimage"))) err))))

;;; Completion scripts (DEP-09/13): sha256(H) opened by a preimage, pointlock(P)
;;; opened by the scalar s with s*G = P.

(defun completion-satisfied-p (script witness) (lg:completion-satisfied-p script witness))

;;; Wallet: DEP-12 escalation through a quorum member

(defun wallet-escalate (wal member-ledger-hex request-hash target-ledger-hex target-operator-hex)
  "Ask a quorum member to anchor our unanswered request on its ledger.
   Returns the member's reply (sequence, tip_hash)."
  (multiple-value-bind (ok res err)
      (wallet-request wal member-ledger-hex "delivery_embed"
                      (w:json-object "request_hash" (bytes->hex request-hash) "target_ledger_id" target-ledger-hex
                                     "target_operator" target-operator-hex))
    (unless ok (fail "delivery_embed: ~a" err))
    res))

(defun wallet-lock-to (wal ledger-id-hex from to amount-msats hash &key (fee 0) (timeout-blocks 144) (height 0) point)
  "A TransferLock behind an externally chosen sha256 HASH, or a POINT (33 bytes)
   for a PTLC leg.  Returns the transfer id."
  (let* ((transfer-nonce (random-aux))
         (transfer-id (sha256 (cat transfer-nonce from to)))
         (o (list :type :transfer-lock :transfer-nonce transfer-nonce :source-deposit-id from :destination-deposit-id to
                  :amount amount-msats :fee fee
                  :completion-script (if point (format nil "pointlock(~a)" (bytes->hex point)) (format nil "sha256(~a)" (bytes->hex hash)))
                  :timeout-height (+ height timeout-blocks) :transfer-id transfer-id
                  :nonce (incf (wallet-nonce wal)) :expiry (+ height 144) :witness '())))
    (setf (getf o :witness) (d17:sign-operation o (wallet-priv wal)))
    (multiple-value-bind (ok res err)
        (wallet-request wal ledger-id-hex "transfer_lock" (w:json-object "operation" (base64-encode (op:encode-operation o))))
      (declare (ignore res))
      (unless ok (fail "transfer_lock: ~a" err))
      transfer-id)))

(defun wallet-pending-lock (node ledger-id-hex hash to-deposit &key point)
  "In a followed/replicated ledger, the pending TransferLock to TO-DEPOSIT behind HASH (or POINT), or NIL."
  (let ((rec (find-record node ledger-id-hex))
        (script (if point (format nil "pointlock(~a)" (bytes->hex point)) (format nil "sha256(~a)" (bytes->hex hash)))))
    (when rec
      (loop for tid being the hash-keys of (lg:ledger-pending-transfers (record-ledger rec)) using (hash-value p)
            when (and (equalp (getf p :destination) to-deposit) (string= (getf p :completion-script) script))
              return (list :transfer-id tid :amount (getf p :amount) :timeout-height (getf p :timeout-height) :source (getf p :source))))))

;;; Wallet: receive over Lightning

(defun wallet-make-invoice (wal ledger-id-hex deposit-id amount-msat &key description operator-pubkey)
  "Ask the operator for an invoice; verify the attestation signatures it and a
   cosigner put on (ledger, payment hash, deposit, amount).  Returns
   (values bolt11 payment-hash attestation)."
  (multiple-value-bind (ok res err)
      (wallet-request wal ledger-id-hex "make_invoice"
                      (w:json-object "amount_msats" amount-msat "deposit_id" (bytes->hex deposit-id) "description" description))
    (unless ok (fail "make_invoice: ~a" err))
    (let* ((hash (hex->bytes (w:jget res "payment_hash")))
           (op-pk (hex->bytes (w:jget res "operator_pubkey"))))
      (when (and operator-pubkey (not (equalp op-pk operator-pubkey))) (fail "invoice attested by the wrong operator"))
      (unless (= (w:jget res "amount_msat") amount-msat) (fail "amount mismatch"))
      (unless (schnorr:schnorr-verify (up:x-only op-pk)
                                      (ln:invoice-cosign-message ledger-id-hex hash deposit-id amount-msat
                                                                 (hex->bytes (w:jget res "operator_ledger_hash")))
                                      (hex->bytes (w:jget res "operator_signature")))
        (fail "operator invoice attestation does not verify"))
      (when (w:jget res "cosign_signature")
        (unless (schnorr:schnorr-verify (up:x-only (hex->bytes (w:jget res "cosigner_pubkey")))
                                        (ln:invoice-cosign-message ledger-id-hex hash deposit-id amount-msat
                                                                   (hex->bytes (w:jget res "cosigner_ledger_hash")))
                                        (hex->bytes (w:jget res "cosign_signature")))
          (fail "cosigner invoice attestation does not verify")))
      (values (w:jget res "invoice") hash res))))

;;; ---------------------------------------------------------------------------
;;; Disputes (DEP-06): forks, arming, confiscation, reveal, claim

(defun fork-key (id-hex operator33) (format nil "~a:fork:~a" id-hex (subseq (bytes->hex operator33) 0 16)))
(defun find-fork (node id-hex operator33) (gethash (fork-key id-hex operator33) (node-ledgers node)))
(defun forks-of (node id-hex)
  (loop for rec being the hash-values of (node-ledgers node)
        when (and (record-fork-p rec) (string= (record-fork-of rec) id-hex)) collect rec))

(defun latest-quorum-begin-seq (rec)
  "The sequence of REC's latest QuorumBegin, or 0."
  (let ((u (record-latest rec :quorum-begin))) (if u (up:update-seq u) 0)))

(defun fork-live-p (node fork)
  "FORK still speaks for its ledger's current dispute: it has custody (DisputeAcquire: the
   base chain is dead), or it is unconcluded and its DisputeEnter is at or after the base's
   latest QuorumBegin.  A yielded fork, or one from before a later QuorumBegin, is history:
   it must not stop us detecting, disputing or acting on what happens on the ledger now."
  (let ((base (find-record node (record-fork-of fork))))
    (multiple-value-bind (enter eo) (fork-op fork :dispute-enter)
      (cond ((fork-op fork :dispute-acquire) t)
            ((fork-op fork :dispute-yield) nil)
            ((null enter) t)
            ((null base) t)
            (t (let ((lvs (or (op:field eo :last-valid-sequence) -1)) (qb (latest-quorum-begin-seq base)))
                 (cond ((>= lvs qb) t)
                       ((not (expiry-reason-p (op:field eo :reason))) nil)
                       ;; strict-lottery-v8 (:expiry-ends-on-spend, judged at the fork point): a later
                       ;; QuorumBegin answers an expiry dispute only once its spend of the vault confirmed.
                       (t (let ((on-spend (lg:ruleset-rule-p (lg:ledger-active-ruleset (record-ledger fork)) :expiry-ends-on-spend)))
                            (expiry-fork-live-p lvs qb on-spend
                                                (and on-spend (reestablishment-confirmed-p node base lvs))))))))))))

(defun expiry-fork-live-p (last-valid-seq latest-quorum-begin-seq on-spend rotation-confirmed)
  "An unconcluded fork on a quorum_expired DisputeEnter at LAST-VALID-SEQ still speaks for its
   ledger: no QuorumBegin since has answered its ground (EXPIRY-DISPUTE-ENDED-P, ignoring
   confiscation; under ON-SPEND only a re-establishment whose spend confirmed answers it).  An
   answered one is history and stands in for no later dispute: DEP-05 \"A member MUST NOT let a
   live dispute on an earlier ground stand in for it\" (signet soak, 2026-11-22: deposits-rust
   ref4's fork of 0aeebcc5 at 359090, re-established at 359228..436154, carried the dispute of
   that quorum's own expiry).  Vector: expiry_dispute_ends.json, its fork_reuse cases."
  (not (expiry-dispute-ended-p last-valid-seq latest-quorum-begin-seq nil
                               :on-spend on-spend :rotation-confirmed rotation-confirmed)))

(defun fork-reuse-p (live unarmed-expiry punitive)
  "Whether a new dispute of ours is carried by our existing fork: it is LIVE (FORK-LIVE-P), and a
   PUNITIVE dispute is never carried by an UNARMED-EXPIRY fork (UNARMED-EXPIRY-FORK-P).  Vector:
   expiry_dispute_ends.json, its fork_reuse cases."
  (and live (not (and punitive unarmed-expiry))))

(defun live-fork (node id-hex operator33)
  "OPERATOR33's fork of ID-HEX when it is live (fork-live-p), else NIL."
  (let ((f (find-fork node id-hex operator33))) (and f (fork-live-p node f) f)))

(defun unarmed-expiry-fork-p (fork)
  "FORK entered on a lapsed quorum (quorum_expired) and has neither armed, yielded nor acquired.
   Its DisputeEnter does not act on any fraud proof (FR::ACTED-ON-P counts a non-expiry
   DisputeEnter or a DisputeArmed), so it must never stand in for a punitive dispute."
  (multiple-value-bind (u o) (fork-op fork :dispute-enter)
    (and u (expiry-reason-p (op:field o :reason))
         (not (fork-op fork :dispute-armed)) (not (fork-op fork :dispute-yield))
         (not (fork-op fork :dispute-acquire)))))

(defun blocking-fork (node id-hex punitive)
  "Our live fork of ID-HEX that already answers a new proof, else NIL.  For a PUNITIVE proof an
   un-armed expiry fork does not: deposits-rust ref7 (signet, 2026-11-20) let its un-armed
   quorum_expired fork of 5effb9e8 absorb a self-detected Equivocation, signed no punitive
   DisputeEnter, and was proved derelict.  Here the same fork made HANDLE-OPERATOR-FRAUD skip the
   proof outright."
  (let ((f (live-fork node id-hex (node-pubkey node))))
    (and f (fork-reuse-p t (unarmed-expiry-fork-p f) punitive) f)))

(defun retire-fork (node fork &key superseded)
  "Drop a fork that is no longer live so a new dispute can open in its place; what it knew of
   a confiscation is kept (note-confiscation persists it).  SUPERSEDED: it is dropped because a
   later DisputeEnter of its disputant replaces it (DEP-03 \"The dispute\", latest counts), which
   is not retiring it for its pledges (DEP-03 \"When a pledge is live\", ruled 2026-11-24): a fork
   of ours keeps whatever it still holds (NOTE-SUPERSEDED), and its dispute's reservation stays."
  (when (record-confiscation fork) (note-confiscation node (record-fork-of fork) (btx:tx-txid (record-confiscation fork))))
  (let* ((ours (equalp (record-fork-operator fork) (node-pubkey node)))
         (kept (and ours superseded (note-superseded node fork))))
    (remhash (fork-key (record-fork-of fork) (record-fork-operator fork)) (node-ledgers node))
    ;; DEP-03 "When a pledge is live": retiring our fork ends its dispute's hold on our pledges.
    ;; (Not while a re-arm round is under way: a yield ends a round, not the dispute, as in DRIVE-DISPUTE.)
    ;; Superseded, only when it held nothing any more (KEPT: what it still holds).
    (when (and ours (not kept) (not (rearm-rounds node (record-fork-of fork))))
      (release-pledges node (record-fork-of fork))))
  (log! node "fork of ~a by ~a ~a" (subseq (record-fork-of fork) 0 8) (subseq (bytes->hex (record-fork-operator fork)) 0 8)
        (if superseded "superseded by its disputant's later DisputeEnter (its pledges stay held)"
            "retired (concluded or superseded by a later QuorumBegin)")))

;;; DEP-03 "When a pledge is live" (ruled 2026-11-24): superseding never ends a pledge.  A fork of
;;; ours that a later DisputeEnter of ours supersedes leaves this table holding what it still held:
;;; its pledges, each until its own valid yield (a void one's evidence confirming), or a binding
;;; claim of its round or a later one (OTHERS-BINDING-ACQUIRES' rule).  One key holds one fork per
;;; ledger here, so the superseded fork itself is gone; what judges its pledges is kept, and saved.
;;; Vector inspect/vectors/enter_after_yield.txt (its pledge cases).

(defun superseded-entry (id-hex events &key enter-seq vault yield-txid)
  "What a superseded fork of ID-HEX still holds, from its EVENTS (FORK-PLEDGE-EVENTS): a plist
   (:id :pledges ((key . round) ...) :enter-seq :vault :yield-txid), or NIL when it holds nothing.
   YIELD-TXID: the transaction its void yield names (its pledges end once that confirms)."
  (let ((pledges (nth-value 3 (fork-pledges-held events)))
        (void (position :void-yield events :key #'first :from-end t)))
    (and pledges (list :id id-hex :pledges pledges :enter-seq enter-seq :vault vault
                       ;; a void yield after its last arm: once its evidence confirms, it ends them
                       :yield-txid (and void (> void (or (position :arm events :key #'first :from-end t) -1))
                                        yield-txid)))))

(defun superseded-pledges-held (entry &key others yield-seen)
  "ENTRY's pledges still held: none once its void yield's evidence is seen (YIELD-SEEN), and
   none of a round at or below the latest OTHERS (rounds closed by binding claims)."
  (unless (and yield-seen (getf entry :yield-txid))
    (let ((over (and others (reduce #'max others))))
      (loop for (k . r) in (getf entry :pledges) unless (and over (<= r over)) collect k))))

(defun note-superseded (node fork)
  "Keep what our FORK, being superseded, still holds (SUPERSEDED-ENTRY), and save it."
  (let* ((enter (fork-op fork :dispute-enter))
         (q (and enter (record-latest fork :quorum-begin :below (up:update-seq enter))))
         (y (nth-value 1 (fork-op fork :dispute-yield)))
         (e (superseded-entry (record-fork-of fork) (fork-pledge-events node fork)
                              :enter-seq (and enter (up:update-seq enter))
                              :vault (and q (first (fr:rotation-rungs (op:update-op q))))
                              :yield-txid (and y (or (op:field y :lost-to) (op:field y :excluded-by))))))
    (when e
      (push e (node-superseded node))
      (save-superseded node))
    e))

(defun superseded-holds (node)
  "The coins our superseded forks still hold (SUPERSEDED-PLEDGES-HELD); entries holding nothing
   any more are dropped."
  (let ((held '()) (keep '()))
    (dolist (e (node-superseded node))
      (let ((h (superseded-pledges-held
                e :others (mapcar #'second (%others-binding-acquires node (getf e :id) (getf e :enter-seq) (getf e :vault) nil))
                  :yield-seen (and (getf e :yield-txid) (yield-evidence-seen-p node (list :type :dispute-yield :lost-to (getf e :yield-txid)))))))
        (when h (push e keep) (setf held (append held h)))))
    (unless (= (length keep) (length (node-superseded node)))
      (setf (node-superseded node) (nreverse keep))
      (save-superseded node))
    held))

(defun save-superseded (node)
  (when (node-data-dir node)
    (ensure-directories-exist (node-data-dir node))
    (with-open-file (out (merge-pathnames "superseded.sexp" (node-data-dir node)) :direction :output :if-exists :supersede)
      (with-standard-io-syntax
        (prin1 (mapcar (lambda (e) (list (getf e :id) (getf e :pledges) (getf e :enter-seq)
                                         (and (getf e :vault) (bytes->hex (getf e :vault)))
                                         (and (getf e :yield-txid) (bytes->hex (getf e :yield-txid)))))
                       (node-superseded node))
               out)))))

(defun load-superseded (node)
  (let ((f (and (node-data-dir node) (probe-file (merge-pathnames "superseded.sexp" (node-data-dir node))))))
    (when f
      (with-open-file (in f)
        (setf (node-superseded node)
              (loop for (id pledges seq vault ytx) in (with-standard-io-syntax (let ((*read-eval* nil)) (read in nil '())))
                    collect (list :id id :pledges pledges :enter-seq seq :vault (and vault (hex->bytes vault))
                                  :yield-txid (and ytx (hex->bytes ytx)))))))))

(defun fork-summaries (node)
  "Every dispute fork we hold: ledger, its operator (the disputant), state, and whether it is
   live (fork-live-p) — a non-live fork no longer suppresses detection on its ledger."
  (loop for f being the hash-values of (node-ledgers node)
        when (record-fork-p f)
          collect (list :ledger (record-fork-of f) :by (bytes->hex (record-fork-operator f))
                        :state (cond ((fork-op f :dispute-acquire) :acquired) ((fork-op f :dispute-yield) :yielded)
                                     ((fork-op f :dispute-armed) :armed) (t :entered))
                        :live (and (fork-live-p node f) t))))

(defun disputing-members (node rec)
  "Pubkeys of REC's current quorum members that have disputed it since the quorum
   began: a fork whose DisputeEnter (other than for a lapsed quorum) is at or after
   the latest QuorumBegin, whether still open, armed, yielded or acquired."
  (let* ((qb-seq (or (let ((u (record-latest rec :quorum-begin))) (and u (up:update-seq u)))
                     0))
         (members (mapcar #'lg:member-pubkey (lg:ledger-quorum-members (record-ledger rec)))))
    (loop with expiry = (lg:ledger-quorum-expiry (record-ledger rec))
          for f in (forks-of node (record-id-hex rec))
          for (u o) = (multiple-value-list (fork-op f :dispute-enter))
          when (and o (member (record-fork-operator f) members :test #'equalp)
                    (>= (or (op:field o :last-valid-sequence) -1) qb-seq)
                    ;; respectful: the operator re-establishes.  Any other dispute counts in
                    ;; every state: a loser yields only once the vault is confiscated.
                    (not (dispute-enter-expiry-p u o expiry)))
            collect (record-fork-operator f) into keys
          finally (return (remove-duplicates keys :test #'equalp)))))

(defun acquire-binds-p (node fork)
  "FORK's DisputeAcquire moves custody: as published under an earlier ruleset, and under
   strict-lottery-v8 (the base ledger's ruleset) only once its claim confirmed (DEP-06 §Phase 4).
   An acquire after its author's own yield (DEP-06 \"A claim after the claimant's own yield\",
   the advantage rule) moves custody only by the binding judgment, under every ruleset."
  (multiple-value-bind (u o) (fork-op fork :dispute-acquire)
    (declare (ignore o))
    (and u
         (let ((base (find-record node (record-id-hex fork))))
           (or (and (not (and base (lg:ruleset-rule-p (lg:ledger-active-ruleset (record-ledger base)) :acquire-on-confirm)))
                    (zerop (fork-acquire-min-round fork u)))
               (acquire-confirmed-p node fork))))))

(defun acquire-min-round (events)
  "DEP-06 \"A claim after the claimant's own yield\": EVENTS are the acquirer's own dispute
   operations on its fork before the acquire, oldest first, as (:arm ROUND), (:yield) or anything
   else.  When a yield follows its latest arm, the acquire must bind that arm's round or a later
   one: that round.  Otherwise 0 (no bound).  Vector: claim_after_yield.json (min_round)."
  (let ((arm 0) (yielded nil))
    (dolist (e events)
      (case (first e)
        (:arm (setf arm (or (second e) 1) yielded nil))
        (:yield (setf yielded t))
        (:acquire (setf yielded nil))))
    (if yielded arm 0)))

(defun fork-acquire-min-round (fork u)
  "ACQUIRE-MIN-ROUND of the DisputeAcquire U on FORK, from U's author's arms and yields before it."
  (let ((me (up:update-operator-id u)))
    (acquire-min-round
     (loop for x in (sort (remove-if-not (lambda (x) (and (equalp (up:update-operator-id x) me) (< (up:update-seq x) (up:update-seq u))))
                                         (append (copy-list (fork-own-updates fork :dispute-armed))
                                                 (copy-list (fork-own-updates fork :dispute-yield))
                                                 (copy-list (fork-own-updates fork :dispute-acquire))))
                          #'< :key #'up:update-seq)
           for o = (op:update-op x)
           collect (case (op:operation-type o)
                     (:dispute-armed (list :arm (or (op:field o :rearm-round) 1)))
                     (:dispute-yield (list :yield))
                     (t (list :acquire)))))))

(defun acquired-fork (node id-hex)
  "The fork of ID-HEX's ledger whose DisputeAcquire took custody, if any (ACQUIRE-BINDS-P)."
  (find-if (lambda (f) (acquire-binds-p node f)) (forks-of node id-hex)))

(defun ledger-chain-record (node id-hex)
  "The record holding ID-HEX's ledger as it now runs: the acquired fork after a custody change
   (cl keeps the winner's chain as its fork), else the replica."
  (or (acquired-fork node id-hex) (find-record node id-hex)))

(defun custody-moved-to (node rec)
  "The key a DisputeAcquire on any fork of REC's ledger gave custody to, when it is
   not ours: the ledger's operator from then on (DEP-06)."
  (loop for f in (forks-of node (record-id-hex rec))
        for o = (nth-value 1 (fork-op f :dispute-acquire))
        when (and o (not (equalp (op:field o :new-custodian) (node-pubkey node)))
                  (acquire-binds-p node f))
          return (op:field o :new-custodian)))

;;; DEP-06 "An acquire binds once its claim confirms" (strict-lottery-v8): a DisputeAcquire binds iff
;;; its claim_txid is confirmed AND its input 0 spends the dispute's current lottery outpoint.
;;; Confirmation alone bound a606a4ca's acquire naming 21910507, a confirmed claim of 70b0abb3's
;;; round-2 output 46a66b12:0 (same script, same value; regtest rearm-rust 1120-090836), and lets
;;; any armer name any confirmed transaction.  Shared vector inspect/vectors/acquire_binding.json.

(defparameter +rearm-tier-csvs+ '(144 1008 4032 8064)
  "The recovery tiers' CSVs: a re-arm spend's one input carries one (DEP-06 Phase 4 step 4); a
   claim's input 0 carries #xfffffffd or the reveal CSV (DEP-03).")
(defparameter +acquire-max-rounds+ 8 "Rounds followed back from a claim.")

(defun rearm-shaped-p (tx)
  "One input, one output, the input's nSequence a recovery tier's CSV."
  (and (= 1 (length (btx:tx-inputs tx))) (= 1 (length (btx:tx-outputs tx)))
       (member (btx:txin-sequence (elt (btx:tx-inputs tx) 0)) +rearm-tier-csvs+)
       t))

(defun judge-acquire (tx-fn vaults claim)
  "Whether the acquire naming CLAIM (txid, wire bytes) binds for the dispute that confiscated the
   vault VAULTS names: (txid vout) for every rung of its QuorumBegin's fee ladder (DEP-03), any of
   which may have confirmed.  TX-FN: txid -> (values tx confirmed-p), or NIL when unknown.
   :BINDS, :UNCONFIRMED (asked again later), :NOT-A-CLAIM (a re-arm spend), :NOT-THIS-LOTTERY.
   Second value: the round a binding claim closes (1 when it spends the confiscation's output 0,
   one more per re-arm spend followed back), else 0."
  (multiple-value-bind (ctx confirmed) (funcall tx-fn claim)
    (cond ((not (and ctx confirmed)) :unconfirmed)
          ((rearm-shaped-p ctx) :not-a-claim)
          ((zerop (length (btx:tx-inputs ctx))) :not-this-lottery)
          (t (let ((in (elt (btx:tx-inputs ctx) 0)))
               (loop with txid = (btx:txin-prev-hash in) and vout = (btx:txin-prev-index in)
                     for round from 1 to (1+ +acquire-max-rounds+)
                     do (unless (zerop vout) (return :not-this-lottery))
                        (multiple-value-bind (tx conf) (funcall tx-fn txid)
                          (unless tx (return :unconfirmed))
                          (when (some (lambda (i) (member (list (btx:txin-prev-hash i) (btx:txin-prev-index i))
                                                          vaults :test #'equalp))
                                      (coerce (btx:tx-inputs tx) 'list))
                            (return (values :binds round)))
                          (unless (and conf (rearm-shaped-p tx)) (return :not-this-lottery))
                          (let ((i (elt (btx:tx-inputs tx) 0)))
                            (setf txid (btx:txin-prev-hash i) vout (btx:txin-prev-index i))))
                     finally (return :not-this-lottery)))))))

;;; DEP-06 "What a yield must say" (yield-evidence-v9, ruled 2026-11-23): a DisputeYield names why
;;; its round ended, and a judge checks it from public state.  Shared vector
;;; inspect/vectors/yield_evidence.json (deposits-rust deposits-node judge_yield).

(defun lottery-tx-round (tx-fn vaults txid)
  "The round of the lottery the transaction TXID created for the dispute of VAULTS: 1 when it
   spends a vault, one more for each confirmed re-arm spend walked back (each spending output 0 of
   the previous).  (values :binds round), or :unconfirmed (a transaction unknown) or
   :not-this-lottery."
  (loop with cur = txid
        for round from 1 to (1+ +acquire-max-rounds+)
        do (multiple-value-bind (tx conf) (funcall tx-fn cur)
             (unless tx (return :unconfirmed))
             (when (some (lambda (i) (member (list (btx:txin-prev-hash i) (btx:txin-prev-index i)) vaults :test #'equalp))
                         (coerce (btx:tx-inputs tx) 'list))
               (return (values :binds round)))
             (unless (and conf (rearm-shaped-p tx)) (return :not-this-lottery))
             (let ((i (elt (btx:tx-inputs tx) 0)))
               (unless (zerop (btx:txin-prev-index i)) (return :not-this-lottery))
               (setf cur (btx:txin-prev-hash i))))
        finally (return :not-this-lottery)))

(defun judge-yield (&key ruleset reasons yield-height (arm-round 1) yielder targets pledges vaults tx-fn
                      dispute-reason last-valid-sequence quorum-begins participants ledger-id fork-enter-seq enters)
  "The verdict on a DisputeYield: (values VERDICT WHY), VERDICT :valid, :invalid or :pending (no
   verdict yet: asked again).  RULESET: the fork's (the fork point's).  REASONS: a plist of the
   yield's :lost-to / :reestablished / :excluded-by.  YIELD-HEIGHT: its signed block_height.
   ARM-ROUND: the yielder's latest arm's round before it.  YIELDER: its x-only key; TARGETS: the
   scriptPubKeys of the target_reserves it declared; PLEDGES: the collateral outpoints (txid vout) it
   declared.  VAULTS: the dispute's vault outpoints (JUDGE-ACQUIRE).  TX-FN: txid -> (values tx
   height-or-NIL), NIL when unknown.  DISPUTE-REASON / LAST-VALID-SEQUENCE: the fork's DisputeEnter.
   QUORUM-BEGINS: the operator chain's QuorumBegins as (content-hash seq spend-confirmed-p).
   PARTICIPANTS: the x-only keys of the lottery an :excluded-by names, as the judge rebuilt it.
   :SUPERSEDED-BY (ruled 2026-11-24): LEDGER-ID is the fork's ledger, FORK-ENTER-SEQ the sequence
   of the yielded fork's own DisputeEnter, ENTERS the DisputeEnters the judge holds, each a plist
   (:hash :by x-only :ledger :seq :punitive :on-ledger); ARM-ROUND 0 is a fork that never armed."
  (unless (lg:ruleset-rule-p ruleset :yield-evidence) (return-from judge-yield (values :valid :legacy)))
  (let ((named (loop for k in '(:lost-to :reestablished :excluded-by :superseded-by) when (getf reasons k) collect k)))
    (unless (= 1 (length named)) (return-from judge-yield (values :invalid :no-reason)))
    (let ((hash (getf reasons (first named)))
          (conf-fn (lambda (txid) (multiple-value-bind (tx height) (funcall tx-fn txid)
                                    (and tx (values tx (and height t)))))))
      (flet ((seen (txid)
               ;; the named transaction: confirmed, and at or below the yield's height
               (multiple-value-bind (tx height) (funcall tx-fn txid)
                 (cond ((not (and tx height)) (return-from judge-yield (values :pending :unconfirmed)))
                       ((> height yield-height) (return-from judge-yield (values :invalid :early)))
                       (t tx)))))
        (ecase (first named)
          (:lost-to
           (let ((tx (seen hash)))
             (multiple-value-bind (v round) (judge-acquire conf-fn vaults hash)
               (case v
                 (:unconfirmed (values :pending :unconfirmed))
                 ((:not-a-claim :not-this-lottery) (values :invalid v))
                 (t (cond ((< round arm-round) (values :invalid :earlier-round))
                          ((or (and (plusp (length (btx:tx-outputs tx)))
                                    (member (btx:txout-script (elt (btx:tx-outputs tx) 0)) targets :test #'equalp))
                               (and (> (length (btx:tx-inputs tx)) 1)
                                    (let ((i (elt (btx:tx-inputs tx) 1)))
                                      (member (list (btx:txin-prev-hash i) (btx:txin-prev-index i)) pledges :test #'equalp))))
                           (values :invalid :own-claim))
                          (t (values :valid :valid))))))))
          (:reestablished
           (let ((q (find hash quorum-begins :key #'first :test #'equalp)))
             (cond ((not (expiry-reason-p dispute-reason)) (values :invalid :not-expiry))
                   ((null q) (values :pending :unknown-quorum-begin))
                   ((<= (second q) (or last-valid-sequence -1)) (values :invalid :not-after-fork-point))
                   ((not (third q)) (values :pending :rotation-unconfirmed))
                   (t (values :valid :valid)))))
          (:superseded-by
           ;; DEP-06, reason 4: a fork that never armed, superseded by its disputant's own later
           ;; DisputeEnter of the same ledger that is on the ledger.
           (let ((e (find hash enters :key (lambda (e) (getf e :hash)) :test #'equalp)))
             (cond ((plusp arm-round) (values :invalid :armed))
                   ((null e) (values :pending :unknown-dispute-enter))
                   ((not (equalp (getf e :by) yielder)) (values :invalid :other-disputant))
                   ((not (equalp (getf e :ledger) ledger-id)) (values :invalid :other-ledger))
                   ((not (if (getf e :punitive) (>= (getf e :seq) fork-enter-seq) (> (getf e :seq) fork-enter-seq)))
                    (values :invalid :not-later))
                   ((not (getf e :on-ledger)) (values :invalid :not-on-ledger))
                   (t (values :valid :valid)))))
          (:excluded-by
           (seen hash)
           (multiple-value-bind (v round) (lottery-tx-round conf-fn vaults hash)
             (case v
               (:unconfirmed (values :pending :unconfirmed))
               (:not-this-lottery (values :invalid :not-this-lottery))
               (t (cond ((< round arm-round) (values :invalid :earlier-round))
                        ((member yielder participants :test #'equalp) (values :invalid :in-lottery))
                        (t (values :valid :valid))))))))))))

(defun fork-acquire-vaults (fork u)
  "The vault the DisputeAcquire U on FORK is judged against: every rung's vault outpoint of the
   latest QuorumBegin before it not authored by the acquirer (it rotates only after acquiring)."
  (let ((q (record-latest fork :quorum-begin :below (up:update-seq u)
                          :test (lambda (q) (not (equalp (up:update-operator-id q) (up:update-operator-id u)))))))
    (and q (let ((o (op:update-op q)))
             (mapcar (lambda (r) (list r (op:field o :new-outpoint-vout))) (fr:rotation-rungs o))))))

(defvar *acquire-verdicts* (make-hash-table :test #'equalp :synchronized t)
  "(claim-txid vault-rung-0) -> a final verdict: never re-read.")
(defvar *acquire-rounds* (make-hash-table :test #'equalp :synchronized t)
  "(claim-txid vault-rung-0) -> the round a binding claim closes (JUDGE-ACQUIRE's second value).")
(defvar *unconfirmed-claims* (make-hash-table :test #'equalp :synchronized t)
  "(claim-txid vault-rung-0) -> when we last judged it :UNCONFIRMED: asked again after a minute,
   not on every co-sign check (a phantom acquire's claim never confirms, and every check paid a
   getrawtransaction, which waits on the txindex).")

(defun acquire-round (fork)
  "The round FORK's binding DisputeAcquire closes, once judged (*ACQUIRE-ROUNDS*), else NIL."
  (multiple-value-bind (u o) (fork-op fork :dispute-acquire)
    (let* ((txid (and o (op:field o :claim-txid)))
           (vaults (and txid (fork-acquire-vaults fork u))))
      (and vaults (gethash (list txid (first (first vaults))) *acquire-rounds*)))))

(defun acquire-confirmed-p (node fork)
  "%ACQUIRE-CLAIM-BINDS-P, and for an acquire after its author's own yield (DEP-06 \"A claim after
   the claimant's own yield\") only when the claim binds the yielded arm's round or a later one
   (FORK-ACQUIRE-MIN-ROUND), which only the chain judgment can tell."
  (multiple-value-bind (u o) (fork-op fork :dispute-acquire)
    (and o (%acquire-claim-binds-p node fork)
         (let ((min (fork-acquire-min-round fork u)))
           (or (zerop min)
               (and (node-tx-fn node) (>= (or (acquire-round fork) 0) min)))))))

(defun %acquire-claim-binds-p (node fork)
  "FORK carries a DisputeAcquire that binds: its claim_txid confirmed AND spending its dispute's
   lottery outpoint (JUDGE-ACQUIRE).  With no TX-FN, the confirmation alone (TX-CONFS-FN); with
   neither, T: the acquire as published, the reading before the rule.  The round it closes is
   kept (ACQUIRE-ROUND)."
  (multiple-value-bind (u o) (fork-op fork :dispute-acquire)
    (and o
         (let ((txid (op:field o :claim-txid)))
           (cond
             ((node-tx-fn node)
              (let* ((vaults (and txid (fork-acquire-vaults fork u)))
                     (key (and vaults (list txid (first (first vaults))))))
                (when key
                  (let ((v (gethash key *acquire-verdicts*)))
                    (if v
                        (eq v :binds)
                        (let ((seen (gethash key *unconfirmed-claims*)))
                          (unless (and seen (< (- (get-universal-time) seen) 60))
                            (let ((v (or (ignore-errors
                                          (multiple-value-bind (v round)
                                              (judge-acquire (lambda (t1)
                                                               (multiple-value-bind (tx confs) (funcall (node-tx-fn node) t1)
                                                                 (and tx (values tx (and confs (plusp confs))))))
                                                             vaults txid)
                                            (when (eq v :binds) (setf (gethash key *acquire-rounds*) round))
                                            v))
                                         :unconfirmed)))
                              (if (eq v :unconfirmed)
                                  (progn (setf (gethash key *unconfirmed-claims*) (get-universal-time)) nil)
                                  (progn (remhash key *unconfirmed-claims*)
                                         (unless (eq v :binds)
                                           (log! node "DisputeAcquire on ~a: claim ~a does not bind (~(~a~))"
                                                 (subseq (record-id-hex fork) 0 8) (txid-hex txid) v))
                                         (setf (gethash key *acquire-verdicts*) v)
                                         (eq v :binds)))))))))))
             ((node-tx-confs-fn node)
              (let ((c (and txid (ignore-errors (funcall (node-tx-confs-fn node) txid)))))
                (and c (plusp c))))
             (t t))))))

(defun cosign-refusal (own members qb-seq disputes &key ruleset)
  "DEP-05 \"Deposed operator\": a reason string when member OWN of MEMBERS must refuse to
   co-sign the operator's chain, else NIL.  DISPUTES are plists (:by :last-valid :reason
   :acquired :acquire-confirmed), one per fork of the ledger.  Under RULESET strict-lottery-v8
   (the ledger's latest QuorumBegin's; ruled 2026-11-10) a rotation does not end a fraud dispute
   (a non-expiry dispute counts whatever its :last-valid), and an acquire moves custody only once
   its claim is confirmed.  Pinned by inspect/vectors/cosign_refusal.json, shared with
   deposits-rust."
  (let ((v8-rotation (lg:ruleset-rule-p ruleset :fraud-survives-rotation))
        (v8-acquire (lg:ruleset-rule-p ruleset :acquire-on-confirm)))
  (when (some (lambda (d) (and (getf d :acquired) (or (not v8-acquire) (getf d :acquire-confirmed)))) disputes)
    (return-from cosign-refusal "custody moved by DisputeAcquire"))
  (let ((freezing (remove-duplicates
                   (loop for d in disputes
                         when (and (or v8-rotation (>= (getf d :last-valid) qb-seq))
                                   (not (expiry-reason-p (getf d :reason)))
                                   (member (getf d :by) members :test #'equalp))
                           collect (getf d :by))
                   :test #'equalp)))
    (cond ((member own freezing :test #'equalp) "we disputed it; not extending the operator's chain")
          ((> (* 2 (length freezing)) (length members))
           (format nil "~a of ~a members disputed it" (length freezing) (length members)))))))

(defun check-not-deposed (node rec)
  "A member refuses to extend REC's base chain once its operator is deposed (DEP-05):
   custody moved by a DisputeAcquire, or we, or a majority of the quorum, disputed it
   at or after the latest QuorumBegin other than for expiry (under strict-lottery-v8: whenever,
   and an acquire only once its claim confirmed; see COSIGN-REFUSAL)."
  (let* ((qb-seq (or (let ((u (record-latest rec :quorum-begin))) (and u (up:update-seq u)))
                     0))
         (expiry (lg:ledger-quorum-expiry (record-ledger rec)))
         (disputes (loop for f in (forks-of node (record-id-hex rec))
                         for (u o) = (multiple-value-list (fork-op f :dispute-enter))
                         when o collect (list :by (record-fork-operator f)
                                              :last-valid (or (op:field o :last-valid-sequence) -1)
                                              ;; by its ground: a legacy generic label on an expiry
                                              ;; dispute stops freezing co-signing (DEP-05)
                                              :reason (if (dispute-enter-expiry-p u o expiry) "quorum_expired" (op:field o :reason))
                                              :acquired (and (fork-op f :dispute-acquire) t)
                                              :acquire-confirmed (acquire-confirmed-p node f))))
         (why (cosign-refusal (node-pubkey node)
                              (mapcar #'lg:member-pubkey (lg:ledger-quorum-members (record-ledger rec)))
                              qb-seq disputes :ruleset (lg:ledger-active-ruleset (record-ledger rec)))))
    (when why (fail "ledger disputed: ~a" why))))

(defun make-fork (node rec last-valid-seq operator33 &key (insert t))
  "A fork of REC's ledger from LAST-VALID-SEQ, operated by OPERATOR33: the
   truncated history replayed, quorum cleared (the reference does the same,
   so fork operations need no cosignatures).  INSERT NIL: not yet entered in our table."
  ;; The base's history is shared from the fork point (not copied), and its state comes from the
  ;; nearest checkpoint: replaying the whole chain per fork was seconds of CPU and a second copy
  ;; of every update list in memory (signet soak, 2026-10-28: 7 forks of a 190k-update ledger).
  (let* ((ledger (ledger-at rec last-valid-seq)))
    (setf (lg:ledger-quorum-at-fork ledger) (lg:ledger-quorum-members ledger)
          (lg:ledger-quorum-members ledger) '() (lg:ledger-next-quorum-members ledger) '())
    (let ((fork (make-view rec last-valid-seq :fork-p t :fork-operator operator33
                                              :owned-p (equalp operator33 (node-pubkey node)) :ledger ledger)))
    (when insert (setf (gethash (fork-key (record-id-hex rec) operator33) (node-ledgers node)) fork))
    fork)))

(defvar *received-broadcast* nil
  "The broadcast JSON text of the fraud proof being handled, so a DisputeEnter it grounds carries
   it exactly as received (DEP-02 TLV 345), embedding and causal chain included.")

(defun dispute-grounds-json (fraud-proof-hash fraud-proof)
  "DEP-03 §Grounded arms: the broadcast a punitive DisputeEnter carries as its grounds: the one being
   handled when its proof has FRAUD-PROOF-HASH, else FRAUD-PROOF (a proof we built) as we publish it."
  (or (and *received-broadcast* fraud-proof-hash
           (ignore-errors (equalp (fr:proof-hash (fr:json->broadcast (w:parse-json *received-broadcast*))) fraud-proof-hash))
           *received-broadcast*)
      (and fraud-proof (w:json (fr:broadcast->json fraud-proof)))))

(defun self-dispute-refusal (us accused33 operator33)
  "Why US must not dispute a ledger whose current operator is OPERATOR33 on a proof accusing
   ACCUSED33, or NIL when it may.  DEP-06 §Enter: the accused operator never signs a DisputeEnter
   on its own ledger.  Its key already signs the ledger's chain, so a fork it opened would put a
   second update under that key at the fork's first sequence: an equivocation proof against
   itself (signet soak, 2026-11-19: deposits-rust ref4 forked its own 5effb9e8 at 432509 on a
   QuorumExpired proof against it, then signed the main chain's 432510).  Vector
   self_dispute.json."
  (cond ((and accused33 (equalp accused33 us)) "the proof accuses us")
        ((and operator33 (equalp operator33 us)) "we operate the ledger")))

(defun enter-dispute (node rec last-valid-seq &key (reason "fraud") anchor-block-hash anchor-block-height fraud-proof-hash fraud-proof)
  "We are a quorum member of REC's ledger and have grounds: fork it and publish DisputeEnter.  A
   punitive one carries its proof (FRAUD-PROOF, or the broadcast being handled) as TLV 345, so an
   arm on our fork has grounds a cosigner can judge from the fork alone (DEP-03 §Grounded arms)."
  ;; Nothing left to dispute: the vault was confiscated, and that confiscation is the dispute's
  ;; end (its lottery, and any re-arm round, are what remain).  A restart forgot this: its forks
  ;; had yielded, so the ledger looked undisputed and expired, and the node opened a second
  ;; dispute on the dead vault (signet soak 2026-11-07, 751e6951).
  (when (reserves-confiscated-p node rec)
    (note-dispute node (record-id-hex rec) "not disputing (~a): its vault was confiscated" reason)
    (return-from enter-dispute nil))
  ;; DEP-06 §Enter, whatever the caller: never a fork of a ledger we operate (its current operator
  ;; key is ours) or on a proof against us.  Every caller already asks (not record-owned-p) and
  ;; quorum membership of its own replica; this is the one place they meet.
  (let ((why (self-dispute-refusal (node-pubkey node) (and fraud-proof (ignore-errors (hex->bytes (getf fraud-proof :accused))))
                                   (let ((l (record-ledger rec))) (and l (lg:ledger-operator-key l))))))
    (when why
      (note-dispute node (record-id-hex rec) "not disputing (~a): ~a; an operator never disputes its own ledger"
                    reason why)
      (return-from enter-dispute nil)))
  (let ((stale (find-fork node (record-id-hex rec) (node-pubkey node))))
    ;; re-entry: our later DisputeEnter supersedes it, which ends none of its pledges
    (when (and stale (not (fork-live-p node stale))) (retire-fork node stale :superseded t)))
  ;; A punitive dispute is never absorbed by an un-armed expiry fork (BLOCKING-FORK), and one key
  ;; holds one fork per ledger here, so the expiry dispute stands down for it: yielded (DEP-05
  ;; §"When a quorum_expired dispute ends" and DEP-06 §Race have an un-armed disputant yield) and
  ;; retired, and the punitive one forks at its own base.  Whatever the expiry dispute could take,
  ;; the punitive one takes too.
  (let ((expiry (find-fork node (record-id-hex rec) (node-pubkey node))))
    (when (and expiry (null anchor-block-height) (not (expiry-reason-p reason))
               (unarmed-expiry-fork-p expiry))
      ;; The punitive DisputeEnter is signed first, on a fork view not yet in our table (one key,
      ;; one fork per ledger here), so the yield can name it (superseded_by); then the expiry fork
      ;; yields and is retired, and the punitive one takes its place.
      (let* ((view (make-fork node rec last-valid-seq (node-pubkey node) :insert nil))
             (enter (new-update node view (punitive-enter-op last-valid-seq reason anchor-block-hash anchor-block-height
                                                             fraud-proof-hash fraud-proof))))
        (stand-down-for-punitive node expiry enter)
        (note-dispute node (record-id-hex rec) "un-armed expiry dispute yielded for a punitive one (~a)" reason)
        (retire-fork node expiry :superseded t)
        (setf (gethash (fork-key (record-id-hex rec) (node-pubkey node)) (node-ledgers node)) view)
        (commit-update node view enter)
        (drive-dispute-now node view)
        (return-from enter-dispute view))))
  ;; One DisputeEnter per dispute: a live fork that already entered keeps the grounds it entered
  ;; on (a second, groundless one would be its latest and lose them, DEP-03 §Grounded arms).
  (let ((live (find-fork node (record-id-hex rec) (node-pubkey node))))
    (when (and live (>= (dispute-fork-point-of live) last-valid-seq)
               (multiple-value-bind (u o) (fork-op live :dispute-enter)
                 (and u (or (null (dispute-grounds-json fraud-proof-hash fraud-proof))
                            (op:field o :fraud-proof)
                            (expiry-reason-p (op:field o :reason))))))
      (return-from enter-dispute live)))
  (let ((fork (or (find-fork node (record-id-hex rec) (node-pubkey node))
                  (make-fork node rec last-valid-seq (node-pubkey node)))))
    (commit-update node fork (new-update node fork (punitive-enter-op last-valid-seq reason anchor-block-hash anchor-block-height
                                                                      fraud-proof-hash fraud-proof)))
    (drive-dispute-now node fork)
    fork))

(defun punitive-enter-op (last-valid-seq reason anchor-block-hash anchor-block-height fraud-proof-hash fraud-proof)
  "The DisputeEnter operation ENTER-DISPUTE publishes."
  (%strip-nil-fields
   (list :type :dispute-enter :last-valid-sequence last-valid-seq :reason reason
         :anchor-block-hash anchor-block-hash :anchor-block-height anchor-block-height
         :fraud-proof-hash fraud-proof-hash
         :fraud-proof (dispute-grounds-json fraud-proof-hash fraud-proof))))

(defun dispute-lottery-n (rec &optional fork-point)
  "N disputants = the DEP-06 recovery voters."
  (length (recovery-voters rec fork-point)))

(defvar *recovery-voters-memo* (make-hash-table :test #'eq :weakness :key :synchronized t)
  "record -> ((fork-point . tip-seq) . voters): the walk decodes the whole chain (~180k updates on
   a soaked ledger) and every lottery and confiscation decision asks for it.")

(defun recovery-voters (rec &optional fork-point)
  "DEP-06 recovery voters: x-only keys, other than the original operator's (the author of
   sequence 0), of the members of the latest QuorumBegin the original operator authored at a
   sequence <= FORK-POINT (the dispute's lowest last_valid_sequence; NIL = every sequence)."
  (let* ((tip (let ((u (first (record-history rec)))) (and u (up:update-seq u))))
         (k (cons fork-point tip))
         (hit (gethash rec *recovery-voters-memo*)))
    (if (and hit tip (equal (car hit) k))
        (cdr hit)
        (let ((v (%recovery-voters rec fork-point)))
          (when tip (setf (gethash rec *recovery-voters-memo*) (cons k v)))
          v))))

(defun %recovery-voters (rec fork-point)
  (let* ((genesis (record-update-at rec 0))
         (operator (and genesis (up:update-operator-id genesis)))
         (qb (and operator
                  (find-if (lambda (u) (and (equalp (up:update-operator-id u) operator)
                                            (or (null fork-point) (<= (up:update-seq u) fork-point))))
                           (record-updates-of rec :quorum-begin))))
         (members (and qb (op:field (op:update-op qb) :quorum-members))))
    (remove-duplicates (mapcar #'up:x-only (remove operator members :test #'equalp)) :test #'equalp)))

(defun our-target-address (node)
  (cl-consensus.encoding:segwit-encode (rs:hrp-for (intern (string-upcase (node-network node)) :keyword)) 1
                                       (subseq (lot:key-path-spk (up:x-only (node-pubkey node))) 2)))

(defun fork-identity (fork)
  "The dispute FORK is: (values last-valid-sequence fork-point-hash) from our own DisputeEnter on
   it, the hash being that update's previous_hash, the chain hash of the update at the fork point.
   Read from the fork's own updates, so a restarted node has it before its base is loaded.  With
   no DisputeEnter, the fork point and zeros."
  (multiple-value-bind (u o) (fork-op fork :dispute-enter)
    (if u
        (values (or (op:field o :last-valid-sequence) (record-fork-seq fork)) (up:update-prev-hash u))
        (values (or (record-fork-seq fork) 0) (make-array 32 :element-type '(unsigned-byte 8) :initial-element 0)))))

(defun lottery-seed (node fork &optional (round 1))
  "Our lottery seed for the dispute FORK is, derived from the node key so a restarted node
   recovers the preimage it committed to.  DEP-06: fresh per dispute and per round.  It binds the
   fork's identity (FORK-IDENTITY); the v1 seed bound only the ledger, so every dispute of one
   ledger reused one preimage, and a preimage revealed in one dispute was known before the next
   one's arms closed."
  (multiple-value-bind (lvs point) (fork-identity fork)
    (fork-lottery-seed (node-priv node) (record-id-hex fork) lvs point round)))

(defun fork-lottery-seed (priv id-hex lvs point round)
  "sha256(\"deposits/cl/lottery-seed/v2\" || PRIV || ledger id || LVS (8 BE) || POINT || ROUND (4 BE))."
  (let ((out (make-array 32 :element-type '(unsigned-byte 8))))
    (natrium:with-sha256 (c)
      (natrium:sha256-update c (ascii->bytes "deposits/cl/lottery-seed/v2"))
      (natrium:sha256-update c priv)          ; streamed: never concatenated
      (natrium:sha256-update c (hex->bytes id-hex))
      (natrium:sha256-update c (int->be lvs 8))
      (natrium:sha256-update c point)
      (natrium:sha256-update c (int->be round 4))
      (natrium:sha256-final-into c out))
    out))

(defun lottery-seed-v1 (node id-hex &optional (round 1))
  "The seed builds before the fork-bound LOTTERY-SEED armed with: only to recover, after a restart,
   the preimage of a fork armed by such a build.  Never used to arm."
  (let ((out (make-array 32 :element-type '(unsigned-byte 8))))
    (natrium:with-sha256 (c)
      (natrium:sha256-update c (ascii->bytes "deposits/cl/lottery-seed/v1"))
      (natrium:sha256-update c (node-priv node))
      (natrium:sha256-update c (hex->bytes id-hex))
      (when (> round 1) (natrium:sha256-update c (ascii->bytes (format nil "/rearm-round/~d" round))))
      (natrium:sha256-final-into c out))
    out))

(defparameter *pledge-height-wait-seconds* 15)

(defun await-pledge-height (node replacement)
  "An arm commits to (height node) as its armed block, and the DEP-03 cut excludes a
   pledge confirmed after the highest such height.  The node's height is cached, so an
   arm right after its pledge's block could name a height before it and exclude itself
   (with every armer doing so, nobody is a participant).  Wait until our height reaches
   the pledge's confirmation; refuse rather than arm with a pledge the cut would drop."
  (let ((pledge-fn (node-pledge-fn node)))
    (when pledge-fn
      (destructuring-bind (txid vout sats) replacement
        (declare (ignore sats))
        (let ((created (getf (funcall pledge-fn txid vout (1+ (height node))) :created))
              (deadline (+ (get-universal-time) *pledge-height-wait-seconds*)))
          (unless created (fail "pledge ~a:~a is not confirmed" (txid-hex txid) vout))
          (loop until (>= (height node) created)
                do (when (> (get-universal-time) deadline)
                     (fail "pledge confirmed at ~a, our chain height is still ~a" created (height node)))
                   (own:pause-for 0.5)))))))

(defun record-obligations (node fork)
  "DEP-06: if the disputed ledger had an unresolved DormancyAccept at the fork point and its source
   consumed the notice, append an ObligationRecord (the source's notice and QuorumBegin) to FORK."
  (let* ((id (record-id-hex fork)) (base (find-record node id)) (lvs (dispute-last-valid-seq node id))
         (l (and base lvs (ledger-at base lvs)))
         (a (and l (lg:ledger-dormancy-accept l))))
    (when (and a (not (getf a :resolved)) (getf a :source))
      (multiple-value-bind (nu qu) (migration-source-updates node a (bytes->hex (getf a :source)))
        (when qu
          (commit-update node fork (new-update node fork (list :type :obligation-record
                                                               :source-notice-update (up:encode-update nu)
                                                               :source-qb-update (up:encode-update qu))))
          (log! node "recorded the dangling migration of ~a on our fork" (subseq id 0 8)))))
    ;; DEP-06: every proven-uncredited payment we verified against this ledger, and any the
    ;; relays hold (one broadcast after we entered the dispute, or while we were down)
    (when base
      (dolist (e (ignore-errors (bus:bus-fetch (node-bus node) (flt:make-filter :kinds (list w:+kind-fraud-proof+)
                                                                                :tags (list (cons "d" (list (subseq id 0 16))))))))
        (ignore-errors (note-obligation-proof node base (fr:json->broadcast (w:parse-json (ev:event-content e)))))))
    (dolist (json (gethash id (node-obligation-proofs node)))
      (handler-case
          (progn (commit-update node fork (new-update node fork (list :type :obligation-record :uncredited-proof (ascii->bytes json))))
                 (log! node "recorded an uncredited payment of ~a on our fork" (subseq id 0 8)))
        (error (e) (log! node "uncredited payment not recorded on ~a: ~a" (subseq id 0 8) e))))))

(defun phantom-acquire (node rec)
  "Red team (DEP-06 §Phase 4, strict-lottery-v8: an acquire binds once its claim confirms): enter
   and arm a dispute on REC's ledger if we have none, then append a DisputeAcquire to our fork for
   a claim that never reaches the chain (a random claim_txid).  Members must not read custody as
   moved (signet soak, 2026-11-07: cld7's phantom acquire on 751e6951).  Returns the claim txid."
  (let* ((id (record-id-hex rec))
         (fork (or (find-fork node id (node-pubkey node))
                   (progn (enter-dispute node rec (lg:ledger-sequence (record-ledger rec)) :reason "equivocation")
                          (find-fork node id (node-pubkey node)))
                   (fail "no fork of ~a after DisputeEnter" (subseq id 0 8))))
         (claim (let ((b (make-array 32 :element-type '(unsigned-byte 8))))
                  (dotimes (i 32 b) (setf (aref b i) (random 256))))))
    (unless (fork-op fork :dispute-armed) (arm-dispute node fork))
    (commit-update node fork (new-update node fork (list :type :dispute-acquire :new-custodian (node-pubkey node)
                                                         :claim-txid claim :new-reserves-address "")))
    claim))

(defun arm-dispute (node fork &key seed replacement (round 1))
  "Commit to our lottery preimage on our fork.  REPLACEMENT is (txid vout sats) or NIL.  ROUND > 1:
   an arm for that re-arm round (DEP-06 Phase 4), with its own preimage."
  (let ((preimage (lot:derive-preimage (or seed (lottery-seed node fork round)))))
    (when replacement (await-pledge-height node replacement))
    ;; DEP-06 §Confiscation obligations: record a dangling migration before arming.
    (handler-case (record-obligations node fork)
      (error (e) (log! node "obligation record on ~a: ~a" (subseq (record-id-hex fork) 0 8) e)))
    (setf (record-preimage fork) preimage)
    (commit-update node fork (new-update node fork (%strip-nil-fields
                                                    (list :type :dispute-armed :armed-block (height node)
                                                          :commitment-hash (lot:commitment-of preimage)
                                                          :target-reserves (our-target-address node)
                                                          :replacement-collateral-txid (first replacement)
                                                          :replacement-collateral-vout (second replacement)
                                                          :replacement-collateral-amount (third replacement)
                                                          :rearm-round (and (> round 1) round)))))
    ;; ADVERSARY :spend-pledge — arm, then spend the pledged coin back to ourselves.
    ;; Under the old rule every cosigner then refused the confiscation: one armer
    ;; vetoed the dispute.  DEP-03 now excludes it instead (redteam/attack-veto-pledge.sh).
    (when (and replacement (getf (node-adversary node) :spend-pledge))
      (handler-case
          (let ((txid (consolidate-utxos node (list (list :txid (first replacement) :vout (second replacement) :sats (third replacement))))))
            (log! node "adversary: spent our pledge ~a:~a in ~a" (txid-hex (first replacement)) (second replacement) (txid-hex txid)))
        (error (e) (log! node "adversary: could not spend our pledge: ~a" e))))
    preimage))

(defun backdated-rearm (node id-hex height &key replacement)
  "Testing only (redteam/check-backdated-arm.sh; docs/ADVERSARIAL.md §Rule inverters, unruled): a
   round-1 re-arm on our fork of ID-HEX signed at block HEIGHT (clamped, as every update, to our
   fork's last height), published now.  The same preimage, so the same commitment, as the fold
   requires of a same-round re-arm; REPLACEMENT (txid vout sats) is the pledge it declares, else a
   fresh one.  The update it published."
  (let* ((fork (or (find-fork node id-hex (node-pubkey node)) (fail "no fork of ~a" (subseq id-hex 0 8))))
         (preimage (or (record-preimage fork) (lot:derive-preimage (lottery-seed node fork 1))))
         (p (or replacement (pledge-collateral node id-hex) (fail "no collateral to pledge"))))
    (setf (record-preimage fork) preimage)
    (let ((u (new-update node fork (%strip-nil-fields
                                    (list :type :dispute-armed :armed-block height
                                          :commitment-hash (lot:commitment-of preimage)
                                          :target-reserves (our-target-address node)
                                          :replacement-collateral-txid (first p)
                                          :replacement-collateral-vout (second p)
                                          :replacement-collateral-amount (third p)))
                         :height height)))
      (commit-update node fork u)
      (log! node "ADVERSARY: backdated round-1 re-arm of ~a at height ~a (tip ~a), pledge ~a:~a"
            (subseq id-hex 0 8) (up:update-block-height u) (height node) (txid-hex (first p)) (second p))
      u)))

;;; DEP-03 §"The dispute": which DisputeEnters are this dispute.  A disputant may hold an older
;;; DisputeEnter on a vault the ledger has since rotated away (a dispute gone dormant, or one
;;; entered on a proof that did not verify); it is no part of the current one.  Q is the operator's
;;; latest QuorumBegin at or below the highest last_valid_sequence any DisputeEnter names (the vault
;;; being confiscated); a disputant counts only through its latest DisputeEnter at or above Q, and
;;; only its updates past that fork point.  The builder, the cosigner, the watch and the verifier all
;;; judge through this (DISPUTE-FORKS on a node's records, DISPUTE-SCOPE on a list of updates), so
;;; they cannot disagree on the fork point, the arms, the shape or the obligations.  (Signet soak,
;;; 2026-11-02: a stale DisputeEnter moved the watch's fork point, its anchor missed the
;;; confiscation, and its challenge lapsed into contagion against three honest members.)
;;; Mirrors deposits-rust's rotation_order::dispute_scope; vector inspect/vectors/dispute_scope.txt.

(defun dispute-scope-q (base-rec top-lvs)
  "The sequence of BASE-REC's latest QuorumBegin at or below TOP-LVS, or 0."
  (let ((qb (and base-rec top-lvs (record-latest base-rec :quorum-begin :below (1+ top-lvs)))))
    (if qb (up:update-seq qb) 0)))

(defun fork-enters (node id-hex fork)
  "FORK's own DisputeEnters that may count in ID-HEX's dispute, newest first: all of them, and
   once the confiscation has confirmed in block C (CONFISCATION-HEIGHT) those signed at or below C.
   DEP-03 §When the set is final: a DisputeEnter above C takes no part, as an arm above C does
   not; it names no fork point, its grounds convict nobody and it admits its author to no later
   round (regtest 12bc96d2, 2026-11-21: a contagion proof re-sent after the confiscation at 23996
   was entered on at 34763, and its proof convicted c30c1b29, the only armer of round 2)."
  (let ((c (confiscation-height node id-hex)))
    (remove-if-not (lambda (u) (and (equalp (up:update-operator-id u) (record-fork-operator fork))
                                    (or (null c) (<= (up:update-block-height u) c))))
                   (fork-own-updates fork :dispute-enter))))

(defun dispute-top (node id-hex)
  "The highest last_valid_sequence of any DisputeEnter that may count in ID-HEX's dispute (every
   fork's FORK-ENTERS, not only each one's latest), or NIL with none."
  (let ((top nil))
    (dolist (f (forks-of node id-hex) top)
      (dolist (u (fork-enters node id-hex f))
        (let ((l (op:field (op:update-op u) :last-valid-sequence)))
          (when (and l (or (null top) (> l top))) (setf top l)))))))

(defun dispute-enter-of (node id-hex fork)
  "FORK's DisputeEnter that counts in ID-HEX's dispute, (values update op) or NIL: its latest among
   FORK-ENTERS at or above Q (DEP-03 §\"The dispute\": each disputant counts through its latest
   DisputeEnter at or above Q).  With none at or above Q, its latest, which DISPUTE-FORKS then
   finds stale.  A repeat entry (one in time, a later one at another fork point) is in the dispute
   through the one the rule counts: a later entry below Q does not take the fork out, and one
   above C takes no part at all.  Mirrors deposits-rust's rotation_order::dispute_scope_final;
   vector rearm_round_agree.json, late_enter."
  (let* ((es (fork-enters node id-hex fork))
         ;; only a repeat entry needs Q
         (q (and (cdr es) (dispute-scope-q (let ((r (find-record node id-hex))) (and r (not (record-fork-p r)) r))
                                           (dispute-top node id-hex))))
         (u (or (and q (find-if (lambda (u) (>= (or (op:field (op:update-op u) :last-valid-sequence) -1) q)) es))
                (first es))))
    (and u (values u (op:update-op u)))))

(defun dispute-forks (node id-hex)
  "The forks of ID-HEX that are its current dispute (see above), each through DISPUTE-ENTER-OF.
   A view built under the reading before this rule (DISPUTE-VIEW :every-enter) takes every fork."
  (when (gethash :every-enter (node-dispute-notes node)) (return-from dispute-forks (forks-of node id-hex)))
  (let* ((forks (forks-of node id-hex))
         (lvs-of (mapcar (lambda (f) (multiple-value-bind (u o) (dispute-enter-of node id-hex f)
                                       (and u (op:field o :last-valid-sequence))))
                         forks))
         (top (dispute-top node id-hex)))
    (if (null top)
        (if (confiscation-height node id-hex)
            (loop for f in forks for l in lvs-of when l collect f)
            forks)
        (let ((q (dispute-scope-q (let ((r (find-record node id-hex))) (and r (not (record-fork-p r)) r)) top)))
          (loop for f in forks for l in lvs-of when (and l (>= l q)) collect f)))))

(defun rearm-fork-out-of-dispute (node id-hex fork)
  "Why FORK may not arm a later re-arm round of ID-HEX (DEP-06 Phase 4 step 2), or NIL.  A
   disputant takes part only through a DisputeEnter at or above Q (DEP-03 §\"The dispute\"); a
   fork whose latest DisputeEnter is below it (an old dispute of a vault since rotated, even one
   it yielded) is no part of the current dispute, so an arm on it counts in no round, against no
   bound and in no manifest.  Vector rearm_round_agree.json (in_dispute / out_of_dispute)."
  (cond ((null fork) "we hold no fork")
        ((member fork (dispute-forks node id-hex)) nil)
        (t (let ((r (find-record node id-hex)))
             (format nil "our fork entered at ~a, below the dispute's QuorumBegin ~a (DEP-03 \"The dispute\")"
                     (dispute-fork-point node id-hex fork)
                     (dispute-scope-q (and r (not (record-fork-p r)) r)
                                      (loop for f in (forks-of node id-hex) maximize (dispute-fork-point node id-hex f))))))))

(defun dispute-fork-point-of (fork)
  "The last_valid_sequence of FORK's latest DisputeEnter, -1 with none.  Our own next DisputeEnter
   is judged against this (ENTER-DISPUTE); what FORK takes part in is DISPUTE-FORK-POINT's."
  (multiple-value-bind (u o) (fork-op fork :dispute-enter)
    (if u (op:field o :last-valid-sequence) -1)))

(defun dispute-fork-point (node id-hex fork)
  "The last_valid_sequence of FORK's DisputeEnter that counts in ID-HEX's dispute (DISPUTE-ENTER-OF:
   once the confiscation confirmed in block C, its latest at or below C), -1 with none.  Its updates
   at or below it belong to an earlier dispute (DEP-03 §\"The dispute\").  A fork that entered in
   time and again above C (a repeat entry naming a later fork point) is in the dispute through the
   first: the later one must not drop the updates between the two.  Vector rearm_round_agree.json,
   late_enter (repeat_enter)."
  (multiple-value-bind (u o) (dispute-enter-of node id-hex fork)
    (if u (op:field o :last-valid-sequence) -1)))

(defun dispute-fork-updates (node id-hex fork type)
  "FORK's own updates of TYPE in ID-HEX's current dispute: after its counted DisputeEnter's fork
   point (DISPUTE-FORK-POINT)."
  (let ((lvs (dispute-fork-point node id-hex fork)))
    (remove-if-not (lambda (u) (> (up:update-seq u) lvs)) (fork-own-updates fork type))))

(defun %op-type (u) (ignore-errors (op:update-type u)))

(defun fork-from (updates enter)
  "The updates on the fork ENTER opens: its author's non-DisputeEnter updates in UPDATES chained
   from it (each previous_hash the CHAIN-HASH of one already on it), in sequence order: one pass,
   since a chain only climbs."
  (let* ((by (up:update-operator-id enter))
         ;; copied: REMOVE-IF-NOT may share UPDATES' tail, and SORT is destructive
         (mine (sort (copy-list (remove-if-not (lambda (u) (and (equalp (up:update-operator-id u) by) (not (eq u enter))
                                                                (> (up:update-seq u) (up:update-seq enter))))
                                               updates))
                     #'< :key #'up:update-seq))
         (hashes (make-hash-table :test #'equalp))
         (out '()))
    (setf (gethash (up:chain-hash enter) hashes) t)
    (dolist (u mine (nreverse out))
      (when (and (gethash (up:update-prev-hash u) hashes) (not (eq (%op-type u) :dispute-enter)))
        (setf (gethash (up:chain-hash u) hashes) t)
        (push u out)))))

(defun reentry-yield-verdict (updates enter yield &key chain)
  "DEP-06 \"What a yield must say\": the verdict a yield builder's own judge gives YIELD, the
   DisputeYield it would sign on the fork ENTER opens (YIELD-SELF-CHECK): :VALID (sign),
   :INVALID (never signed) or :PENDING (wait).  No other member reads a yield (\"A yield binds
   only its author\", ruled 2026-11-24).  CHAIN: txid -> the height of the block confirming it, or NIL while unconfirmed;
   NIL itself = no chain view, the chain reasons as published.  No reason: valid (before
   yield-evidence-v9; the v9 fold refuses one); more than one: invalid.  :SUPERSEDED-BY is judged
   from UPDATES alone: invalid if the fork armed before the yield; pending until the named
   DisputeEnter is held; invalid if another disputant's or ledger's, or not later (a punitive one
   at or after the fork's own entry, any other strictly after); pending until the operator's
   update it forks from is held; invalid if it does not chain onto it.  :LOST-TO / :EXCLUDED-BY:
   pending until the transaction confirms, invalid if above the yield's height.  :REESTABLISHED:
   an expiry dispute, and a QuorumBegin of the operator's after the fork point, pending until
   held and its rotation confirmed.  Mirrors deposits-rust's rotation_order::reentry_yield_verdict."
  (let* ((eo (op:update-op enter)) (yo (op:update-op yield))
         (lvs (or (op:field eo :last-valid-sequence) -1))
         (named (loop for k in '(:lost-to :reestablished :excluded-by :superseded-by) when (op:field yo k) collect k))
         (origin (let ((o (find-if (lambda (u) (zerop (up:update-seq u))) updates))) (and o (up:update-operator-id o)))))
    (cond ((null named) :valid)
          ((rest named) :invalid)
          (t (let ((v (op:field yo (first named))))
               (flet ((conf (txid) (if chain (list (funcall chain txid)) nil)))
                 (ecase (first named)
                   ((:lost-to :excluded-by)
                    (let ((c (conf v)))
                      (cond ((null c) :valid)
                            ((null (first c)) :pending)
                            ((> (first c) (up:update-block-height yield)) :invalid)
                            (t :valid))))
                   (:reestablished
                    (let ((q (find-if (lambda (u) (and (equalp (up:update-operator-id u) origin)
                                                       (equalp (up:content-hash u) v)
                                                       (eq (%op-type u) :quorum-begin)))
                                      updates)))
                      (cond ((not (expiry-reason-p (op:field eo :reason))) :invalid)
                            ((null q) :pending)
                            ((<= (up:update-seq q) lvs) :invalid)
                            ((let ((c (conf (op:field (op:update-op q) :new-outpoint-txid)))) (and c (null (first c)))) :pending)
                            (t :valid))))
                   (:superseded-by
                    (let ((n (find-if (lambda (u) (and (equalp (up:content-hash u) v) (eq (%op-type u) :dispute-enter))) updates)))
                      (cond ((some (lambda (u) (and (< (up:update-seq u) (up:update-seq yield)) (eq (%op-type u) :dispute-armed)))
                                   (fork-from updates enter))
                             :invalid)
                            ((null n) :pending)
                            ((not (equalp (up:update-operator-id n) (up:update-operator-id yield))) :invalid)
                            ((not (equalp (up:update-ledger-id n) (up:update-ledger-id enter))) :invalid)
                            ((not (if (expiry-reason-p (op:field (op:update-op n) :reason))
                                      (> (up:update-seq n) (up:update-seq enter))
                                      (>= (up:update-seq n) (up:update-seq enter))))
                             :invalid)
                            (t (let* ((nl (op:field (op:update-op n) :last-valid-sequence))
                                      (base (find-if (lambda (u) (and (equalp (up:update-operator-id u) origin) (eql (up:update-seq u) nl)))
                                                     updates)))
                                 (cond ((null base) :pending)
                                       ((not (equalp (up:chain-hash base) (up:update-prev-hash n))) :invalid)
                                       (t :valid))))))))))))))

(defun dispute-scope (updates)
  "UPDATES (a disputed ledger's, every operator's) reduced to its current dispute (see above), a
   function of the SET of UPDATES: each disputant takes part through its counted DisputeEnter
   (COUNTED-ENTRY: canonical order, latest counts, an acquired fork never superseded) and the
   updates on the chain it is on, from that chain's first entry (CHAIN-ROOT, CHAIN-FROM), past its
   fork point; superseding ends no pledge
   (DEP-03 \"When a pledge is live\").  As deposits-rust's rotation_order::dispute_scope.  Vector
   inspect/vectors/enter_after_yield.txt."
  (let* ((open (find-if (lambda (u) (zerop (up:update-seq u))) updates))
         (origin (and open (up:update-operator-id open)))
         (enters (and origin
                      (remove-if-not (lambda (u) (and (not (equalp (up:update-operator-id u) origin))
                                                      (eq (%op-type u) :dispute-enter)))
                                     updates))))
    (if (null enters)
        updates
        (let* ((top (reduce #'max enters :key (lambda (u) (op:field (op:update-op u) :last-valid-sequence))))
               (q (or (loop for u in updates
                            when (and (equalp (up:update-operator-id u) origin) (<= (up:update-seq u) top)
                                      (eq (%op-type u) :quorum-begin))
                              maximize (up:update-seq u))
                      0))
               (by (make-hash-table :test #'equalp))
               (keep (make-hash-table :test #'eq)))
          (dolist (e enters)
            (when (>= (op:field (op:update-op e) :last-valid-sequence) q)
              (push e (gethash (up:update-operator-id e) by))))
          (loop for es being the hash-values of by
                for cur = (counted-entry es (lambda (e) (fork-acquired-p updates e)))
                for lvs = (op:field (op:update-op cur) :last-valid-sequence)
                do (dolist (u updates)
                     (when (and (equalp (up:update-operator-id u) (up:update-operator-id cur))
                                (equalp (up:content-hash u) (up:content-hash cur)) (> (up:update-seq u) lvs))
                       (setf (gethash u keep) t)))
                   ;; the chain CUR is on, from its first entry (a continuation shares its fork's)
                   (let ((mine (remove-if-not (lambda (u) (equalp (up:update-operator-id u) (up:update-operator-id cur))) updates)))
                     (dolist (u (chain-from mine (chain-root mine cur)))
                       (when (and (> (up:update-seq u) lvs) (not (eq (%op-type u) :dispute-enter)))
                         (setf (gethash u keep) t)))))
          (remove-if-not (lambda (u) (or (equalp (up:update-operator-id u) origin) (gethash u keep))) updates)))))

(defun node-chain-view (node)
  "NODE's chain view for REENTRY-YIELD-VERDICT: txid -> the height of the block confirming it,
   NIL while unconfirmed (or unknown); NIL with no TX-FN or TX-CONFS-FN (as published)."
  (let ((tx-fn (node-tx-fn node)) (confs-fn (node-tx-confs-fn node)))
    (when (or tx-fn confs-fn)
      (lambda (txid)
        (let ((c (ignore-errors (if tx-fn (nth-value 1 (funcall tx-fn txid)) (funcall confs-fn txid))))
              (tip (funcall (node-height-fn node))))
          (and c tip (plusp c) (1+ (- tip c))))))))

(defun armers-of (node id-hex &key until (round 1))
  "Each armer's latest DisputeArmed (highest sequence) on any fork of the ledger:
   (pubkey33 commitment target collateral arm-height seq), ARM-HEIGHT being the
   update's signed-header block height.  A member may re-arm to add the replacement
   collateral its first arm lacked (DEP-03; the reference does after losing a
   scantxoutset race); counting every arm listed it twice.  UNTIL: the block the
   confiscation confirmed in; arms above it do not count (DEP-03)."
  (let ((arms (make-hash-table :test #'equalp)))
    (dolist (a (%all-arms node id-hex))
      (unless (and until (> (fifth a) until)) (push a (gethash (first a) arms))))
    ;; Only the first +max-arms+ arms (by sequence) count, so a griefer cannot keep moving E.  The
    ;; bound spans every re-arm round (DEP-06 Phase 4); ROUND picks that round's latest counted arm.
    (loop for list being the hash-values of arms
          for counted = (subseq (sort (copy-list list) #'< :key #'sixth) 0 (min +max-arms+ (length list)))
          for mine = (remove-if-not (lambda (a) (eql (seventh a) round)) counted)
          when mine collect (car (last mine)))))

(defun pick-round-arms (arms round opens closes)
  "DEP-06 Phase 4 step 2: of ARMS (%all-arms entries), each armer's arm for re-arm round ROUND in
   the window (OPENS, CLOSES]: the latest (by sequence) of its first +max-arms+ arms that is of
   ROUND and whose signed block_height lies inside the window.  Arms outside the window, or of
   other rounds, still count against the bound but never displace an in-window arm: taking the
   latest counted arm and filtering it by the window after let a later same-round arm signed past
   the close withdraw its armer from a closed window, or empty the cut (2026-11-15).  Pure;
   vector rearm_window_arms.json."
  (let ((by (make-hash-table :test #'equalp)))
    (dolist (a arms) (push a (gethash (first a) by)))
    (loop for list being the hash-values of by
          for counted = (subseq (sort (copy-list list) #'< :key #'sixth) 0 (min +max-arms+ (length list)))
          for inside = (remove-if-not (lambda (a) (and (eql (seventh a) round) (< opens (fifth a)) (<= (fifth a) closes))) counted)
          when inside collect (car (last inside)))))

(defun inverted-round-arms (arms round opens closes)
  "ADVERSARY :invert-arm-selection (testing only, a rule inverter): the rule PICK-ROUND-ARMS
   replaced, each armer's latest counted arm of ROUND, then kept only if inside (OPENS, CLOSES]."
  (let ((by (make-hash-table :test #'equalp)))
    (dolist (a arms) (push a (gethash (first a) by)))
    (loop for list being the hash-values of by
          for counted = (subseq (sort (copy-list list) #'< :key #'sixth) 0 (min +max-arms+ (length list)))
          for mine = (car (last (remove-if-not (lambda (a) (eql (seventh a) round)) counted)))
          when (and mine (< opens (fifth mine)) (<= (fifth mine) closes)) collect mine)))

;;; DEP-06 §Arm manifests (strict-lottery-v8; ruled 2026-11-15, option A).  A fork's DisputeArmed is
;;; self-signed, so an armer can publish an arm dated into a window after that window's spend was
;;; signed or confirmed.  Judges therefore never re-derive "each armer's latest arm" for a spend that
;;; exists: the spend's signers publish the arms they used, and the spend is honest iff that set of
;;; arms is valid and rebuilds it byte for byte.

(defun %armer-label (armer) (if (stringp armer) armer (bytes->hex (subseq armer 0 (min 4 (length armer))))))

(defun manifest-arms (arms manifest round opens closes)
  "The arms MANIFEST names, as ARMS entries (%ALL-ARMS shape: first the armer, fifth the signed
   height, sixth the sequence, seventh the round), or (values NIL reason) when the manifest is not
   a valid arm set for ROUND's window (OPENS, CLOSES] (round 1: OPENS -1, CLOSES the confiscation
   block).  MANIFEST is a list of (armer seq).  Valid: every entry names an arm we hold, no armer
   twice, each arm among its armer's first +MAX-ARMS+ (by sequence, every round), of ROUND, and
   signed inside the window.  Omitting an armer is not a fault (signing policy)."
  (let ((by (make-hash-table :test #'equalp)) (out '()) (seen '()))
    (dolist (a arms) (push a (gethash (first a) by)))
    (when (null manifest) (return-from manifest-arms (values nil "empty manifest")))
    (dolist (m manifest (values (sort out (lambda (x y) (if (stringp x) (string< x y) (bytes< x y))) :key #'first) nil))
      (destructuring-bind (armer seq) m
        (when (member armer seen :test #'equalp)
          (return-from manifest-arms (values nil (format nil "armer ~a named twice" (%armer-label armer)))))
        (push armer seen)
        (let* ((counted (let ((l (sort (copy-list (gethash armer by)) #'< :key #'sixth)))
                          (subseq l 0 (min +max-arms+ (length l)))))
               (a (find seq (gethash armer by) :key #'sixth)))
          (cond ((null a) (return-from manifest-arms (values nil (format nil "no arm ~a/~a" (%armer-label armer) seq))))
                ((not (member a counted)) (return-from manifest-arms (values nil (format nil "arm ~a/~a is past the ~a-arm bound" (%armer-label armer) seq +max-arms+))))
                ((not (eql (seventh a) round)) (return-from manifest-arms (values nil (format nil "arm ~a/~a is of round ~a" (%armer-label armer) seq (seventh a)))))
                ((not (and (< opens (fifth a)) (<= (fifth a) closes)))
                 (return-from manifest-arms (values nil (format nil "arm ~a/~a signed at ~a, outside (~a, ~a]" (%armer-label armer) seq (fifth a) opens closes))))
                (t (push a out))))))))

(defun round-arms (node arms round opens closes)
  (if (and node (getf (node-adversary node) :invert-arm-selection))
      (inverted-round-arms arms round opens closes)
      (pick-round-arms arms round opens closes)))

(defun %all-arms (node id-hex)
  "Every DisputeArmed on every fork of the ledger, newest first within each fork."
  (loop for fork in (dispute-forks node id-hex)
        ;; A fork's arms are its operator's own updates; the prefix it inherited from the base
        ;; (~180k updates on a soaked ledger) is the base operator's, and decoding it on every
        ;; lottery and confiscation decision saturated the node (signet soak, 2026-10-27).
        for lvs = (multiple-value-bind (u o) (dispute-enter-of node id-hex fork)
                    (if u (op:field o :last-valid-sequence) -1))
        append (loop for u in (if (record-fork-base fork) (gethash :dispute-armed (record-index fork)) (record-updates-of fork :dispute-armed))
                     for o = (and (equalp (up:update-operator-id u) (record-fork-operator fork))
                                  (> (up:update-seq u) lvs)   ; an arm of an earlier dispute on this fork does not count
                                  (op:update-op u))
                     when o
                       collect (list (up:update-operator-id u) (op:field o :commitment-hash) (op:field o :target-reserves)
                                     (and (op:field o :replacement-collateral-txid)
                                          (list (op:field o :replacement-collateral-txid) (op:field o :replacement-collateral-vout)
                                                (op:field o :replacement-collateral-amount)))
                                     (up:update-block-height u) (up:update-seq u)
                                     (or (op:field o :rearm-round) 1)))))

;;; DEP-03 §"Replacement collateral declaration": who is in the lottery is a
;;; deterministic function of the ledger and the confirmed chain.  E is the highest
;;; signed-header height among the armers' latest arms; a pledge counts if it is
;;; large enough, confirmed by E, unspent through E and holds what it declares.  A
;;; failing armer is excluded and never stalls the dispute: one armer pledging a
;;; spent coin used to make every cosigner refuse, forever.

(defparameter *claim-fee-floor-sats* 5000
  "DEP-03 claim_fee_floor when the governing QuorumBegin records no reference feerate.")

(defun dispute-last-valid-seq (node id-hex)
  "The dispute's fork point: the lowest last_valid_sequence any fork of the current dispute
   (DISPUTE-FORKS) names in its DisputeEnter."
  (loop for f in (dispute-forks node id-hex)
        for (u o) = (multiple-value-list (dispute-enter-of node id-hex f))
        when u minimize (op:field o :last-valid-sequence)))

(defun fork-point-anchor (update)
  "DEP-03 §On-Chain State Anchor: a confiscation's anchor from the update at the dispute's fork
   point, tagged_hash(\"deposits/fork-point\", cosign_data): its signatures are left out, so every
   variant of the update (one cosignature set or another) gives the same anchor."
  (tagged-hash "deposits/fork-point" (up::cosign-data update)))

(defun dispute-anchor (node id-hex)
  "A confiscation's anchor (FORK-POINT-ANCHOR) from the update at the dispute's fork point (the
   lowest last_valid_sequence any DisputeEnter names), as any fork or our replica holds it."
  (let ((lvs (dispute-last-valid-seq node id-hex)))
    (unless lvs (fail "no fork point for ~a's confiscation anchor" (subseq id-hex 0 8)))
    (let ((u (or (loop for r in (cons (find-record node id-hex) (dispute-forks node id-hex))
                       thereis (and r (record-update-at r lvs)))
                 (fail "no update at ~a's fork point ~a" (subseq id-hex 0 8) lvs))))
      (fork-point-anchor u))))

(defun eligibility-floor-sats (node id-hex)
  "obligations x collateral/reserves at the fork point, + the claim fee floor, in the
   reference's integer arithmetic (floor the product, then round msat up to sats)."
  (let* ((base (or (find-record node id-hex) (fail "unknown ledger")))
         (lvs (dispute-last-valid-seq node id-hex))
         (l (if lvs
                (ledger-at base lvs)
                (record-ledger base)))
         (reserves (lg:ledger-reserves-amount l)))
    (unless (plusp reserves) (fail "QuorumBegin reserves were zero"))
    (+ (ceiling (floor (* (lg:total-obligations l) (lg:ledger-collateral-amount l)) reserves) 1000)
       *claim-fee-floor-sats*)))

(defvar *pledge-verdicts* (make-hash-table :test #'equal) "(txid vout amount E) -> NIL or a reason, once E is buried.")
(defvar *pledge-verdicts-lock* (bt:make-lock "pledge-verdicts"))

(defun pledge-failure (pledge-fn coll snapshot floor-sats tip)
  "Why the pledge COLL = (txid vout sats) fails the cut at SNAPSHOT, or NIL.  PLEDGE-FN
   is a node's pledge-fn; without one only the declaration is checked."
  (destructuring-bind (txid vout sats) coll
    (when (< sats floor-sats) (return-from pledge-failure (format nil "declared ~a sats, below the floor ~a" sats floor-sats)))
    (unless pledge-fn (return-from pledge-failure nil))
    (let ((key (list (bytes->hex txid) vout sats snapshot)))
      (multiple-value-bind (hit found) (bt:with-lock-held (*pledge-verdicts-lock*) (gethash key *pledge-verdicts*))
        (when found (return-from pledge-failure hit)))
      (let* ((facts (funcall pledge-fn txid vout (1+ snapshot)))
             (created (getf facts :created)) (value (getf facts :value-sats)) (spend (getf facts :spend))
             (verdict (cond ((null facts) "pledge transaction not found")
                            ((null value) "pledge output does not exist")
                            ((null created) "pledge is unconfirmed")
                            ((> created snapshot) (format nil "pledge confirmed at ~a, after the snapshot ~a" created snapshot))
                            ((< value sats) (format nil "pledge holds ~a sats, less than the ~a declared" value sats))
                            ((eq spend :unspent) nil)
                            ((and (consp spend) (> (second spend) snapshot)) nil)
                            (t (format nil "pledge spent, unconfirmed or unknown at the snapshot ~a" snapshot)))))
        (when (and tip (>= tip (+ snapshot 6)))
          (bt:with-lock-held (*pledge-verdicts-lock*) (setf (gethash key *pledge-verdicts*) verdict)))
        verdict))))

(defun split-armers (armers floor-sats pledge-fn &key tip confiscated-at)
  "The DEP-03 cut over ARMERS (armers-of entries): (values participants excluded snapshot),
   participants sorted by key, EXCLUDED ((entry . reason) ...).  Once the confiscation has
   confirmed in block CONFISCATED-AT, an arm above it does not count (DEP-03 \"When the set
   is final\"): it neither moves E nor joins."
  (let* ((armers (sort (remove-if (lambda (a) (and confiscated-at (> (fifth a) confiscated-at))) armers)
                       #'bytes< :key #'first))
         (snapshot (reduce #'max armers :key #'fifth :initial-value 0))
         (in '()) (out '()))
    (dolist (a armers)
      (let ((why (if (fourth a) (pledge-failure pledge-fn (fourth a) snapshot floor-sats tip) "declared no replacement collateral")))
        (if why (push (cons a why) out) (push a in))))
    (values (nreverse in) (nreverse out) snapshot)))

;;; DEP-03 §Grounded arms (grounded-arms-v7): an arm counts only if its
;;; fork's DisputeEnter has grounds, an expiry ground or a proven one carried on the fork as
;;; fraud_proof (TLV 345).  The winner's fork becomes the ledger's history, so we never sign a
;;; lottery that could make a DisputeEnter without grounds canonical.  Motive is never examined:
;;; a member may arm on another's grounds by citing them.  Mirrors deposits-rust's
;;; armers::grounds_verdict; vector inspect/vectors/grounded_arms.txt.

(defun verify-received-proof (node proof)
  "Whether PROOF's evidence verifies (DEP-06 §Verification, the per-type check; DEP-03 §Grounded
   arms: its embedding is not asked for, the DisputeEnter that carries it being a signed, dated
   update on a fork of the accused ledger): (values ok why), third value :UNKNOWN when we cannot
   judge it yet (evidence we do not hold)."
  (let* ((id (getf proof :ledger-id))
         (hob (or (node-height-of-block node) (lambda (h) (declare (ignore h)) (height node)))))
    (handler-case
        (case (getf proof :type)
          (:unauthorized-vault-spend (vault-spend-proof-verdict node proof))
          (:non-conforming-cosignature
           (let* ((ev (getf proof :evidence))
                  (fault-id (getf ev :fault-ledger-id))
                  (fault (up:decode-update (hex->bytes (getf ev :fault-update-hex))))
                  (prefix (fault-prefix node fault-id fault)))
             (if prefix
                 (fr:verify-non-conforming-cosignature proof prefix :prefix-ledger-fn (prefix-ledger-fn (find-record node fault-id)))
                 (values nil "the fault ledger's history is not held" :unknown))))
          (t
           (let ((rec (find-record node id)))
             (if (null rec)
                 (values nil "the accused ledger is not held" :unknown)
                 (case (getf proof :type)
                   (:unhonoured-obligation
                    (fr:verify-proof proof :history (reverse (record-history (ledger-chain-record node id))) :height-of-block hob))
                   (:dispute-dereliction
                    (let ((original (getf (getf proof :evidence) :original-proof)))
                      (if original
                          (fr:verify-dispute-dereliction proof (reverse (record-history rec)) hob
                                                         :defrauded-updates (updates-of-ledger node (getf original :ledger-id)))
                          (values nil "no original proof"))))
                   (t (fr:verify-proof proof :history (reverse (record-history rec)) :height-of-block hob
                                             :prefix-ledger-fn (prefix-ledger-fn rec))))))))
      (error (e) (values nil (format nil "not judged yet: ~a" e) :unknown)))))

(defun grounds-class (enter-op enter-height governing-expiry fork-point-operator)
  "DEP-03 §Grounded arms from the DisputeEnter alone: :EXPIRY (grounded), :UNGROUNDED, or a proof to
   verify (the decoded broadcast proof).  Second value: why.  Pure, for the shared vector."
  (let ((reason (op:field enter-op :reason))
        (hash (op:field enter-op :fraud-proof-hash))
        (body (op:field enter-op :fraud-proof)))
    (cond ((dispute-ground-expiry-p reason (op:field enter-op :anchor-block-height) hash enter-height governing-expiry)
           (if (and governing-expiry (> enter-height governing-expiry))
               (values :expiry "a quorum_expired dispute entered past the quorum_expiry")
               (values :ungrounded (format nil "a quorum_expired dispute entered at ~a, not past the quorum_expiry ~a" enter-height governing-expiry))))
          ((null body) (values :ungrounded "a punitive DisputeEnter that carries no fraud_proof"))
          (t (let ((proof (ignore-errors (fr:json->broadcast (w:parse-json body)))))
               (cond ((null proof) (values :ungrounded "its fraud_proof does not parse"))
                     ((not (and hash (equalp (fr:proof-hash proof) hash)))
                      (values :ungrounded "its fraud_proof does not hash to its fraud_proof_hash"))
                     ((not (and fork-point-operator (stringp (getf proof :accused))
                                (string-equal (getf proof :accused) (bytes->hex fork-point-operator))))
                      (values :ungrounded "its proof does not accuse the operator at its fork point"))
                     (t (values proof "a proof to verify"))))))))

(defun arm-grounds (node id-hex fork)
  "(values verdict why) for FORK's DisputeEnter (DISPUTE-ENTER-OF), VERDICT :GROUNDED, :UNGROUNDED
   or :UNKNOWN."
  (multiple-value-bind (u o) (dispute-enter-of node id-hex fork)
    (unless u (return-from arm-grounds (values :ungrounded "no DisputeEnter on its fork")))
    ;; Judged by the node the view belongs to when it holds the ledger, else by the view itself,
    ;; whose base record is the chain the relay gave (a judge that never followed the ledger).
    (let* ((judge (if (and (node-parent node) (find-record (node-parent node) id-hex)) (node-parent node) node))
           (key (up:chain-hash u))
           (hit (gethash key (node-grounds-verdicts judge))))
      (when hit (return-from arm-grounds (values (car hit) (cdr hit))))
      (let* ((base (find-record node id-hex))
             (lvs (op:field o :last-valid-sequence))
             (l (and base (ignore-errors (ledger-at base lvs))))
             (pt (and base (record-update-at base lvs))))
        (multiple-value-bind (class why)
            (grounds-class o (up:update-block-height u) (and l (lg:ledger-quorum-expiry l)) (and pt (up:update-operator-id pt)))
          (multiple-value-bind (verdict why)
              (case class
                (:expiry (values :grounded why))
                (:ungrounded (values :ungrounded why))
                (t (multiple-value-bind (ok vwhy unknown) (verify-received-proof judge class)
                     (cond (ok (values :grounded "its proof verifies"))
                           (unknown (values :unknown vwhy))
                           (t (values :ungrounded (format nil "its proof does not verify: ~a" vwhy)))))))
            (unless (eq verdict :unknown) (setf (gethash key (node-grounds-verdicts judge)) (cons verdict why)))
            (values verdict why)))))))

(defun cut-by-grounds (ruleset entries)
  "DEP-03 §Grounded arms over ENTRIES ((item verdict why) ...), VERDICT :GROUNDED, :UNGROUNDED or
   :UNKNOWN: (values kept excluded), EXCLUDED ((item . reason) ...).  Every item is kept under a
   RULESET without grounded arms; under one with them, an :UNKNOWN verdict stops the cut.  Pure,
   for the shared vector."
  (if (not (lg:ruleset-rule-p ruleset :grounded-arms))
      (values (mapcar #'first entries) '())
      (let ((kept '()) (out '()))
        (loop for (item verdict why) in entries
              do (case verdict
                   (:grounded (push item kept))
                   (:ungrounded (push (cons item (format nil "no grounds: ~a" why)) out))
                   (t (fail "grounds not judged yet: ~a" why))))
        (values (nreverse kept) (nreverse out)))))

(defun shape-by-grounds (ruleset entries)
  "DEP-06 §Respectful vs punitive over ENTRIES ((reason verdict) ...): :RESPECTFUL iff every counted
   DisputeEnter is for a lapsed quorum, and at least one counts.  Under grounded arms only the
   :GROUNDED ones count (an :UNKNOWN stops it); otherwise every one.  Pure, for the shared vector."
  (let ((reasons (if (lg:ruleset-rule-p ruleset :grounded-arms)
                     (loop for (reason verdict) in entries
                           when (eq verdict :unknown) do (fail "grounds not judged yet")
                           when (eq verdict :grounded) collect reason)
                     (mapcar #'first entries))))
    (if (and reasons (every #'expiry-reason-p reasons)) :respectful :punitive)))

(defun ruleset-at-fork-point (node id-hex)
  "The ruleset in force at the dispute's fork point (its ledger state there)."
  (let ((base (find-record node id-hex)) (lvs (dispute-last-valid-seq node id-hex)))
    (and base lvs (lg:ledger-active-ruleset (ledger-at base lvs)))))

(defun grounded-armers (node id-hex armers)
  "ARMERS (armers-of entries) with grounds, under a ruleset with grounded arms: (values kept
   excluded), EXCLUDED ((entry . reason) ...).  An arm whose grounds cannot be judged yet stops
   the cut: we neither build, cosign nor judge on a guess."
  (let ((ruleset (ruleset-at-fork-point node id-hex)))
    (if (not (lg:ruleset-rule-p ruleset :grounded-arms))
        (values armers '())
        (cut-by-grounds ruleset
                        (mapcar (lambda (a)
                                  (let ((fork (find-fork node id-hex (first a))))
                                    (multiple-value-bind (verdict why) (if fork (arm-grounds node id-hex fork) (values :ungrounded "no fork"))
                                      (list a verdict (if (eq verdict :unknown)
                                                          (format nil "armer ~a: ~a" (subseq (bytes->hex (first a)) 0 8) why)
                                                          why)))))
                                armers)))))

(defun dispute-accused-keys (node id-hex)
  "DEP-03 §Lottery: the x-only keys the dispute's own grounds convict: the operator at the fork
   point, and every key the proof each counted DisputeEnter carries (TLV 345) convicts
   (FR:PROOF-ACCUSED-KEYS).  Under grounded arms only grounded DisputeEnters count.  Only this
   dispute's grounds: a key convicted on another ledger is not excluded here."
  (let* ((ruleset (ruleset-at-fork-point node id-hex))
         (base (find-record node id-hex))
         (lvs (dispute-last-valid-seq node id-hex))
         (pt (and base lvs (record-update-at base lvs)))
         (keys (and pt (list (up:x-only (up:update-operator-id pt))))))
    ;; The current dispute's DisputeEnters only (DEP-03 §The accused never win: "each DisputeEnter
    ;; counted in the current dispute"), as deposits-rust's dispute_accused_keys reads them.
    (dolist (fork (dispute-forks node id-hex) (remove-duplicates keys :test #'equalp))
      (multiple-value-bind (u o) (dispute-enter-of node id-hex fork)
        (when (and u (op:field o :fraud-proof)
                   (or (not (lg:ruleset-rule-p ruleset :grounded-arms))
                       (eq (ignore-errors (arm-grounds node id-hex fork)) :grounded)))
          (let ((proof (ignore-errors (fr:json->broadcast (w:parse-json (op:field o :fraud-proof))))))
            (when proof (setf keys (append (fr:proof-accused-keys proof) keys)))))))))

(defun lottery-voters (node id-hex)
  "DEP-06 §Lottery: the lottery's recovery voters and threshold, (values voters threshold).  The
   members of the governing QuorumBegin other than the operator; under strict-lottery-v8
   (provisional, docs/REVIEW.md) also without Accused(grounds), the threshold the strict majority
   of what remains (0 when nothing remains: then the lottery has only its full-set leaf).
   ADVERSARY :lottery-include-accused keeps the accused here too (the pre-v8 lottery)."
  (let* ((base (find-record node id-hex))
         (all (recovery-voters base (dispute-last-valid-seq node id-hex)))
         (strict (and (lg:ruleset-rule-p (ruleset-at-fork-point node id-hex) :strict-lottery)
                      (not (getf (node-adversary node) :lottery-include-accused)))))
    (lot:strict-voters all (and strict (dispute-accused-keys node id-hex)))))

(defun accused-cut (armers accused)
  "ARMERS (armers-of entries) without the ACCUSED x-only keys: (values kept excluded).  Pure."
  (let ((kept '()) (out '()))
    (dolist (a armers (values (nreverse kept) (nreverse out)))
      (if (member (up:x-only (first a)) accused :test #'equalp)
          (push (cons a "accused by the dispute's own grounds") out)
          (push a kept)))))

(defun lottery-armers (node id-hex)
  "The lottery's participants: (values participants excluded snapshot floor).  Once the
   confiscation has confirmed, the arms above its block do not count (DEP-03)."
  (let ((floor-sats (eligibility-floor-sats node id-hex))
        (c (confiscation-height node id-hex)))
    (multiple-value-bind (in out snapshot)
        (multiple-value-bind (grounded ungrounded) (grounded-armers node id-hex (armers-of node id-hex :until c))
          ;; DEP-03 §Lottery: a key the dispute's grounds convict never wins.  Dropped before the cut,
          ;; so the lottery is the cut of a subset of the arms, which every judge already accepts.
          ;; ADVERSARY :lottery-include-accused — a builder that keeps the accused in its lottery (the
          ;; reading every judge accepted before strict-lottery-v8; red team: a guilty majority that
          ;; confiscates into a lottery of its own).
          (multiple-value-bind (grounded accused) (if (getf (node-adversary node) :lottery-include-accused)
                                                      (values grounded '())
                                                      (accused-cut grounded (dispute-accused-keys node id-hex)))
            (multiple-value-bind (in out snapshot)
                (split-armers grounded floor-sats (node-pledge-fn node) :tip (height node) :confiscated-at c)
              (values in (append ungrounded accused out) snapshot))))
      (dolist (x out)
        (log! node "armer ~a excluded from ~a's lottery: ~a" (subseq (bytes->hex (first (car x))) 0 8) (subseq id-hex 0 8) (cdr x)))
      ;; Comparable with the reference's "lottery participants of" line: the set and E.
      (let ((line (format nil "lottery participants of ~a at snapshot ~a: [~{~a~^ ~}]; excluded: [~{~a~^ ~}]"
                          (subseq id-hex 0 16) snapshot
                          (sort (mapcar (lambda (a) (subseq (bytes->hex (first a)) 0 16)) in) #'string<)
                          (sort (mapcar (lambda (x) (subseq (bytes->hex (first (car x))) 0 16)) out) #'string<))))
        (unless (equal line (gethash (cons :participants id-hex) (node-dispute-notes node)))
          (setf (gethash (cons :participants id-hex) (node-dispute-notes node)) line)
          (log! node "~a" line)))
      (values in out snapshot floor-sats))))

(defun collateral-floor-sats (base &key (claim-fee *claim-fee-floor-sats*))
  "DEP-06: obligations x the ledger's collateral ratio, plus the claim fee."
  (let* ((l (record-ledger base))
         (obligations (floor (lg:total-obligations l) 1000))
         (ratio (if (plusp (lg:ledger-reserves-amount l)) (/ (lg:ledger-collateral-amount l) (lg:ledger-reserves-amount l)) 0)))
    (+ (ceiling (* obligations ratio)) claim-fee)))

(defun disputed-reserves (node rec)
  "From the latest QuorumBegin: (values reserves-struct txid vout sats operator33 collateral-msats
   feerate), FEERATE its reference_feerate_sat_vb (2 when none): what its confiscation pays (DEP-03)."
  (let* ((open (record-latest rec :ledger-open))
         (operator (and open (op:field (op:update-op open) :operator-id)))
         (qbu (record-latest rec :quorum-begin))
         (qb (and qbu (op:update-op qbu))))
    (unless qb (fail "no QuorumBegin"))
    (multiple-value-bind (txid sats) (vault-rung node qb)
      (values (rs:build-reserves :operator operator :members (op:field qb :quorum-members)
                                 :ledger-hash (op:field qb :ledger-hash) :quorum-expiry (op:field qb :quorum-expiry)
                                 :ruleset (or (op:field qb :protocol-version) "cltv-offset-v2")
                                 :network (intern (string-upcase (node-network node)) :keyword))
              txid (op:field qb :new-outpoint-vout) sats operator (op:field qb :collateral-amount)
              (let ((f (op:field qb :reference-feerate))) (if (and f (plusp f)) f lot:+confiscation-default-feerate+))))))

(defvar *vault-rungs* (make-hash-table :test #'equalp :synchronized t)
  "rung-0 txid -> (txid sats): which rung of a fee ladder confirmed (DEP-03), once seen confirmed.")

(defvar *judged-spend* nil
  "(TX . PREVOUTS) while a spend is judged: PREVOUTS ((sats . spk)...) in TX's input order, from our
   own chain read or committed by TX's own signatures (BIP341 sighashes commit every input amount).")

(defun judged-spend-rung (rungs vout)
  "DEP-03 §Fee ladder: the rung the spend being judged (*JUDGED-SPEND*) spends, as (txid sats), read
   from the spend itself: its input names the rung that confirmed, its prevout the vault's value.
   Literal, and it holds after the vault is spent, when the UTXO set no longer shows any rung."
  (destructuring-bind (&optional tx . prevouts) *judged-spend*
    (when (and tx prevouts)
      (loop for in in (btx:tx-inputs tx) for i from 0
            when (and (= (btx:txin-prev-index in) vout) (member (btx:txin-prev-hash in) rungs :test #'equalp)
                      (< i (length prevouts)))
              return (list (btx:txin-prev-hash in) (car (elt prevouts i)))))))

(defun vault-rung (node qb)
  "DEP-03 §Fee ladder: the vault QuorumBegin QB created, (values txid sats): output 0 of the rung
   that confirmed: the one the spend being judged spends (JUDGED-SPEND-RUNG), else the one our chain
   holds (unspent; once spent, the one we saw confirm), else rung 0 at QB's amounts.  Judging a
   spend from the UTXO set alone fell back to rung 0 once the vault was spent: a node that had not
   seen the bumped rung confirm (cld4, Nov 8 soak) rebuilt G's confiscation 6076 sats off, challenged
   it, and its lapse convicted the three members that signed it."
  (let* ((rungs (fr:rotation-rungs qb)) (vout (op:field qb :new-outpoint-vout))
         (recorded (floor (+ (op:field qb :amount) (op:field qb :collateral-amount)) 1000))
         (spent (judged-spend-rung rungs vout))
         (known (or spent (gethash (first rungs) *vault-rungs*))))
    (when spent (setf (gethash (first rungs) *vault-rungs*) spent))
    (cond (known (values-list known))
          ((or (null (cdr rungs)) (null (node-chain-fn node))) (values (first rungs) recorded))
          (t (loop for txid in rungs for i from 0
                   for info = (ignore-errors (funcall (node-chain-fn node) txid vout))
                   when info
                     ;; rung 0 holds the recorded amounts; a higher rung, what the chain says
                     do (let ((sats (if (zerop i) recorded (getf info :value-sats))))
                          (when (>= (or (getf info :confirmations) 0) 1)
                            (setf (gethash (first rungs) *vault-rungs*) (list txid sats)))
                          (return (values txid sats)))
                   finally (return (values (first rungs) recorded)))))))

(defun confiscation-tier (reserves h)
  "The reserves tier a confiscation signs at height H: the lowest threshold whose
   CLTV has passed, never the operator's tie-breaker tier.  DEP-06 §Phase 2: a
   strict majority at Tier 0, a minority from quorum_expiry + 720, one member
   from + 4032.  Always signing Tier 0 meant a quorum short of a majority of
   armers could not confiscate even after the minority leaf opened."
  (let ((best 0))
    (loop for tier in (rs:reserves-tiers reserves) for i from 0
          when (and (not (rs:tier-tie-breaker-p tier)) (<= (rs:tier-locktime tier) h)
                    (< (rs:tier-threshold tier) (rs:tier-threshold (nth best (rs:reserves-tiers reserves)))))
            do (setf best i))
    best))

(defun outpoint-at-snapshot (node txid vout snapshot)
  "An output confirmed by SNAPSHOT and unspent through it: its sats, else NIL (pledge-fn facts)."
  (let ((facts (and (node-pledge-fn node) (funcall (node-pledge-fn node) txid vout (1+ snapshot)))))
    (and facts (getf facts :value-sats) (getf facts :created) (<= (getf facts :created) snapshot)
         (let ((spend (getf facts :spend))) (or (eq spend :unspent) (and (consp spend) (> (second spend) snapshot))))
         (getf facts :value-sats))))

(defvar *obligations-memo* (make-hash-table :test #'equalp))
(defvar *obligations-memo-lock* (bt:make-lock "obligations-memo"))

(defun confiscation-obligations (node id-hex participants snapshot)
  "Memoized for a minute per (ID-HEX, SNAPSHOT, PARTICIPANTS): a rebuild tries every shape
   and tier over the same set, and each computation can walk the chain."
  (let ((key (list (node-pubkey node) id-hex snapshot (mapcar #'first participants) (height node))))
    (multiple-value-bind (hit found) (bt:with-lock-held (*obligations-memo-lock*) (gethash key *obligations-memo*))
      (if found
          (values-list hit)
          (let ((v (multiple-value-list (%confiscation-obligations node id-hex participants snapshot))))
            (bt:with-lock-held (*obligations-memo-lock*)
              (when (> (hash-table-count *obligations-memo*) 4096) (clrhash *obligations-memo*))
              (setf (gethash key *obligations-memo*) v))
            (values-list v))))))

(defvar *fork-point-memo* (make-hash-table :test #'equal :synchronized t)
  "(id-hex seq hash) -> the ledger replayed to a dispute's fork point.  It never changes, and a
   replay of a soaked ledger (~180k updates) took seconds on every confiscation_sign request.")

(defun fork-point-ledger (base id-hex lvs)
  (let* ((at (record-update-at base lvs))
         (key (list id-hex lvs (and at (bytes->hex (up:content-hash at))))))
    (or (gethash key *fork-point-memo*)
        (let ((l (ledger-at base lvs)))
          (when (> (hash-table-count *fork-point-memo*) 256) (clrhash *fork-point-memo*))
          (setf (gethash key *fork-point-memo*) l)))))

(defun %confiscation-obligations (node id-hex participants snapshot)
  "DEP-06 §Confiscation obligations: (values swept splice-outs residue-sats) for the confiscation of
   ID-HEX.  SWEPT ((txid vout sats) ...) ascending; SPLICE-OUTS ((spk . sats) ...) ascending by
   deposit id; RESIDUE-SATS the owed entries no splice-out pays.  From the ledger at the fork
   point and the ObligationRecords on PARTICIPANTS' forks below their DisputeArmed."
  (let* ((base (or (find-record node id-hex) (fail "unknown ledger")))
         (lvs (dispute-last-valid-seq node id-hex))
         (l (if lvs (fork-point-ledger base id-hex lvs) (record-ledger base)))
         (a (lg:ledger-dormancy-accept l))
         (swept '()) (outs '()) (residue 0))
    (when a
      ;; a credited migration output not yet spliced backs the ledger's own deposits
      (when (getf a :outpoint)
        (let ((sats (outpoint-at-snapshot node (car (getf a :outpoint)) (cdr (getf a :outpoint)) snapshot)))
          (when sats (push (list (car (getf a :outpoint)) (cdr (getf a :outpoint)) sats) swept))))
      ;; dangling: recorded on a participant's fork, unresolved at the fork point
      (unless (getf a :resolved)
        (let ((seen '()))
          (dolist (p participants)
            (let ((fork (find-fork node id-hex (first p))))
              (dolist (u (and fork (reverse (dispute-fork-updates node id-hex fork :obligation-record))))
                (let ((o (ignore-errors (op:update-op u))))
                  (when (and o (< (up:update-seq u) (sixth p)))
                    (multiple-value-bind (notice qb qu to-us)
                        (ignore-errors (lg:migration-evidence l (op:field o :source-notice-update) (op:field o :source-qb-update)))
                      (when (and qb to-us
                                 (equalp (op:field notice :manifest-hash) (getf a :hash))
                                 (< (up:update-block-height qu) (getf a :expires)))
                        (let* ((txid (op:field qb :new-outpoint-txid)) (vout (op:field qb :migration-vout))
                               (sats (and (not (member (cons txid vout) seen :test #'equalp))
                                          (outpoint-at-snapshot node txid vout snapshot))))
                          (when sats
                            (push (cons txid vout) seen)
                            (push (list txid vout sats) swept)
                            (dolist (e (op:field qb :migration-manifest))
                              (multiple-value-bind (spk v) (lg:owed-spk-sats e)
                                (if spk
                                    (push (list* (getf e :deposit-id) spk v) outs)
                                    (incf residue (floor (getf e :amount) 1000)))))))))))))))))
    ;; DEP-06: proven-uncredited offer payments recorded on the participants' forks are owed too
    ;; (paid from the vault: the payment itself sits at the operator's offer address).
    (let ((hist nil) (paid '())
          (hob (or (node-height-of-block node) (lambda (b) (declare (ignore b)) nil))))
      (dolist (p participants)
        (let ((fork (find-fork node id-hex (first p))))
          (dolist (u (and fork (reverse (dispute-fork-updates node id-hex fork :obligation-record))))
            (let ((o (ignore-errors (op:update-op u))))
              (when (and o (op:field o :uncredited-proof)
                         (< (up:update-seq u) (sixth p)))
                (unless hist (setf hist (reverse (record-history base))))   ; only when a proof needs judging
                (let* ((proof (ignore-errors (fr:json->proof (w:parse-json (bytes->ascii (op:field o :uncredited-proof))))))
                       (txid (and proof (ignore-errors (hex->bytes (fr::e proof :txid)))))
                       (vout (and proof (fr::e proof :vout))))
                  (when (and txid (not (member (cons txid vout) paid :test #'equalp))
                             (string-equal (getf proof :ledger-id) id-hex)
                             (fr:verify-proof proof :history hist :height-of-block hob)
                             (not (fr::onchain-credited-p hist (or lvs most-positive-fixnum) txid vout)))
                    (push (cons txid vout) paid)
                    (let ((e (fr::payment-entry proof)))
                      (multiple-value-bind (spk v) (lg:owed-spk-sats e)
                        (if spk
                            (push (list* (getf e :deposit-id) spk v) outs)
                            (incf residue (floor (getf e :amount) 1000)))))))))))))
    (values (sort swept (lambda (x y) (or (bytes< (first x) (first y))
                                          (and (equalp (first x) (first y)) (< (second x) (second y))))))
            (mapcar #'cdr (sort outs #'bytes< :key #'first))
            residue)))

(defun build-confiscation (node id-hex &key respectful fee tier-index armers snapshot)
  "The confiscation transaction for a disputed ledger, from public state only,
   so every cosigner rebuilds the same one.  It spends the reserves through
   TIER-INDEX (default: the tier open at our height), its nLockTime that tier's
   CLTV.  Its lottery is over ARMERS, by default the DEP-03 eligibility cut
   (lottery-armers).  Returns (values tx lottery prevouts reserves tier-index rungs): TX is rung 0
   of RUNGS, the fee ladder (DEP-03 §Confiscation ladder)."
  (let* ((base (or (find-record node id-hex) (fail "unknown ledger")))
         (armers (sort (copy-list (or armers (lottery-armers node id-hex))) #'bytes< :key #'first))
         (voters (recovery-voters base (dispute-last-valid-seq node id-hex)))   ; the vault's members, for the fee
         (participants (loop for (pk c target) in armers collect (lot:make-participant :pubkey (up:x-only pk) :commitment c :target target)))
         (lottery (progn (when (null participants) (fail "no armer is a lottery participant"))
                         (multiple-value-bind (lvoters threshold) (lottery-voters node id-hex)
                           (lot:build-lottery participants lvoters threshold :network (intern (string-upcase (node-network node)) :keyword))))))
    (multiple-value-bind (reserves txid vout sats operator collateral-msats feerate) (disputed-reserves node base)
      (multiple-value-bind (swept splice-outs residue)
          (confiscation-obligations node id-hex armers (or snapshot (nth-value 2 (lottery-armers node id-hex))))
        (let* ((tier-index (or tier-index (confiscation-tier reserves (height node))))
               (rungs (lot:confiscation-ladder :vault (list txid vout sats) :swept swept :lottery-spk (lot:lottery-spk lottery)
                                               :anchor (dispute-anchor node id-hex)
                                               :voters (1+ (length voters)) :locktime (rs:tier-locktime (nth tier-index (rs:reserves-tiers reserves)))
                                               :respectful respectful :fee fee
                                               :obligations-sats (floor (lg:total-obligations (record-ledger base)) 1000)
                                               :residue-sats residue :splice-outs splice-outs :operator-pubkey33 operator
                                               :collateral-msats collateral-msats :feerate feerate))
               (tx (first rungs)))
          (values tx lottery (coerce (cons (cons sats (rs:reserves-spk reserves))
                                           (loop for (nil nil ss) in swept collect (cons ss (rs:reserves-spk reserves))))
                                     'vector)
                  reserves tier-index rungs))))))

(defun unsigned-tx-hex (tx)
  "An unsigned transaction as we send it to other signers: the legacy form.
   BIP-144 serializes a transaction without witness data without the segwit
   marker and flag; rust-bitcoin refuses the marker with empty witnesses, which
   is how we used to send confiscation_sign and lottery_recovery_sign requests.
   Neither the txid nor any sighash depends on the form."
  (bytes->hex (btx:serialize-tx tx :witness nil)))

(defun confiscation-sighash (tx prevouts reserves &optional (tier-index 0))
  (rot:tier-sighash tx 0 prevouts (nth tier-index (rs:reserves-leaves reserves))))

(defvar *confiscation-ladders* (make-hash-table :test #'equalp :synchronized t)
  "(node pubkey . ledger id) -> (rungs h-c): the assembled rungs of a confiscation we proposed and
   the height we first broadcast it, which its schedule counts from (DEP-03 §Confiscation ladder).")

(defun ladder-rung-due (n h-c height)
  "DEP-03: the rung a holder broadcasts while none has confirmed, min(n - 1, (tip - h_c) / 6)."
  (max 0 (min (1- n) (floor (- height h-c) 6))))

(defun bump-confiscation (node id-hex)
  "Broadcast the rung of our assembled confiscation of ID-HEX that the schedule names (a BIP-125
   replacement of the one below), while no rung has confirmed.  Returns the rung index, or NIL."
  (destructuring-bind (&optional rungs h-c) (gethash (cons (node-pubkey node) id-hex) *confiscation-ladders*)
    (when (and rungs (node-chain-fn node)
               (notany (lambda (r) (let ((info (funcall (node-chain-fn node) (btx:tx-txid r) 0)))
                                     (and info (plusp (or (getf info :confirmations) 0)))))
                       rungs))
      (let ((i (ladder-rung-due (length rungs) h-c (height node))))
        (broadcast node (nth i rungs))
        i))))

(defun confiscate (node id-hex &key respectful fee)
  "Build the confiscation's fee ladder, gather the recovery quorum's signatures on every rung over
   the relay (confiscation_sign), assemble each rung that reaches the tier's threshold, and
   broadcast the one the schedule names (DEP-03 §Confiscation ladder).  Returns (values tx
   lottery), TX rung 0."
  (multiple-value-bind (tx lottery prevouts reserves tier-index rungs) (build-confiscation node id-hex :respectful respectful :fee fee)
    (setf fee (- (reduce #'+ prevouts :key #'car) (reduce #'+ (btx:tx-outputs tx) :key #'btx:txout-value)))
    (let* ((leaf (nth tier-index (rs:reserves-leaves reserves)))
           ;; per rung, one sighash per input (input 0 the vault, then the swept outputs, same tier)
           (hashes (mapcar (lambda (r) (loop for i below (length prevouts) collect (rot:tier-sighash r i prevouts leaf))) rungs))
           (tier (nth tier-index (rs:reserves-tiers reserves)))
           (keys (rs:tier-keys tier))
           ;; signer x-only -> per rung, a list of per-input signatures (NIL for a rung it did not sign)
           (sigs (list (cons (up:x-only (node-pubkey node))
                             (mapcar (lambda (hs) (mapcar (lambda (h) (schnorr:schnorr-sign (node-priv node) h (random-aux))) hs)) hashes))))
           (responses (send-request node id-hex "confiscation_sign"
                                    ;; The reference's field names: sighash, unsigned_tx, last_valid_sequence;
                                    ;; unsigned_rungs / rung_signatures for the ladder.
                                    (w:json-object "sighash" (bytes->hex (first (first hashes))) "respectful" (and respectful t) "fee_sats" fee
                                                   "tier_index" tier-index
                                                   "sweep_sighashes" (and (rest (first hashes)) (coerce (mapcar #'bytes->hex (rest (first hashes))) 'vector))
                                                   "unsigned_tx" (unsigned-tx-hex tx)
                                                   "unsigned_rungs" (coerce (mapcar #'unsigned-tx-hex rungs) 'vector)
                                                   "last_valid_sequence" (lg:ledger-sequence (record-ledger (or (find-fork node id-hex (node-pubkey node)) (find-record node id-hex)))))
                                    :want (1- (rs:tier-threshold tier)) :timeout 20 :successes-only t)))
      (dolist (r responses)
        (let ((res (w:jget r "result")))
          (unless (w:jget r "success") (log! node "confiscation_sign refused: ~a" (w:jget r "error")))
          (when (and (w:jget r "success") res)
            (let* ((pk (up:x-only (hex->bytes (w:jget res "signer"))))
                   (hexes (lambda (v) (mapcar #'hex->bytes (coerce (or v #()) 'list))))
                   ;; per rung: input 0's signature then the swept inputs'.  A signer that predates
                   ;; the ladder answers rung 0 alone (signature, sweep_signatures).
                   (per-rung (let ((r0s (funcall hexes (w:jget res "rung_signatures")))
                                   (rss (coerce (or (w:jget res "rung_sweep_signatures") #()) 'list)))
                               (if r0s
                                   (loop for s0 in r0s for i from 0
                                         collect (cons s0 (funcall hexes (nth i rss))))
                                   (list (cons (hex->bytes (w:jget res "signature")) (funcall hexes (w:jget res "sweep_signatures")))))))
                   (verified (loop for ss in per-rung for hs in hashes
                                   collect (and (= (length ss) (length hs))
                                                (every (lambda (h s) (schnorr:schnorr-verify pk h s)) hs ss)
                                                ss))))
              (when (and (member pk keys :test #'equalp) (not (assoc pk sigs :test #'equalp)) (first verified))
                (push (cons pk verified) sigs))))))
      ;; Assemble the longest prefix of rungs that reach the threshold.
      (let ((assembled
              (loop for r in rungs for i from 0
                    for signers = (remove-if-not (lambda (e) (nth i (cdr e))) sigs)
                    while (>= (length signers) (rs:tier-threshold tier))
                    collect (let ((signed r))
                              (dotimes (in (length prevouts) signed)
                                (setf signed (rot:attach-tier-witness signed in reserves tier-index
                                                                      (mapcar (lambda (k) (let ((e (assoc k signers :test #'equalp)))
                                                                                            (and e (nth in (nth i (cdr e))))))
                                                                              keys))))))))
        (unless assembled
          (fail "only ~a of ~a confiscation signatures" (count-if (lambda (e) (first (cdr e))) sigs) (rs:tier-threshold tier)))
        (dolist (signed assembled)
          (dotimes (i (length prevouts))
            (unless (rot:verify-spend signed i prevouts) (fail "assembled confiscation input ~a does not verify" i))))
        ;; DEP-03: the schedule counts from our first broadcast of this confiscation (a re-proposal
        ;; of the same ladder keeps the first one's count).
        (let* ((key (cons (node-pubkey node) id-hex))
               (prior (gethash key *confiscation-ladders*))
               (h-c (if (and prior (equalp (btx:tx-txid (first (first prior))) (btx:tx-txid (first assembled))))
                        (second prior)
                        (height node))))
          (setf (gethash key *confiscation-ladders*) (list assembled h-c))
          (broadcast node (nth (ladder-rung-due (length assembled) h-c (height node)) assembled)))
        ;; Every rung is a confiscation we hold: whichever confirms is found by its output 0.
        (dolist (signed assembled)
          (unless (find (btx:tx-txid signed) (gethash id-hex (node-signed-confiscations node)) :key (lambda (e) (btx:tx-txid (car e))) :test #'equalp)
            (push (cons signed lottery) (gethash id-hex (node-signed-confiscations node)))))
        (dolist (fork (forks-of node id-hex)) (setf (record-lottery fork) lottery (record-confiscation fork) (first assembled)))
        (handler-case (dolist (signed assembled) (publish-arm-manifest node id-hex signed lottery))
          (error (e) (log! node "arm manifest of ~a: ~a" (subseq id-hex 0 8) e)))
        (values (first assembled) lottery)))))

(defun broadcast (node tx)
  (push tx (node-broadcasts node))
  (when (node-broadcast-fn node)
    (handler-case (funcall (node-broadcast-fn node) (btx:serialize-tx tx))
      (error (c) (log! node "broadcast of ~a failed: ~a" (bytes->hex (reverse (btx:tx-txid tx))) c) nil))))

;;; ---------------------------------------------------------------------------
;;; Red team: unauthorised vault spend (DEP-06 type 7, the gap docs/MISSING.md
;;; opens with).  A colluding majority of a ledger's quorum spends the reserves
;;; outpoint at Tier 0 to an address of theirs — no dispute, no rotation, no
;;; confiscation: nothing in either implementation watches for it.  This is the
;;; theft the contagion simulation models, made concrete on the devnet.

(defun build-vault-theft (node id-hex destination-address &key (tier-index 0) anchor)
  "The theft transaction: the reserves outpoint spent through TIER-INDEX (default
   Tier 0, the majority leaf, open at any height) to DESTINATION-ADDRESS.  Built
   from public state only, like build-confiscation, so every colluder rebuilds
   the same one.  Returns (values tx prevouts reserves tier-index)."
  (let* ((base (or (find-record node id-hex) (fail "unknown ledger")))
         (network (intern (string-upcase (node-network node)) :keyword)))
    (multiple-value-bind (reserves txid vout sats) (disputed-reserves node base)
      (let* ((tier (nth tier-index (rs:reserves-tiers reserves)))
             (locktime (rs:tier-locktime tier))
             (spk (multiple-value-bind (witver program)
                      (cl-consensus.encoding:segwit-decode destination-address (rs:hrp-for network))
                    (cat (octets (if (zerop witver) 0 (+ #x50 witver)) (length program)) program)))
             (prevouts (vector (cons sats (rs:reserves-spk reserves))))
             (tx (rot:build-spend :prev-txid txid :prev-vout vout :reserves-amount sats
                                  :destination-spk spk :fee-rate 1 :locktime locktime))
             ;; ANCHOR: a forged anchor (red team: a theft that names a place in the ledger no
             ;; rotation answers for, DEP-06 §Spend challenge), as the last output
             (tx (if anchor
                     (btx:parse-tx (bw:make-reader
                                    (btx:serialize-tx
                                     (btx:make-tx :version 2 :locktime locktime :segwit-p t :inputs (btx:tx-inputs tx)
                                                  :outputs (append (btx:tx-outputs tx)
                                                                   (list (btx:make-txout :value 0 :script (rot:anchor-script anchor))))
                                                  :witnesses (list nil)))))
                     tx)))
        (values tx prevouts reserves tier-index)))))

(defun vault-spend (node id-hex destination-address &key (tier-index 0) (broadcast-p t) anchor)
  "Spend a ledger's vault outside any recorded rotation or dispute: build the
   tier-0 theft, sign with our key, collect the rest of the threshold's
   signatures from our co-conspirators over the relay (theft_sign), assemble,
   and broadcast.  Returns (values tx sig-count)."
  (multiple-value-bind (tx prevouts reserves tier-index) (build-vault-theft node id-hex destination-address :tier-index tier-index :anchor anchor)
    (let* ((sighash (rot:tier-sighash tx 0 prevouts (nth tier-index (rs:reserves-leaves reserves))))
           (tier (nth tier-index (rs:reserves-tiers reserves)))
           (keys (rs:tier-keys tier))
           (ours (schnorr:schnorr-sign (node-priv node) sighash (random-aux)))
           (sigs (list (cons (up:x-only (node-pubkey node)) ours)))
           (responses (send-request node id-hex "theft_sign"
                                    (w:json-object "sighash" (bytes->hex sighash) "tier_index" tier-index
                                                   "anchor" (and anchor (bytes->hex anchor))
                                                   "unsigned_tx" (unsigned-tx-hex tx))
                                    :want (1- (rs:tier-threshold tier)) :timeout 90 :successes-only t)))
      (log! node "vault-spend: ~a of ~a theft_sign responses in time"
            (count-if (lambda (r) (w:jget r "success")) responses) (rs:tier-threshold tier))
      (dolist (r responses)
        (let ((res (w:jget r "result")))
          (when (and (w:jget r "success") res)
            (let ((pk (up:x-only (hex->bytes (w:jget res "signer")))) (sig (hex->bytes (w:jget res "signature"))))
              (when (and (member pk keys :test #'equalp) (schnorr:schnorr-verify pk sighash sig)
                         (not (assoc pk sigs :test #'equalp)))
                (push (cons pk sig) sigs))))))
      (when (< (length sigs) (rs:tier-threshold tier))
        (fail "only ~a of ~a theft signatures" (length sigs) (rs:tier-threshold tier)))
      (let* ((ordered (mapcar (lambda (k) (cdr (assoc k sigs :test #'equalp))) keys))
             (signed (rot:attach-tier-witness tx 0 reserves tier-index ordered)))
        (unless (rot:verify-spend signed 0 prevouts) (fail "assembled theft does not verify"))
        (when broadcast-p (broadcast node signed))
        (values signed (length sigs))))))

(defun handle-theft-sign (node event params)
  "A co-conspirator: rebuild the theft from public state and sign the proposer's
   sighash.  Gated on the ADVERSARY switch :theft-sign — an honest node never
   answers, which is the point: the theft needs colluders, and the switch is
   what makes a node one."
  (unless (getf (node-adversary node) :theft-sign)
    (return-from handle-theft-sign nil))
  (let ((id (w:event-ledger-id event)))
    (handler-case
        (let* ((proposed (btx:parse-tx (bw:make-reader (hex->bytes (or (w:jget params "unsigned_tx") (fail "no unsigned_tx"))))))
               (tier-index (or (w:jget params "tier_index") 0))
               (destination (arg-theft-destination node proposed)))
          (multiple-value-bind (tx prevouts reserves tier-index)
              (build-vault-theft node id destination :tier-index tier-index
                                                     :anchor (let ((a (w:jget params "anchor"))) (and a (hex->bytes a))))
            (declare (ignore tx))
            (let ((expected (rot:tier-sighash proposed 0 prevouts (nth tier-index (rs:reserves-leaves reserves)))))
              (unless (equalp expected (hex->bytes (w:jget params "sighash")))
                (fail "sighash is not for the theft we expect"))
              (log! node "ADVERSARY: signing vault theft of ~a proposed by ~a" (subseq id 0 8) (subseq (ev:event-pubkey event) 0 8))
              (respond node event t :result (w:json-object "signer" (node-pubkey-hex node)
                                                           "signature" (bytes->hex (schnorr:schnorr-sign (node-priv node) expected (random-aux))))))))
      (error (e) (log! node "refused theft_sign: ~a" e) (respond node event nil :error (princ-to-string e))))))

;;; A reference operator rotates its vault itself (deposits-rust auto_rotation): it
;;; spends the current vault at a tier, 1-in/1-out, into the reserves of the next
;;; quorum, and asks the members for the tier's script-path signature with
;;; `rotation_sign` {sighash, unsigned_tx, tier_index, ledger_hash, new_quorum_expiry}.
;;; A member rebuilds both ends from the replica it holds and signs only that.

(defun parse-splice-param (node param)
  "\"txidhex:vout\" (rotation_sign) -> (txid vout sats spk), looked up on our chain (DEP-20 §4)."
  (when param
    (let* ((colon (position #\: param)) (txid (hex->bytes (subseq param 0 colon))) (vout (parse-integer param :start (1+ colon))))
      (multiple-value-bind (sats spk) (splice-prevout node txid vout) (list txid vout sats spk)))))

(defun pre-update-view (rec seq)
  "REC as it stood before sequence SEQ: a scratch record whose history and ledger stop at SEQ - 1."
  (if (< (lg:ledger-sequence (record-ledger rec)) seq)
      rec
      (make-view rec (1- seq) :owned-p (record-owned-p rec))))

(defun handle-rotation-sign (node event params)
  "DEP-03 Rotation ordering, step 3: sign the rungs a FINAL QuorumBegin names, never a vault
   spend no QuorumBegin names.  The QuorumBegin (carried) must be operator-signed and cosigned to
   its requirement, extend our replica, and its rungs be the ladder we build from the ledger as it
   stood before it.  One signature per rung (and per rung for a vault-script splice-in)."
  (let* ((id (w:event-ledger-id event)) (rec (find-record node id)))
    (unless rec (return-from handle-rotation-sign nil))
    (handler-case
        (let* ((qu (up:decode-update (base64-decode (or (w:jget params "quorum_begin") (fail "no quorum_begin")))))
               (o (op:decode-operation (up:update-message qu)))
               (proposed (mapcar (lambda (h) (btx:parse-tx (bw:make-reader (hex->bytes h))))
                                 (coerce (or (w:jget params "unsigned_rungs") (fail "no unsigned_rungs")) 'list)))
               (tier-index (or (w:jget params "tier_index") 0)))
          (when (record-fork-p rec) (fail "not a base ledger"))
          (unless (eq (op:operation-type o) :quorum-begin) (fail "not a QuorumBegin"))
          (unless (and (equalp (up:update-ledger-id qu) (hex->bytes id)) (equalp (up:update-operator-id qu) (lg:ledger-operator-key (record-ledger rec)))
                       (up:verify-operator-signature qu))
            (fail "the QuorumBegin is not this ledger's operator's"))
          ;; it extends what we hold: our tip, or (applied already) the update before it
          (when (< (lg:ledger-sequence (record-ledger rec)) (1- (up:update-seq qu))) (catch-up node rec))
          (let* ((view (pre-update-view rec (up:update-seq qu)))
                 (vtip (tip view)))
            (unless (and vtip (equalp (up:chain-hash vtip) (up:update-prev-hash qu)) (= (up:update-seq qu) (1+ (up:update-seq vtip))))
              (fail "the QuorumBegin does not extend our replica"))
            (multiple-value-bind (required signers) (lg:cosign-requirement (record-ledger view) o (up:update-block-height qu))
              (multiple-value-bind (ok why) (up:verify-cosignatures qu :quorum (mapcar #'lg:member-pubkey signers) :threshold required)
                (unless ok (fail "the QuorumBegin is not final: ~a" why))))
            (check-not-deposed node view)
            ;; Member policy (REVIEW 11): an opt-out covers the rungs too, judged against the spent
            ;; vault's quorum (the replica before the QuorumBegin), never the new one: else our
            ;; signature could still carry a rotation we declined over its threshold.
            (let ((old-expiry (lg:ledger-quorum-expiry (record-ledger view))))
              (unless (rung-sign-policy-allows-p (up:update-block-height qu) old-expiry *cosign-post-expiry-establishment*)
                (fail "member policy: we do not sign the rungs of a rotation past quorum_expiry ~a" old-expiry)))
            (multiple-value-bind (cur) (disputed-reserves node view)
              (unless (member (node-pubkey node) (rs:reserves-members cur) :test #'equalp) (fail "not a member of the spent vault"))
              (unless (eql tier-index (rung-tier-index cur (btx:tx-locktime (first proposed)) (up:update-block-height qu)))
                (fail "tier_index is not the rungs' tier"))
              ;; DEP-06: this QuorumBegin is the only answer to a challenge of these rungs.  Final
              ;; under DEP-05 is not enough when the spent tier's floor is higher (past expiry the
              ;; lifecycle requirement drops; the vault's tier does not): signet C, 2026-11-16, was
              ;; signed by five over a QuorumBegin no judge accepts, and they were all proved.
              (multiple-value-bind (keys need) (fr:answer-cosign-need cur tier-index)
                (let ((have (fr:tier-cosignatures qu keys)))
                  ;; ADVERSARY :sign-below-floor — a member that signs the rungs anyway (red team:
                  ;; redteam/check-rotation-recorded-threshold.sh needs such a spend on chain to
                  ;; judge; DEP-05 still forbids it).
                  (when (and (< have need) (not (getf (node-adversary node) :sign-below-floor)))
                    (fail "the QuorumBegin carries ~a of the ~a cosignatures by the spent vault's tier that answer its rungs (DEP-06): signing would be a spend no judge can answer"
                          have need)))))
            (multiple-value-bind (ours prevouts cur splice)
                (expected-ladder node view o (up:update-block-height qu) (up:update-prev-hash qu) tier-index)
              (unless (and ours (= (length ours) (length proposed))
                           (every (lambda (a b) (equalp (btx:serialize-tx a :witness nil) (btx:serialize-tx b :witness nil))) ours proposed)
                           (equal (mapcar #'bytes->hex (mapcar #'btx:tx-txid ours)) (mapcar #'bytes->hex (fr:rotation-rungs o))))
                (fail "the rungs are not the ladder the QuorumBegin names"))
              (when (and (node-chain-fn node) (null (funcall (node-chain-fn node) (btx:txin-prev-hash (first (btx:tx-inputs (first ours))))
                                                             (btx:txin-prev-index (first (btx:tx-inputs (first ours)))))))
                (fail "vault outpoint is spent or unknown"))
              (dolist (tx ours) (check-relayable tx))
              (let ((leaf (nth tier-index (rs:reserves-leaves cur)))
                    (vault-splice (and splice (equalp (fourth splice) (rs:reserves-spk cur)))))
                (log! node "signing the ~a rungs of ~a's rotation (QuorumBegin seq ~a) at tier ~a"
                      (length ours) (subseq id 0 8) (up:update-seq qu) tier-index)
                (respond node event t
                         :result (w:json-object
                                  "signer" (node-pubkey-hex node)
                                  "signatures" (coerce (mapcar (lambda (tx) (bytes->hex (schnorr:schnorr-sign (node-priv node) (rot:tier-sighash tx 0 prevouts leaf) (random-aux)))) ours) 'vector)
                                  ;; DEP-03: a vault-script splice-in is signed through the same tier
                                  "splice_signatures" (and vault-splice
                                                           (coerce (mapcar (lambda (tx) (bytes->hex (schnorr:schnorr-sign (node-priv node) (rot:tier-sighash tx 1 prevouts leaf) (random-aux)))) ours) 'vector))))))))
      (error (e) (log! node "refused rotation_sign for ~a: ~a" (subseq id 0 8) e)
        (respond node event nil :error (princ-to-string e))))))

(defun arg-theft-destination (node tx)
  "The destination address of a theft tx: its single output's spk, re-encoded as
   an address.  The conspirators rebuild the same tx from the same public state,
   so this is only a cross-check that the proposer's tx is the one we would build."
  (let* ((spk (btx:txout-script (first (btx:tx-outputs tx))))
         (witver (aref spk 0)) (program (subseq spk (if (>= witver #x50) 2 1))))
    (cl-consensus.encoding:segwit-encode (rs:hrp-for (intern (string-upcase (node-network node)) :keyword))
                                         (if (>= witver #x50) (- witver #x50) witver) program)))

(defun grounded-shape-respectful (node id-hex)
  "Under grounded arms (DEP-03 §Grounded arms): :RESPECTFUL or :PUNITIVE from the grounded
   DisputeEnters of the current dispute alone, so a DisputeEnter without grounds cannot turn a
   respectful confiscation punitive; NIL when the ruleset has no grounded arms.  Signals when a
   ground cannot be judged yet."
  (let ((ruleset (ruleset-at-fork-point node id-hex)))
    (when (lg:ruleset-rule-p ruleset :grounded-arms)
      (shape-by-grounds ruleset
                        (loop for f in (dispute-forks node id-hex)
                              for (u o) = (multiple-value-list (dispute-enter-of node id-hex f))
                              when u collect (list (op:field o :reason) (arm-grounds node id-hex f)))))))

(defun dispute-respectful-p (node id-hex)
  "Whether our dispute of ID-HEX is for a lapsed quorum (a respectful confiscation, DEP-06),
   from our own fork's DisputeEnter: never from a proposer.  Under grounded arms, from the
   grounded DisputeEnters (GROUNDED-SHAPE-RESPECTFUL)."
  (let ((g (grounded-shape-respectful node id-hex)))
    (when g (return-from dispute-respectful-p (eq g :respectful))))
  (let ((fork (find-fork node id-hex (node-pubkey node))))
    (and fork (multiple-value-bind (enter enter-op) (dispute-enter-of node id-hex fork)
                (and enter (expiry-reason-p (op:field enter-op :reason)))))))

(defun unsigned-bytes (tx) (btx:serialize-tx tx :witness nil))

(defun confiscation-match (node id-hex tx &key (respectful (dispute-respectful-p node id-hex)))
  "TX is a confiscation of ID-HEX as the pinned builder makes it (DEP-03): every byte of our
   own rebuild at TX's tier, the shape our dispute's reason dictates, and the rule's fee.  The
   lottery output may pay a lottery over another subset of the armers (a proposer that saw a
   different set of late arms, DEP-03); nothing else may differ.  Returns :ours (our cut),
   :subset, or NIL; second value the lottery it pays."
  (let* ((reserves (ignore-errors (disputed-reserves node (find-record node id-hex))))
         (ti (and reserves (position (btx:tx-locktime tx) (rs:reserves-tiers reserves) :key #'rs:tier-locktime))))
    (when (and ti (not (rs:tier-tie-breaker-p (nth ti (rs:reserves-tiers reserves)))) (btx:tx-outputs tx))
      (let ((ours (ignore-errors (multiple-value-list
                                  (build-confiscation node id-hex :respectful respectful :tier-index ti)))))
        (when ours
          (destructuring-bind (built lottery prevouts reserves tier rungs &rest _) ours
            (declare (ignore built prevouts reserves tier _))
            ;; DEP-03 §Confiscation ladder: any rung of the rebuild
            (cond ((find (unsigned-bytes tx) rungs :key #'unsigned-bytes :test #'equalp) (values :ours lottery))
                  (t (let* ((l (ignore-errors (lottery-paid-by node id-hex (btx:txout-script (first (btx:tx-outputs tx))))))
                            ;; DEP-03 §Grounded arms: a lottery over an arm without grounds is no subset of the cut
                            (grounded (and l (ignore-errors (mapcar (lambda (a) (up:x-only (first a)))
                                                                    (grounded-armers node id-hex (armers-of node id-hex)))))))
                       (when (and l (every (lambda (p) (member (lot:participant-pubkey p) grounded :test #'equalp))
                                           (lot:lottery-participants l))
                                  ;; DEP-03 §The accused never win (strict-lottery-v8)
                                  (let ((rs (ruleset-at-fork-point node id-hex)))
                                    (lg:lottery-admissible-p rs (mapcar #'lot:participant-pubkey (lot:lottery-participants l))
                                                             (and (lg:ruleset-rule-p rs :strict-lottery) (dispute-accused-keys node id-hex)))))
                         (loop for built in rungs
                               for swapped = (btx:make-tx :version (btx:tx-version built) :locktime (btx:tx-locktime built) :segwit-p t
                                                          :inputs (btx:tx-inputs built)
                                                          :outputs (cons (btx:make-txout :value (btx:txout-value (first (btx:tx-outputs built)))
                                                                                         :script (lot:lottery-spk l))
                                                                         (rest (btx:tx-outputs built)))
                                                          :witnesses (list nil))
                               when (equalp (unsigned-bytes swapped) (unsigned-bytes tx))
                                 do (return (values :subset l)))))))))))))

;;; DEP-06 "Authorised confiscation": a vault spend is a confiscation iff it is byte-identical to
;;; the one the rules build from public state (the ledger's history, the public DisputeArmed
;;; events, the eligibility cut as of the spend's block, the obligations, the fee rule), its
;;; lottery over a set the cut yields for some subset of the arms.  Never "one we know of": a
;;; member that missed the dispute rebuilds it from the relay like anyone else.

(defun dispute-view (node id-hex updates &key confiscated-at every-enter)
  "A scratch node holding ID-HEX's ledger and its dispute forks as UPDATES (the relay's, every
   operator's) give them: the original operator's chain, and for each member that entered a
   dispute, the base to its DisputeEnter's fork point then its own updates.  It shares NODE's
   chain functions, so the eligibility cut and obligations are judged on the same chain.
   Linear in UPDATES: the chain is walked by a sequence table (a search of every operator update
   per link was quadratic, 38% of a soaked node's CPU), and when our own replica holds the same
   chain its state is taken from a checkpoint instead of replayed."
  (let* ((sorted (sort (copy-list updates) #'< :key #'up:update-seq))
         (open (or (find-if (lambda (u) (and (zerop (up:update-seq u)) (fr:update-opens-ledger-p u (hex->bytes id-hex)))) sorted)
                   (fail "no LedgerOpen for ~a" (subseq id-hex 0 8))))
         (origin (up:update-operator-id open))
         (by-operator (make-hash-table :test #'equalp))   ; operator -> its updates, ascending
         (base nil))
    (dolist (u (reverse sorted)) (push u (gethash (up:update-operator-id u) by-operator)))
    ;; The operator's chain by its hash links, from LedgerOpen until it forks (an equivocation):
    ;; every dispute forks before its fault, so that prefix is the one the forks share.
    (let ((at-seq (make-hash-table)) (chain (list open))
          (ours (let ((r (find-record node id-hex))) (and r (not (record-fork-p r)) r))))
      (dolist (u (gethash origin by-operator)) (push u (gethash (up:update-seq u) at-seq)))
      (loop for tip = (first chain)
            ;; TIP's chain hash, without hashing when our replica holds the same update (the
            ;; operator's signature commits to its content): our next update's previous_hash
            for link = (let* ((mine (and ours (record-update-at ours (up:update-seq tip))))
                              (after (and mine (equalp (up:update-operator-sig mine) (up:update-operator-sig tip))
                                          (record-update-at ours (1+ (up:update-seq tip))))))
                         (if after (up:update-prev-hash after) (up:chain-hash tip)))
            for next = (remove-duplicates (remove-if-not (lambda (u) (equalp (up:update-prev-hash u) link))
                                                         (gethash (1+ (up:update-seq tip)) at-seq))
                                          :test #'equalp :key #'up:chain-hash)
            while (= (length next) 1)
            do (push (first next) chain))
      ;; DEP-06 §Authorised confiscation: the base ends at the dispute's last fork point.  An
      ;; operator chain that carries on past it carries the fault itself (a colluding majority's
      ;; invalid credit), and replaying that refused (OVER-OBLIGATION), so the rebuild silently
      ;; failed and a judge challenged an honest rung (soak, 6056fb38 rung 1, Nov 4).
      (let ((fork-points (loop for op being the hash-keys of by-operator using (hash-value mine)
                               for e = (and (not (equalp op origin)) (find :dispute-enter mine :key #'op:update-type))
                               when e collect (op:field (op:update-op e) :last-valid-sequence))))
        (when fork-points
          (let ((last-fork (reduce #'max fork-points)))
            (setf chain (or (member-if (lambda (u) (<= (up:update-seq u) last-fork)) chain) (last chain))))))
      (setf base chain))                                  ; newest first
    (let* ((s (%make-node :pubkey (let ((k (make-array 33 :element-type '(unsigned-byte 8))))
                                    (setf (aref k 0) 2) (loop for i from 1 below 33 do (setf (aref k i) (random 256))) k)
                          :network (node-network node) :height-fn (node-height-fn node) :chain-fn (node-chain-fn node)
                          :pledge-fn (node-pledge-fn node) :spender-fn (node-spender-fn node) :feerate-fn (node-feerate-fn node)
                          :tx-confs-fn (node-tx-confs-fn node) :tx-fn (node-tx-fn node)
                          :height-of-block (node-height-of-block node) :block-hash-fn (node-block-hash-fn node)
                          :parent node))
           (top (first base))
           (ours (find-record node id-hex))
           (same (and ours (not (record-fork-p ours))
                      (let ((u (record-update-at ours (up:update-seq top))))
                        (and u (equalp (up:chain-hash u) (up:chain-hash top))))))
           (brec (if same
                     (make-view ours (up:update-seq top))   ; the same chain: shared, state from a checkpoint
                     (index-record (make-record :id-hex id-hex :ledger (lg:replay (reverse base)) :history base)))))
      (setf (gethash id-hex (node-ledgers s)) brec)
      (loop for op being the hash-keys of by-operator using (hash-value mine)
            unless (equalp op origin)
              do (let ((enter (find :dispute-enter mine :key #'op:update-type)))
                   (when enter
                     (let* ((lvs (op:field (op:update-op enter) :last-valid-sequence))
                            (fork (make-view brec (min lvs (up:update-seq top)) :fork-p t :fork-operator op :ledger (lg:make-ledger))))
                       (dolist (u mine)                     ; ascending
                         (when (> (up:update-seq u) lvs) (record-push fork u)))
                       (setf (gethash (fork-key id-hex op) (node-ledgers s)) fork)))))
      (when confiscated-at (setf (gethash id-hex (node-confiscation-heights s)) confiscated-at))
      (when every-enter (setf (gethash :every-enter (node-dispute-notes s)) t))
      s)))

(defun view-respectful-p (view id-hex)
  "DEP-06: a confiscation is respectful iff every DisputeEnter of the dispute is for a lapsed
   quorum; any punitive ground makes it punitive.  Under grounded arms, every grounded one."
  (let ((g (grounded-shape-respectful view id-hex)))
    (when g (return-from view-respectful-p (eq g :respectful))))
  (let ((reasons (loop for f in (dispute-forks view id-hex)
                       for (u o) = (multiple-value-list (dispute-enter-of view id-hex f))
                       when u collect (op:field o :reason))))
    (and reasons (every #'expiry-reason-p reasons))))

(defun rebuild-matches-p (view id-hex tx &key manifest)
  "TX is byte for byte a confiscation VIEW builds: at TX's tier (a confiscation tier, never the
   tie-breaker), in the dispute's shape, its lottery over the cut of some subset of the arms
   counted as of the confiscation's block, with that subset's snapshot for the obligations (as a
   proposer that saw only those arms builds it).  MANIFEST (DEP-06 §Arm manifests, a list of
   (pubkey33 seq)): exactly the arms it names, valid as of the confiscation's block, and no other
   set.  Mirrors deposits-rust's rebuild_matching."
  (let* ((reserves (disputed-reserves view (find-record view id-hex)))
         (tiers (rs:reserves-tiers reserves))
         (ti (position (btx:tx-locktime tx) tiers :key #'rs:tier-locktime))
         (c (confiscation-height view id-hex))
         (named (and manifest (manifest-arms (%all-arms view id-hex) manifest 1 -1 (or c most-positive-fixnum))))
         (all (sort (copy-list (grounded-armers view id-hex (if manifest named (armers-of view id-hex :until c))))
                    #'bytes< :key #'first))
         (floor-sats (eligibility-floor-sats view id-hex))
         (respectful (view-respectful-p view id-hex))
         ;; DEP-03 §The accused never win, under strict-lottery-v8 (the fork point's ruleset, as
         ;; grounded arms): a lottery with a key the dispute's grounds convict is no confiscation.
         ;; Earlier rulesets still accept it (the cut of a subset of the arms).
         (ruleset (ruleset-at-fork-point view id-hex))
         (accused (and (lg:ruleset-rule-p ruleset :strict-lottery) (dispute-accused-keys view id-hex)))
         (want (unsigned-bytes tx))
         (tried '()))
    (when (and ti (not (rs:tier-tie-breaker-p (nth ti tiers))) all
               (if manifest (= (length all) (length manifest)) (<= (length all) 8)))
      (loop for mask from (1- (ash 1 (length all))) downto (if manifest (1- (ash 1 (length all))) 1)
            for arms = (loop for a in all for i from 0 when (logbitp i mask) collect a)
            thereis (multiple-value-bind (in out snapshot) (split-armers arms floor-sats (node-pledge-fn view) :tip (height view))
                      (declare (ignore out))
                      (let ((key (mapcar #'first in)))
                        (when (and in (not (member key tried :test #'equalp))
                                   (lg:lottery-admissible-p ruleset (mapcar (lambda (a) (up:x-only (first a))) in) accused))
                          (push key tried)
                          (let ((rungs (ignore-errors (nth-value 5 (build-confiscation view id-hex :tier-index ti :respectful respectful
                                                                                                   :armers in :snapshot snapshot)))))
                            ;; DEP-06: byte-identical to any rung of the ladder (DEP-03 §Confiscation ladder)
                            (find want rungs :key #'unsigned-bytes :test #'equalp)))))))))

(defvar *rebuilt-confiscations* (make-hash-table :test #'equalp) "spend txid -> verdict, once judged")
(defvar *rebuilt-confiscations-lock* (bt:make-lock "rebuilt-confiscations"))

(defvar *rebuilt-misses* (make-hash-table :test #'equalp :synchronized t)
  "txid -> (update-count dispute-update-count universal-time): a rebuild that did not match, what
   it was built from, and when.")
(defparameter *rebuilt-miss-seconds* 60
  "A rebuild that missed is not tried again (nor the ledger fetched from the relay again) for this long.")

(defun rebuilt-confiscation-p (node id-hex tx &key spend-height updates updates-fn)
  "DEP-06: TX (a spend of ID-HEX's vault, confirmed at SPEND-HEIGHT) is the confiscation the
   rules build from public state.  UPDATES (or what UPDATES-FN returns, called only when needed)
   default to the relay's.  A match is cached by txid; a miss is remembered for
   *REBUILT-MISS-SECONDS* and then rebuilt again (arms the relay had not delivered, pledges not
   yet confirmed)."
  (let ((txid (btx:tx-txid tx)))
    (multiple-value-bind (hit found) (bt:with-lock-held (*rebuilt-confiscations-lock*) (gethash txid *rebuilt-confiscations*))
      (when found (return-from rebuilt-confiscation-p hit)))
    (let ((miss (gethash txid *rebuilt-misses*)))
      (when (and miss (< (- (get-universal-time) (third miss)) *rebuilt-miss-seconds*))
        (return-from rebuilt-confiscation-p nil)))
    (let* ((updates (or updates (and updates-fn (funcall updates-fn)) (ledger-updates-from-relays node id-hex)))
           (disputes (count-if (lambda (u) (member (ignore-errors (op:update-type u)) '(:dispute-enter :dispute-armed :obligation-record)))
                               updates))
           (miss (gethash txid *rebuilt-misses*)))
      ;; A miss over the same updates is not final either: the rebuild also reads the chain
      ;; (pledge confirmations, the confiscation's block), so it is tried again once
      ;; *REBUILT-MISS-SECONDS* have passed (above).  Refreshing the miss here instead, on an
      ;; unchanged update count, never retried it: a judge holding the answer let its challenge
      ;; lapse into false proofs (regtest confiscation-answer, 2026-11-04).
      (declare (ignorable miss disputes))
      ;; The current dispute (DISPUTE-SCOPE) first.  A confiscation built before that rule, over every
      ;; DisputeEnter a disputant ever made, is excused too: that reading only ever excuses more,
      ;; never convicts more, so it holds under every ruleset (DEP-18).
      (let* ((scoped (dispute-scope updates))
             (verdict (or (manifest-confiscation-p node id-hex tx scoped spend-height)
                          (let ((view (and scoped (ignore-errors (dispute-view node id-hex scoped :confiscated-at spend-height)))))
                            (and view (forks-of view id-hex) (ignore-errors (rebuild-matches-p view id-hex tx))))
                          (and (/= (length scoped) (length updates))
                               (let ((view (ignore-errors (dispute-view node id-hex updates :confiscated-at spend-height :every-enter t))))
                                 (and view (forks-of view id-hex) (ignore-errors (rebuild-matches-p view id-hex tx))))))))
        ;; Only a match is final; a miss may be a relay that has not delivered every arm yet.
        (if verdict
            (progn (bt:with-lock-held (*rebuilt-confiscations-lock*) (setf (gethash txid *rebuilt-confiscations*) t))
                   (remhash txid *rebuilt-misses*))
            (setf (gethash txid *rebuilt-misses*) (list (length updates) disputes (get-universal-time))))
        verdict))))

(defun manifest-confiscation-p (node id-hex tx scoped spend-height)
  "DEP-06 §Arm manifests (strict-lottery-v8): some published arm set for ID-HEX's round 1 is valid
   as of the confiscation's block and rebuilds TX byte for byte.  Never the latest arm of each
   armer: an arm signed into the window after the spend (fork updates are not cosigned) cannot
   unmake it."
  (let ((view (and scoped (ignore-errors (dispute-view node id-hex scoped :confiscated-at spend-height)))))
    (and view (forks-of view id-hex)
         (lg:ruleset-rule-p (ruleset-at-fork-point view id-hex) :strict-lottery)
         (loop for m in (arm-manifests-of node id-hex 1 :refresh t)
               thereis (and (ignore-errors (rebuild-matches-p view id-hex tx :manifest m))
                            (progn (log! node "~a's spend ~a rebuilds from its arm manifest (~a arms)" (subseq id-hex 0 8)
                                         (subseq (bytes->hex (reverse (btx:tx-txid tx))) 0 16) (length m))
                                   t))))))

(defun handle-confiscation-sign (node event params)
  "A recovery-quorum member: rebuild the confiscation from public state and sign
   only a transaction byte-identical to that rebuild (FINDINGS D2: never a sighash
   the proposer computed over a transaction of its choosing)."
  (let ((id (w:event-ledger-id event)))
    (unless (find-fork node id (node-pubkey node))
      (log! node "confiscation_sign for ~a from ~a: we hold no fork, not answering" (subseq id 0 8) (subseq (ev:event-pubkey event) 0 8))
      (return-from handle-confiscation-sign nil))   ; not a disputant: not ours to answer
    (handler-case
        (let* ((proposed (progn
                           ;; ADVERSARY :hold-arm — holding our arm, we sign no confiscation either.
                           (when (getf (node-adversary node) :hold-arm) (fail "holding our arm (:hold-arm)"))
                           (btx:parse-tx (bw:make-reader (hex->bytes (or (w:jget params "unsigned_tx") (w:jget params "tx_hex") (fail "no unsigned_tx")))))))
               ;; DEP-03: the fee is the rule's and the shape our own dispute's reason, never the proposer's.
               (fee nil)
               (respectful (dispute-respectful-p node id))
               (match (confiscation-match node id proposed))
               ;; DEP-03 §Confiscation ladder: every rung, rung 0 first (a proposer that predates the
               ;; ladder sends rung 0 alone, as unsigned_tx)
               (proposed-rungs (mapcar (lambda (h) (btx:parse-tx (bw:make-reader (hex->bytes h))))
                                       (coerce (or (w:jget params "unsigned_rungs") #()) 'list))))
          (let ((r (w:jget params "respectful")))
            (when (and r (not (eq r :false)) (not respectful)) (fail "a respectful confiscation of a punitive dispute")))
          ;; A proposal over another subset of the armers is a real confiscation (it may land, and
          ;; we must recognise it), but not ours to sign until our views of late arms converge.
          (when match
            (dolist (r (cons proposed proposed-rungs))
              (unless (find (btx:tx-txid r) (gethash id (node-seen-confiscations node)) :key #'btx:tx-txid :test #'equalp)
                (push r (gethash id (node-seen-confiscations node))))))
          (multiple-value-bind (tx lottery prevouts reserves tier-index rungs)
              ;; The proposer names its tier (the reference's `tier_index`; else the
              ;; one whose CLTV is the proposed nLockTime).  It must be open at our height.
              (let* ((reserves (disputed-reserves node (or (find-record node id) (fail "unknown ledger"))))
                     (tiers (rs:reserves-tiers reserves))
                     (ti (or (w:jget params "tier_index")
                             (position (btx:tx-locktime proposed) tiers :key #'rs:tier-locktime)
                             (fail "no tier has CLTV ~a" (btx:tx-locktime proposed)))))
                (unless (and (integerp ti) (< -1 ti (length tiers))) (fail "tier_index ~a out of range" ti))
                (when (rs:tier-tie-breaker-p (nth ti tiers)) (fail "the operator's tier is not a confiscation tier"))
                (when (> (rs:tier-locktime (nth ti tiers)) (height node))
                  (fail "tier ~a opens at ~a, we are at ~a" ti (rs:tier-locktime (nth ti tiers)) (height node)))
                (build-confiscation node id :respectful respectful :fee fee :tier-index ti))
            (unless (and (equalp (btx:tx-txid tx) (btx:tx-txid proposed)) (equalp (unsigned-bytes tx) (unsigned-bytes proposed)))
              (fail "~a confiscation is not the one we rebuild (ours: sats ~a, base seq ~a, outputs ~a)"
                    (if (eq match :subset) "a subset-lottery" "the proposed")
                    (car (aref prevouts 0)) (lg:ledger-sequence (record-ledger (find-record node id)))
                    (mapcar (lambda (o) (cons (btx:txout-value o) (subseq (bytes->hex (btx:txout-script o)) 0 12))) (btx:tx-outputs tx))))
            (when proposed-rungs
              (unless (= (length proposed-rungs) (length rungs))
                (fail "the proposal has ~a rungs; our ladder has ~a" (length proposed-rungs) (length rungs)))
              (loop for p in proposed-rungs for r in rungs for i from 0
                    unless (equalp (unsigned-bytes p) (unsigned-bytes r))
                      do (fail "rung ~a is not our rebuild's" i)))
            (let ((expected (confiscation-sighash tx prevouts reserves tier-index))
                  (leaf (nth tier-index (rs:reserves-leaves reserves))))
              (unless (equalp expected (hex->bytes (w:jget params "sighash")))
                (fail "the proposer's sighash is not our rebuild's"))
              ;; Its txid does not depend on the witness: keep it, the claim spends it.  Keep every
              ;; one we sign, too: a proposal from another proposer may be the one that lands.
              (dolist (fork (forks-of node id)) (setf (record-lottery fork) lottery (record-confiscation fork) proposed))
              (dolist (r (if proposed-rungs rungs (list proposed)))
                (unless (find (btx:tx-txid r) (gethash id (node-signed-confiscations node))
                              :key (lambda (e) (btx:tx-txid (car e))) :test #'equalp)
                  (push (cons r lottery) (gethash id (node-signed-confiscations node)))))
              (log! node "signed confiscation of ~a proposed by ~a (fee ~a sats)" (subseq id 0 8) (subseq (ev:event-pubkey event) 0 8)
                    (- (reduce #'+ prevouts :key #'car) (reduce #'+ (btx:tx-outputs tx) :key #'btx:txout-value)))
              (handler-case (dolist (r (if proposed-rungs rungs (list proposed))) (publish-arm-manifest node id r lottery))
                (error (e) (log! node "arm manifest of ~a: ~a" (subseq id 0 8) e)))
              (respond node event t :result (w:json-object "signer" (node-pubkey-hex node)
                                                           "signature" (bytes->hex (schnorr:schnorr-sign (node-priv node) expected (random-aux)))
                                                           ;; DEP-06: one signature per swept migration output
                                                           "sweep_signatures"
                                                           (coerce (loop for i from 1 below (length prevouts)
                                                                         collect (bytes->hex (schnorr:schnorr-sign
                                                                                              (node-priv node)
                                                                                              (rot:tier-sighash tx i prevouts (nth tier-index (rs:reserves-leaves reserves)))
                                                                                              (random-aux))))
                                                                   'vector)
                                                           ;; DEP-03 §Confiscation ladder: per rung, input 0 and the swept inputs
                                                           "rung_signatures"
                                                           (and proposed-rungs
                                                                (coerce (loop for r in rungs
                                                                              collect (bytes->hex (schnorr:schnorr-sign (node-priv node) (rot:tier-sighash r 0 prevouts leaf) (random-aux))))
                                                                        'vector))
                                                           "rung_sweep_signatures"
                                                           (and proposed-rungs (> (length prevouts) 1)
                                                                (coerce (loop for r in rungs
                                                                              collect (coerce (loop for i from 1 below (length prevouts)
                                                                                                    collect (bytes->hex (schnorr:schnorr-sign (node-priv node) (rot:tier-sighash r i prevouts leaf) (random-aux))))
                                                                                              'vector))
                                                                        'vector)))))))
      (error (e) (log! node "refused confiscation_sign: ~a" e) (respond node event nil :error (princ-to-string e))))))

(defun publish-reveal (node id-hex)
  "Our preimage, both ways it travels: the durable Kind 9106 event, and the
   reference daemon's lottery_reveal request (which it fetches from the relay
   and matches to a participant by commitment hash; no reply expected)."
  (let* ((fork (or (find-fork node id-hex (node-pubkey node)) (fail "no fork")))
         (preimage (or (record-preimage fork) (fail "not armed")))
         (sig (schnorr:schnorr-sign (node-priv node) (w:reveal-message id-hex preimage) (random-aux))))
    (note-reveal node id-hex (node-pubkey node) preimage)
    (bus:bus-publish (node-bus node) (w:request-event (node-keypair node) id-hex "lottery_reveal"
                                                      (w:json-object "ledger_id" id-hex "preimage" (bytes->hex preimage))))
    (bus:bus-publish (node-bus node) (w:reveal-event (node-keypair node) (node-pubkey-hex node) id-hex preimage sig))))

(defun handle-lottery-reveal-request (node event params)
  "The reference's reveal: {ledger_id, preimage}, authored by the node's Nostr
   key (not the participant's key), so the participant is the armer whose
   commitment the preimage opens."
  (let* ((id (or (w:jget params "ledger_id") (w:event-ledger-id event)))
         (preimage (hex->bytes (or (w:jget params "preimage") (return-from handle-lottery-reveal-request nil))))
         (armer (and (find-record node id)
                     (find (lot:commitment-of preimage) (%all-arms node id) :key #'second :test #'equalp))))
    (when armer
      (log! node "lottery reveal for ~a from ~a opens ~a's commitment" (subseq id 0 8) (subseq (ev:event-pubkey event) 0 8) (subseq (bytes->hex (first armer)) 0 8))
      (note-reveal node id (first armer) preimage))))

(defun note-reveal (node id-hex member33 preimage)
  (let ((alist (gethash id-hex (node-reveals node))))
    ;; A member reveals once per re-arm round (DEP-06 Phase 4): keep each preimage it opens.
    (unless (find-if (lambda (r) (and (equalp (car r) member33) (equalp (cdr r) preimage))) alist)
      (setf (gethash id-hex (node-reveals node)) (cons (cons member33 preimage) alist))
      (save-reveals node id-hex))))

(defun reveals-file-name (id-hex) (format nil "reveals_~a.json" (subseq id-hex 0 16)))

(defun save-reveals (node id-hex)
  (when (node-data-dir node)
    (ensure-directories-exist (node-data-dir node))
    (with-open-file (out (merge-pathnames (reveals-file-name id-hex) (node-data-dir node)) :direction :output :if-exists :supersede)
      (format out "[~{~a~^,~%~}]~%"
              (mapcar (lambda (r) (format nil "[~s,~s]" (bytes->hex (car r)) (bytes->hex (cdr r)))) (reverse (gethash id-hex (node-reveals node))))))))

(defun load-reveals (node id-hex path)
  (let* ((text (uiop:read-file-string path))
         (strings (loop with pos = 0
                        for start = (position #\" text :start pos) while start
                        collect (let ((end (position #\" text :start (1+ start)))) (setf pos (1+ end)) (subseq text (1+ start) end)))))
    (loop for (m pre) on strings by #'cddr do (note-reveal node id-hex (hex->bytes m) (hex->bytes pre)))))

(defun handle-reveal (node event)
  (let* ((j (w:parse-json (ev:event-content event)))
         (id (w:jget j "ledger_id")) (member (hex->bytes (w:jget j "member_pubkey")))
         (preimage (hex->bytes (w:jget j "preimage_hex"))) (sig (hex->bytes (w:jget j "signature"))))
    (when (and (find-record node id)
               (schnorr:schnorr-verify (up:x-only member) (w:reveal-message id preimage) sig)
               ;; The preimage must open the SIGNER's commitment.  Any armer's would do
               ;; before: a member waited for the others' reveals and published, as its
               ;; own, whichever copy made it the winner, never opening its own.
               (find-if (lambda (a) (and (equalp (first a) member) (equalp (second a) (lot:commitment-of preimage))))
                        (%all-arms node id)))
      (note-reveal node id member preimage))))

(defun reveals-of (node id-hex) (gethash id-hex (node-reveals node)))

(defun claim-or-yield (node id-hex &key confiscation-txid (fee lot:+claim-fee-floor+) ((:lottery lottery-key)) lottery-tx)
  "The drawn winner claims the lottery output and takes custody (DisputeAcquire);
   everyone else yields.  Every participant revealed: the full-set leaf.  Past the
   reveal deadline with some missing: the leaf of the revealers we hold, with the
   recovery voters' attestation.  Returns (values :won-or-:yielded claim-tx)."
  (let* ((fork (or (find-fork node id-hex (node-pubkey node)) (fail "no fork")))
         (lottery (or lottery-key (record-lottery fork)
                      ;; After a restart: rebuild from public state (the unsigned tx has the claim's
                      ;; txid).  Its nLockTime is its tier's CLTV, so take the tier whose rebuild is
                      ;; the one on chain; without a chain view, the tier open now.
                      (destructuring-bind (tx l &rest rest)
                          (or (rebuild-confiscation-on-chain node id-hex)
                              ;; A fresh build is a guess at a confiscation that hasn't happened;
                              ;; once the vault is spent, only the one on chain has a lottery to
                              ;; claim (a guessed one "won" off chain, 751e6951).
                              (and (reserves-confiscated-p node (find-record node id-hex))
                                   (fail "no confiscation on chain that we can rebuild"))
                              (multiple-value-list (build-confiscation node id-hex)))
                        (declare (ignore rest))
                        (setf (record-lottery fork) l (record-confiscation fork) tx)
                        l)))
         (participants (lot:lottery-participants lottery))
         (k (length participants))
         ;; CONF: the transaction whose output 0 is the lottery output (a re-arm round's
         ;; recovery spend, DEP-06 Phase 4, or the confiscation)
         (conf (or lottery-tx (record-confiscation fork))))
    (multiple-value-bind (idx preimages) (revealed-indices node id-hex lottery)
      (let ((full (= (length idx) k)))
        (cond ((= k 1) (setf idx '(0) preimages (list nil) full t))
              (full)
              ((null idx) (fail "nobody revealed"))
              ((not (and conf (reveal-deadline-passed-p node conf))) (fail "missing a reveal before the deadline")))
        (let* ((winner (if (= k 1) 0 (lot:subset-winner idx preimages)))
               (winner-pk (lot:participant-pubkey (nth winner participants))))
          ;; ADVERSARY :yield-win — the drawn winner yields its own custody instead of claiming
          ;; (round 1 only; signet soak 2026-11-04, ledger 30ea46ac): every fork yields, the
          ;; output stays unspent, and the re-arm round (DEP-06 Phase 4) must recover it.
          (unless (and (equalp winner-pk (up:x-only (node-pubkey node)))
                       (not (and (getf (node-adversary node) :yield-win) (null lottery-tx))))
            ;; DEP-06 "What a yield must say" (yield-evidence-v9): a lottery we armed for and are not
            ;; in is reason 3 (excluded_by, the transaction that created it); a draw we merely
            ;; computed as lost is no reason yet: wait for the winner's claim to bind (lost_to,
            ;; %DRIVE-DISPUTE), our pledge held meanwhile.  The :yield-win adversary (a drawn winner
            ;; yielding) has no reason at all, so under v9 it only withholds its claim.
            (let* ((in-lottery (member (up:x-only (node-pubkey node)) (mapcar #'lot:participant-pubkey participants) :test #'equalp))
                   (won (and in-lottery (fork-yield-evidence-p fork)
                             (lost-to-acquire node fork (or (op:field (or (nth-value 1 (fork-op fork :dispute-armed)) '(:type :dispute-armed)) :rearm-round) 1))))
                   (reason (cond ((not in-lottery) (and conf (list :excluded-by (btx:tx-txid conf))))
                                 (won (list :lost-to (third won))))))
              (when (and (fork-yield-evidence-p fork) (null reason))
                (return-from claim-or-yield (values :awaiting-claim nil)))
              (unless (yield-once node fork :reason reason) (fail "yield held (YIELD-ONCE)")))
            (return-from claim-or-yield (values :yielded nil)))
          ;; DEP-06 "A claim after the claimant's own yield": the fold takes such an acquire, but a
          ;; node SHOULD never make one.  Our fork yielded this arm's round: broadcast no claim
          ;; (regtest c8b9b7b1, 2026-11-21: deposits-rust ref7's).
          (when (eq (lg:ledger-dispute-state (record-ledger fork)) :tombstoned)
            (fail "our fork yielded this round; not claiming"))
          (let* ((txid (or confiscation-txid (and conf (btx:tx-txid conf)) (fail "no confiscation tx")))
                 (claim-txid (if lottery-tx (btx:tx-txid lottery-tx) txid))   ; the output we spend
                 (amount (btx:txout-value (first (btx:tx-outputs conf))))
                 (target (lot:participant-target (nth winner participants)))
                 (spk (multiple-value-bind (witver program)
                          (cl-consensus.encoding:segwit-decode target (rs:hrp-for (intern (string-upcase (node-network node)) :keyword)))
                        (cat (octets (if (zerop witver) 0 (+ #x50 witver)) (length program)) program)))
                 ;; Our declared replacement collateral (a key-path P2TR of our key) comes along as input 1.
                 (coll (fourth (find (node-pubkey node) (armers-of node id-hex) :key #'first :test #'equalp)))
                 ;; DEP-03 §Claim transaction (multi-input): input 1 MUST be the declared collateral,
                 ;; any other coin is a WinnerCollateralDeviation; one that is a lottery claim's
                 ;; output 0 is a ledger's custody, so the claim is refused (CLAIM-COLLATERAL-REFUSAL).
                 (refusal (and coll (claim-collateral-refusal node coll)))
                 (coll-spk (if refusal
                               (progn (log! node "REFUSING to claim the lottery of ~a: ~a" (subseq id-hex 0 8) refusal)
                                      (fail "claim refused: ~a" refusal))
                               (and coll (lot:key-path-spk (up:x-only (node-pubkey node))))))
                 ;; DEP-03: the shared claim shape (deposits-core build_lottery_claim_tx).
                 (tx (btx:parse-tx (bw:make-reader
                                    (btx:serialize-tx (lot:claim-tx claim-txid 0 amount coll spk :fee fee :subset (not full))))))
                 (prevouts (coerce (append (list (cons amount (lot:lottery-spk lottery))) (and coll (list (cons (third coll) coll-spk)))) 'vector))
                 (leaf (if full (first (lot:lottery-leaves lottery))
                           (nth (lot:subset-leaf-index lottery idx) (lot:lottery-leaves lottery))))
                 (sighash (rot:tier-sighash tx 0 prevouts leaf))
                 (sig (schnorr:schnorr-sign (node-priv node) sighash (random-aux)))
                 (w0 (if full
                         (lot:claim-witness lottery sig preimages)
                         (lot:subset-witness lottery idx sig preimages (subset-attestations node id-hex lottery idx tx prevouts sighash))))
                 (witnesses (append (list w0) (and coll (list (list (key-path-signature node tx 1 prevouts))))))
                 (signed (btx:parse-tx (bw:make-reader
                                        (btx:serialize-tx (btx:make-tx :version 2 :locktime 0 :segwit-p t :inputs (btx:tx-inputs tx) :outputs (btx:tx-outputs tx)
                                                                       :witnesses witnesses))))))
            (dotimes (i (length (btx:tx-inputs signed)))
              (unless (rot:verify-spend signed i prevouts) (fail "claim input ~a does not verify" i)))
            ;; Custody is the claim on chain, not our belief in it: a claim the network refuses
            ;; takes nothing, so no DisputeAcquire for it.
            (when (and (node-broadcast-fn node) (null (broadcast node signed)))
              (fail "claim ~a refused by the network" (txid-hex (btx:tx-txid signed))))
            (unless (node-broadcast-fn node) (broadcast node signed))
            (commit-update node fork (new-update node fork (list :type :dispute-acquire :new-custodian (node-pubkey node)
                                                                 :claim-txid (btx:tx-txid signed) :new-reserves-address target
                                                                 ;; DEP-06: the confiscation whose residue we now owe
                                                                 :confiscation-txid txid)))
            ;; DEP-06 §Residue: we owe it now, within the ledger's service_response_blocks.
            ;; ADVERSARY :withhold-residue — a winner that never credits it (proof 11's target).
            (unless (getf (node-adversary node) :withhold-residue)
            (let ((ctx (if (and conf (equalp (btx:tx-txid conf) txid))
                           conf
                           (first (ignore-errors (rebuild-confiscation-on-chain node id-hex))))))
              (if (and ctx (equalp (btx:tx-txid ctx) txid))
                  (handler-case (credit-residue node fork ctx)
                    (error (e) (log! node "residue of ~a: ~a" (subseq id-hex 0 8) e)))
                  (log! node "residue of ~a: the confiscation ~a is not one we can rebuild" (subseq id-hex 0 8) (txid-hex txid)))))
            (values :won signed)))))))

(defun credit-residue (node fork conf)
  "DEP-06 §Residue, as the new operator after DisputeAcquire on FORK: credit every owed entry
   the confiscation CONF did not pay.  A migration dangling at the fork point: one MigrationCredit
   carrying CONF (the fold credits only its unpaid entries, and resolves the accept).  A payment
   proven uncredited (recorded on a fork, or verified by us): its deposit opened if need be, then
   an OnchainCredit of its outpoint.  Returns how many credits were appended."
  (let* ((id (record-id-hex fork)) (base (find-record node id)) (lvs (dispute-last-valid-seq node id))
         (l (and base lvs (ledger-at base lvs)))
         (a (and l (lg:ledger-dormancy-accept l)))
         (n 0))
    (when (and a (not (getf a :resolved)) (getf a :source))
      (multiple-value-bind (nu qu) (migration-source-updates node a (bytes->hex (getf a :source)))
        (when qu
          (commit-update node fork (new-update node fork (list :type :migration-credit
                                                               :source-notice-update (up:encode-update nu)
                                                               :source-qb-update (up:encode-update qu)
                                                               :confiscation-tx (btx:serialize-tx conf :witness nil))))
          (log! node "residue of ~a: credited the migration's unpaid entries" (subseq id 0 8))
          (incf n))))
    (let ((jsons (remove-duplicates
                  (append (gethash id (node-obligation-proofs node))
                          (loop for f in (dispute-forks node id)
                                append (loop for u in (dispute-fork-updates node id f :obligation-record)
                                             for o = (ignore-errors (op:update-op u))
                                             when (and o (op:field o :uncredited-proof))
                                               collect (bytes->ascii (op:field o :uncredited-proof)))))
                  :test #'string=)))
      (dolist (json jsons)
        (handler-case
            (let* ((proof (fr:json->proof (w:parse-json json))) (e (fr::payment-entry proof))
                   (txid (hex->bytes (fr::e proof :txid))) (vout (fr::e proof :vout)))
              (when (and (string-equal (getf proof :ledger-id) id)
                         (fr::unpaid-in-tx (list e) conf)
                         (not (fr::onchain-credited-p (reverse (record-history fork)) most-positive-fixnum txid vout)))
                (unless (gethash (getf e :deposit-id) (lg:ledger-deposits (record-ledger fork)))
                  (commit-update node fork (new-update node fork (list :type :deposit-open :deposit-id (getf e :deposit-id)
                                                                       :descriptor (getf e :descriptor)))))
                (commit-update node fork (new-update node fork (list :type :onchain-credit :txid txid :vout vout
                                                                     :deposit-id (getf e :deposit-id) :amount (getf e :amount)
                                                                     :funding-address (fr::e proof :funding-address))))
                (log! node "residue of ~a: credited an uncredited payment (~a msat)" (subseq id 0 8) (getf e :amount))
                (incf n)))
          (error (err) (log! node "residue of ~a: a payment not credited: ~a" (subseq id 0 8) err)))))
    n))

(defun subset-attestations (node id-hex lottery idx tx prevouts sighash)
  "The recovery voters' signatures on a revealer-subset claim, parallel to the
   sorted voters (NIL where absent): ours if we are a voter, then
   lottery_subset_attest until the threshold is met."
  (let* ((voters (lot::sorted-keys (lot:lottery-recovery-voters lottery)))
         (threshold (lot:lottery-recovery-threshold lottery))
         (me (up:x-only (node-pubkey node)))
         (sigs (and (member me voters :test #'equalp) (list (cons me (schnorr:schnorr-sign (node-priv node) sighash (random-aux)))))))
    (when (< (length sigs) threshold)
      (dolist (r (send-request node id-hex "lottery_subset_attest"
                               (w:json-object "unsigned_tx" (unsigned-tx-hex tx) "sighash" (bytes->hex sighash)
                                              "subset" (mapcar (lambda (i) (bytes->hex (lot:participant-pubkey (nth i (lot:lottery-participants lottery))))) idx)
                                              "prevout_amounts" (map 'list #'car prevouts)
                                              "prevout_spks" (map 'list (lambda (p) (bytes->hex (cdr p))) prevouts))
                               :want (- threshold (length sigs)) :timeout 30 :successes-only t))
        (let ((res (w:jget r "result")))
          (when (and (w:jget r "success") res)
            (let ((pk (up:x-only (hex->bytes (w:jget res "signer")))) (sig (hex->bytes (w:jget res "signature"))))
              (when (and (member pk voters :test #'equalp) (schnorr:schnorr-verify pk sighash sig) (not (assoc pk sigs :test #'equalp)))
                (push (cons pk sig) sigs)))))))
    (when (< (length sigs) threshold) (fail "only ~a of ~a subset attestations" (length sigs) threshold))
    (mapcar (lambda (v) (cdr (assoc v sigs :test #'equalp))) voters)))

;;; DEP-06 Phase 4: the re-arm round (strict-lottery-v8, provisional; docs/REVIEW.md).  A lottery
;;; output nobody claims (nobody revealed by its deadline, or revealers but no claim by the time
;;; its CSV-144 recovery leaf opens) is spent by its recovery voters into the lottery of a fresh
;;; arm round over the same dispute; reveals and the claim then run against that output.  Every
;;; honest voter rebuilds the spend byte for byte from public state: the round's arms (DisputeArmed
;;; with rearm_round r, inside the round's window), its cut, and the lottery output being spent.

(defun rearm-rounds (node id-hex) (gethash id-hex (node-rearms node)))

(defun rearms-file-name (id-hex) (format nil "rearms_~a.json" (subseq id-hex 0 16)))

(defun save-rearms (node id-hex)
  (when (node-data-dir node)
    (ensure-directories-exist (node-data-dir node))
    (with-open-file (out (merge-pathnames (rearms-file-name id-hex) (node-data-dir node)) :direction :output :if-exists :supersede)
      (format out "[~{~a~^,~%~}]~%"
              (mapcar (lambda (r) (format nil "[~d,~d,~d,~d,~s]" (getf r :round) (or (getf r :height) 0)
                                          (or (getf r :opens) 0) (or (getf r :closes) 0)
                                          (bytes->hex (btx:serialize-tx (getf r :tx)))))
                      (reverse (rearm-rounds node id-hex)))))))

(defun load-rearms (node id-hex path)
  (let ((j (w:parse-json (uiop:read-file-string path))))
    (setf (gethash id-hex (node-rearms node))
          (reverse (loop for e in (coerce j 'list)
                         for v = (coerce e 'list)
                         collect (list :round (first v) :height (and (plusp (second v)) (second v))
                                       :opens (third v) :closes (fourth v)
                                       :tx (btx:parse-tx (bw:make-reader (hex->bytes (fifth v))))))))))

(defun note-rearm-round (node id-hex round tx height &key lottery opens closes)
  "Remember round ROUND's lottery output TX (confirmed at HEIGHT, NIL while unconfirmed), its
   LOTTERY when known, and the window (OPENS, CLOSES] its arms were taken from (round > 1)."
  (let* ((old (find round (rearm-rounds node id-hex) :key (lambda (r) (getf r :round))))
         (rounds (remove round (rearm-rounds node id-hex) :key (lambda (r) (getf r :round)))))
    (setf (gethash id-hex (node-rearms node))
          (cons (list :round round :tx tx :height (or height (getf old :height)) :lottery (or lottery (getf old :lottery))
                      :opens (or opens (getf old :opens)) :closes (or closes (getf old :closes)))
                rounds))
    (save-rearms node id-hex)
    (log! node "dispute ~a: re-arm round ~a's lottery output is ~a~@[ (block ~a)~]" (subseq id-hex 0 8) round
          (txid-hex (btx:tx-txid tx)) height)))

(defun rearm-window (node id-hex lottery-height revealed-p)
  "(values opens closes) for the round after a lottery output confirmed at LOTTERY-HEIGHT: it
   opens at the reveal deadline when nobody revealed, else when the CSV-144 recovery leaf opens
   (provisional), and takes arms through the dispute's arm window."
  (let* ((opens (+ lottery-height (if revealed-p 144 lot:+reveal-csv+)))
         (base (find-record node id-hex))
         (window (let ((named (and base (loop for m in (lg:ledger-quorum-members (record-ledger base))
                                               for b = (lg::member-dispute-arm-blocks m) when (and b (plusp b)) collect b))))
                   (if named (reduce #'max named) *default-dispute-arm-blocks*))))
    (values opens (+ opens window))))

(defun rearm-armers (node id-hex round opens closes)
  "Round ROUND's participants: the arms for that round signed inside (OPENS, CLOSES], through the
   same grounds, accused exclusion and eligibility cut as round 1.  (values participants excluded)."
  (let* ((arms (round-arms node (%all-arms node id-hex) round opens closes))
         (floor-sats (eligibility-floor-sats node id-hex)))
    (multiple-value-bind (grounded ungrounded) (grounded-armers node id-hex arms)
      (multiple-value-bind (grounded accused) (accused-cut grounded (dispute-accused-keys node id-hex))
        (multiple-value-bind (in out) (split-armers grounded floor-sats (node-pledge-fn node) :tip (height node) :confiscated-at closes)
          (values in (append ungrounded accused out)))))))

(defun rearm-round-window-of (node id-hex round opens closes &optional (tip (height node)))
  "Round ROUND's window as of TIP (DEP-06 Phase 4 step 3, recurring windows): OPENS/CLOSES is the
   round's scheduled window (j = 0), which fixes o and w; the round takes the first closed window
   whose cut is non-empty.  (values j opens closes), or NIL."
  ;; The round's arms are read once; the cut (grounds, accused, pledges) runs only for a window
  ;; that holds one.  A lottery stranded for weeks has dozens of closed windows, and this runs on
  ;; every pass (regtest, 2026-11-07: the full cut per window starved a busy node's dispute loop).
  (let ((arms (%all-arms node id-hex)))
    (lot:rearm-round-window opens (- closes opens) tip
                            (lambda (o c) (and (round-arms node arms round o c)
                                               (rearm-armers node id-hex round o c))))))

(defun rearm-lottery (node id-hex round opens closes &optional (tip (height node)))
  "Round ROUND's lottery (the same recovery voters and threshold as round 1), built over the cut
   of its window: the first window, from the scheduled one (OPENS, CLOSES] on, that has closed by
   TIP with a non-empty cut (DEP-06 Phase 4 step 3: the one reopening, then windows recurring
   every k blocks).  (values lottery wopens wcloses), or NIL while no window has."
  (multiple-value-bind (j wo wc) (rearm-round-window-of node id-hex round opens closes tip)
    (when j
      (let ((in (rearm-armers node id-hex round wo wc)))
        (multiple-value-bind (voters threshold) (lottery-voters node id-hex)
          (values (lot:build-lottery (loop for (pk c target) in (sort (copy-list in) #'bytes< :key #'first)
                                           collect (lot:make-participant :pubkey (up:x-only pk) :commitment c :target target))
                                     voters threshold :network (intern (string-upcase (node-network node)) :keyword))
                  wo wc))))))

(defun manifest-round-lottery (node id-hex round opens closes spend-height spk)
  "DEP-03 §Arm manifests (DEP-06 Phase 4 step 5): ROUND's lottery from a published arm manifest
   valid in one of the round's windows (scheduled (OPENS, CLOSES], then its reopening and the
   recurring ones) that closed by SPEND-HEIGHT, whose lottery pays SPK; NIL if none does."
  (let ((manifests (arm-manifests-of node id-hex round :refresh t)))
   (when manifests
    (let ((arms (%all-arms node id-hex)) (w (- closes opens)))
    (multiple-value-bind (voters threshold) (ignore-errors (lottery-voters node id-hex))
     (when voters
      (loop for m in manifests
            thereis (loop for j from 0
                          for (wo wc) = (multiple-value-list (lot:rearm-window-nth opens w j))
                          while (<= wc spend-height)
                          thereis (let ((named (manifest-arms arms m round wo wc)))
                                    (and named
                                         (let ((l (ignore-errors
                                                   (lot:build-lottery (loop for (pk c target) in named
                                                                            collect (lot:make-participant :pubkey (up:x-only pk) :commitment c :target target))
                                                                      voters threshold :network (intern (string-upcase (node-network node)) :keyword)))))
                                           (and l (equalp (lot:lottery-spk l) spk) l))))))))))))

(defun lottery-output-height (node tx)
  (let ((info (and (node-chain-fn node) (funcall (node-chain-fn node) (btx:tx-txid tx) 0))))
    (and info (getf info :confirmations) (plusp (getf info :confirmations))
         (- (1+ (height node)) (getf info :confirmations)))))

(defun current-lottery (node id-hex)
  "(values tx lottery round height) of ID-HEX's newest lottery output that is unspent: a re-arm
   round's (its lottery rebuilt from that round's arms and window), else round 1's (FORK-LOTTERY),
   or NIL."
  (let ((r (first (rearm-rounds node id-hex))))
    (when (and r (> (getf r :round) 1))
      (let ((tx (getf r :tx)) (round (getf r :round)))
        (when (and (node-chain-fn node) (funcall (node-chain-fn node) (btx:tx-txid tx) 0))
          (let ((l (or (getf r :lottery)
                       (and (getf r :height) (getf r :opens)
                            (manifest-round-lottery node id-hex round (getf r :opens) (getf r :closes) (getf r :height)
                                                    (btx:txout-script (first (btx:tx-outputs tx)))))
                       (rearm-lottery node id-hex round (getf r :opens) (getf r :closes))))
                (h (or (getf r :height) (lottery-output-height node tx))))
            (when (and l (equalp (lot:lottery-spk l) (btx:txout-script (first (btx:tx-outputs tx)))))
              (when (and h (not (getf r :height))) (note-rearm-round node id-hex round tx h))
              (setf (getf (first (gethash id-hex (node-rearms node))) :lottery) l)
              (return-from current-lottery (values tx l round h)))))
        (return-from current-lottery nil))))
  (multiple-value-bind (tx l) (fork-lottery node id-hex)
    (when tx (values tx l 1 (or (confiscation-height node id-hex) (lottery-output-height node tx))))))

(defun rearm-open-tiers (lottery height now)
  "The recovery tiers of LOTTERY (output confirmed at HEIGHT) whose CSV has passed at NOW, tier 0
   (the highest threshold) first."
  (let ((age (1+ (- now height))))
    (loop for (csv . nil) in (lot::recovery-specs (lot:lottery-recovery-threshold lottery)) for i from 0
          when (>= age csv) collect i)))

(defvar *rearm-spend-memo* (make-hash-table :test #'equalp :synchronized t)
  "(node-pubkey id txid round tier tip) -> (spend next tier prevouts): REARM-SPEND-FOR's result for one
   block.  A voter's lottery_rearm_sign handler rebuilt the spend from scratch for every request
   (grounds, pledges, the cut), behind slow dispute work on the same worker, and answered after the
   proposer had stopped waiting (signet soak, 2026-11-11).  The voter has usually just built the same
   spend as a proposer, at the same tip.")

(defun rearm-spend-for (node id-hex tx lottery round height &key tier)
  "REARM-SPEND-FOR*, remembered for the current block."
  (let* ((key (list (node-pubkey node) id-hex (btx:tx-txid tx) round tier (height node)))
         (hit (gethash key *rearm-spend-memo*)))
    (if hit
        (values-list hit)
        (let ((r (multiple-value-list (rearm-spend-for* node id-hex tx lottery round height :tier tier))))
          (when (> (hash-table-count *rearm-spend-memo*) 512) (clrhash *rearm-spend-memo*))
          (setf (gethash key *rearm-spend-memo*) r)
          (values-list r)))))

(defun rearm-spend-for* (node id-hex tx lottery round height &key tier)
  "The recovery spend of the lottery output of TX (LOTTERY, round ROUND, confirmed at HEIGHT) into
   round ROUND+1's lottery, through TIER (default the first open: tier 0) when it is open now:
   (values spend next-lottery tier prevouts), or NIL while the next round cannot be built (window
   open, empty cut, TIER not open)."
  (multiple-value-bind (idx) (revealed-indices node id-hex lottery)
    (multiple-value-bind (opens closes) (rearm-window node id-hex height (and idx t))
      ;; No window has closed with a non-empty cut yet (the scheduled one, its reopening, or a
      ;; recurring one): nothing is due.
      (let* ((next (or (rearm-lottery node id-hex (1+ round) opens closes) (return-from rearm-spend-for* nil)))
             (open (rearm-open-tiers lottery height (height node)))
             (tier (if tier (and (member tier open) tier) (first open)))
             (sats (btx:txout-value (first (btx:tx-outputs tx))))
             (feerate (nth-value 6 (disputed-reserves node (find-record node id-hex)))))
        (unless (and tier (plusp (lot:lottery-recovery-threshold lottery))) (return-from rearm-spend-for* nil))
        (let ((spend (lot:rearm-spend lottery (btx:tx-txid tx) 0 sats tier (lot:lottery-spk next) :feerate (or feerate 2))))
          (values spend next tier (vector (cons sats (lot:lottery-spk lottery)))))))))

(defvar *rearm-sign-timeout* 30 "Seconds a proposer waits for lottery_rearm_sign answers in one pass.")

(defun keep-rearm-signature (node sighash-hex response &key late)
  "Keep a lottery_rearm_sign RESPONSE's signature under SIGHASH-HEX when it verifies.  The voter set
   is checked when the signatures are used (REARM-SIGNATURES), so only the signature is checked here."
  (let ((res (and response (w:jget response "success") (w:jget response "result"))))
    (when res
      (let* ((pk (ignore-errors (up:x-only (hex->bytes (w:jget res "signer")))))
             (sig (ignore-errors (hex->bytes (w:jget res "signature"))))
             (sighash (hex->bytes sighash-hex))
             (table (node-rearm-sigs node)))
        (when (and pk sig (ignore-errors (schnorr:schnorr-verify pk sighash sig)))
          (sb-ext:with-locked-hash-table (table)
            (unless (assoc pk (gethash sighash-hex table) :test #'equalp)
              (push (cons pk sig) (gethash sighash-hex table))
              (when late
                (log! node "late re-arm signature kept (~a held)" (length (gethash sighash-hex table)))))))))))

(defun rearm-signatures (node id-hex lottery spend tier prevouts)
  "The recovery voters' signatures on SPEND through TIER, parallel to the sorted voters (NIL where
   absent): ours if we are a voter, those kept from earlier passes (late answers included), then
   lottery_rearm_sign until the tier's threshold is met."
  (let* ((voters (lot::sorted-keys (lot:lottery-recovery-voters lottery)))
         (th (cdr (nth tier (lot::recovery-specs (lot:lottery-recovery-threshold lottery)))))
         (leaf (nth (lot::recovery-leaf-index lottery tier) (lot:lottery-leaves lottery)))
         (sighash (rot:tier-sighash spend 0 prevouts leaf))
         (sh (bytes->hex sighash))
         (me (up:x-only (node-pubkey node))))
    (flet ((held ()
             ;; Kept signatures that are a voter's and verify against this very sighash.
             (remove-if-not (lambda (c) (and (member (car c) voters :test #'equalp)
                                             (schnorr:schnorr-verify (car c) sighash (cdr c))))
                            (gethash sh (node-rearm-sigs node)))))
      (when (> (hash-table-count (node-rearm-late-requests node)) 4096) (clrhash (node-rearm-late-requests node)))
      (when (> (hash-table-count (node-rearm-sigs node)) 1024) (clrhash (node-rearm-sigs node)))
      (when (and (member me voters :test #'equalp) (not (assoc me (held) :test #'equalp)))
        (sb-ext:with-locked-hash-table ((node-rearm-sigs node))
          (push (cons me (schnorr:schnorr-sign (node-priv node) sighash (random-aux))) (gethash sh (node-rearm-sigs node)))))
      (let ((have (length (held))))
        (when (< have th)
          (dolist (r (send-request node id-hex "lottery_rearm_sign"
                                   (w:json-object "unsigned_tx" (unsigned-tx-hex spend) "tier" tier "sighash" sh)
                                   :want (- th have) :timeout *rearm-sign-timeout* :successes-only t
                                   :on-publish (lambda (eid) (setf (gethash eid (node-rearm-late-requests node)) sh))))
            (keep-rearm-signature node sh r))))
      (let ((sigs (held)))
        (when (< (length sigs) th) (fail "only ~a of ~a re-arm signatures" (length sigs) th))
        ;; A threshold-1 leaf names only the lowest sorted voter: keep that voter's signature only.
        (if (= th 1)
            (let ((low (first voters))) (list (cdr (assoc low sigs :test #'equalp))))
            ;; Exactly TH signatures, the lowest sorted voters' that we hold: the spend's fee was
            ;; sized for a TH-signature witness, and kept answers can exceed it.
            (let ((n 0))
              (mapcar (lambda (v) (let ((sig (cdr (assoc v sigs :test #'equalp))))
                                    (when (and sig (< n th)) (incf n) sig)))
                      voters)))))))

(defun handle-lottery-rearm-sign (node event params)
  "A recovery voter (DEP-06 Phase 4): sign a re-arm recovery spend only if it is byte for byte the
   one we rebuild from public state, through a tier whose CSV has elapsed."
  (let ((id (w:event-ledger-id event)))
    (unless (find-record node id) (return-from handle-lottery-rearm-sign nil))
    ;; ADVERSARY :slow-rearm-sign SECONDS — testing only: answer after SECONDS, as a voter whose
    ;; worker is behind slow dispute work (signet soak 2026-11-11; redteam/check-rearm-slow.sh).
    (let ((d (getf (node-adversary node) :slow-rearm-sign))) (when (and (realp d) (plusp d)) (own:pause-for d)))
    (handler-case
        (multiple-value-bind (tx lottery round height) (current-lottery node id)
          (unless (and tx lottery height) (fail "no unclaimed lottery output on chain"))
          (unless (member (up:x-only (node-pubkey node)) (lot:lottery-recovery-voters lottery) :test #'equalp)
            (fail "not a recovery voter"))
          ;; The tier the proposer asks for, when it is open: it falls through the tiers until its
          ;; signers reach one's threshold (DEP-06 Phase 4, "or a later tier if fewer sign").
          (multiple-value-bind (ours next tier prevouts)
              (rearm-spend-for node id tx lottery round height :tier (let ((tr (w:jget params "tier"))) (and (integerp tr) tr)))
            (unless ours (fail "no re-arm spend is due for ~a's round ~a at tier ~a" (subseq id 0 8) round (w:jget params "tier")))
            (let ((asked (btx:parse-tx (bw:make-reader (hex->bytes (w:jget params "unsigned_tx"))))))
              (unless (and (eql tier (w:jget params "tier"))
                           (equalp (btx:serialize-tx asked :witness nil) (btx:serialize-tx ours :witness nil)))
                (fail "the re-arm spend is not the one we rebuild (tier ~a)" tier))
              (let* ((leaf (nth (lot::recovery-leaf-index lottery tier) (lot:lottery-leaves lottery)))
                     (sighash (rot:tier-sighash ours 0 prevouts leaf)))
                (log! node "signed the re-arm spend of ~a's round-~a lottery (tier ~a)" (subseq id 0 8) round tier)
                (handler-case (publish-arm-manifest node id ours next :round (1+ round)
                                                    :window (rearm-manifest-window node id round height (and (revealed-indices node id lottery) t)))
                  (error (e) (log! node "arm manifest of ~a: ~a" (subseq id 0 8) e)))
                (respond node event t :result (w:json-object "signer" (node-pubkey-hex node)
                                                             "signature" (bytes->hex (schnorr:schnorr-sign (node-priv node) sighash (random-aux)))))))))
      (error (e) (log! node "refused lottery_rearm_sign: ~a" e) (respond node event nil :error (princ-to-string e))))))

(defun lottery-spend-confirmed-p (node r)
  "The output of round R's lottery tx is spent in a block (not merely in the mempool).  Without a
   block reader or R's height, T: the gettxout-only reading."
  (let ((tx (getf r :tx)) (height (getf r :height)))
    (or (not (and (node-spender-fn node) height))
        (and (ignore-errors (funcall (node-spender-fn node) height (height node) (list (cons (btx:tx-txid tx) 0)))) t))))

(defparameter +rearm-concluded-depth+ +reveal-depth+
  "Confirmations a spend of a round's lottery output needs before the round is concluded and no
   longer followed: the depth the node treats as safe from a reorganisation (+REVEAL-DEPTH+), or the
   node's MIN-CONFS if that is deeper.")

(defvar *rearm-follow* (make-hash-table :test #'equalp :synchronized t)
  "(node pubkey, ledger id, round) -> plist :scanned-to H :hash B (the block hash at H when it was
   scanned) :spend-height S (a spend of the output seen, not yet deep enough) :concluded T.
   regtest 1120-055242: FOLLOW-REARM-SPEND rescanned every block from the round's lottery height to
   the tip, a getblock with prevouts apiece, on every watch pass, for every fork whose output a
   claim had spent (a claim registers no next round, so nothing remembered it): cld364's 94 rounds
   summed to 867,503 blocks a pass, and one pass spent 1112 s and more in DRIVE-REARMS.")

(defun rearm-follow-key (node id-hex round tx)
  "(node pubkey, ledger, round, the round's lottery txid): the lottery outpoint is in the key, so
   a round re-registered over a different output (a reorganised re-arm) starts its own scan."
  (list (node-pubkey node) id-hex round (txid-hex (btx:tx-txid tx))))

(defun rearm-follow-file (node) (and (node-data-dir node) (merge-pathnames "rearm-follow.sexp" (node-data-dir node))))

(defvar *rearm-follow-save-lock* (bt:make-lock "rearm-follow-save"))

(defun save-rearm-follow (node)
  "Persist NODE's re-arm follow state (write beside, rename), so a restart resumes each scan where
   it stopped instead of rescanning every claimed fork from its lottery height.  A stale entry is
   safe: the block hash at scanned-to is checked before it is used (REARM-FOLLOW-FROM)."
  (let ((f (rearm-follow-file node)) (pk (node-pubkey node)))
    (when f
      (bt:with-lock-held (*rearm-follow-save-lock*)
        (ensure-directories-exist f)
        (let ((tmp (make-pathname :type "tmp" :defaults f))
              (entries (sb-ext:with-locked-hash-table (*rearm-follow*)
                         (loop for k being the hash-keys of *rearm-follow* using (hash-value v)
                               when (equalp (first k) pk)
                                 collect (cons (rest k)
                                               (let ((h (getf v :hash)))
                                                 (if (vectorp h) (list* :hash (bytes->hex h) (alexandria:remove-from-plist v :hash)) v)))))))
          (with-open-file (out tmp :direction :output :if-exists :supersede)
            (with-standard-io-syntax (let ((*print-readably* nil)) (prin1 entries out))))
          (uiop:rename-file-overwriting-target tmp f))))))

(defun load-rearm-follow (node)
  (let ((f (rearm-follow-file node)) (pk (node-pubkey node)))
    (when (and f (probe-file f))
      (dolist (e (ignore-errors (with-open-file (in f) (with-standard-io-syntax (read in)))))
        (ignore-errors
         (let* ((v (cdr e)) (h (getf v :hash)))
           (setf (gethash (cons pk (car e)) *rearm-follow*)
                 (if (stringp h) (list* :hash (hex->bytes h) (alexandria:remove-from-plist v :hash)) v))))))))

(defun rearm-follow-from (node key lottery-height)
  "Where FOLLOW-REARM-SPEND scans from for KEY: :CONCLUDED once a spend of the output is buried
   +REARM-CONCLUDED-DEPTH+ deep; else the height of a spend seen but not yet that deep; else the
   block after the last one scanned, if its hash is unchanged; else LOTTERY-HEIGHT (first scan,
   a restart, or a reorganisation under what was scanned)."
  (let ((e (gethash key *rearm-follow*)))
    (cond ((null e) lottery-height)
          ((getf e :concluded) :concluded)
          ((getf e :spend-height) (max lottery-height (getf e :spend-height)))
          ((and (getf e :scanned-to) (getf e :hash) (node-block-hash-fn node)
                (equalp (ignore-errors (funcall (node-block-hash-fn node) (getf e :scanned-to))) (getf e :hash)))
           (max lottery-height (1+ (getf e :scanned-to))))
          (t (remhash key *rearm-follow*) lottery-height))))

(defun rearm-follow-note (node key tip spend)
  "%REARM-FOLLOW-NOTE, persisted when it changed anything."
  (let ((before (gethash key *rearm-follow*)))
    (%rearm-follow-note node key tip spend)
    (unless (equalp before (gethash key *rearm-follow*)) (ignore-errors (save-rearm-follow node)))))

(defun %rearm-follow-note (node key tip spend)
  "Record a FOLLOW-REARM-SPEND scan up to TIP that found SPEND (or NIL).  Only a spend that is not
   a re-arm spend (one input, one output: a claim) concludes the round, and only once it is
   +REARM-CONCLUDED-DEPTH+ deep; a re-arm spend is followed again every pass until the next round
   is registered (its arms or manifest may still be on their way), but scanned from its own height."
  (let* ((stx (and spend (let ((x (getf spend :tx))) (if (stringp x) (ignore-errors (btx:parse-tx (bw:make-reader (hex->bytes x)))) x))))
         (rearm-shape (and stx (= 1 (length (btx:tx-inputs stx))) (= 1 (length (btx:tx-outputs stx)))))
         (sh (and spend (getf spend :height)))
         (prior (gethash key *rearm-follow*)))
    (cond ((and sh (not rearm-shape) (>= (1+ (- tip sh)) (max +rearm-concluded-depth+ (or (node-min-confs node) 1))))
           (setf (gethash key *rearm-follow*) (list :concluded t)))
          (sh (setf (gethash key *rearm-follow*) (list :spend-height sh)))
          ;; A spend we had seen is gone from where it was (reorganised out): start over.
          ((getf prior :spend-height) (remhash key *rearm-follow*))
          ((node-block-hash-fn node)
           (let ((hash (ignore-errors (funcall (node-block-hash-fn node) tip))))
             (if hash
                 (setf (gethash key *rearm-follow*) (list :scanned-to tip :hash hash))
                 (remhash key *rearm-follow*))))
          (t (remhash key *rearm-follow*)))))

(defun follow-rearm-spend (node id-hex r)
  "If the lottery output of round R (a NOTE-REARM-ROUND plist with its lottery and height) was
   spent into the next round's lottery, register that round.  Returns the spend or NIL."
  (let* ((tx (getf r :tx)) (round (getf r :round)) (height (getf r :height))
         (key (and tx (rearm-follow-key node id-hex round tx)))
         ;; A concluded round needs nothing below, not even its lottery rebuilt (LOTTERY-PAID-BY
         ;; tries subsets of the armers, and a restart would pay that for every claimed fork).
         (concluded (and key (getf (gethash key *rearm-follow*) :concluded)))
         ;; LOAD-REARMS keeps no lottery: after a restart, rebuild the one whose output TX pays.
         (spk (btx:txout-script (first (btx:tx-outputs tx))))
         (l (or (getf r :lottery)
                (let ((x (if concluded nil (if (= round 1)
                             (lottery-paid-by node id-hex spk)
                             (and (getf r :opens) (getf r :closes) (rearm-lottery node id-hex round (getf r :opens) (getf r :closes)))))))
                  (and x (equalp (lot:lottery-spk x) spk) x)))))
    (when concluded (return-from follow-rearm-spend nil))
    (when (and (node-spender-fn node) height l)
      (let* ((tip (height node))
             (from (rearm-follow-from node key height)))
        (when (eq from :concluded) (return-from follow-rearm-spend nil))
      (let ((spend (find-if (lambda (s) (equalp (getf s :txid) (btx:tx-txid tx)))
                            ;; Outpoints are (txid . vout), and a spend's :tx is its hex.  This
                            ;; once passed (txid 0) and read :tx as parsed, so a voter that did
                            ;; not broadcast the spend itself never followed it into the next
                            ;; round (regtest, 2026-11-07: cld28 on 75395b59 and 7c4d6b2a).
                            (ignore-errors (funcall (node-spender-fn node) from tip (list (cons (btx:tx-txid tx) 0)))))))
        (rearm-follow-note node key tip spend)
        (when spend
          (let ((stx (let ((x (getf spend :tx)))
                       (if (stringp x) (ignore-errors (btx:parse-tx (bw:make-reader (hex->bytes x)))) x))))
            (when (and stx (= 1 (length (btx:tx-inputs stx))) (= 1 (length (btx:tx-outputs stx))))
              (multiple-value-bind (opens closes) (rearm-window node id-hex height (and (revealed-indices node id-hex l) t))
                ;; DEP-03 §Arm manifests: the confirmed spend's output, its set named by a published
                ;; manifest; re-deriving the window's cut is the fallback.
                (let ((next (or (and (getf spend :height)
                                     (manifest-round-lottery node id-hex (1+ round) opens closes (getf spend :height)
                                                             (btx:txout-script (first (btx:tx-outputs stx)))))
                                (rearm-lottery node id-hex (1+ round) opens closes (or (getf spend :height) (height node))))))
                  (when (and next (equalp (lot:lottery-spk next) (btx:txout-script (first (btx:tx-outputs stx)))))
                    (note-rearm-round node id-hex (1+ round) stx (getf spend :height) :lottery next :opens opens :closes closes)
                    stx)))))))))))

(defvar *rearm-backoff* (make-hash-table :test #'equal :synchronized t)
  "Ledger id -> (next-height . gap): a re-arm spend whose signatures fell short is retried after
   GAP blocks, doubling to +REARM-BACKOFF-MAX+.")
(defparameter +rearm-backoff-max+ 12)

(defvar *late-rearmed* (make-hash-table :test #'equal :synchronized t)
  "ADVERSARY :late-rearm: the disputes we already late-armed (testing only).")

(defun rearm-manifest-window (node id-hex round height revealed)
  "The window (opens . closes) whose cut round ROUND+1's lottery is built over, or NIL."
  (multiple-value-bind (opens closes) (rearm-window node id-hex height revealed)
    (multiple-value-bind (j wo wc) (rearm-round-window-of node id-hex (1+ round) opens closes)
      (and j (cons wo wc)))))

(defun late-rearm-pledge (node id-hex)
  "ADVERSARY :late-rearm: a fresh coin, else the collateral our latest arm declared (a re-arm may
   repeat it)."
  (or (pledge-collateral node id-hex)
      (let ((mine (remove-if-not (lambda (a) (equalp (first a) (node-pubkey node))) (%all-arms node id-hex))))
        (fourth (first (sort (copy-list mine) #'> :key #'sixth))))))

(defun drive-rearm (node id-hex)
  "One pass of the re-arm round for ID-HEX (DEP-06 Phase 4, strict-lottery-v8): follow a spent
   lottery output into the next round; arm a round that has opened; past its window, as a voter,
   build and sign the recovery spend; in a later round, reveal and claim against its output."
  (unless (lg:ruleset-rule-p (ruleset-at-fork-point node id-hex) :strict-lottery) (return-from drive-rearm nil))
  (let ((fork (find-fork node id-hex (node-pubkey node))))
    ;; A DisputeAcquire ends our part only when it is literal: the confiscation's lottery output is
    ;; spent.  One for a claim that never landed (751e6951's restart, before claims had to be
    ;; accepted first) took nothing, and must not keep us out of the round that recovers it.
    (unless (and fork (fork-op fork :dispute-enter)
                 (not (and (fork-op fork :dispute-acquire) (or (not (node-chain-fn node)) (lottery-output-spent-p node id-hex)))))
      (return-from drive-rearm nil))
    (multiple-value-bind (tx lottery round height) (current-lottery node id-hex)
      (unless tx
        ;; The newest output we know of is gone: follow it (a claim ends the dispute; a re-arm
        ;; spend opens the next round).
        (let ((r (first (rearm-rounds node id-hex))))
          (when r (follow-rearm-spend node id-hex r)))
        (return-from drive-rearm nil))
      (unless height (return-from drive-rearm (note-dispute node id-hex "lottery round ~a: its output is not confirmed yet" round)))
      (when (and (= round 1) (not (rearm-rounds node id-hex)))
        (note-rearm-round node id-hex 1 tx height :lottery lottery))
      (let* ((h (height node)) (idx (revealed-indices node id-hex lottery))
             (me (node-pubkey node))
             (participant (member (up:x-only me) (mapcar #'lot:participant-pubkey (lot:lottery-participants lottery)) :test #'equalp)))
        (multiple-value-bind (opens closes) (rearm-window node id-hex height (and idx t))
          ;; A later round: reveal, then claim or yield (once per round: only while armed).
          ;; ADVERSARY :late-rearm, the spend already confirmed (it landed before a pass of ours
          ;; past the close): the same late same-round arm, now after the spend.  Followers name the
          ;; round's set from its manifest, so it changes nothing (DEP-03 §Arm manifests).
          (when (and (> round 1) participant (getf (node-adversary node) :late-rearm) (not (gethash id-hex *late-rearmed*)))
            (let ((p (late-rearm-pledge node id-hex)))
              (when p
                (arm-dispute node fork :replacement p :round round)
                (setf (gethash id-hex *late-rearmed*) t)
                (note-dispute node id-hex "ADVERSARY: late re-arm of round ~a at ~a, after its window closed" round h))))
          (when (and (> round 1) participant (eq (lg:ledger-dispute-state (record-ledger fork)) :armed))
            (let ((pre (record-preimage fork)))
              (when (and pre (not (find-if (lambda (r) (and (equalp (car r) me) (equalp (cdr r) pre))) (reveals-of node id-hex))))
                (publish-reveal node id-hex)
                (note-dispute node id-hex "re-arm round ~a's lottery on chain; revealed" round)))
            (when (or (= (length (revealed-indices node id-hex lottery)) (length (lot:lottery-participants lottery)))
                      (>= (1+ (- h height)) lot:+reveal-csv+))
              (handler-case
                  (note-dispute node id-hex "re-arm round ~a: ~(~a~)" round
                                (claim-or-yield node id-hex :lottery lottery :lottery-tx tx
                                                            :confiscation-txid (let ((r1 (find 1 (rearm-rounds node id-hex) :key (lambda (r) (getf r :round)))))
                                                                                 (and r1 (btx:tx-txid (getf r1 :tx))))))
                (error (e) (note-dispute node id-hex "re-arm round ~a: claim not yet: ~a" round e)))
              (return-from drive-rearm nil)))
          (multiple-value-bind (wj wo wc) (lot:rearm-open-window opens (- closes opens) h)
          (let ((due (rearm-round-window-of node id-hex (1+ round) opens closes)))
          (cond
            ;; A window of the next round is open (the scheduled one, its reopening, or a recurring
            ;; one) and no earlier window has a non-empty cut: arm it, unless we already armed
            ;; inside this window.
            ((and wj (not due))
             ;; ADVERSARY :hold-rearm-until H — testing only: arm no re-arm round before block H, as
             ;; a member that was down through the scheduled windows (redteam/check-rearm-late.sh).
             (unless (or (let ((u (getf (node-adversary node) :hold-rearm-until))) (and u (< h u)))
                         ;; A fork outside the current dispute takes no part in any round: its arms
                         ;; are no arms, so the two tests below could never see one of ours and it
                         ;; re-armed on every pass of every window (regtest 2026-11-20/21, cld364:
                         ;; EYAAAAAA on 8082521c, 17 round-2 arms on 34651658).
                         (let ((why (rearm-fork-out-of-dispute node id-hex fork)))
                           (when why
                             (note-dispute node id-hex "lottery round ~a unclaimed; not arming round ~a: ~a" round (1+ round) why)
                             t))
                         (find me (pick-round-arms (%all-arms node id-hex) (1+ round) wo wc) :key #'first :test #'equalp)
                         (>= (count me (%all-arms node id-hex) :key #'first :test #'equalp) +max-arms+))
               (let ((p (pledge-collateral node id-hex :round (1+ round))))
                 (if p
                     (progn (arm-dispute node fork :replacement p :round (1+ round))
                            (note-dispute node id-hex "lottery round ~a unclaimed; armed round ~a" round (1+ round)))
                     (note-dispute node id-hex "lottery round ~a unclaimed; waiting for collateral to arm round ~a" round (1+ round))))))
            ;; A window has closed with a non-empty cut: as a recovery voter, spend the output into
            ;; the next round.
            ;; ADVERSARY :late-rearm — testing only: once round (1+ ROUND)'s window has closed with our
            ;; arm in its cut, publish another arm of that round, signed past the close, as an armer
            ;; trying to withdraw (redteam/check-rearm-invert.sh).  The cut keeps the in-window arm.
            ((and due (getf (node-adversary node) :late-rearm)
                  (not (gethash id-hex *late-rearmed*))
                  (destructuring-bind (&optional dj dwo dwc) (multiple-value-list (rearm-round-window-of node id-hex (1+ round) opens closes))
                    (and dj (find me (pick-round-arms (%all-arms node id-hex) (1+ round) dwo dwc) :key #'first :test #'equalp))))
             (let ((p (late-rearm-pledge node id-hex)))
               (if (null p)
                   (note-dispute node id-hex "ADVERSARY: late re-arm of round ~a: no collateral to declare" (1+ round))
                 (progn
                 (arm-dispute node fork :replacement p :round (1+ round))
                 (setf (gethash id-hex *late-rearmed*) t)
                 (note-dispute node id-hex "ADVERSARY: late re-arm of round ~a at ~a, after its window closed"
                               (1+ round) h)))))
            ;; ADVERSARY :invert-arm-selection — testing only: the inverter proposes only once its rule
            ;; gives a cut the honest one does not (a late arm), so it is the differing spend that is
            ;; refused (redteam/check-rearm-invert.sh).
            ((and due (getf (node-adversary node) :invert-arm-selection)
                  (destructuring-bind (&optional dj dwo dwc) (multiple-value-list (rearm-round-window-of node id-hex (1+ round) opens closes))
                    (and dj (let ((all (%all-arms node id-hex)))
                              ;; By (armer, sequence): sequences alone repeat across forks.
                              (flet ((ids (l) (mapcar (lambda (a) (list (first a) (sixth a))) l)))
                                (null (set-exclusive-or (ids (pick-round-arms all (1+ round) dwo dwc))
                                                        (ids (inverted-round-arms all (1+ round) dwo dwc))
                                                        :test #'equalp)))))))
             (let* ((all (%all-arms node id-hex))
                    (w (multiple-value-list (rearm-round-window-of node id-hex (1+ round) opens closes))))
               (note-dispute node id-hex "ADVERSARY: inverter waits for a late arm in round ~a (window ~a..~a; ~a arms of the round: ~{~a~^ ~})"
                             (1+ round) (second w) (third w) (count (1+ round) all :key #'seventh)
                             (loop for a in all when (eql (seventh a) (1+ round))
                                   collect (format nil "~a/~a@~a" (subseq (bytes->hex (first a)) 2 8) (sixth a) (fifth a))))))
            ;; ADVERSARY :rearm-sign-only — testing only: a voter that answers lottery_rearm_sign but
            ;; never proposes, so another implementation's proposer is the one whose spend lands
            ;; (redteam/check-rearm-rust.sh).
            ((and due (getf (node-adversary node) :rearm-sign-only))
             (note-dispute node id-hex "ADVERSARY: sign-only voter; not proposing round ~a's spend" (1+ round)))
            ((and due
                  (member (up:x-only me) (lot:lottery-recovery-voters lottery) :test #'equalp))
             ;; DEP-06 Phase 4: "through the CSV-144 recovery leaf (or a later tier if fewer sign)".
             ;; Each open tier in turn: a quorum whose other voters never sign (deposits-rust runs
             ;; no re-arm round) re-arms at the tier its signers reach.  Only ever asking tier 0
             ;; left E's round-1 lottery at "3 of 4 re-arm signatures" for 3000 blocks (signet
             ;; soak, 2026-11-08..10).
             (let ((last-error nil) (backoff (gethash id-hex *rearm-backoff*)))
               ;; Every tier's lottery_rearm_sign waits out its 30 s on silent voters, and the
               ;; passes over a node's disputes are serial: back off by blocks, or one stuck
               ;; ledger stalls the rest (regtest, 2026-11-10: 5d50d654 delayed 3151f272's claim).
               (when (and backoff (< h (car backoff)))
                 (return-from drive-rearm
                   (note-dispute node id-hex "lottery round ~a unclaimed; re-arm signing backed off until block ~a" round (car backoff))))
               (dolist (tier-try (rearm-open-tiers lottery height h)
                                 (when last-error
                                   (let ((gap (min +rearm-backoff-max+ (if backoff (* 2 (cdr backoff)) 1))))
                                     (setf (gethash id-hex *rearm-backoff*) (cons (+ h gap) gap)))
                                   (note-dispute node id-hex "lottery round ~a unclaimed; re-arm spend not yet: ~a" round last-error)))
                 (multiple-value-bind (spend next tier prevouts) (rearm-spend-for node id-hex tx lottery round height :tier tier-try)
                   (when spend
                     (handler-case
                         (let* ((sigs (rearm-signatures node id-hex lottery spend tier prevouts))
                                (w0 (lot:recovery-witness lottery tier sigs))
                                (signed (btx:parse-tx (bw:make-reader
                                                       (btx:serialize-tx (btx:make-tx :version 2 :locktime 0 :segwit-p t
                                                                                      :inputs (btx:tx-inputs spend) :outputs (btx:tx-outputs spend)
                                                                                      :witnesses (list w0)))))))
                           (unless (rot:verify-spend signed 0 prevouts) (fail "the re-arm spend does not verify"))
                           (broadcast node signed)
                           (handler-case (publish-arm-manifest node id-hex signed next :round (1+ round)
                                                               :window (rearm-manifest-window node id-hex round height (and idx t)))
                             (error (e) (log! node "arm manifest of ~a: ~a" (subseq id-hex 0 8) e)))
                           (note-rearm-round node id-hex (1+ round) signed nil :lottery next :opens opens :closes closes)
                           (note-dispute node id-hex "lottery round ~a unclaimed; spent into round ~a's lottery (tier ~a)" round (1+ round) tier)
                           (remhash id-hex *rearm-backoff*)
                           (return))
                       (error (e) (setf last-error (format nil "tier ~a: ~a" tier e))))))))
             )
            ((and (> h closes) (not due))
             (note-dispute node id-hex "lottery round ~a unclaimed; round ~a's next arm window opens after block ~a"
                           round (1+ round) (lot:rearm-next-window opens (- closes opens) h)))))))))))

(defun drive-rearms (node)
  "DRIVE-REARM for every dispute we hold a fork in (a yielded one included: a yield ends a round,
   not the dispute)."
  (let ((ids (remove-duplicates (loop for r being the hash-values of (node-ledgers node)
                                      when (and (record-fork-p r) (record-owned-p r)) collect (record-id-hex r))
                                :test #'equal)))
    (dolist (id ids)
      (handler-case (drive-rearm node id)
        (error (e) (note-dispute node id "re-arm: ~a" e))))))

;;; Testing only: the operator publishes a conflicting update at its current tip
;;; sequence, so members can be seen catching it.

(defun equivocate (node rec)
  (let* ((last (tip rec))
         (o (op:decode-operation (up:update-message last)))
         (u (up:make-signed-update :operator-id (node-pubkey node) :ledger-id (hex->bytes (record-id-hex rec))
                                   :seq (up:update-seq last) :prev-hash (up:update-prev-hash last)
                                   :message (op:encode-operation (append (list :type :onchain-credit :txid (random-aux) :vout 0
                                                                               :deposit-id (or (op:field o :deposit-id) (make-array 16 :element-type '(unsigned-byte 8)))
                                                                               :amount 1 :funding-address "equivocation")))
                                   :block-height (up:update-block-height last) :block-hash (up:update-block-hash last))))
    (up:sign-operator u (node-priv node))
    (bus:bus-publish (node-bus node) (w:update-event (node-keypair node) u))
    u))

;;; Respectful disputes: the quorum expired and the operator has not rotated.

(defun expired-quorum-p (node rec h grace)
  "REC is a ledger we cosign whose quorum_expiry is more than GRACE blocks behind H."
  (let ((ledger (record-ledger rec)))
    (and (not (record-owned-p rec)) (not (record-fork-p rec))
         (lg:ledger-quorum-expiry ledger) (> h (+ (lg:ledger-quorum-expiry ledger) grace))
         (member (node-pubkey node) (lg:ledger-quorum-members ledger) :key #'lg:member-pubkey :test #'equalp)
         (not (live-fork node (record-id-hex rec) (node-pubkey node))))))

(defun expiry-disputed-p (node rec)
  "We already disputed REC's current quorum for expiry and that dispute concluded (yielded: its
   lottery claimed by the winner, or the quorum re-established).  The same expiry is not grounds
   for another: DEP-05 asks for a new DisputeEnter only for a later expiry, which only a later
   QuorumBegin can bring.  Re-disputing every minute had a member append a DisputeEnter and a
   DisputeYield to a dead chain each pass (signet soak, 2026-10-28, ledger G)."
  (let ((f (find-fork node (record-id-hex rec) (node-pubkey node))))
    (and f (fork-op f :dispute-yield)
         (multiple-value-bind (enter eo) (fork-op f :dispute-enter)
           (and enter (expiry-reason-p (op:field eo :reason))
                (>= (or (op:field eo :last-valid-sequence) -1) (latest-quorum-begin-seq rec)))))))

(defvar *expiry-proof-clock* #'get-universal-time
  "Seconds now, for the QuorumExpired republication backoff (tests drive a fake one).")
(defparameter *expiry-proof-backoff* '(600 . 21600)
  "A published QuorumExpired proof is republished after (CAR) seconds, the wait doubling up to (CDR).")
(defparameter *expiry-proof-relay-check* 600
  "Between republications, how often to ask the relays whether they still hold our proof.")

(defun expiry-proof-held-p (node id-hex expiry)
  "The relays hold a QuorumExpired proof of ours for ID-HEX at quorum_expiry EXPIRY.  NIL also when
   they cannot be read (then the backoff alone decides)."
  (let ((me (k:public-hex (node-keypair node))))
    (some (lambda (e)
            (and (string= (ev:event-pubkey e) me)
                 (let ((p (ignore-errors (fr:json->broadcast (w:parse-json (ev:event-content e))))))
                   (and p (eq (getf p :type) :quorum-expired) (equal (getf p :ledger-id) id-hex)
                        (eql (getf (getf p :evidence) :quorum-expiry) expiry)))))
          (ignore-errors (bus:bus-fetch (node-bus node)
                                        (flt:make-filter :kinds (list w:+kind-fraud-proof+)
                                                         :tags (list (cons "d" (list (subseq id-hex 0 16))))))))))

(defun publish-expiry-proof-p (node id-hex expiry)
  "Whether to (re)publish our QuorumExpired proof of ID-HEX at EXPIRY now, and note it if so.
   Once on first sight; then at the backoff (10 min doubling to 6 h); between those, at most every
   *EXPIRY-PROOF-RELAY-CHECK* s, when the relays no longer hold it (so a relay that lost it gets it
   back).  Signet cld7 (ea90aca) re-broadcast four identical proofs every ~72 s pass, 43 per ledger
   per hour, because nothing remembered the last one."
  (let* ((key (cons id-hex expiry)) (now (funcall *expiry-proof-clock*))
         (e (gethash key (node-expiry-proofs node))))
    (flet ((publish (interval)
             (setf (gethash key (node-expiry-proofs node))
                   (list :next (+ now interval) :interval interval :checked now))
             t))
      (cond ((null e) (publish (car *expiry-proof-backoff*)))
            ((>= now (getf e :next))
             (publish (min (cdr *expiry-proof-backoff*) (* 2 (getf e :interval)))))
            ((< (- now (getf e :checked)) *expiry-proof-relay-check*) nil)
            ((progn (setf (getf (gethash key (node-expiry-proofs node)) :checked) now)
                    (expiry-proof-held-p node id-hex expiry))
             nil)
            (t (log! node "quorum expired on ~a: our proof is no longer on the relays; republishing" (subseq id-hex 0 8))
               (setf (getf (gethash key (node-expiry-proofs node)) :checked) now)
               t)))))

(defun check-expired-quorums (node &key anchor-block-hash (grace 0) skip)
  "For every ledger we cosign whose quorum_expiry is more than GRACE blocks behind
   the chain tip (and whose id is not in SKIP), publish a QuorumExpired proof and
   open a dispute fork.  Returns the ledger ids disputed.  The proof is published once per
   (ledger, quorum_expiry) and again only on backoff or when the relays lost it
   (PUBLISH-EXPIRY-PROOF-P); none at all once the vault is confiscated, which ends the dispute
   an expiry would open (ENTER-DISPUTE refuses one then)."
  (let ((h (height node)) (disputed '()))
    (loop for rec being the hash-values of (node-ledgers node)
          for ledger = (record-ledger rec)
          when (and (expired-quorum-p node rec h grace) (not (member (record-id-hex rec) skip :test #'equal))
                    (not (expiry-disputed-p node rec))
                    (not (reserves-confiscated-p node rec)))
            do (let ((proof (fr:make-quorum-expired-proof (lg:ledger-operator-key ledger) (hex->bytes (record-id-hex rec))
                                                          (or anchor-block-hash (make-array 32 :element-type '(unsigned-byte 8)))
                                                          (lg:ledger-quorum-expiry ledger))))
                 (when (publish-expiry-proof-p node (record-id-hex rec) (lg:ledger-quorum-expiry ledger))
                   (broadcast-fraud node proof))
                 (unless (live-fork node (record-id-hex rec) (node-pubkey node))
                   (enter-dispute node rec (lg:ledger-sequence ledger) :reason "quorum_expired"
                                  :anchor-block-hash anchor-block-hash :anchor-block-height h))
                 (push (record-id-hex rec) disputed)))
    disputed))

;;; ---------------------------------------------------------------------------
;;; Collateral wallet: the node key's own P2TR (our-target-address) holds the
;;; UTXOs a disputant pledges as replacement collateral (DEP-06 Phase 1).
;;; Discovery goes through UTXOS-FN (bitcoind scantxoutset: no bitcoind wallet);
;;; a pledge is a whole UTXO declared at its full value, because the winner's
;;; claim signs that input for exactly the declared amount; pledges persist in
;;; the data dir so a restart never pledges one UTXO to two disputes.

(defparameter *reference-claim-fee-sats* 5000
  "The reference cosigner's claim_fee_estimate: its floor is the stricter of the two.")

(defun required-replacement-sats (base)
  "What a pledge on BASE must cover to pass every cosigner: our floor and the
   reference's (obligations x collateral/reserves, rounded up, + 5000 sats)."
  (let* ((l (record-ledger base))
         (reserves (lg:ledger-reserves-amount l))
         (theirs (if (plusp reserves)
                     (+ (ceiling (* (lg:total-obligations l) (lg:ledger-collateral-amount l)) (* reserves 1000))
                        *reference-claim-fee-sats*)
                     0)))
    (max theirs (collateral-floor-sats base))))

(defun outpoint-key (txid vout) (format nil "~a:~a" (txid-hex txid) vout))

(defun save-pledges (node)
  (when (node-data-dir node)
    (with-open-file (out (merge-pathnames "pledges.sexp" (node-data-dir node)) :direction :output :if-exists :supersede)
      (with-standard-io-syntax
        (prin1 (loop for k being the hash-keys of (node-pledges node) using (hash-value v) collect (cons k v)) out)))))

(defun load-pledges (node)
  (let ((f (and (node-data-dir node) (probe-file (merge-pathnames "pledges.sexp" (node-data-dir node))))))
    (when f
      (with-open-file (in f)
        (dolist (p (with-standard-io-syntax (let ((*read-eval* nil)) (read in nil '()))))
          (setf (gethash (car p) (node-pledges node)) (cdr p)))))))

(defun release-pledges (node id-hex)
  (loop for k being the hash-keys of (node-pledges node) using (hash-value v)
        when (equal v id-hex) do (remhash k (node-pledges node)))
  (save-pledges node))

(defun our-utxos (node)
  "Our P2TR's UTXOs, each a plist :txid (wire order) :vout :sats :confirmations."
  (and (node-utxos-fn node) (funcall (node-utxos-fn node) (our-target-address node))))

(defun consolidate-utxos (node utxos &key (sat-per-vb 2))
  "Key-path spend of UTXOS into one output back to us.  Returns (values txid vout sats)."
  (let* ((spk (lot:key-path-spk (up:x-only (node-pubkey node))))
         (total (reduce #'+ utxos :key (lambda (u) (getf u :sats))))
         (fee (* sat-per-vb (+ 11 (* 58 (length utxos)) 43)))
         (inputs (loop for u in utxos collect (btx:make-txin :prev-hash (getf u :txid) :prev-index (getf u :vout) :script (octets) :sequence rot:+sequence-rbf+)))
         (unsigned (btx:parse-tx (bw:make-reader
                                  (btx:serialize-tx (btx:make-tx :version 2 :locktime 0 :segwit-p t :inputs inputs
                                                                 :outputs (list (btx:make-txout :value (- total fee) :script spk))
                                                                 :witnesses (make-list (length inputs) :initial-element nil))))))
         (prevouts (coerce (loop for u in utxos collect (cons (getf u :sats) spk)) 'vector))
         (signed (btx:parse-tx (bw:make-reader
                                (btx:serialize-tx (btx:make-tx :version 2 :locktime 0 :segwit-p t :inputs (btx:tx-inputs unsigned)
                                                               :outputs (btx:tx-outputs unsigned)
                                                               :witnesses (loop for i below (length inputs)
                                                                                collect (list (key-path-signature node unsigned i prevouts)))))))))
    (dotimes (i (length inputs))
      (unless (rot:verify-spend signed i prevouts) (fail "consolidation input ~a does not verify" i)))
    (broadcast node signed)
    (values (btx:tx-txid signed) 0 (- total fee))))

(defun pick-pledge (utxos need min-confs own taken &key (reserve 0))
  "The coin to pledge as replacement collateral (DEP-03 §Replacement collateral declaration), from
   UTXOS (plists :key \"txid:vout\" :sats :confirmations): OWN (this dispute's earlier pledge) while it
   is unspent; else the smallest confirmed coin (at least MIN-CONFS, at least 1) covering NEED that no
   other live arm of ours pledges (TAKEN, a list of keys), ties to the smaller key; else NIL.  A coin
   pledged to two disputes is spent by whichever claim lands first and strands the other (regtest
   rearm-rust, 2026-11-19, deposits-rust).  Vector: pledge_pick.json.  RESERVE (local policy, a
   re-arm's *REARM-PLEDGE-RESERVE*): a new coin only while more than RESERVE free coins cover NEED;
   OWN is kept regardless."
  (or (and own (find own utxos :key (lambda (u) (getf u :key)) :test #'equal))
      (let ((free (remove-if (lambda (u) (or (< (getf u :confirmations) (max 1 min-confs))
                                             (member (getf u :key) taken :test #'equal)
                                             (< (getf u :sats) need)))
                             (copy-list utxos))))
        (and (> (length free) reserve)
             (first (sort free
                          (lambda (a b) (or (< (getf a :sats) (getf b :sats))
                                            (and (= (getf a :sats) (getf b :sats)) (string< (getf a :key) (getf b :key)))))))))))

;;; DEP-03 §Replacement collateral declaration: a coin pledged in a LIVE dispute is not pledged in
;;; another.  What a fork of ours still holds, from its own dispute operations.

(defun fork-pledges-held (events &key retired others)
  "EVENTS are a fork's own dispute operations, oldest first: (:enter), (:arm KEY-OR-NIL [ROUND]),
   (:yield), (:acquire CLAIM-KEY BINDS).  (values PLEDGES CUSTODY ENDED): a pledge is held from its
   arm until a later yield (or the tombstone a lost lottery leaves), a binding acquire (the winner's
   claim confirmed: it spent the pledge or left it free), a binding acquire by ANOTHER participant
   of the dispute for the arm's round or a later one (OTHERS: the rounds those claims close, by
   JUDGE-ACQUIRE; the round is over whether or not we yielded to it -- regtest 1121-next4c, 12 of
   deposits-rust ref6's 25 holding forks), or retirement (RETIRED); a binding claim's output 0 is
   custody while that acquire stands; ENDED is true when the dispute has ended for us.  Fourth
   value: the held pledges with their rounds, ((key . round) ...).
   Regtest 1120-next4 (deposits-rust ref6): counting every pledge ever declared left a long-lived
   node with 31 coins and none it could pledge.  Vector: pledge_pick.json (its forks cases)."
  (if retired
      (values nil nil t)
      (let ((pledges '()) (custody nil) (ended nil) (last-round 0))
        (dolist (e events)
          (ecase (first e)
            (:enter (setf ended nil))
            (:arm (when (second e) (push (cons (second e) (or (third e) 1)) pledges))
             (setf custody nil ended nil last-round (or (third e) 1)))
            (:yield (setf pledges '() custody nil ended t))
            (:void-yield)                ; a yield whose evidence is not seen: absent (DEP-06)
            (:acquire (if (third e)
                          (setf pledges '() custody (second e) ended t)
                          (setf custody nil)))))
        (let ((over (and others (reduce #'max others))))
          (when over
            (setf pledges (remove-if (lambda (p) (<= (cdr p) over)) pledges))
            (when (and (plusp last-round) (<= last-round over)) (setf ended t))))
        (let ((ps (nreverse pledges))) (values (mapcar #'car ps) custody ended ps)))))

(defun others-binding-acquires (node fork)
  "The binding DisputeAcquires by OTHER participants of the dispute our FORK is in: on the other
   forks of its ledger we hold, after our DisputeEnter, not naming us, judged (ACQUIRE-CONFIRMED-P)
   against the same vault as ours (the latest QuorumBegin before our DisputeEnter).  A list of
   (acquirer round claim-txid)."
  (let* ((enter (fork-op fork :dispute-enter))
         (q (and enter (record-latest fork :quorum-begin :below (up:update-seq enter))))
         (ours (and q (first (fr:rotation-rungs (op:update-op q))))))
    (%others-binding-acquires node (record-id-hex fork) (and enter (up:update-seq enter)) ours fork)))

(defun %others-binding-acquires (node id-hex enter-seq vault except)
  "OTHERS-BINDING-ACQUIRES for a dispute of ID-HEX entered at ENTER-SEQ on VAULT (its rung-0
   txid), over our forks of it but EXCEPT (also a superseded fork's, NOTE-SUPERSEDED)."
  (let ((us (node-pubkey node)))
    (when (and vault enter-seq)
      (loop for f in (forks-of node id-hex)
            for (u o) = (multiple-value-list (fork-op f :dispute-acquire))
            when (and o (not (eq f except))
                      (not (equalp (up:update-operator-id u) us))
                      (not (equalp (op:field o :new-custodian) us))
                      (> (up:update-seq u) enter-seq)
                      (equalp (first (first (fork-acquire-vaults f u))) vault)
                      (acquire-confirmed-p node f))
              collect (list (up:update-operator-id u) (or (acquire-round f) 1) (op:field o :claim-txid))))))

(defun yield-evidence-seen-p (node yield-op)
  "DEP-06 \"What a yield must say\": whether the transaction a DisputeYield names (:LOST-TO or
   :EXCLUDED-BY) is confirmed, so the yield counts.  A yield naming none (an earlier ruleset's, or
   :REESTABLISHED, checked when it was signed) counts as before; with no chain view, as
   published.  Only the confirmation is asked here: the full judgment is JUDGE-YIELD."
  (let ((txid (or (op:field yield-op :lost-to) (op:field yield-op :excluded-by))))
    (cond ((null txid) t)
          ((node-tx-fn node)
           (let ((c (nth-value 1 (ignore-errors (funcall (node-tx-fn node) txid)))))
             (and c (plusp c))))
          ((node-tx-confs-fn node)
           (let ((c (ignore-errors (funcall (node-tx-confs-fn node) txid)))) (and c (plusp c))))
          (t t))))

(defun fork-pledge-events (node fork)
  "FORK's own dispute operations as FORK-PLEDGES-HELD reads them, oldest first; its latest
   acquire binds by ACQUIRE-CONFIRMED-P."
  (let* ((us (loop for type in '(:dispute-enter :dispute-armed :dispute-yield :dispute-acquire)
                   append (remove-if-not (lambda (u) (equalp (up:update-operator-id u) (record-fork-operator fork)))
                                         (fork-own-updates fork type))))
         (us (sort (copy-list us) #'< :key #'up:update-seq))
         (last-acquire (find :dispute-acquire (reverse us) :key (lambda (u) (ignore-errors (op:update-type u))))))
    (loop for u in us
          for o = (op:update-op u)
          collect (ecase (op:operation-type o)
                    (:dispute-enter (list :enter))
                    (:dispute-armed (list :arm (and (op:field o :replacement-collateral-txid)
                                                    (outpoint-key (op:field o :replacement-collateral-txid)
                                                                  (op:field o :replacement-collateral-vout)))
                                          (or (op:field o :rearm-round) 1)))
                    ;; DEP-06 "An invalid yield is void": one naming a transaction not confirmed
                    ;; (YIELD-EVIDENCE-SEEN-P) frees no pledge; read as absent until it is.
                    (:dispute-yield (if (yield-evidence-seen-p node o) (list :yield) (list :void-yield)))
                    (:dispute-acquire (list :acquire (and (op:field o :claim-txid) (outpoint-key (op:field o :claim-txid) 0))
                                            (and (eq u last-acquire) (acquire-confirmed-p node fork) t)))))))

(defvar *rearm-pledge-reserve*
  (let ((v (ignore-errors (parse-integer (or (uiop:getenv "CLD_REARM_PLEDGE_RESERVE") "")))))
    (if (and v (>= v 0)) v 2))
  "Local policy, not DEP-03 (CLD_REARM_PLEDGE_RESERVE, default 2): a re-arm round (>= 2) of an old
   dispute pledges a new coin only while MORE than this many free coins cover its need, so the last
   ones stay for new disputes' round-1 arms, which may take them (not arming a new dispute is what
   dereliction is judged on).  Regtest 1121-next4c: deposits-rust ref6's re-arm passes spent 10 of
   the 14 coins the pledge-liveness fix freed.")

(defun claim-output-p (tx vout)
  "Whether output VOUT of TX is a lottery claim's output 0: a ledger's custody until it is spent
   (rotated into the ledger's vault), whatever our records say.  From TX alone: its input 0 spends
   output 0 of its prevout through a taproot SCRIPT path (the witness ends in a control block,
   33+32k bytes, leaf version #xc0) with nSequence #xfffffffd (a full claim) or the reveal CSV (a
   subset claim), and the coin is its ONE output (a confiscation spends the vault the same way
   with more outputs; a re-arm spend carries a tier CSV).  Regtest 1121-next4c (deposits-rust
   ref6): a claim of ad87b48b's lottery, recorded on another ledger's fork, was pledged on
   9e23c858; 14 of ref6's 31 coins were claim outputs and 7 were pledged.  Vector
   custody_coin.json."
  (let* ((ins (btx:tx-inputs tx))
         (in (and (plusp (length ins)) (elt ins 0)))
         (w (first (btx:tx-witnesses tx)))
         (cb (car (last w))))
    (and in (= vout 0) (= 1 (length (btx:tx-outputs tx)))
         (zerop (btx:txin-prev-index in))
         (>= (length w) 2) cb (>= (length cb) 33) (zerop (mod (- (length cb) 33) 32))
         (= (logand (aref cb 0) #xfe) #xc0)
         (member (btx:txin-sequence in) (list #xfffffffd lot:+reveal-csv+))
         t)))

(defvar *custody-coins* (make-hash-table :test #'equal :synchronized t)
  "\"txid:vout\" -> T when the coin is a claim's output 0 (CLAIM-OUTPUT-P), NIL when not: a
   transaction never changes.")

(defun claim-collateral-refusal (node coll)
  "Why a claim may not spend COLL (txid vout sats), our declared collateral, as its input 1, else
   NIL: it is a lottery claim's output 0 (CLAIM-OUTPUT-P), a ledger's custody, and the claim may
   spend no other coin instead (DEP-03 §Claim transaction); or its funding transaction cannot be
   read this pass.  With no TX-FN (a test node), NIL."
  (when (node-tx-fn node)
    (let ((tx (ignore-errors (funcall (node-tx-fn node) (first coll))))
          (key (outpoint-key (first coll) (second coll))))
      (cond ((null tx) (format nil "the funding transaction of our collateral ~a is unreadable; not claiming this pass" key))
            ((claim-output-p tx (second coll))
             (format nil "our declared collateral ~a is a lottery claim's output 0, a ledger's custody; a claim must spend the declared pledge and nothing else, so it is not built (re-arm with a fresh pledge, or arm the next round)" key))))))

(defun pledge-custody-rearm-p (node coll vault-unspent)
  "Our latest arm's declared pledge COLL must be replaced by a same-round re-arm (DEP-03
   §Eligibility snapshot: a re-arm replaces the declaration; its latest arm counts): it is a
   lottery claim's output 0, and VAULT-UNSPENT (no confiscation has fixed the set yet)."
  (and vault-unspent coll (node-tx-fn node)
       (let ((tx (ignore-errors (funcall (node-tx-fn node) (first coll)))))
         (and tx (claim-output-p tx (second coll)) t))))

(defun without-custody-coins (node utxos)
  "UTXOS (plists :txid :vout ...) without the coins that are a lottery claim's output 0, asked of
   NODE-TX-FN once per coin.  A coin whose funding transaction cannot be read this pass is left
   out too (pledging a ledger's custody loses depositors' funds; skipping a coin costs a retry);
   with no TX-FN (a test node) every coin is ordinary."
  (if (null (node-tx-fn node))
      utxos
      (remove-if
       (lambda (u)
         (let* ((key (outpoint-key (getf u :txid) (getf u :vout)))
                (verdict (multiple-value-bind (v found) (gethash key *custody-coins*)
                           (if found
                               v
                               (let ((tx (ignore-errors (funcall (node-tx-fn node) (getf u :txid)))))
                                 (if tx
                                     (setf (gethash key *custody-coins*) (claim-output-p tx (getf u :vout)))
                                     :unreadable))))))
           (case verdict
             (:unreadable (log! node "pledge: ~a left out this pass, its funding transaction is unreadable" key) t)
             ((nil) nil)
             (t (log! node "pledge: ~a (~a sats) is a lottery claim's output 0, a ledger's custody; never pledged"
                      key (getf u :sats))
                t))))
       utxos)))

(defun pledge-collateral (node id-hex &key (round 1))
  "A confirmed UTXO of ours, pledged to ID-HEX, covering its required replacement
   collateral: (txid vout sats), or NIL.  When no single UTXO is large enough but
   together they are, consolidate them (the result is pledgeable once confirmed)
   and return NIL for now; a pledge already made for ID-HEX is returned again.
   ROUND >= 2 (a re-arm round) leaves *REARM-PLEDGE-RESERVE* coins free (logged when it skips)."
  (let ((mine (loop for k being the hash-keys of (node-pledges node) using (hash-value v) when (equal v id-hex) collect k))
        (utxos (without-custody-coins node (our-utxos node))))
    (when mine
      (let ((u (find (first mine) utxos :key (lambda (u) (outpoint-key (getf u :txid) (getf u :vout))) :test #'equal)))
        (when u (return-from pledge-collateral (list (getf u :txid) (getf u :vout) (getf u :sats))))
        (remhash (first mine) (node-pledges node))))           ; spent or gone: pledge afresh
    (let* ((need (required-replacement-sats (or (find-record node id-hex) (fail "unknown ledger"))))
           ;; What our forks still hold (FORK-PLEDGES-HELD): the pledges of disputes that have
           ;; not ended for us, declared on the fork whether recorded in NODE-PLEDGES or not (an
           ;; arm made by hand, or before pledges were kept), and the custody of a binding claim of
           ;; ours (output 0 pays our own address, as our coins do, but it is a ledger's custody
           ;; until rotated: 1120-090836).  A yielded, tombstoned, acquired or retired dispute holds
           ;; nothing (regtest 1120-next4).
           (held (loop for r being the hash-values of (node-ledgers node)
                       when (and (record-fork-p r) (record-owned-p r))
                         collect (cons (record-fork-of r)
                                       (multiple-value-list
                                        (fork-pledges-held (fork-pledge-events node r)
                                                           :others (mapcar #'second (others-binding-acquires node r)))))))
           (declared (loop for h in held append (second h)))
           (custody (loop for h in held when (third h) collect (third h)))
           ;; A NODE-PLEDGES reservation is held until its dispute ends for us: released when our
           ;; fork concludes or is retired (RELEASE-PLEDGES), and not counted once our fork of it
           ;; has ended, even if the release was missed.  One with no fork yet is held.
           (reserved (loop for k being the hash-keys of (node-pledges node) using (hash-value v)
                           for h = (find v held :key #'first :test #'equal)
                           unless (and h (fourth h)) collect k))
           (keyed (loop for u in utxos collect (list* :key (outpoint-key (getf u :txid) (getf u :vout)) u)))
           ;; and what our superseded forks still hold: superseding ends no pledge (ruled 2026-11-24)
           (taken (append declared custody reserved (superseded-holds node)))
           (free (remove-if (lambda (u) (or (< (getf u :confirmations) (max 1 (node-min-confs node)))
                                            (member (getf u :key) taken :test #'equal)))
                            keyed))
           (reserve (if (>= round 2) *rearm-pledge-reserve* 0))
           (pick (pick-pledge keyed need (node-min-confs node) nil taken :reserve reserve)))
      (when (and (null pick) (plusp reserve) (pick-pledge keyed need (node-min-confs node) nil taken))
        (log! node "re-arm round ~a of ~a skipped for the reserve: ~a free coin~:p cover ~a sats, and a re-arm leaves the last ~a for new disputes (CLD_REARM_PLEDGE_RESERVE)"
              round (subseq id-hex 0 8)
              (count-if (lambda (u) (>= (getf u :sats) need)) free) need reserve)
        (return-from pledge-collateral nil))
      (cond (pick
             (let ((u pick))
               (setf (gethash (outpoint-key (getf u :txid) (getf u :vout)) (node-pledges node)) id-hex)
               (save-pledges node)
               (list (getf u :txid) (getf u :vout) (getf u :sats))))
            ((and (rest free) (>= (reduce #'+ free :key (lambda (u) (getf u :sats))) (+ need 1000)))
             (multiple-value-bind (txid vout sats) (consolidate-utxos node free)
               (log! node "collateral for ~a: consolidated ~a UTXOs into ~a:~a (~a sats), pledgeable once confirmed"
                     (subseq id-hex 0 8) (length free) (txid-hex txid) vout sats))
             nil)
            (t (log! node "collateral for ~a: need ~a sats at ~a, have ~a unpledged"
                     (subseq id-hex 0 8) need (our-target-address node) (reduce #'+ free :key (lambda (u) (getf u :sats))))
               nil)))))

;;; Key-path Taproot spend of our own P2TR (replacement collateral inputs).

(defun attach-key-path-witness (tx in-index sig)
  (let ((witnesses (let ((w (copy-list (btx:tx-witnesses tx)))) (setf (nth in-index w) (list sig)) w)))
    (btx:parse-tx (bw:make-reader
                   (btx:serialize-tx
                    (btx:make-tx :version (btx:tx-version tx) :inputs (btx:tx-inputs tx) :outputs (btx:tx-outputs tx)
                                 :locktime (btx:tx-locktime tx) :witnesses witnesses :segwit-p t))))))

(defun key-path-signature (node tx in-index prevouts &optional (root (octets)))
  "BIP-341 key-path signature for input IN-INDEX under our key tweaked by ROOT (empty: no tree;
   an offer or accept address commits a 32-byte root)."
  (let* ((xonly (up:x-only (node-pubkey node)))
         (n secp256k1-fast:*secp256k1-n*)
         (tweak (mod (be->int (tagged-hash "TapTweak" (cat xonly root))) n))   ; public
         (sighash (cl-consensus.script:taproot-sighash tx in-index prevouts 0 :ext-flag 0)))
    (multiple-value-bind (spk parity) (lot:p2tr-spk xonly root)
      (declare (ignore spk))
      ;; d = (d0 + t) mod n, negated when Q has odd Y; d0 = our key with even-Y P.
      (gossamer:with-fixed-scratch ((d :octets 32) (tw :octets 32))
        (secp256k1-fast:seckey-negate-into (node-priv node) d :negate (/= (aref (node-pubkey node) 0) 2))
        (replace tw (int->be tweak 32))
        (secp256k1-fast:seckey-tweak-add-into d tw d)
        (secp256k1-fast:seckey-negate-into d d :negate (= parity 1))
        (schnorr:schnorr-sign d sighash (random-aux))))))

;;; Fraud broadcasts (Kind 9101): verify, and if we are a member, dispute.

(defun repair-replica (node rec)
  "Rebuild REC's state from its history, one update per sequence along the chain, and forget
   the refusal, so catch-up resumes.  For a replica whose state disagrees with a replay."
  (with-replica-writer (rec)
    (let* ((seen (make-hash-table)) (chain '()))
      (dolist (u (reverse (record-history rec)))
        (unless (gethash (up:update-seq u) seen)
          (setf (gethash (up:update-seq u) seen) t) (push u chain)))
      (let ((chron (reverse chain)))
        (setf (record-ledger rec) (lg:replay chron)
              (record-history rec) chain
              ;; the replay just made is a checkpoint at the tip
              (record-checkpoints rec) (list (cons (lg:ledger-sequence (record-ledger rec)) (lg:copy-ledger (record-ledger rec))))
              (record-persisted rec) 0)        ; the next save rewrites the file
        (index-record rec))
      (remhash (record-id-hex rec) (node-refused node))
      (save-record node rec)
      (log! node "repaired ~a: replayed ~a updates to seq ~a" (subseq (record-id-hex rec) 0 8)
            (length chain) (lg:ledger-sequence (record-ledger rec))))))

(defun report-non-conforming (node rec update condition)
  ;; ADVERSARY :ignore-fraud — a passive derelict member: it refuses the bad update
  ;; (never applies it) but takes no dispute action, self-detected or received.
  (when (getf (node-adversary node) :ignore-fraud) (return-from report-non-conforming nil))
  "UPDATE passed every signature check on REC (operator, cosign threshold, chain)
   and the ledger rules reject it: publish a NonConformingUpdate proof and, as a
   quorum member, dispute from the last valid sequence.  A member that could only
   refuse such an update left the ledger's fraud to someone else — on the soak a
   majority-cosigned credit of twice the reserves went unreported by every
   replica that rejected it (docs/REDTEAM.md attack #1)."
  (let ((id (record-id-hex rec)) (ledger (record-ledger rec)))
    (when (and (not (record-owned-p rec)) (not (record-fork-p rec))
               (equalp (up:update-prev-hash update) (lg:ledger-chain-tip ledger))
               (> (up:update-seq update) (lg:ledger-sequence ledger))
               (not (blocking-fork node id t)))
      (log! node "NON-CONFORMING cosigned update on ~a at seq ~a: ~a" (subseq id 0 8) (up:update-seq update) condition)
      (let ((proof (fr:make-non-conforming-update-proof (up:update-operator-id update) (up:update-ledger-id update) update)))
        ;; A proof is what every verifier will judge, so judge it first as they will: from a
        ;; replay of the history, not from the replica that refused the update.  A replica can be
        ;; wrong (an update applied twice); a replay that accepts the update means the fault is
        ;; ours.  Repair the replica and accuse no one.
        (multiple-value-bind (ok why) (ignore-errors (fr:verify-proof proof :history (reverse (record-history rec))
                                                                             :prefix-ledger-fn (prefix-ledger-fn rec)))
          (unless ok
            (log! node "NOT REPORTED: our replica of ~a refused seq ~a (~a) but a replay of its history accepts it (~a): repairing the replica"
                  (subseq id 0 8) (up:update-seq update) condition why)
            (repair-replica node rec)
            (return-from report-non-conforming nil)))
        (broadcast-fraud node proof)
        (broadcast-cosigner-contagion node rec update)
        (when (and (member (node-pubkey node) (lg:ledger-quorum-members ledger) :key #'lg:member-pubkey :test #'equalp)
                   (not (blocking-fork node id t)))   ; the proof may have looped back and forked us already
          ;; DEP-19 §6: our DisputeEnter cites the proof; watch co-members who ignore it.
          (watch-derelicts node id proof
                           (enter-dispute node rec (lg:ledger-sequence ledger) :reason "non_conforming_update"
                                                                                :fraud-proof-hash (fr:proof-hash proof) :fraud-proof proof)))))))

;;; Contagion (DEP-19 §5-6).  A cosigner of a non-conforming update is slashable on
;;; every ledger it operates, by that ledger's own quorum.  Without it, signing a
;;; theft cost a colluder nothing (docs/TRUST-MODEL.md §2a: the difference between
;;; ~5% and ~30% collusion tolerated at Q = 7).

(defun ledgers-operated-by (node pubkey33 &key strict)
  "Ledger ids PUBKEY33 operates: its advertisements (Kind 39100, tag o) and our
   replicas of ledgers it operates.  Second value: NIL if the relay fetch failed (so the
   list may be incomplete); STRICT callers retry later instead of treating it as final."
  (declare (ignore strict))
  (let ((ids '()) (ok t))
    (dolist (e (handler-case (bus:bus-fetch (node-bus node)
                                            (flt:make-filter :kinds (list w:+kind-advertisement+)
                                                             :tags (list (cons "o" (list (bytes->hex pubkey33))))))
                 (error () (setf ok nil) '())))
      (let ((d (ev:first-tag-value e "d"))) (when (and d (= (length d) 64)) (pushnew d ids :test #'string=))))
    (loop for rec being the hash-values of (node-ledgers node)
          when (and (not (record-fork-p rec)) (equalp (lg:ledger-operator-key (record-ledger rec)) pubkey33))
            do (pushnew (record-id-hex rec) ids :test #'string=))
    (values ids ok)))

(defun governing-quorum-begin-seq (rec seq)
  (let ((qb (record-latest rec :quorum-begin :below (1+ seq))))   ; the latest at or before SEQ
    (and qb (up:update-seq qb))))

(defun contagion-target-p (node target)
  "Whether a contagion proof is still worth sending against ledger TARGET: not when we hold it and
   its vault is already confiscated (RESERVES-CONFISCATED-P, the test ENTER-DISPUTE refuses on).
   That dispute is over; a DisputeEnter on the proof now would take no part in it (DEP-03 §When the
   set is final), and one by a member that does not know that convicts a later round's armer.  On
   regtest (2026-11-21) our restart re-sent the proof against 12bc96d2, 10 767 blocks after its
   confiscation; deposits-rust ref6 entered on it and cut c30c1b29's round-2 arm."
  (let ((r (find-record node target)))
    (not (and r (not (record-fork-p r)) (reserves-confiscated-p node r)))))

(defun broadcast-cosigner-contagion (node rec update)
  "Everyone who signed the non-conforming UPDATE on REC, against every other ledger
   they operate: each cosigner, and the operator (DEP-19 §5; operator contagion
   puts the operator's whole collateral at stake, not just this ledger's).  Not against a ledger
   whose vault is already confiscated (CONTAGION-TARGET-P)."
  (let ((qb (governing-quorum-begin-seq rec (up:update-seq update))))
    (when qb
      (dolist (signer (cons (up:update-operator-id update) (mapcar #'up:cosig-pubkey (up:update-cosignatures update))))
        (dolist (target (remove-if-not (lambda (id) (contagion-target-p node id))
                                       (remove (record-id-hex rec) (ledgers-operated-by node signer) :test #'string=)))
          (log! node "contagion: ~a signed the fault on ~a; proof against its ledger ~a"
                (subseq (bytes->hex signer) 0 8) (subseq (record-id-hex rec) 0 8) (subseq target 0 8))
          (broadcast-fraud node (fr:make-non-conforming-cosignature-proof signer (hex->bytes target) update qb)))))))

(defun fault-prefix (node fault-id-hex fault)
  "The fault ledger's updates before FAULT, as FAULT's signed previous_hash pins them:
   walked back link by link from our replica or the relay.  Oldest first."
  (let* ((rec (find-record node fault-id-hex))
         (pool (if (and rec (not (record-fork-p rec))) (record-history rec) (ledger-updates-from-relays node fault-id-hex)))
         (by-chain (make-hash-table :test #'equalp)) (out '()))
    (dolist (u pool) (setf (gethash (up:chain-hash u) by-chain) u))
    (loop for u = (gethash (up:update-prev-hash fault) by-chain) then (gethash (up:update-prev-hash u) by-chain)
          while u do (push u out)
          until (zerop (up:update-seq u)))
    out))

(defun handle-cosigner-fraud (node proof)
  "A NonConformingCosignature: dispute every ledger we cosign whose operator is the
   accused, whichever of its ledgers the proof names."
  (let* ((accused (hex->bytes (getf proof :accused)))
         (targets (loop for rec being the hash-values of (node-ledgers node)
                        when (and (not (record-owned-p rec)) (not (record-fork-p rec))
                                  ;; the fault ledger itself is judged by its own proof, from before the fault
                                  (not (string= (record-id-hex rec) (getf (getf proof :evidence) :fault-ledger-id)))
                                  (equalp (lg:ledger-operator-key (record-ledger rec)) accused)
                                  (member (node-pubkey node) (lg:ledger-quorum-members (record-ledger rec)) :key #'lg:member-pubkey :test #'equalp)
                                  (not (blocking-fork node (record-id-hex rec) t)))
                          collect rec)))
    (when targets
      (let* ((fault (up:decode-update (hex->bytes (getf (getf proof :evidence) :fault-update-hex))))
             (prefix (fault-prefix node (getf (getf proof :evidence) :fault-ledger-id) fault)))
        (multiple-value-bind (ok why) (fr:verify-non-conforming-cosignature
                                        proof prefix :prefix-ledger-fn (prefix-ledger-fn (find-record node (getf (getf proof :evidence) :fault-ledger-id))))
          (if (not ok)
              (unless (judge-later-p node proof why)
                (log! node "contagion proof against ~a rejected: ~a" (subseq (getf proof :accused) 0 8) why))
              (dolist (rec targets)
                (log! node "contagion: ~a cosigned a non-conforming update on ~a; disputing its ledger ~a"
                      (subseq (getf proof :accused) 0 8) (subseq (getf (getf proof :evidence) :fault-ledger-id) 0 8) (subseq (record-id-hex rec) 0 8))
                (enter-dispute node rec (lg:ledger-sequence (record-ledger rec)) :reason "non_conforming_cosignature" :fraud-proof-hash (fr:proof-hash proof) :fraud-proof proof))))))))

(defun updates-of-ledger (node id-hex)
  "Every update we hold of ID-HEX — its own chain and each fork of it — or, holding none,
   what the relays have."
  (let ((rec (find-record node id-hex)))
    (if (and rec (not (record-fork-p rec)))
        ;; A fork shares its base's history up to its fork point: add only its own updates.
        (append (record-history rec)
                (loop for f in (forks-of node id-hex)
                      append (if (record-fork-base f)
                                 (loop for u in (record-history f) while (> (up:update-seq u) (record-fork-seq f)) collect u)
                                 (record-history f))))
        (ledger-updates-from-relays node id-hex))))

(defun watch-derelicts (node id-hex proof fork)
  "DEP-19 §6: we disputed ID-HEX on PROOF with FORK's DisputeEnter, which cites the proof and
   anchors it.  Watch the co-members who do not."
  (let ((enter (and fork (first (fork-own-updates fork :dispute-enter)))))
    (when enter
      (setf (gethash id-hex (node-derelict-watch node)) (list :proof proof :disclosure enter)))))

(defun governing-quorum-begin (rec seq)
  "REC's latest QuorumBegin at or before SEQ."
  (record-latest rec :quorum-begin :below (1+ seq)))

(defun report-derelict-members (node rec watch)
  "DEP-19 §6 / DEP-11.  We disputed REC on (getf WATCH :proof) with the DisputeEnter (getf WATCH
   :disclosure).  A co-member that cosigned REC at or after that disclosure and then kept operating
   a ledger it runs past its own dispute_response_blocks, without disputing REC, is derelict.  It is
   slashed on the ledgers it OPERATES (which have a quorum), found as contagion finds them
   (advertisements + our replicas), not on the quorumless member-ledger it cited when joining."
  (let* ((id (record-id-hex rec)) (proof (getf watch :proof)) (disc (getf watch :disclosure))
         (anchor (up:update-block-height disc))
         (lvs (op:field (op:decode-operation (up:update-message disc)) :last-valid-sequence))
         (qb (governing-quorum-begin rec lvs))
         (all nil)
         ;; Who acted is read from the disputes alone, not from every transfer on the chain.
         (acts (append (loop for type in '(:dispute-enter :dispute-armed) append (record-updates-of rec type))
                       (loop for f in (forks-of node id)
                             append (loop for type in '(:dispute-enter :dispute-armed) append (fork-own-updates f type))))))
    (when qb
      (dolist (mk (op:field (op:decode-operation (up:update-message qb)) :quorum-members))
        (let* ((vis (and (not (equalp mk (node-pubkey node)))
                         ;; the earliest at or above ANCHOR: heights never fall along the chain, so walk
                         ;; back from the tip only as far as ANCHOR
                         (let ((hit nil))
                           (loop for u in (record-history rec)
                                 while (>= (up:update-block-height u) anchor)
                                 when (find mk (up:update-cosignatures u) :key #'up:cosig-pubkey :test #'equalp)
                                   do (setf hit u))
                           hit)))
               (required (and vis (fr::member-response-blocks (reverse (record-updates-of rec :quorum-add-member)) mk (up:update-seq qb)))))
          (when (and vis (notany (lambda (u) (fr::acted-on-p u mk (hex->bytes id))) acts))
            (dolist (target (ledgers-operated-by node mk))
              (let* ((mrec (find-record node target))
                     (key (format nil "~a:~a:~a" target (bytes->hex mk) id))
                     (newest (and mrec (not (record-fork-p mrec))
                                  (find-if (lambda (u) (equalp (up:update-operator-id u) mk)) (record-history mrec)))))
                (when (and newest
                           (not (gethash key (node-reported-derelict node)))
                           (equalp (lg:ledger-operator-key (record-ledger mrec)) mk)   ; it operates target, we hold it
                           (>= (up:update-block-height newest) (+ (up:update-block-height vis) required)))
                  (let ((d (fr:make-dispute-dereliction-proof mk (hex->bytes target) proof disc qb vis newest)))
                    (multiple-value-bind (ok why)
                        (fr:verify-dispute-dereliction d (reverse (record-history mrec))
                                                       (or (node-height-of-block node) (lambda (h) (declare (ignore h)) (height node)))
                                                       :defrauded-updates (or all (setf all (updates-of-ledger node id))))
                      (if (not ok)
                          (log! node "not reporting ~a on ~a: our own dereliction proof does not verify: ~a"
                                (subseq (bytes->hex mk) 0 8) (subseq target 0 8) why)
                          (progn
                            (log! node "DERELICTION: ~a kept operating ~a ~a blocks past seeing ~a's fraud without disputing it"
                                  (subseq (bytes->hex mk) 0 8) (subseq target 0 8)
                                  (- (up:update-block-height newest) (up:update-block-height vis)) (subseq id 0 8))
                            (broadcast-fraud node d)
                            ;; marked only once published: a failed publish is retried on the next pass
                            (setf (gethash key (node-reported-derelict node)) t))))))))))))))

(defun node-derelict-watch-keys (node) (loop for k being the hash-keys of (node-derelict-watch node) collect k))

(defun drive-dereliction (node)
  "DEP-19 §6: for each ledger we disputed on a fraud proof, report co-members that stayed
   active past dispute_response_blocks without disputing it."
  (loop for id being the hash-keys of (node-derelict-watch node) using (hash-value w)
        for rec = (find-record node id)
        when (and rec (listp w) (getf w :disclosure)) do (ignore-errors (report-derelict-members node rec w))))

;;; Unauthorised vault spend (DEP-06).  A reserves outpoint is spent by its
;;; QuorumBegin's rotation, a recorded exit, or a confiscation.  Anything else that
;;; clears a tier's threshold is a theft by exactly the keys that signed it, and
;;; every one of them is slashable on every ledger it operates (contagion).

(defun note-confiscation (node id-hex txid)
  "Remember that TXID, a confiscation of ledger ID-HEX, confirmed (see known-confiscations)."
  (unless (member txid (gethash id-hex (node-known-confiscations node)) :test #'equalp)
    (push txid (gethash id-hex (node-known-confiscations node)))
    (when (node-data-dir node)
      (ignore-errors
       (with-open-file (out (merge-pathnames "confiscations.txt" (node-data-dir node))
                            :direction :output :if-exists :append :if-does-not-exist :create)
         (format out "~a ~a~%" id-hex (txid-hex txid)))))))

(defun load-known-confiscations (node)
  (let ((f (and (node-data-dir node) (probe-file (merge-pathnames "confiscations.txt" (node-data-dir node))))))
    (when f
      (with-open-file (in f)
        (loop for line = (read-line in nil) while line
              do (let ((sp (position #\Space line)))
                   (when sp (pushnew (reverse (hex->bytes (subseq line (1+ sp))))
                                     (gethash (subseq line 0 sp) (node-known-confiscations node)) :test #'equalp))))))))

;;; The lottery of a confirmed confiscation, kept across restarts.  Everything in it is public
;;; (the participants' keys, commitments and targets; the recovery voters), but rebuilding it
;;; after a restart means recomputing the eligibility cut from forks that may since have yielded,
;;; been retired, or re-armed, and that rebuild missed (signet soak 2026-11-07, 751e6951: cld7
;;; "won" a lottery off chain, its fellows concluded, and the output never re-armed).  A loaded
;;; lottery is used only when its script is literally output 0 of the confiscation it was saved
;;; with, so a stale or corrupt file can never stand in for the real one.

(defun confirmed-lottery-path (node id-hex)
  (and (node-data-dir node) (merge-pathnames (format nil "lottery_~a.sexp" (subseq id-hex 0 16)) (node-data-dir node))))

(defun save-confirmed-lottery (node id-hex tx lottery)
  (let ((path (confirmed-lottery-path node id-hex)))
    (when (and path tx lottery (not (probe-file path)))
      (ignore-errors
       (with-open-file (out path :direction :output :if-exists :supersede :if-does-not-exist :create)
         (with-standard-io-syntax
           (let ((*print-readably* nil))
             (prin1 (list :id id-hex :tx (bytes->hex (btx:serialize-tx tx))
                          :participants (loop for p in (lot:lottery-participants lottery)
                                              collect (list (bytes->hex (lot:participant-pubkey p))
                                                            (bytes->hex (lot:participant-commitment p))
                                                            (lot:participant-target p)))
                          :voters (mapcar #'bytes->hex (lot:lottery-recovery-voters lottery))
                          :threshold (lot:lottery-recovery-threshold lottery)
                          :network (string (intern (string-upcase (node-network node)) :keyword)))
                    out))))))))

(defun read-confirmed-lottery (path)
  "PATH's (id tx lottery) when its lottery's script is output 0 of its tx, or NIL."
  (ignore-errors
   (let* ((plist (with-open-file (in path) (with-standard-io-syntax (let ((*read-eval* nil)) (read in)))))
          (tx (btx:parse-tx (bw:make-reader (hex->bytes (getf plist :tx)))))
          (l (lot:build-lottery (loop for (pk c target) in (getf plist :participants)
                                      collect (lot:make-participant :pubkey (hex->bytes pk) :commitment (hex->bytes c) :target target))
                                (mapcar #'hex->bytes (getf plist :voters))
                                (getf plist :threshold)
                                :network (intern (getf plist :network) :keyword))))
     (and (equalp (lot:lottery-spk l) (btx:txout-script (first (btx:tx-outputs tx))))
          (list (getf plist :id) tx l)))))

(defun load-confirmed-lotteries (node)
  "Every saved confirmed lottery back among the confiscations we signed (CONFISCATED-LOTTERY
   reads those first), so a restart neither rebuilds nor loses it."
  (when (node-data-dir node)
    (dolist (f (directory (merge-pathnames "lottery_*.sexp" (node-data-dir node))))
      (destructuring-bind (&optional id tx l) (read-confirmed-lottery f)
        (when (and id tx l)
          (unless (find (btx:tx-txid tx) (gethash id (node-signed-confiscations node)) :key (lambda (e) (btx:tx-txid (car e))) :test #'equalp)
            (push (cons tx l) (gethash id (node-signed-confiscations node))))
          (note-confiscation node id (btx:tx-txid tx)))))))

(defun reserves-confiscated-p (node rec)
  "REC's reserves are spent and we know a confirmed confiscation of its ledger: no vault is left
   to dispute.  A later custodian's reserves are a new outpoint, unspent, so this is NIL for them."
  (and rec (node-chain-fn node)
       (gethash (record-id-hex rec) (node-known-confiscations node))
       (multiple-value-bind (r txid vout) (ignore-errors (disputed-reserves node rec))
         (and r txid (not (funcall (node-chain-fn node) txid vout))))))

;;; DEP-06 §Spend challenge.  A vault spend is judged by its anchor H (its last output): none is
;;; theft on its face; with one, H names the one place in the ledger that must answer for it.  A
;;; judge looks for the answer among everything it holds of the spent ledger, the relay's copies,
;;; and the answers others published (Kind 9112).  Finding nothing proves nothing: the judge
;;; challenges (QuorumChallenge on its own ledger, Kind 9111) and proves the spend only when the
;;; challenge lapses unanswered.

(defun relay-updates-past (node id-hex from &key (page 200) (max-pages 1000))
  "Every update the relays hold of ID-HEX at sequence FROM or later, a page of sequences at a
   time until a page comes back empty."
  (loop for lo from from by page repeat max-pages
        for got = (ledger-updates-from-relays node id-hex :from lo :to (+ lo page -1))
        while got append got))

(defun spend-answer-updates (node id-hex gseq &optional anchor)
  "Everything we can find of ID-HEX past its QuorumBegin at GSEQ that could answer a spend anchored
   at ANCHOR: our replica, the relay's copies (signals when the relay holds nothing at all of the
   ledger, so the caller judges later), and the answers published to challenges of it.  When our
   replica holds the update ANCHOR names, only the sequence after it is read (an answer is that
   update's child); otherwise the relay is read past our own tip, since anything at or below it we
   hold.  Reading every update past an old QuorumBegin, page by page, was hundreds of relay round
   trips per judgement on a soaked ledger."
  (let* ((rec (find-record node id-hex))
         (base (and rec (not (record-fork-p rec)) rec))
         (k (and base anchor (record-seq-of-hash base anchor)))
         (history (cond ((null base) nil)
                        (k (let ((u (record-update-at base (1+ k)))) (and u (list u))))
                        (t (loop for u in (record-history base) while (> (up:update-seq u) gseq) collect u))))
         ;; FAULT :blind-relay (a ledger id prefix): we read none of that ledger's updates on the
         ;; relay, only our replica and published answers (redteam/check-rotation-lag.sh)
         (blind (relay-blind-p node id-hex))
         (relay (and (not blind)
                     (if k
                         (ledger-updates-from-relays node id-hex :from (1+ k) :to (1+ k))
                         (relay-updates-past node id-hex (1+ (max gseq (if base (lg:ledger-sequence (record-ledger base)) gseq))))))))
    (unless (or blind relay (ledger-updates-from-relays node id-hex :from gseq :to gseq))
      (error "the relay holds nothing of ~a at ~a" (subseq id-hex 0 8) gseq))
    (append history relay (gethash id-hex (node-spend-answers node)))))

(defun spend-answered-p (node id-hex tx gseq reserves tier-index &key spend-height prevouts)
  "DEP-06 §Spend challenge: TX's spend of ID-HEX's vault (under the QuorumBegin at GSEQ, its
   witness at TIER-INDEX of RESERVES) has an answer we can find: the QuorumBegin that is the child
   of its anchor and names it (FR:ROTATION-ANSWER), or the confiscation the rules rebuild from
   public state.  NIL for an unanchored spend.  Signals when we cannot read the relay."
  (let ((anchor (rot:anchor-of tx))
        (*judged-spend* (if prevouts (cons tx (coerce prevouts 'list)) *judged-spend*)))
    (when anchor
      (let ((updates (spend-answer-updates node id-hex gseq anchor)))
        (or (let ((ans (fr:rotation-answer updates anchor (btx:tx-txid tx) reserves tier-index)))
              (when ans
                (multiple-value-bind (keys need) (fr:answer-cosign-need reserves tier-index)
                  (when (< (fr:tier-cosignatures ans keys) need)
                    (log! node "vault spend ~a of ~a: answered by rotation seq ~a at the ledger's recorded threshold, below the tier floor (~a of ~a; strict-lottery-v8)"
                          (subseq (txid-hex (btx:tx-txid tx)) 0 16) (subseq id-hex 0 8) (up:update-seq ans)
                          (fr:tier-cosignatures ans keys) need))))
              ans)
            ;; A rung of a confiscation we signed: we checked it byte for byte against our own rebuild
            ;; before signing (HANDLE-CONFISCATION-SIGN), so we never challenge it.  A rebuild from the
            ;; relay later can miss (arms it has not delivered, a cut it judges otherwise): Nov 4 soak,
            ;; a member challenged rung 1 of a confiscation it had signed, and the challenge lapsed.
            (find (btx:tx-txid tx) (gethash id-hex (node-signed-confiscations node))
                  :key (lambda (e) (btx:tx-txid (car e))) :test #'equalp)
            (rebuilt-confiscation-p node id-hex tx :spend-height spend-height
                                                   :updates-fn (lambda ()
                                                                 ;; Our own base chain too: an answer carries
                                                                 ;; only the dispute's updates, and a judge whose
                                                                 ;; relay lacks the ledger rebuilt from them alone,
                                                                 ;; with no LedgerOpen, and could never accept it
                                                                 ;; (regtest confiscation-answer, 2026-11-04).
                                                                 (distinct-updates
                                                                  (append (unless (relay-blind-p node id-hex)
                                                                            (ledger-updates-from-relays node id-hex))
                                                                          (let ((r (find-record node id-hex)))
                                                                            (and r (not (record-fork-p r)) (record-history r)))
                                                                          updates)))))))))

(defun distinct-updates (updates)
  "UPDATES without repeats (by chain hash), first occurrence kept."
  (let ((seen (make-hash-table :test #'equalp)))
    (remove-if-not (lambda (u) (let ((k (up:chain-hash u))) (unless (gethash k seen) (setf (gethash k seen) t))))
                   updates)))

(defun refresh-spend-answers (node id-hex)
  "Read the answers (Kind 9112) the relays hold to challenges of ID-HEX's spends into our store, so
   a judgement sees every answer published, not only those our subscription delivered."
  (dolist (e (ignore-errors (bus:bus-fetch (node-bus node)
                                           (flt:make-filter :kinds (list w:+kind-challenge-answer+)
                                                            :tags (list (cons "d" (list (subseq id-hex 0 16))))))))
    (handle-challenge-answer node e)))

(defun answers-readable-p (node id-hex gseq)
  "DEP-06 §Spend challenge: whether we can read the places answers to a challenge of ID-HEX's spend
   go: the relays (they hold the spent ledger at its governing QuorumBegin GSEQ) and our own store.
   A judge that cannot reaches no verdict on a lapse."
  (and (not (relay-blind-p node id-hex))
       (ledger-updates-from-relays node id-hex :from gseq :to gseq)
       t))

(defun authorised-spend-p (node rec tx &key spend-height)
  "DEP-06 §Spend challenge: TX's spend of one of REC's vaults is answered (a rotation naming it,
   or the confiscation the rules rebuild from public state).  The tier is read from TX's witness
   leaf (0 when unsigned)."
  (loop for u in (record-updates-of rec :quorum-begin)
        thereis (and (multiple-value-bind (reserves rungs vout) (fr:spent-vault (spent-vault-updates rec) (up:update-seq u))
                       (let ((i (and reserves (position-if (lambda (in) (and (member (btx:txin-prev-hash in) rungs :test #'equalp)
                                                                             (= (btx:txin-prev-index in) vout)))
                                                           (btx:tx-inputs tx)))))
                         (when i
                           (let* ((stack (nth i (btx:tx-witnesses tx)))
                                  (tier (or (and (>= (length stack) 3) (position (nth (- (length stack) 2) stack) (rs:reserves-leaves reserves) :test #'equalp)) 0)))
                             (spend-answered-p node (record-id-hex rec) tx (up:update-seq u) reserves tier :spend-height spend-height))))))))

(defun open-spend-challenge (node e)
  "Record the challenge of owed entry E's anchored spend on our own ledger (QuorumChallenge,
   cosigned as any update) and publish it (Kind 9111).  Returns the challenge update, or NIL when
   we hold no ledger of our own to record it on."
  (let ((own (and (node-member-ledger-hex node) (find-record node (node-member-ledger-hex node)))))
    (when (and own (record-owned-p own))
      (let* ((tx (btx:parse-tx (bw:make-reader (hex->bytes (getf e :tx)))))
             (u (append-operation node own (list :type :quorum-challenge
                                                 :challenged-ledger-id (hex->bytes (getf e :id))
                                                 :challenged-txid (btx:tx-txid tx)
                                                 :challenged-anchor (rot:anchor-of tx)))))
        (bus:bus-publish (node-bus node) (w:spend-challenge-event (node-keypair node) (getf e :id) (bytes->hex (btx:tx-txid tx))
                                                                  (bytes->hex (rot:anchor-of tx)) (base64-encode (up:encode-update u))))
        u))))

(defun handle-spend-challenge (node event)
  "Kind 9111: a challenge of a spend of a vault we follow.  If we hold its answer (the rotation's
   QuorumBegin, or the confiscation's dispute on our fork), publish it (Kind 9112): anyone may
   answer, not only the accused."
  (ignore-errors
   (let* ((c (w:parse-json (ev:event-content event)))
          (id (w:jget c "challenged_ledger_id"))
          (txid (hex->bytes (w:jget c "txid"))) (anchor (hex->bytes (w:jget c "anchor")))
          (rec (find-record node id)))
     (when (and rec (not (record-fork-p rec)))
       (let ((answer (find-if (lambda (u) (let ((o (ignore-errors (op:update-op u))))
                                            (and o (equalp (up:update-prev-hash u) anchor)
                                                 (member txid (fr:rotation-rungs o) :test #'equalp))))
                              (record-updates-of rec :quorum-begin)))
             (fork (or (find-if (lambda (f) (or (and (record-confiscation f) (equalp (btx:tx-txid (record-confiscation f)) txid))
                                                ;; DEP-03 §Confiscation ladder: a rung of one we signed
                                                (find txid (gethash id (node-signed-confiscations node)) :key (lambda (e) (btx:tx-txid (car e))) :test #'equalp)))
                                (forks-of node id))
                       ;; Any holder answers (DEP-06), signer or not: a rung of our own rebuild at any tier.
                       (and (forks-of node id) (rebuilt-rung-p node id txid) (first (forks-of node id))))))
         ;; DEP-03 §Arm manifests: answering is permissionless.  Any node that holds a manifest
         ;; of the ledger's round 1 (its own, or one it heard) publishes it; the judge checks it
         ;; from public state, whoever sent it.
         (relay-arm-manifests node id txid anchor)
         (cond (answer
                (log! node "answering the challenge of ~a's spend ~a: its rotation's QuorumBegin (seq ~a)"
                      (subseq id 0 8) (subseq (bytes->hex txid) 0 16) (up:update-seq answer))
                (bus:bus-publish (node-bus node) (w:challenge-answer-event (node-keypair node) id (bytes->hex txid) (bytes->hex anchor)
                                                                           (list (base64-encode (up:encode-update answer))))))
               (fork
                (log! node "answering the challenge of ~a's spend ~a: its confiscation's dispute" (subseq id 0 8) (subseq (bytes->hex txid) 0 16))
                ;; Every disputant's updates we hold, not only our own fork's: a judge that missed
                ;; some arms rebuilds the same lottery from them.
                (bus:bus-publish (node-bus node) (w:challenge-answer-event (node-keypair node) id (bytes->hex txid) (bytes->hex anchor)
                                                                           (remove-duplicates
                                                                            (loop for f in (forks-of node id)
                                                                                  append (mapcar (lambda (u) (base64-encode (up:encode-update u)))
                                                                                                 (remove-if (lambda (u) (equalp (up:update-operator-id u)
                                                                                                                                (lg:ledger-operator-key (record-ledger rec))))
                                                                                                            (fork-own-segment f))))
                                                                            :test #'string=))))))))))

(defun relay-arm-manifests (node id-hex txid anchor)
  "Publish, as Challenge Answers to the challenge of TXID, every round-1 arm manifest we hold of
   ID-HEX (DEP-03 §Arm manifests: permissionless, checked by the judge).  The number published."
  (let ((ms (arm-manifests-of node id-hex 1)))
    (dolist (m ms (length ms))
      (bus:bus-publish (node-bus node)
                       (w:challenge-answer-event (node-keypair node) id-hex (bytes->hex txid) (bytes->hex anchor) '()
                                                 :round 1 :arms (mapcar (lambda (a) (list (bytes->hex (first a)) (second a))) m)))
      (log! node "answering the challenge of ~a's spend ~a: an arm manifest (~a arms)" (subseq id-hex 0 8)
            (subseq (bytes->hex txid) 0 16) (length m)))))

(defun rebuilt-rung-p (node id-hex txid)
  "TXID is a rung of the confiscation of ID-HEX we rebuild from what we hold, at any confiscation tier."
  (let ((reserves (ignore-errors (disputed-reserves node (find-record node id-hex)))))
    (and reserves
         (loop for tier in (rs:reserves-tiers reserves) for ti from 0
               thereis (and (not (rs:tier-tie-breaker-p tier))
                            (let ((rungs (ignore-errors (nth-value 5 (build-confiscation node id-hex :tier-index ti :respectful (dispute-respectful-p node id-hex))))))
                              (find txid rungs :key #'btx:tx-txid :test #'equalp)))))))

(defun handle-challenge-answer (node event)
  "Kind 9112: keep the updates answering a challenge, for every later judgement of that ledger's
   spends, and the arm manifest it carries (DEP-06 §Arm manifests)."
  (ignore-errors
   (let* ((c (w:parse-json (ev:event-content event)))
          (id (w:jget c "challenged_ledger_id"))
          (arms (loop for a in (coerce (or (w:jget c "arms") #()) 'list)
                      for k = (ignore-errors (hex->bytes (w:jget a "armer")))
                      for q = (w:jget a "seq")
                      when (and k (= (length k) 33) (integerp q)) collect (list k q))))
     (when (and arms (stringp id))
       (note-arm-manifest node id (or (w:jget c "round") 1) (w:jget c "txid") arms))
     (let* ((c c) (id id)
          (updates (loop for b in (coerce (or (w:jget c "updates") #()) 'list)
                         for u = (ignore-errors (up:decode-update (base64-decode b)))
                         when (and u (equalp (up:update-ledger-id u) (hex->bytes id))) collect u)))
     (when updates
       (let ((have (gethash id (node-spend-answers node))))
         (dolist (u updates)
           (unless (member (up:chain-hash u) have :key #'up:chain-hash :test #'equalp) (push u have)))
         (setf (gethash id (node-spend-answers node)) (subseq have 0 (min 64 (length have))))))))))

(defun note-arm-manifest (node id-hex round txid-hex arms)
  "Keep a published arm manifest (at most 32 distinct per ledger)."
  (let* ((e (list round txid-hex (sort (copy-list arms) #'bytes< :key #'first)))
         (have (gethash id-hex (node-arm-manifests node))))
    (unless (member e have :test #'equalp)
      (setf (gethash id-hex (node-arm-manifests node)) (subseq (cons e have) 0 (min 32 (1+ (length have))))))))

(defun arm-manifests-of (node id-hex round &key refresh)
  "The distinct arm sets published for ID-HEX's ROUND (REFRESH: read the relays' answers first)."
  (when refresh (ignore-errors (refresh-spend-answers node id-hex)))
  (remove-duplicates (loop for (r nil arms) in (gethash id-hex (node-arm-manifests node)) when (eql r round) collect arms)
                     :test #'equalp))

(defun lottery-manifest (node id-hex lottery &key (round 1) until window)
  "The arm set LOTTERY was built from: per participant, the arm (pubkey33 seq) whose key and
   commitment it carries, among each armer's counted arms of ROUND signed at or below UNTIL, or
   inside WINDOW (opens . closes) for a re-arm round."
  (let ((arms (remove-if (lambda (a) (or (not (eql (seventh a) round)) (and until (> (fifth a) until))
                                         (and window (not (and (< (car window) (fifth a)) (<= (fifth a) (cdr window)))))))
                         (let ((by (make-hash-table :test #'equalp)))
                           (dolist (a (%all-arms node id-hex)) (push a (gethash (first a) by)))
                           (loop for l being the hash-values of by
                                 append (let ((s (sort (copy-list l) #'< :key #'sixth))) (subseq s 0 (min +max-arms+ (length s)))))))))
    (loop for p in (lot:lottery-participants lottery)
          for a = (car (last (sort (remove-if-not (lambda (a) (and (equalp (up:x-only (first a)) (lot:participant-pubkey p))
                                                                  (equalp (second a) (lot:participant-commitment p))
                                                                  (equal (third a) (lot:participant-target p))))
                                                  arms)
                                   #'< :key #'sixth)))
          unless a do (return nil)
          collect (list (first a) (sixth a)))))

(defun publish-arm-manifest (node id-hex tx lottery &key (round 1) until window)
  "DEP-06 §Arm manifests: publish the arm set LOTTERY (in TX, a confiscation or a re-arm spend into
   ROUND, its arms in WINDOW) was built from, as a Challenge Answer (Kind 9112), once per txid;
   strict-lottery-v8 only."
  ;; TX may be unsigned (no witnesses): its txid from its witness-free bytes.
  (let ((txid (bytes->hex (btx:tx-txid (btx:parse-tx (bw:make-reader (btx:serialize-tx tx :witness nil)))))))
    (when (and (lg:ruleset-rule-p (ruleset-at-fork-point node id-hex) :strict-lottery)
               (not (find txid (gethash id-hex (node-arm-manifests node)) :key #'second :test #'equal)))
      (let ((arms (lottery-manifest node id-hex lottery :round round :until until :window window)))
        (if (null arms)
            (log! node "arm manifest of ~a's ~a: no arm set for its lottery" (subseq id-hex 0 8) (subseq txid 0 16))
            (progn
              (note-arm-manifest node id-hex round txid arms)
              (bus:bus-publish (node-bus node)
                               (w:challenge-answer-event (node-keypair node) id-hex txid (bytes->hex (or (ignore-errors (rot:anchor-of tx)) #()))
                                                         '() :round round
                                                         :arms (mapcar (lambda (a) (list (bytes->hex (first a)) (second a))) arms)))
              (log! node "published the arm manifest of ~a's ~a (round ~a): ~{~a~^ ~}" (subseq id-hex 0 8) (subseq txid 0 16) round
                    (mapcar (lambda (a) (format nil "~a/~a" (subseq (bytes->hex (first a)) 0 8) (second a))) arms))))))))

(defparameter *vault-spend-grace-blocks* 3
  "A rotation's QuorumBegin may reach us a block or two after the spend confirms, so a
   spend is judged only once it is this deep.")
(defparameter *vault-scan-depth* 30 "Blocks before our first scan to look back over.")

(defparameter *vault-spend-publish-blocks* 144
  "Blocks after a theft's block during which we keep (re)publishing its proofs: to targets a
   relay error hid, and to ledgers its signers start advertising later.")

(defun vault-watch-file (node) (and (node-data-dir node) (merge-pathnames "vault-watch.sexp" (node-data-dir node))))

(defun save-vault-watch (node)
  "Persist the scan height and every theft we still owe proofs for (write beside, rename)."
  (let ((f (vault-watch-file node)))
    (when f
      (ensure-directories-exist f)
      (let ((tmp (make-pathname :type "tmp" :defaults f))
            (plist (list :scanned (node-vault-scanned node)
                         :spends (loop for k being the hash-keys of (node-reported-vault-spend node) using (hash-value v)
                                       collect (cons k v)))))
        (with-open-file (out tmp :direction :output :if-exists :supersede)
          (with-standard-io-syntax (let ((*print-readably* nil)) (prin1 plist out))))
        (uiop:rename-file-overwriting-target tmp f)))))

(defun load-vault-watch (node)
  (let ((f (vault-watch-file node)))
    (when (and f (probe-file f))
      (let ((plist (ignore-errors (with-open-file (in f) (with-standard-io-syntax (read in))))))
        (when plist
          (setf (node-vault-scanned node) (getf plist :scanned))
          (dolist (e (getf plist :spends)) (setf (gethash (car e) (node-reported-vault-spend node)) (cdr e))))))))

(defun vault-watch-targets (node)
  "((rec qb-seq txid vout) ...): for every base ledger we hold, the vaults of its latest two
   QuorumBegins."
  (let ((out '()))
    (loop for rec being the hash-values of (node-ledgers node)
          unless (record-fork-p rec)
            do (ignore-errors
                (let ((qbs (mapcar #'up:update-seq (record-updates-of rec :quorum-begin))))
                  (dolist (seq (subseq qbs 0 (min 2 (length qbs))))
                    ;; DEP-03 §Fee ladder: output 0 of every rung (only one can confirm)
                    (multiple-value-bind (reserves rungs vout) (fr:spent-vault (spent-vault-updates rec) seq)
                      (when reserves (dolist (txid rungs) (push (list rec seq txid vout) out))))))))
    out))

(defun drive-vault-watch (node)
  "Scan the blocks that are now GRACE deep for spends of any vault outpoint we replicate.
   A spend its ledger's history does not account for becomes an owed theft record (keyed by
   ledger and spending txid, persisted) BEFORE the scan height moves past it; each pass then
   (re)publishes an UnauthorizedVaultSpend against each signer on each ledger that signer
   operates, until every target found has its proof and the publish window has passed.  A spend
   we could not judge holds the scan height below its block, so the next pass retries it."
  (when (node-spender-fn node)
    (let* ((to (- (height node) *vault-spend-grace-blocks*))
           (from (or (and (node-vault-scanned node) (1+ (node-vault-scanned node))) (max 0 (- to *vault-scan-depth*))))
           (watched (make-hash-table :test #'equalp)) (outpoints '()) (hold nil) (dirty nil))
      (when (>= to from)
        ;; The current vault, and the one before it: a QuorumBegin is recorded before its
        ;; rotation confirms (DEP-03), so the old vault stays watched until it is spent by
        ;; that rotation (authorised) or by anything else (theft under the old quorum).
        (loop for (rec seq txid vout) in (vault-watch-targets node)
              do (push (cons rec seq) (gethash (cons txid vout) watched))
                 (pushnew (cons txid vout) outpoints :test #'equalp))
        (dolist (spend (funcall (node-spender-fn node) from to outpoints))
          (dolist (w (gethash (cons (getf spend :txid) (getf spend :vout)) watched))
            (destructuring-bind (rec . qb-seq) w
            (handler-case (when (note-vault-spend node rec spend qb-seq) (setf dirty t))
              (error (e)
                (log! node "vault watch on ~a: ~a (retrying)" (subseq (record-id-hex rec) 0 8) e)
                (let ((h (getf spend :height))) (when h (setf hold (min (or hold h) h)))))))))
        (setf (node-vault-scanned node) (if hold (min to (1- hold)) to))
        (setf dirty t))
      (when (publish-owed-vault-spends node) (setf dirty t))
      (when dirty (ignore-errors (save-vault-watch node))))))

(defun drive-obligation-watch (node)
  "DEP-06 §Confiscation obligations: for each ledger we hold whose custody changed after a
   confiscation, for each obligation it owed — a migration dangling at the acquire, or a payment
   recorded on its history's forks (ObligationRecord) — once the new operator signs an update its
   service_response_blocks past the acquire without crediting the residue, broadcast
   UnhonouredObligation against it (once each)."
  (loop for base being the hash-values of (node-ledgers node)
        ;; the ledger's chain after a custody change: a replica that followed it, or the fork
        ;; that acquired it (we keep the winner's chain as its fork)
        for rec = (and (not (record-fork-p base)) (or (ledger-chain-record node (record-id-hex base)) base))
        for l = (and rec (record-ledger rec))
        when (and l (lg:ledger-confiscation-txid l))
          do (handler-case
                 (let* ((history nil)   ; the whole chain, built only when a candidate needs a proof
                        (au (record-latest rec :dispute-acquire))
                        (conf (find (lg:ledger-confiscation-txid l)
                                    (loop for f in (forks-of node (record-id-hex rec)) when (record-confiscation f) collect (record-confiscation f))
                                    :key #'btx:tx-txid :test #'equalp))
                        (a (lg:ledger-dormancy-accept l))
                        (candidates '()))
                   (when (and au conf)
                     (when (and a (not (getf a :resolved)) (getf a :source))
                       (multiple-value-bind (nu qu) (migration-source-updates node a (bytes->hex (getf a :source)))
                         (when qu (push (list (format nil "obligation:~a:migration" (record-id-hex rec)) :notice-update nu :qb-update qu) candidates))))
                     (dolist (u (reverse (record-updates-of rec :obligation-record)))
                       (let ((o (ignore-errors (op:update-op u))))
                         (when (and o (op:field o :uncredited-proof)
                                    (< (up:update-seq u) (up:update-seq au)))
                           (push (list (format nil "obligation:~a:~a" (record-id-hex rec) (bytes->hex (sha256 (op:field o :uncredited-proof))))
                                       :uncredited-proof (bytes->ascii (op:field o :uncredited-proof)))
                                 candidates))))
                     (dolist (c candidates)
                       (destructuring-bind (key &rest args) c
                         (unless (gethash key (node-migrations-watched node))
                           (unless history (setf history (reverse (record-history rec))))
                           (let ((proof (apply #'fr:unhonoured-obligation-proof history au conf args)))
                             (when proof
                               (multiple-value-bind (ok why)
                                   (fr:verify-proof proof :history history
                                                          :height-of-block (or (node-height-of-block node) (lambda (b) (declare (ignore b)) (height node))))
                                 (if ok
                                     (progn (setf (gethash key (node-migrations-watched node)) :done)
                                            (log! node "UNHONOURED OBLIGATION: ~a's new operator left an obligation's residue uncredited; proof broadcast"
                                                  (subseq (record-id-hex rec) 0 8))
                                            (broadcast-fraud node proof)
                                            (ignore-errors (dispute-new-operator node rec proof)))
                                     (log! node "unhonoured-obligation proof on ~a does not verify: ~a" (subseq (record-id-hex rec) 0 8) why))))))))))
               (error (e) (log! node "obligation watch on ~a: ~a" (subseq (record-id-hex rec) 0 8) e)))))

(defun drive-migration-watch (node)
  "DEP-20 §8.3: for each ledger we hold whose latest rotation migrated deposits, note the block
   the migration output confirmed in (while it is still unspent), and once the receiver has signed
   an update its own service_response_blocks later without crediting every migrated entry,
   broadcast the UncreditedOnchainPayment proof against it."
  (loop for rec being the hash-values of (node-ledgers node)
        unless (record-fork-p rec)
          do (let ((source (sort (append (record-updates-of rec :quorum-begin) (record-updates-of rec :dormancy-notice))
                                 #'< :key #'up:update-seq)))   ; what LATEST-MIGRATION reads; the full chain only for a proof
               (multiple-value-bind (qu nu qb) (fr:latest-migration source)
                 (let* ((key (and qu (format nil "~a:~a" (record-id-hex rec) (up:update-seq qu))))
                        (seen (and key (gethash key (node-migrations-watched node)))))
                   (when (and qu (not (eq seen :done)))
                     (handler-case
                         (let* ((txid (op:field qb :new-outpoint-txid)) (vout (op:field qb :migration-vout))
                                (conf (or seen
                                          (let ((info (and (node-chain-fn node) (funcall (node-chain-fn node) txid vout))))
                                            (when (and info (plusp (or (getf info :confirmations) 0)) (node-block-hash-fn node))
                                              (let* ((h (- (height node) (getf info :confirmations) -1))
                                                     (b (funcall (node-block-hash-fn node) h)))
                                                (when b (setf (gethash key (node-migrations-watched node)) (list :height h :hash b)))))))))
                           (when conf
                             (let* ((au (up:decode-update (op:field (op:decode-operation (up:update-message nu)) :dormancy-accept)))
                                    (rid (bytes->hex (up:update-ledger-id au)))
                                    (rrec (find-record node rid))
                                    (rhist (if (and rrec (not (record-fork-p rrec))) (reverse (record-history rrec)) (ledger-updates-from-relays node rid)))
                                    (proof (fr:uncredited-migration-proof (reverse (record-history rec)) rhist (getf conf :hash) (getf conf :height))))
                               (cond (proof
                                      (multiple-value-bind (ok why)
                                          (fr:verify-proof proof :history rhist
                                                                 :height-of-block (or (node-height-of-block node) (lambda (b) (declare (ignore b)) (height node))))
                                        (if ok
                                            (progn (log! node "UNCREDITED MIGRATION: ~a has not credited ~a's migration; proof broadcast"
                                                         (subseq rid 0 8) (subseq (record-id-hex rec) 0 8))
                                                   (setf (gethash key (node-migrations-watched node)) :done)
                                                   (broadcast-fraud node proof))
                                            (log! node "uncredited-migration proof against ~a does not verify: ~a" (subseq rid 0 8) why))))
                                     ;; nothing late enough yet, or all credited: done only when all are
                                     ((and rhist (multiple-value-bind (q n qbo) (fr:latest-migration source)
                                                   (declare (ignore q n))
                                                   (fr::migration-credited-p qbo rhist (up:update-seq (car (last rhist)))
                                                                             (op:field qbo :new-outpoint-txid) (op:field qbo :migration-vout))))
                                      (setf (gethash key (node-migrations-watched node)) :done))))))
                       (error (e) (log! node "migration watch on ~a: ~a" (subseq (record-id-hex rec) 0 8) e)))))))))

(defun vault-spend-key (id-hex txid) (format nil "~a:~a" id-hex (txid-hex txid)))

(defun note-vault-spend (node rec spend &optional qb-seq)
  "DEP-06: judge SPEND of REC's vault (under the QuorumBegin at QB-SEQ, default the latest).
   Answered (a rotation or confiscation names it): nothing.  Unanchored: an owed theft, proven at
   once.  Anchored and unanswered: an owed challenge, never a proof until it lapses.  T when newly
   recorded; signals (the scan retries) when we cannot read the relay."
  (let* ((id (record-id-hex rec))
         (tx (btx:parse-tx (bw:make-reader (hex->bytes (getf spend :tx)))))
         (key (vault-spend-key id (btx:tx-txid tx))))
    (unless (gethash key (node-reported-vault-spend node))
      (let* ((qb (or qb-seq (governing-quorum-begin-seq rec (lg:ledger-sequence (record-ledger rec)))))
             (probe (fr:make-unauthorized-vault-spend-proof (node-pubkey node) (hex->bytes id) (hex->bytes id) qb tx
                                                           (getf spend :prevouts) (getf spend :block-hash))))
        (multiple-value-bind (reserves rungs vvout operator ruleset) (fr:spent-vault (spent-vault-updates rec) qb)
          (declare (ignore operator))
          (multiple-value-bind (signers idx tier-index)
              (fr:vault-spend-signers tx (fr::parse-prevouts (getf (getf probe :evidence) :prevouts)) reserves rungs vvout)
            (declare (ignore idx))
            ;; DEP-18: a vault created under a ruleset without vault-spend proofs is never
            ;; proven against and opens no challenge (dormant: it can only excuse).
            (unless (lg:ruleset-rule-p ruleset :vault-spend-proofs) (setf signers nil))
            (when signers
              (let ((anchor (rot:anchor-of tx)))
                (cond ((spend-answered-p node id tx qb reserves tier-index :spend-height (getf spend :height)
                                                                     :prevouts (getf spend :prevouts))
                       (log! node "vault watch: ~a's spend ~a is answered by its anchor (~a)" (subseq id 0 8)
                             (subseq (txid-hex (btx:tx-txid tx)) 0 16) (if (rot:anchor-of tx) "a rotation or confiscation" "-"))
                       nil)
                      (t
                       (if anchor
                           (log! node "VAULT SPEND CHALLENGED: ~a's reserves were spent by ~a, anchored at ~a, and nothing we hold answers it; challenging (~a signers)"
                                 (subseq id 0 8) (subseq (txid-hex (btx:tx-txid tx)) 0 16) (subseq (bytes->hex anchor) 0 16) (length signers))
                           (log! node "VAULT SPEND: ~a's reserves were spent by ~a, which carries no anchor: theft on its face; ~a signers"
                                 (subseq id 0 8) (subseq (txid-hex (btx:tx-txid tx)) 0 16) (length signers)))
                       (setf (gethash key (node-reported-vault-spend node))
                             (list :id id :qb qb :tx (getf spend :tx) :height (getf spend :height)
                                   :block-hash (bytes->hex (getf spend :block-hash))
                                   :prevouts (getf (getf probe :evidence) :prevouts)
                                   :form (if anchor :challenge :unanchored) :tier tier-index
                                   :signers (mapcar #'bytes->hex signers) :published '()))
                       t))))))))))

(defun lapsed-challenge (node e)
  "For owed challenge E: (values challenge-update lapse-block-hash new-challenge-hex), the first
   two once its window has passed (the caller then checks for an answer); NIL while open.  Opens
   the challenge first if it is not yet (third value: the update to remember)."
  (let* ((opened (unless (getf e :challenge)
                   (let ((u (ignore-errors (open-spend-challenge node e))))
                     (when u
                       (log! node "challenge of ~a's spend recorded on our ledger at seq ~a" (subseq (getf e :id) 0 8) (up:update-seq u))
                       (bytes->hex (up:encode-update u))))))
         (hex (or (getf e :challenge) opened))
         (cu (and hex (up:decode-update (hex->bytes hex)))))
    (if (null cu)
        (values nil nil opened)
        (let* ((rec (find-record node (getf e :id)))
               (w (fr:spend-window (if rec
                                       (append (record-updates-of rec :quorum-add-member) (record-updates-of rec :quorum-begin))
                                       (ledger-updates-from-relays node (getf e :id)))
                                   (getf e :qb)))
               (end (+ (max (up:update-block-height cu) (or (getf e :height) 0)) w))
               (hash (and (>= (height node) end) (node-block-hash-fn node) (funcall (node-block-hash-fn node) end))))
          (values (and hash cu) hash opened)))))

(defun publish-owed-vault-spends (node)
  "Publish every owed theft proof not yet published; T if anything changed.  An owed challenge
   is re-judged each pass: answered, it is done; lapsed, its proofs go out in the lapsed form."
  (let ((changed nil) (h (height node)))
    (loop for key being the hash-keys of (node-reported-vault-spend node) using (hash-value e)
          when (and (listp e) (not (getf e :done)))
            do (handler-case
                   (if (and (node-height-of-block node) (getf e :block-hash)
                            (null (funcall (node-height-of-block node) (hex->bytes (getf e :block-hash)))))
                       ;; DEP-06: its block was reorganised out.  Not a fault, and not proof: forget
                       ;; it and rescan from below it, so the spend is judged again where it confirms.
                       (progn (remhash key (node-reported-vault-spend node))
                              (when (getf e :height)
                                (setf (node-vault-scanned node) (min (or (node-vault-scanned node) 0) (1- (getf e :height)))))
                              (log! node "vault spend ~a: its block was reorganised out; re-checking" (subseq key 0 8))
                              (setf changed t))
                   (let* ((tx (btx:parse-tx (bw:make-reader (hex->bytes (getf e :tx)))))
                          (prevouts (coerce (fr::parse-prevouts (getf e :prevouts)) 'list))
                          (bh (hex->bytes (getf e :block-hash))) (complete t)
                          (lapse nil) (cu nil))
                     ;; an entry kept before forms existed is judged by its anchor
                     (unless (getf e :form) (setf (getf e :form) (if (rot:anchor-of tx) :challenge :unanchored)))
                     (when (eq (getf e :form) :challenge)
                       (multiple-value-bind (c l opened) (lapsed-challenge node e)
                         (setf cu c lapse l)
                         (when opened (setf (getf e :challenge) opened changed t)))
                       ;; DEP-06 "Verify before publishing": a lapse is judged afresh, never from a
                       ;; cached miss of the confiscation rebuild, and over every answer the relays
                       ;; hold now (re-read, not only what our subscription delivered).
                       (when lapse
                         (remhash (btx:tx-txid tx) *rebuilt-misses*)
                         (refresh-spend-answers node (getf e :id)))
                       (multiple-value-bind (reserves) (fr:spent-vault (let ((r (find-record node (getf e :id)))) (if r (spent-vault-updates r) '())) (getf e :qb))
                         (when (and reserves (ignore-errors (spend-answered-p node (getf e :id) tx (getf e :qb) reserves (getf e :tier)
                                                                              :spend-height (getf e :height)
                                                                              :prevouts (ignore-errors (fr::parse-prevouts (getf e :prevouts))))))
                           (log! node "the challenge of ~a's spend ~a is answered; nothing to prove" (subseq (getf e :id) 0 8)
                                 (subseq (txid-hex (btx:tx-txid tx)) 0 16))
                           (setf (getf e :done) t (getf e :answered) t lapse nil changed t)))
                       ;; DEP-06: a lapse asserts that no answer exists, which only a judge that reads
                       ;; where answers go can say.  One that cannot reaches no verdict and judges again
                       ;; later; the entry stays owed (regtest confiscation-answer, 2026-11-04: a judge
                       ;; blind to the relay proved an honest lottery participant).
                       (when (and lapse (not (answers-readable-p node (getf e :id) (getf e :qb))))
                         (unless (getf e :unreadable-logged)
                           (log! node "the challenge of ~a's spend ~a has lapsed, but we cannot read where its answers go: no verdict"
                                 (subseq (getf e :id) 0 8) (subseq (txid-hex (btx:tx-txid tx)) 0 16))
                           (setf (getf e :unreadable-logged) t changed t))
                         (setf lapse nil)))
                     (when (or (eq (getf e :form) :unanchored) lapse)
                       (dolist (xh (getf e :signers))
                         (let ((x (hex->bytes xh)))
                          ;; Never a proof against our own key: we know our own signatures were not a
                          ;; theft, so a judgement that says so is our judge's error (signet soak,
                          ;; 2026-11-19: C's operator proved itself and its four co-signers over an
                          ;; honest rescue it had broadcast).  Said loudly; the others are judged on.
                          (if (equalp x (up:x-only (node-pubkey node)))
                              (unless (member "self" (getf e :published) :test #'string=)
                                (log! node "VAULT SPEND JUDGEMENT DISAGREES WITH OUR OWN CONDUCT: ~a's spend ~a is one we signed; no proof against ourselves"
                                      (subseq (getf e :id) 0 8) (subseq (txid-hex (btx:tx-txid tx)) 0 16))
                                (push "self" (getf e :published)) (setf changed t))
                           ;; x-only key; the operated ledgers are advertised under the full key, either parity
                           (dolist (full (list (cat (octets 2) x) (cat (octets 3) x)))
                             (multiple-value-bind (targets ok) (ledgers-operated-by node full :strict t)
                               (unless ok (setf complete nil))
                               (dolist (target targets)
                                 (let ((pk (format nil "~a:~a" (bytes->hex full) target)))
                                   (unless (member pk (getf e :published) :test #'string=)
                                     (log! node "vault spend: ~a signed it; ~a proof against its ledger ~a" (subseq xh 0 8)
                                           (if lapse "lapsed-challenge" "unanchored") (subseq target 0 8))
                                     (broadcast-fraud node (fr:make-unauthorized-vault-spend-proof
                                                            full (hex->bytes target) (hex->bytes (getf e :id)) (getf e :qb) tx prevouts bh
                                                            :challenge-update cu :lapse-block-hash lapse))
                                     (push pk (getf e :published))
                                     (setf changed t))))))))))
                     (when (and complete (or (eq (getf e :form) :unanchored) lapse)
                                (> h (+ (or (getf e :height) 0) *vault-spend-publish-blocks*)))
                       (setf (getf e :done) t changed t))
                     (setf (gethash key (node-reported-vault-spend node)) e)))
                 (error (err) (log! node "vault spend ~a: publishing failed (~a); retrying" (subseq key 0 8) err))))
    changed))

(defparameter *vault-spend-verdict-ttl* 600
  "Seconds a spend's verdict is reused: long enough to absorb one theft's proof storm, short
   enough that a QuorumBegin or confiscation learned later changes the answer.")

(defun vault-spend-proof-verdict (node proof)
  "Whether the UnauthorizedVaultSpend PROOF verifies as a received proof does: (values ok why),
   third value :UNKNOWN when it cannot be judged yet.  Cached per proof for a while."
  (let* ((ev (getf proof :evidence)) (spent-id (getf ev :spent-ledger-id)))
    (let* ((key (list (getf proof :accused) spent-id (getf ev :spend-tx-hex) (getf ev :governing-quorumbegin-seq)
                            (getf ev :challenge-update)))
                 (lapsed (getf ev :challenge-update))
                 (hit (gethash key (node-vault-spend-verdicts node))))
            ;; A lapsed form is judged afresh every time: an answer, however late, rebuts it.
            (if (and hit (not lapsed) (< (- (get-universal-time) (first hit)) *vault-spend-verdict-ttl*))
                (values (second hit) (third hit))
                (let* ((srec (find-record node spent-id))
                       (relay (ledger-updates-from-relays node spent-id))
                       (history (if (and srec (not (record-fork-p srec))) (append (record-history srec) relay) relay))
                       (tx (ignore-errors (btx:parse-tx (bw:make-reader (hex->bytes (getf ev :spend-tx-hex))))))
                       (spend-height (ignore-errors (and (node-height-of-block node)
                                                         (funcall (node-height-of-block node) (getf ev :spend-block-hash)))))
                       (gseq (getf ev :governing-quorumbegin-seq)))
                  (when lapsed (refresh-spend-answers node spent-id))
                  (multiple-value-bind (ok why unknown)
                      (handler-case
                          (fr:verify-unauthorized-vault-spend
                           proof history (or (node-height-of-block node) (lambda (h) (declare (ignore h)) (height node)))
                           ;; DEP-06: a lapsed challenge is rebutted by any answer we can find, and is
                           ;; no verdict where we cannot read the places answers go
                           :answered-fn (lambda (txid anchor reserves tier-index)
                                          (declare (ignore txid anchor))
                                          (spend-answered-p node spent-id tx gseq reserves tier-index :spend-height spend-height
                                                            :prevouts (ignore-errors (fr::parse-prevouts (getf ev :prevouts)))))
                           :answers-readable (or (not lapsed) (answers-readable-p node spent-id gseq)))
                        (error (e) (return-from vault-spend-proof-verdict
                                     (values nil (format nil "not judged yet: ~a" e) :unknown))))
                    (if unknown
                        (values nil why :unknown)
                        (progn (setf (gethash key (node-vault-spend-verdicts node)) (list (get-universal-time) ok why))
                               (values ok why)))))))))

(defun handle-vault-spend-fraud (node proof)
  "An UnauthorizedVaultSpend against a ledger the accused operates: if we cosign it, verify
   and dispute (the accused signed a theft of someone's vault)."
  (let* ((ev (getf proof :evidence))
         (accused (hex->bytes (getf proof :accused)))
         (spent-id (getf ev :spent-ledger-id))
         (targets (loop for rec being the hash-values of (node-ledgers node)
                        when (and (not (record-owned-p rec)) (not (record-fork-p rec))
                                  (not (string= (record-id-hex rec) spent-id))
                                  (equalp (lg:ledger-operator-key (record-ledger rec)) accused)
                                  (member (node-pubkey node) (lg:ledger-quorum-members (record-ledger rec)) :key #'lg:member-pubkey :test #'equalp)
                                  (not (blocking-fork node (record-id-hex rec) t)))
                          collect rec)))
    (when targets
      (multiple-value-bind (ok why) (vault-spend-proof-verdict node proof)
          (if (not ok)
              (unless (judge-later-p node proof why)
                (log! node "vault-spend proof against ~a rejected: ~a" (subseq (getf proof :accused) 0 8) why))
              (dolist (rec targets)
                (log! node "contagion: ~a signed an unauthorised spend of ~a's vault; disputing its ledger ~a"
                      (subseq (getf proof :accused) 0 8) (subseq spent-id 0 8) (subseq (record-id-hex rec) 0 8))
                (enter-dispute node rec (lg:ledger-sequence (record-ledger rec)) :reason "unauthorized_vault_spend" :fraud-proof-hash (fr:proof-hash proof) :fraud-proof proof)))))))

(defun broadcast-fraud (node proof)
  (bus:bus-publish (node-bus node) (w:fraud-event (node-keypair node) (getf proof :ledger-id) (getf proof :accused) (fr:broadcast->json proof))))

(defun handle-fraud (node event)
  ;; ADVERSARY :ignore-fraud — a member that drops every fraud proof while it keeps
  ;; operating its own ledgers.  DEP-19 §6 makes that provable dereliction; the harness
  ;; redteam/attack-dereliction.sh drives it (docs/REDTEAM.md).
  (when (getf (node-adversary node) :ignore-fraud) (return-from handle-fraud nil))
  (let ((proof (fr:json->broadcast (w:parse-json (ev:event-content event))))
        (*received-broadcast* (ev:event-content event)))
    (dispatch-fraud node proof)))

(defun dispatch-fraud (node proof)
  (case (getf proof :type)
    (:non-conforming-cosignature (handle-cosigner-fraud node proof))
    (:unauthorized-vault-spend (handle-vault-spend-fraud node proof))
    (t (handle-operator-fraud node proof))))

;;; ---------------------------------------------------------------------------
;;; Proofs we cannot judge YET.  Regtest 1120-075609 (2026-11-20T08:02:51Z): the reference
;;; member ref7, 3 s behind ledger 7341c3d1 at seq 4, got four NonConformingUpdate proofs whose
;;; fault is at seq 9, refused each for good ("follows an update that is not in this ledger's
;;; history"), caught up milliseconds later and never judged them again: no fork, no arm.  This
;;; daemon did the same ("fraud proof rejected" with the replica behind).  A member briefly
;;; behind must not lose its standing, and delivering a proof ahead of its updates must not be a
;;; way to silence one.  So a proof that fails while our replica of a ledger it rests on is
;;; behind (FR:PROOF-HISTORY-NEEDS) is parked while that ledger is caught up off the worker, and
;;; judged again once the replica gets there: at most *PARKED-PROOFS-PER-LEDGER* per accused ledger, each for
;;; *PARKED-PROOF-TTL* seconds, re-judged by the watch pass.

(defparameter *parked-proof-ttl* 3600)
(defparameter *parked-proofs-per-ledger* 32)

(defun replica-tip (node id)
  (let ((r (find-record node id))) (and r (record-p r) (lg:ledger-sequence (record-ledger r)))))

(defun proof-unmet-needs (node needs)
  "NEEDS our replicas have not reached.  A ledger we hold no replica of has met none of its needs
   (DEP-06 vector proof_history_needs.json, as the reference): such a proof is parked and expires
   unless we come to hold that ledger."
  (fr:unmet-history-needs needs (lambda (id) (replica-tip node id))))

(defun proof-need-tips (node needs) (mapcar (lambda (n) (or (replica-tip node (car n)) -1)) needs))

(defun proof-shortfall (node needs)
  (reduce #'max (mapcar (lambda (n) (max 0 (- (cdr n) (or (replica-tip node (car n)) 0)))) needs)
          :initial-value 0))

(defun park-proof (node proof needs &optional (now (get-universal-time)))
  "Park PROOF under its accused ledger.  Returns :parked, :already-parked, :parked-displacing
   (the set was full and PROOF reaches less far than the one it displaced) or :full."
  (let* ((id (getf proof :ledger-id)) (hash (fr:proof-hash proof))
         (set (remove-if (lambda (p) (>= (- now (getf p :at)) *parked-proof-ttl*))
                         (gethash id (node-parked-proofs node))))
         (entry (list :hash hash :proof proof :content *received-broadcast* :needs needs :at now
                      :tips (proof-need-tips node needs))))
    (flet ((done (set outcome) (setf (gethash id (node-parked-proofs node)) set) outcome))
      (cond ((find hash set :key (lambda (p) (getf p :hash)) :test #'equalp) (done set :already-parked))
            ((< (length set) *parked-proofs-per-ledger*) (done (cons entry set) :parked))
            (t (let ((worst (reduce (lambda (a b) (if (>= (proof-shortfall node (getf a :needs))
                                                          (proof-shortfall node (getf b :needs)))
                                                      a b))
                                    set)))
                 (if (> (proof-shortfall node (getf worst :needs)) (proof-shortfall node needs))
                     (done (cons entry (remove worst set)) :parked-displacing)
                     (done set :full))))))))

(defun relay-blind-p (node id-hex)
  "FAULT :blind-relay (a ledger id prefix, redteam): true when NODE must read none of ID-HEX's updates
   on the relays, only its replica and published answers (redteam/check-rotation-lag.sh,
   check-confiscation-answer.sh).  Every relay read of a ledger's updates asks this."
  (let ((p (getf (node-adversary node) :blind-relay)))
    (and (stringp p) (>= (length id-hex) (length p)) (string-equal p (subseq id-hex 0 (length p))))))

(defun judge-later-p (node proof why)
  "PROOF failed verification for WHY.  When our replica of a ledger it rests on is behind, park
   it and start a catch-up of that ledger (KICK-PROOF-CATCH-UP): true, and the caller reports no
   rejection.  NIL when every need is met (the proof is invalid).  Nothing here waits on a relay:
   fraud proofs are handled on the main worker, which also answers consent requests, and a
   catch-up is a 5 s fetch per 200-sequence window for as many windows as the replica is behind."
  (let* ((needs (fr:proof-history-needs proof)) (unmet (proof-unmet-needs node needs)))
    (when (eq (fr:proof-verdict needs (lambda (id) (replica-tip node id)) nil) :park)
      (let ((n (first unmet)) (id (getf proof :ledger-id)))
        (log! node "fraud proof ~a on ~a not judgeable yet (~a): it needs seq ~a of ~a, our replica is at ~a; ~(~a~), catching up"
              (getf proof :type) (subseq id 0 8) why (cdr n) (subseq (car n) 0 8)
              (replica-tip node (car n)) (park-proof node proof needs)))
      (dolist (n unmet)
        (cond ((not (find-record node (car n))))
              ;; Blind to that ledger on the relays (redteam :blind-relay): parked, never fetched.
              ;; regtest 1120-112248: a catch-up that ignored the switch let confiscation-answer's
              ;; blind judge read the dispute it is there to miss.
              ((relay-blind-p node (car n))
               (log! node "not catching up ~a for a parked proof: blind to it on the relays" (subseq (car n) 0 8)))
              (t (kick-proof-catch-up node (car n) (cdr n)))))
      t)))

(defun kick-proof-catch-up (node id seq)
  "Catch our replica of ID up to SEQ on a lane of its own (one per ledger at a time; OWN:MAKE-LANE),
   not on the handler's, then have the parked proofs judged again: on the main worker when the node
   runs one, else on that lane.  Returns the lane, or NIL when one is already running for ID, or
   when we are blind to ID on the relays (RELAY-BLIND-P)."
  (let ((running (gethash id (node-proof-catch-ups node))))
    (unless (or (own:lane-live-p running) (relay-blind-p node id))
      (let ((lane (own:make-lane :name "cld-proof-catch-up" :close-when-empty t)))
        (own:lane-push lane
                       (lambda ()
                         (unwind-protect
                              (let ((r (find-record node id)))
                                (when r (ignore-errors (catch-up-to node r seq)))
                                (if (node-worker node)
                                    (enqueue node (lambda () (rejudge-parked-proofs node)))
                                    (ignore-errors (rejudge-parked-proofs node))))
                           (remhash id (node-proof-catch-ups node)))))
        (setf (gethash id (node-proof-catch-ups node)) lane)))))

(defun stop-node-work (node)
  "Close the lanes a node started for itself (its proof catch-ups): STOP-NODE."
  (loop for lane being the hash-values of (node-proof-catch-ups node) do (own:lane-close lane))
  (clrhash (node-proof-catch-ups node)))

(defun rejudge-parked-proofs (node &optional (now (get-universal-time)))
  "Drop expired parked proofs and judge again every one whose needs our replicas now meet, or
   whose replicas have advanced since it was last judged: the needs are an upper bound (a fault
   that SKIPS, signed at T+2 onto T, needs T, not T+1).  An advanced one stays parked, so its
   expiry runs from when it was first parked.  Returns how many were judged."
  (let ((ready '()) (expired 0))
    (loop for id in (loop for k being the hash-keys of (node-parked-proofs node) collect k)
          do (let ((keep '()))
               (dolist (p (gethash id (node-parked-proofs node)))
                 (let ((tips (proof-need-tips node (getf p :needs))))
                   (cond ((>= (- now (getf p :at)) *parked-proof-ttl*) (incf expired))
                         ((null (proof-unmet-needs node (getf p :needs))) (push p ready))
                         ((some #'> tips (getf p :tips))
                          (setf (getf p :tips) tips) (push p ready) (push p keep))
                         (t (push p keep)))))
               (if keep (setf (gethash id (node-parked-proofs node)) (nreverse keep))
                   (remhash id (node-parked-proofs node)))))
    (when (plusp expired)
      (log! node "dropped ~a parked fraud proof(s) unjudged: our replica did not catch up in ~a s" expired *parked-proof-ttl*))
    (dolist (p ready (length ready))
      (log! node "judging parked fraud proof ~a on ~a again: our replica has caught up"
            (getf (getf p :proof) :type) (subseq (getf (getf p :proof) :ledger-id) 0 8))
      (let ((*received-broadcast* (getf p :content)))
        (ignore-errors (dispatch-fraud node (getf p :proof)))))))

(defun offer-proof-p (proof)
  (and (eq (getf proof :type) :uncredited-onchain-payment) (not (fr::e proof :source-qb-update))))

(defun note-obligation-proof (node rec proof)
  "DEP-06: an offer-evidence proof against REC that verifies is owed at confiscation; keep it
   to record on our fork before arming.  True when kept."
  (when (and (offer-proof-p proof) (string-equal (getf proof :ledger-id) (record-id-hex rec))
             (fr:verify-proof proof :history (reverse (record-history rec))
                                    :height-of-block (or (node-height-of-block node) (lambda (h) (declare (ignore h)) (height node)))))
    (pushnew (w:json (fr:proof->json proof)) (gethash (record-id-hex rec) (node-obligation-proofs node)) :test #'string=)
    t))

(defun dispute-new-operator (node chain proof)
  "A verified UnhonouredObligation (DEP-06) against the operator CHAIN's ledger has had since a
   custody change: as a member of that chain's quorum, dispute it from its tip, as the reference
   disputes any proven fraud of a ledger's current operator.  CHAIN is the replica, or (cl keeps
   the winner's chain as its fork) the acquired fork.  Returns our new fork, or NIL."
  (let* ((id (record-id-hex chain)) (l (record-ledger chain))
         (accused (hex->bytes (getf proof :accused))) (us (node-pubkey node))
         ;; DEP-06: judged by the quorum the dispute forked from.  The acquired fork carries
         ;; none (its DisputeEnter cleared it, the DisputeAcquire cleared quorum-at-fork), so
         ;; every member found itself outside it and no one disputed (regtest 2026-10-14);
         ;; the base replica holds the ledger's last QuorumBegin quorum.
         (base (find-record node id))
         (members (or (lg:ledger-quorum-members l) (lg:ledger-quorum-at-fork l)
                      (and base (or (lg:ledger-quorum-members (record-ledger base))
                                    (lg:ledger-quorum-at-fork (record-ledger base)))))))
    (cond ((equalp accused us) nil)
          ((not (equalp accused (lg:ledger-operator-key l)))
           (log! node "unhonoured-obligation proof on ~a names ~a, not its operator" (subseq id 0 8) (subseq (bytes->hex accused) 0 8)) nil)
          ((not (member us members :key #'lg:member-pubkey :test #'equalp))
           (log! node "unhonoured-obligation proof on ~a: not a member of its quorum; not disputing" (subseq id 0 8)) nil)
          ;; already disputing it: our fork holds the custody change
          ((let ((own (find-fork node id us)))
             (and own (not (eq own chain))
                  (some (lambda (u) (eq (op:update-type u) :dispute-acquire))
                        (record-history own))))
           nil)
          (t
           (log! node "UNHONOURED OBLIGATION on ~a verified: disputing its new operator ~a from seq ~a"
                 (subseq id 0 8) (subseq (bytes->hex accused) 0 8) (lg:ledger-sequence l))
           ;; Our fork from the dispute that moved custody is history now.
           (let ((own (find-fork node id us)))
             (when (and own (not (eq own chain)))
               (retire-fork node own :superseded t)))
           (enter-dispute node chain (lg:ledger-sequence l) :reason "unhonoured_obligation"
                                                            :fraud-proof-hash (fr:proof-hash proof) :fraud-proof proof)))))

(defun handle-operator-fraud (node proof)
  (let* ((proof proof)
         (id (getf proof :ledger-id))
         (rec (find-record node id)))
    ;; DEP-06 UnhonouredObligation accuses the new operator: judged on the chain after the
    ;; custody change, never by disputing the old operator's chain.
    (when (and rec (eq (getf proof :type) :unhonoured-obligation))
      (let ((chain (ledger-chain-record node id)))
        (multiple-value-bind (ok why)
            (fr:verify-proof proof :history (reverse (record-history chain))
                                   :height-of-block (or (node-height-of-block node) (lambda (h) (declare (ignore h)) (height node))))
          (if ok
              (dispute-new-operator node chain proof)
              (unless (judge-later-p node proof why)
                (log! node "unhonoured-obligation proof on ~a rejected: ~a" (subseq id 0 8) why)))))
      (return-from handle-operator-fraud nil))
    ;; DEP-06 §Enter: a proof against us, or on a ledger we operate, is never ours to act on
    ;; (UnhonouredObligation, above, is judged on the chain after a custody change and asks
    ;; (equalp accused us) itself).
    (when (and rec (self-dispute-refusal (node-pubkey node) (ignore-errors (hex->bytes (getf proof :accused)))
                                         (let ((l (record-ledger rec))) (and l (lg:ledger-operator-key l)))))
      (return-from handle-operator-fraud nil))
    ;; Already disputing (another proof came first): an offer proof is still owed at confiscation.
    (when (and rec (not (record-owned-p rec)) (offer-proof-p proof) (live-fork node id (node-pubkey node)))
      (ignore-errors (note-obligation-proof node rec proof)))
    ;; DEP-06 Entering a dispute: a type that needs an embedding is entered only on a verified one.
    ;; We verify none (and have no lightning verifier), so we decline every such proof.
    (when (and rec (fr:requires-embedding-p (getf proof :type)))
      (log! node "fraud proof ~a on ~a: needs an embedding we do not verify; not disputing"
            (getf proof :type) (subseq id 0 8))
      (return-from handle-operator-fraud nil))
    (when (and rec (not (record-owned-p rec))
               (member (node-pubkey node) (lg:ledger-quorum-members (record-ledger rec)) :key #'lg:member-pubkey :test #'equalp)
               (not (blocking-fork node id (not (eq (getf proof :type) :quorum-expired)))))
      (multiple-value-bind (ok why)
          (let ((hob (or (node-height-of-block node)
                         ;; no chain view: trust our own tip for the anchor
                         (lambda (hash) (declare (ignore hash)) (height node)))))
            (if (eq (getf proof :type) :dispute-dereliction)
                (let ((original (getf (getf proof :evidence) :original-proof)))
                  (if original
                      (fr:verify-dispute-dereliction proof (reverse (record-history rec)) hob
                                                     :defrauded-updates (updates-of-ledger node (getf original :ledger-id)))
                      (values nil "no original proof")))
                (fr:verify-proof proof :history (reverse (record-history rec)) :height-of-block hob
                                       :prefix-ledger-fn (prefix-ledger-fn rec))))
        (when (and ok (eq (getf proof :type) :uncredited-onchain-payment) (not (fr::e proof :source-qb-update)))
          ;; DEP-06: a proven-uncredited payment is owed at confiscation: keep it to record before arming
          (pushnew (w:json (fr:proof->json proof)) (gethash id (node-obligation-proofs node)) :test #'string=))
        (if ok
            (let ((last-valid (fr:dispute-fork-point proof (lg:ledger-sequence (record-ledger rec)))))
              (log! node "fraud proof ~a on ~a verified: disputing from seq ~a" (getf proof :type) (subseq id 0 8) last-valid)
              (let ((fork (enter-dispute node rec last-valid
                                         ;; snake_case, as the reference writes and matches it
                                         ;; ("quorum_expired", dispute.rs); "quorum-expired" made our
                                         ;; expiry disputes unrecognisable, to it and to our own driver.
                                         :reason (substitute #\_ #\- (string-downcase (symbol-name (getf proof :type))))
                                         :fraud-proof-hash (fr:proof-hash proof) :fraud-proof proof)))
                (unless (member (getf proof :type) '(:dispute-dereliction :quorum-expired))
                  (watch-derelicts node id proof fork))))
            (unless (judge-later-p node proof why)
              (log! node "fraud proof rejected: ~a" why)))))))

;;; ---------------------------------------------------------------------------
;;; Persistence: the fixture format — a JSON array of base64 updates, oldest first.

(defun record-file-name (rec)
  (if (record-fork-p rec)
      (format nil "ledger_~a_fork_~a.json" (subseq (record-id-hex rec) 0 16) (subseq (bytes->hex (record-fork-operator rec)) 0 16))
      (format nil "ledger_~a.json" (subseq (record-id-hex rec) 0 16))))

;;; Verified checkpoints on disk: ckpt_<id16>.sexp holds the newest one, so a restart loads it and
;;; replays forward instead of from genesis.  Its digest guards against a damaged file, and the
;;; update it was taken at must be the one in the ledger file (same chain hash), or it is ignored.

(defun checkpoint-path (node rec)
  (merge-pathnames (format nil "ckpt_~a.sexp" (subseq (record-id-hex rec) 0 16)) (node-data-dir node)))

(defun drain-checkpoint-events (node rec)
  (loop for m = (pop (record-ckpt-events rec)) while m do (log! node "~a" m)))

(defun persist-checkpoint (node rec)
  "Write REC's newest checkpoint if it is newer than the one on disk (base records only)."
  (let ((cp (first (record-checkpoints rec))))
    (when (and cp (node-data-dir node) (not (record-fork-p rec)) (not (record-fork-base rec))
               (> (car cp) (record-ckpt-persisted rec)))
      (let ((u (record-update-at rec (car cp))))
        (when u
          (let* ((path (checkpoint-path node rec))
                 (tmp (make-pathname :type "tmp" :defaults path))
                 (state (lg:encode-state (cdr cp))))
            (with-open-file (out tmp :direction :output :if-exists :supersede :external-format :utf-8)
              (with-standard-io-syntax
                (prin1 (list :seq (car cp) :chain-hash (bytes->hex (up:chain-hash u))
                             :digest (bytes->hex (sha256 (sb-ext:string-to-octets state :external-format :utf-8)))
                             :state state)
                       out)))
            (uiop:rename-file-overwriting-target tmp path)
            (setf (record-ckpt-persisted rec) (car cp))))))))

(defun read-checkpoint (path)
  "(values seq chain-hash-hex ledger) from a checkpoint file, or NIL if absent or damaged."
  (handler-case
      (when (probe-file path)
        (let ((f (with-open-file (in path :external-format :utf-8)
                   (with-standard-io-syntax (let ((*read-eval* nil)) (read in))))))
          (when (string= (getf f :digest) (bytes->hex (sha256 (sb-ext:string-to-octets (getf f :state) :external-format :utf-8))))
            (values (getf f :seq) (getf f :chain-hash) (lg:decode-state (getf f :state))))))
    (error () nil)))

(defun save-record (node rec)
  "Persist the history as a JSON array of base64 updates, one per line (a fork: only the
   updates after its fork point; LOAD-RECORD takes the rest from the base).  The
   common case — one new update on a file we wrote — APPENDS inside the closing
   bracket; rewriting the whole file per update was O(sequence) and at seq 1800
   (a 5.7 MB file, six updates a second across the ledgers a node replicates)
   it pegged a core in base64 alone."
  (when (and *deferred-saves* (not (member rec (car *deferred-saves*))))
    (push rec (car *deferred-saves*)))
  (when (and (node-data-dir node) (not *deferred-saves*))
    (ensure-directories-exist (node-data-dir node))
    (let* ((path (merge-pathnames (record-file-name rec) (node-data-dir node)))
           (n (- (record-count rec) (record-file-base rec)))   ; entries the file should hold
           (appendable (and (plusp (record-persisted rec)) (= n (1+ (record-persisted rec))) (probe-file path)
                            (with-open-file (in path :external-format :latin-1)
                              (and (> (file-length in) 2)
                                   (progn (file-position in (- (file-length in) 2))
                                          (and (char= (read-char in) #\]) (char= (read-char in) #\Newline))))))))
      (if appendable
          (with-open-file (out path :direction :output :if-exists :overwrite :external-format :latin-1)
            (file-position out (- (file-length out) 2))
            (format out ",~%~s]~%" (base64-encode (up:encode-update (first (record-history rec)))))
            (when *durable* (fsync-stream out)))
          ;; Whole file: write beside it and rename.  SBCL DELETES a :supersede
          ;; target when the write is aborted — and a node killed mid-write (or
          ;; an error inside FORMAT) aborts it: that is how replicas vanished.
          (let ((tmp (make-pathname :type "tmp" :defaults path)))
            (with-open-file (out tmp :direction :output :if-exists :supersede :external-format :latin-1)
              ;; A fork's file holds its own updates only; its base's file holds the rest.
              (format out "[~{~s~^,~%~}]~%" (mapcar (lambda (u) (base64-encode (up:encode-update u)))
                                                    (reverse (subseq (record-history rec) 0 n))))
              (when *durable* (fsync-stream out)))
            (uiop:rename-file-overwriting-target tmp path)
            (when *durable* (fsync-dir (node-data-dir node)))))
      (setf (record-persisted rec) n)
      (persist-checkpoint node rec)))
  (drain-checkpoint-events node rec))

(defun load-record (node path &key owned-p)
  "Rebuild a record from a saved (or fixture) file, validating as we go.  A
   fork file (ledger_<id>_fork_<op>.json) becomes a fork record of its base,
   which must already be loaded."
  (let* (;; One entry per line, streamed: slurping an 84 MB file into a Lisp
         ;; string (4 bytes a character, then a SUBSEQ copy) blew a 1 GB heap
         ;; at startup.  A node killed mid-append leaves a truncated last entry:
         ;; keep what decodes, drop the tail, catch-up refills it from the relay.
         (clean t)   ; NIL if we stopped before the end: the file must be REWRITTEN, never appended to
         (updates (with-open-file (in path :external-format :latin-1)
                    (loop for line = (read-line in nil nil) while line
                          for start = (position #\" line)
                          for end = (and start (position #\" line :start (1+ start)))
                          for u = (and end (handler-case (up:decode-update (base64-decode (subseq line (1+ start) end)))
                                             (error () nil)))
                          for closing = (string= (string-trim '(#\Space #\Return #\Tab) line) "]")
                          while (or u (and closing (not (read-line in nil nil))))   ; a lone "]" as the last line
                          when u collect u
                          finally (unless (or u closing) (setf clean nil)))))
         (first (first updates))
         (id-hex (bytes->hex (up:update-ledger-id first)))
         (fork-p (search "_fork_" (file-namestring path)))
         (inherited-in-file nil)
         (rec (if fork-p
                  (let* ((base (or (find-record node id-hex) (fail "fork file before its base ledger")))
                         ;; Current files start at the fork's first own update; older ones repeat the
                         ;; base's history from genesis first.
                         (divergence (if (plusp (up:update-seq first))
                                         0
                                         (or (position-if (lambda (u) (not (equalp (up:update-operator-id u) (lg:ledger-operator-key (record-ledger base))))) updates)
                                             (fail "fork file with no fork updates"))))
                         (operator (up:update-operator-id (nth divergence updates))))
                    (setf inherited-in-file divergence)
                    (make-fork node base (1- (up:update-seq (nth divergence updates))) operator))
                  (make-record :id-hex id-hex :ledger (lg:make-ledger) :owned-p owned-p))))
    ;; An entry that does not chain (a gap or a bad update mid-file, from a
    ;; rewrite of a history that was itself loaded past damage) ends the load
    ;; there, like a damaged tail: keep the prefix, rewrite, catch up.
    ;;
    ;; Our own data dir holds only what we validated before persisting it, so by
    ;; default a load re-applies without re-verifying signatures (CLD_VERIFY_ON_LOAD
    ;; restores the full check) and never writes: ACCEPT-UPDATE's SAVE-RECORD
    ;; rewrote the file being loaded from its first entry and then appended every
    ;; other one, one open-seek-write each.  With a million updates across the
    ;; soak's replicas and forks, that and ~2M Schnorr verifications made a
    ;; restart take 20 minutes.
    ;; A verified checkpoint on disk: take its state and the updates through it as they are, and
    ;; replay only what follows.  It must sit on this file's chain (same update, same hash).
    (unless (or fork-p *verify-on-load* (null (node-data-dir node)))
      (multiple-value-bind (cseq chash cledger) (read-checkpoint (checkpoint-path node rec))
        (let ((at (and cseq (nth cseq updates))))
          (if (and at (= (up:update-seq at) cseq) (string= (bytes->hex (up:chain-hash at)) chash)
                   (= (lg:ledger-sequence cledger) cseq))
              (let ((prefix (subseq updates 0 (1+ cseq))))
                (setf (record-ledger rec) cledger
                      (record-history rec) (reverse prefix)
                      (record-checkpoints rec) (list (cons cseq (lg:copy-ledger cledger)))
                      (record-ckpt-persisted rec) cseq)
                (index-record rec)
                (log! node "~a: from its checkpoint at seq ~a, replaying ~a" (file-namestring path) cseq (- (length updates) cseq 1)))
              (when cseq (log! node "~a: checkpoint at seq ~a is not on this file's chain; replaying from genesis" (file-namestring path) cseq))))))
    (let ((*deferred-saves* (list nil)) (*replaying* t))
     (dolist (u updates)
      (when (> (up:update-seq u) (lg:ledger-sequence (record-ledger rec)))   ; a fork file's inherited prefix: skipped
        (handler-case
            (cond ((and (record-owned-p rec) (not fork-p))
                   (lg:apply-update (record-ledger rec) u) (record-push rec u))
                  (*verify-on-load* (accept-update node rec u))
                  (t (when (and fork-p (not (equalp (up:update-operator-id u) (record-fork-operator rec))))
                       (fail "fork update not signed by the fork's operator"))
                     (lg:apply-update (record-ledger rec) u) (record-push rec u)))
          (error (e)
            (log! node "~a: entry at seq ~a does not apply (~a); keeping ~a entries"
                  (file-namestring path) (up:update-seq u) e (record-count rec))
            (setf clean nil) (return))))))
    (unless fork-p (setf (gethash (record-id-hex rec) (node-ledgers node)) rec))
    (when (and clean (not fork-p)) (ignore-errors (persist-checkpoint node rec)))
    ;; A damaged file is rewritten whole on the next save; so is a fork file in the old format,
    ;; which repeated its base's whole history before the fork's own updates.
    (setf (record-persisted rec) (if (and clean (or (not fork-p) (null inherited-in-file) (zerop inherited-in-file)))
                                     (- (record-count rec) (record-file-base rec))
                                     0))
    (unless clean (log! node "~a: damaged after seq ~a; will rewrite, catch-up refills the rest" (file-namestring path) (lg:ledger-sequence (record-ledger rec))))
    (when (and clean fork-p inherited-in-file (plusp inherited-in-file))
      (save-record node rec)
      (log! node "~a: rewritten with the fork's own ~a updates (was ~a with its base's history)"
            (file-namestring path) (record-persisted rec) (+ inherited-in-file (record-persisted rec))))
    (when (and owned-p (not fork-p) (null (node-member-ledger-hex node)))
      (setf (node-member-ledger-hex node) (record-id-hex rec)))
    ;; Our own fork, armed before the restart: the preimage is re-derivable.
    (when (and fork-p (record-owned-p rec))
      (let ((armed (first (fork-own-updates rec :dispute-armed))))   ; the latest arm
        (when armed
          (let* ((aop (op:decode-operation (up:update-message armed)))
                 (round (or (op:field aop :rearm-round) 1))
                 (preimage (find (op:field aop :commitment-hash)
                                 (list (lot:derive-preimage (lottery-seed node rec round))
                                       ;; armed by a build before the fork-bound seed
                                       (lot:derive-preimage (lottery-seed-v1 node id-hex round)))
                                 :key #'lot:commitment-of :test #'equalp)))
            (if preimage
                (setf (record-preimage rec) preimage)
                (log! node "fork ~a: armed with a preimage we cannot re-derive" (subseq id-hex 0 8)))))))
    rec))

(defun load-data-dir (node &rest args)
  "Reload everything we knew: our ledgers, the ones we cosign, forks, reveals.
   Then release the worker lanes (see make-node)."
  (unwind-protect (apply #'%load-data-dir node args)
    (setf (node-loading node) nil)))

(defun %load-data-dir (node &key (log-fn (lambda (fmt &rest args) (apply #'log! node fmt args))))
  (load-known-confiscations node)
  (load-confirmed-lotteries node)
  (load-vault-watch node)
  (load-rearm-follow node)
  (let* ((dir (node-data-dir node))
         (log-lock (bt:make-lock "load-log"))
         (files (directory (merge-pathnames "ledger_*.json" dir))))
    (declare (ignorable log-lock))
    (flet ((load-one (f)
             (handler-case
                 (let* ((first (with-open-file (in f) (read-line in)))
                        (u (up:decode-update (base64-decode (string-trim '(#\[ #\] #\" #\, #\Space #\Return) first))))   ; one update: ["…"]
                        (owned (equalp (up:update-operator-id u) (node-pubkey node)))
                        (fork-op (let ((i (search "_fork_" (file-namestring f)))) (and i (subseq (file-namestring f) (+ i 6) (+ i 22)))))
                        (rec (load-record node f :owned-p owned)))
                   (bt:with-lock-held (log-lock)
                     (funcall log-fn "loaded ~a (~a)" (file-namestring f)
                              (cond ((and fork-op (record-owned-p rec)) "our fork") (fork-op "their fork") (owned "ours") (t "replica")))))
               (error (e) (bt:with-lock-held (log-lock) (funcall log-fn "could not load ~a: ~a" f e))))))
      ;; Bases, then forks (a fork is built from its base).  On the owner thread, one file at a
      ;; time: a record is the node's, and only the owner may make what the node holds (on modus
      ;; a loading thread could not store its record into the node's ledgers table).  They loaded
      ;; in parallel before, one thread per file.
      (dolist (set (list (remove-if (lambda (f) (search "_fork_" (file-namestring f))) files)
                         (remove-if-not (lambda (f) (search "_fork_" (file-namestring f))) files)))
        (mapc #'load-one set)))
    (dolist (f (directory (merge-pathnames "reveals_*.json" dir)))
      (let* ((prefix (subseq (pathname-name f) 8))
             (id (loop for k being the hash-keys of (node-ledgers node) when (and (>= (length k) 16) (string= prefix (subseq k 0 16))) return k)))
        (if id
            (handler-case (load-reveals node id f) (error (e) (funcall log-fn "could not load ~a: ~a" f e)))
            (funcall log-fn "reveals file ~a for a ledger we do not hold" (file-namestring f)))))
    (dolist (f (directory (merge-pathnames "rearms_*.json" dir)))
      (let* ((prefix (subseq (pathname-name f) 7))
             (id (loop for k being the hash-keys of (node-ledgers node) when (and (>= (length k) 16) (string= prefix (subseq k 0 16))) return k)))
        (when id (handler-case (load-rearms node id f) (error (e) (funcall log-fn "could not load ~a: ~a" f e))))))
    (handler-case (load-pledges node) (error (e) (funcall log-fn "could not load pledges: ~a" e)))
    (handler-case (load-superseded node) (error (e) (funcall log-fn "could not load superseded forks: ~a" e)))
    (handler-case (load-side-forks node) (error (e) (funcall log-fn "could not load side forks: ~a" e)))
    (publish-pending node)
    node))
