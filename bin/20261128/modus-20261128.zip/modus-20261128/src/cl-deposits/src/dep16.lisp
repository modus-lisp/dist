;;;; src/dep16.lisp — the DEP-16 descriptor calculus: what authorizes an
;;;; operation on a deposit.
;;;;
;;;; A descriptor is a boolean term over proof obligations (signatures, hash
;;;; preimages, scalars, attestations), ledger state predicates, and value
;;;; comparisons.  This file parses the text form, encodes/decodes the DEP-17
;;;; canonical bytes (descriptor, witness, snapshot), and evaluates a descriptor
;;;; against (operation, snapshot, witness) exactly as the reference calculus
;;;; does.  Verified by replaying the reference conformance vectors.
;;;;
;;;; Terms:      (:const b) (:and ts) (:or ts) (:thresh k ts) (:not t) (:if c t e)
;;;;             (:match v arms default) (:cmp op a b) (:state pred args) (:prove o)
;;;; Value terms: (:lit value) (:var name) (:op fn args)
;;;; Obligations: (:pk v) (:pk-h v) (:pk-any v) (:multi k v) (:hashlock v)
;;;;             (:attest v schema) (:pointlock v)
;;;; Values:     as in dep17.lisp, plus (:subtree term)

(defpackage #:cl-deposits.dep16
  (:use #:cl #:cl-deposits.util)
  (:local-nicknames (#:d17 #:cl-deposits.dep17) (#:secp #:secp256k1-fast) (#:schnorr #:secp256k1-fast.schnorr))
  (:export #:parse-descriptor #:encode-descriptor #:decode-descriptor #:descriptor-id
           #:encode-term #:decode-value #:decode-witness #:encode-witness #:decode-snapshot #:encode-snapshot
           #:decode-operation #:evaluate #:eval-error #:make-witness #:make-snapshot #:make-operation
           #:witness-from-stack #:descriptor-keys #:descriptor-violation))
(in-package #:cl-deposits.dep16)

(define-condition eval-error (error) ((detail :initarg :detail :reader detail))
  (:report (lambda (c s) (format s "dep16: ~a" (detail c)))))
(defun fail (fmt &rest args) (error 'eval-error :detail (apply #'format nil fmt args)))

;;; ---------------------------------------------------------------------------
;;; Registries (declaration order = id)

(defparameter +value-fns+
  '("add" "sub" "mul" "div" "min" "max" "pct" "bps" "operation_type" "operation_arg" "operation_path"
    "operation_subtree" "blocks_since_activity" "blocks_since_open" "deposit_balance" "rolling_window"
    "cumulative_spent_via" "ast_ref" "ast_shape_at" "path" "blocks_since_received"))
(defparameter +state-preds+
  '("older" "after" "amount_at_most" "amount_in_range" "amount_at_most_pct" "destination_is" "destination_in"
    "balance_at_least" "balance_at_most" "blocks_since_activity_at_least" "blocks_since_open_below"
    "rolling_amount_below" "rolling_amount_below_pct" "subtree_at" "blocks_since_open_at_least"
    "blocks_since_received_at_least"))
(defparameter +obligations+ '(:pk :pk-h :pk-any :multi :hashlock :attest :pointlock))
(defparameter +cmp-ops+ '(:eq :lt :le :gt :ge))
(defparameter +node-tags+ '(:const :and :or :thresh :not :if :match :cmp :state :prove))
(defparameter +hash-fns+ '(:sha256 :hash256 :ripemd160 :hash160))
(defparameter +rw-fields+ '("amount_out" "amount_in" "transfer_count"))

(defun id-of (name table) (or (position name table :test #'equal) (fail "unknown ~a" name)))

;;; ---------------------------------------------------------------------------
;;; Text -> AST

;;; The lexer and parser follow deposits-rust's (rust-miniscript calculus/parse.rs) token for
;;; token, so the two give the same verdict on every text: DEP-16 §Descriptor validity, pinned by
;;; inspect/vectors/descriptor_validity.json.

(defconstant +max-depth+ 128 "DEP-16 parse nesting limit (rust-miniscript calculus MAX_DEPTH).")
(defparameter +int-min+ (- (expt 2 127)))
(defparameter +int-max+ (1- (expt 2 127)))

(defun ws-char-p (c) (member (char-code c) '(9 10 11 12 13 32)))
(defun ascii-digit-p (c) (char<= #\0 c #\9))
(defun word-char-p (c) (or (char= c #\_) (ascii-digit-p c) (char<= #\a c #\z) (char<= #\A c #\Z)))
(defun hex-char-p (c) (or (ascii-digit-p c) (char<= #\a c #\f) (char<= #\A c #\F)))

(defun lex-integer (text)
  (let ((n (parse-integer text)))
    (unless (<= +int-min+ n +int-max+) (fail "bad integer `~a`" text))
    n))

(defun lex (s)
  (let ((i 0) (n (length s)) (out '()))
    (loop while (< i n)
          do (let ((c (char s i)))
               (cond ((ws-char-p c) (incf i))
                     ((find c "()[],=:") (push (cdr (assoc c '((#\( . :lp) (#\) . :rp) (#\[ . :lb) (#\] . :rb) (#\, . :comma) (#\= . :eq) (#\: . :colon)))) out) (incf i))
                     ((char= c #\-)
                      ;; a sign: only before a digit, and the literal is the digits after it
                      (unless (and (< (1+ i) n) (ascii-digit-p (char s (1+ i)))) (fail "unexpected character `-`"))
                      (let ((start i))
                        (incf i)
                        (loop while (and (< i n) (ascii-digit-p (char s i))) do (incf i))
                        (push (lex-integer (subseq s start i)) out)))
                     ((char= c #\<) (if (and (< (1+ i) n) (char= (char s (1+ i)) #\=)) (progn (push :le out) (incf i 2)) (progn (push :lt out) (incf i))))
                     ((char= c #\>) (if (and (< (1+ i) n) (char= (char s (1+ i)) #\=)) (progn (push :ge out) (incf i 2)) (progn (push :gt out) (incf i))))
                     ((word-char-p c)
                      (let ((start i))
                        (loop while (and (< i n) (word-char-p (char s i))) do (incf i))
                        (let ((w (subseq s start i)))
                          (push (if (every #'ascii-digit-p w) (lex-integer w) w) out))))
                     (t (fail "unexpected character ~s" c)))))
    (nreverse out)))

(defvar *toks*) (defvar *pos*) (defvar *bound*) (defvar *depth* 0) (defvar *duplicate-name* nil)
(defun peek () (nth *pos* *toks*))
(defun next () (prog1 (or (peek) (fail "unexpected end")) (incf *pos*)))
(defun expect (tok) (let ((got (next))) (unless (equal got tok) (fail "expected ~s, found ~s" tok got))))
(defun word () (let ((w (next))) (unless (stringp w) (fail "expected a word, found ~s" w)) w))
(defun hashfn-p (w) (member w '("sha256" "hash256" "ripemd160" "hash160") :test #'string=))
(defun hashfn-kw (w) (intern (string-upcase w) :keyword))

(defun decode-hex (h)
  "Strict hex: an even number of hex digits."
  (unless (evenp (length h)) (fail "hex literal has an odd number of digits"))
  (unless (every #'hex-char-p h) (fail "invalid hex in `~a`" h))
  (hex->bytes h))

(defun try-key (w)
  "A v1 key literal: 66 hex digits naming a compressed secp256k1 point; else NIL."
  (and (= (length w) 66) (every #'hex-char-p w)
       (let ((b (hex->bytes w))) (and (ignore-errors (d17::parse-pubkey b)) b))))

(defun hash-literal (fnname hexword)
  (unless (stringp hexword) (fail "expected a digest"))
  (let ((d (decode-hex (if (and (>= (length hexword) 2) (string= "0x" (subseq hexword 0 2))) (subseq hexword 2) hexword))))
    (unless (= (length d) (if (member fnname '("sha256" "hash256") :test #'string=) 32 20)) (fail "bad digest length"))
    (list :hash (hashfn-kw fnname) d)))

(defun hex-prefixed-p (tok) (and (stringp tok) (>= (length tok) 2) (string= "0x" (subseq tok 0 2))))
(defun bytes-literal (tok)
  (let ((h (subseq tok 2)))
    (when (zerop (length h)) (fail "empty hex literal `0x`"))
    (list :bytes (decode-hex h))))

(defmacro with-depth (&body body)
  `(progn (when (>= *depth* +max-depth+) (fail "nesting too deep (> ~a)" +max-depth+))
          (let ((*depth* (1+ *depth*))) ,@body)))

(defun parse-literal () (with-depth (parse-literal-inner)))
(defun parse-literal-inner ()
  (let ((tok (peek)))
    (cond ((eq tok :lb) (next)
           (let ((items '()))
             (if (eq (peek) :rb) (next)
                 (loop (push (parse-literal) items)
                       (let ((sep (next))) (cond ((eq sep :comma)) ((eq sep :rb) (return)) (t (fail "expected , or ]"))))))
             (list :list (nreverse items))))
          ((integerp tok) (next) (list :int tok))
          ((stringp tok) (next)
           (cond ((and (hashfn-p tok) (eq (peek) :lp)) (next) (let ((h (hash-literal tok (word)))) (expect :rp) h))
                 ((and (hashfn-p tok) (eq (peek) :colon)) (next) (hash-literal tok (word)))
                 ((hex-prefixed-p tok) (bytes-literal tok))
                 ((try-key tok) (list :key (try-key tok)))
                 (t (list :bytes (ascii->bytes tok)))))
          (t (fail "expected a literal, found ~s" tok)))))

(defun parse-vterm () (with-depth (parse-vterm-inner)))
(defun parse-vterm-inner ()
  (let ((tok (peek)))
    (cond ((integerp tok) (next) (list :lit (list :int tok)))
          ((eq tok :lb) (list :lit (parse-literal)))
          ((stringp tok)
           (cond ((and (hashfn-p tok) (member (nth (1+ *pos*) *toks*) '(:lp :colon))) (list :lit (parse-literal-inner)))
                 ((hex-prefixed-p tok) (next) (list :lit (bytes-literal tok)))
                 ((eq (nth (1+ *pos*) *toks*) :lp)
                  (next) (next)
                  (unless (member tok +value-fns+ :test #'string=) (fail "unknown value function ~a" tok))
                  (if (string= tok "operation_arg")
                      (let ((sym (word))) (expect :rp) (list :op tok (list (list :lit (list :symbol sym)))))
                      (list :op tok (parse-vterm-list))))
                 (t (next)
                    (cond ((member tok *bound* :test #'string=) (list :var tok))
                          ((try-key tok) (list :lit (list :key (try-key tok))))
                          (t (list :var tok))))))
          (t (fail "expected a value, found ~s" tok)))))

(defun parse-vterm-list ()
  (let ((out '()))
    (if (eq (peek) :rp) (next)
        (loop (push (parse-vterm) out)
              (let ((sep (next))) (cond ((eq sep :comma)) ((eq sep :rp) (return)) (t (fail "expected , or )"))))))
    (nreverse out)))

(defun parse-bterm-list ()
  (let ((out '()))
    (when (eq (peek) :rp) (next) (return-from parse-bterm-list '()))
    (loop (push (parse-bterm) out)
          (let ((sep (next))) (cond ((eq sep :comma)) ((eq sep :rp) (return)) (t (fail "expected , or )")))))
    (nreverse out)))

(defun parse-cmpop ()
  (let ((tok (next)))
    (case tok (:eq :eq) (:lt :lt) (:le :le) (:gt :gt) (:ge :ge)
      (t (fail "expected a comparison operator")))))

(defun num () (let ((n (next))) (unless (integerp n) (fail "expected an integer, found ~s" n)) n))

(defun parse-obligation-body (name)
  (flet ((v () (parse-vterm)))
    (cond ((string= name "pk") (prog1 (list :pk (v)) (expect :rp)))
          ((string= name "pk_h") (prog1 (list :pk-h (v)) (expect :rp)))
          ((string= name "pk_any") (prog1 (list :pk-any (v)) (expect :rp)))
          ((member name '("multi" "pk_threshold") :test #'string=)
           (let ((k (num))) (expect :comma) (prog1 (list :multi k (v)) (expect :rp))))
          ((string= name "hashlock") (prog1 (list :hashlock (v)) (expect :rp)))
          ((string= name "pointlock") (prog1 (list :pointlock (v)) (expect :rp)))
          ((string= name "attest")
           (let ((key (v))) (expect :comma)
             (let ((schema (let ((w (word))) (expect :lp) (unless (string= w "price_schema") (fail "unknown schema ~a" w)) (let ((n (num))) (expect :rp) (list :price-within-bps n)))))
               (expect :rp) (list :attest key schema))))
          (t (fail "unknown obligation ~a" name)))))

(defun obligation-name-p (w) (member w '("pk" "pk_h" "pk_any" "multi" "pk_threshold" "hashlock" "pointlock" "attest") :test #'string=))

(defun parse-bterm () (with-depth (parse-bterm-inner)))
(defun parse-bterm-inner ()
  (let ((name (word)))
    (cond ((string= name "true") (list :const t))
          ((string= name "false") (list :const nil))
          (t (expect :lp)
             (cond ((string= name "and") (list :and (parse-bterm-list)))
                   ((string= name "or") (list :or (parse-bterm-list)))
                   ((string= name "thresh") (let ((k (num))) (expect :comma) (list :thresh k (parse-bterm-list))))
                   ((string= name "not") (let ((b (parse-bterm))) (expect :rp) (list :not b)))
                   ((string= name "if") (let ((c (parse-bterm))) (expect :comma) (let ((th (parse-bterm))) (expect :comma) (let ((el (parse-bterm))) (expect :rp) (list :if c th el)))))
                   ((string= name "match") (parse-match))
                   ((string= name "cmp") (let ((op (parse-cmpop))) (expect :comma) (let ((a (parse-vterm))) (expect :comma) (let ((b (parse-vterm))) (expect :rp) (list :cmp op a b)))))
                   ((member name '("eq" "lt" "le" "gt" "ge") :test #'string=)
                    (let ((a (parse-vterm))) (expect :comma) (let ((b (parse-vterm))) (expect :rp) (list :cmp (intern (string-upcase name) :keyword) a b))))
                   ((string= name "prove") (let ((o (let ((n (word))) (expect :lp) (parse-obligation-body n)))) (expect :rp) (list :prove o)))
                   ((obligation-name-p name) (list :prove (parse-obligation-body name)))
                   ((hashfn-p name) (let ((h (hash-literal name (word)))) (expect :rp) (list :prove (list :hashlock (list :lit h)))))
                   ((member name +state-preds+ :test #'string=) (list :state name (parse-vterm-list)))
                   (t (fail "unknown combinator ~a" name)))))))

(defun parse-match ()
  (let ((scrutinee (parse-vterm)) (arms '()) (default nil))
    (expect :comma)
    (loop (let ((kw (word))) (unless (string= kw "branch") (fail "expected branch")))
          (expect :lp)
          (let ((tag (word))) (expect :comma)
            (let ((body (parse-bterm))) (expect :rp)
              (if (string= tag "else") (setf default body) (push (cons tag body) arms))))
          (let ((sep (next))) (cond ((eq sep :comma)) ((eq sep :rp) (return)) (t (fail "expected , or )")))))
    (unless default (fail "match is missing an else branch"))
    (list :match scrutinee (nreverse arms) default)))

(defun parse-with-or-bare ()
  (if (and (stringp (peek)) (string= (peek) "with"))
      (progn (next) (expect :lp)
             (let ((constants '()))
               (loop (when (and (stringp (peek)) (string= (peek) "in")) (next) (return))
                     (let ((name (word)))
                       (unless (canonical-name-p name) (fail "invalid constant name `~a`" name))
                       (expect :eq)
                       (let ((v (parse-literal)))
                         ;; the reference keeps the last binding of a name (a BTreeMap); validity refuses it
                         (when (assoc name constants :test #'string=)
                           (setf *duplicate-name* name constants (remove name constants :key #'car :test #'string=)))
                         (push (cons name v) constants))
                       (expect :comma)))
               (setf *bound* (mapcar #'car constants))
               (let ((body (parse-bterm))) (expect :rp) (values (nreverse constants) body))))
      (values '() (parse-bterm))))

(defun canonical-name-p (name)
  (and (plusp (length name))
       (let ((c (char name 0))) (or (char= c #\_) (char<= #\a c #\z)))
       (every (lambda (c) (or (char= c #\_) (char<= #\a c #\z) (ascii-digit-p c))) name)))

(defun parse-descriptor (text)
  "Descriptor text -> (:scheme :wsh|:tr :internal-key k :constants alist :body term)."
  (let ((*toks* (lex text)) (*pos* 0) (*bound* '()) (*depth* 0))
    (prog1 (parse-descriptor-tokens)
      (when (< *pos* (length *toks*)) (fail "trailing tokens after descriptor at position ~a" *pos*)))))

(defun parse-descriptor-tokens ()
    (cond ((equal (peek) "wsh") (next) (expect :lp)
           (multiple-value-bind (constants body) (parse-with-or-bare) (expect :rp)
             (list :scheme :wsh :constants constants :body body)))
          ((equal (peek) "tr") (next) (expect :lp)
           (let ((key (or (try-key (word)) (fail "bad tr internal key"))))
             (if (eq (peek) :comma)
                 (progn (next) (multiple-value-bind (constants body) (parse-with-or-bare) (expect :rp)
                                 (list :scheme :tr :internal-key key :constants constants :body body)))
                 (progn (expect :rp) (list :scheme :tr :internal-key key :constants '() :body nil)))))
          (t (multiple-value-bind (constants body) (parse-with-or-bare)
               (list :scheme :wsh :constants constants :body body)))))

;;; ---------------------------------------------------------------------------
;;; DEP-16 §Descriptor validity: may this text enter a ledger (DepositOpen, DepositKeyRotate)?
;;; The reference is deposits-core dep16/validity.rs; inspect/vectors/descriptor_validity.json
;;; pins both.

(defun descriptor-char-ok-p (c)
  (let ((n (char-code c))) (or (<= 9 n 13) (<= 32 n 126))))

(defun key-word-violation (w)
  (let ((hex (every #'hex-char-p w)))
    (cond ((and hex (= (length w) 130)) (format nil "`~a…` is an uncompressed key" (subseq w 0 8)))
          ((and hex (= (length w) 66) (not (try-key w))) (format nil "`~a…` is not a compressed secp256k1 key" (subseq w 0 8))))))

(defun polarity-violation (term positive)
  (ecase (first term)
    (:prove (unless positive "a proof obligation is in negative position"))
    (:not (polarity-violation (second term) nil))
    (:if (or (polarity-violation (second term) nil) (polarity-violation (third term) positive) (polarity-violation (fourth term) positive)))
    ((:and :or) (some (lambda (b) (polarity-violation b positive)) (second term)))
    (:thresh (some (lambda (b) (polarity-violation b positive)) (third term)))
    (:match (or (some (lambda (arm) (polarity-violation (cdr arm) positive)) (third term)) (polarity-violation (fourth term) positive)))
    ((:const :cmp :state) nil)))

(defun vterm-unresolved (vt names)
  (ecase (first vt)
    (:lit nil)
    (:var (unless (member (second vt) names :test #'string=) (second vt)))
    (:op (some (lambda (a) (vterm-unresolved a names)) (third vt)))))

(defun obligation-unresolved (o names)
  (ecase (first o)
    ((:pk :pk-h :pk-any :hashlock :pointlock) (vterm-unresolved (second o) names))
    (:multi (vterm-unresolved (third o) names))
    (:attest (vterm-unresolved (second o) names))))

(defun term-unresolved (term names)
  (ecase (first term)
    (:const nil)
    ((:and :or) (some (lambda (b) (term-unresolved b names)) (second term)))
    (:thresh (some (lambda (b) (term-unresolved b names)) (third term)))
    (:not (term-unresolved (second term) names))
    (:if (or (term-unresolved (second term) names) (term-unresolved (third term) names) (term-unresolved (fourth term) names)))
    (:match (or (vterm-unresolved (second term) names)
                (some (lambda (arm) (term-unresolved (cdr arm) names)) (third term))
                (term-unresolved (fourth term) names)))
    (:cmp (or (vterm-unresolved (third term) names) (vterm-unresolved (fourth term) names)))
    (:state (some (lambda (a) (vterm-unresolved a names)) (third term)))
    (:prove (obligation-unresolved (second term) names))))

(defun thresh-violation (term)
  (when (and (eq (first term) :thresh) (not (<= 1 (second term) (length (third term)))))
    (return-from thresh-violation (format nil "thresh needs 1 <= k <= ~a" (length (third term)))))
  (some #'thresh-violation
        (case (first term)
          ((:and :or) (second term))
          (:thresh (third term))
          (:not (list (second term)))
          (:if (list (second term) (third term) (fourth term)))
          (:match (append (mapcar #'cdr (third term)) (list (fourth term)))))))

(defun descriptor-violation (text)
  "NIL if TEXT is a valid descriptor (DEP-16 §Descriptor validity), else the reason it is not."
  (let ((bad (find-if-not #'descriptor-char-ok-p text)))
    (when bad (return-from descriptor-violation
                (format nil "character ~s is outside the descriptor character set" bad))))
  ;; Words: a 66-hex-digit word is a compressed key, none is 130 (uncompressed).
  (let ((i 0) (n (length text)))
    (loop while (< i n)
          do (if (word-char-p (char text i))
                 (let ((start i))
                   (loop while (and (< i n) (word-char-p (char text i))) do (incf i))
                   (let ((v (key-word-violation (subseq text start i))))
                     (when v (return-from descriptor-violation v))))
                 (incf i))))
  (handler-case
      (let* ((*duplicate-name* nil) (d (parse-descriptor text)) (body (getf d :body))
             (names (mapcar #'car (getf d :constants))))
        (if *duplicate-name*
            (format nil "name `~a` is bound twice" *duplicate-name*)
            (when body
              (or (polarity-violation body t)
                  (let ((u (term-unresolved body names))) (when u (format nil "name `~a` does not resolve" u)))
                  (thresh-violation body)))))
    (eval-error (e) (detail e))))

;;; ---------------------------------------------------------------------------
;;; Canonical bytes (DEP-17)

(defun u32 (n) (int->be n 4))
(defun u16 (n) (int->be n 2))
(defun bytes-field (b) (cat (u32 (length b)) b))
(defun sym (s) (bytes-field (ascii->bytes s)))
(defun int128 (n) (int->be (ldb (byte 128 0) n) 16))

(defun encode-value (v)
  (if (eq (first v) :subtree)
      (cat (octets 7) (encode-term (second v)))
      (d17:encode-value (if (eq (first v) :list) (list :list (second v)) v))))

(defun encode-vterm (vt)
  (ecase (first vt)
    (:lit (cat (octets 0) (encode-value (second vt))))
    (:var (cat (octets 1) (sym (second vt))))
    (:op (apply #'cat (octets 2) (u16 (id-of (second vt) +value-fns+)) (u32 (length (third vt))) (mapcar #'encode-vterm (third vt))))))

(defun encode-obligation (o)
  (let ((id (u16 (position (first o) +obligations+))))
    (ecase (first o)
      ((:pk :pk-h :pk-any :hashlock :pointlock) (cat id (encode-vterm (second o))))
      (:multi (cat id (u32 (second o)) (encode-vterm (third o))))
      (:attest (cat id (encode-vterm (second o)) (u16 0) (u32 (second (third o))))))))

(defun encode-term (term)
  (let ((tag (octets (position (first term) +node-tags+))))
    (ecase (first term)
      (:const (cat tag (octets (if (second term) 1 0))))
      ((:and :or) (apply #'cat tag (u32 (length (second term))) (mapcar #'encode-term (second term))))
      (:thresh (apply #'cat tag (u32 (second term)) (u32 (length (third term))) (mapcar #'encode-term (third term))))
      (:not (cat tag (encode-term (second term))))
      (:if (cat tag (encode-term (second term)) (encode-term (third term)) (encode-term (fourth term))))
      (:match (apply #'cat tag (encode-vterm (second term)) (u32 (length (third term)))
                     (append (loop for (name . body) in (third term) collect (cat (sym name) (encode-term body)))
                             (list (encode-term (fourth term))))))
      (:cmp (cat tag (octets (position (second term) +cmp-ops+)) (encode-vterm (third term)) (encode-vterm (fourth term))))
      (:state (apply #'cat tag (u16 (id-of (second term) +state-preds+)) (u32 (length (third term))) (mapcar #'encode-vterm (third term))))
      (:prove (cat tag (encode-obligation (second term)))))))

(defun encode-constants (constants)
  (apply #'cat (u32 (length constants))
         (loop for (name . v) in (sort (copy-list constants) #'string< :key #'car) collect (cat (sym name) (encode-value v)))))

(defun encode-descriptor (d)
  (ecase (getf d :scheme)
    (:wsh (cat (octets 1) (encode-constants (getf d :constants)) (encode-term (getf d :body))))
    (:tr (cat (octets 2) (bytes-field (getf d :internal-key)) (encode-constants (getf d :constants))
              (if (getf d :body) (cat (octets 1) (encode-term (getf d :body))) (octets 0))))))

(defun descriptor-id (d) (tagged-hash "dep17/descriptor" (encode-descriptor d)))

;;; Decoding

(defvar *buf*) (defvar *at*)
(defun take (n) (when (> (+ *at* n) (length *buf*)) (fail "truncated")) (prog1 (subseq *buf* *at* (+ *at* n)) (incf *at* n)))
(defun d-u8 () (aref (take 1) 0))
(defun d-u16 () (be->int (take 2)))
(defun d-u32 () (be->int (take 4)))
(defun d-u64 () (be->int (take 8)))
(defun d-int () (let ((n (be->int (take 16)))) (if (logbitp 127 n) (- n (ash 1 128)) n)))
(defun d-bytes () (take (d-u32)))
(defun d-sym () (bytes->ascii (d-bytes)))

(defun decode-value ()
  (ecase (d-u8)
    (0 (list :int (d-int)))
    (1 (list :key (d-bytes)))
    (2 (let ((fn (nth (d-u8) +hash-fns+))) (list :hash fn (take (if (member fn '(:sha256 :hash256)) 32 20)))))
    (3 (list :bytes (d-bytes)))
    (4 (list :path (loop repeat (d-u32) collect (d-u32))))
    (5 (list :list (loop repeat (d-u32) collect (decode-value))))
    (6 (list :symbol (d-sym)))
    (7 (list :subtree (decode-term)))))

(defun decode-vterm ()
  (ecase (d-u8)
    (0 (list :lit (decode-value)))
    (1 (list :var (d-sym)))
    (2 (let ((fn (nth (d-u16) +value-fns+))) (list :op fn (loop repeat (d-u32) collect (decode-vterm)))))))

(defun decode-obligation ()
  (let ((form (nth (d-u16) +obligations+)))
    (ecase form
      ((:pk :pk-h :pk-any :hashlock :pointlock) (list form (decode-vterm)))
      (:multi (let ((k (d-u32))) (list :multi k (decode-vterm))))
      (:attest (let ((v (decode-vterm))) (unless (zerop (d-u16)) (fail "unknown schema")) (list :attest v (list :price-within-bps (d-u32))))))))

(defun decode-term ()
  (ecase (nth (d-u8) +node-tags+)
    (:const (list :const (= 1 (d-u8))))
    (:and (list :and (loop repeat (d-u32) collect (decode-term))))
    (:or (list :or (loop repeat (d-u32) collect (decode-term))))
    (:thresh (let ((k (d-u32))) (list :thresh k (loop repeat (d-u32) collect (decode-term)))))
    (:not (list :not (decode-term)))
    (:if (let* ((c (decode-term)) (th (decode-term)) (el (decode-term))) (list :if c th el)))
    (:match (let* ((s (decode-vterm)) (arms (loop repeat (d-u32) collect (let ((name (d-sym))) (cons name (decode-term))))) (def (decode-term)))
              (list :match s arms def)))
    (:cmp (let* ((op (nth (d-u8) +cmp-ops+)) (a (decode-vterm)) (b (decode-vterm))) (list :cmp op a b)))
    (:state (let ((pred (nth (d-u16) +state-preds+))) (list :state pred (loop repeat (d-u32) collect (decode-vterm)))))
    (:prove (list :prove (decode-obligation)))))

(defun decode-constants () (loop repeat (d-u32) collect (let ((name (d-sym))) (cons name (decode-value)))))

(defun decode-descriptor (bytes)
  (let ((*buf* bytes) (*at* 0))
    (prog1 (ecase (d-u8)
             (1 (let* ((c (decode-constants)) (body (decode-term))) (list :scheme :wsh :constants c :body body)))
             (2 (let* ((key (d-bytes)) (c (decode-constants)) (present (= 1 (d-u8))))
                  (list :scheme :tr :internal-key key :constants c :body (and present (decode-term))))))
      (unless (= *at* (length bytes)) (fail "trailing bytes in descriptor")))))

;;; Witness, snapshot, operation

(defun decode-witness (bytes)
  "(:signatures ((key . sig)...) :preimages (((fn . digest) . preimage)...) :attestations (key...) :scalars ((key . s32)...))"
  (let ((*buf* bytes) (*at* 0))
    (let* ((version (d-u8))
           (sigs (loop repeat (d-u32) collect (let ((k (d-bytes))) (cons k (d-bytes)))))
           (pres (loop repeat (d-u32) collect (let* ((fn (nth (d-u8) +hash-fns+)) (digest (take (if (member fn '(:sha256 :hash256)) 32 20)))) (cons (cons fn digest) (d-bytes)))))
           (atts (loop repeat (d-u32) collect (d-bytes)))
           (scalars (when (>= version 2) (loop repeat (d-u32) collect (let ((k (d-bytes))) (cons k (d-bytes)))))))
      (unless (member version '(1 2)) (fail "witness version"))
      (list :signatures sigs :preimages pres :attestations atts :scalars scalars))))

(defun encode-witness (w)
  (let ((version (if (getf w :scalars) 2 1)))
    (apply #'cat (octets version)
           (u32 (length (getf w :signatures)))
           (append (loop for (k . s) in (sort (copy-list (getf w :signatures)) #'bytes< :key #'car) collect (cat (bytes-field k) (bytes-field s)))
                   (list (u32 (length (getf w :preimages))))
                   (loop for ((fn . d) . p) in (getf w :preimages) collect (cat (octets (position fn +hash-fns+)) d (bytes-field p)))
                   (list (u32 (length (getf w :attestations))))
                   (loop for k in (sort (copy-list (getf w :attestations)) #'bytes<) collect (bytes-field k))
                   (when (= version 2)
                     (cons (u32 (length (getf w :scalars)))
                           (loop for (k . s) in (sort (copy-list (getf w :scalars)) #'bytes< :key #'car) collect (cat (bytes-field k) (bytes-field s)))))))))

(defun make-witness (&key signatures preimages attestations scalars)
  (list :signatures signatures :preimages preimages :attestations attestations :scalars scalars))

(defun witness-from-stack (stack descriptor operation)
  "A DescriptorWitness stack (the ledger's wire form) as a calculus witness:
   64-byte items are signatures tried against the descriptor's keys, 32-byte
   items are preimages for its hashlocks (or scalars for its pointlocks)."
  (declare (ignore operation))
  (let ((keys (descriptor-keys descriptor)) (hashes (descriptor-hashes descriptor)) (points (descriptor-points descriptor))
        (sigs '()) (pres '()) (scalars '()))
    (dolist (item stack)
      (cond ((= (length item) 64) (dolist (k keys) (push (cons k item) sigs)))
            ((= (length item) 32)
             (dolist (h hashes) (when (equalp (hash-with (car h) item) (cdr h)) (push (cons h item) pres)))
             (dolist (p points) (push (cons p item) scalars)))
            (t (dolist (h hashes) (when (equalp (hash-with (car h) item) (cdr h)) (push (cons h item) pres))))))
    (make-witness :signatures sigs :preimages pres :scalars scalars)))

(defun decode-snapshot (bytes)
  (let ((*buf* bytes) (*at* 0))
    (unless (= 1 (d-u8)) (fail "snapshot version"))
    (let* ((balance (d-int)) (activity (d-u32)) (open (d-u32)) (received (d-u32)) (height (d-u32))
           (rolling (loop repeat (d-u32) collect (let* ((f (nth (d-u8) +rw-fields+)) (p (d-u32)) (a (d-int))) (list f p a))))
           (cum (loop repeat (d-u32) collect (let ((path (loop repeat (d-u32) collect (d-u32)))) (cons path (d-int))))))
      (list :balance balance :blocks-since-activity activity :blocks-since-open open :blocks-since-received received
            :height height :rolling rolling :cumulative cum))))

(defun encode-snapshot (s)
  (apply #'cat (octets 1) (int128 (getf s :balance)) (u32 (getf s :blocks-since-activity)) (u32 (getf s :blocks-since-open))
         (u32 (or (getf s :blocks-since-received) 0)) (u32 (getf s :height))
         (u32 (length (getf s :rolling)))
         (append (loop for (f p a) in (getf s :rolling) collect (cat (octets (id-of f +rw-fields+)) (u32 p) (int128 a)))
                 (list (u32 (length (getf s :cumulative))))
                 (loop for (path . a) in (getf s :cumulative) collect (apply #'cat (u32 (length path)) (append (mapcar #'u32 path) (list (int128 a))))))))

(defun make-snapshot (&key (balance 0) (blocks-since-activity 0) (blocks-since-open 0) (blocks-since-received 0) (height 0) rolling cumulative)
  (list :balance balance :blocks-since-activity blocks-since-activity :blocks-since-open blocks-since-open
        :blocks-since-received blocks-since-received :height height :rolling rolling :cumulative cumulative))

(defun decode-operation (bytes)
  (let ((*buf* bytes) (*at* 0))
    (unless (= 1 (d-u8)) (fail "operation version"))
    (let* ((deposit (take 32)) (type (d-sym)) (args (loop repeat (d-u32) collect (let ((n (d-sym))) (cons n (decode-value))))) (nonce (d-u64)) (expiry (d-u32)))
      (list :deposit-id deposit :op-type type :args args :nonce nonce :expiry expiry))))

(defun make-operation (&key deposit-id op-type args (nonce 0) (expiry #xffffffff))
  (list :deposit-id deposit-id :op-type op-type :args args :nonce nonce :expiry expiry))

(defun operation-preimage (o)
  (d17:operation-preimage (getf o :deposit-id) (getf o :op-type) (getf o :args) (getf o :nonce) (getf o :expiry)))

;;; ---------------------------------------------------------------------------
;;; Descriptor introspection (keys, hashes, points it mentions)

(defun walk-values (term fn)
  (labels ((v (vt) (case (first vt) (:lit (funcall fn (second vt))) (:op (mapc #'v (third vt)))))
           (o (ob) (ecase (first ob) ((:pk :pk-h :pk-any :hashlock :pointlock :attest) (v (second ob))) (:multi (v (third ob)))))
           (tm (x) (when x (ecase (first x)
                            (:const) ((:and :or) (mapc #'tm (second x))) (:thresh (mapc #'tm (third x))) (:not (tm (second x)))
                            (:if (tm (second x)) (tm (third x)) (tm (fourth x)))
                            (:match (v (second x)) (loop for (nil . b) in (third x) do (tm b)) (tm (fourth x)))
                            (:cmp (v (third x)) (v (fourth x))) (:state (mapc #'v (third x))) (:prove (o (second x)))))))
    (tm term)))

(defun collect-values (d pred)
  (let ((out '()))
    (flet ((grab (val) (labels ((g (v) (cond ((funcall pred v) (push v out)) ((eq (first v) :list) (mapc #'g (second v)))))) (g val))))
      (dolist (c (getf d :constants)) (grab (cdr c)))
      (walk-values (getf d :body) #'grab))
    (remove-duplicates out :test #'equalp)))

(defun descriptor-keys (d) (append (and (eq (getf d :scheme) :tr) (list (getf d :internal-key))) (mapcar #'second (collect-values d (lambda (v) (eq (first v) :key))))))
(defun descriptor-hashes (d) (mapcar (lambda (v) (cons (second v) (third v))) (collect-values d (lambda (v) (eq (first v) :hash)))))
(defun descriptor-points (d) (descriptor-keys d))

;;; ---------------------------------------------------------------------------
;;; Evaluation

(defun hash-with (fn bytes)
  (ecase fn
    (:sha256 (sha256 bytes)) (:hash256 (sha256 (sha256 bytes)))
    (:ripemd160 (cl-consensus.wire:hash160 (coerce bytes 'octets)))   ; placeholder: no bare ripemd here
    (:hash160 (cl-consensus.wire:hash160 (coerce bytes 'octets)))))

(defun verify-signature (key message sig)
  "ECDSA compact, low-S, over the DEP-17 sighash, under a 33-byte key."
  (and (= (length key) 33) (= (length sig) 64)
       (< (be->int sig :start 32) (floor secp:*secp256k1-n* 2))
       (d17:ecdsa-compact-verify key (d17:operation-sighash message) sig)))

(defun key-hashes-to (key h)
  (and (eq (car h) :hash160) (equalp (cl-consensus.wire:hash160 (coerce key 'octets)) (cdr h))))

(defun point-is-scalar-image (point scalar)
  (let ((s (be->int scalar)))
    (and (< 0 s secp:*secp256k1-n*) (equalp (cl-deposits.update:public-scalar-point s) point))))

(defvar *budget*)
(defun charge (n) (when *budget* (when (< (decf (car *budget*) n) 0) (fail "budget exhausted"))))

(defun as-int (v) (if (eq (first v) :int) (second v) (fail "expected an integer")))
(defun as-key (v) (if (eq (first v) :key) (second v) (fail "expected a key")))
(defun as-keys (v) (if (eq (first v) :list) (mapcar #'as-key (second v)) (fail "expected a list of keys")))
(defun as-path (v) (if (eq (first v) :path) (second v) (fail "expected a path")))

(defun sat (n) (max (- (ash 1 127)) (min (1- (ash 1 127)) n)))
(defun pct (a p) (floor (* a p) 100))
(defun bps (a b) (floor (* a b) 10000))

(defun node-at (d path)
  "The descriptor node at PATH: the body's subterm by child indices; for tr,
   path (0) is the internal key.  Returns (values node kind) or NIL."
  (labels ((children (x) (case (first x) ((:and :or) (second x)) (:thresh (third x)) (:not (list (second x)))
                           (:if (list (second x) (third x) (fourth x))) (:match (append (mapcar #'cdr (third x)) (list (fourth x)))) (t '())))
           (walk (x p) (if (null p) x (let ((c (nth (car p) (children x)))) (and c (walk c (cdr p)))))))
    (cond ((and (eq (getf d :scheme) :tr) (equal path '(0))) (values (getf d :internal-key) :key))
          (t (let ((n (walk (getf d :body) path))) (and n (values n :body)))))))

(defun shape (term) (string-downcase (symbol-name (first term))))

(defun eval-v (vt env d op st)
  (charge 1)
  (ecase (first vt)
    (:lit (second vt))
    (:var (or (cdr (assoc (second vt) env :test #'string=)) (fail "unresolved variable ~a" (second vt))))
    (:op (let* ((fn (second vt)) (args (mapcar (lambda (a) (eval-v a env d op st)) (third vt))))
           (flet ((i (k) (as-int (nth k args))))
             (cond ((string= fn "add") (list :int (sat (+ (i 0) (i 1)))))
                   ((string= fn "sub") (list :int (sat (- (i 0) (i 1)))))
                   ((string= fn "mul") (list :int (sat (* (i 0) (i 1)))))
                   ((string= fn "div") (list :int (if (zerop (i 1)) 0 (floor (i 0) (i 1)))))
                   ((string= fn "min") (list :int (min (i 0) (i 1))))
                   ((string= fn "max") (list :int (max (i 0) (i 1))))
                   ((string= fn "pct") (list :int (pct (i 0) (i 1))))
                   ((string= fn "bps") (list :int (bps (i 0) (i 1))))
                   ((string= fn "operation_type") (list :symbol (getf op :op-type)))
                   ((string= fn "operation_arg")
                    (let ((name (second (nth 0 args)))) (or (cdr (assoc name (getf op :args) :test #'string=)) (fail "operation has no arg ~a" name))))
                   ((string= fn "operation_path") (or (cdr (assoc "path" (getf op :args) :test #'string=)) (fail "operation has no path")))
                   ((string= fn "operation_subtree") (or (cdr (assoc "subtree" (getf op :args) :test #'string=)) (fail "operation has no subtree")))
                   ((string= fn "blocks_since_activity") (list :int (getf st :blocks-since-activity)))
                   ((string= fn "blocks_since_open") (list :int (getf st :blocks-since-open)))
                   ((string= fn "blocks_since_received") (list :int (or (getf st :blocks-since-received) 0)))
                   ((string= fn "deposit_balance") (list :int (getf st :balance)))
                   ((string= fn "rolling_window")
                    (let ((field (second (nth 0 args))) (period (i 1)))
                      (list :int (or (third (find-if (lambda (r) (and (string= (first r) field) (= (second r) period))) (getf st :rolling))) 0))))
                   ((string= fn "cumulative_spent_via")
                    (list :int (or (cdr (assoc (as-path (nth 0 args)) (getf st :cumulative) :test #'equal)) 0)))
                   ((string= fn "path") (list :path (mapcar #'as-int args)))
                   ((string= fn "ast_ref")
                    (multiple-value-bind (node kind) (node-at d (as-path (nth 0 args)))
                      (cond ((null node) (fail "path out of range")) ((eq kind :key) (list :key node)) (t (list :subtree node)))))
                   ((string= fn "ast_shape_at")
                    (multiple-value-bind (node kind) (node-at d (as-path (nth 0 args)))
                      (cond ((null node) (fail "path out of range")) ((eq kind :key) (list :symbol "internal_key")) (t (list :symbol (shape node))))))
                   (t (fail "unknown value function ~a" fn))))))))

(defun eval-cmp (o a b)
  (if (eq o :eq)
      (equalp a b)
      (let ((x (as-int a)) (y (as-int b)))
        (ecase o (:lt (< x y)) (:le (<= x y)) (:gt (> x y)) (:ge (>= x y))))))

(defun eval-state (pred args d op st)
  (charge 1)
  (flet ((amount () (as-int (or (cdr (assoc "amount" (getf op :args) :test #'string=)) (fail "operation has no amount"))))
         (a (k) (as-int (nth k args)))
         (dest () (or (cdr (assoc "destination" (getf op :args) :test #'string=)) (fail "operation has no destination"))))
    (cond ((string= pred "older") (>= (getf st :blocks-since-activity) (a 0)))
          ((string= pred "after") (>= (getf st :height) (a 0)))
          ((string= pred "amount_at_most") (<= (amount) (a 0)))
          ((string= pred "amount_in_range") (and (>= (amount) (a 0)) (<= (amount) (a 1))))
          ((string= pred "amount_at_most_pct") (<= (amount) (pct (getf st :balance) (a 0))))
          ((string= pred "destination_is") (equalp (dest) (nth 0 args)))
          ((string= pred "destination_in") (let ((set (nth 0 args))) (unless (eq (first set) :list) (fail "destination_in expects a list")) (and (member (dest) (second set) :test #'equalp) t)))
          ((string= pred "balance_at_least") (>= (getf st :balance) (a 0)))
          ((string= pred "balance_at_most") (<= (getf st :balance) (a 0)))
          ((string= pred "blocks_since_activity_at_least") (>= (getf st :blocks-since-activity) (a 0)))
          ((string= pred "blocks_since_open_below") (< (getf st :blocks-since-open) (a 0)))
          ((string= pred "blocks_since_open_at_least") (>= (getf st :blocks-since-open) (a 0)))
          ((string= pred "blocks_since_received_at_least") (>= (or (getf st :blocks-since-received) 0) (a 0)))
          ((string= pred "rolling_amount_below")
           (let ((field (second (nth 0 args))) (period (a 1)))
             (< (or (third (find-if (lambda (r) (and (string= (first r) field) (= (second r) period))) (getf st :rolling))) 0) (a 2))))
          ((string= pred "rolling_amount_below_pct")
           (let ((field (second (nth 0 args))) (period (a 1)))
             (< (or (third (find-if (lambda (r) (and (string= (first r) field) (= (second r) period))) (getf st :rolling))) 0) (pct (getf st :balance) (a 2)))))
          ((string= pred "subtree_at")
           (multiple-value-bind (node kind) (node-at d (as-path (nth 0 args)))
             (let ((cand (nth 1 args)))
               (cond ((null node) nil)
                     ((and (eq kind :body) (eq (first cand) :subtree)) (equalp (second cand) node))
                     ((and (eq kind :key) (eq (first cand) :key)) (equalp (second cand) node))
                     (t nil)))))
          (t (fail "unknown state predicate ~a" pred)))))

(defun verify-o (o env d op st w)
  (charge 1)
  (let ((message (operation-preimage op)))
    (flet ((signed-by (key) (let ((sig (cdr (assoc key (getf w :signatures) :test #'equalp)))) (and sig (verify-signature key message sig))))
           (v (x) (eval-v x env d op st)))
      (ecase (first o)
        (:pk (signed-by (as-key (v (second o)))))
        (:pk-any (some #'signed-by (as-keys (v (second o)))))
        (:multi (let ((keys (remove-duplicates (as-keys (v (third o))) :test #'equalp)))
                  (>= (count-if #'signed-by keys) (second o))))
        (:pk-h (let ((h (let ((val (v (second o)))) (if (eq (first val) :hash) (cons (second val) (third val)) (fail "pk_h expects a key hash")))))
                 (some (lambda (entry) (and (key-hashes-to (car entry) h) (verify-signature (car entry) message (cdr entry)))) (getf w :signatures))))
        (:hashlock (let* ((val (v (second o))) (h (if (eq (first val) :hash) (cons (second val) (third val)) (fail "hashlock expects a hash")))
                          (pre (cdr (assoc h (getf w :preimages) :test #'equalp))))
                     (and pre (equalp (hash-with (car h) pre) (cdr h)))))
        (:pointlock (let* ((point (as-key (v (second o)))) (s (cdr (assoc point (getf w :scalars) :test #'equalp))))
                      (and s (point-is-scalar-image point s))))
        (:attest (let ((key (as-key (v (second o)))))
                   (and (member key (getf w :attestations) :test #'equalp) t)))))))

(defun eval-b (term env d op st w)
  (charge 1)
  (ecase (first term)
    (:const (second term))
    (:and (every (lambda (x) (eval-b x env d op st w)) (second term)))
    (:or (some (lambda (x) (eval-b x env d op st w)) (second term)))
    (:thresh (>= (count-if (lambda (x) (eval-b x env d op st w)) (third term)) (second term)))
    (:not (not (eval-b (second term) env d op st w)))
    (:if (if (eval-b (second term) env d op st w) (eval-b (third term) env d op st w) (eval-b (fourth term) env d op st w)))
    (:match (let ((sv (eval-v (second term) env d op st)))
              (let ((arm (and (eq (first sv) :symbol) (assoc (second sv) (third term) :test #'string=))))
                (eval-b (if arm (cdr arm) (fourth term)) env d op st w))))
    (:cmp (eval-cmp (second term) (eval-v (third term) env d op st) (eval-v (fourth term) env d op st)))
    (:state (eval-state (second term) (mapcar (lambda (a) (eval-v a env d op st)) (third term)) d op st))
    (:prove (verify-o (second term) env d op st w))))

(defun evaluate (d op st w &key (budget 100000))
  "Does descriptor D authorize operation OP given snapshot ST and witness W?"
  (let ((*budget* (and budget (list budget))) (env (getf d :constants)))
    (and (ecase (getf d :scheme)
           (:wsh (eval-b (getf d :body) env d op st w))
           (:tr (let* ((key (getf d :internal-key))
                       (sig (cdr (assoc key (getf w :signatures) :test #'equalp)))
                       (message (operation-preimage op)))
                  (or (and sig (schnorr:schnorr-verify (if (= (length key) 33) (subseq key 1) key) (d17:operation-sighash message) sig))
                      (and (getf d :body) (eval-b (getf d :body) env d op st w))))))
         t)))
