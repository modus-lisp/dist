# redteam/_lib.sh — shared by the scenario scripts.  Source after devnet/_common.sh and $S/env.
# In a soak turn (devnet/soak-attackers.sh sets ATTACK_NAME) a scenario that has called setup_phase
# reports a failure BEFORE its fault lands as "INVALID: setup: ...": no attack happened, so nothing is
# owed a proof and the oracle must not count a MISS (signet, 2026-11-20/21: three of four MISSes were
# turns that died in form_ledger).  fault_landed ends the setup phase and records the landing in
# $S/attack-landed.tsv, which the oracle requires before it judges a scheduled turn.  Outside a soak
# turn (the regtest suite) a setup failure stays a FAIL: there it is a regression to see.
SCENARIO_PHASE=
setup_phase() { SCENARIO_PHASE=setup; }
fault_landed() {   # fault_landed LEDGER DETAIL... — the fault is on chain or on the relay
  SCENARIO_PHASE=attack
  [ -n "${ATTACK_NAME:-}" ] && echo "$(date +%s) $ATTACK_NAME $*" >>"$S/attack-landed.tsv"
  return 0
}
fail() {
  if [ -n "${ATTACK_NAME:-}" ] && [ "$SCENARIO_PHASE" = setup ]; then echo "INVALID: setup: $*" >&2; exit 75; fi
  echo "FAIL: $*" >&2; exit 1
}
# node_log NODE — NODE's log since log_mark NODE (the whole log if never marked).  The daemon takes
# (:log :tail N) or (:log :since K); a (:log :n N) is NOT a bound, it returns every line since the node
# started, earlier runs' included (signet, 2026-11-21: attack-vault-anchored saw the PREVIOUS run's
# "lapsed-challenge proof against" on a cld7 up since Nov 19, failed, and so never mined past the
# challenge window).  A node restarted since its mark (count below the mark) gives its whole log.
declare -gA LOGMARK=()
log_count() { cld_ctl "$1" '(:log :tail 0)' 2>/dev/null | grep -oE ':COUNT [0-9]+' | head -1 | cut -d' ' -f2; }
log_mark() { local n c; for n in "$@"; do case $n in cld*) c=$(log_count "$n"); LOGMARK[$n]=${c:-0};; esac; done; }
node_log() {
  local n=$1 k=${LOGMARK[$1]:-} out c
  [ -n "$k" ] || { cld_ctl "$n" '(:log)'; return; }
  out=$(cld_ctl "$n" "(:log :since $k)")
  c=$(grep -oE ':COUNT [0-9]+' <<<"$out" | head -1 | cut -d' ' -f2)
  if [ -n "$c" ] && [ "$c" -lt "$k" ]; then cld_ctl "$n" '(:log)'; else printf '%s\n' "$out"; fi
}
# The red team attacks whatever devnet _common.sh selected, and that defaults to signet, where the
# overnight soak runs.  A scenario run without DEVNET=regtest once attacked the live soak, so
# signet takes an explicit opt-in.
if [ "${CLD_CHAIN:-}" = signet ] && [ "${REDTEAM_ON_SIGNET:-}" != 1 ]; then
  echo "FAIL: refusing to attack the signet devnet (its soak); run with DEVNET=regtest, or REDTEAM_ON_SIGNET=1" >&2; exit 2
fi
# Every check times out instead of hanging: CHECK_TIMEOUT seconds (default 2700), then FAIL.
if [ -z "${CHECK_WATCHDOG:-}" ]; then
  export CHECK_WATCHDOG=1
  trap 'echo "FAIL: $(basename "$0") timed out after ${CHECK_TIMEOUT:-2700}s" >&2; exit 124' TERM
  ( sleep "${CHECK_TIMEOUT:-2700}"; kill -TERM $$ 2>/dev/null; pkill -TERM -P $$ 2>/dev/null ) </dev/null >/dev/null 2>&1 &
  CHECK_WATCHDOG_PID=$!; disown $CHECK_WATCHDOG_PID   # a script's bare `wait` must not wait for it
  trap 'kill $CHECK_WATCHDOG_PID 2>/dev/null' EXIT
fi
pubkey_of() {   # pubkey_of NODE — its protocol key, cached in $S/pubkey.NODE (a key never changes)
  local c="$S/pubkey.$1" k i; [ -s "$c" ] && { cat "$c"; return 0; }
  for i in 1 2 3 4 5 6; do
    k=$(case $1 in cld*) cld_pubkey "$1";; ref*) ref_pubkey "$1";; esac)
    [ -n "$k" ] && { echo "$k" >"$c"; echo "$k"; return 0; }; sleep 5
  done; fail "no pubkey for $1"
}
# poll SECS CMD... — run CMD every 5 s until it succeeds (0) or SECS pass (1).  For a log line a
# node writes AFTER the chain event the check just saw (a claim's "won" follows its confirmation; a
# spend's line follows its manifest publication): grep once and the check races the node
# (regtest 1120-233824, 1121-042712: both rearm-rust FAILs were that race, the node right).
poll() { local secs=$1 t0=$SECONDS; shift; until "$@"; do [ $((SECONDS - t0)) -ge "$secs" ] && return 1; sleep 5; done; }
# won_lines PATTERN NODE... — each node's first log line containing PATTERN, prefixed by the node.
won_lines() { local pat=$1 n; shift; for n in "$@"; do cld_ctl $n '(:log)' 2>/dev/null | tr '"' '\n' | grep -F "$pat" | head -1 | sed "s/^/$n /"; done; }
# await_won SECS PATTERN NODE... — won_lines once any node has logged PATTERN, mining a block every
# 30 s meanwhile (a winner logs after its claim's broadcast and DisputeAcquire, and the claim can be
# seen first); prints nothing and returns 1 after SECS.
await_won() {
  local secs=$1 pat=$2 t0=$SECONDS k=0 out; shift 2
  while :; do
    out=$(won_lines "$pat" "$@"); [ -n "$out" ] && { echo "$out"; return 0; }
    [ $((SECONDS - t0)) -ge "$secs" ] && return 1
    k=$((k + 1)); [ $((k % 6)) -eq 0 ] && mine 1 >/dev/null; sleep 5
  done
}
expect() { case "$1" in *":STATUS :OK"*) ;; *) fail "${2:+$2: }${1:-no answer (control port timed out?)}";; esac; }
own_ledger() {      # own_ledger NODE — the ledger NODE cites as a member; opened and recorded in $S/env on first use
  local var id; case $1 in cld*) var="L${1#cld}";; ref*) var="RL${1#ref}";; esac
  [ -f "$S/env" ] && source "$S/env"
  if [ -z "${!var:-}" ]; then
    case $1 in
      cld*) id=$(sx "$(cld_ctl "$1" "(:open-ledger :reserves-id \"genesis:$1:redteam:$RANDOM\")")" ":LEDGER");;
      ref*) id=$(ref_ledger "$1"); [ -n "$id" ] || id=$(ref_cli "$1" ledger open --collateral-ratio 0.5 | sed -nE 's/.*Ledger ID: ([0-9a-f]{64}).*/\1/p');;
    esac
    [ -n "$id" ] || fail "own ledger for $1"; printf '%s=%s\n' "$var" "$id" >>"$S/env"; declare -g "$var=$id"
  fi; echo "${!var}"
}
outpoint_vout() {   # outpoint_vout TXID ADDRESS
  bcli getrawtransaction "$1" true | python3 -c "import json,sys; tx=json.load(sys.stdin); print([o['n'] for o in tx['vout'] if o['scriptPubKey'].get('address')=='$2'][0])"
}
out_sats() {        # out_sats TXID VOUT
  bcli getrawtransaction "$1" true | python3 -c "import json,sys; tx=json.load(sys.stdin); print(round(tx['vout'][$2]['value']*1e8))"
}
consent() {         # consent LEDGER OPERATOR MEMBER... — a reference member's consent can time out under load: retry
  local l=$1 op=$2 m r i; shift 2
  for m in "$@"; do
    for i in 1 2 3 4 5 6; do   # a reference node can hang and be restarted by the devnet watchdog: ride it out
      r=$(cld_ctl "$op" "(:add-member :ledger \"$l\" :member \"$(pubkey_of $m)\" :member-ledger \"$(own_ledger "$m")\"${RESP:+ :dispute-response-blocks $RESP}${DORM:+ :dormancy-blocks $DORM :dormancy-notice-blocks ${DORM_NOTICE:-3}})")
      [[ "$r" == *":STATUS :OK"* ]] && break; sleep 20
    done; expect "$r" "add-member $m"
  done
}
# form_ledger ROWNAME OPERATOR RULESET MEMBER... — a fresh funded ledger, remembered in $S/redteam-ROWNAME
# (its reserves outpoint in ROWNAME.outpoint).  Prints the ledger id.  RULESET "" means the default.
# COLLATERAL_SATS (default 25000000: DEP-05 needs >= 20%) of the 0.5 BTC vault is collateral, the rest reserves.  RESP (blocks), when
# set, is each member's dispute_response_blocks: the arm window, so a scenario need not mine ~720 blocks.
form_ledger() {
  local row="$S/redteam-$1" op=$2 rs=${3:-${FORM_RULESET:-}} l prep addr txid vout coll=${COLLATERAL_SATS:-25000000}; shift 3   # DEP-05 floor: >= 20%
  # No member on stale code, and the operator neither: a cached row's ledger was formed earlier, and
  # its nodes need not have gone through pick since (2026-11-19: cld7..24 sat on 844a7fa all run).
  local m; for m in "$op" "$@"; do case $m in ref*) ref_ensure_current "$m";; cld*) cld_ensure_current "$m";; esac; done
  if [ -f "$row" ]; then cat "$row"; return; fi
  l=$(sx "$(cld_ctl "$op" "(:open-ledger :reserves-id \"genesis:$op:redteam-$(basename "$row"):$RANDOM\" :reserves-msat 25000000000 :collateral-msat 25000000000${OPEN_RULESET:+ :ruleset \"$OPEN_RULESET\"})")" ":LEDGER")
  [ -n "$l" ] || fail "open ledger $(basename "$row")"
  consent "$l" "$op" "$@" >&2
  prep=$(cld_ctl "$op" "(:prepare-quorum :ledger \"$l\" :expiry-blocks ${FORM_EXPIRY:-4320}${rs:+ :ruleset \"$rs\"})"); expect "$prep" "prepare-quorum"; addr=$(sx "$prep" ":ADDRESS")
  # An empty txid is a refused sendtoaddress (signet, 2026-11-21 15:01: "Work queue depth exceeded"),
  # which used to reach begin-quorum as `:TXID "" :VOUT` and fail as a malformed plist.  And the
  # members refuse to cosign an unconfirmed reserves outpoint, so wait for it rather than retry into
  # "0 of 3 cosignatures" (2026-11-21 23:14).
  for i in 1 2 3 4 5; do txid=$(wcli sendtoaddress "$addr" 0.5 2>/dev/null); [ -n "$txid" ] && break; sleep 10; done
  [ -n "$txid" ] || fail "fund $(basename "$row"): sendtoaddress $addr returned no txid"
  mine 3 >/dev/null || echo "   $(basename "$row"): mine 3 fell short; waiting for the funding to confirm" >&2
  await_confs "$txid" "${CLD_MIN_CONFS:-1}" "${FUND_CONF_WAIT:-600}" || fail "fund $(basename "$row"): $txid unconfirmed after ${FUND_CONF_WAIT:-600}s"
  vout=$(outpoint_vout "$txid" "$addr")
  [ -n "$vout" ] || fail "fund $(basename "$row"): no output to $addr in $txid"
  local r i; for i in 1 2 3; do   # a busy member can miss the cosign round: retry
    r=$(cld_ctl "$op" "(:begin-quorum :ledger \"$l\" :txid \"$txid\" :vout $vout :sats $(( 50000000 - coll )) :collateral-sats $coll)")
    case "$r" in *":STATUS :OK"*) break;; *"cosignatures"*) echo "   begin-quorum retry $i: $r" >&2; sleep 15;; *) break;; esac
  done
  expect "$r" "begin-quorum"
  cld_ctl "$op" "(:advertise :ledger \"$l\")" >/dev/null 2>&1
  await_active "$l" "$@" >&2
  echo "$txid $vout" > "$row.outpoint"; echo "$l" > "$row"; echo "$l"
}
# await_active LEDGER NODE... — until each cl NODE's replica has applied the QuorumBegin (a member that
# has only cosigned it refuses requests that need it, e.g. theft_sign's "no QuorumBegin").  60 s cap.
await_active() {
  local l=$1 n i; shift
  for n in "$@"; do
    case $n in cld*) ;; *) continue;; esac
    for i in $(seq 1 30); do
      cld_ctl "$n" "(:info)" 2>/dev/null | grep -qE "\(:ID \"$l\"[^)]*:QUORUM :ACTIVE" && break; sleep 2
    done
  done
}
# fresh_deposits ROWNAME OPERATOR LEDGER N [MSAT] — N cl wallet deposits (w1..wN) on a form_ledger ledger,
# each credited MSAT (default 20000000) by its operator.  Prints the deposit ids, one per line.
fresh_deposits() {
  local row="$S/redteam-$1" op=$2 l=$3 n=$4 msat=${5:-20000000} i d txid vout out
  if [ -f "$row.deposits" ]; then cat "$row.deposits"; return; fi
  read -r txid vout <"$row.outpoint"
  for i in $(seq 1 "$n"); do
    out=$("$CLD_SRC/devnet/cld-wallet.sh" "w$i" "$l" open); d=$(sx "$out" ":DEPOSIT")
    [ -n "$d" ] || fail "w$i open on $1: ${out:-no reply}"
    expect "$(cld_ctl "$op" "(:credit :ledger \"$l\" :deposit \"$d\" :msat $msat :txid \"$txid\" :vout $vout)")"
    echo "$d" >>"$row.deposits.tmp"
  done
  mv "$row.deposits.tmp" "$row.deposits"; cat "$row.deposits"
}
# vault_spend OPERATOR LEDGER ADDRESS [TIER] — the colluders must already be armed (:theft-sign).
# Talks to the control port directly: the daemon's signature window (90 s) outlasts cld_ctl's 60 s.
vault_spend() {   # [ANCHOR]: "tip" or 64 hex, a forged anchor (DEP-06 §Spend challenge)
  printf '%s\n' "(:vault-spend :ledger \"$2\" :address \"$3\" :tier ${4:-0}${5:+ :anchor \"$5\"})" |
    timeout 180 bash -c "exec 3<>/dev/tcp/127.0.0.1/$(cld_port "$1"); cat >&3; head -n1 <&3"
}
# accused NODE LEDGER [SECS] — run NODE's vault watch now; true if it logs VAULT SPEND for LEDGER
# within SECS (default 180).  After mining hundreds of blocks a pass scans them all, which outlasts
# one control call (60 s), so poll the log rather than trusting the call's return.
accused() {
  local i
  cld_ctl "$1" '(:vault-watch)' >/dev/null 2>&1
  for i in $(seq 1 $(( ${3:-180} / 10 ))); do
    cld_ctl "$1" '(:log)' 2>/dev/null | grep -q "VAULT SPEND: ${2:0:8}" && return 0
    sleep 10; cld_ctl "$1" '(:vault-watch)' >/dev/null 2>&1
  done; return 1
}
# proved_lapsed NODE LEDGER [SECS] — run NODE's vault watch until it publishes a lapsed-challenge
# proof for a spend of LEDGER (DEP-06): true if it does within SECS (default 300).
proved_lapsed() {
  local i
  for i in $(seq 1 $(( ${3:-300} / 10 ))); do
    cld_ctl "$1" '(:vault-watch)' >/dev/null 2>&1
    node_log "$1" 2>/dev/null | grep -q "lapsed-challenge proof against its ledger ${2:0:8}" && return 0
    sleep 10
  done; return 1
}
arm()    { local k=$1 n; shift; for n in "$@"; do expect "$(cld_ctl "$n" "(:adversary :set $k t)")"; done; }
disarm() { local k=$1 n; shift; for n in "$@"; do cld_ctl "$n" "(:adversary :set $k nil)" >/dev/null 2>&1; done; }
# Actors.  Contagion taints a key for good (a theft it signed, a fraud it committed, a false accusation):
# every later ledger it operates is disputed on sight, so a scenario that needs a clean operator or a
# clean honest member must not reuse it.  $S/redteam-tainted lists tainted cl nodes; a scenario calls
# `taint` on the keys it burns.  clean_cl prints the untainted cl nodes, freshest (highest-numbered) first,
# and also drops — and records — a node any of whose operated ledgers its own :info shows disputed.
TAINTED="$S/redteam-tainted"
taint() { local n; for n in "$@"; do grep -qx "$n" "$TAINTED" 2>/dev/null || echo "$n" >>"$TAINTED"; done; }
tainted() { grep -qx "$1" "$TAINTED" 2>/dev/null; }
clean_cl() {
  local n info; for n in $(cld_names | sort -t d -k2 -nr); do
    tainted "$n" && continue
    [[ " ${REDTEAM_AVOID:-} " == *" $n "* ]] && continue   # clean but busy (e.g. still in an earlier scenario's dispute)
    info=$(cld_ctl "$n" '(:info)' 2>/dev/null)
    [[ "$info" == *":STATUS :OK"* ]] || continue   # not answering (still loading, or down): not an actor
    if grep -qE ':OWNED T [^)]*:DISPUTED [1-9]' <<<"$info"; then taint "$n"; continue; fi
    echo "$n"
  done
}
# pick ROLE... — bind each named shell variable to a distinct clean cl node (in order).  Not enough clean
# nodes is a SKIP, not a FAIL: the scenario cannot tell its result apart from earlier taint.
# mint_cl K — on regtest, start K more cl nodes with fresh keys (cldN+1..), each with collateral coins,
# so a scenario never runs out of untainted actors.  They persist (counted in $CLD_ROOT/minted-cl).
mint_cl() {   # on signet only for the adversarial soak (REDTEAM_MINT=1): new nodes run the version cld7 runs
  [ "$CLD_CHAIN" = regtest ] || [ "${REDTEAM_MINT:-}" = 1 ] || return 1
  local k=$1 have i n a j minted
  have=$(cld_names | wc -l)
  minted=$(cat "$CLD_ROOT/minted-cl" 2>/dev/null || echo 0)
  # Signet has ports for 37 minted actors (devnet/_common.sh: cld19..cld55, 10063..10099).  Counting
  # past that named nodes no port or key exists for: every attack turn failed "no pubkey for cld56"
  # from Nov 8 on and the oracle scored nine MISSes.  At the cap, mint nothing: the caller SKIPs.
  if [ "$CLD_CHAIN" = signet ] && [ $((minted + k)) -gt 37 ]; then
    echo "== cannot mint $k more cl nodes: signet's 37 minted-actor ports are used (minted-cl $minted)" >&2; return 1
  fi
  echo $((minted + k)) >"$CLD_ROOT/minted-cl"
  source "$CLD_SRC/devnet/_common.sh" >/dev/null 2>&1
  for i in $(seq $((have + 1)) $((have + k))); do
    n=cld$i; mkdir -p "$(cld_dir "$n")"
    [ -n "${REDTEAM_MINTED_FILE:-}" ] && echo "$n" >>"$REDTEAM_MINTED_FILE"   # stopped when the scenario ends (scenarios.lisp)
    [ -f "$(cld_dir "$n")/version" ] || [ ! -f "$(cld_dir cld7)/version" ] || cp "$(cld_dir cld7)/version" "$(cld_dir "$n")/version"
    start_cld "$n" >&2   # may report "did not come up" while still loading under load
    local w; for w in $(seq 1 60); do cld_ctl "$n" '(:info)' 2>/dev/null | grep -q ":STATUS :OK" && break; sleep 5; done
    pubkey_of "$n" >/dev/null
    a=$(sx "$(cld_ctl "$n" '(:address)')" ":ADDRESS") || return 1
    for j in 1 2 3 4 5 6 7 8; do wcli sendtoaddress "$a" 0.01 >/dev/null; done
    touch "$S/.cl-collateral-funded.$n"
  done
  mine 2 >/dev/null; echo "== minted $k fresh cl nodes (cld$((have + 1))..cld$((have + k)))" >&2
}
# wake_cl K — start up to K existing, stopped, untainted pool nodes (a key and a data dir already).
# The signet soak now runs only its operators (2026-11-11); its red-team pool (cld7.., minted cld19..)
# stays stopped between attack turns, and CLEAN_CL counts only nodes that answer, so every turn
# minted afresh until the 37 minted slots were gone and turns SKIPped.  Woken nodes are listed in
# REDTEAM_MINTED_FILE like minted ones, so they are stopped again when the scenario ends.
wake_cl() {
  local k=$1 n woke=0 w
  for n in $(cld_names | sort -t d -k2 -nr); do
    [ $woke -ge "$k" ] && break
    tainted "$n" && continue
    [[ " ${REDTEAM_AVOID:-} " == *" $n "* ]] && continue
    cld_running "$n" && continue
    # A recycled slot (recycle_cl) is an empty dir with a fresh-key marker: it starts with a new key.
    [ -f "$(cld_dir "$n")/node.key" ] || [ -f "$(cld_dir "$n")/recycled" ] || continue
    [ -n "${REDTEAM_MINTED_FILE:-}" ] && echo "$n" >>"$REDTEAM_MINTED_FILE"
    # Its collateral went to earlier scenarios' pledges: fund it again (pick -> fund_cl).  A woken
    # cld251 had "0 unpledged", never armed, and rearm-restart saw one participant (2026-11-12).
    rm -f "$S/.cl-collateral-funded.$n"
    start_cld "$n" >&2
    for w in $(seq 1 60); do cld_ctl "$n" '(:info)' 2>/dev/null | grep -q ":STATUS :OK" && break; sleep 5; done
    rm -f "$(cld_dir "$n")/recycled"
    woke=$((woke+1))
  done
  [ $woke -gt 0 ] && echo "== woke $woke stopped pool node(s)" >&2
  return 0
}
# recycle_cl K — on signet at the minted-slot cap: give up to K tainted, stopped minted slots
# (cld19..) a fresh key and an empty data dir, so a slot's taint never ends the adversarial soak.
# The old dir is kept under $CLD_ROOT/recycled/ (the newest 3 only: an actor replicates ledgers).
recycle_cl() {
  local k=$1 n done_=0 d
  [ "$CLD_CHAIN" = signet ] && [ "${REDTEAM_MINT:-}" = 1 ] || return 1
  mkdir -p "$CLD_ROOT/recycled"
  for n in $(cld_names | sort -t d -k2 -n); do
    [ $done_ -ge "$k" ] && break
    [ "${n#cld}" -ge 19 ] 2>/dev/null || continue
    tainted "$n" || continue
    cld_running "$n" && continue
    d=$(cld_dir "$n"); [ -d "$d" ] || continue
    # Until 2026-11-14 the emptied slot had no node.key, so wake_cl never started it and every turn
    # that recycled still SKIPped "needs 6 clean cl nodes, have 3" (oracle: 2 MISS, now moot).
    mv "$d" "$CLD_ROOT/recycled/$n-$(date +%s)" && mkdir -p "$d" && touch "$d/recycled" || continue
    [ -f "$(cld_dir cld7)/version" ] && cp "$(cld_dir cld7)/version" "$d/version"
    # The taint stays with the old KEY: the oracle reads adversaries.tsv by key, so proofs against
    # the burned key stay PASS after the slot's name is clean again (soak-oracle.py; CHAOS.md).
    old=$(cat "$S/pubkey.$n" 2>/dev/null || awk -v n="$n" '$1==n{print $2}' "$S/names.tsv" 2>/dev/null | tail -1)
    [ -n "$old" ] && printf 'key\t%s\trecycled %s %s\n' "$old" "$n" "$(date +%FT%T)" >>"$S/adversaries.tsv"
    grep -vx "$n" "$TAINTED" >"$TAINTED.tmp" 2>/dev/null; mv "$TAINTED.tmp" "$TAINTED"
    # its cached key (pubkey_of) and its recorded ledger (own_ledger: L<i> in $S/env) were the old key's
    rm -f "$S/.cl-collateral-funded.$n" "$S/pubkey.$n"
    [ -f "$S/env" ] && { grep -v "^L${n#cld}=" "$S/env" >"$S/env.tmp"; mv "$S/env.tmp" "$S/env"; unset "L${n#cld}"; }
    echo "== recycled $n (fresh key)" >&2; done_=$((done_+1))
  done
  ls -dt "$CLD_ROOT"/recycled/* 2>/dev/null | tail -n +4 | xargs -r rm -rf
  [ $done_ -gt 0 ]
}
fund_cl() {   # fund_cl NODE — collateral coins for an actor that has none yet
  local n=$1 a j
  [ -f "$S/.cl-collateral-funded.$n" ] && return 0
  pubkey_of "$n" >/dev/null
  a=$(sx "$(cld_ctl "$n" '(:address)')" ":ADDRESS") || return 1
  for j in 1 2 3 4 5 6 7 8; do wcli sendtoaddress "$a" 0.01 >/dev/null; done
  touch "$S/.cl-collateral-funded.$n"; mine 2 >/dev/null
}
pick() {
  # PICK_<ROLE>=cldN binds ROLE to that node whatever its taint (an aged, loaded holder on
  # purpose: redteam/check-drive-load.sh); the other roles come from the clean pool as before.
  local forced=" " f v n i=0 need=0 sel=()
  for v in "$@"; do f="PICK_$v"; if [ -n "${!f:-}" ]; then forced+="${!f} "; else need=$((need+1)); fi; done
  local pool=($(clean_cl | while read -r n; do [[ "$forced" == *" $n "* ]] || echo "$n"; done))
  if [ ${#pool[@]} -lt $need ] && { [ "$CLD_CHAIN" = regtest ] || [ "${REDTEAM_MINT:-}" = 1 ]; }; then
    wake_cl $(( need - ${#pool[@]} )); pool=($(clean_cl | while read -r n; do [[ "$forced" == *" $n "* ]] || echo "$n"; done))
  fi
  if [ ${#pool[@]} -lt $need ] && { [ "$CLD_CHAIN" = regtest ] || [ "${REDTEAM_MINT:-}" = 1 ]; }; then
    if ! mint_cl $(( need - ${#pool[@]} )); then
      recycle_cl $(( need - ${#pool[@]} )) && wake_cl $(( need - ${#pool[@]} ))
    fi
    pool=($(clean_cl | while read -r n; do [[ "$forced" == *" $n "* ]] || echo "$n"; done))
  fi
  [ ${#pool[@]} -ge $need ] || { echo "SKIP: needs $need clean cl nodes ($*), have ${#pool[@]} (${pool[*]:-none}); add fresh-key nodes (devnet/_common.sh CLD_NODES)"; exit 0; }
  # i again: bash scope is dynamic, and start_cld (via wake_cl) runs its own unlocal `for i` loop.
  i=0; for v in "$@"; do f="PICK_$v"; if [ -n "${!f:-}" ]; then sel+=("${!f}"); else sel+=("${pool[$i]}"); i=$((i+1)); fi; done
  for n in "${sel[@]}"; do [ -f "$S/.cl-collateral-funded.$n" ] || fund_cl "$n"; done
  # A running actor whose loaded code is not its build's current tree restarts on it (by tree hash,
  # devnet/_common.sh cld_tree_hash; a node with no record, or down, restarts too).
  local stale=()
  for n in "${sel[@]}"; do cld_running "$n" && ! cld_stale "$n" || stale+=("$n"); done
  if [ ${#stale[@]} -gt 0 ]; then
    echo "== restarting ${stale[*]} on the current tree"
    for n in "${stale[@]}"; do ( stop_cld "$n" >/dev/null 2>&1; start_cld "$n" >/dev/null ) & done; wait
  fi
  i=0; for v in "$@"; do declare -g "$v=${sel[$i]}"; i=$((i+1)); done
  echo "== actors: $(for v in "$@"; do printf '%s=%s ' "$v" "${!v}"; done)"
}

# spender_of TXID VOUT [DEPTH]: the txid that spends TXID:VOUT, from the mempool or from the last
# DEPTH (30) blocks.  gettxspendingprevout sees only the mempool, so once the spend confirms it
# answers nothing (regtest 1119-214607: rotation-post-expiry-race read an empty spender, took the
# rotation's confirmed win for a confiscation, and failed the members who rightly yielded).
spender_of() {
  local t=$1 v=$2 depth=${3:-30} sp tip h
  sp=$(bcli gettxspendingprevout "[{\"txid\":\"$t\",\"vout\":$v}]" 2>/dev/null | python3 -c 'import json,sys; print(json.load(sys.stdin)[0].get("spendingtxid",""))' 2>/dev/null)
  [ -n "$sp" ] && { echo "$sp"; return 0; }
  tip=$(bcli getblockcount)
  for h in $(seq "$tip" -1 $((tip - depth > 0 ? tip - depth : 0))); do
    sp=$(bcli getblock "$(bcli getblockhash "$h")" 2 | python3 -c 'import json,sys
b=json.load(sys.stdin); t,v=sys.argv[1],int(sys.argv[2])
print(next((x["txid"] for x in b["tx"] for i in x["vin"] if i.get("txid")==t and i.get("vout")==v),""))' "$t" "$v")
    [ -n "$sp" ] && { echo "$sp"; return 0; }
  done
  return 1
}
