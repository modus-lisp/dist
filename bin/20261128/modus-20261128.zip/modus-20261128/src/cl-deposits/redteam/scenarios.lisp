;;;; redteam/scenarios.lisp — the red-team scenario suite against the live devnet.
;;;;   redteam/run-all.sh [--list] [--only a,b] [--skip a,b] [--tags safe,contagion] [--dry-run]
;;;;
;;;; Each scenario is one redteam/attack-*.sh run (with an arm, where it has two) on a fresh
;;;; test ledger (its REDTEAM_x variable gets a per-run name), under a hard timeout.  The
;;;; verdict comes from the script: a line starting PASS, FAIL or SKIP, else its exit status
;;;; (124 = timed out).  After every scenario, pass or fail, every adversary switch on every
;;;; cl node is turned off.  Logs: $CLD_ROOT/soak/scenarios/RUN/NAME.log; summary.tsv beside.
;;;;
;;;; Tags: safe        touches only its own test ledger, or nothing
;;;;       contagion   proofs it provokes dispute SOAK ledgers (the signers' / operator's own)
;;;;       disruptive  stops and restarts nodes
;;;;       slow        > 15 min
;;;; Default order: safe, then contagion, then disruptive.  Mind the soak: a contagion
;;;; scenario confiscates soak ledgers, which soak-rotate must then replace.
;;;;
;;;; Flakiness (the scripts are shell over the control port and log greps, not events):
;;;;  - attack1-invalid-credit / attack-forge-lock read ref2/ref3's node.log by timestamp and
;;;;    sleep fixed intervals; slow relays or a log rotation miss the line.
;;;;  - attack-vault-spend / attack-collude-q7 with reference members: add-member to a busy
;;;;    reference node times out (60 s); the suite forms cl-only quorums for vault spend (REFS="").
;;;;  - attack-dereliction needs RESP blocks with the derelict idle; the soak miner's pace sets it.
;;;;  - attack-withhold-reveal / -missed-confiscation wait for auto-arming, which waits on blocks.
;;;;  - attack-rollback-depth stops cld6 ref6 ref7; a cl restart can take minutes (big histories).
(require :sb-bsd-sockets)
(require :sb-posix)

(defparameter *src* (or (sb-posix:getenv "CLD_SRC") (namestring (merge-pathnames "../" (directory-namestring *load-truename*)))))

(defstruct sc name script (args '()) ledger-var (env '()) (timeout 900) (tags '(:safe)) note)

(defparameter *scenarios*
  (list
   (make-sc :name "invalid-credit-honest" :script "attack1-invalid-credit.sh" :args '("honest") :ledger-var "REDTEAM_IC" :timeout 600)
   (make-sc :name "forge-lock-honest" :script "attack-forge-lock.sh" :args '("honest") :ledger-var "REDTEAM_FL" :timeout 600)
   (make-sc :name "relabel" :script "attack-relabel.sh" :timeout 300)
   (make-sc :name "fuzz-proofs" :script "attack-fuzz-proofs.sh" :timeout 900)
   (make-sc :name "censor-hold-honest" :script "attack-censor-hold.sh" :args '("honest") :ledger-var "REDTEAM_CH" :timeout 600)
   (make-sc :name "censor-hold" :script "attack-censor-hold.sh" :args '("censor") :ledger-var "REDTEAM_CH" :timeout 600
            :note "finding: the escalation lands and nothing acts on it")
   (make-sc :name "vault-rotate-grace" :script "attack-vault-rotate-grace.sh" :args '("inside")
            :ledger-var "REDTEAM_RG" :timeout 900)
   (make-sc :name "rotation" :script "check-rotation.sh" :ledger-var "REDTEAM_ROT" :timeout 1200
            :note "a cl rotation spends its old vault on chain (mixed quorum); no leftovers")
   (make-sc :name "rotation-lag" :script "check-rotation-lag.sh" :ledger-var "REDTEAM_LAG" :timeout 1200
            :note "a watcher whose replica lags behind the QuorumBegin does not take the rotation for a theft")
   (make-sc :name "rotation-bump" :script "check-rotation-bump.sh" :ledger-var "REDTEAM_BUMP" :timeout 1800
            :note "DEP-03 fee ladder: a stuck rung 0 is replaced by a higher rung, and the next rotation spends it")
   (make-sc :name "confiscation-answer" :script "check-confiscation-answer.sh" :ledger-var "REDTEAM_CA"
            :env '("WAIT=1200") :timeout 3000 :tags '(:contagion)
            :note "DEP-06 spend challenge: a confiscation challenge is answered by a reference member holding the dispute")
   (make-sc :name "confiscation-vault-rung" :script "check-confiscation-vault-rung.sh" :ledger-var "REDTEAM_CVR"
            :env '("WAIT=2400") :timeout 4000 :tags '(:contagion)
            :note "DEP-03 fee ladder: a confiscation of a bumped vault is judged answered by a node that never saw the rung (soak G, Nov 8)")
   (make-sc :name "confiscation-bump" :script "check-confiscation-bump.sh" :ledger-var "REDTEAM_CB"
            :env '("REFS=" "WAIT=900") :timeout 2400 :tags '(:contagion)
            :note "DEP-03 confiscation ladder: a stuck rung 0 is replaced by a higher rung, and its lottery is claimed")
   (make-sc :name "rearm" :script "check-rearm.sh" :ledger-var "REDTEAM_RA"
            :env '("WAIT=1800") :timeout 4800 :tags '(:contagion :slow)
            :note "DEP-06 Phase 4 re-arm (strict-lottery-v8, provisional): nobody reveals, a fresh round is armed and spent into, and its lottery is claimed")
   (make-sc :name "rearm-yield" :script "check-rearm-yield.sh" :ledger-var "REDTEAM_RY"
            :env '("WAIT=1800") :timeout 4800 :tags '(:contagion :slow)
            :note "DEP-06 Phase 4 re-arm with revealers (provisional): every fork yields, the winner included; a fresh round recovers the output and is claimed")
   (make-sc :name "rearm-restart" :script "check-rearm-restart.sh" :ledger-var "REDTEAM_RR"
            :env '("WAIT=1800" "CHECK_TIMEOUT=5000") :timeout 5400 :tags '(:contagion :slow)
            :note "the all-yield re-arm with a participant restarted after its yield, its quorum expired: no second dispute, no phantom win, the output still re-arms (751e6951)")
   (make-sc :name "rearm-late" :script "check-rearm-late.sh" :ledger-var "REDTEAM_RL"
            :env '("WAIT=1800") :timeout 6000 :tags '(:contagion :slow)
            :note "DEP-06 Phase 4 recurring windows (strict-lottery-v8, ruled 2026-11-07): a lottery stranded past both scheduled windows re-arms at the first recurring one and is claimed")
   (make-sc :name "rearm-slow" :script "check-rearm-slow.sh" :ledger-var "REDTEAM_RS"
            :env '("WAIT=1800") :timeout 4800 :tags '(:contagion :slow)
            :note "DEP-06 Phase 4 re-arm with both recovery voters answering lottery_rearm_sign after the proposer's wait: their late signatures are kept and the spend still goes out (d5880288, a2d44d7a)")
   (make-sc :name "rearm-invert" :script "check-rearm-invert.sh" :ledger-var "REDTEAM_RI"
            :env '("WAIT=3600" "CHECK_TIMEOUT=7000") :timeout 7200 :tags '(:contagion :slow)
            :note "two rule inverters in a re-arm round: a late same-round arm after the close stays in the cut (DEP-06 step 2), and a voter that inverts the arm selection is refused while the honest spend lands")
   (make-sc :name "backdated-arm" :script "check-backdated-arm.sh" :ledger-var "REDTEAM_BA"
            :env '("WAIT=1500") :timeout 3600 :tags '(:contagion :slow)
            :note "reproduction (unruled finding): a counted armer's round-1 re-arm signed at the confiscation block after it confirmed, pledging a later coin; a judge judging afresh must still find the confiscation authorised")
   (make-sc :name "rearm-mixed" :script "check-rearm-mixed.sh" :ledger-var "REDTEAM_RM"
            :env '("WAIT=1800" "CHECK_TIMEOUT=5000") :timeout 5400 :tags '(:contagion :slow)
            :note "DEP-06 Phase 4 re-arm whose tier-0 recovery spend needs a reference voter's signature: deposits-rust answers lottery_rearm_sign (cl proposes, Rust signs)")
   (make-sc :name "rearm-rust" :script "check-rearm-rust.sh" :ledger-var "REDTEAM_RR2"
            :env '("WAIT=1800" "CHECK_TIMEOUT=5000") :timeout 5400 :tags '(:contagion :slow)
            :note "DEP-06 Phase 4 re-arm driven end to end by deposits-rust: R arms round 2, proposes and assembles the tier-0 recovery spend (cl H only signs), and reveals and claims round 2")
   (make-sc :name "proof-lag" :script "check-proof-lag.sh" :ledger-var "REDTEAM_PL" :timeout 1500
            :tags '(:contagion)
            :note "DEP-06 §Verification: a member whose replica lags when the fraud proof arrives (paused across the updates it builds on) parks the proof, catches up, re-judges, and still enters the dispute (regtest 1120-075609)")
   (make-sc :name "rotation-drop" :script "check-rotation-drop.sh" :ledger-var "REDTEAM_RD" :timeout 1500
            :note "DEP-11 rotating without a silent member (ruled 2026-11-10): a silent member is dropped and the consenting ones seated")
   (make-sc :name "rotation-post-expiry" :script "check-rotation-post-expiry.sh" :args '("rescue") :ledger-var "REDTEAM_PX" :timeout 1800
            :tags '(:disruptive) :note "DEP-05/06 a rotation past expiry is allowed, never owed (ruled 2026-11-14): the rotation wins (ticker paused, cl members hold their arms); disputes stand until its spend confirms, then yield")
   (make-sc :name "drive-load" :script "check-drive-load.sh" :ledger-var "REDTEAM_PX" :timeout 2400
            :tags '(:disruptive :slow) :note "an aged holder (cld364, ~60 dispute forks) still yields within 900 s of a confirmed re-establishment and leaves no dispute undriven (regtest 1119-111730)")
   (make-sc :name "rotation-recorded-threshold" :script "check-rotation-recorded-threshold.sh" :ledger-var "REDTEAM_RT" :timeout 2400
            :tags '(:disruptive) :note "DEP-06 strict-lottery-v8 (ruled 2026-11-19): a rotation recorded at the ledger's own threshold, below its rungs' tier floor, answers the spend of its rung; signet C's shape on regtest, judged by cl and deposits-rust")
   (make-sc :name "rotation-post-expiry-race" :script "check-rotation-post-expiry.sh" :args '("race") :ledger-var "REDTEAM_PX" :timeout 2400
            :tags '(:disruptive) :note "DEP-05 v8 amendment (2026-11-15): the rotation races the confiscation at the default arm window; the confiscation wins and no member yields its stake on the recorded QuorumBegin")
   (make-sc :name "rotation-post-expiry-confiscated" :script "check-rotation-post-expiry.sh" :args '("confiscated") :ledger-var "REDTEAM_PX" :timeout 2400
            :tags '(:disruptive) :note "DEP-06 Race: a confiscation that confirmed first; no rotation of the confiscated vault is recorded")
   (make-sc :name "fraud-rotation" :script "check-fraud-rotation.sh" :ledger-var "REDTEAM_FR" :timeout 1500
            :note "DEP-05 deposed operator (strict-lottery-v8, ruled 2026-11-10): a fraud dispute outlives a rotation")
   (make-sc :name "acquire-unconfirmed" :script "check-acquire-unconfirmed.sh" :ledger-var "REDTEAM_AU" :timeout 1200
            :note "DEP-06 Phase 4 (strict-lottery-v8, ruled 2026-11-10): an acquire whose claim never confirms deposes no one")
   (make-sc :name "grounded-arms" :script "check-grounded-arms.sh" :ledger-var "REDTEAM_GA"
            :env '("WAIT=1500") :timeout 2400 :tags '(:contagion)
            :note "DEP-18 grounded-arms-v7: an arm whose DisputeEnter has no grounds is disregarded")
   (make-sc :name "exit" :script "check-exit.sh" :ledger-var "REDTEAM_EXIT" :timeout 1200
            :note "DEP-20 exits settle at the rotation (mixed quorum); dust carried; cancel releases")
   (make-sc :name "splice" :script "check-splice.sh" :ledger-var "REDTEAM_SPLICE" :timeout 2400
            :note "DEP-20 splice-in at rotation, cl and reference operators, signed across implementations")
   (make-sc :name "migrate" :script "check-migrate.sh" :ledger-var "REDTEAM_MIGRATE" :timeout 3000
            :note "DEP-20 §10 migration: exits pay a cl and a reference destination's offers, each credited")
   (make-sc :name "dormancy" :script "check-dormancy.sh" :ledger-var "REDTEAM_DORMANCY" :timeout 3000
            :note "DEP-20 §8 dormancy: a large dormant pk() deposit is spun out at the notice's rotation")
   (make-sc :name "obligations" :script "check-obligations.sh" :ledger-var "REDTEAM_OBL" :timeout 3600
            :note "DEP-06 confiscation obligations: an uncredited migration and payment are paid out at confiscation")
   (make-sc :name "invalid-credit-collude" :script "attack1-invalid-credit.sh" :args '("collude")
            :ledger-var "REDTEAM_IC"
            :timeout 600 :tags '(:contagion))
   (make-sc :name "forge-lock-collude" :script "attack-forge-lock.sh" :args '("collude")
            :ledger-var "REDTEAM_FL"
            :timeout 600 :tags '(:contagion))
   (make-sc :name "collude-q7" :script "attack-collude-q7.sh" :ledger-var "REDTEAM_M"
            :env '("WAIT=300") :timeout 1800 :tags '(:contagion))
   (make-sc :name "vault-spend" :script "attack-vault-spend.sh" :ledger-var "REDTEAM_V"
            :env '("REFS=" "WAIT=300") :timeout 1200 :tags '(:contagion))
   (make-sc :name "vault-anchored" :script "attack-vault-anchored.sh" :ledger-var "REDTEAM_VA"
            :env '("REFS=") :timeout 1800 :tags '(:contagion)
            :note "DEP-06 §Spend challenge: a theft with a forged anchor is challenged, then proven once the challenge lapses")
   (make-sc :name "ruleset-prior" :script "check-ruleset-prior.sh"
            :timeout 1800 :tags '(:contagion)
            :note "DEP-18: a cltv-offset-v2 vault's unanchored spend is never proven; a rotation moves the ledger to balance-anchor-v6")
   (make-sc :name "ruleset-v6" :script "check-ruleset-v6.sh"
            :timeout 2400 :tags '(:safe)
            :note "DEP-18 balance-anchor-v6: a mixed v5 quorum rotates to v6 and refuses a missing commitment; a reference-only v4 ledger upgrades to v6")
   (make-sc :name "ruleset-undeclared" :script "check-ruleset-undeclared.sh"
            :timeout 1800 :tags '(:safe)
            :note "DEP-18: a QuorumBegin naming a ruleset a seated member did not declare is refused by cl and reference operators")
   (make-sc :name "descriptor-validity-honest" :script "check-descriptor-validity.sh" :args '("honest")
            :ledger-var "REDTEAM_DV" :timeout 900
            :note "DEP-16 §descriptor validity: cl and reference cosigners refuse an invalid descriptor")
   (make-sc :name "descriptor-validity-collude" :script "check-descriptor-validity.sh" :args '("collude")
            :ledger-var "REDTEAM_DV" :timeout 900 :tags '(:contagion)
            :note "DEP-16 §descriptor validity: a committed invalid descriptor is fraud on neither side")
   (make-sc :name "vault-recovery-tier" :script "attack-vault-recovery-tier.sh" :ledger-var "REDTEAM_RT"
            :timeout 1800 :tags '(:contagion :disruptive :slow) :note "mines past expiry + 720")
   (make-sc :name "vault-rotate-late" :script "attack-vault-rotate-grace.sh" :args '("late")
            :ledger-var "REDTEAM_RG" :timeout 900 :tags '(:contagion) :note "signers remember the rotation; a non-signer reports a late one")
   (make-sc :name "vault-missed-confiscation" :script "attack-vault-missed-confiscation.sh"
            :ledger-var "REDTEAM_MC" :env '("WAIT=1500") :timeout 2400 :tags '(:contagion :slow))
   (make-sc :name "withhold-reveal" :script "attack-withhold-reveal.sh" :ledger-var "REDTEAM_W"
            :env '("REFS=" "WAIT=1200") :timeout 5400 :tags '(:contagion :slow))
   (make-sc :name "veto-pledge" :script "attack-veto-pledge.sh" :ledger-var "REDTEAM_VP"
            :timeout 2400 :tags '(:contagion) :note "one armer spends its pledge; the confiscation must still land")
   (make-sc :name "veto-pledge-sole" :script "attack-veto-pledge.sh" :args '("sole") :ledger-var "REDTEAM_VPS"
            :timeout 2400 :tags '(:contagion) :note "one eligible armer takes custody without a draw")
   (make-sc :name "veto-pledge-reopen" :script "attack-veto-pledge.sh" :args '("reopen") :ledger-var "REDTEAM_VPR"
            :timeout 3000 :tags '(:contagion) :note "nobody eligible: the honest armer re-arms")
   (make-sc :name "dereliction" :script "attack-dereliction.sh" :ledger-var "REDTEAM_D"
            :timeout 3600 :tags '(:contagion :slow))
   (make-sc :name "rollback-depth" :script "attack-rollback-depth.sh" :ledger-var "REDTEAM_R"
            :timeout 2400 :tags '(:contagion :disruptive :slow))))

(defparameter *switches* '(:blind-relay :cosign-blind :ignore-fraud :ignore-requests :lag-replica :mute :sign-invalid :spend-pledge :theft-sign :withhold-reveal))

;;; --- the devnet, as devnet/_common.sh describes it -------------------------------------

(defun sh (cmd)
  (string-right-trim '(#\Newline)
   (with-output-to-string (s)
     (sb-ext:run-program "/bin/bash" (list "-c" cmd) :output s :error nil :directory *src*))))

(defun split-lines (s)
  (loop for start = 0 then (1+ end) for end = (position #\Newline s :start start)
        collect (subseq s start end) while end))

(defun devnet ()
  "(values cld-root ((name . port) ...))"
  (let ((lines (split-lines (sh "source devnet/_common.sh >/dev/null 2>&1; echo \"$CLD_ROOT\"; printf '%s\\n' \"${CLD_NODES[@]}\""))))
    (values (first lines)
            (loop for e in (rest lines)
                  for c = (position #\: e :from-end t)
                  when c collect (cons (subseq e 0 (position #\: e)) (parse-integer e :start (1+ c) :junk-allowed t))))))

(defun control (port form &key (timeout 30))
  "One request/response on a cl node's control port; NIL if it does not answer."
  (handler-case
      (let ((s (make-instance 'sb-bsd-sockets:inet-socket :type :stream :protocol :tcp)))
        (unwind-protect
             (progn
               (sb-bsd-sockets:socket-connect s #(127 0 0 1) port)
               (let ((io (sb-bsd-sockets:socket-make-stream s :input t :output t :external-format :utf-8 :timeout timeout)))
                 (write-line form io) (finish-output io)
                 (read-line io nil nil)))
          (sb-bsd-sockets:socket-close s)))
    (error () nil)))

(defun disarm-all (nodes)
  "Every adversary switch off (a scenario killed by its timeout never runs its own restore)."
  (let ((form (format nil "(:adversary :set~{ ~s nil~})" *switches*)))
    (loop for (name . port) in nodes
          unless (search ":STATUS :OK" (or (control port form) ""))
            collect name)))

;;; --- running ------------------------------------------------------------------------------

(defun now () (get-universal-time))

(defun excerpt (file &optional (n 4))
  (let ((lines (with-open-file (in file :if-does-not-exist nil :external-format :utf-8)
                 (and in (loop for l = (read-line in nil) while l collect l)))))
    (last (remove-if (lambda (l) (zerop (length (string-trim " " l)))) lines) n)))

(defun verdict (file exit)
  (let ((lines (with-open-file (in file :if-does-not-exist nil :external-format :utf-8)
                 (and in (loop for l = (read-line in nil) while l collect l)))))
    (flet ((starts (p) (find-if (lambda (l) (and (>= (length l) (length p)) (string= p l :end2 (length p)))) lines :from-end t)))
      (cond ((eql exit 124) :timeout)
            ((starts "INVALID") :invalid)
            ((starts "FAIL") :fail)
            ((starts "SKIP") :skip)
            ((and (starts "PASS") (eql exit 0)) :pass)
            ((starts "NOTE") :note)
            (t :fail)))))

(defun run-one (sc run-id dir nodes)
  (let* ((log (format nil "~a/~a.log" dir (sc-name sc)))
         (env (append (sc-env sc)
                      (and (sc-ledger-var sc) (list (format nil "~a=~a-~a" (sc-ledger-var sc) (sc-name sc) run-id)))))
         ;; Its own process group, killed whole when it ends: `timeout` alone kills only the
         ;; script's bash, and its subshells (control calls, mining, waits) lived on for hours.
         (pgfile (format nil "~a/~a.pgid" dir (sc-name sc)))
         ;; Every cl node the scenario mints (redteam/_lib.sh mint_cl) is listed here and stopped
         ;; when it ends, pass or fail: actors were never stopped, and a day of scenarios left 229
         ;; regtest nodes holding 406 GB (2026-11-10).  Their data dirs stay, for the evidence.
         (minted (format nil "~a/~a.minted" dir (sc-name sc)))
         (cmd (format nil "setsid bash -c 'echo $$ >~a; exec env REDTEAM_MINTED_FILE=~a ~{~a ~}timeout --kill-after=15 ~a bash redteam/~a~{ ~a~}' >~a 2>&1; rc=$?; pg=$(cat ~a 2>/dev/null); [ -n \"$pg\" ] && kill -KILL -- -$pg 2>/dev/null; rm -f ~a; exit $rc"
                      pgfile minted env (sc-timeout sc) (sc-script sc) (sc-args sc) log pgfile pgfile))
         (t0 (now)) exit)
    (format t "~&-- ~a (~{~(~a~)~^,~}) ... " (sc-name sc) (sc-tags sc)) (finish-output)
    (unwind-protect
         (setf exit (sb-ext:process-exit-code (sb-ext:run-program "/bin/bash" (list "-c" cmd) :directory *src* :output nil :error nil)))
      (let ((stuck (disarm-all nodes)))
        (when stuck (format t "~&   (could not disarm: ~{~a~^ ~})~%" stuck)))
      (when (probe-file minted)
        (sb-ext:run-program "/bin/bash"
                            (list "-c" (format nil "source devnet/_common.sh >/dev/null 2>&1; for n in $(sort -u ~a); do stop_cld \"$n\" >/dev/null 2>&1 & done; wait" minted))
                            :directory *src* :output nil :error nil)))
    (let ((v (verdict log exit)) (dt (- (now) t0)))
      (format t "~a  ~ds~%" v dt)
      (unless (eq v :pass) (dolist (l (excerpt log)) (format t "     | ~a~%" (subseq l 0 (min 160 (length l))))))
      (list (sc-name sc) v dt exit log))))

(defun split (s)
  (and s (loop for start = 0 then (1+ end)
               for end = (position #\, s :start start)
               for part = (string-trim " " (subseq s start end))
               unless (string= part "") collect part
               while end)))

(defun option (args name) (let ((m (member name args :test #'string=))) (and m (second m))))

(defun select (args)
  (let ((only (split (option args "--only"))) (skip (split (option args "--skip")))
        (tags (mapcar (lambda (x) (intern (string-upcase x) :keyword)) (split (option args "--tags")))))
    (remove-if-not (lambda (sc)
                     (and (or (null only) (member (sc-name sc) only :test #'string=))
                          (not (member (sc-name sc) skip :test #'string=))
                          (or (null tags) (intersection tags (sc-tags sc)))))
                   *scenarios*)))

(defun main (args)
  (let ((chosen (select args)))
    (when (member "--list" args :test #'string=)
      (dolist (sc *scenarios*)
        (format t "~28a ~22a ~{~(~a~)~^,~}~@[  — ~a~]~%" (sc-name sc)
                (format nil "~a~{ ~a~}" (sc-script sc) (sc-args sc)) (sc-tags sc) (sc-note sc)))
      (return-from main 0))
    (multiple-value-bind (root nodes) (devnet)
      (let* ((run-id (multiple-value-bind (s m h d mo) (decode-universal-time (now) 0)
                       (format nil "~2,'0d~2,'0d-~2,'0d~2,'0d~2,'0d" mo d h m s)))
             (dir (format nil "~a/soak/scenarios/~a" root run-id))
             (down (loop for (name . port) in nodes unless (control port "(:info)" :timeout 10) collect name)))
        (format t "scenario run ~a: ~d scenario~:p~@[; cl nodes not answering: ~{~a~^ ~}~]~%" run-id (length chosen) down)
        (when (member "--dry-run" args :test #'string=)
          (dolist (sc chosen) (format t "  would run ~a~%" (sc-name sc)))
          (return-from main 0))
        (ensure-directories-exist (format nil "~a/" dir))
        (let ((results (mapcar (lambda (sc)
                                 ;; INVALID: the run could not test what it tests (e.g. a race went the
                                 ;; other way); retry on a fresh ledger, up to twice.
                                 (loop for try from 0 to 2
                                       for r = (run-one sc (if (zerop try) run-id (format nil "~a-r~d" run-id try)) dir nodes)
                                       unless (eq (second r) :invalid) return r
                                       finally (return r)))
                               chosen)))
          (with-open-file (o (format nil "~a/summary.tsv" dir) :direction :output :if-exists :supersede)
            (dolist (r results) (format o "~{~a~^	~}~%" r)))
          (format t "~%~28a ~8a ~6a~%" "scenario" "verdict" "secs")
          (dolist (r results) (format t "~28a ~8a ~6d~%" (first r) (second r) (third r)))
          (let ((bad (count-if-not (lambda (r) (member (second r) '(:pass :skip))) results)))
            (format t "~%~d passed, ~d not; logs in ~a~%" (count :pass results :key #'second) bad dir)
            (if (zerop bad) 0 1)))))))

(sb-ext:exit :code (main (rest (member "--" sb-ext:*posix-argv* :test #'string=))))
