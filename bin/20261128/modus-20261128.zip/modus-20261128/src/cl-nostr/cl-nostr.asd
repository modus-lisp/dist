;;;; cl-nostr.asd

(defsystem "cl-nostr"
  :description "A from-scratch Nostr client in Common Lisp — NIP-01 events
                (BIP340-signed), NIP-19 bech32 entities, and a WebSocket relay
                pool for publishing and subscribing."
  :version "0.1.0"
  :author "ynniv"
  :license "MIT"
  :depends-on ("secp256k1-fast"      ; BIP340 Schnorr + secp256k1 (event sigs + NIP-44 ECDH)
               "seal/http"           ; HTTP over seal's TLS  (was: dexador -> cl+ssl)
               "natrium"             ; SHA-256 (event ids), HMAC/ChaCha20 (NIP-44), secure random
               "cl-base64"           ; NIP-44 payload base64
               "json-simple"      ; JSON: relay messages + events
               "seal/websocket"      ; WebSocket client (wss:// relays), on seal's TLS
               "bordeaux-threads"    ; locks
               "bobbin"              ; copying channels: a relay's I/O thread <-> its owner
               "cl-transport/sockets") ; UDP datagrams (publish-datagram); SBCL and modus
  :serial t
  :components
  ((:module "src"
    :serial t
    :components
    ((:file "packages")   ; package + nickname layout
     (:file "util")       ; hex, utf-8, json helpers
     (:file "keys")       ; secret/public keys, Schnorr sign/verify (over secp256k1-fast)
     (:file "bech32")     ; NIP-19 bech32 entities (npub/nsec/note + TLV nprofile/nevent/naddr)
     (:file "event")      ; NIP-01 event: canonical serialization, id, sign, verify, JSON
     (:file "filter")     ; NIP-01 subscription filters
     (:file "relay")      ; one relay: its I/O thread, REQ/EVENT/CLOSE, message dispatch
     (:file "udp")        ; one event as one UDP datagram, sent and not answered
     (:file "pool")     ; high-level multi-relay client: publish + subscribe across relays
     (:file "nip44")      ; NIP-44 v2 payload encryption (ECDH -> HKDF -> ChaCha20 + HMAC)
     (:file "nip59")      ; NIP-59 gift wrap / NIP-17 private DMs (rumor -> seal -> wrap)
     (:file "double-ratchet") ; Nostr Double Ratchet (yakihonne "Secure DMs", kind-1060)
     (:file "blossom")    ; Blossom blob upload/download (BUD-01/02, kind-24242 auth)
     (:file "nsite")      ; nsite: publish AND resolve a static site on Nostr (NIP-5A, kind-15128)
     (:file "nip05"))))   ; NIP-05: resolve name@domain -> pubkey (DNS-based identifiers)
  :in-order-to ((test-op (test-op "cl-nostr/test"))))

(defsystem "cl-nostr/test"
  :depends-on ("cl-nostr")
  :components ((:module "inspect"
               :serial t
               :components ((:file "offline-test")
                            (:file "fake-relay")    ; a NIP-01 relay on 127.0.0.1, for tests
                            (:file "pool-test"))))  ; the pool against it
  :perform (test-op (o c) (uiop:symbol-call :cl-nostr.test :run)
                          (uiop:symbol-call :cl-nostr.pool-test :run)))
