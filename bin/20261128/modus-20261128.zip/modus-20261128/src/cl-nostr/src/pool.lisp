;;;; src/pool.lisp — a pool of relays: the high-level client surface.
;;;;
;;;; Nostr's redundancy model is "publish to many relays, read from many relays."
;;;; A pool fans publish/subscribe out to all its relays and (for fetch-events)
;;;; deduplicates the merged stream by event id, so the same note arriving from
;;;; three relays is delivered once.
;;;;
;;;; Each relay of a pool is a reconnecting relay (src/relay.lisp): its I/O thread pings it
;;;; every *POOL-WATCH-INTERVAL* seconds (relays drop idle sockets), reopens it when it is lost
;;;; and sends every live subscription again, and keeps trying a relay that never answered, on
;;;; a doubling schedule.  So there is no watcher thread and nothing for the caller to pump:
;;;; the pool's own state is the relay objects, on the thread that made the pool.

(in-package #:cl-nostr.pool)

(defstruct (pool (:constructor %make-pool))
  (members '() :type list)       ; every relay asked for, connected or not, in order
  (subs '() :type list)          ; live pool subscriptions, sent to a relay added later
  (verify t)                     ; TLS verification, for relays added later
  (lock (bt:make-lock "pool")))

(defparameter *pool-watch-interval* 20
  "Seconds between keepalive pings of a pool's relays, and the first wait before trying again
a relay that never connected.")

(defparameter *unreachable-retry-max* 600
  "Longest wait, in seconds, between tries at a relay that has never connected.  The wait starts
at *POOL-WATCH-INTERVAL* and doubles per failure up to this.  A relay that was connected and was
lost is tried again after R:*RECONNECT-DELAY* seconds, doubling up to *POOL-WATCH-INTERVAL*.")

(defun %members (pool)
  (bt:with-lock-held ((pool-lock pool)) (copy-list (pool-members pool))))

(defun pool-relays (pool)
  "The relays of POOL that have connected (they may be down now and reconnecting)."
  (remove-if-not #'r::relay-ever-connected-p (%members pool)))

(defun %relays (pool) (pool-relays pool))

(defun pool-unreachable (pool)
  "URLs of the relays POOL was asked for that have never connected (they are still tried)."
  (mapcar #'r:relay-url (remove-if #'r::relay-ever-connected-p (%members pool))))

(defun pool-relay-urls (pool)
  "The URLs of the relays of POOL that have connected."
  (mapcar #'r:relay-url (pool-relays pool)))

(defun %start-member (pool url on-notice timeout &optional (verify (pool-verify pool)))
  (let ((relay (r::%start-link url :verify verify :timeout timeout
                                   :on-notice on-notice :reconnect t
                                   :ping-every *pool-watch-interval*
                                   :retry-first *pool-watch-interval*
                                   :retry-max *unreachable-retry-max*
                                   :lost-first r:*reconnect-delay*
                                   :lost-max *pool-watch-interval*)))
    (bt:with-lock-held ((pool-lock pool))
      (setf (pool-members pool) (append (pool-members pool) (list relay))))
    (dolist (spec (bt:with-lock-held ((pool-lock pool)) (copy-list (pool-subs pool))))
      (%subscribe-member relay spec))
    relay))

(defun %await-members (relays timeout)
  "Wait (pumping) until every one of RELAYS has finished its first connection attempt, or
   TIMEOUT seconds."
  (let ((end (+ (get-internal-real-time) (round (* timeout internal-time-units-per-second)))))
    (loop until (or (notany (lambda (r) (eq (r::relay-status r) :connecting)) relays)
                    (>= (get-internal-real-time) end))
          do (r::wait-for-relays relays 0.01))))

(defun make-pool (&optional urls &key (verify t) (timeout 10))
  "Make a pool, connecting (in parallel) to a list of relay URLS up front.  Returns once each
has connected or failed, or after TIMEOUT seconds.  A relay that did not connect is REMEMBERED
(POOL-UNREACHABLE) and tried again, not dropped: \"I published to three relays\" and \"three
relays were in my config\" are different claims."
  (let* ((pool (%make-pool :verify verify))
         (urls (remove nil (if (listp urls) urls (list urls))))
         (relays (loop for url in urls collect (%start-member pool url nil timeout))))
    (%await-members relays timeout)
    pool))

(defun add-relay (pool url &key (verify t) on-notice (timeout 10))
  "Connect to URL and add it to the pool (with every live pool subscription).  Returns the
relay, or NIL if it did not connect within TIMEOUT seconds -- it stays in the pool and is
tried again, like any relay that has not answered yet."
  (let ((relay (%start-member pool url on-notice timeout verify)))
    (%await-members (list relay) timeout)
    (and (r:relay-connected-p relay) relay)))

(defun remove-relay (pool relay-or-url)
  "Close and drop a relay (by object or url)."
  (let ((relay (bt:with-lock-held ((pool-lock pool))
                 (let ((relay (if (stringp relay-or-url)
                                  (find relay-or-url (pool-members pool)
                                        :key #'r:relay-url :test #'string=)
                                  relay-or-url)))
                   (when relay
                     (setf (pool-members pool) (remove relay (pool-members pool))))
                   relay))))
    (when relay (r:close-relay relay))
    relay))

(defun close-pool (pool)
  "Close every relay in the pool (ending their I/O threads) and the delivery threads of its
subscriptions."
  (let (relays specs)
    (bt:with-lock-held ((pool-lock pool))
      (setf relays (pool-members pool) specs (pool-subs pool)
            (pool-members pool) '() (pool-subs pool) '()))
    (mapc #'r:close-relay relays)
    (%stop-deliveries specs))
  pool)

(defun %stop-deliveries (specs)
  "Stop the delivery thread of each :THREAD subscription in SPECS that no relay still feeds
   (one made while the pool had no relay never had a feed to lose)."
  (dolist (spec specs)
    (when (getf spec :slot)
      (r::%delivery-ref (getf spec :slot) 0 (getf spec :subid)))))

(defun pool-pump (pool &optional (timeout 0))
  "Run the callbacks for what POOL's relays have delivered (OKs, NOTICEs, :PUMP subscriptions),
for up to TIMEOUT seconds, on THIS thread -- which need not be the one that made the pool, where
the Lisp allows that (SBCL).  PUMP serves only the calling thread's own relays."
  (r:pump-relays (%members pool) timeout))

(defun pool-publish (pool event &key on-ok)
  "Publish EVENT to every connected relay and return its id immediately.  ON-OK, if
given, is called as (relay accepted-p message) once per relay reply, on the thread that
pumps (every cl-nostr wait pumps; or call CL-NOSTR.RELAY:PUMP).

FIRE AND FORGET.  This tells you nothing about whether the event landed: a websocket
whose socket has gone away swallows the frame without signalling, and a process that
exits here exits before any relay has answered.  Use POOL-PUBLISH-SYNC whenever the
answer matters."
  (dolist (relay (pool-relays pool) (cl-nostr.event:event-id event))
    ;; REBOUND for the closure.  Whether DOLIST makes a fresh binding per iteration is the
    ;; implementation's choice (CLHS DOLIST); modus assigns one binding, and binds it to NIL for
    ;; the result form -- so every ON-OK was told the relay was NIL.
    (let ((relay relay))
      (ignore-errors
       (r:publish relay event
                  :on-ok (when on-ok
                           (lambda (accepted msg) (funcall on-ok relay accepted msg))))))))

;;; ---- publishing you can believe --------------------------------------------
;;; The relay's OK reply is the ONLY evidence that an event was published.  A send
;;; can vanish without a trace: a socket that has gone away takes the frame and says
;;; nothing.  A publisher that does not wait for OK is guessing -- and a script that guesses
;;; and then exits has lost the event.  (That is not hypothetical; it is what silently
;;; dropped two site deployments before this function existed.)

(defclass relay-ack ()
  ((url      :initarg :url      :reader ack-url)
   (event-id :initarg :event-id :reader ack-event-id)
   (status   :initarg :status   :initform :no-reply :reader ack-status
             :documentation
             "One of :ACCEPTED (relay said OK true), :REJECTED (OK false — policy,
paid relay, bad signature), :NO-REPLY (sent, never answered in time), :SEND-FAILED
(the socket would not take it), :UNREACHABLE (never connected at all).")
   (message  :initarg :message  :initform nil :reader ack-message
             :documentation "The relay's own words, when it had any."))
  (:documentation "What one relay did with one event.  A partial result is normal:
relays refuse events for their own reasons and that is not the publisher's failure."))

(defun ack-accepted-p (ack) (eq (ack-status ack) :accepted))
(defun ack-replied-p (ack) (member (ack-status ack) '(:accepted :rejected)))

(defmethod print-object ((a relay-ack) stream)
  (print-unreadable-object (a stream :type t)
    (format stream "~a ~a~@[ ~a~]" (ack-url a) (ack-status a) (ack-message a))))

(defun pool-publish-sync (pool event &key (timeout 8) (retry-after 3) (retries 1))
  "Publish EVENT to every relay and WAIT, up to TIMEOUT seconds, for each one's OK.
Returns a list of RELAY-ACK — one per relay in the pool, plus one :UNREACHABLE ack per
url the pool could not connect to — so the caller can see exactly what happened rather
than a boolean.  Any relay that has not answered after RETRY-AFTER seconds is sent the
event again (RETRIES times) once it is connected -- its I/O thread reopens a lost socket by
itself; re-sending is harmless because relays deduplicate by event id.

Returns as soon as every relay has answered, so the common case costs one round trip."
  (let* ((relays (pool-relays pool))
         (unreachable (pool-unreachable pool))
         (id (cl-nostr.event:event-id event))
         (lock (bt:make-lock "publish-sync"))
         (acks (make-hash-table :test 'equal)))
    (dolist (relay relays)
      (let ((url (r:relay-url relay)))
        (setf (gethash url acks)
              (make-instance 'relay-ack :url url :event-id id :status :no-reply))))
    (labels ((note (url status &optional message)
               (bt:with-lock-held (lock)
                 (let ((ack (gethash url acks)))
                   (when (and ack (not (ack-replied-p ack)))
                     (setf (slot-value ack 'status) status
                           (slot-value ack 'message) message)))))
             (send (relay)
               (let ((url (r:relay-url relay)))
                 (handler-case
                     (progn (r:publish relay event
                                       :on-ok (lambda (accepted msg)
                                                (note url (if accepted :accepted :rejected) msg)))
                            ;; a retry that gets out clears an earlier send failure
                            (bt:with-lock-held (lock)
                              (let ((ack (gethash url acks)))
                                (when (eq (ack-status ack) :send-failed)
                                  (setf (slot-value ack 'status) :no-reply
                                        (slot-value ack 'message) nil)))))
                   (serious-condition (c) (note url :send-failed (princ-to-string c))))))
             (outstanding ()
               (remove-if (lambda (relay) (ack-replied-p (gethash (r:relay-url relay) acks)))
                          relays)))
      (dolist (relay relays) (send relay))
      (loop with start = (get-internal-real-time) with attempts = 0
            for waited = (/ (- (get-internal-real-time) start) internal-time-units-per-second)
            until (null (outstanding))
            while (< waited timeout)
            do (r::wait-for-relays relays 0.02)
               (when (and retry-after (< attempts retries)
                          (>= waited (* (1+ attempts) retry-after)))
                 (incf attempts)
                 (dolist (relay (outstanding)) (send relay))))
      (append (loop for relay in relays collect (gethash (r:relay-url relay) acks))
              (loop for url in unreachable
                    collect (make-instance 'relay-ack :url url :event-id id
                                                      :status :unreachable
                                                      :message "never connected"))))))

(defun acks-accepted (acks)
  "The subset of ACKS whose relay accepted the event."
  (remove-if-not #'ack-accepted-p acks))

;;; ---- subscriptions ---------------------------------------------------------

(defun %subscribe-member (relay spec)
  (destructuring-bind (&key subid filters on-event on-eose slot) spec
    (ignore-errors (r::%subscribe relay filters subid on-event on-eose slot))))

(defun pool-subscribe (pool filters &key on-event on-eose (deliver :thread))
  "Subscribe across every relay, de-duplicating events by id.  ON-EVENT is called
(event relay) once per distinct event; ON-EOSE (relay) as each relay finishes its
stored set.  The subscription is sent again to a relay after it reconnects, and to a
relay that connects later.  Returns the list of per-relay subscriptions.

WHERE THE CALLBACKS RUN.  DELIVER :THREAD (the default) runs them on a thread of the
subscription's own, started with them as its arguments -- nobody needs to pump, but they
must not change state that belongs to another thread (on modus that is refused; hand
the event on, as cl-deposits does with its OWNER-POST, or use :PUMP), and on modus the
subscribing thread must be the main thread.  The RELAY they are given there carries the
relay's URL only.  DELIVER :PUMP runs them on the thread that pumps
(CL-NOSTR.RELAY:PUMP; every cl-nostr wait pumps) with the pool's own relay objects."
  (let* ((filters (if (listp filters) filters (list filters)))
         (subid (r::%random-id))
         (spec (ecase deliver
                 (:thread
                  (list :subid subid :filters filters :on-event on-event :on-eose on-eose
                        :slot (r::%delivery-start subid on-event on-eose)))
                 (:pump
                  (let* ((seen (make-hash-table :test 'equal))
                         (seen-lock (bt:make-lock "seen"))
                         (dedup (lambda (event relay)
                                  (when on-event
                                    (let ((id (cl-nostr.event:event-id event)))
                                      (when (bt:with-lock-held (seen-lock)
                                              (unless (gethash id seen)
                                                (setf (gethash id seen) t)))
                                        (funcall on-event event relay)))))))
                    (list :subid subid :filters filters :on-event dedup :on-eose on-eose))))))
    (bt:with-lock-held ((pool-lock pool)) (push spec (pool-subs pool)))
    (remove nil (mapcar (lambda (relay) (%subscribe-member relay spec)) (%members pool)))))

(defun pool-unsubscribe (pool subscriptions)
  "Close a subscription POOL-SUBSCRIBE returned (its list of per-relay subscriptions), on every
relay, and stop its delivery thread."
  (let* ((subs (if (listp subscriptions) subscriptions (list subscriptions)))
         (ids (remove-duplicates (mapcar #'r:subscription-id subs) :test #'string=)))
    (let ((gone (bt:with-lock-held ((pool-lock pool))
                  (let ((g (remove-if-not (lambda (spec) (member (getf spec :subid) ids :test #'string=))
                                          (pool-subs pool))))
                    (setf (pool-subs pool) (set-difference (pool-subs pool) g))
                    g))))
      (dolist (relay (%members pool))
        (dolist (id ids) (r:unsubscribe relay id)))
      (%stop-deliveries gone))
    ids))

(defun fetch-events (pool filters &key (timeout 5) limit)
  "Collect stored events matching FILTERS from all connected relays, blocking until every
relay sends EOSE or TIMEOUT seconds pass.  Deduplicated by id, newest first.
LIMIT caps the returned count."
  (let* ((relays (remove-if-not #'r:relay-connected-p (%members pool)))
         (n (length relays))
         (results '())
         (eose 0)
         (lock (bt:make-lock "fetch"))
         (seen (make-hash-table :test 'equal)))
    (when (zerop n) (return-from fetch-events '()))
    (flet ((collect (event relay)
             (declare (ignore relay))
             (bt:with-lock-held (lock)
               (let ((id (cl-nostr.event:event-id event)))
                 (unless (gethash id seen)
                   (setf (gethash id seen) t)
                   (push event results)))))
           (eosed (relay)
             (declare (ignore relay))
             (bt:with-lock-held (lock) (incf eose))))
      (let ((subs (loop for relay in relays
                        for sub = (ignore-errors (r:subscribe relay filters
                                                              :on-event #'collect
                                                              :on-eose #'eosed))
                        if sub collect (cons relay sub)
                        else do (bt:with-lock-held (lock) (incf eose)))))
        ;; the events arrive while this thread pumps (WAIT-STEP)
        (let ((end (+ (get-internal-real-time) (round (* timeout internal-time-units-per-second)))))
          (loop until (or (>= (bt:with-lock-held (lock) eose) n)
                          (>= (get-internal-real-time) end))
                do (r::wait-for-relays relays 0.02)))
        (loop for (relay . sub) in subs do (ignore-errors (r:unsubscribe relay sub)))
        (let ((sorted (sort (bt:with-lock-held (lock) (copy-list results))
                            #'> :key #'cl-nostr.event:event-created-at)))
          (if (and limit (> (length sorted) limit)) (subseq sorted 0 limit) sorted))))))

(defun fetch-one (pool filters &key (timeout 5))
  "Fetch the single newest event matching FILTERS, or NIL."
  (first (fetch-events pool filters :timeout timeout :limit 1)))
