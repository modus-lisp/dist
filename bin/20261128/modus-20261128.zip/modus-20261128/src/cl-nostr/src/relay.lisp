;;;; src/relay.lisp — one relay connection.
;;;;
;;;; A relay speaks NIP-01 over a single WebSocket.  Client -> relay messages:
;;;;   ["EVENT", <event>]            publish
;;;;   ["REQ", <subid>, <filter>...] open a subscription
;;;;   ["CLOSE", <subid>]            close it
;;;; Relay -> client:
;;;;   ["EVENT", <subid>, <event>]   a matching event
;;;;   ["EOSE", <subid>]             end of stored events (now live)
;;;;   ["OK", <id>, <bool>, <msg>]   publish accepted/rejected
;;;;   ["NOTICE", <msg>]             human-readable notice
;;;;   ["CLOSED", <subid>, <msg>]    subscription closed by the relay
;;;;
;;;; THE MODEL, the same on every Lisp.  Threads share no state (on modus a thread may not
;;;; store an object it made where another thread can reach it, and a socket belongs to the
;;;; thread that drives it), so a relay is split in two:
;;;;
;;;;   - its I/O THREAD (%LINK-MAIN) owns the WebSocket: it connects, reconnects, pings, sends
;;;;     what it is told to and reads every frame.  It is started on a NAMED function with its
;;;;     channels as :ARGUMENTS and keeps everything it makes in locals.  It moves TEXT: it
;;;;     reads only enough of a frame (type and subscription id) to know where it goes, and it
;;;;     remembers each live subscription's REQ so it can send it again after a reconnect.
;;;;   - the RELAY object stays with the thread that made it, the OWNER: the subscription and
;;;;     pending-OK tables and the callbacks.  Commands go to the I/O thread over the relay's
;;;;     command channel; what comes back is delivered in one of two ways, per subscription:
;;;;
;;;;       :PUMP    to *INBOX*, and the callbacks run on whichever thread PUMPS (PUMP, and
;;;;                every wait in cl-nostr -- U:WAIT-STEP -- pumps).  On modus that must be
;;;;                the owner.  OK replies, NOTICEs, CLOSED and connect failures always come
;;;;                this way.
;;;;       :THREAD  to a DELIVERY THREAD started for the subscription with the callbacks as
;;;;                :ARGUMENTS (so, on modus, from the main thread): the callbacks run there,
;;;;                with no pumping, de-duplicated by event id.  For a caller whose own loop
;;;;                never calls into cl-nostr (cl-deposits' owner, glass's bot).
;;;;
;;;;   - the connection's STATE is fixnums in a vector the owner made, written by the I/O
;;;;     thread (storing a fixnum is not storing an object), so RELAY-CONNECTED-P is right
;;;;     without anybody pumping.
;;;;
;;;; Channels copy what they carry (bobbin), so nothing is shared on SBCL either.

(in-package #:cl-nostr.relay)

(defstruct subscription
  (id nil :type string)
  (filters nil :type list)
  (on-event nil)
  (on-eose nil)
  (slot nil))                 ; delivery slot when delivered on a thread (:DELIVER :THREAD)

;;; State vector slots, and the states of slot 0.
(defconstant +st-state+ 0)
(defconstant +st-connects+ 1)        ; how many times the socket has opened
(defconstant +st-done+ 2)            ; 1 once the I/O thread has ended
(defconstant +st-dropped+ 3)         ; frames thrown away because nobody was draining

(defconstant +connecting+ 0)         ; first attempt in progress
(defconstant +open+ 1)
(defconstant +down+ 2)               ; was open, lost, retrying
(defconstant +closed+ 3)             ; closed, or failed with no retry: the thread has ended
(defconstant +unreachable+ 4)        ; never connected, retrying

(defstruct (relay (:constructor %make-relay))
  (url "" :type string)
  (id 0)                                     ; key in *RELAYS-BY-ID*: how the inbox names it
  (cmd nil)                                  ; channel: owner -> I/O thread
  (state (make-array 4 :initial-element 0))  ; written by the I/O thread: fixnums only
                                             ; (%START-LINK makes it in shared memory)
  (hub nil)                                  ; the owner's HUB: its inbox and relay table
  (subs (make-hash-table :test 'equal))      ; subid -> subscription
  (pending-ok (make-hash-table :test 'equal)) ; event-id -> (lambda (accepted msg))
  (notice-handler nil)
  (error nil)                                ; text of the last connect failure
  (reader nil)                               ; the I/O thread
  (lock (bt:make-lock "relay")))

(defun relay-status (relay)
  "One of :CONNECTING :OPEN :DOWN :CLOSED :UNREACHABLE."
  (case (svref (relay-state relay) +st-state+)
    (0 :connecting) (1 :open) (2 :down) (3 :closed) (t :unreachable)))

(defun relay-connected-p (relay)
  "True while RELAY's socket is open (as its I/O thread last said)."
  (eql (svref (relay-state relay) +st-state+) +open+))

(defun (setf relay-connected-p) (value relay)
  (setf (svref (relay-state relay) +st-state+) (if value +open+ +down+))
  (when (and value (zerop (svref (relay-state relay) +st-connects+)))
    (setf (svref (relay-state relay) +st-connects+) 1))
  value)

(defun relay-ever-connected-p (relay)
  (plusp (svref (relay-state relay) +st-connects+)))

(defun %random-id ()
  (cl-nostr.util:bytes->hex (cl-nostr.util:random-bytes 8)))

;;; ---- shared, made once at load time (on the loading thread) ---------------------------

(defparameter *inbox-bytes* (* 8 1024 1024))
(defparameter *command-bytes* (* 1024 1024))
(defparameter *delivery-bytes* (* 2 1024 1024))
(defparameter *worker-inbox-bytes* (* 512 1024)
  "Inbox capacity for a hub made on a thread other than the main one.  On modus such a channel
   is made in the shared arena, which is small and never reclaimed (and a byte ring there
   reserves 8 bytes per byte), so a worker's channels are kept smaller.")
(defparameter *worker-command-bytes* (* 256 1024)
  "Command channel capacity for a relay made on a thread other than the main one: it bounds
   the largest event such a relay can publish.")

(defun %bytes (main worker) (if (sb-thread:main-thread-p) main worker))
(defconstant +delivery-slots+ 32)


(defvar *delivery* (make-array +delivery-slots+ :initial-element nil)
  "Delivery slot -> its channel (made on first use, reused for ever: a modus channel is never
   reclaimed).  I/O threads read it; only the subscribing thread writes it.")
(defvar *delivery-threads* (make-array +delivery-slots+ :initial-element nil))
(defvar *delivery-refs* (make-array +delivery-slots+ :initial-element 0)
  "How many relay subscriptions still deliver to the slot.")
(defvar *delivery-lock* (bt:make-lock "cl-nostr delivery"))

(defun %shared-vector (n)
  "A vector of N zeros that a thread this one starts can write and this one read: in shared
   memory on modus (where an object a thread makes is copied when handed to another, so the
   writes would land in the copy), a plain vector elsewhere."
  (let ((f (and (find-package "MODUS") (find-symbol "MAKE-SHARED-ARRAY" "MODUS"))))
    (if (and f (fboundp f))
        (funcall f n :initial-element 0)
        (make-array n :initial-element 0))))

;;; ---- owners -----------------------------------------------------------------------------
;;; A relay belongs to the thread that made it, its OWNER, and lives in that thread's HUB: the
;;; owner's inbox (what its relays' I/O threads send back) and its table of open relays.  PUMP
;;; serves the calling thread's hub only, so two threads that pump never take each other's
;;; replies, and a wait inside cl-nostr pumps the hub of the relays it waits for.
;;;
;;; The loading thread's hub is made here.  Another thread gets one on first use, registered in
;;; *THREAD-HUBS* -- which modus refuses (a thread may not store its objects where others can
;;; see them), so there a thread that is not the main one uses relays inside WITH-RELAY-OWNER,
;;; which keeps the hub in a binding of its own.

(defstruct (hub (:constructor %make-hub (thread)))
  thread
  (inbox nil)                       ; channel: this owner's relays' I/O threads -> its PUMP
  (relays (make-hash-table))        ; relay id -> relay
  (open '())                        ; relays made here and not closed
  (spare '())                       ; command channels of closed relays, for reuse
  (next 0)
  (lock (bt:make-lock "cl-nostr hub")))

(defun %new-hub ()
  (let ((h (%make-hub sb-thread:*current-thread*)))
    (setf (hub-inbox h) (bobbin:make-channel :capacity (%bytes *inbox-bytes* *worker-inbox-bytes*)
                                  :name "cl-nostr inbox"))
    h))

(defvar *hub* (%new-hub) "This thread's hub: the loading thread's, or WITH-RELAY-OWNER's.")
(defvar *thread-hubs* (make-hash-table :test 'eq) "thread -> hub, for threads with no binding.")
(defvar *thread-hubs-lock* (bt:make-lock "cl-nostr thread hubs"))

(defun %current-hub (&optional (create t))
  "The calling thread's hub; with CREATE, made (and registered) when it has none."
  (let ((h *hub*) (me sb-thread:*current-thread*))
    (cond ((eq (hub-thread h) me) h)
          ((bt:with-lock-held (*thread-hubs-lock*) (gethash me *thread-hubs*)))
          ((not create) nil)
          (t (let ((new (%make-hub me)))
               (handler-case
                   (bt:with-lock-held (*thread-hubs-lock*) (setf (gethash me *thread-hubs*) new))
                 (error ()
                   (error "cl-nostr: this thread cannot keep relays where PUMP finds them (on ~
                           modus a thread may not store its objects where another can see ~
                           them).  Make and use them inside (CL-NOSTR.RELAY:WITH-RELAY-OWNER () ...).")))
               (setf (hub-inbox new) (bobbin:make-channel :capacity (%bytes *inbox-bytes* *worker-inbox-bytes*)
                                  :name "cl-nostr inbox"))
               new)))))

(defun %hub-relays (hub)
  (bt:with-lock-held ((hub-lock hub)) (copy-list (hub-open hub))))

(defmacro with-relay-owner ((&key) &body body)
  "Run BODY with a hub of its own: the relays and pools it makes belong to this thread, PUMP
   here serves them, and they are closed when BODY is left.  Needed on modus by any thread but
   the main one; harmless (and the same) elsewhere."
  `(let ((*hub* (%new-hub)))
     (unwind-protect (progn ,@body)
       (mapc #'close-relay (%hub-relays *hub*)))))

(defvar *open-relays* '()
  "Unused: each owner's open relays are in its hub (kept so old code that reads it loads).")
(defvar *pump-hooks* '()
  "Functions of no arguments PUMP calls once per call.")

;;; ---- the I/O thread ---------------------------------------------------------------------
;;; Everything from here to THE OWNER SIDE runs on a relay's I/O thread and keeps its state in
;;; locals.  What it is handed (the channels, the state vector, the delivery table) it reads,
;;; and the only thing it stores into is the state vector, and only fixnums.

(defun %json-string-at (s i)
  "The JSON string starting at S[I] (a #\"), and the index past it; NIL if there is none."
  (let ((n (length s)))
    (when (and (< i n) (char= (char s i) #\"))
      (let ((j (1+ i)))
        (loop
          (when (>= j n) (return nil))
          (let ((c (char s j)))
            (cond ((char= c #\") (return (values (subseq s (1+ i) j) (1+ j))))
                  ((char= c #\\) (return nil))   ; rare in an id: the caller parses the frame
                  (t (incf j)))))))))

(defun %skip-ws (s i)
  (loop while (and (< i (length s)) (member (char s i) '(#\Space #\Tab #\Newline #\Return)))
        do (incf i))
  i)

(defun %frame-head (text)
  "The message type and its first string argument of a relay frame, without parsing the
   rest: (values TYPE ARG).  Falls back to a full parse for frames the fast path cannot read."
  (block nil
    (let ((i (%skip-ws text 0)))
      (when (and (< i (length text)) (char= (char text i) #\[))
        (multiple-value-bind (type j) (%json-string-at text (%skip-ws text (1+ i)))
          (when type
            (let ((k (%skip-ws text j)))
              (if (and (< k (length text)) (char= (char text k) #\,))
                  (multiple-value-bind (arg m) (%json-string-at text (%skip-ws text (1+ k)))
                    (declare (ignore m))
                    (when arg (return (values type arg))))
                  (return (values type nil))))))))
    (let ((msg (ignore-errors (json-simple:parse text))))
      (if (and (vectorp msg) (plusp (length msg)) (stringp (aref msg 0)))
          (values (aref msg 0) (and (> (length msg) 1) (stringp (aref msg 1)) (aref msg 1)))
          (values nil nil)))))

;;; A PLAIN ws:// SOCKET'S END IS NOT "PENDING" ON SBCL.  seal's PENDING-P asks LISTEN, and SBCL's
;;; LISTEN on a socket stream at end of file answers NIL (modus's answers T), so a relay that
;;; closed its end looked merely quiet: the loss was only noticed at the next keepalive ping.
;;; So, when nothing is pending, ask the descriptor too: readable with nothing to LISTEN to is
;;; the end, and a blocking RECEIVE then reads it (and returns NIL) at once.  wss:// does not
;;; need this: seal's TLS stream asks the descriptor itself.
(defvar *fd-stream-fd* :unknown)

(defun %fd-of (stream)
  (when (eq *fd-stream-fd* :unknown)
    (setf *fd-stream-fd*
          (let ((s (and (find-package "SB-SYS") (find-symbol "FD-STREAM-FD" "SB-SYS"))))
            (and s (fboundp s) (symbol-function s)))))
  (and *fd-stream-fd* (ignore-errors (funcall *fd-stream-fd* stream))))

(defun %ended-p (ws)
  "True when WS's plain socket is readable although nothing is pending: its peer closed it."
  (let ((s (seal.websocket:websocket-stream ws)))
    (and (not (typep s 'seal:tls-stream))
         (let ((fd (%fd-of s)))
           (and (integerp fd) (ignore-errors (seal:wait-readable fd 0)))))))

(defun %link-main (id url verify timeout cmd inbox state delivery reconnect ping-every
                   retry-first retry-max lost-first lost-max)
  "A relay's I/O thread: owns the WebSocket to URL; runs commands from CMD; reports to INBOX
   (as (ID kind . data)) and to delivery channels; keeps STATE.  With RECONNECT it retries:
   a relay that has never answered after RETRY-FIRST seconds, doubling to RETRY-MAX; one that
   was open and was lost after LOST-FIRST, doubling to LOST-MAX -- and sends every live
   subscription again on each connect.  Without RECONNECT the first failure or loss ends it."
  (let ((ws nil)
        (subs (make-hash-table :test 'equal))   ; subid -> (req-text . slot-or-nil)
        (oks (make-hash-table :test 'equal))    ; event ids whose OK the owner waits for
        (notices nil)
        (ever nil)
        (delay retry-first)
        (cap retry-max)
        (next-try 0)
        (next-ping nil)
        (stalled-until 0)                       ; inbox full: do not wait on it until then
        (idle 0.001)
        (hz internal-time-units-per-second))
    (labels ((now () (get-internal-real-time))
             (set-state (s) (setf (svref state +st-state+) s))
             (dropped () (setf (svref state +st-dropped+) (1+ (svref state +st-dropped+))))
             (emit (kind &rest data)
               ;; Never let an owner that is not pumping stop the socket: after one send that
               ;; timed out, the next ones only go in if there is room now.
               (let ((ok (ignore-errors
                          (bobbin:channel-send inbox (list* id kind data)
                                               :timeout (if (< (now) stalled-until) 0 1)))))
                 (unless ok
                   (dropped)
                   (setf stalled-until (+ (now) (* 10 hz))))
                 ok))
             (deliver (slot msg)
               (let ((ch (svref delivery slot)))
                 (unless (and ch (ignore-errors (bobbin:channel-send ch msg :timeout 10)))
                   (dropped))))
             (close-ws ()
               (when ws (ignore-errors (seal.websocket:close-socket ws)) (setf ws nil)))
             (send (text)
               (handler-case (progn (seal.websocket:send-text ws text) t)
                 (error () (lost) nil)))
             (connect ()
               (handler-case
                   (progn
                     (setf ws (seal.websocket:connect url :verify verify :timeout timeout))
                     (setf ever t delay lost-first cap lost-max
                           next-ping (and ping-every (+ (now) (* ping-every hz))))
                     (setf (svref state +st-connects+) (1+ (svref state +st-connects+)))
                     (set-state +open+)
                     (loop for (req) being the hash-values of subs
                           while ws do (send req))
                     t)
                 (error (e)
                   (setf ws nil)
                   (emit :failed (or (ignore-errors (princ-to-string e)) "connect failed"))
                   (if reconnect
                       (progn (set-state (if ever +down+ +unreachable+)) (schedule) nil)
                       (progn (set-state +closed+) (throw 'done nil))))))
             (schedule ()
               (setf next-try (+ (now) (round (* delay hz)))
                     delay (min cap (* 2 delay))))
             (lost ()
               (close-ws)
               (if reconnect
                   (progn (set-state +down+) (schedule))
                   (progn (set-state +closed+) (throw 'done nil))))
             (route (text)
               (multiple-value-bind (type arg) (%frame-head text)
                 (cond
                   ((null type))
                   ((string= type "EVENT")
                    (let ((sub (and arg (gethash arg subs))))
                      (when sub
                        (if (cdr sub)
                            (deliver (cdr sub) (list :event arg url text))
                            (emit :text text)))))
                   ((string= type "EOSE")
                    (let ((sub (and arg (gethash arg subs))))
                      (when sub
                        (if (cdr sub)
                            (deliver (cdr sub) (list :eose arg url))
                            (emit :text text)))))
                   ((string= type "OK")
                    (when (and arg (gethash arg oks))
                      (remhash arg oks)
                      (emit :text text)))
                   ((string= type "NOTICE") (when notices (emit :text text)))
                   ((string= type "CLOSED")
                    (let ((sub (and arg (gethash arg subs))))
                      (when sub
                        (remhash arg subs)
                        (unless (cdr sub) (emit :text text))))))))
             (command (c)
               (case (first c)
                 (:send (destructuring-bind (text &optional ok-id) (rest c)
                          (when ok-id (setf (gethash ok-id oks) t))
                          (when ws (send text))))
                 (:sub (destructuring-bind (subid req slot) (rest c)
                         (setf (gethash subid subs) (cons req slot))
                         (when ws (send req))))
                 (:unsub (destructuring-bind (subid text) (rest c)
                           (when (gethash subid subs)
                             (remhash subid subs)
                             (when ws (send text)))))
                 (:notices (setf notices (second c)))
                 (:ping (when ws
                          (handler-case (seal.websocket:send-ping ws) (error () (lost)))))
                 (:close (throw 'done nil))))
             (drain-commands ()
               (loop (multiple-value-bind (c ok) (bobbin:channel-try-receive cmd)
                       (unless ok (return))
                       (command c))))
             (read-frames ()
               "Every frame ready now; the number read."
               (let ((n 0))
                 (loop while (and ws (< n 64))
                       do (multiple-value-bind (text st)
                              (handler-case (seal.websocket:receive-text ws :wait nil)
                                (error () (values nil :error)))
                            (cond ((stringp text) (incf n) (route text))
                                  (text (incf n))              ; a binary frame: not NIP-01
                                  ((eq st :pending)
                                   (when (and (zerop n) (%ended-p ws))
                                     (multiple-value-bind (text)
                                         (handler-case (seal.websocket:receive-text ws :wait t)
                                           (error () nil))
                                       (if (stringp text) (progn (incf n) (route text)) (lost))))
                                   (return))
                                  (t (lost) (return)))))
                 n)))
      (unwind-protect
           (catch 'done
             (connect)
             (loop
               (drain-commands)
               (cond
                 (ws
                  (if (plusp (read-frames))
                      (setf idle 0.001)
                      (progn
                        (when (and ws next-ping (>= (now) next-ping))
                          (setf next-ping (+ (now) (* ping-every hz)))
                          (handler-case (seal.websocket:send-ping ws) (error () (lost))))
                        ;; wait for a command, or for input to arrive (polled)
                        (multiple-value-bind (c ok) (bobbin:channel-receive cmd :timeout idle)
                          (when ok (command c) (setf idle 0.001)))
                        (setf idle (min 0.01 (* 2 idle))))))
                 ((>= (now) next-try) (connect))
                 (t (multiple-value-bind (c ok)
                        (bobbin:channel-receive
                         cmd :timeout (max 0.001 (min 0.25 (/ (- next-try (now)) hz))))
                      (when ok (command c)))))))
        (close-ws)
        (set-state +closed+)
        (setf (svref state +st-done+) 1)))))

;;; ---- delivery threads (:DELIVER :THREAD) ------------------------------------------------

(defun %delivery-main (subid ch on-event on-eose)
  "A subscription's delivery thread: parse each event its relays forward on CH, drop repeats
   (the same note from several relays, or again after a reconnect), and call ON-EVENT (event
   relay); ON-EOSE (relay) per relay.  RELAY here is a stand-in made on this thread with the
   relay's URL: the real relay object belongs to its owner."
  (let ((seen (make-hash-table :test 'equal))
        (views (make-hash-table :test 'equal)))
    (flet ((view (url)
             (or (gethash url views)
                 (setf (gethash url views)
                       (let ((r (%make-relay :url url)))
                         (setf (svref (relay-state r) +st-state+) +open+
                               (svref (relay-state r) +st-connects+) 1)
                         r)))))
      (loop
        (multiple-value-bind (m ok) (bobbin:channel-receive ch)
          (when ok
            (case (first m)
              (:stop (when (equal (second m) subid) (return)))
              (:event
               (destructuring-bind (sid url text) (rest m)
                 (when (equal sid subid)
                   (handler-case
                       (let* ((msg (json-simple:parse text))
                              (event (cl-nostr.event:json->event (aref msg 2)))
                              (eid (cl-nostr.event:event-id event)))
                         (unless (gethash eid seen)
                           (setf (gethash eid seen) t)
                           (when on-event (funcall on-event event (view url)))))
                     (error () nil)))))
              (:eose
               (destructuring-bind (sid url) (rest m)
                 (when (and (equal sid subid) on-eose)
                   (handler-case (funcall on-eose (view url)) (error () nil))))))))))))

(defun %delivery-start (subid on-event on-eose)
  "A delivery slot running a thread for SUBID's callbacks; the slot number."
  (handler-case (%delivery-start-1 subid on-event on-eose)
    (error (e)
      (error "cl-nostr: no delivery thread for the subscription (~a).  On modus only the main ~
              thread can start one with callbacks it made; subscribe with :DELIVER :PUMP and ~
              PUMP on this thread instead." e))))

(defun %delivery-start-1 (subid on-event on-eose)
  (bt:with-lock-held (*delivery-lock*)
    (let ((slot (loop for i below +delivery-slots+
                      for th = (svref *delivery-threads* i)
                      when (or (null th) (not (sb-thread:thread-alive-p th)))
                        return i)))
      (unless slot (error "cl-nostr: all ~d delivery threads are in use" +delivery-slots+))
      (let ((ch (or (svref *delivery* slot)
                    (setf (svref *delivery* slot)
                          (bobbin:make-channel :capacity *delivery-bytes*
                                               :name "cl-nostr delivery")))))
        (bobbin:channel-drain ch)
        (setf (svref *delivery-refs* slot) 0
              (svref *delivery-threads* slot)
              (sb-thread:make-thread #'%delivery-main
                                     :name (format nil "cl-nostr delivery ~a" subid)
                                     :arguments (list subid ch on-event on-eose)))
        slot))))

(defun %delivery-ref (slot delta subid)
  "Count a relay subscription on SLOT in or out (DELTA 0 only asks); at zero its thread is told
   to stop."
  (bt:with-lock-held (*delivery-lock*)
    (when (<= (incf (svref *delivery-refs* slot) delta) 0)
      (setf (svref *delivery-refs* slot) 0)
      (ignore-errors (bobbin:channel-send (svref *delivery* slot) (list :stop subid) :timeout 2)))))

;;; ---- the owner side: dispatch of what comes back by *INBOX* -----------------------------

(defun %as-bool (x) (and x t))           ; json-simple parses JSON true/false to T/NIL

(defun %dispatch (relay text)
  (let ((msg (ignore-errors (json-simple:parse text))))
    (when (and msg (vectorp msg) (plusp (length msg)))
      (let ((type (aref msg 0)))
        (cond
          ((string= type "EVENT")
           (let* ((subid (aref msg 1))
                  (event (cl-nostr.event:json->event (aref msg 2)))
                  (sub (bt:with-lock-held ((relay-lock relay))
                         (gethash subid (relay-subs relay)))))
             (when (and sub (subscription-on-event sub))
               (funcall (subscription-on-event sub) event relay))))
          ((string= type "EOSE")
           (let* ((subid (aref msg 1))
                  (sub (bt:with-lock-held ((relay-lock relay))
                         (gethash subid (relay-subs relay)))))
             (when (and sub (subscription-on-eose sub))
               (funcall (subscription-on-eose sub) relay))))
          ((string= type "OK")
           (let* ((id (aref msg 1))
                  (accepted (%as-bool (and (> (length msg) 2) (aref msg 2))))
                  (note (and (> (length msg) 3) (aref msg 3)))
                  (cb (bt:with-lock-held ((relay-lock relay))
                        (prog1 (gethash id (relay-pending-ok relay))
                          (remhash id (relay-pending-ok relay))))))
             (when cb (funcall cb accepted note))))
          ((string= type "NOTICE")
           (when (relay-notice-handler relay)
             (funcall (relay-notice-handler relay) (and (> (length msg) 1) (aref msg 1)))))
          ((string= type "CLOSED")
           (let ((subid (aref msg 1)))
             (bt:with-lock-held ((relay-lock relay))
               (remhash subid (relay-subs relay))))))))))

(defun %handle-inbox (hub m)
  (destructuring-bind (id kind &rest data) m
    (let ((relay (bt:with-lock-held ((hub-lock hub)) (gethash id (hub-relays hub)))))
      (when relay
        (case kind
          (:text (handler-case (%dispatch relay (first data)) (error () nil)))
          (:failed (setf (relay-error relay) (first data))))))))

(defun pump (&optional (timeout 0))
  "Run, on THIS thread, the callbacks for what THIS thread's relays have delivered by pumping
-- OK replies, NOTICEs, and subscriptions made with :DELIVER :PUMP -- for up to TIMEOUT
seconds.  Returns how many messages were handled, as soon as at least one was and no more are
waiting.  Every wait in cl-nostr pumps, so an application's own loop needs to call this only
for :PUMP subscriptions of its own."
  (dolist (hook *pump-hooks*) (ignore-errors (funcall hook)))
  (let ((hub (%current-hub nil)))
    (if hub
        (%pump-hub hub timeout)
        (progn (when (plusp timeout) (sleep timeout)) 0))))

(defun %pump-hub (hub timeout)
  (let ((end (+ (get-internal-real-time) (round (* timeout internal-time-units-per-second))))
        (inbox (hub-inbox hub))
        (n 0))
    (loop
      (multiple-value-bind (m ok) (bobbin:channel-try-receive inbox)
        (if ok
            (progn (incf n) (%handle-inbox hub m))
            (let ((left (- end (get-internal-real-time))))
              ;; return once something was handled and nothing more is waiting: a caller
              ;; waiting for one reply looks again at once rather than after TIMEOUT
              (when (or (<= left 0) (plusp n)) (return n))
              (multiple-value-bind (m ok)
                  (bobbin:channel-receive inbox :timeout (/ left internal-time-units-per-second))
                (when ok (incf n) (%handle-inbox hub m)))))))))

(defun pump-relays (relays &optional (timeout 0))
  "PUMP for RELAYS: run the callbacks for what they have delivered, whoever's they are, for up
   to TIMEOUT seconds.  For a thread that services relays another thread made (on SBCL; on modus
   a thread can only touch its own).  cl-nostr's own waits use it."
  (wait-for-relays relays timeout))

(defun wait-for-relays (relays seconds)
  "Wait SECONDS, pumping the hubs RELAYS belong to (each relay's owner's: the caller's own,
   except on a Lisp where one thread may use another's pool)."
  (let ((hubs (remove-duplicates (remove nil (mapcar #'relay-hub relays)))))
    (cond ((null hubs) (u:wait-step seconds))
          ((null (rest hubs)) (%pump-hub (first hubs) seconds))
          (t (dolist (h hubs) (%pump-hub h 0))
             (sleep (min seconds 0.005))))))

(setf cl-nostr.util::*pump* #'pump)

;;; ---- connect / send ------------------------------------------------------

(defparameter *reconnect-delay* 1
  "Seconds before the first try at a relay whose socket was lost; doubles per failure.")

(defun %start-link (url &key (verify t) (timeout 10) on-notice reconnect ping-every
                          (retry-first *reconnect-delay*) (retry-max 600)
                          (lost-first *reconnect-delay*) (lost-max 60))
  "A relay object for URL and its I/O thread, started (not waited for)."
  (let* ((hub (%current-hub))
         (cmd (or (bt:with-lock-held ((hub-lock hub)) (pop (hub-spare hub)))
                  (bobbin:make-channel :capacity (%bytes *command-bytes* *worker-command-bytes*)
                                       :name "cl-nostr relay")))
         (relay (%make-relay :url url :cmd cmd :notice-handler on-notice :hub hub
                             :state (%shared-vector 4))))
    (bobbin:channel-drain cmd)
    (bt:with-lock-held ((hub-lock hub))
      (setf (relay-id relay) (incf (hub-next hub))
            (gethash (relay-id relay) (hub-relays hub)) relay)
      (push relay (hub-open hub)))
    (when on-notice (bobbin:channel-send cmd (list :notices t)))
    (setf (relay-reader relay)
          (sb-thread:make-thread #'%link-main
                                 :name (format nil "cl-nostr relay ~a" url)
                                 :arguments (list (relay-id relay) url verify timeout cmd (hub-inbox hub)
                                                  (relay-state relay) *delivery* reconnect
                                                  ping-every retry-first retry-max
                                                  lost-first lost-max)))
    relay))

(defun %await-first (relay timeout)
  "Wait (pumping) up to TIMEOUT seconds for RELAY's first connection attempt to finish.
   T if it is open."
  (let ((end (+ (get-internal-real-time) (round (* timeout internal-time-units-per-second)))))
    (loop until (or (/= (svref (relay-state relay) +st-state+) +connecting+)
                    (>= (get-internal-real-time) end))
          do (wait-for-relays (list relay) 0.01))
    (relay-connected-p relay)))

(defun connect-relay (url &key on-notice (verify t) (timeout 10) reconnect)
  "Open a relay at URL (ws:// or wss://).  Blocks until connected or errors.
ON-NOTICE, if given, is called with each NOTICE message string (when this thread pumps).
With RECONNECT, a lost socket is reopened (and every live subscription sent again) by the
relay's I/O thread; without, a lost relay stays closed.

seal.websocket is a blocking client; the relay's I/O thread is the one that blocks."
  (let ((relay (%start-link url :verify verify :timeout timeout :on-notice on-notice
                                :reconnect reconnect)))
    (unless (%await-first relay timeout)
      (let ((why (relay-error relay)))
        (close-relay relay)
        (error "could not connect to relay ~a~@[: ~a~]" url why)))
    relay))

(defun %command (relay message)
  (let ((cmd (relay-cmd relay)))
    (unless cmd (error "relay has no connection: ~a" (relay-url relay)))
    (unless (bobbin:channel-send cmd message :timeout 10)
      (error "relay ~a: its I/O thread is not taking commands" (relay-url relay)))))

(defun %send (relay string &optional ok-id)
  (unless (relay-connected-p relay) (error "relay not connected: ~a" (relay-url relay)))
  (%command relay (if ok-id (list :send string ok-id) (list :send string))))

(defun close-relay (relay)
  "Close the relay's WebSocket and end its I/O thread."
  (when (relay-cmd relay)
    (ignore-errors (bobbin:channel-send (relay-cmd relay) (list :close) :timeout 2)))
  (let ((hub (relay-hub relay)))
    (when hub
      (bt:with-lock-held ((hub-lock hub))
        (setf (hub-open hub) (remove relay (hub-open hub)))
        (remhash (relay-id relay) (hub-relays hub)))))
  ;; the delivery threads of its subscriptions lose a source
  (let ((subs (bt:with-lock-held ((relay-lock relay))
                (prog1 (loop for s being the hash-values of (relay-subs relay) collect s)
                  (clrhash (relay-subs relay))))))
    (dolist (s subs)
      (when (subscription-slot s) (%delivery-ref (subscription-slot s) -1 (subscription-id s)))))
  (let ((th (relay-reader relay)))
    (when th
      ;; the thread ends after the command it is in (a connect in flight finishes first)
      (loop repeat 200
            until (eql (svref (relay-state relay) +st-done+) 1)
            do (sleep 0.01))
      (when (eql (svref (relay-state relay) +st-done+) 1)
        (ignore-errors (sb-thread:join-thread th :default nil))
        (let ((cmd (relay-cmd relay)))
          (when cmd
            (bobbin:channel-drain cmd)
            (when (relay-hub relay)
              (bt:with-lock-held ((hub-lock (relay-hub relay)))
                (push cmd (hub-spare (relay-hub relay))))))))
      (setf (relay-reader relay) nil (relay-cmd relay) nil)))
  (unless (eql (svref (relay-state relay) +st-state+) +closed+)
    (setf (svref (relay-state relay) +st-state+) +closed+))
  relay)

(defun relay-ping (relay)
  "Ask the relay's I/O thread to send a WebSocket ping.  A failure there marks the relay
disconnected (and, for a reconnecting relay, reopens it)."
  (when (relay-connected-p relay)
    (ignore-errors (%command relay (list :ping)) t)))

;;; ---- publish / subscribe -------------------------------------------------

(defun publish (relay event &key on-ok)
  "Send EVENT to the relay.  ON-OK, if given, is called as (accepted-p message)
when the relay replies with OK for this event id (on the thread that pumps)."
  (let ((id (cl-nostr.event:event-id event)))
    (when on-ok
      (bt:with-lock-held ((relay-lock relay))
        (setf (gethash id (relay-pending-ok relay)) on-ok)))
    (%send relay (concatenate 'string "[\"EVENT\"," (cl-nostr.event:event->json event) "]")
           (and on-ok id))
    id))

(defun %req-text (subid filters)
  (with-output-to-string (out)
    (format out "[\"REQ\",~s" subid)
    (dolist (f filters)
      (write-char #\, out)
      (write-string (cl-nostr.filter:filter->json f) out))
    (write-char #\] out)))

(defun %subscribe (relay filters subid on-event on-eose slot)
  "Register a subscription on RELAY and hand its REQ to the I/O thread, which sends it now if
   connected, and again after each reconnect."
  (let ((sub (make-subscription :id subid :filters filters :on-event on-event
                                :on-eose on-eose :slot slot)))
    (bt:with-lock-held ((relay-lock relay))
      (setf (gethash subid (relay-subs relay)) sub))
    (when slot (%delivery-ref slot 1 subid))
    (%command relay (list :sub subid (%req-text subid filters) slot))
    sub))

(defun subscribe (relay filters &key on-event on-eose id (deliver :pump))
  "Open a subscription for FILTERS (a single filter or a list).  ON-EVENT is
called (event relay) per matching event; ON-EOSE (relay) at end of stored events.
DELIVER :PUMP (the default) runs them on the thread that pumps (every cl-nostr wait
pumps); :THREAD runs them on a thread of the subscription's own, de-duplicated by event
id, with no pumping needed (on modus, subscribe from the main thread).
Returns the subscription."
  (let* ((filters (if (listp filters) filters (list filters)))
         (subid (or id (%random-id)))
         (slot (ecase deliver
                 (:pump nil)
                 (:thread (%delivery-start subid on-event on-eose)))))
    (%subscribe relay filters subid on-event on-eose slot)))

(defun unsubscribe (relay subscription-or-id)
  "Close a subscription (by object or subid string)."
  (let* ((subid (if (subscription-p subscription-or-id)
                    (subscription-id subscription-or-id)
                    subscription-or-id))
         (sub (bt:with-lock-held ((relay-lock relay))
                (prog1 (gethash subid (relay-subs relay))
                  (remhash subid (relay-subs relay))))))
    (when (and sub (subscription-slot sub))
      (%delivery-ref (subscription-slot sub) -1 subid))
    (ignore-errors (%command relay (list :unsub subid (format nil "[\"CLOSE\",~s]" subid))))
    subid))

;;; thin re-exports so callers can set handlers after connecting
(defun on-event (sub fn) (setf (subscription-on-event sub) fn))
(defun on-eose (sub fn) (setf (subscription-on-eose sub) fn))
(defun on-notice (relay fn)
  (setf (relay-notice-handler relay) fn)
  (ignore-errors (%command relay (list :notices (and fn t)))))
(defun on-ok (relay event-id fn)
  "Have FN called (accepted message) on EVENT-ID's OK.  Only an OK the I/O thread was told
   to wait for comes back: register before publishing (PUBLISH's :ON-OK does)."
  (bt:with-lock-held ((relay-lock relay))
    (setf (gethash event-id (relay-pending-ok relay)) fn)))
